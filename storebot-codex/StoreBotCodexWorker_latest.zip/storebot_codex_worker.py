#!/usr/bin/env python3
from __future__ import annotations

import argparse
import atexit
from contextlib import contextmanager
from email.utils import parsedate_to_datetime
import hashlib
import http.server
import ipaddress
import io
import json
import os
import re
import select
import secrets
import shlex
import signal
import shutil
import socket
import stat
import subprocess
import sys
import tempfile
import threading
import time
import urllib.error
import urllib.parse
import urllib.request
import uuid
import zipfile
import xml.etree.ElementTree as ET
from dataclasses import dataclass, field
from datetime import datetime, timezone, timedelta
from pathlib import Path
from typing import Any, Callable

try:
    import fcntl
except ImportError:  # pragma: no cover - server-phone deployment is POSIX.
    fcntl = None

try:
    import yaml as _yaml
except Exception:  # pragma: no cover - exercised only on stripped worker bundles.
    _yaml = None

try:
    from operation_knowledge_adapter import (
        AUDIT_PATH as KNOWLEDGE_AUDIT_PATH,
        OUTPUT_VARIANTS_PATH as KNOWLEDGE_OUTPUT_VARIANTS_PATH,
        QUEUE_PATH as KNOWLEDGE_QUEUE_PATH,
        OperationKnowledgeError,
        RAW_ITEMS_PATH as KNOWLEDGE_RAW_ITEMS_PATH,
        STRUCTURED_SUMMARIES_PATH as KNOWLEDGE_STRUCTURED_SUMMARIES_PATH,
        WORKSCHEDULE_V2_PATH as KNOWLEDGE_CANONICAL_SCHEDULE_SOURCE,
        build_operation_knowledge_preview,
        delete_request_payload as build_operation_knowledge_delete_request,
        hard_delete_payload as build_operation_knowledge_hard_delete,
        ingest_raw_item as build_operation_knowledge_ingest,
        process_queue_job as build_operation_knowledge_process_job,
        render_output_payload as build_operation_knowledge_render_output,
        restore_payload as build_operation_knowledge_restore,
        soft_delete_payload as build_operation_knowledge_soft_delete,
        target_path as operation_knowledge_target_path,
        upsert_output_variant as build_operation_knowledge_output_upsert,
        upsert_structured_summary as build_operation_knowledge_summary_upsert,
        ensure_write_enabled_adapter_contract,
    )
except ModuleNotFoundError:  # pragma: no cover - used when imported as scripts.storebot_codex_worker.
    from scripts.operation_knowledge_adapter import (
        AUDIT_PATH as KNOWLEDGE_AUDIT_PATH,
        OUTPUT_VARIANTS_PATH as KNOWLEDGE_OUTPUT_VARIANTS_PATH,
        QUEUE_PATH as KNOWLEDGE_QUEUE_PATH,
        OperationKnowledgeError,
        RAW_ITEMS_PATH as KNOWLEDGE_RAW_ITEMS_PATH,
        STRUCTURED_SUMMARIES_PATH as KNOWLEDGE_STRUCTURED_SUMMARIES_PATH,
        WORKSCHEDULE_V2_PATH as KNOWLEDGE_CANONICAL_SCHEDULE_SOURCE,
        build_operation_knowledge_preview,
        delete_request_payload as build_operation_knowledge_delete_request,
        hard_delete_payload as build_operation_knowledge_hard_delete,
        ingest_raw_item as build_operation_knowledge_ingest,
        process_queue_job as build_operation_knowledge_process_job,
        render_output_payload as build_operation_knowledge_render_output,
        restore_payload as build_operation_knowledge_restore,
        soft_delete_payload as build_operation_knowledge_soft_delete,
        target_path as operation_knowledge_target_path,
        upsert_output_variant as build_operation_knowledge_output_upsert,
        upsert_structured_summary as build_operation_knowledge_summary_upsert,
        ensure_write_enabled_adapter_contract,
    )

try:
    from storebot_telegram_worker_adapter import StoreBotTelegramWorkerAdapter
except ModuleNotFoundError:  # pragma: no cover - used when imported as scripts.storebot_codex_worker.
    try:
        from scripts.storebot_telegram_worker_adapter import StoreBotTelegramWorkerAdapter
    except ModuleNotFoundError:  # pragma: no cover - optional default-off bundle component.
        StoreBotTelegramWorkerAdapter = None  # type: ignore[assignment,misc]


BASE_DIR = Path(__file__).resolve().parents[1]
DEFAULT_FIREBASE = "https://poskds-4ba60-default-rtdb.asia-southeast1.firebasedatabase.app"
REQUESTS_PATH = "/packhelper/storebot_codex/requests"
EXPLICIT_ACTION_REQUESTS_PATH = "/packhelper/storebot_codex/explicit_pending"
OPS_MANUAL_ROOT = "/packhelper/ops_manual"
OPS_MANUAL_ENTRIES_PATH = f"{OPS_MANUAL_ROOT}/entries"
OPS_MANUAL_CANDIDATES_PATH = f"{OPS_MANUAL_ROOT}/candidates"
OPS_MANUAL_READ_MODEL_SEARCH_PATH = f"{OPS_MANUAL_ROOT}/read_model/search"
INPUT_HEALTH_PATH = "/packhelper/storebot_termux/input_health/latest"
IMAGE_SEND_ENABLED_PATH = "/packhelper/storebot_termux/image_send_enabled"
IMAGE_SEND_MODE_PATH = "/packhelper/storebot_termux/image_send_mode"
IMAGE_SEND_PAUSE_REASON_PATH = "/packhelper/storebot_termux/image_send_pause_reason"
THERMAL_STATE_PATH = "/packhelper/storebot_termux/thermal_state"
IMAGE_SEND_CONFIG_CACHE_SEC = 15.0
SCHEDULE_IMAGE_REQUEST_DEDUPE_TTL_SEC = 180.0
SCHEDULE_IMAGE_REQUEST_CAUTION_COOLDOWN_SEC = 12 * 60.0
SCHEDULE_IMAGE_FALLBACK_POLICY = "retry_pending"
WORK_SCHEDULE_BROADCAST_EVENT_KIND = "work_schedule_broadcast"
LEGACY_SCHEDULE_FIXED_BRIEFING_EVENT_KIND = "schedule_fixed_briefing"
SCHEDULE_IMAGE_EVENT_KINDS = {
    WORK_SCHEDULE_BROADCAST_EVENT_KIND,
    LEGACY_SCHEDULE_FIXED_BRIEFING_EVENT_KIND,
}
USER_CHAT_EVENT_KINDS = {"", "chat", "chat_image", "chat_replay"}
CHAT_IMAGE_EVENT_KIND = "chat_image"
CHAT_VISION_DEFAULT_ROOTS = (
    "/sdcard/Android/data/com.sbotux/files/Download/storebot_chat_vision",
    "/storage/emulated/0/Android/data/com.sbotux/files/Download/storebot_chat_vision",
)
CHAT_VISION_MAX_BYTES = 8 * 1024 * 1024
CHAT_VISION_MAX_AGE_MS = 35 * 60 * 1000
HARD_NO_REPLY_EVENT_KINDS = {
    "action_result",
    "android_latency",
    "attachment_status",
    "debug_kakao_attachment_status",
    "freshness_metadata_self_test",
    "heartbeat",
    "input_health",
    "keepalive",
    "local_direct_health",
    "native_supervisor",
    "ops_receiver",
    "self_fix",
    "self_heal",
    "system",
    "worker_action",
    "worker_heartbeat",
}
CONTEXTLESS_NO_REPLY_MARKERS = (
    "accessibility_foreground_scan",
    "android_latency",
    "attachment_status",
    "debug_kakao_attachment_status",
    "foreground_scan",
    "freshness_metadata_self_test",
    "heartbeat",
    "input_health",
    "keepalive",
    "native_supervisor",
    "ops_receiver",
    "self_test",
    "worker_action",
)
SELF_REPLY_SENDERS = {
    "백수",
    "StoreBot",
    "StoreBotTermux",
    "storebot",
    "storebottermux",
}
EXPLICIT_KAKAO_REPLY_KEYS = (
    "allow_kakao_reply",
    "direct_inject",
    "explicit_kakao_reply",
    "kakao_reply_allowed",
    "publish_to_kakao",
    "requires_codex_output",
    "send_to_kakao",
)
CODEX_OPS_BASE_PATH = os.environ.get("CODEX_OPS_BASE_PATH", "/packhelper/codex_ops_v2").rstrip("/")
CODEX_OPS_REQUESTS_PATH = f"{CODEX_OPS_BASE_PATH}/requests"
SESSIONS_PATH = "/packhelper/storebot_codex/sessions"
ROOM_CONTEXT_PATH = "/packhelper/storebot_codex/room_context"
ROOM_EVENT_JOURNAL_PATH = "/packhelper/storebot_codex/room_event_journal"
ACTION_LEDGER_PATH = "/packhelper/storebot_codex/action_ledger"
RECONCILIATION_PATH = "/packhelper/storebot_codex/reconciliation"
BRIEFING_CHANNEL_REMOTE_PATH = "/packhelper/storebot_termux/briefing_channel"
BRIEFING_CHANNEL_DEFAULT_DIR = "/sdcard/Download/StoreBotTermux/briefing_channel"
BRIEFING_CHANNEL_MAX_RECENT = 12
HEARTBEAT_PATH = "/packhelper/storebot_codex/heartbeat"
OUTBOUND_PATH = "/packhelper/storebot_pending_queue"
CAPTURE_PATH = "/packhelper/capture"
TEMP_ALERTS_PATH = "/packhelper/storebot_codex/temp_alerts"
TEMP_ALERTS_LATEST_PATH = f"{TEMP_ALERTS_PATH}/latest"
SCHEDULE_TIMER_PATH = "/packhelper/storebot_codex/schedule_timer"
SCHEDULE_TIMER_LATEST_PATH = f"{SCHEDULE_TIMER_PATH}/latest"
WORK_SCHEDULE_BROADCAST_STATE_PATH = "/packhelper/storebot_termux/work_schedule_broadcast_state"
SELF_SYNC_STATUS_PATH = "/packhelper/storebot_codex/self_sync/latest"
LEARNING_STAMPS_PATH = "/packhelper/ai_learning/storebot/codex_stamps"
LEARNING_STAMP_LATEST_PATH = "/packhelper/storebot_codex/learning_stamp/latest"
DYNAMIC_GUIDANCE_PATH = "/packhelper/storebot_codex/dynamic_guidance"
DYNAMIC_GUIDANCE_RULES_PATH = f"{DYNAMIC_GUIDANCE_PATH}/rules"
DYNAMIC_GUIDANCE_LATEST_PATH = f"{DYNAMIC_GUIDANCE_PATH}/latest"
IMPROVEMENT_REPORTS_PATH = "/packhelper/storebot_codex/improvement_reports"
IMPROVEMENT_REPORT_LATEST_PATH = f"{IMPROVEMENT_REPORTS_PATH}/latest"
APP_IMPROVEMENT_REPORTS_PATH = "/packhelper/app_improvement_reports"
OUTPUTS_PATH = "/packhelper/storebot_codex/outputs"
REALTIME_CACHE_PATH = "/packhelper/storebot_codex/realtime_cache"
STAGE_LEDGER_PATH = "/packhelper/storebot_codex/stage_ledger"
CLI_DIAGNOSTICS_PATH = "/packhelper/storebot_codex/cli_diagnostics"
CLI_DIAGNOSTIC_STATE_PATH = f"{CLI_DIAGNOSTICS_PATH}/state"
CLI_DIAGNOSTIC_LATEST_PATH = f"{CLI_DIAGNOSTICS_PATH}/latest"
WORKSCHEDULE_V2_PATH = "/workschedule_v2"
SIDE_JOB_REFERENCES_PATH = f"{WORKSCHEDULE_V2_PATH}/side_job_references"
CONFIRMED_SCHEDULE_WRITE_REQUEST_TYPE = "confirmed_schedule_write_request"
CONFIRMED_SCHEDULE_WRITE_REQUEST_QUEUE_PATH = "/packhelper/storebot_termux/confirmed_schedule_write_requests"
CONFIRMED_SCHEDULE_ALLOWED_WRITE_TARGETS = (
    f"{WORKSCHEDULE_V2_PATH}/overrides",
    f"{WORKSCHEDULE_V2_PATH}/status",
)
_IMAGE_SEND_CONFIG_CACHE: dict[str, Any] = {
    "at": 0.0,
    "enabled": True,
    "pause_reason": "",
    "mode": "auto",
    "thermal_state": "unknown",
}
_IMAGE_SEND_CONFIG_LOCK = threading.Lock()
_SCHEDULE_IMAGE_REQUEST_DEDUPE: dict[str, float] = {}
_SCHEDULE_IMAGE_REQUEST_DEDUPE_LOCK = threading.Lock()
CONFIRMED_SCHEDULE_REQUIRED_FIELDS = (
    "actor",
    "source_event_id",
    "date",
    "employee",
    "action",
    "confirmed_at_ms",
    "dry_run_result",
)
STOREBOT_REPLY_CONTRACT_VERSION = "STOREBOT_REPLY_V1"
STOREBOT_REPLY_MAX_CHARS = 1200
STOREBOT_BRIDGE_MODE = os.environ.get("STOREBOT_CODEX_BRIDGE_MODE", "dedicated_persistent_phase1").strip() or "dedicated_persistent_phase1"
RESIDENT_PROMPT_PAYLOAD_MAX_CHARS = 1800
RESIDENT_CORRECTION_USER_MAX_CHARS = 700
RESIDENT_CORRECTION_REPLY_MAX_CHARS = 900
RESIDENT_CORRECTION_ACTION_MAX_CHARS = 1600
FAST_ROUTER_PAYLOAD_MAX_CHARS = 1600
FAST_ROUTER_CONTEXT_MAX_CHARS = 1600
CORRECTION_CONTEXT_MAX_AGE_MS = 6 * 60 * 60 * 1000
# Groq docs list this production model at ~1000 tps with strict structured outputs,
# so it is the no-env default for tiny JSON-only diagnostic triage.
DEFAULT_GROQ_TRIAGE_MODEL = "openai/gpt-oss-20b"
GROQ_STRICT_JSON_SCHEMA_MODELS = {"openai/gpt-oss-20b", "openai/gpt-oss-120b"}
GROQ_TRIAGE_REQUIRED_FIELDS = ("likely_stage", "severity", "summary", "codex_task_hint")
GROQ_TRIAGE_SEVERITIES = {"info", "warning", "error", "critical"}
DEFAULT_FAST_BRAIN_GROQ_MODEL = os.environ.get("STOREBOT_FAST_BRAIN_GROQ_MODEL", DEFAULT_GROQ_TRIAGE_MODEL).strip() or DEFAULT_GROQ_TRIAGE_MODEL
DEFAULT_FAST_BRAIN_OPENAI_MODEL = os.environ.get("STOREBOT_FAST_BRAIN_OPENAI_MODEL", "gpt-4.1-mini").strip() or "gpt-4.1-mini"
REALTIME_INFO_MAX_AGE_MINUTES = 60
SCHEDULE_NEWS_MAX_AGE_MINUTES = 12 * 60
SCHEDULE_REQUIRED_SECTIONS = ("근무", "날씨", "뉴스")
SCHEDULE_NEWS_PLACEHOLDERS = (
    "조회 결과 최신값 없음",
    "조회 결과 없음",
    "실시간 조회 실패",
    "조회 실패",
    "뉴스 조회 결과 없음",
    "뉴스 실시간 조회 실패",
    "최근 7일 뉴스 없음",
    "실시간 뉴스 조회 불가",
)
SCHEDULE_WEATHER_PLACEHOLDERS = (
    "날씨 조회 실패",
    "날씨 실시간 조회 실패",
    "지난 운영일 날씨 조회 불가",
    "실시간 조회 실패",
    "조회 실패",
    "조회 결과 최신값 없음",
)
STOREBOT_CLI_DIAGNOSTIC_TYPES = {
    "schedule_image_required_data_incomplete",
    "schedule_image_render_or_send_failed",
    "search_realtime_source_empty_or_stale",
    "worker_bundle_adoption_mismatch",
    "local_direct_unavailable_or_timeout",
    "codex_model_refresh_runtime_failure",
    "request_stale_running_or_publish_missing",
    "action_tool_failure_repeated",
    "bridge_protocol_suppressed",
}
ROOM_AGENT_CONTEXT_MAX_EVENTS = 12
ROOM_AGENT_CONTEXT_MAX_CHARS = 3600
ROOM_EPISODE_GAP_MS = 15 * 60 * 1000
DEFAULT_GUIDE = BASE_DIR / "STOREBOT_CODEX_WORKER.md"
DEFAULT_CODEX_CWD = "/root/storebot-codex-workspace"
DEFAULT_STOREBOT_CODEX_HOME = str(Path.home() / ".storebot_codex_home")
DEFAULT_RESIDENT_CODEX_HOME = DEFAULT_STOREBOT_CODEX_HOME
DEFAULT_MODEL = "gpt-5.6-terra"
DEFAULT_REASONING_EFFORT = "low"
DEFAULT_ESCALATION_MODEL = "gpt-5.5"
DEFAULT_ESCALATION_REASONING_EFFORT = "low"
DEFAULT_IMPROVEMENT_APP_NAME = "StoreBotTermux"
DEFAULT_IMPROVEMENT_REPORT_MODEL = "gpt-5.5"
DEFAULT_IMPROVEMENT_REPORT_REASONING_EFFORT = "low"
DEFAULT_SKILL_NAME = "storebot-kakao-reply"
DEFAULT_SELF_SYNC_MANIFEST_URL = "https://wk7007-ops-static-2026.web.app/storebot-codex/bundle.json"
DEFAULT_CAPABILITY_CATALOG = BASE_DIR / "config" / "storebot_capabilities.yaml"
SELF_SYNC_STATE_FILE = BASE_DIR / ".storebot_codex_bundle_state.json"
DEPLOYMENT_LOCK_FILE = BASE_DIR / ".storebot_codex_deploy.lock"
DEPLOYMENT_LOCK_TIMEOUT_SEC = 30
AUTOMATION_RUNTIME_BUNDLE_PATHS = {
    "automation_goal_dispatcher.py": "scripts/automation_goal_dispatcher.py",
    "automation_goal_dispatch_firebase.py": "scripts/automation_goal_dispatch_firebase.py",
    "config/automation_goal_dispatch_policy.json": "config/automation_goal_dispatch_policy.json",
    "config/automation_goal_runtime.json": "config/automation_goal_runtime.json",
    "start_automation_goal_dispatcher.sh": "subphone/start_automation_goal_dispatcher.sh",
}
IMPROVEMENT_REPORT_STATE_FILE = BASE_DIR / ".storebot_improvement_report_state.json"
DEFAULT_OPENCLAW_SESSIONS_DIR = Path.home() / ".openclaw" / "agents" / "main" / "sessions"
TERMUX_OPENCLAW_SESSIONS_DIRS = (
    Path("/data/data/com.sbotux/files/home/.openclaw/agents/main/sessions"),
    Path("/data/data/com.termux/files/home/.openclaw/agents/main/sessions"),
    Path("/data/data/com.wonmux/files/home/.openclaw/agents/main/sessions"),
)
SELF_SYNC_EXIT_CODE = 75
LOCAL_DIRECT_STATE: dict[str, Any] = {
    "enabled": False,
    "listening": False,
    "host": "",
    "port": 0,
    "started_at_ms": 0,
    "last_error": "",
}
ALLOWED_REASONING_EFFORTS = {"minimal", "low", "medium", "high", "xhigh"}
ACTION_SENTINEL = "STOREBOT_ACTIONS"
OUTPUT_SENTINEL = "STOREBOT_OUTPUT"
FAST_ROUTER_SESSION_KEY = "__fast_router_v2"
FAST_ROUTER_FULL_SENTINEL = "ROUTE_FULL"
DEFAULT_FAST_ROUTER_ROOM_TURN_LIMIT = 8
DEFAULT_FAST_ROUTER_TOTAL_TOKEN_LIMIT = 8000
DEFAULT_FAST_ROUTER_PRIOR_TURN_DURATION_LIMIT_MS = 30_000
DEFAULT_FAST_ROUTER_RUNTIME_ROOM_LIMIT = 16
FAST_ROUTER_THREAD_CLEANUP_METHOD = "thread/unsubscribe"
FAST_ROUTER_THREAD_CLEANUP_ACK_STATUSES = {"notLoaded", "notSubscribed", "unsubscribed"}
FAST_ROUTER_THREAD_CLEANUP_TIMEOUT_SEC = 5
CONTEXT_BUNDLE_V1_VERSION = "context_bundle_v1"
KST = timezone(timedelta(hours=9))
WORK_SCHEDULE_OPERATIONAL_DAY_START_MINUTES = 6 * 60
SCHEDULE_TIMER_LAST_CHECK_KEY = ""
WORK_SCHEDULE_BROADCAST_SCHEMA_VERSION = 2
WORK_SCHEDULE_BROADCAST_INTERVAL_MS = 6 * 60 * 60 * 1000
WORK_SCHEDULE_BROADCAST_DEBOUNCE_MS = 5 * 60 * 1000
WORK_SCHEDULE_BROADCAST_BLOCKED_RETRY_MS = 60 * 1000
WORK_SCHEDULE_BROADCAST_REQUEST_TERMINAL_STATUSES = {
    "done",
    "error",
    "failed_timeout",
    "stale_killed",
    "rejected",
    "expired",
}
MIN_SCHEDULE_IMAGE_DAY_COUNT = 4
DEFAULT_SCHEDULE_IMAGE_DAY_COUNT = 7
MAX_SCHEDULE_IMAGE_DAY_COUNT = 7
WORK_SCHEDULE_BROADCAST_DAY_COUNT = 7
MAX_SCHEDULE_QUERY_DAY_COUNT = 14
SCHEDULE_SOURCE_READ_ATTEMPTS = 2
SEARCH_SOURCE_READ_ATTEMPTS = 2
KR_PUBLIC_HOLIDAY_API_URL_TEMPLATE = "https://date.nager.at/api/v3/PublicHolidays/{year}/KR"
KR_PUBLIC_HOLIDAY_CACHE_TTL_MS = 24 * 60 * 60 * 1000
_KR_PUBLIC_HOLIDAY_CACHE: dict[int, dict[str, Any]] = {}
_KR_PUBLIC_HOLIDAY_CACHE_LOCK = threading.Lock()
LEGACY_DAY_ONLY_SCHEDULE_MODES = {"today", "daily", "tomorrow"}
WORK_SCHEDULE_BROADCAST_HASH_IGNORED_KEYS = {
    "updated_at",
    "updated_at_ms",
    "updatedAt",
    "updatedAtMs",
    "created_at",
    "created_at_ms",
    "createdAt",
    "createdAtMs",
    "timestamp",
    "timestamp_ms",
    "ts",
    "ts_ms",
    "worker",
    "worker_id",
    "workerId",
}
WORK_SCHEDULE_BROADCAST_PLANNING_KEYS = (
    "employees",
    "fixed_schedules",
    "overrides",
    "status",
)


def work_schedule_operational_day_start(now: datetime | None = None) -> datetime:
    current = now if now is not None else datetime.now(KST)
    if current.tzinfo is None:
        current = current.replace(tzinfo=KST)
    current = current.astimezone(KST)
    day_start = current.replace(hour=0, minute=0, second=0, microsecond=0)
    current_minutes = current.hour * 60 + current.minute
    if current_minutes < WORK_SCHEDULE_OPERATIONAL_DAY_START_MINUTES:
        day_start -= timedelta(days=1)
    return day_start


def work_schedule_operational_dates(start_offset_days: Any = 0, day_count: Any = DEFAULT_SCHEDULE_IMAGE_DAY_COUNT) -> list[str]:
    start_offset = max(0, safe_int(start_offset_days, 0))
    count = min(max(1, safe_int(day_count, DEFAULT_SCHEDULE_IMAGE_DAY_COUNT)), MAX_SCHEDULE_QUERY_DAY_COUNT)
    today = work_schedule_operational_day_start()
    return [(today + timedelta(days=offset)).strftime("%Y-%m-%d") for offset in range(start_offset, start_offset + count)]


@dataclass(frozen=True)
class WorkScheduleCanonicalRange:
    mode: str
    dates: tuple[str, ...]
    source: str

    @property
    def start_date(self) -> str:
        return self.dates[0] if self.dates else ""

    @property
    def end_date(self) -> str:
        return self.dates[-1] if self.dates else ""

    @property
    def day_count(self) -> int:
        return len(self.dates)

    @property
    def range_label(self) -> str:
        if not self.dates:
            return ""
        if self.start_date == self.end_date:
            return schedule_compact_date_label(self.start_date)
        return f"{schedule_compact_date_label(self.start_date)}~{schedule_compact_date_label(self.end_date)}"

    @property
    def date_range(self) -> str:
        if not self.dates:
            return ""
        if self.start_date == self.end_date:
            return self.start_date
        return f"{self.start_date}~{self.end_date}"

    @property
    def title(self) -> str:
        return f"근무표 {self.range_label}" if self.range_label else "근무표 브리핑"

    @property
    def caption(self) -> str:
        parts = [part for part in (self.date_range, f"{self.day_count}일" if self.day_count else "", "06:00 KST 기준") if part]
        return " | ".join(parts)

    @property
    def file_prefix(self) -> str:
        if not self.dates:
            return "storebot_schedule"
        if self.start_date == self.end_date:
            return f"storebot_schedule_{self.start_date}"
        return f"storebot_schedule_{self.start_date}_{self.end_date}"

    def metadata(self) -> dict[str, Any]:
        return {
            "mode": self.mode,
            "source": self.source,
            "dates": list(self.dates),
            "start_date": self.start_date,
            "end_date": self.end_date,
            "day_count": self.day_count,
            "date_range": self.date_range,
            "range_label": self.range_label,
            "title": self.title,
            "caption": self.caption,
            "file_prefix": self.file_prefix,
            "operational_day_start_hour_kst": WORK_SCHEDULE_OPERATIONAL_DAY_START_MINUTES // 60,
            "operational_day_rule": "06:00_KST",
        }


def schedule_time_minutes(value: Any) -> int:
    match = re.match(r"^\s*(\d{1,2}):(\d{2})", str(value or ""))
    if not match:
        return -1
    hour = safe_int(match.group(1), -1)
    minute = safe_int(match.group(2), -1)
    if hour < 0 or minute < 0:
        return -1
    return max(0, min(hour, 47)) * 60 + max(0, min(minute, 59))


def schedule_time_compact(value: Any) -> str:
    minutes = schedule_time_minutes(value)
    if minutes < 0:
        return ""
    hour = (minutes // 60) % 24
    minute = minutes % 60
    return str(hour) if minute == 0 else f"{hour}:{minute:02d}"


def schedule_graph_employee_label(value: Any) -> str:
    text = str(value or "").strip()
    if not text:
        return ""
    return text[:2] if len(text) > 2 else text


def schedule_shift_absolute_range(day_index: int, shift: dict[str, Any]) -> tuple[int, int] | None:
    raw_start = schedule_time_minutes(shift.get("start"))
    raw_end = schedule_time_minutes(shift.get("end"))
    if raw_start < 0 and raw_end < 0:
        return None
    start = raw_start if raw_start >= 0 else max(0, raw_end - 60)
    end = raw_end if raw_end >= 0 else start + 60
    if raw_start >= 0 and raw_end >= 0 and end <= start:
        end += 24 * 60
    if end <= start:
        end = start + 60
    day_base = max(0, day_index) * 24 * 60
    return day_base + start, day_base + end


def schedule_graph_bounds_from_days(days: list[dict[str, Any]]) -> dict[str, Any]:
    first: dict[str, Any] | None = None
    last: dict[str, Any] | None = None
    for day_index, day in enumerate(days):
        if not isinstance(day, dict):
            continue
        date_text = str(day.get("date") or "").strip()
        rows = day.get("shifts")
        if not isinstance(rows, list):
            continue
        for shift in rows:
            if not isinstance(shift, dict):
                continue
            shift_range = schedule_shift_absolute_range(day_index, shift)
            if shift_range is None:
                continue
            start_abs, end_abs = shift_range
            employee = str(shift.get("employee_name") or shift.get("employee") or shift.get("employee_id") or "").strip()
            start_item = {
                "absolute_minutes": start_abs,
                "date": date_text,
                "employee": employee,
                "time": str(shift.get("start") or ""),
                "time_label": schedule_time_compact(shift.get("start")),
                "employee_label": schedule_graph_employee_label(employee),
                "day_offset": start_abs // (24 * 60),
            }
            end_item = {
                "absolute_minutes": end_abs,
                "date": date_text,
                "employee": employee,
                "time": str(shift.get("end") or ""),
                "time_label": schedule_time_compact(shift.get("end")),
                "employee_label": schedule_graph_employee_label(employee),
                "day_offset": end_abs // (24 * 60),
            }
            if first is None or start_abs < int(first.get("absolute_minutes") or 0):
                first = start_item
            if last is None or end_abs > int(last.get("absolute_minutes") or 0):
                last = end_item
    if not first or not last:
        return {}
    start_label = f"{first.get('employee_label')}{first.get('time_label')}".strip()
    end_core = f"{last.get('employee_label')}{last.get('time_label')}".strip()
    end_day_offset = int(last.get("day_offset") or 0)
    end_label = f"{end_core}(+{end_day_offset})" if end_day_offset > 0 else end_core
    summary = f"{start_label}~{end_label}".strip("~")
    return {
        "source": "actual_shift_bounds",
        "start": first,
        "end": last,
        "axis_start_minutes": int(first.get("absolute_minutes") or 0),
        "axis_end_minutes": int(last.get("absolute_minutes") or 0),
        "duration_minutes": max(0, int(last.get("absolute_minutes") or 0) - int(first.get("absolute_minutes") or 0)),
        "summary": summary,
    }


SCHEDULE_ATTENDANCE_EVENTS = (
    ("schedule_attendance_final", "attendance_final", 0, "출근 정각 미출근 확인"),
)
SCHEDULE_ATTENDANCE_EVENT_KINDS = {event_kind for event_kind, _payload_kind, _offset, _label in SCHEDULE_ATTENDANCE_EVENTS}
SCHEDULE_ATTENDANCE_PAYLOAD_KINDS = {payload_kind for _event_kind, payload_kind, _offset, _label in SCHEDULE_ATTENDANCE_EVENTS}
SUPERVISOR_STAGE_ORDER = (
    "schedule_fire",
    "worker_pickup",
    "realtime_data",
    "image_build",
    "outbound_publish",
    "phone_receive",
    "kakao_send",
    "ack",
)
SUPERVISOR_STAGE_STATUSES = {"started", "done", "error", "timeout", "skipped"}
SUPERVISOR_TERMINAL_STAGE_STATUSES = {"done", "error", "timeout", "skipped"}
SUPERVISOR_STAGE_TIMEOUT_MS = {
    "schedule_fire": 2 * 60 * 1000,
    "worker_pickup": 3 * 60 * 1000,
    "realtime_data": 3 * 60 * 1000,
    "image_build": 2 * 60 * 1000,
    "outbound_publish": 60 * 1000,
    "phone_receive": 2 * 60 * 1000,
    "kakao_send": 3 * 60 * 1000,
    "ack": 2 * 60 * 1000,
}
FAST_ROUTER_SKIP_FULL_FALLBACK_EVENT_KINDS = {
    LEGACY_SCHEDULE_FIXED_BRIEFING_EVENT_KIND,
    WORK_SCHEDULE_BROADCAST_EVENT_KIND,
    "reservation",
    "dinein",
    "payment",
    "logistics",
}
CAPABILITY_ROUTE_SYNONYM_GROUPS = (
    ("recipe", "레시피", "조리", "튀겨", "튀김", "몇분", "몇 분", "타이머", "timer", "cook"),
    ("sports", "스포츠", "월드컵", "축구", "경기", "한국경기", "한국 경기", "fixture", "score"),
    ("weather", "날씨", "비", "눈", "기온", "forecast"),
    ("news", "뉴스", "소식", "latest", "최신"),
    ("schedule", "근무", "근무표", "스케줄", "출근", "shift", "직원", "알바"),
    ("attendance", "출근", "퇴근", "도착", "지각", "근태", "도장"),
    ("address", "주소", "동호수", "호수", "공동현관", "비번", "비밀번호", "password", "gate"),
    ("order", "주문", "오더", "영수증", "프린터", "배달", "내점", "receipt"),
    ("kds", "KDS", "밀렸", "밀려", "바쁨", "바빠", "건수", "대기"),
    ("platform", "플랫폼", "배민", "쿠팡", "쿠팡이츠", "땡겨요", "요기요"),
    ("control", "멈춰", "정지", "일시정지", "막아", "꺼", "켜", "재개", "resume", "pause"),
    ("phonebook", "번호", "전화번호", "연락처", "콜센터", "고객센터", "support", "contact"),
    ("private_contact", "직원번호", "직원 번호", "고객전화", "고객 전화", "개인번호", "개인 번호"),
    ("reservation", "예약", "홀예약", "배달예약", "booking"),
    ("customer_service", "고객", "클레임", "항의", "답장", "응대", "문구", "사과", "polish", "response"),
    ("briefing", "브리핑", "요약", "정리", "종합", "composite", "daily"),
)
CAPABILITY_ROUTE_SCHEDULE_FIRST_AXIS_DOMAINS = {"schedule", "attendance", "reservation"}
CAPABILITY_ROUTE_SCHEDULE_FIRST_AXIS_TERMS = {
    "workschedule",
    "schedule",
    "attendance",
    "reservation",
    "근무",
    "근무표",
    "스케줄",
    "출근",
    "퇴근",
    "지각",
    "도장",
    "근태",
    "예약",
    "홀예약",
    "배달예약",
    "누가나와",
}
_CAPABILITY_CATALOG_LOCK = threading.Lock()
_CAPABILITY_CATALOG_CACHE: dict[str, Any] = {}
_CAPABILITY_CATALOG_LAST_GOOD: dict[str, Any] | None = None
STOREBOT_MCP_ENABLED_TOOLS = [
    "storebot_tool",
    "storebot_firebase_get",
    "storebot_schedule_query",
    "storebot_schedule_upsert_shift",
    "storebot_schedule_off",
    "storebot_schedule_clear",
    "storebot_employee_add_alias",
    "storebot_missed_chat_query",
    "storebot_order_recent",
    "storebot_ops_manual_search",
    "storebot_operation_knowledge_preview",
    "storebot_operation_knowledge_ingest",
    "storebot_operation_knowledge_process_queue",
    "storebot_operation_knowledge_upsert_summary",
    "storebot_operation_knowledge_render_output",
    "storebot_operation_knowledge_request_delete",
    "storebot_operation_knowledge_restore",
    "storebot_operation_knowledge_send_reply",
    "storebot_alert_schedule",
    "storebot_alert_query",
    "storebot_alert_cancel",
    "storebot_guidance_query",
    "storebot_guidance_add_rule",
    "storebot_weather_forecast",
    "storebot_news_search",
    "storebot_sports_search",
    "storebot_web_search",
]
BUNDLE_FILE_TARGETS = {
    "codex_hook_policy_probe.py": [BASE_DIR / "scripts" / "codex_hook_policy_probe.py"],
    "codex_fresh_hook_receipt_verifier.py": [
        BASE_DIR / "scripts" / "codex_fresh_hook_receipt_verifier.py"
    ],
    "codex_hooks/minimal_managed_lifecycle.py": [
        BASE_DIR / "scripts" / "codex_hooks" / "minimal_managed_lifecycle.py"
    ],
    "codex_ops_enqueue.py": [BASE_DIR / "scripts" / "codex_ops_enqueue.py"],
    "codex_ops_worker.py": [BASE_DIR / "scripts" / "codex_ops_worker.py"],
    "codex_ops_adb_check.py": [BASE_DIR / "scripts" / "codex_ops_adb_check.py"],
    "codex_ops_kakao_wake.py": [BASE_DIR / "scripts" / "codex_ops_kakao_wake.py"],
    "codex_ops_posdelay_watchdog.py": [BASE_DIR / "scripts" / "codex_ops_posdelay_watchdog.py"],
    "codex_ops_storebottermux_watchdog.py": [BASE_DIR / "scripts" / "codex_ops_storebottermux_watchdog.py"],
    "codex_sdk_runner.py": [BASE_DIR / "scripts" / "codex_sdk_runner.py"],
    "ai_ops_common_monitor.py": [BASE_DIR / "scripts" / "ai_ops_common_monitor.py"],
    "automation_goal_dispatcher.py": [BASE_DIR / "scripts" / "automation_goal_dispatcher.py"],
    "automation_goal_seed.py": [BASE_DIR / "scripts" / "automation_goal_seed.py"],
    "automation_goal_program_compiler.py": [BASE_DIR / "scripts" / "automation_goal_program_compiler.py"],
    "automation_goal_program_firebase_publish.py": [BASE_DIR / "scripts" / "automation_goal_program_firebase_publish.py"],
    "automation_goal_dispatch_firebase.py": [BASE_DIR / "scripts" / "automation_goal_dispatch_firebase.py"],
    "automation_learning_firebase_publish.py": [BASE_DIR / "scripts" / "automation_learning_firebase_publish.py"],
    "diagnostic_redaction.py": [BASE_DIR / "scripts" / "diagnostic_redaction.py"],
    "secure_ca_env.sh": [BASE_DIR / "scripts" / "secure_ca_env.sh"],
    "pc_codex_cli_enqueue.py": [BASE_DIR / "scripts" / "pc_codex_cli_enqueue.py"],
    "telegram_openclaw_codex_gate.py": [BASE_DIR / "scripts" / "telegram_openclaw_codex_gate.py"],
    "project_telegram_ca_lifecycle.py": [BASE_DIR / "scripts" / "project_telegram_ca_lifecycle.py"],
    "storebot_ca_log.py": [BASE_DIR / "scripts" / "storebot_ca_log.py"],
    "manage_storebot_ca_activation.py": [BASE_DIR / "scripts" / "manage_storebot_ca_activation.py"],
    "posdelay_ca_log.py": [BASE_DIR / "scripts" / "posdelay_ca_log.py"],
    "config/telegram_openclaw_room_registry.json": [BASE_DIR / "config" / "telegram_openclaw_room_registry.json"],
    "config/telegram_project_ca_registry.json": [BASE_DIR / "config" / "telegram_project_ca_registry.json"],
    "config/automation_goal_dispatch_policy.json": [BASE_DIR / "config" / "automation_goal_dispatch_policy.json"],
    "config/automation_goal_programs.json": [BASE_DIR / "config" / "automation_goal_programs.json"],
    "config/automation_goal_runtime.json": [BASE_DIR / "config" / "automation_goal_runtime.json"],
    "write_update_manifest.py": [BASE_DIR / "scripts" / "write_update_manifest.py"],
    "deploy_banktotal_update.sh": [BASE_DIR / "scripts" / "deploy_banktotal_update.sh"],
    "deploy_deliveryhelper_update.sh": [BASE_DIR / "scripts" / "deploy_deliveryhelper_update.sh"],
    "deploy_posdelay_update.sh": [BASE_DIR / "scripts" / "deploy_posdelay_update.sh"],
    "deploy_storebot_update.sh": [BASE_DIR / "scripts" / "deploy_storebot_update.sh"],
    "deploy_all_update_channels.sh": [BASE_DIR / "scripts" / "deploy_all_update_channels.sh"],
    "operation_knowledge_adapter.py": [BASE_DIR / "scripts" / "operation_knowledge_adapter.py"],
    "storebot_telegram_projection.py": [BASE_DIR / "scripts" / "storebot_telegram_projection.py"],
    "storebot_telegram_backplane.py": [BASE_DIR / "scripts" / "storebot_telegram_backplane.py"],
    "storebot_telegram_chat_contract.py": [BASE_DIR / "scripts" / "storebot_telegram_chat_contract.py"],
    "storebot_telegram_ops_log.py": [BASE_DIR / "scripts" / "storebot_telegram_ops_log.py"],
    "storebot_telegram_worker_adapter.py": [BASE_DIR / "scripts" / "storebot_telegram_worker_adapter.py"],
    "deliveryhelper_gpt_reanalyze_worker.py": [BASE_DIR / "scripts" / "deliveryhelper_gpt_reanalyze_worker.py"],
    "storebot_codex_worker.py": [BASE_DIR / "scripts" / "storebot_codex_worker.py"],
    "storebot_codex_replay_chat.py": [BASE_DIR / "scripts" / "storebot_codex_replay_chat.py"],
    "storebot_direct_inject.py": [BASE_DIR / "scripts" / "storebot_direct_inject.py"],
    "storebot_kakao_live_diag.py": [BASE_DIR / "scripts" / "storebot_kakao_live_diag.py"],
    "storebot_manual_reply.py": [BASE_DIR / "scripts" / "storebot_manual_reply.py"],
    "STOREBOT_CODEX_WORKER.md": [BASE_DIR / "STOREBOT_CODEX_WORKER.md"],
    "STOREBOT_CODEX_BRIDGE.md": [BASE_DIR / "subphone" / "STOREBOT_CODEX_BRIDGE.md"],
    "start_storebot_codex_worker.sh": [BASE_DIR / "subphone" / "start_storebot_codex_worker.sh"],
    "run_storebot_codex_worker.sh": [BASE_DIR / "subphone" / "run_storebot_codex_worker.sh"],
    "launch_storebot_codex_background.sh": [BASE_DIR / "subphone" / "launch_storebot_codex_background.sh"],
    "restart_storebot_codex_worker.sh": [BASE_DIR / "subphone" / "restart_storebot_codex_worker.sh"],
    "admin_update_codex_cli_0_145_0.sh": [
        BASE_DIR / "subphone" / "admin_update_codex_cli_0_145_0.sh"
    ],
    "restart_ca_live_runtime.sh": [BASE_DIR / "subphone" / "restart_ca_live_runtime.sh"],
    "watch_storebot_codex_worker.sh": [BASE_DIR / "subphone" / "watch_storebot_codex_worker.sh"],
    "watch_storebot_kakao_stack.sh": [BASE_DIR / "subphone" / "watch_storebot_kakao_stack.sh"],
    "setup_storebot_codex_autostart.sh": [BASE_DIR / "subphone" / "setup_storebot_codex_autostart.sh"],
    "harden_storebottermux_power.sh": [BASE_DIR / "subphone" / "harden_storebottermux_power.sh"],
    "start_codex_ops_worker.sh": [BASE_DIR / "subphone" / "start_codex_ops_worker.sh"],
    "start_ai_ops_monitor.sh": [BASE_DIR / "subphone" / "start_ai_ops_monitor.sh"],
    "start_automation_goal_dispatcher.sh": [BASE_DIR / "subphone" / "start_automation_goal_dispatcher.sh"],
    "start_deliveryhelper_gpt_reanalyze_worker.sh": [BASE_DIR / "subphone" / "start_deliveryhelper_gpt_reanalyze_worker.sh"],
    "watch_deliveryhelper_gpt_reanalyze_worker.sh": [BASE_DIR / "subphone" / "watch_deliveryhelper_gpt_reanalyze_worker.sh"],
    "setup_deliveryhelper_gpt_autostart.sh": [BASE_DIR / "subphone" / "setup_deliveryhelper_gpt_autostart.sh"],
    "check_storebot_codex_worker.sh": [BASE_DIR / "subphone" / "check_storebot_codex_worker.sh"],
    "storebot_manual_reply.sh": [BASE_DIR / "subphone" / "storebot_manual_reply.sh"],
    "install_storebot_codex_termux.sh": [BASE_DIR / "subphone" / "install_storebot_codex_termux.sh"],
    "fix_storebot_codex_copy.sh": [BASE_DIR / "subphone" / "fix_storebot_codex_copy.sh"],
    "skills/storebot-kakao-reply/SKILL.md": [
        BASE_DIR / ".agents" / "skills" / "storebot-kakao-reply" / "SKILL.md",
        Path.home() / ".agents" / "skills" / "storebot-kakao-reply" / "SKILL.md",
    ],
    "skills/deliveryhelper-reanalyze/SKILL.md": [
        BASE_DIR / ".agents" / "skills" / "deliveryhelper-reanalyze" / "SKILL.md",
        Path.home() / ".agents" / "skills" / "deliveryhelper-reanalyze" / "SKILL.md",
    ],
}
CONTEXT_BUNDLE_PREFIX = "ai_ops_context/"
EXECUTABLE_BUNDLE_FILES = {
    "codex_hook_policy_probe.py",
    "codex_fresh_hook_receipt_verifier.py",
    "codex_hooks/minimal_managed_lifecycle.py",
    "codex_ops_enqueue.py",
    "codex_ops_worker.py",
    "codex_ops_adb_check.py",
    "codex_ops_kakao_wake.py",
    "codex_ops_posdelay_watchdog.py",
    "codex_ops_storebottermux_watchdog.py",
    "codex_sdk_runner.py",
    "ai_ops_common_monitor.py",
    "automation_goal_dispatcher.py",
    "automation_goal_seed.py",
    "automation_goal_program_compiler.py",
    "automation_goal_program_firebase_publish.py",
    "automation_goal_dispatch_firebase.py",
    "automation_learning_firebase_publish.py",
    "diagnostic_redaction.py",
    "secure_ca_env.sh",
    "pc_codex_cli_enqueue.py",
    "telegram_openclaw_codex_gate.py",
    "project_telegram_ca_lifecycle.py",
    "storebot_ca_log.py",
    "manage_storebot_ca_activation.py",
    "write_update_manifest.py",
    "deploy_banktotal_update.sh",
    "deploy_deliveryhelper_update.sh",
    "deploy_posdelay_update.sh",
    "deploy_storebot_update.sh",
    "deploy_all_update_channels.sh",
    "deliveryhelper_gpt_reanalyze_worker.py",
    "storebot_codex_worker.py",
    "storebot_codex_replay_chat.py",
    "storebot_direct_inject.py",
    "storebot_kakao_live_diag.py",
    "storebot_manual_reply.py",
    "start_storebot_codex_worker.sh",
    "run_storebot_codex_worker.sh",
    "launch_storebot_codex_background.sh",
    "restart_storebot_codex_worker.sh",
    "admin_update_codex_cli_0_145_0.sh",
    "restart_ca_live_runtime.sh",
    "watch_storebot_codex_worker.sh",
    "watch_storebot_kakao_stack.sh",
    "setup_storebot_codex_autostart.sh",
    "harden_storebottermux_power.sh",
    "start_codex_ops_worker.sh",
    "start_ai_ops_monitor.sh",
    "start_automation_goal_dispatcher.sh",
    "start_deliveryhelper_gpt_reanalyze_worker.sh",
    "watch_deliveryhelper_gpt_reanalyze_worker.sh",
    "setup_deliveryhelper_gpt_autostart.sh",
    "check_storebot_codex_worker.sh",
    "storebot_manual_reply.sh",
    "install_storebot_codex_termux.sh",
    "fix_storebot_codex_copy.sh",
}


class WorkerError(RuntimeError):
    pass


class SourceReadError(WorkerError):
    def __init__(
        self,
        message: str,
        *,
        code: str,
        source: str,
        attempts: int,
        path: str = "",
        query: str = "",
    ) -> None:
        super().__init__(message)
        self.code = code
        self.source = source
        self.attempts = attempts
        self.path = path
        self.query = query


class FastRouterFullFallback(RuntimeError):
    pass


@dataclass
class CodexResult:
    final: str
    thread_id: str | None
    tool_call_count: int = 0
    tool_ok_count: int = 0
    tool_error_count: int = 0
    metadata: dict[str, Any] = field(default_factory=dict)


@dataclass
class ScheduleImageBuildResult:
    image_request: dict[str, Any] | None = None
    incomplete: dict[str, Any] | None = None
    self_fix_request_id: str = ""
    suppressed_reason: str = ""
    suppressed_detail: str = ""
    dedupe_key: str = ""


def now_ms() -> int:
    return int(time.time() * 1000)


def kst_text(ms: int | None = None) -> str:
    when = datetime.fromtimestamp((ms or now_ms()) / 1000, KST)
    return when.strftime("%Y-%m-%d %H:%M:%S KST")


def log(message: str) -> None:
    print(f"[{kst_text()}] {message}", flush=True)


def env_bool(name: str, default: bool) -> bool:
    raw = os.environ.get(name)
    if raw is None:
        return default
    return raw.strip().lower() in {"1", "true", "yes", "y", "on"}


def catalog_path(value: Any = None) -> Path:
    explicit = str(value or os.environ.get("STOREBOT_CAPABILITY_CATALOG") or "").strip()
    return Path(explicit).expanduser() if explicit else DEFAULT_CAPABILITY_CATALOG


def _catalog_mtime(path: Path) -> int:
    try:
        return int(path.stat().st_mtime_ns)
    except OSError:
        return -1


def _compact_catalog_capability(raw: dict[str, Any]) -> dict[str, Any] | None:
    cap_id = str(raw.get("id") or "").strip()
    if not cap_id:
        return None
    compact: dict[str, Any] = {
        "id": cap_id,
        "domain": str(raw.get("domain") or "").strip(),
        "mode": str(raw.get("mode") or "").strip(),
        "aliases": [str(item).strip() for item in as_list(raw.get("aliases")) if str(item).strip()],
        "examples": [str(item).strip() for item in as_list(raw.get("examples")) if str(item).strip()],
        "supported_intents": [str(item).strip() for item in as_list(raw.get("supported_intents") or raw.get("intents")) if str(item).strip()],
        "actions": raw.get("actions") if isinstance(raw.get("actions"), dict) else {},
        "evidence_requirements": [
            str(item).strip()
            for item in as_list(raw.get("evidence_requirements") or raw.get("evidence"))
            if str(item).strip()
        ],
        "freshness_sla": str(raw.get("freshness_sla") or "").strip(),
        "privacy_risk": str(raw.get("privacy_risk") or "unknown").strip().lower() or "unknown",
        "side_effect_risk": str(raw.get("side_effect_risk") or "unknown").strip().lower() or "unknown",
        "auto_answer_threshold": safe_int(raw.get("auto_answer_threshold"), 85),
        "needs_review_threshold": safe_int(raw.get("needs_review_threshold"), 65),
    }
    data_sources = [str(item).strip() for item in as_list(raw.get("data_sources")) if str(item).strip()]
    if data_sources:
        compact["data_sources"] = data_sources[:8]
    return compact


def load_storebot_capability_catalog(path: str | Path | None = None, *, force: bool = False) -> dict[str, Any]:
    """Load the StoreBot capability catalog without network or writes.

    The worker keeps a last-known-good catalog in memory. A broken YAML update or
    missing PyYAML therefore degrades to the previous catalog, and finally to an
    empty catalog with load_error metadata.
    """
    global _CAPABILITY_CATALOG_LAST_GOOD
    resolved = catalog_path(path)
    key = str(resolved)
    mtime = _catalog_mtime(resolved)
    with _CAPABILITY_CATALOG_LOCK:
        cached = _CAPABILITY_CATALOG_CACHE.get(key)
        if not force and isinstance(cached, dict) and cached.get("mtime_ns") == mtime:
            return dict(cached.get("catalog") or {})
        try:
            if _yaml is None:
                raise WorkerError("PyYAML is not available")
            raw = _yaml.safe_load(resolved.read_text(encoding="utf-8"))
            if not isinstance(raw, dict):
                raise WorkerError("catalog root is not an object")
            raw_caps = raw.get("capabilities")
            if not isinstance(raw_caps, list):
                raise WorkerError("catalog capabilities is not a list")
            capabilities = []
            for raw_cap in raw_caps:
                if isinstance(raw_cap, dict):
                    cap = _compact_catalog_capability(raw_cap)
                    if cap:
                        capabilities.append(cap)
            if not capabilities:
                raise WorkerError("catalog has no valid capabilities")
            catalog = {
                "version": raw.get("version"),
                "purpose": str(raw.get("purpose") or ""),
                "defaults": raw.get("defaults") if isinstance(raw.get("defaults"), dict) else {},
                "capabilities": capabilities,
                "loaded_at_ms": now_ms(),
                "path": key,
                "capability_count": len(capabilities),
            }
            _CAPABILITY_CATALOG_CACHE[key] = {"mtime_ns": mtime, "catalog": catalog}
            _CAPABILITY_CATALOG_LAST_GOOD = catalog
            return dict(catalog)
        except Exception as exc:
            fallback = _CAPABILITY_CATALOG_LAST_GOOD
            if fallback is not None:
                catalog = dict(fallback)
                if isinstance(exc, WorkerError) and str(exc) == "PyYAML is not available":
                    catalog["load_error"] = ""
                    catalog["fallback"] = "last_good_optional_yaml_unavailable"
                    catalog["optional_yaml_unavailable"] = True
                else:
                    catalog["load_error"] = compact_error(str(exc), 240)
                    catalog["fallback"] = "last_good"
                return catalog
            catalog = {
                "version": None,
                "purpose": "",
                "defaults": {},
                "capabilities": [],
                "loaded_at_ms": now_ms(),
                "path": key,
                "capability_count": 0,
                "load_error": compact_error(str(exc), 240),
                "fallback": "empty",
            }
            if isinstance(exc, WorkerError) and str(exc) == "PyYAML is not available":
                catalog["load_error"] = ""
                catalog["fallback"] = "empty_optional_yaml_unavailable"
                catalog["optional_yaml_unavailable"] = True
            return catalog


def _route_flatten_strings(value: Any) -> list[str]:
    if value is None:
        return []
    if isinstance(value, str):
        text = value.strip()
        return [text] if text else []
    if isinstance(value, dict):
        texts: list[str] = []
        for item in value.values():
            texts.extend(_route_flatten_strings(item))
        return texts
    if isinstance(value, list):
        texts = []
        for item in value:
            texts.extend(_route_flatten_strings(item))
        return texts
    return []


def route_normalize_text(value: Any) -> str:
    return re.sub(r"\s+", " ", str(value or "").strip().lower())


def route_compact_text(value: Any) -> str:
    return re.sub(r"[^0-9a-z가-힣]+", "", route_normalize_text(value))


def route_terms(value: Any) -> set[str]:
    text = route_normalize_text(value)
    compact = route_compact_text(text)
    terms = {
        route_compact_text(token)
        for token in re.findall(r"[0-9a-zA-Z가-힣]+", text)
        if len(route_compact_text(token)) >= 2
    }
    for group in CAPABILITY_ROUTE_SYNONYM_GROUPS:
        group_terms = {route_compact_text(term) for term in group if route_compact_text(term)}
        if any(term and (term in compact or term in terms) for term in group_terms):
            terms.update(group_terms)
    return {term for term in terms if term}


def schedule_first_axis_applies(message_text: str) -> bool:
    compact = route_compact_text(message_text)
    terms = {
        route_compact_text(token)
        for token in re.findall(r"[0-9a-zA-Z가-힣]+", route_normalize_text(message_text))
        if route_compact_text(token)
    }
    return any(term in terms or (len(term) >= 3 and term in compact) for term in CAPABILITY_ROUTE_SCHEDULE_FIRST_AXIS_TERMS)


def capability_is_schedule_first_axis(capability: dict[str, Any]) -> bool:
    domain = route_compact_text(capability.get("domain"))
    if domain in CAPABILITY_ROUTE_SCHEDULE_FIRST_AXIS_DOMAINS:
        return True
    cap_id = route_compact_text(capability.get("id"))
    if any(axis in cap_id for axis in CAPABILITY_ROUTE_SCHEDULE_FIRST_AXIS_DOMAINS):
        return True
    intent_text = route_compact_text(" ".join(_route_flatten_strings(capability.get("supported_intents"))))
    return any(axis in intent_text for axis in CAPABILITY_ROUTE_SCHEDULE_FIRST_AXIS_DOMAINS)


def route_message_text(item: dict[str, Any]) -> str:
    parts = [
        str(item.get("event_kind") or item.get("kind") or "chat"),
        str(item.get("message") or ""),
        str(item.get("text") or ""),
        str(item.get("query") or ""),
    ]
    payload = item.get("payload")
    if isinstance(payload, dict):
        for key in ("event_kind", "kind", "message", "text", "query", "title", "summary", "customer_request"):
            value = payload.get(key)
            if isinstance(value, (str, int, float)):
                parts.append(str(value))
    return "\n".join(part for part in parts if part)


def capability_route_text(capability: dict[str, Any]) -> str:
    fields = [
        capability.get("id"),
        capability.get("domain"),
        capability.get("mode"),
        capability.get("aliases"),
        capability.get("examples"),
        capability.get("supported_intents"),
        capability.get("actions"),
        capability.get("evidence_requirements"),
        capability.get("data_sources"),
    ]
    return "\n".join(text for field in fields for text in _route_flatten_strings(field))


def _capability_has_write(capability: dict[str, Any]) -> bool:
    actions = capability.get("actions")
    if not isinstance(actions, dict):
        return False
    writes = actions.get("write")
    return bool(as_list(writes))


def score_capability_route(message_text: str, capability: dict[str, Any], *, schedule_first_axis: bool = False) -> dict[str, Any]:
    msg_compact = route_compact_text(message_text)
    msg_terms = route_terms(message_text)
    cap_text = capability_route_text(capability)
    cap_compact = route_compact_text(cap_text)
    cap_terms = route_terms(cap_text)
    reasons: list[str] = []
    score = 0

    cap_id = str(capability.get("id") or "")
    domain = str(capability.get("domain") or "")
    for value, label, weight in ((cap_id, "id", 18), (domain, "domain", 14)):
        compact = route_compact_text(value)
        if compact and compact in msg_terms | {msg_compact}:
            score += weight
            reasons.append(f"matched {label}: {value}")
        elif compact and compact in msg_compact:
            score += max(8, weight - 4)
            reasons.append(f"matched {label} substring: {value}")

    phrase_hits: list[str] = []
    for label, values, weight in (
        ("alias", capability.get("aliases"), 42),
        ("example", capability.get("examples"), 38),
        ("intent", capability.get("supported_intents"), 18),
    ):
        for raw in as_list(values):
            text = str(raw or "").strip()
            compact = route_compact_text(text)
            if len(compact) < 2:
                continue
            if compact in msg_compact or (len(msg_compact) >= 5 and msg_compact in compact):
                score += weight
                phrase_hits.append(f"{label}: {text}")
                break
    reasons.extend(f"matched {hit}" for hit in phrase_hits[:3])

    overlap = sorted((msg_terms & cap_terms), key=lambda item: (-len(item), item))
    if overlap:
        score += min(45, len(overlap) * 7)
        reasons.append("matched terms: " + ",".join(overlap[:8]))

    evidence_terms = route_terms("\n".join(_route_flatten_strings(capability.get("evidence_requirements"))))
    evidence_overlap = sorted(msg_terms & evidence_terms, key=lambda item: (-len(item), item))
    if evidence_overlap:
        score += min(12, len(evidence_overlap) * 3)
        reasons.append("matched evidence terms: " + ",".join(evidence_overlap[:4]))

    if schedule_first_axis and capability_is_schedule_first_axis(capability):
        score += 16
        reasons.append("primary_axis:schedule_first_review")

    risk_penalty = 0
    if str(capability.get("privacy_risk") or "").lower() == "high":
        risk_penalty += 4
    if str(capability.get("side_effect_risk") or "").lower() in {"high", "critical"}:
        risk_penalty += 4
    score = max(0, min(100, score - risk_penalty))
    return {"score": score, "evidence": reasons[:6]}


def capability_route_mode_band(selected: dict[str, Any] | None, score: int, ambiguous: bool) -> str:
    if not selected or score <= 0:
        return "clarify"
    review_threshold = safe_int(selected.get("needs_review_threshold"), 65)
    auto_threshold = safe_int(selected.get("auto_answer_threshold"), 85)
    if score < review_threshold:
        return "clarify"
    risk = str(selected.get("side_effect_risk") or "").lower()
    privacy = str(selected.get("privacy_risk") or "").lower()
    cap_mode = str(selected.get("mode") or "").lower()
    if cap_mode in {"review_required", "ops_write"} or risk in {"high", "critical"} or privacy == "high":
        return "needs_review"
    if ambiguous:
        return "needs_review"
    return "auto_answer" if score >= auto_threshold else "needs_review"


def plan_storebot_capability_route(
    item: dict[str, Any],
    catalog: dict[str, Any] | None = None,
    *,
    catalog_file: str | Path | None = None,
) -> dict[str, Any]:
    catalog = catalog if isinstance(catalog, dict) else load_storebot_capability_catalog(catalog_file)
    capabilities = catalog.get("capabilities") if isinstance(catalog, dict) else []
    if not isinstance(capabilities, list):
        capabilities = []
    message_text = route_message_text(item)
    schedule_first_axis = schedule_first_axis_applies(message_text)
    scored: list[dict[str, Any]] = []
    for capability in capabilities:
        if not isinstance(capability, dict):
            continue
        scored_item = score_capability_route(message_text, capability, schedule_first_axis=schedule_first_axis)
        score = int(scored_item.get("score") or 0)
        if score <= 0:
            continue
        scored.append(
            {
                "id": str(capability.get("id") or ""),
                "domain": str(capability.get("domain") or ""),
                "score": score,
                "mode": str(capability.get("mode") or ""),
                "privacy_risk": str(capability.get("privacy_risk") or "unknown"),
                "side_effect_risk": str(capability.get("side_effect_risk") or "unknown"),
                "has_write_actions": _capability_has_write(capability),
                "evidence": scored_item.get("evidence") if isinstance(scored_item.get("evidence"), list) else [],
                "_capability": capability,
            }
        )
    scored.sort(key=lambda row: (-int(row.get("score") or 0), str(row.get("id") or "")))
    selected_row = scored[0] if scored else None
    selected = selected_row.get("_capability") if isinstance(selected_row, dict) else None
    selected_score = int(selected_row.get("score") or 0) if selected_row else 0
    runner_up_score = int(scored[1].get("score") or 0) if len(scored) > 1 else 0
    ambiguous = bool(selected_row and runner_up_score > 0 and selected_score - runner_up_score <= 6)
    mode_band = capability_route_mode_band(selected if isinstance(selected, dict) else None, selected_score, ambiguous)
    if mode_band == "clarify" and selected_score < 45:
        selected_row = None
        selected = None
        selected_score = 0
    top_candidates = [
        {
            "id": str(row.get("id") or ""),
            "domain": str(row.get("domain") or ""),
            "score": int(row.get("score") or 0),
            "mode": str(row.get("mode") or ""),
            "privacy_risk": str(row.get("privacy_risk") or "unknown"),
            "side_effect_risk": str(row.get("side_effect_risk") or "unknown"),
        }
        for row in scored[:5]
    ]
    evidence = []
    if selected_row:
        evidence = [str(item) for item in as_list(selected_row.get("evidence")) if str(item).strip()][:6]
    if not evidence and mode_band == "clarify":
        evidence = ["low evidence: no catalog field produced a confident match"]
    return {
        "selected_capability_id": str(selected.get("id") or "") if isinstance(selected, dict) else "",
        "score": selected_score,
        "mode_band": mode_band,
        "top_candidates": top_candidates,
        "evidence": evidence,
        "freshness_sla": str(selected.get("freshness_sla") or "") if isinstance(selected, dict) else "",
        "privacy_risk": str(selected.get("privacy_risk") or "unknown") if isinstance(selected, dict) else "unknown",
        "side_effect_risk": str(selected.get("side_effect_risk") or "unknown") if isinstance(selected, dict) else "unknown",
        "shadow_only": True,
        "adapter_action_execution": False,
        "primary_axis": "schedule_first_review" if schedule_first_axis else "",
        "catalog_version": catalog.get("version") if isinstance(catalog, dict) else None,
        "catalog_capability_count": int(catalog.get("capability_count") or len(capabilities)) if isinstance(catalog, dict) else 0,
        "catalog_load_error": str(catalog.get("load_error") or "") if isinstance(catalog, dict) else "",
    }


def default_openclaw_sessions_dir() -> str:
    explicit = os.environ.get("STOREBOT_OPENCLAW_SESSIONS_DIR")
    if explicit:
        return explicit
    for path in (DEFAULT_OPENCLAW_SESSIONS_DIR, *TERMUX_OPENCLAW_SESSIONS_DIRS):
        if path.exists():
            return str(path)
    return str(DEFAULT_OPENCLAW_SESSIONS_DIR)


def firebase_base() -> str:
    return os.environ.get("FIREBASE_DB_URL", DEFAULT_FIREBASE).rstrip("/")


def fb_url(path: str) -> str:
    clean = path.strip("/")
    if not clean:
        return firebase_base() + "/.json"
    quoted = "/".join(urllib.parse.quote(part, safe="") for part in clean.split("/"))
    return f"{firebase_base()}/{quoted}.json"


def fb_request(method: str, path: str, payload: Any | None = None, timeout: int = 20) -> Any:
    data = None
    headers = {"Content-Type": "application/json; charset=utf-8"}
    if payload is not None:
        data = json.dumps(payload, ensure_ascii=False, separators=(",", ":")).encode("utf-8")
    req = urllib.request.Request(fb_url(path), data=data, headers=headers, method=method)
    try:
        with urllib.request.urlopen(req, timeout=timeout) as resp:
            body = resp.read().decode("utf-8")
    except urllib.error.HTTPError as exc:
        body = exc.read().decode("utf-8", errors="replace")
        raise WorkerError(f"firebase {method} {path} failed: HTTP {exc.code} {body[:300]}") from exc
    except urllib.error.URLError as exc:
        raise WorkerError(f"firebase {method} {path} failed: {exc}") from exc
    if not body:
        return None
    return json.loads(body)


def fb_get(path: str) -> Any:
    return fb_request("GET", path)


def fb_get_timeout(path: str, timeout: int = 2) -> Any:
    return fb_request("GET", path, timeout=timeout)


def fb_get_query(path: str, params: dict[str, Any], timeout: int = 20) -> Any:
    query = urllib.parse.urlencode(params)
    req = urllib.request.Request(f"{fb_url(path)}?{query}", headers={"Content-Type": "application/json; charset=utf-8"})
    try:
        with urllib.request.urlopen(req, timeout=timeout) as resp:
            body = resp.read().decode("utf-8")
    except urllib.error.HTTPError as exc:
        body = exc.read().decode("utf-8", errors="replace")
        raise WorkerError(f"firebase GET {path} failed: HTTP {exc.code} {body[:300]}") from exc
    except urllib.error.URLError as exc:
        raise WorkerError(f"firebase GET {path} failed: {exc}") from exc
    if not body:
        return None
    return json.loads(body)


def fb_put(path: str, payload: Any) -> Any:
    return fb_request("PUT", path, payload)


def fb_patch(path: str, payload: dict[str, Any]) -> Any:
    return fb_request("PATCH", path, payload)


def sanitize_key(value: str | None, fallback: str = "default") -> str:
    text = (value or "").strip() or fallback
    text = re.sub(r"[.#$/\[\]?]+", "_", text)
    text = re.sub(r"\s+", "_", text)
    text = re.sub(r"[^0-9A-Za-z가-힣_-]+", "_", text)
    text = text.strip("_")
    return (text or fallback)[:80]


def compact_error(text: str, limit: int = 500) -> str:
    text = re.sub(r"\s+", " ", text).strip()
    return text[:limit]


def structured_source_error_fields(exc: BaseException) -> dict[str, Any]:
    if not isinstance(exc, SourceReadError):
        return {}
    fields: dict[str, Any] = {
        "source_error_code": exc.code,
        "source": exc.source,
        "source_attempts": exc.attempts,
        "source_retryable": exc.attempts > 0,
    }
    if exc.path:
        fields["source_path"] = exc.path
    if exc.query:
        fields["source_query"] = compact_text(exc.query, 180)
    return fields


def is_retryable_codex_runtime_error(error: Any) -> bool:
    text = compact_error(str(error or ""), 1200).lower()
    return (
        "failed to refresh available models" in text
        or "timeout waiting for child process to exit" in text
        or "resident_response_health_empty_final" in text
    )


def is_resident_codex_runtime_error(error: Any) -> bool:
    text = compact_error(str(error or ""), 1200).lower()
    return "resident codex" in text or "resident_response_health_empty_final" in text


def normalize_key_text(value: Any) -> str:
    return re.sub(r"\s+", "", str(value or "")).strip().lower()


def parse_json_object_text(text: str, *, allow_balanced_suffix: bool = False) -> dict[str, Any] | None:
    text = text.strip()
    if text.startswith("```"):
        text = re.sub(r"^```(?:json|JSON)?\s*", "", text)
        text = re.sub(r"\s*```$", "", text).strip()
    if not text:
        return None
    if not text.startswith("{"):
        start = text.find("{")
        if start < 0:
            return None
        text = text[start:]
    depth = 0
    in_string = False
    escaped = False
    end = -1
    for idx, ch in enumerate(text):
        if in_string:
            if escaped:
                escaped = False
            elif ch == "\\":
                escaped = True
            elif ch == '"':
                in_string = False
            continue
        if ch == '"':
            in_string = True
        elif ch == "{":
            depth += 1
        elif ch == "}":
            depth -= 1
            if depth == 0:
                end = idx + 1
                break
    if end < 0:
        if not allow_balanced_suffix or depth <= 0 or in_string:
            return None
        text = text + ("}" * depth)
        end = len(text)
    try:
        parsed = json.loads(text[:end])
    except json.JSONDecodeError:
        return None
    return parsed if isinstance(parsed, dict) else None


def looks_like_action_protocol(answer: str) -> bool:
    text = str(answer or "").strip()
    if not text or text == "SKIP":
        return False
    if ACTION_SENTINEL in text:
        return True
    if text.startswith("```"):
        stripped = re.sub(r"^```(?:json|JSON)?\s*", "", text)
        stripped = re.sub(r"\s*```$", "", stripped).strip()
        text = stripped
    return bool(re.match(r"^\{\s*\"actions\"\s*:", text))


def looks_like_storebot_output_protocol(answer: str) -> bool:
    text = str(answer or "").strip()
    if not text or text == "SKIP":
        return False
    if OUTPUT_SENTINEL in text:
        return True
    if text.startswith("```"):
        stripped = re.sub(r"^```(?:json|JSON)?\s*", "", text)
        stripped = re.sub(r"\s*```$", "", stripped).strip()
        text = stripped
    return bool(re.match(r"^\{\s*\"(?:category|type)\"\s*:", text))


def parse_action_request(answer: str) -> dict[str, Any] | None:
    text = answer.strip()
    if not text or text == "SKIP":
        return None
    action_protocol = looks_like_action_protocol(text)
    if ACTION_SENTINEL in text:
        text = text.split(ACTION_SENTINEL, 1)[1].strip()
    elif not text.startswith("{") and not text.startswith("```"):
        return None
    parsed = parse_json_object_text(text, allow_balanced_suffix=action_protocol)
    if not isinstance(parsed, dict):
        return None
    actions = parsed.get("actions")
    if not isinstance(actions, list) or not actions:
        return None
    return parsed


def parse_storebot_output(answer: str) -> dict[str, Any] | None:
    text = str(answer or "").strip()
    if not text:
        return None
    if text == "SKIP":
        return {"category": "skip", "message": ""}
    if OUTPUT_SENTINEL in text:
        text = text.split(OUTPUT_SENTINEL, 1)[1].strip()
    elif not text.startswith("{") and not text.startswith("```"):
        return None
    parsed = parse_json_object_text(text)
    if not isinstance(parsed, dict):
        return None
    if not str(parsed.get("category") or parsed.get("type") or "").strip():
        return None
    return parsed


def normalize_output_category(value: Any) -> str:
    text = str(value or "").strip().lower().replace("-", "_")
    aliases = {
        "reply": "kakao_reply",
        "kakao": "kakao_reply",
        "send": "kakao_reply",
        "report_only": "report",
        "record": "log_only",
        "log": "log_only",
        "none": "skip",
        "self_repair": "self_fix",
        "code_fix": "self_fix",
        "fix": "self_fix",
    }
    text = aliases.get(text, text)
    allowed = {"kakao_reply", "report", "self_heal", "self_fix", "log_only", "skip"}
    return text if text in allowed else "report"


def output_text(payload: dict[str, Any]) -> str:
    for key in ("message", "reply", "text", "summary", "report", "note"):
        value = str(payload.get(key) or "").strip()
        if value:
            return value
    return ""


def output_public_payload(payload: dict[str, Any]) -> dict[str, Any]:
    public: dict[str, Any] = {}
    for key in (
        "category",
        "severity",
        "message",
        "summary",
        "reason",
        "task",
        "cwd",
        "project",
        "profile",
        "model",
        "reasoning_effort",
        "allow_apply",
        "ops_manual_collect",
        "manual_candidate_id",
        "manual_update_request_id",
        "manual_scope",
        "reference_targets",
        "keep_raw_note",
        "category_policy",
        "title_policy",
        "organize_mode",
    ):
        if key in payload:
            value = payload.get(key)
            if isinstance(value, str):
                public[key] = compact_error(value, 1200)
            else:
                public[key] = value
    return public


def is_schedule_attendance_event(item: dict[str, Any]) -> bool:
    event_kind = str(item.get("event_kind") or item.get("kind") or "").strip()
    if event_kind in SCHEDULE_ATTENDANCE_EVENT_KINDS:
        return True
    payload = item.get("payload")
    if not isinstance(payload, dict):
        return False
    payload_kind = str(payload.get("event_kind") or payload.get("kind") or "").strip()
    return event_kind.startswith("schedule_attendance_") or payload_kind in SCHEDULE_ATTENDANCE_PAYLOAD_KINDS


def request_event_kind(item: dict[str, Any]) -> str:
    event_kind = str(item.get("event_kind") or item.get("kind") or "").strip()
    if event_kind:
        return event_kind
    payload = item.get("payload")
    if isinstance(payload, dict):
        return str(payload.get("event_kind") or payload.get("kind") or "").strip()
    return ""


def request_truthy_flag(item: dict[str, Any], keys: tuple[str, ...]) -> bool:
    candidates: list[Any] = [item]
    payload = item.get("payload")
    if isinstance(payload, dict):
        candidates.append(payload)
    for candidate in candidates:
        if not isinstance(candidate, dict):
            continue
        for key in keys:
            value = candidate.get(key)
            if value is True:
                return True
            if isinstance(value, str) and value.strip().lower() in {"1", "true", "yes", "y", "on"}:
                return True
    return False


def request_context_fields(item: dict[str, Any]) -> str:
    payload = item.get("payload")
    values = [
        item.get("source"),
        item.get("transport"),
        item.get("android_source"),
        item.get("android_transport"),
        item.get("sender"),
        item.get("sender_name"),
        item.get("from"),
        item.get("worker"),
    ]
    if isinstance(payload, dict):
        values.extend(
            [
                payload.get("source"),
                payload.get("transport"),
                payload.get("sender"),
                payload.get("worker"),
            ]
        )
    return " ".join(str(value or "") for value in values).lower()


def is_chat_image_event(item: dict[str, Any]) -> bool:
    return request_event_kind(item).strip().lower() == CHAT_IMAGE_EVENT_KIND


def chat_vision_capture_payload(item: dict[str, Any]) -> dict[str, Any]:
    for key in ("vision_capture", "capture", "payload"):
        value = item.get(key)
        if isinstance(value, dict) and (
            str(value.get("capture_kind") or "").strip() == "kakao_visible_chat"
            or str(value.get("image_capture_status") or "").strip()
            or str(value.get("screen_capture_path") or value.get("path") or "").strip()
        ):
            return value
    return {}


def chat_vision_allowed_roots() -> list[Path]:
    configured = str(os.environ.get("STOREBOT_CHAT_VISION_ROOTS") or "").strip()
    raw_roots = [part.strip() for part in configured.split(os.pathsep) if part.strip()] if configured else list(CHAT_VISION_DEFAULT_ROOTS)
    roots: list[Path] = []
    for raw in raw_roots:
        try:
            root = Path(raw).expanduser().resolve(strict=False)
        except (OSError, RuntimeError):
            continue
        if root not in roots:
            roots.append(root)
    return roots


def _chat_vision_path_candidates(raw_path: str) -> list[Path]:
    clean = str(raw_path or "").strip()
    if not clean:
        return []
    candidates = [Path(clean)]
    storage_prefix = "/storage/emulated/0/"
    sdcard_prefix = "/sdcard/"
    if clean.startswith(storage_prefix):
        candidates.append(Path(sdcard_prefix + clean[len(storage_prefix):]))
    elif clean.startswith(sdcard_prefix):
        candidates.append(Path(storage_prefix + clean[len(sdcard_prefix):]))
    return candidates


def _path_within_any_root(path: Path, roots: list[Path]) -> bool:
    for root in roots:
        try:
            path.relative_to(root)
            return True
        except ValueError:
            continue
    return False


def resolve_chat_vision_image_paths(item: dict[str, Any]) -> tuple[list[str], str]:
    if not is_chat_image_event(item):
        return [], ""
    capture = chat_vision_capture_payload(item)
    if not capture:
        return [], "capture_metadata_missing"
    if str(capture.get("image_capture_status") or "").strip() != "captured":
        return [], compact_error(str(capture.get("image_capture_error") or "capture_not_completed"), 120)
    raw_path = str(capture.get("screen_capture_path") or capture.get("path") or "").strip()
    roots = chat_vision_allowed_roots()
    resolved: Path | None = None
    for candidate in _chat_vision_path_candidates(raw_path):
        try:
            current = candidate.expanduser().resolve(strict=True)
        except (FileNotFoundError, OSError, RuntimeError):
            continue
        if current.is_file() and _path_within_any_root(current, roots):
            resolved = current
            break
    if resolved is None:
        return [], "capture_path_missing_or_outside_allowlist"
    if resolved.suffix.lower() not in {".jpg", ".jpeg", ".png", ".webp"}:
        return [], "capture_format_not_allowed"
    try:
        stat = resolved.stat()
    except OSError:
        return [], "capture_stat_failed"
    if stat.st_size <= 0 or stat.st_size > CHAT_VISION_MAX_BYTES:
        return [], "capture_size_invalid"
    age_ms = max(0, now_ms() - int(stat.st_mtime * 1000))
    if age_ms > CHAT_VISION_MAX_AGE_MS:
        return [], "capture_stale"
    expected_sha = str(capture.get("screen_capture_sha256") or capture.get("sha256") or "").strip().lower()
    if not re.fullmatch(r"[0-9a-f]{64}", expected_sha):
        return [], "capture_sha256_missing"
    digest = hashlib.sha256()
    try:
        with resolved.open("rb") as source:
            while True:
                chunk = source.read(128 * 1024)
                if not chunk:
                    break
                digest.update(chunk)
    except OSError:
        return [], "capture_read_failed"
    if digest.hexdigest() != expected_sha:
        return [], "capture_sha256_mismatch"
    return [str(resolved)], ""


def storebot_contextless_no_reply_reason(item: dict[str, Any]) -> str:
    event_kind = request_event_kind(item)
    lower_event_kind = event_kind.lower()
    if lower_event_kind in HARD_NO_REPLY_EVENT_KINDS:
        return f"internal_event_no_reply_{lower_event_kind}"

    if lower_event_kind == CHAT_IMAGE_EVENT_KIND:
        _image_paths, image_error = resolve_chat_vision_image_paths(item)
        if image_error:
            return f"chat_image_no_reply_{sanitize_key(image_error, 'capture_unavailable')}"
        return ""

    context_fields = request_context_fields(item)
    sender = str(item.get("sender") or item.get("sender_name") or item.get("from") or "").strip()
    if sender in SELF_REPLY_SENDERS:
        return "self_message_no_reply"
    if any(marker in context_fields for marker in CONTEXTLESS_NO_REPLY_MARKERS):
        return "contextless_internal_source_no_reply"

    if request_truthy_flag(item, EXPLICIT_KAKAO_REPLY_KEYS):
        return ""
    if event_kind not in USER_CHAT_EVENT_KINDS:
        return f"non_chat_event_no_reply_{sanitize_key(event_kind, 'unknown')}"
    return ""


def schedule_attendance_output_violation_reason(item: dict[str, Any], answer: str) -> str:
    if not is_schedule_attendance_event(item):
        return ""
    text = str(answer or "").strip()
    if not text or text == "SKIP":
        return ""
    if re.search(r"image_request|schedule_briefing", text, flags=re.IGNORECASE):
        return "attendance_event_image_payload_blocked"
    if re.search(r"^\s*근무표\b", text):
        return "attendance_event_schedule_heading_blocked"
    schedule_sections = sum(
        1
        for label in ("근무", "날씨", "월드컵", "뉴스", "콘티")
        if re.search(rf"(?m)^\s*{label}\s*[:：]", text)
    )
    if schedule_sections >= 2:
        return "attendance_event_schedule_sections_blocked"
    non_empty_lines = [line for line in text.splitlines() if line.strip()]
    if len(non_empty_lines) >= 3 and re.search(r"근무표|스케줄", text):
        return "attendance_event_schedule_body_blocked"
    if re.search(r"(?m)^\s*[-*•]?\s*[가-힣A-Za-z0-9]{1,12}\s+\d{1,2}:\d{2}\s*[~-]", text):
        return "attendance_event_schedule_rows_blocked"
    return ""


def blocked_schedule_attendance_output(
    req_id: str,
    item: dict[str, Any],
    answer: str,
    reason: str,
    args: argparse.Namespace,
) -> dict[str, Any]:
    output = {
        "category": "skip",
        "message": "",
        "reason": reason,
        "summary": compact_error(str(answer or ""), 500),
    }
    write_output_record(
        req_id,
        item,
        output,
        "skip",
        answer="SKIP",
        skipped=True,
        self_fix_request_id="",
        args=args,
    )
    return {
        "answer": "SKIP",
        "skipped": True,
        "output_category": "skip",
        "output_payload": output_public_payload(output),
        "self_fix_request_id": "",
    }


def blocked_internal_protocol_output(
    req_id: str,
    item: dict[str, Any],
    answer: str,
    reason: str,
    args: argparse.Namespace,
) -> dict[str, Any]:
    output = {
        "category": "skip",
        "message": "",
        "reason": reason,
        "summary": compact_error(str(answer or ""), 500),
    }
    write_output_record(
        req_id,
        item,
        output,
        "skip",
        answer="SKIP",
        skipped=True,
        self_fix_request_id="",
        args=args,
    )
    return {
        "answer": "SKIP",
        "skipped": True,
        "output_category": "skip",
        "output_payload": output_public_payload(output),
        "self_fix_request_id": "",
    }


def enqueue_self_fix_request(req_id: str, item: dict[str, Any], output: dict[str, Any], args: argparse.Namespace) -> str:
    if args.dry_run:
        return ""
    task = str(output.get("task") or output.get("message") or output.get("summary") or "").strip()
    if not task:
        task = "StoreBot AI가 self_fix를 요청했지만 task가 비어 있습니다. parent request와 최신 StoreBot 문서를 보고 문제를 진단하세요."
    cwd = str(output.get("cwd") or BASE_DIR)
    project = str(output.get("project") or "my-first-project")
    profile = str(output.get("profile") or "patch").strip().lower()
    if profile not in {"read_only", "patch", "yolo"}:
        profile = "patch"
    model = str(output.get("model") or "gpt-5.5").strip() or "gpt-5.5"
    effort = str(output.get("reasoning_effort") or "xhigh").strip().lower() or "xhigh"
    if effort not in ALLOWED_REASONING_EFFORTS:
        effort = "xhigh"
    created = now_ms()
    key = sanitize_key(f"storebot_self_fix_{created}_{short_text_hash(req_id + task)[:8]}")
    message_preview = compact_error(str(item.get("message") or item.get("text") or ""), 500)
    reason = compact_error(str(output.get("reason") or output.get("summary") or ""), 500)
    fast_triage = build_storebot_groq_triage(
        candidate_type="storebot_output_self_fix",
        severity="error",
        request_id=req_id,
        item=item,
        evidence={
            "request_id": req_id,
            "event_kind": item.get("event_kind") or item.get("kind") or "",
            "source": item.get("source") or "",
            "reason": reason,
            "output": compact_payload(output, 5000),
        },
        task=task,
    )
    full_task = (
        "StoreBot AI가 운영 이벤트를 분석해 자체수정(self_fix)을 요청했습니다.\n"
        "현재 Codex 세션과 같은 운영 원칙을 적용하세요. AGENTS.md, CODEX_BRIEF.md, CODEMAP.txt, 대상 앱 문서를 먼저 읽고, "
        "기존 미커밋 변경은 되돌리지 마세요. destructive reset/checkout/force push 금지입니다.\n"
        "goal mode의 뜻은 사용자 승인 대기 없이 분석/복구/수정을 끝까지 진행해 승인 딜레이로 멈추지 않는 것입니다. "
        "필요한 수정은 최소 범위로 하고 가능한 검증까지 수행하세요. 커밋은 사용자가 명시한 기준이 있을 때만 하세요.\n\n"
        f"parent_request_id: {req_id}\n"
        f"event_kind: {item.get('event_kind') or item.get('kind') or ''}\n"
        f"source: {item.get('source') or ''}\n"
        f"room: {item.get('room_name') or item.get('roomTitle') or item.get('room') or ''}\n"
        f"message_preview: {message_preview}\n"
        f"reason: {reason}\n\n"
        f"{groq_triage_task_block(fast_triage)}"
        "## self_fix task\n"
        f"{task}\n"
    )
    payload = {
        "status": "pending",
        "source": "storebot_output_self_fix",
        "requester": "storebot_ai",
        "is_owner": True,
        "task": full_task,
        "cwd": cwd,
        "project": project,
        "profile": profile,
        "model": model,
        "reasoning_effort": effort,
        "timeout_sec": int(output.get("timeout_sec") or 1800),
        "ttl_ms": int(output.get("ttl_ms") or 6 * 60 * 60 * 1000),
        "created_at_ms": created,
        "parent_request_id": req_id,
        "parent_source": str(item.get("source") or ""),
        "parent_event_kind": str(item.get("event_kind") or item.get("kind") or ""),
        "bypass_adb": True,
        "bypass_kakao": True,
        "reply_target": {"type": "firebase_result", "kakao_publish": False},
        "fast_triage": compact_payload(fast_triage, 4000),
        "fast_triage_provider": str(fast_triage.get("provider") or ""),
        "fast_triage_status": str(fast_triage.get("status") or ""),
    }
    fb_put(f"{CODEX_OPS_REQUESTS_PATH}/{key}", payload)
    return key


def manual_collect_from_output(output: dict[str, Any]) -> dict[str, Any]:
    collect = output.get("ops_manual_collect")
    if isinstance(collect, dict):
        return dict(collect)
    manual_update = output.get("manual_update")
    if isinstance(manual_update, dict):
        return dict(manual_update)
    if collect is True or manual_update is True:
        return {
            "summary": output.get("summary") or output.get("message") or output.get("note") or "",
            "reason": output.get("reason") or "",
        }
    return {}


def build_ops_manual_candidate(
    *,
    candidate_id: str,
    req_id: str,
    item: dict[str, Any],
    output: dict[str, Any],
    collect: dict[str, Any],
    captured_at_ms: int,
) -> dict[str, Any]:
    event_kind = str(item.get("event_kind") or item.get("kind") or "chat").strip()
    room_id = str(item.get("room_id") or item.get("room") or "storebot_group")
    room_name = str(item.get("room_name") or item.get("roomTitle") or "운영방")
    actor = str(item.get("sender") or item.get("from") or "storebot")
    original_message = str(item.get("message") or item.get("text") or "").strip()
    reason = str(collect.get("reason") or output.get("reason") or "").strip()
    text = str(
        collect.get("summary")
        or collect.get("body")
        or collect.get("text")
        or output.get("summary")
        or output.get("message")
        or output.get("note")
        or reason
        or original_message
        or ""
    ).strip()
    reference_targets = collect.get("reference_targets") or output.get("reference_targets") or ["ops_manual"]
    if isinstance(reference_targets, str):
        reference_targets = [reference_targets]
    classification_hints = {
        "reason": reason,
        "category_policy": str(collect.get("category_policy") or output.get("category_policy") or "auto_by_volume"),
        "title_policy": str(collect.get("title_policy") or output.get("title_policy") or "codex_optional_or_none"),
        "organize_mode": str(collect.get("organize_mode") or output.get("organize_mode") or "candidate_review"),
        "reference_targets": list(reference_targets),
    }
    return {
        "schema_version": "ops_manual_candidate_v1",
        "candidate_id": candidate_id,
        "source_channel": "kakao",
        "source_event_id": req_id,
        "actor": actor,
        "room_id": room_id,
        "captured_at_ms": captured_at_ms,
        "text": text,
        "raw_payload": {
            "source": "storebot_chat_ops_manual_collect",
            "event_kind": event_kind,
            "room_name": room_name,
            "message_preview": compact_error(original_message, 700),
            "collect": compact_payload(collect, 2500),
            "storebot_output": output_public_payload(output),
        },
        "classification_hints": classification_hints,
        "status": "pending",
        "status_history": [
            {
                "status": "pending",
                "at_ms": captured_at_ms,
                "actor": actor,
                "source": "storebot_codex_worker",
            }
        ],
    }


def enqueue_ops_manual_candidate(req_id: str, item: dict[str, Any], output: dict[str, Any], args: argparse.Namespace) -> str:
    if args.dry_run:
        return ""
    collect = manual_collect_from_output(output)
    if not collect:
        return ""
    summary = str(
        collect.get("summary")
        or collect.get("body")
        or collect.get("text")
        or output.get("summary")
        or output.get("message")
        or output.get("note")
        or ""
    ).strip()
    original_message = str(item.get("message") or item.get("text") or "").strip()
    reason = str(collect.get("reason") or output.get("reason") or "").strip()
    if not summary and not reason:
        return ""
    created = now_ms()
    fingerprint = short_text_hash(json.dumps(
        {
            "parent": req_id,
            "summary": summary,
            "reason": reason,
            "message": original_message[:500],
        },
        ensure_ascii=False,
        sort_keys=True,
    ))
    key = sanitize_key(f"ops_manual_collect_{created}_{fingerprint[:8]}")
    payload = build_ops_manual_candidate(
        candidate_id=key,
        req_id=req_id,
        item=item,
        output=output,
        collect=collect,
        captured_at_ms=created,
    )
    fb_put(f"{OPS_MANUAL_CANDIDATES_PATH}/{key}", payload)
    return key


def enqueue_ops_manual_collect_request(req_id: str, item: dict[str, Any], output: dict[str, Any], args: argparse.Namespace) -> str:
    return enqueue_ops_manual_candidate(req_id, item, output, args)


def normalize_cli_diagnostic_type(candidate_type: str) -> str:
    normalized = sanitize_key(str(candidate_type or "").strip(), "storebot_diagnostic")
    if normalized not in STOREBOT_CLI_DIAGNOSTIC_TYPES:
        return "storebot_diagnostic"
    return normalized


def cli_diagnostic_cooldown_ms(severity: str, requested_ms: int | None = None) -> int:
    if requested_ms is not None and requested_ms >= 0:
        return requested_ms
    severity_text = str(severity or "").lower()
    if severity_text in {"critical", "error"}:
        return 10 * 60 * 1000
    if severity_text == "warning":
        return 30 * 60 * 1000
    return 60 * 60 * 1000


def cli_diagnostic_dedupe_key(
    candidate_type: str,
    domain: str,
    request_id: str,
    evidence: dict[str, Any],
) -> str:
    request_part = str(request_id or "").strip()
    if not request_part:
        request_part = short_text_hash(json.dumps(compact_payload(evidence, 2000), ensure_ascii=False, sort_keys=True))
    return sanitize_key(f"{domain}_{candidate_type}_{request_part}", "storebot_cli_diagnostic")


def enqueue_storebot_cli_diagnostic(
    *,
    candidate_type: str,
    severity: str,
    request_id: str,
    item: dict[str, Any] | None,
    evidence: dict[str, Any],
    args: argparse.Namespace | None,
    missing_sections: list[str] | None = None,
    retry_count: int = 0,
    safe_scope: str = "",
    domain: str = "storebot",
    cooldown_ms: int | None = None,
    auto_coding_allowed: bool = True,
    must_attempt_repair: bool = True,
) -> str:
    if args is None or args.dry_run:
        return ""
    item = item if isinstance(item, dict) else {}
    normalized_type = normalize_cli_diagnostic_type(candidate_type)
    severity_text = str(severity or "error").lower()
    if severity_text not in {"info", "warning", "error", "critical"}:
        severity_text = "error"
    domain_key = sanitize_key(domain or "storebot", "storebot")
    now = now_ms()
    evidence_payload = compact_payload(evidence, 8000) if isinstance(evidence, dict) else {}
    dedupe_key = cli_diagnostic_dedupe_key(normalized_type, domain_key, request_id, evidence_payload if isinstance(evidence_payload, dict) else {})
    state_path = f"{CLI_DIAGNOSTIC_STATE_PATH}/{domain_key}/{normalized_type}/{dedupe_key}"
    previous: dict[str, Any] = {}
    try:
        raw_previous = fb_get(state_path) or {}
        if isinstance(raw_previous, dict):
            previous = raw_previous
    except Exception as exc:
        log(f"cli diagnostic state read failed key={dedupe_key}: {compact_error(str(exc), 160)}")
    previous_request_id = str(previous.get("last_request_id") or "")
    previous_status = ""
    if previous_request_id:
        try:
            previous_request = fb_get(f"{CODEX_OPS_REQUESTS_PATH}/{previous_request_id}") or {}
            if isinstance(previous_request, dict):
                previous_status = str(previous_request.get("status") or "").lower()
        except Exception:
            previous_status = ""
    if previous_status in {"pending", "running"}:
        return previous_request_id
    last_requested_at = normalize_ts_ms(previous.get("last_requested_at_ms") or 0)
    cooldown = cli_diagnostic_cooldown_ms(severity_text, cooldown_ms)
    if last_requested_at > 0 and now - last_requested_at < cooldown:
        return previous_request_id

    room_id = str(item.get("room_id") or item.get("room") or evidence.get("room_id") or "")
    room_name = str(item.get("room_name") or item.get("roomTitle") or evidence.get("room_name") or "")
    source = str(item.get("source") or evidence.get("source") or "")
    missing = [str(section) for section in (missing_sections or evidence.get("missing_sections") or []) if str(section or "").strip()]
    req_key = sanitize_key(f"ops_storebot_{normalized_type}_{now}_{short_text_hash(dedupe_key)[:8]}")
    safe_scope_text = safe_scope or "Non-destructive StoreBot diagnostics and bounded code/config repair only. Do not send Kakao messages."
    fast_triage = build_storebot_groq_triage(
        candidate_type=normalized_type,
        severity=severity_text,
        request_id=request_id,
        item=item,
        evidence=evidence_payload if isinstance(evidence_payload, dict) else {},
        task=safe_scope_text,
    )
    task = (
        "StoreBot worker가 사용자 결과 파손 또는 운영 hot path 차단 후보를 감지해 서버폰 CLI 진단/self_fix를 요청했습니다.\n"
        "단발 retry 가능한 실패는 제외하고, 아래 candidate와 evidence만 근거로 안전 범위 안에서 원인 진단과 수정/검증을 시도하세요.\n"
        "실패한 실시간 자료를 임의 생성하지 말고, 카카오 직접 발송/destructive reset/force push/금융·주문 원본 변경은 금지입니다.\n\n"
        f"candidate_type: {normalized_type}\n"
        f"severity: {severity_text}\n"
        f"request_id: {request_id}\n"
        f"room_id: {room_id}\n"
        f"room_name: {room_name}\n"
        f"source: {source}\n"
        f"retry_count: {retry_count}\n"
        f"missing_sections: {', '.join(missing)}\n"
        f"safe_scope: {safe_scope_text}\n\n"
        f"{groq_triage_task_block(fast_triage)}"
        "## evidence\n"
        f"{json.dumps(evidence_payload, ensure_ascii=False, indent=2)}\n"
    )
    payload = {
        "status": "pending",
        "source": "storebot_cli_diagnostic",
        "requester": "storebot_codex_worker",
        "is_owner": True,
        "task": task,
        "cwd": str(BASE_DIR),
        "project": "my-first-project",
        "domain": domain_key,
        "profile": "patch" if auto_coding_allowed else "read_only",
        "model": "gpt-5.5",
        "reasoning_effort": "xhigh",
        "timeout_sec": 1800,
        "ttl_ms": 6 * 60 * 60 * 1000,
        "created_at_ms": now,
        "parent_request_id": request_id,
        "request_id": request_id,
        "candidate_type": normalized_type,
        "severity": severity_text,
        "room_id": room_id,
        "room_name": room_name,
        "parent_source": source,
        "parent_event_kind": str(item.get("event_kind") or item.get("kind") or evidence.get("event_kind") or ""),
        "missing_sections": missing,
        "retry_count": max(0, retry_count),
        "evidence": evidence_payload,
        "fast_triage": compact_payload(fast_triage, 4000),
        "fast_triage_provider": str(fast_triage.get("provider") or ""),
        "fast_triage_status": str(fast_triage.get("status") or ""),
        "safe_scope": safe_scope_text,
        "dedupe_key": dedupe_key,
        "detected_severity": severity_text,
        "detected_issue_codes": [normalized_type],
        "detected_error_issue_codes": [normalized_type] if severity_text in {"error", "critical"} else [],
        "bypass_adb": True,
        "bypass_kakao": True,
        "reply_target": {"type": "firebase_result", "kakao_publish": False},
        "safety_boundary": safe_scope_text,
        "auto_coding_allowed": bool(auto_coding_allowed),
        "must_attempt_repair": bool(must_attempt_repair),
        "repair_scope": safe_scope_text,
        "destructive_actions_allowed": False,
    }
    fb_put(f"{CODEX_OPS_REQUESTS_PATH}/{req_key}", payload)
    state_payload = {
        "candidate_type": normalized_type,
        "domain": domain_key,
        "dedupe_key": dedupe_key,
        "last_request_id": req_key,
        "last_requested_at_ms": now,
        "severity": severity_text,
        "request_id": request_id,
        "room_id": room_id,
        "missing_sections": missing,
        "cooldown_ms": cooldown,
    }
    fb_put(state_path, state_payload)
    fb_put(CLI_DIAGNOSTIC_LATEST_PATH, state_payload)
    return req_key


def enqueue_local_direct_codex_runtime_diagnostic(
    req_id: str,
    item: dict[str, Any],
    args: argparse.Namespace | None,
    error: Any,
    stage: str,
) -> str:
    if args is None or args.dry_run or not is_retryable_codex_runtime_error(error):
        return ""
    candidate_type = "codex_model_refresh_runtime_failure"
    cooldown = 10 * 60 * 1000
    now = now_ms()
    error_text = compact_error(str(error), 500)
    error_signature = short_text_hash(error_text)
    request_marker_key = sanitize_key(req_id, "local_direct")
    marker_paths = [
        f"{CLI_DIAGNOSTIC_STATE_PATH}/storebot/{candidate_type}/request/{request_marker_key}",
        f"{CLI_DIAGNOSTIC_STATE_PATH}/storebot/{candidate_type}/signature/{error_signature}",
    ]

    def mark_diagnostic_metadata(diagnostic_id: str, enqueue_status: str) -> None:
        if not diagnostic_id:
            return
        metadata = {
            "diagnostic_enqueued": True,
            "self_fix_enqueued": True,
            "diagnostic_enqueue_status": enqueue_status,
            "diagnostic_request_id": diagnostic_id,
            "diagnostic_enqueued_at_ms": now,
            "diagnostic_candidate_type": candidate_type,
            "diagnostic_error_signature": error_signature,
        }
        item.update(metadata)
        safe_req_id = sanitize_key(req_id, "local_direct")
        try:
            fb_patch(f"{REQUESTS_PATH}/{safe_req_id}", metadata)
        except Exception as exc:
            log(f"request diagnostic metadata patch failed request={req_id}: {compact_error(str(exc), 160)}")
        try:
            fb_patch(
                INPUT_HEALTH_PATH,
                {
                    "last_request_diagnostic_id": diagnostic_id,
                    "last_request_diagnostic_at_ms": now,
                    "last_request_diagnostic_candidate_type": candidate_type,
                    "last_request_diagnostic_error_signature": error_signature,
                    "last_request_diagnostic_trigger_id": safe_req_id,
                    "last_request_diagnostic_enqueue_status": enqueue_status,
                    "diagnostic_enqueued": True,
                    "self_fix_enqueued": True,
                },
            )
        except Exception as exc:
            log(f"input health diagnostic metadata patch failed request={req_id}: {compact_error(str(exc), 160)}")

    for state_path in marker_paths:
        previous: dict[str, Any] = {}
        try:
            raw_previous = fb_get(state_path) or {}
            if isinstance(raw_previous, dict):
                previous = raw_previous
        except Exception as exc:
            log(f"codex runtime diagnostic state read failed: {compact_error(str(exc), 160)}")
        previous_request_id = str(previous.get("last_request_id") or "")
        if previous_request_id:
            try:
                previous_request = fb_get(f"{CODEX_OPS_REQUESTS_PATH}/{previous_request_id}") or {}
                if isinstance(previous_request, dict) and str(previous_request.get("status") or "").lower() in {"pending", "running"}:
                    mark_diagnostic_metadata(previous_request_id, "deduped_running")
                    return previous_request_id
            except Exception:
                pass
        last_requested_at = normalize_ts_ms(previous.get("last_requested_at_ms") or 0)
        if last_requested_at > 0 and now - last_requested_at < cooldown:
            mark_diagnostic_metadata(previous_request_id, "deduped_cooldown")
            return previous_request_id

    elapsed_ms = 0
    try:
        elapsed_ms = int(item.get("_local_direct_elapsed_ms") or item.get("local_direct_elapsed_ms") or 0)
    except (TypeError, ValueError):
        elapsed_ms = 0
    started_at = normalize_ts_ms(item.get("_local_direct_started_at_ms") or 0)
    if elapsed_ms <= 0 and started_at > 0:
        elapsed_ms = max(0, now - started_at)
    message = str(item.get("message") or item.get("text") or "")
    evidence = {
        "stage": stage,
        "trigger_request_id": req_id,
        "request_id": req_id,
        "error": error_text,
        "error_signature": error_signature,
        "request_status": item.get("status"),
        "ingress_status": item.get("ingress_status"),
        "source": item.get("source"),
        "room_id": item.get("room_id") or item.get("room"),
        "room_name": item.get("room_name") or item.get("roomTitle"),
        "message_preview": compact_error(message, 220),
        "local_direct_elapsed_ms": elapsed_ms,
        "requested_action": "재발 방지 분석 및 가능한 StoreBot worker/config/code 보정",
        "event_kind": item.get("event_kind") or item.get("kind"),
        "local_direct": item.get("local_direct") is True,
        "fast_router_stateless_exec": fast_router_stateless_exec_enabled(),
    }
    try:
        diagnostic_id = enqueue_storebot_cli_diagnostic(
            candidate_type=candidate_type,
            severity="error",
            request_id=req_id,
            item=item,
            evidence=evidence,
            args=args,
            retry_count=1,
            safe_scope="StoreBot local-direct fast-router Codex runtime diagnostics and bounded repair only. Do not send Kakao messages.",
            cooldown_ms=cooldown,
            auto_coding_allowed=True,
            must_attempt_repair=True,
        )
        if diagnostic_id:
            state_payload = {
                "candidate_type": candidate_type,
                "last_request_id": diagnostic_id,
                "last_requested_at_ms": now,
                "trigger_request_id": req_id,
                "stage": stage,
                "error": error_text,
                "error_signature": error_signature,
                "cooldown_ms": cooldown,
            }
            for state_path in marker_paths:
                fb_put(state_path, state_payload)
            mark_diagnostic_metadata(diagnostic_id, "enqueued")
        return diagnostic_id
    except Exception as exc:
        log(f"codex runtime diagnostic enqueue failed request={req_id}: {compact_error(str(exc), 200)}")
        return ""


def write_output_record(
    req_id: str,
    item: dict[str, Any],
    output: dict[str, Any],
    category: str,
    *,
    answer: str,
    skipped: bool,
    self_fix_request_id: str = "",
    args: argparse.Namespace,
) -> None:
    if args.dry_run:
        return
    payload = {
        "request_id": req_id,
        "category": category,
        "answer_preview": compact_error(answer, 1200),
        "answer_len": len(answer),
        "skipped": skipped,
        "self_fix_request_id": self_fix_request_id,
        "source": str(item.get("source") or ""),
        "event_kind": str(item.get("event_kind") or item.get("kind") or "chat"),
        "room_id": str(item.get("room_id") or item.get("room") or ""),
        "room_name": str(item.get("room_name") or item.get("roomTitle") or ""),
        "created_at_ms": now_ms(),
        "worker": args.node,
        "output": output_public_payload(output),
    }
    fb_put(f"{OUTPUTS_PATH}/{sanitize_key(req_id)}", payload)
    fb_put(f"{OUTPUTS_PATH}/latest", payload)


def apply_storebot_output_contract(
    req_id: str,
    item: dict[str, Any],
    answer: str,
    args: argparse.Namespace,
) -> dict[str, Any]:
    output = parse_storebot_output(answer)
    if output is None:
        if looks_like_action_protocol(answer):
            return blocked_internal_protocol_output(req_id, item, answer, "internal_action_protocol_blocked", args)
        if looks_like_storebot_output_protocol(answer):
            return blocked_internal_protocol_output(req_id, item, answer, "malformed_storebot_output_blocked", args)
        violation_reason = schedule_attendance_output_violation_reason(item, answer)
        if violation_reason:
            return blocked_schedule_attendance_output(req_id, item, answer, violation_reason, args)
        return {
            "answer": answer,
            "skipped": answer == "SKIP",
            "output_category": "skip" if answer == "SKIP" else "kakao_reply",
            "output_payload": {},
            "self_fix_request_id": "",
        }
    category = normalize_output_category(output.get("category") or output.get("type"))
    output["category"] = category
    text = output_text(output)
    self_fix_request_id = ""
    manual_update_request_id = enqueue_ops_manual_collect_request(req_id, item, output, args)
    if manual_update_request_id:
        output["manual_candidate_id"] = manual_update_request_id
        output["manual_update_request_id"] = manual_update_request_id
    if category == "kakao_reply":
        normalized_answer = text or answer
        skipped = normalized_answer == "SKIP"
    elif category == "skip":
        normalized_answer = "SKIP"
        skipped = True
    elif category == "self_fix":
        self_fix_request_id = enqueue_self_fix_request(req_id, item, output, args)
        normalized_answer = text or f"self_fix queued {self_fix_request_id}".strip()
        skipped = True
    else:
        normalized_answer = text or category
        skipped = True
    violation_reason = schedule_attendance_output_violation_reason(item, normalized_answer)
    if violation_reason:
        return blocked_schedule_attendance_output(req_id, item, normalized_answer, violation_reason, args)
    write_output_record(
        req_id,
        item,
        output,
        category,
        answer=normalized_answer,
        skipped=skipped,
        self_fix_request_id=self_fix_request_id,
        args=args,
    )
    return {
        "answer": normalized_answer,
        "skipped": skipped,
        "output_category": category,
        "output_payload": output_public_payload(output),
        "self_fix_request_id": self_fix_request_id,
    }


def validate_date_text(value: Any) -> str:
    text = str(value or "").strip()
    if not re.fullmatch(r"\d{4}-\d{2}-\d{2}", text):
        raise WorkerError(f"invalid date: {text}")
    datetime.strptime(text, "%Y-%m-%d")
    return text


def validate_time_text(value: Any, allow_empty: bool = False) -> str:
    text = str(value or "").strip()
    if allow_empty and not text:
        return ""
    match = re.fullmatch(r"([01]?\d|2[0-3]):([0-5]\d)", text)
    if not match:
        raise WorkerError(f"invalid time: {text}")
    return f"{int(match.group(1)):02d}:{match.group(2)}"


def as_list(value: Any) -> list[Any]:
    if value is None:
        return []
    if isinstance(value, list):
        return value
    return [value]


def schedule_compact_date_label(date_text: str) -> str:
    try:
        date_obj = datetime.strptime(str(date_text or "").strip(), "%Y-%m-%d")
        return f"{date_obj.month}/{date_obj.day}"
    except Exception:
        return str(date_text or "").strip()


def schedule_normalize_mode(value: Any, fallback: str = "") -> str:
    text = str(value or "").strip()
    return text or fallback


def schedule_payload_has_offset_range(payload: dict[str, Any]) -> bool:
    if not isinstance(payload, dict):
        return False
    for key in ("start_offset_days", "day_count"):
        if key in payload and payload.get(key) not in (None, ""):
            return True
    return False


def clamp_schedule_image_day_count(value: Any, default: int = DEFAULT_SCHEDULE_IMAGE_DAY_COUNT) -> int:
    count = safe_int(value, default)
    return min(max(MIN_SCHEDULE_IMAGE_DAY_COUNT, count), MAX_SCHEDULE_IMAGE_DAY_COUNT)


def schedule_image_viewport_from_request(item: dict[str, Any], payload: dict[str, Any] | None = None) -> dict[str, int]:
    sources = [payload if isinstance(payload, dict) else {}, item]
    width = 0
    height = 0
    for source in sources:
        nested = source.get("schedule_image_viewport")
        if isinstance(nested, dict):
            width = safe_int(nested.get("width_px") or nested.get("width"), 0)
            height = safe_int(nested.get("height_px") or nested.get("height"), 0)
        if width <= 0:
            width = safe_int(source.get("viewport_width_px"), 0)
        if height <= 0:
            height = safe_int(source.get("viewport_height_px"), 0)
        if width > 0 and height > 0:
            break
    if width <= 0 or height <= 0:
        return {}
    return {"width_px": width, "height_px": height}


def schedule_image_day_count_for_viewport(viewport: dict[str, int]) -> int:
    width = max(1, safe_int(viewport.get("width_px"), 0))
    height = max(1, safe_int(viewport.get("height_px"), 0))
    aspect = height / width
    if aspect < 1.25:
        return 4
    if aspect < 1.60:
        return 5
    if aspect < 1.95:
        return 6
    return 7


def schedule_image_generated_at_ms(item: dict[str, Any], payload: dict[str, Any] | None = None) -> int:
    payload_dict = payload if isinstance(payload, dict) else {}
    for raw in (
        payload_dict.get("generated_at_ms"),
        item.get("generated_at_ms"),
        item.get("created_at_ms"),
        item.get("ts_ms"),
    ):
        value = normalize_ts_ms(raw or 0)
        if value > 0:
            return value
    return now_ms()


def schedule_image_current_date_kst(
    item: dict[str, Any],
    payload: dict[str, Any] | None = None,
    *,
    generated_at_ms: int = 0,
) -> str:
    payload_dict = payload if isinstance(payload, dict) else {}
    for raw in (payload_dict.get("current_date_kst"), item.get("current_date_kst")):
        date_text = normalize_schedule_date_value(raw)
        if date_text:
            return date_text
    reference_ms = normalize_ts_ms(generated_at_ms or 0) or schedule_image_generated_at_ms(item, payload_dict)
    return datetime.fromtimestamp(reference_ms / 1000, KST).strftime("%Y-%m-%d")


def resolve_schedule_image_day_count_contract(
    item: dict[str, Any],
    payload: dict[str, Any] | None = None,
    *,
    explicit_dates_count: int = 0,
) -> tuple[int, str, dict[str, int]]:
    payload_dict = payload if isinstance(payload, dict) else {}
    viewport = schedule_image_viewport_from_request(item, payload_dict)
    explicit_raw = payload_dict.get("day_count") if "day_count" in payload_dict else item.get("day_count")
    explicit_value = safe_int(explicit_raw, 0)
    if MIN_SCHEDULE_IMAGE_DAY_COUNT <= explicit_value <= MAX_SCHEDULE_IMAGE_DAY_COUNT:
        return explicit_value, "explicit_day_count", viewport
    if MIN_SCHEDULE_IMAGE_DAY_COUNT <= explicit_dates_count <= MAX_SCHEDULE_IMAGE_DAY_COUNT:
        return explicit_dates_count, "explicit_dates", viewport
    if viewport:
        return schedule_image_day_count_for_viewport(viewport), "viewport_aspect", viewport
    if explicit_raw not in (None, ""):
        return clamp_schedule_image_day_count(explicit_raw), "explicit_day_count_clamped", viewport
    return DEFAULT_SCHEDULE_IMAGE_DAY_COUNT, "default_7_days", viewport


def schedule_payload_is_legacy_day_only_fallback(payload: dict[str, Any]) -> bool:
    if not isinstance(payload, dict):
        return False
    mode = str(payload.get("mode") or "").strip().casefold()
    if mode in LEGACY_DAY_ONLY_SCHEDULE_MODES:
        return True
    if not mode and schedule_payload_has_offset_range(payload):
        return safe_int(payload.get("day_count"), DEFAULT_SCHEDULE_IMAGE_DAY_COUNT) <= 1
    return False


def normalize_schedule_date_value(value: Any) -> str:
    try:
        return validate_date_text(value)
    except Exception:
        return ""


def append_schedule_date_value(dates: list[str], value: Any) -> None:
    date_text = normalize_schedule_date_value(value)
    if date_text and date_text not in dates:
        dates.append(date_text)


def append_schedule_date_values(dates: list[str], values: Any, *, limit: int = MAX_SCHEDULE_IMAGE_DAY_COUNT) -> None:
    if isinstance(values, list):
        for value in values[:limit]:
            if isinstance(value, dict):
                append_schedule_date_value(dates, value.get("date"))
            else:
                append_schedule_date_value(dates, value)
    else:
        append_schedule_date_value(dates, values)


def expand_schedule_date_range(start_date: Any, end_date: Any) -> list[str]:
    start = normalize_schedule_date_value(start_date)
    end = normalize_schedule_date_value(end_date)
    if not start and not end:
        return []
    if start and not end:
        return [start]
    if end and not start:
        return [end]
    try:
        start_obj = datetime.strptime(start, "%Y-%m-%d")
        end_obj = datetime.strptime(end, "%Y-%m-%d")
    except Exception:
        return [value for value in (start, end) if value]
    if end_obj < start_obj:
        start_obj, end_obj = end_obj, start_obj
    count = min((end_obj - start_obj).days + 1, MAX_SCHEDULE_IMAGE_DAY_COUNT)
    return [(start_obj + timedelta(days=offset)).strftime("%Y-%m-%d") for offset in range(count)]


def work_schedule_canonical_range_from_dates(
    mode: str,
    dates: list[str],
    source: str,
    *,
    day_count: Any = None,
) -> WorkScheduleCanonicalRange:
    clean_dates: list[str] = []
    for date_text in dates[:MAX_SCHEDULE_IMAGE_DAY_COUNT]:
        append_schedule_date_value(clean_dates, date_text)
    requested_count = clamp_schedule_image_day_count(
        day_count,
        len(clean_dates) if MIN_SCHEDULE_IMAGE_DAY_COUNT <= len(clean_dates) <= MAX_SCHEDULE_IMAGE_DAY_COUNT else DEFAULT_SCHEDULE_IMAGE_DAY_COUNT,
    )
    if clean_dates:
        try:
            first_obj = datetime.strptime(clean_dates[0], "%Y-%m-%d")
            clean_dates = [
                (first_obj + timedelta(days=offset)).strftime("%Y-%m-%d")
                for offset in range(requested_count)
            ]
        except Exception:
            clean_dates = clean_dates[:requested_count]
    else:
        clean_dates = work_schedule_operational_dates(0, requested_count)
    return WorkScheduleCanonicalRange(schedule_normalize_mode(mode, "chat_default_week"), tuple(clean_dates), source)


def work_schedule_canonical_range_from_offsets(
    mode: str,
    start_offset_days: Any = 0,
    day_count: Any = DEFAULT_SCHEDULE_IMAGE_DAY_COUNT,
    source: str = "offset_range",
) -> WorkScheduleCanonicalRange:
    start_offset = max(0, safe_int(start_offset_days, 0))
    count = clamp_schedule_image_day_count(day_count)
    dates = work_schedule_operational_dates(start_offset, count)
    return WorkScheduleCanonicalRange(schedule_normalize_mode(mode, "chat_default_week"), tuple(dates), source)


def work_schedule_default_canonical_range(source: str = "default_week") -> WorkScheduleCanonicalRange:
    return work_schedule_canonical_range_from_offsets("chat_default_week", 0, DEFAULT_SCHEDULE_IMAGE_DAY_COUNT, source)


def validate_kst_datetime_text(value: Any) -> tuple[str, int]:
    text = str(value or "").strip()
    if not text:
        raise WorkerError("alert datetime missing")
    dt = parse_kst_datetime(text)
    if dt is None:
        raise WorkerError(f"invalid alert datetime: {text}")
    return dt.strftime("%Y-%m-%d %H:%M"), int(dt.timestamp() * 1000)


def compact_payload(value: Any, limit: int = 4000) -> Any:
    text = json.dumps(value, ensure_ascii=False, separators=(",", ":"))
    if len(text) <= limit:
        return value
    return {"truncated": True, "text": text[:limit]}


def compact_explicit_action_result_payload(value: Any, limit: int = 4000) -> Any:
    if isinstance(value, list):
        return [compact_explicit_action_result_payload(item, limit) for item in value]
    if isinstance(value, dict):
        compacted: dict[str, Any] = {}
        for key, item in value.items():
            if key in {"request_payload", "response_payload", "payload"}:
                compacted[key] = compact_payload(redact_payload_for_audit(item), limit)
            else:
                compacted[key] = compact_explicit_action_result_payload(item, limit)
        return compacted
    return value


def stage_ledger_request_path(req_id: str) -> str:
    return f"{STAGE_LEDGER_PATH}/requests/{sanitize_key(req_id, 'request')}"


def build_stage_record(
    stage: str,
    status: str,
    *,
    ts_ms: int | None = None,
    message: str = "",
    evidence_key: str = "",
    evidence: Any | None = None,
    elapsed_ms: int | None = None,
    retry_count: int | None = None,
    source_component: str = "storebot_codex_worker",
) -> dict[str, Any]:
    stage_name = str(stage or "").strip()
    if stage_name not in SUPERVISOR_STAGE_ORDER:
        raise WorkerError(f"unknown supervisor stage: {stage_name}")
    normalized_status = str(status or "").strip().lower()
    if normalized_status not in SUPERVISOR_STAGE_STATUSES:
        raise WorkerError(f"unknown supervisor stage status: {normalized_status}")
    updated_at = ts_ms or now_ms()
    record: dict[str, Any] = {
        "stage": stage_name,
        "status": normalized_status,
        "ts": updated_at,
        "updated_at": updated_at,
        "updated_at_ms": updated_at,
        "source_component": source_component,
    }
    if message:
        record["message"] = compact_error(message, 500)
    if evidence_key:
        record["evidence_key"] = sanitize_key(evidence_key, stage_name)
    if evidence is not None:
        record["evidence"] = compact_payload(evidence, 4000)
    if elapsed_ms is not None:
        record["elapsed_ms"] = max(0, int(elapsed_ms))
    if retry_count is not None:
        record["retry_count"] = max(0, int(retry_count))
    return record


def record_stage(
    req_id: str,
    item: dict[str, Any] | None,
    args: argparse.Namespace | None,
    stage: str,
    status: str,
    *,
    message: str = "",
    evidence_key: str = "",
    evidence: Any | None = None,
    elapsed_ms: int | None = None,
    retry_count: int | None = None,
    ts_ms: int | None = None,
) -> dict[str, Any]:
    if not req_id or (args is not None and getattr(args, "dry_run", False)):
        return {}
    record = build_stage_record(
        stage,
        status,
        ts_ms=ts_ms,
        message=message,
        evidence_key=evidence_key,
        evidence=evidence,
        elapsed_ms=elapsed_ms,
        retry_count=retry_count,
    )
    item = item if isinstance(item, dict) else {}
    payload: dict[str, Any] = {
        "schema": "storebot_stage_ledger_v1",
        "request_id": req_id,
        "stage_order": list(SUPERVISOR_STAGE_ORDER),
        "updated_at_ms": record["updated_at_ms"],
        "stages": {record["stage"]: record},
    }
    worker = str(getattr(args, "node", "") or "")
    if worker:
        payload["worker"] = worker
    room_id = str(item.get("room_id") or item.get("room") or "")
    room_name = str(item.get("room_name") or item.get("roomTitle") or "")
    if room_id:
        payload["room_id"] = room_id
    if room_name:
        payload["room_name"] = room_name
    event_kind = str(item.get("event_kind") or item.get("kind") or "")
    if event_kind:
        payload["event_kind"] = event_kind
    fb_patch(stage_ledger_request_path(req_id), payload)
    return record


def safe_record_stage(
    req_id: str,
    item: dict[str, Any] | None,
    args: argparse.Namespace | None,
    stage: str,
    status: str,
    **kwargs: Any,
) -> dict[str, Any]:
    try:
        return record_stage(req_id, item, args, stage, status, **kwargs)
    except Exception as exc:
        log(f"stage ledger write failed request={req_id} stage={stage}: {compact_error(str(exc), 180)}")
        return {}


def supervisor_stage_template(req_id: str = "") -> dict[str, Any]:
    return {
        "schema": "storebot_stage_ledger_v1",
        "request_id": req_id,
        "stage_order": list(SUPERVISOR_STAGE_ORDER),
        "stage_path": stage_ledger_request_path(req_id or "REQUEST_ID"),
        "stages": {
            stage: {
                "status": "started|done|error|timeout|skipped",
                "ts": 0,
                "updated_at": 0,
                "message": "",
                "evidence_key": "",
                "elapsed_ms": 0,
                "retry_count": 0,
            }
            for stage in SUPERVISOR_STAGE_ORDER
        },
    }


def detect_stage_timeouts(
    ledger: dict[str, Any],
    *,
    now_ms_value: int | None = None,
    timeouts_ms: dict[str, int] | None = None,
) -> list[dict[str, Any]]:
    now_value = now_ms_value or now_ms()
    stages = ledger.get("stages") if isinstance(ledger, dict) else {}
    if not isinstance(stages, dict):
        stages = {}
    timeout_config = {**SUPERVISOR_STAGE_TIMEOUT_MS, **(timeouts_ms or {})}
    timed_out: list[dict[str, Any]] = []
    previous_stage = ""
    previous_record: dict[str, Any] | None = None
    for stage in SUPERVISOR_STAGE_ORDER:
        raw_record = stages.get(stage)
        record = raw_record if isinstance(raw_record, dict) else {}
        status = str(record.get("status") or "").lower()
        timeout_ms = max(1, int(timeout_config.get(stage, 60 * 1000)))
        if status in SUPERVISOR_TERMINAL_STAGE_STATUSES:
            previous_stage = stage
            previous_record = record
            continue
        if status == "started":
            started_at = normalize_ts_ms(record.get("updated_at_ms") or record.get("updated_at") or record.get("ts") or 0)
            elapsed_ms = now_value - started_at if started_at > 0 else 0
            if elapsed_ms > timeout_ms:
                timed_out.append(
                    {
                        "stage": stage,
                        "status": "timeout",
                        "previous_status": status,
                        "elapsed_ms": elapsed_ms,
                        "timeout_ms": timeout_ms,
                    }
                )
            previous_stage = stage
            previous_record = record
            continue
        if previous_record and str(previous_record.get("status") or "").lower() == "done":
            anchor = normalize_ts_ms(
                previous_record.get("updated_at_ms") or previous_record.get("updated_at") or previous_record.get("ts") or 0
            )
            elapsed_ms = now_value - anchor if anchor > 0 else 0
            if elapsed_ms > timeout_ms:
                timed_out.append(
                    {
                        "stage": stage,
                        "status": "timeout",
                        "previous_stage": previous_stage,
                        "previous_status": "missing",
                        "elapsed_ms": elapsed_ms,
                        "timeout_ms": timeout_ms,
                    }
                )
                break
        previous_stage = stage
        previous_record = record if record else previous_record
    return timed_out


def supervisor_check_stage_ledger(
    req_id: str,
    ledger: dict[str, Any],
    *,
    now_ms_value: int | None = None,
    dry_run: bool = True,
) -> dict[str, Any]:
    timed_out = detect_stage_timeouts(ledger, now_ms_value=now_ms_value)
    return {
        "schema": "storebot_stage_supervisor_report_v1",
        "request_id": req_id,
        "checked_at_ms": now_ms_value or now_ms(),
        "status": "timeout" if timed_out else "ok",
        "timed_out": timed_out,
        "dry_run": dry_run,
        "recovery_action": "report_only" if dry_run else "not_implemented",
    }


def groq_triage_timeout_sec() -> float:
    try:
        return max(1.0, float(os.environ.get("STOREBOT_GROQ_TRIAGE_TIMEOUT_SEC", "8")))
    except (TypeError, ValueError):
        return 8.0


def groq_triage_model() -> tuple[str, str]:
    storebot_model = str(os.environ.get("STOREBOT_GROQ_MODEL") or "").strip()
    if storebot_model:
        return storebot_model, "STOREBOT_GROQ_MODEL"
    groq_model = str(os.environ.get("GROQ_MODEL") or "").strip()
    if groq_model:
        return groq_model, "GROQ_MODEL"
    return DEFAULT_GROQ_TRIAGE_MODEL, "default"


def groq_triage_candidates() -> list[dict[str, str]]:
    if not env_bool("STOREBOT_GROQ_TRIAGE_ENABLED", True):
        return []

    candidates: list[dict[str, str]] = []
    cli = str(os.environ.get("GROQ_CLI") or "").strip()
    if cli:
        candidates.append({"provider": "groq_cli", "mode": "cli", "command": cli, "source": "GROQ_CLI"})
    else:
        detected_cli = shutil.which("groq")
        if detected_cli:
            candidates.append({"provider": "groq_cli", "mode": "cli", "command": detected_cli, "source": "PATH"})

    if str(os.environ.get("GROQ_API_KEY") or "").strip():
        model, source = groq_triage_model()
        candidates.append({"provider": "groq_api", "mode": "api", "model": model, "model_source": source})
    return candidates


def groq_triage_config() -> dict[str, str]:
    if not env_bool("STOREBOT_GROQ_TRIAGE_ENABLED", True):
        return {"provider": "", "reason": "disabled"}
    candidates = groq_triage_candidates()
    if candidates:
        return candidates[0]
    return {"provider": "", "reason": "no_groq_config"}


def groq_triage_response_format(model: str) -> dict[str, Any]:
    if str(model or "").strip() in GROQ_STRICT_JSON_SCHEMA_MODELS:
        return {
            "type": "json_schema",
            "json_schema": {
                "name": "storebot_fast_triage",
                "strict": True,
                "schema": {
                    "type": "object",
                    "properties": {
                        "likely_stage": {"type": "string"},
                        "severity": {"type": "string", "enum": sorted(GROQ_TRIAGE_SEVERITIES)},
                        "summary": {"type": "string"},
                        "codex_task_hint": {"type": "string"},
                    },
                    "required": list(GROQ_TRIAGE_REQUIRED_FIELDS),
                    "additionalProperties": False,
                },
            },
        }
    return {"type": "json_object"}


def build_groq_triage_prompt(context: dict[str, Any]) -> str:
    safe_context = compact_payload(context, 6000)
    return (
        "You are StoreBot fast triage. Do not execute actions. Do not send Kakao messages. "
        "Classify the failure stage and produce a concise recovery summary for a later Codex self-fix request.\n"
        "Return only compact JSON with keys: likely_stage, severity, summary, codex_task_hint. "
        "severity must be one of info, warning, error, critical. No markdown.\n\n"
        f"{json.dumps(safe_context, ensure_ascii=False, indent=2)}\n"
    )


def validate_groq_triage_json(parsed: dict[str, Any] | None) -> tuple[dict[str, str] | None, str]:
    if not isinstance(parsed, dict):
        return None, "invalid_json"
    missing = [field for field in GROQ_TRIAGE_REQUIRED_FIELDS if not str(parsed.get(field) or "").strip()]
    if missing:
        return None, "missing_fields:" + ",".join(missing)
    severity = str(parsed.get("severity") or "").strip().lower()
    if severity not in GROQ_TRIAGE_SEVERITIES:
        return None, "invalid_severity"
    return {
        "likely_stage": compact_error(str(parsed.get("likely_stage") or ""), 160),
        "severity": severity,
        "summary": compact_error(str(parsed.get("summary") or ""), 600),
        "codex_task_hint": compact_error(str(parsed.get("codex_task_hint") or ""), 800),
    }, ""


def groq_triage_result_from_text(
    provider: str,
    output_text: str,
    elapsed_ms: int,
    *,
    model: str = "",
    mode: str = "",
) -> dict[str, Any]:
    parsed = parse_json_object_text(output_text)
    summary, validation_error = validate_groq_triage_json(parsed)
    if validation_error:
        return {
            "status": "error",
            "provider": provider,
            "mode": mode or provider.replace("groq_", ""),
            "model": model,
            "elapsed_ms": elapsed_ms,
            "error": validation_error,
            "raw_preview": compact_error(output_text, 500),
            "raw_len": len(output_text),
        }
    return {
        "status": "ok",
        "provider": provider,
        "mode": mode or provider.replace("groq_", ""),
        "model": model,
        "elapsed_ms": elapsed_ms,
        "summary": summary,
        "raw_len": len(output_text),
    }


def run_groq_cli_triage_candidate(config: dict[str, str], prompt: str, timeout_sec: float) -> dict[str, Any]:
    started = time.perf_counter()
    try:
        command = shlex.split(config["command"])
        extra_args = shlex.split(str(os.environ.get("GROQ_CLI_ARGS") or ""))
        completed = subprocess.run(
            [*command, *extra_args],
            input=prompt,
            text=True,
            capture_output=True,
            timeout=timeout_sec,
            check=False,
        )
        elapsed_ms = int((time.perf_counter() - started) * 1000)
        if completed.returncode != 0:
            return {
                "status": "error",
                "provider": "groq_cli",
                "mode": "cli",
                "elapsed_ms": elapsed_ms,
                "error": compact_error(completed.stderr or completed.stdout, 500),
                "source": config.get("source") or "",
            }
        return groq_triage_result_from_text("groq_cli", completed.stdout, elapsed_ms, mode="cli")
    except Exception as exc:
        elapsed_ms = int((time.perf_counter() - started) * 1000)
        return {
            "status": "error",
            "provider": "groq_cli",
            "mode": "cli",
            "elapsed_ms": elapsed_ms,
            "error": compact_error(str(exc), 500),
            "source": config.get("source") or "",
        }


def run_groq_api_triage_candidate(config: dict[str, str], prompt: str, timeout_sec: float) -> dict[str, Any]:
    started = time.perf_counter()
    model = config["model"]
    try:
        payload = {
            "model": model,
            "messages": [
                {
                    "role": "system",
                    "content": "Return only a JSON object matching the requested triage keys. Do not include markdown.",
                },
                {"role": "user", "content": prompt},
            ],
            "temperature": 0,
            "max_completion_tokens": int(os.environ.get("STOREBOT_GROQ_TRIAGE_MAX_TOKENS", "512")),
            "response_format": groq_triage_response_format(model),
        }
        if model.startswith("openai/gpt-oss"):
            effort = str(os.environ.get("STOREBOT_GROQ_REASONING_EFFORT") or "low").strip().lower()
            if effort not in {"low", "medium", "high"}:
                effort = "low"
            payload["reasoning_effort"] = effort
            payload["reasoning_format"] = "hidden"
        url = str(os.environ.get("GROQ_API_URL") or "https://api.groq.com/openai/v1/chat/completions").strip()
        data = json.dumps(payload, ensure_ascii=False).encode("utf-8")
        req = urllib.request.Request(
            url,
            data=data,
            headers={
                "Authorization": f"Bearer {os.environ.get('GROQ_API_KEY')}",
                "Content-Type": "application/json; charset=utf-8",
            },
            method="POST",
        )
        with urllib.request.urlopen(req, timeout=timeout_sec) as resp:
            body = resp.read().decode("utf-8", errors="replace")
        elapsed_ms = int((time.perf_counter() - started) * 1000)
        parsed_body = json.loads(body)
        choices = parsed_body.get("choices") if isinstance(parsed_body, dict) else []
        content = ""
        if isinstance(choices, list) and choices:
            first = choices[0] if isinstance(choices[0], dict) else {}
            message = first.get("message") if isinstance(first.get("message"), dict) else {}
            content = str(message.get("content") or "").strip()
        if not content:
            content = compact_error(body, 1200)
        return groq_triage_result_from_text("groq_api", content, elapsed_ms, model=model, mode="api")
    except urllib.error.HTTPError as exc:
        elapsed_ms = int((time.perf_counter() - started) * 1000)
        try:
            body = exc.read().decode("utf-8", errors="replace")
        except Exception:
            body = ""
        return {
            "status": "error",
            "provider": "groq_api",
            "mode": "api",
            "model": model,
            "elapsed_ms": elapsed_ms,
            "status_code": int(exc.code),
            "rate_limited": int(exc.code) == 429,
            "error": compact_error(body or str(exc), 500),
        }
    except Exception as exc:
        elapsed_ms = int((time.perf_counter() - started) * 1000)
        return {
            "status": "error",
            "provider": "groq_api",
            "mode": "api",
            "model": model,
            "elapsed_ms": elapsed_ms,
            "error": compact_error(str(exc), 500),
        }


def run_groq_fast_triage(prompt: str) -> dict[str, Any]:
    candidates = groq_triage_candidates()
    if not candidates:
        config = groq_triage_config()
        return {"status": "skipped", "provider": "", "mode": "fallback", "reason": config.get("reason") or "no_groq_config"}

    timeout_sec = groq_triage_timeout_sec()
    attempts: list[dict[str, Any]] = []
    for config in candidates:
        provider = config.get("provider", "")
        if provider == "groq_cli":
            result = run_groq_cli_triage_candidate(config, prompt, timeout_sec)
        elif provider == "groq_api":
            result = run_groq_api_triage_candidate(config, prompt, timeout_sec)
        else:
            continue
        if result.get("status") == "ok":
            if attempts:
                result["fallback_attempts"] = compact_payload(attempts, 1600)
            return result
        attempts.append(compact_payload(result, 1000))

    final = dict(attempts[-1]) if attempts else {"status": "skipped", "provider": "", "mode": "fallback", "reason": "no_groq_config"}
    final["fallback_exhausted"] = True
    final["attempts"] = compact_payload(attempts, 2000)
    return final


def fast_brain_enabled() -> bool:
    return env_bool("STOREBOT_FAST_BRAIN_ENABLED", False)


def thin_bridge_cli_direct_enabled() -> bool:
    return env_bool("STOREBOT_CODEX_THIN_BRIDGE_CLI_DIRECT", True)


def guarded_fast_brain_hot_path_enabled() -> bool:
    return env_bool("STOREBOT_FAST_BRAIN_GUARDED_HOT_PATH", False)


def resident_exec_fallback_enabled() -> bool:
    return env_bool("STOREBOT_CODEX_RESIDENT_FALLBACK_EXEC", False)


def fast_brain_timeout_sec() -> float:
    try:
        return max(1.0, float(os.environ.get("STOREBOT_FAST_BRAIN_TIMEOUT_SEC", "12")))
    except (TypeError, ValueError):
        return 12.0


def fast_brain_max_tokens() -> int:
    try:
        return max(64, int(os.environ.get("STOREBOT_FAST_BRAIN_MAX_TOKENS", "900")))
    except (TypeError, ValueError):
        return 900


def fast_brain_candidates() -> list[dict[str, str]]:
    if not fast_brain_enabled():
        return []
    provider_pref = str(os.environ.get("STOREBOT_FAST_BRAIN_PROVIDER") or "auto").strip().lower()
    candidates: list[dict[str, str]] = []
    if provider_pref in {"auto", "groq"} and str(os.environ.get("GROQ_API_KEY") or "").strip():
        model = str(os.environ.get("STOREBOT_FAST_BRAIN_MODEL") or os.environ.get("STOREBOT_GROQ_MODEL") or DEFAULT_FAST_BRAIN_GROQ_MODEL).strip()
        candidates.append(
            {
                "provider": "groq_api",
                "mode": "api",
                "model": model,
                "model_source": "STOREBOT_FAST_BRAIN_MODEL/GROQ",
                "url": str(os.environ.get("GROQ_API_URL") or "https://api.groq.com/openai/v1/chat/completions").strip(),
                "key_env": "GROQ_API_KEY",
            }
        )
    if provider_pref in {"auto", "openai"} and str(os.environ.get("OPENAI_API_KEY") or "").strip():
        model = str(os.environ.get("STOREBOT_FAST_BRAIN_MODEL") or os.environ.get("OPENAI_MODEL") or DEFAULT_FAST_BRAIN_OPENAI_MODEL).strip()
        candidates.append(
            {
                "provider": "openai_api",
                "mode": "api",
                "model": model,
                "model_source": "STOREBOT_FAST_BRAIN_MODEL/OPENAI",
                "url": str(os.environ.get("OPENAI_API_URL") or "https://api.openai.com/v1/chat/completions").strip(),
                "key_env": "OPENAI_API_KEY",
            }
        )
    if provider_pref == "openai":
        candidates.sort(key=lambda item: 0 if item.get("provider") == "openai_api" else 1)
    return candidates


FAST_BRAIN_SECRET_ALLOWED_KEY_NAMES = [
    "GROQ_API_KEY",
    "OPENAI_API_KEY",
    "STOREBOT_FAST_BRAIN_PROVIDER",
    "STOREBOT_FAST_BRAIN_MODEL",
    "STOREBOT_FAST_BRAIN_TIMEOUT_SEC",
    "STOREBOT_FAST_BRAIN_MAX_TOKENS",
    "STOREBOT_FAST_BRAIN_REASONING_EFFORT",
    "STOREBOT_GROQ_MODEL",
    "GROQ_MODEL",
    "OPENAI_MODEL",
    "STOREBOT_GROQ_REASONING_EFFORT",
]


def fast_brain_secret_status() -> dict[str, Any]:
    loaded = env_bool("STOREBOT_FAST_BRAIN_SECRET_LOADED", False)
    keys_raw = str(os.environ.get("STOREBOT_FAST_BRAIN_SECRET_KEYS") or "")
    keys = [key.strip() for key in keys_raw.split(",") if key.strip()]
    reason = str(os.environ.get("STOREBOT_FAST_BRAIN_SECRET_REASON") or "").strip()
    if reason == "no_local_secret_file":
        reason = "no_secret_file"
    elif reason == "no_allowed_keys_in_secret_file":
        reason = "no_allowed_key_loaded"
    source_env = str(os.environ.get("STOREBOT_FAST_BRAIN_SECRET_SOURCE") or "").strip()
    if loaded:
        secret_status = "loaded"
        secret_source = "local_file"
    elif source_env:
        secret_status = "present_no_allowed_key" if reason == "no_allowed_key_loaded" else "error"
        secret_source = "local_file"
    else:
        secret_status = "missing"
        secret_source = ""
        if not reason:
            reason = "no_secret_file"
    status: dict[str, Any] = {
        "secret_loaded": loaded,
        "secret_source": secret_source,
        "secret_status": secret_status,
        "secret_reason": reason,
        "secret_keys": keys,
        "secret_allowed_key_names": list(FAST_BRAIN_SECRET_ALLOWED_KEY_NAMES),
    }
    mode_warning = str(os.environ.get("STOREBOT_FAST_BRAIN_SECRET_MODE_WARNING") or "").strip()
    if mode_warning:
        status["secret_mode_warning"] = mode_warning
    ignored_count_raw = str(os.environ.get("STOREBOT_FAST_BRAIN_SECRET_IGNORED_COUNT") or "").strip()
    try:
        ignored_count = int(ignored_count_raw or "0")
    except ValueError:
        ignored_count = 0
    if ignored_count:
        status["secret_ignored_count"] = ignored_count
    return status


def fast_brain_config_status() -> dict[str, Any]:
    secret_status = fast_brain_secret_status()
    if not fast_brain_enabled():
        return {"enabled": False, "reason": "disabled", **secret_status}
    candidates = fast_brain_candidates()
    if not candidates:
        reason = str(secret_status.get("secret_reason") or "no_fast_brain_api_key")
        if reason in {"no_local_secret_file", "no_secret_file"}:
            reason = "no_fast_brain_api_key"
        return {"enabled": True, "configured": False, "reason": reason, **secret_status}
    first = candidates[0]
    return {
        "enabled": True,
        "configured": True,
        "provider": first.get("provider") or "",
        "model": first.get("model") or "",
        "model_source": first.get("model_source") or "",
        "timeout_sec": fast_brain_timeout_sec(),
        **secret_status,
    }


def fast_brain_secret_mirrors(status: dict[str, Any] | None = None) -> dict[str, Any]:
    if status is None:
        status = fast_brain_config_status()
    return {
        "fast_brain_secret_loaded": bool(status.get("secret_loaded")),
        "fast_brain_secret_source": str(status.get("secret_source") or ""),
        "fast_brain_secret_status": str(status.get("secret_status") or ""),
        "fast_brain_secret_reason": str(status.get("secret_reason") or ""),
        "fast_brain_secret_allowed_key_names": list(status.get("secret_allowed_key_names") or []),
        "fast_brain_secret_key_names": list(status.get("secret_keys") or []),
        "fast_brain_secret_mode_warning": str(status.get("secret_mode_warning") or ""),
    }


def fast_brain_should_escalate(item: dict[str, Any], route_metadata: dict[str, Any] | None) -> str:
    if not guarded_fast_brain_hot_path_enabled():
        return "guarded_fast_brain_hot_path_disabled"
    if not fast_brain_enabled():
        return "fast_brain_disabled"
    if not fast_brain_candidates():
        return "no_fast_brain_api_key"
    if wants_escalated_model(item):
        return "user_requested_escalation"
    event_kind = str(item.get("event_kind") or item.get("kind") or "chat").strip() or "chat"
    if event_kind not in {"chat", "chat_replay", "probe", "contract_probe", "diagnostic"}:
        return f"non_chat_event:{event_kind}"
    if route_needs_review(route_metadata):
        return "route_needs_review"
    text = request_text_for_model_policy(item)
    if len(text) > int(os.environ.get("STOREBOT_FAST_BRAIN_MAX_INPUT_CHARS", "2200")):
        return "input_too_large_for_fast_brain"
    lowered = normalize_key_text(text)
    markers = (
        "위험",
        "삭제",
        "초기화",
        "정산",
        "결제",
        "환불",
        "송금",
        "장기분석",
        "전체분석",
    )
    if any(marker in lowered for marker in markers):
        return "risk_or_long_analysis_marker"
    return ""


def build_fast_brain_compact_context(req_id: str, item: dict[str, Any], room_id: str, room_name: str) -> dict[str, Any]:
    room_key = sanitize_key(room_id or room_name, "storebot_group")
    recent_text = build_recent_room_context(room_id, room_name, limit=6, max_chars=1800)
    previous_turn_context = str(item.get("_previous_turn_context") or "").strip()
    briefing_state: dict[str, Any] = {}
    try:
        room_path = briefing_channel_dir() / "rooms" / f"{briefing_channel_room_id_from_item(item)}.json"
        raw_room = read_json_file(room_path)
        if isinstance(raw_room, dict):
            briefing_state = {
                "processing_status": str(raw_room.get("processing_status") or ""),
                "last_message_preview": briefing_channel_preview(raw_room.get("last_message_preview") or raw_room.get("last_message") or "", 180),
                "last_outbound_category": str(raw_room.get("last_outbound_category") or ""),
                "last_ai_response_preview": briefing_channel_preview(raw_room.get("last_ai_response") or "", 180),
            }
    except Exception:
        briefing_state = {}
    context = {
        "schema": "storebot_backplane_compact_v1",
        "request_id": req_id,
        "room_id": room_id,
        "room_key": room_key,
        "source": "storebot_backplane_compact",
        "recent_room_context": recent_text[:1800],
        "previous_turn_context": previous_turn_context[:1200],
        "briefing_channel_state": briefing_state,
        "current_event": {
            "event_kind": str(item.get("event_kind") or item.get("kind") or "chat"),
            "sender": redact_room_text_preview(item.get("sender") or item.get("from") or "", 60),
            "message_preview": redact_room_text_preview(room_event_text(item), 240),
        },
    }
    context["context_hash"] = context_bundle_v1_hash(context)
    return compact_payload(context, 3600)


def build_fast_brain_messages(
    req_id: str,
    item: dict[str, Any],
    room_id: str,
    room_name: str,
    router_guide: str,
    compact_context: dict[str, Any],
    *,
    action_results: list[dict[str, Any]] | None = None,
    action_request: dict[str, Any] | None = None,
) -> list[dict[str, str]]:
    if action_results is None:
        turn = build_fast_router_turn_prompt(item, room_id, room_name)
    else:
        turn = build_action_result_prompt(item, room_id, room_name, action_request or {}, action_results)
    system = (
        "You are StoreBot fast brain for one Kakao room. The StoreBotTermux backplane supplies compact context; "
        "you must not ask for giant prompt dumps or hidden session memory. Output only one allowed StoreBot reply form. "
        "Allowed outputs: SKIP, ROUTE_FULL, final short Kakao text, STOREBOT_ACTIONS plus one JSON object, or STOREBOT_OUTPUT plus one JSON object. "
        "Use STOREBOT_ACTIONS for DB/search/tool needs. Use ROUTE_FULL for high ambiguity, risky side effects, missing context, or long analysis. "
        "Never claim a write succeeded before action_results say ok:true. No markdown explanations."
    )
    user = (
        "## Fast Router Contract\n"
        f"{router_guide[:6500]}\n\n"
        "## Compact StoreBot Backplane Context\n"
        f"{json.dumps(compact_context, ensure_ascii=False, separators=(',', ':'))}\n\n"
        "## Current Turn\n"
        f"{turn}\n"
    )
    return [{"role": "system", "content": system}, {"role": "user", "content": user}]


def extract_chat_completion_text(body: str) -> str:
    parsed_body = json.loads(body)
    choices = parsed_body.get("choices") if isinstance(parsed_body, dict) else []
    if isinstance(choices, list) and choices:
        first = choices[0] if isinstance(choices[0], dict) else {}
        message = first.get("message") if isinstance(first.get("message"), dict) else {}
        content = message.get("content")
        if isinstance(content, str):
            return content.strip()
        if isinstance(content, list):
            parts: list[str] = []
            for part in content:
                if isinstance(part, dict) and str(part.get("type") or "") in {"text", "output_text"}:
                    parts.append(str(part.get("text") or ""))
            return "\n".join(parts).strip()
    return ""


def run_fast_brain_api_candidate(
    config: dict[str, str],
    messages: list[dict[str, str]],
    timeout_sec: float,
) -> dict[str, Any]:
    started = time.perf_counter()
    model = str(config.get("model") or "")
    try:
        payload: dict[str, Any] = {
            "model": model,
            "messages": messages,
            "temperature": 0,
            "max_completion_tokens": fast_brain_max_tokens(),
        }
        if model.startswith("openai/gpt-oss"):
            effort = str(os.environ.get("STOREBOT_FAST_BRAIN_REASONING_EFFORT") or os.environ.get("STOREBOT_GROQ_REASONING_EFFORT") or "low").strip().lower()
            if effort not in {"low", "medium", "high"}:
                effort = "low"
            payload["reasoning_effort"] = effort
            payload["reasoning_format"] = "hidden"
        data = json.dumps(payload, ensure_ascii=False).encode("utf-8")
        key_env = str(config.get("key_env") or "")
        req = urllib.request.Request(
            str(config.get("url") or ""),
            data=data,
            headers={
                "Authorization": f"Bearer {os.environ.get(key_env)}",
                "Content-Type": "application/json; charset=utf-8",
            },
            method="POST",
        )
        with urllib.request.urlopen(req, timeout=timeout_sec) as resp:
            body = resp.read().decode("utf-8", errors="replace")
        elapsed_ms = int((time.perf_counter() - started) * 1000)
        text = extract_chat_completion_text(body)
        if not text:
            return {
                "status": "error",
                "provider": config.get("provider") or "",
                "model": model,
                "elapsed_ms": elapsed_ms,
                "error": "empty_fast_brain_response",
                "raw_preview": compact_error(body, 500),
            }
        return {
            "status": "ok",
            "provider": config.get("provider") or "",
            "model": model,
            "elapsed_ms": elapsed_ms,
            "text": text,
        }
    except urllib.error.HTTPError as exc:
        elapsed_ms = int((time.perf_counter() - started) * 1000)
        try:
            body = exc.read().decode("utf-8", errors="replace")
        except Exception:
            body = ""
        return {
            "status": "error",
            "provider": config.get("provider") or "",
            "model": model,
            "elapsed_ms": elapsed_ms,
            "status_code": int(exc.code),
            "rate_limited": int(exc.code) == 429,
            "error": compact_error(body or str(exc), 500),
        }
    except Exception as exc:
        elapsed_ms = int((time.perf_counter() - started) * 1000)
        return {
            "status": "error",
            "provider": config.get("provider") or "",
            "model": model,
            "elapsed_ms": elapsed_ms,
            "error": compact_error(str(exc), 500),
        }


def run_fast_brain_api_messages(
    req_id: str,
    messages: list[dict[str, str]],
    compact_context: dict[str, Any],
    context_build_ms: int,
) -> CodexResult:
    candidates = fast_brain_candidates()
    if not candidates:
        raise FastRouterFullFallback("no fast brain API key configured")
    attempts: list[dict[str, Any]] = []
    for config in candidates:
        submit_started = time.perf_counter()
        result = run_fast_brain_api_candidate(config, messages, fast_brain_timeout_sec())
        api_wait_ms = int(result.get("elapsed_ms") or int((time.perf_counter() - submit_started) * 1000))
        if result.get("status") == "ok":
            model = str(result.get("model") or config.get("model") or "")
            provider = str(result.get("provider") or config.get("provider") or "")
            metadata = compact_timing_metadata(
                {
                    "api_submit_ms": 0,
                    "api_wait_ms": api_wait_ms,
                    "context_build_ms": context_build_ms,
                    "clean_extract_ms": 0,
                    "publish_gate_ms": 0,
                    "total_ms": context_build_ms + api_wait_ms,
                    "bottleneck_stage": "api_wait_ms",
                }
            )
            metadata.update(
                {
                    "api_submit_ms": 0,
                    "api_wait_ms": api_wait_ms,
                    "context_build_ms": context_build_ms,
                    "brain_route": "fast_api",
                    "reply_source": "fast_model",
                    "fallback_used": False,
                    "escalation_used": False,
                    "worker_role": "guarded_side_path",
                    "cli_direct": False,
                    "resident_required": False,
                    "fast_brain_hot_path": True,
                    "fast_brain_provider": provider,
                    "fast_brain_model": model,
                    "fast_brain_policy": "guarded_opt_in_side_path_not_default",
                    "context_source": "storebot_backplane_compact",
                    "context_hash": str(compact_context.get("context_hash") or ""),
                }
            )
            if attempts:
                metadata["fast_brain_attempts"] = compact_payload(attempts, 1200)
            return CodexResult(
                final=str(result.get("text") or "").strip(),
                thread_id=f"fast_api:{provider}:{model}",
                metadata=metadata,
            )
        attempts.append(compact_payload(result, 900))
    error = str((attempts[-1] if attempts else {}).get("error") or "fast brain API failed")
    raise FastRouterFullFallback(f"fast brain API failed: {error}")


def run_fast_brain_api_turn(
    req_id: str,
    item: dict[str, Any],
    room_id: str,
    room_name: str,
    router_guide: str,
    *,
    action_results: list[dict[str, Any]] | None = None,
    action_request: dict[str, Any] | None = None,
) -> CodexResult:
    context_started = time.perf_counter()
    compact_context = build_fast_brain_compact_context(req_id, item, room_id, room_name)
    context_build_ms = int((time.perf_counter() - context_started) * 1000)
    messages = build_fast_brain_messages(
        req_id,
        item,
        room_id,
        room_name,
        router_guide,
        compact_context,
        action_results=action_results,
        action_request=action_request,
    )
    return run_fast_brain_api_messages(req_id, messages, compact_context, context_build_ms)


def run_fast_brain_api_prompt(
    req_id: str,
    item: dict[str, Any],
    room_id: str,
    room_name: str,
    router_guide: str,
    prompt_body: str,
) -> CodexResult:
    context_started = time.perf_counter()
    compact_context = build_fast_brain_compact_context(req_id, item, room_id, room_name)
    context_build_ms = int((time.perf_counter() - context_started) * 1000)
    messages = [
        {
            "role": "system",
            "content": (
                "You are StoreBot fast brain follow-up. Use only the provided compact backplane context and prompt. "
                "Output one allowed StoreBot form only. Use ROUTE_FULL if the follow-up is risky or ambiguous."
            ),
        },
        {
            "role": "user",
            "content": (
                "## Fast Router Contract\n"
                f"{router_guide[:6500]}\n\n"
                "## Compact StoreBot Backplane Context\n"
                f"{json.dumps(compact_context, ensure_ascii=False, separators=(',', ':'))}\n\n"
                "## Follow-up Prompt\n"
                f"{prompt_body}\n"
            ),
        },
    ]
    return run_fast_brain_api_messages(req_id, messages, compact_context, context_build_ms)


def build_storebot_groq_triage(
    *,
    candidate_type: str,
    severity: str,
    request_id: str,
    item: dict[str, Any] | None,
    evidence: dict[str, Any],
    task: str = "",
) -> dict[str, Any]:
    item = item if isinstance(item, dict) else {}
    if item.get("local_direct") is True:
        return {"status": "skipped", "provider": "", "reason": "local_direct_hot_path_disabled"}
    context = {
        "candidate_type": candidate_type,
        "severity": severity,
        "request_id": request_id,
        "event_kind": str(item.get("event_kind") or item.get("kind") or evidence.get("event_kind") or ""),
        "source": str(item.get("source") or evidence.get("source") or ""),
        "room_id": str(item.get("room_id") or item.get("room") or evidence.get("room_id") or ""),
        "message_preview": compact_error(str(item.get("message") or item.get("text") or ""), 400),
        "task": compact_error(task, 1000),
        "evidence": compact_payload(evidence, 5000),
    }
    return run_groq_fast_triage(build_groq_triage_prompt(context))


def groq_triage_task_block(triage: dict[str, Any]) -> str:
    if not isinstance(triage, dict) or triage.get("status") != "ok":
        return ""
    return "## Groq fast triage\n" + json.dumps(compact_payload(triage, 3000), ensure_ascii=False, indent=2) + "\n\n"


def redact_payload_for_audit(value: Any) -> Any:
    if isinstance(value, list):
        return [redact_payload_for_audit(item) for item in value]
    if isinstance(value, dict):
        redacted: dict[str, Any] = {}
        for key, item in value.items():
            if str(key).lower() in {"raw_text", "raw_hex", "receipt_raw"}:
                text = str(item or "")
                redacted[key] = {"redacted": True, "length": len(text), "sha256": hashlib.sha256(text.encode("utf-8")).hexdigest()[:16]}
            else:
                redacted[str(key)] = redact_payload_for_audit(item)
        return redacted
    return value


def parse_kst_datetime(value: Any) -> datetime | None:
    text = str(value or "").strip()
    if not text:
        return None
    try:
        iso_text = text.replace("Z", "+00:00")
        dt = datetime.fromisoformat(iso_text)
        if dt.tzinfo is None:
            dt = dt.replace(tzinfo=KST)
        return dt.astimezone(KST)
    except ValueError:
        pass
    for fmt in ("%Y-%m-%d %H:%M:%S", "%Y-%m-%d %H:%M", "%Y-%m-%dT%H:%M:%S", "%Y-%m-%dT%H:%M"):
        try:
            return datetime.strptime(text[:19], fmt).replace(tzinfo=KST)
        except ValueError:
            continue
    if re.fullmatch(r"\d{10,13}(?:\.\d+)?", text):
        try:
            return datetime.fromtimestamp(normalize_ts_ms(text) / 1000, KST)
        except Exception:
            return None
    return None


def compact_text(value: Any, limit: int = 80) -> str:
    text = re.sub(r"\s+", " ", str(value or "").strip())
    return text[:limit]


def compact_address(value: Any, limit: int = 36) -> str:
    return compact_text(value, limit)


def safe_int(value: Any, default: int = 0) -> int:
    try:
        return int(float(value))
    except (TypeError, ValueError):
        return default


def truthy(value: Any) -> bool:
    if isinstance(value, bool):
        return value
    if isinstance(value, (int, float)):
        return value != 0
    text = str(value or "").strip().lower()
    return text in {"1", "true", "yes", "y", "on", "create", "allow"}


def request_payload(item: dict[str, Any]) -> dict[str, Any]:
    payload = item.get("payload") if isinstance(item, dict) else {}
    return payload if isinstance(payload, dict) else {}


def request_field(item: dict[str, Any], key: str) -> Any:
    if isinstance(item, dict) and key in item:
        return item.get(key)
    return request_payload(item).get(key)


def hynixops_request_source(item: dict[str, Any]) -> bool:
    source = str(request_field(item, "source") or "").strip().lower()
    input_channel = str(request_field(item, "input_channel") or "").strip().lower()
    schema = str(request_field(item, "schema") or "").strip().lower()
    return (
        source == "hynixops_web_chat"
        or (input_channel == "hynixops" and schema == "hynixops_storebot_request_v1")
        or (source.startswith("hynixops_") and input_channel == "hynixops")
    )


def request_action_dry_run_required(item: dict[str, Any]) -> bool:
    if not hynixops_request_source(item):
        return False
    mode = str(request_field(item, "safety_action_mode") or "").strip().lower()
    return (
        truthy(request_field(item, "dry_run"))
        or truthy(request_field(item, "no_send"))
        or truthy(request_field(item, "test_safe"))
        or mode in {"dry_run_only", "test_no_send", "no_write"}
    )


def request_side_effect_safety(item: dict[str, Any]) -> dict[str, Any]:
    if not request_action_dry_run_required(item):
        return {}
    return {
        "hynixops_test_safe": True,
        "hynixops_dry_run_only": True,
        "dry_run_enforced": True,
        "request_dry_run_enforced": True,
        "no_send_enforced": True,
        "publish_disabled": True,
        "side_effects_disabled": True,
        "mcp_write_tools_disabled": True,
        "storebot_action_execution": "dry_run_only",
        "safety_action_mode": "dry_run_only",
    }


def request_publish_disabled(args: argparse.Namespace, item: dict[str, Any]) -> bool:
    return bool(args.no_publish or item.get("no_publish") is True or request_action_dry_run_required(item))


def request_learning_suppression_context(args: argparse.Namespace, item: dict[str, Any]) -> dict[str, Any]:
    reply_target = request_field(item, "reply_target")
    kakao_publish_disabled = isinstance(reply_target, dict) and reply_target.get("kakao_publish") is False
    probe = (
        truthy(request_field(item, "probe"))
        or truthy(request_field(item, "contract_probe"))
        or truthy(request_field(item, "dry_run_probe"))
    )
    disabled = bool(
        truthy(request_field(item, "learning_disabled"))
        or truthy(request_field(item, "no_send"))
        or truthy(request_field(item, "no_publish"))
        or truthy(request_field(item, "publish_disabled"))
        or kakao_publish_disabled
        or probe
        or request_action_dry_run_required(item)
        or getattr(args, "no_publish", False)
        or getattr(args, "dry_run", False)
    )
    if not disabled:
        return {}
    reasons: list[str] = []
    for key in ("learning_disabled", "no_send", "no_publish", "publish_disabled"):
        if truthy(request_field(item, key)):
            reasons.append(key)
    if kakao_publish_disabled:
        reasons.append("reply_target.kakao_publish=false")
    if probe:
        reasons.append("probe")
    if request_action_dry_run_required(item):
        reasons.append("request_dry_run_required")
    if getattr(args, "no_publish", False):
        reasons.append("args.no_publish")
    if getattr(args, "dry_run", False):
        reasons.append("args.dry_run")
    return {
        "learning_suppressed": True,
        "learning_disabled": True,
        "learning_write_skipped_reason": "no_send_probe",
        "learning_suppression_reasons": sorted(set(reasons))[:10],
    }


def request_no_send_contract_probe(item: dict[str, Any]) -> bool:
    reply_target = request_field(item, "reply_target")
    kakao_publish_disabled = isinstance(reply_target, dict) and reply_target.get("kakao_publish") is False
    explicit_probe = (
        truthy(request_field(item, "probe"))
        or truthy(request_field(item, "contract_probe"))
        or truthy(request_field(item, "dry_run_probe"))
        or truthy(request_field(item, "resident_probe"))
    )
    no_send = (
        truthy(request_field(item, "no_send"))
        or truthy(request_field(item, "no_publish"))
        or truthy(request_field(item, "publish_disabled"))
        or kakao_publish_disabled
    )
    event_kind = str(item.get("event_kind") or item.get("kind") or "chat").strip()
    if event_kind not in {"chat", "chat_replay", "probe", "contract_probe", "diagnostic"}:
        return False
    return bool(explicit_probe and no_send)


def timing_bottleneck_stage(timing: dict[str, Any]) -> str:
    candidates = {
        key: safe_int(timing.get(key))
        for key in (
            "context_build_ms",
            "api_submit_ms",
            "api_wait_ms",
            "resident_submit_ms",
            "resident_wait_ms",
            "clean_extract_ms",
            "publish_gate_ms",
        )
    }
    if not candidates:
        return ""
    return max(candidates.items(), key=lambda item: item[1])[0]


def compact_timing_metadata(timing: dict[str, Any]) -> dict[str, Any]:
    fields = {
        "context_build_ms": safe_int(timing.get("context_build_ms")),
        "api_submit_ms": safe_int(timing.get("api_submit_ms")),
        "api_wait_ms": safe_int(timing.get("api_wait_ms")),
        "resident_submit_ms": safe_int(timing.get("resident_submit_ms")),
        "resident_wait_ms": safe_int(timing.get("resident_wait_ms")),
        "clean_extract_ms": safe_int(timing.get("clean_extract_ms")),
        "publish_gate_ms": safe_int(timing.get("publish_gate_ms")),
        "total_ms": safe_int(timing.get("total_ms")),
    }
    fields["bottleneck_stage"] = str(timing.get("bottleneck_stage") or timing_bottleneck_stage(fields))
    return fields


def attach_timing_metadata(payload: dict[str, Any], timing: dict[str, Any] | None) -> dict[str, Any]:
    if not isinstance(timing, dict) or not timing:
        return payload
    payload.update(compact_timing_metadata(timing))
    return payload


def apply_request_side_effect_safety(payload: dict[str, Any], item: dict[str, Any]) -> dict[str, Any]:
    payload.update(request_side_effect_safety(item))
    return payload


STOREBOT_WRITE_ACTION_TYPES = {
    "operation_knowledge.ingest",
    "operation_knowledge.upsert",
    "operation_knowledge.upsert_summary",
    "operation_knowledge.upsert_output",
    "operation_knowledge.upsert_output_variant",
    "operation_knowledge.render_output",
    "operation_knowledge.delete_request",
    "operation_knowledge.request_delete",
    "operation_knowledge.delete",
    "operation_knowledge.restore",
    "operation_knowledge.send_reply",
    "ops_knowledge.ingest",
    "ops_knowledge.upsert_summary",
    "ops_knowledge.request_delete",
    "employee.add_alias",
    "employee.alias",
    "staff.add_alias",
    "staff.alias",
    "schedule.upsert",
    "schedule.upsert_shift",
    "schedule.set_shift",
    "work_schedule.upsert",
    "schedule.off",
    "work_schedule.off",
    "schedule.clear",
    "work_schedule.clear",
    "attendance.record",
    "attendance.set",
    "attendance.check",
    "alert.schedule",
    "temp_alert.schedule",
    "reminder.schedule",
    "alert.cancel",
    "temp_alert.cancel",
    "reminder.cancel",
    "guidance.add_rule",
    "md.guidance.add_rule",
    "memory.guidance.add_rule",
}

STOREBOT_CACHE_WRITE_ACTION_TYPES = {
    "news.search",
    "search.news",
    "sports.search",
    "search.sports",
    "web.search",
    "search.web",
}

STOREBOT_LOCAL_DIRECT_PROBE_ACTION_TYPES = {
    "storebot_local_direct_probe",
    "storebot.local_direct_probe",
}
STOREBOT_EXPLICIT_LOCAL_DIRECT_ACTION_FIELDS = ("storebot_actions", "explicit_actions", "actions")
STOREBOT_LOCAL_DIRECT_PROBE_ENDPOINT = "http://127.0.0.1:8765/storebot/request"
STOREBOT_LOCAL_DIRECT_PROBE_ALLOWED_HOSTS = {"127.0.0.1", "localhost", "::1"}


def action_type_name(action: dict[str, Any]) -> str:
    return str(action.get("type") or action.get("action") or "").strip().lower()


def enforce_dry_run_only_action(action: dict[str, Any], *, enforced: bool) -> dict[str, Any]:
    if not enforced:
        return action
    safe_action = dict(action)
    action_type = action_type_name(safe_action)
    if action_type in STOREBOT_WRITE_ACTION_TYPES or action_type in STOREBOT_CACHE_WRITE_ACTION_TYPES:
        safe_action["dry_run"] = True
    safe_action["dry_run_enforced"] = True
    safe_action["request_dry_run_enforced"] = True
    safe_action["side_effects_disabled"] = True
    safe_action["dry_run_only"] = True
    return safe_action


def enforce_request_action_dry_run(item: dict[str, Any], action: dict[str, Any]) -> dict[str, Any]:
    return enforce_dry_run_only_action(action, enforced=request_action_dry_run_required(item))


def safety_result_flags_from_action(action: dict[str, Any]) -> dict[str, Any]:
    if action.get("dry_run_enforced") is not True and action.get("request_dry_run_enforced") is not True:
        return {}
    return {
        "dry_run_enforced": True,
        "request_dry_run_enforced": True,
        "side_effects_disabled": True,
        "dry_run_only": True,
    }


def mcp_context_for_request(item: dict[str, Any]) -> dict[str, Any]:
    flags = request_side_effect_safety(item)
    if not flags:
        return {}
    return {
        **flags,
        "source": str(request_field(item, "source") or ""),
        "input_channel": str(request_field(item, "input_channel") or ""),
        "schema": str(request_field(item, "schema") or ""),
    }


_MCP_REQUEST_CONTEXT: dict[str, Any] = {}


def parse_mcp_context(value: str) -> dict[str, Any]:
    text = str(value or "").strip()
    if not text:
        return {}
    try:
        parsed = json.loads(text)
    except json.JSONDecodeError:
        return {}
    return parsed if isinstance(parsed, dict) else {}


def set_mcp_request_context(context: dict[str, Any]) -> None:
    _MCP_REQUEST_CONTEXT.clear()
    if isinstance(context, dict):
        _MCP_REQUEST_CONTEXT.update(context)


def mcp_request_context() -> dict[str, Any]:
    if _MCP_REQUEST_CONTEXT:
        return dict(_MCP_REQUEST_CONTEXT)
    return parse_mcp_context(os.environ.get("STOREBOT_MCP_REQUEST_CONTEXT_JSON", ""))


def mcp_side_effects_disabled(context: dict[str, Any] | None = None) -> bool:
    context = context if isinstance(context, dict) else mcp_request_context()
    return bool(
        truthy(context.get("side_effects_disabled"))
        or truthy(context.get("dry_run_only"))
        or truthy(context.get("dry_run_enforced"))
    )


def enforce_mcp_request_context(action: dict[str, Any]) -> dict[str, Any]:
    return enforce_dry_run_only_action(action, enforced=mcp_side_effects_disabled())


def annotate_mcp_result(result: dict[str, Any], action: dict[str, Any]) -> dict[str, Any]:
    result.update(safety_result_flags_from_action(action))
    if result.get("side_effects_disabled") is True:
        result.setdefault("mcp_write_tools_disabled", True)
    return result


ALLOWED_FIREBASE_GET_PREFIXES = (
    f"{WORKSCHEDULE_V2_PATH}/meta",
    f"{WORKSCHEDULE_V2_PATH}/employees",
    f"{WORKSCHEDULE_V2_PATH}/aliases",
    f"{WORKSCHEDULE_V2_PATH}/overrides",
    f"{WORKSCHEDULE_V2_PATH}/fixed_schedules",
    f"{WORKSCHEDULE_V2_PATH}/status",
    f"{WORKSCHEDULE_V2_PATH}/attendance",
    f"{WORKSCHEDULE_V2_PATH}/side_job_references",
    "/packhelper/storebot_summary",
    "/packhelper/storebot_codex/heartbeat",
    "/packhelper/storebot_codex/self_sync",
    "/packhelper/storebot_codex/dynamic_guidance",
    "/packhelper/storebot_codex/learning_stamp",
    "/packhelper/ai_learning/storebot/codex_stamps",
    "/packhelper/rules_hub/StoreBot",
    OPS_MANUAL_ENTRIES_PATH,
    OPS_MANUAL_READ_MODEL_SEARCH_PATH,
)
FORBIDDEN_FIREBASE_GET_PATHS = (
    "/packhelper/storebot_summary/schedule",
    "/packhelper/storebot_summary/weather",
    "/packhelper/storebot_summary/news",
)
NON_AUTHORITATIVE_STOREBOT_SUMMARY_KEYS = ("schedule", "weather", "news")


def clean_firebase_path(path: Any) -> str:
    raw = "/" + str(path or "").strip().strip("/")
    if raw == "/" or ".." in raw or "/secrets" in raw.lower():
        raise WorkerError(f"firebase path not allowed: {raw}")
    if any(raw == path or raw.startswith(path + "/") for path in FORBIDDEN_FIREBASE_GET_PATHS):
        raise WorkerError(f"firebase get path not allowed: {raw}")
    if not any(raw == prefix or raw.startswith(prefix + "/") for prefix in ALLOWED_FIREBASE_GET_PREFIXES):
        raise WorkerError(f"firebase get path not allowed: {raw}")
    return raw


def sanitize_firebase_get_payload(path: str, data: Any) -> Any:
    if path != "/packhelper/storebot_summary" or not isinstance(data, dict):
        return data
    sanitized = dict(data)
    removed = [key for key in NON_AUTHORITATIVE_STOREBOT_SUMMARY_KEYS if key in sanitized]
    for key in removed:
        sanitized.pop(key, None)
    if removed:
        sanitized["_source_output_policy"] = {
            "removed_non_authoritative_cache_keys": removed,
            "realtime_required": ["weather.forecast", "news.search"],
            "schedule_source": WORKSCHEDULE_V2_PATH,
        }
    return sanitized


def ops_manual_collection_items(data: Any, id_field: str) -> list[dict[str, Any]]:
    if data is None:
        return []
    if isinstance(data, list):
        return [item for item in data if isinstance(item, dict)]
    if isinstance(data, dict):
        result: list[dict[str, Any]] = []
        for key, value in data.items():
            if not isinstance(value, dict):
                continue
            item = dict(value)
            item.setdefault(id_field, key)
            item.setdefault("id", key)
            result.append(item)
        return result
    return []


def ops_manual_search_blob(item: dict[str, Any]) -> str:
    parts: list[str] = []
    for key in ("category", "title", "summary", "body", "text", "search_text"):
        parts.append(str(item.get(key) or ""))
    for key in ("tags", "actions", "cautions", "tokens"):
        value = item.get(key)
        if isinstance(value, list):
            parts.extend(str(part) for part in value)
    return compact_text(" ".join(parts), 5000).casefold()


def ops_manual_candidate_evidence_ids(candidate: dict[str, Any]) -> list[str]:
    raw_payload = candidate.get("raw_payload") if isinstance(candidate.get("raw_payload"), dict) else {}
    collect = raw_payload.get("collect") if isinstance(raw_payload.get("collect"), dict) else {}
    storebot_output = (
        raw_payload.get("storebot_output") if isinstance(raw_payload.get("storebot_output"), dict) else {}
    )
    output_collect = (
        storebot_output.get("ops_manual_collect")
        if isinstance(storebot_output.get("ops_manual_collect"), dict)
        else {}
    )
    raw_ids = (
        candidate.get("evidence_request_ids")
        or collect.get("evidence_request_ids")
        or output_collect.get("evidence_request_ids")
        or []
    )
    if isinstance(raw_ids, str):
        raw_ids = [raw_ids]
    result: list[str] = []
    seen: set[str] = set()
    if isinstance(raw_ids, list):
        for raw in raw_ids:
            value = compact_text(raw, 120)
            if value and value not in seen:
                seen.add(value)
                result.append(value)
    return result[:20]


def execute_ops_manual_search(action: dict[str, Any]) -> dict[str, Any]:
    query = compact_text(action.get("query") or action.get("q") or action.get("text"), 160)
    limit = safe_int(action.get("limit"), 5)
    if limit <= 0:
        limit = 5
    limit = min(limit, 10)
    read_model = fb_get(OPS_MANUAL_READ_MODEL_SEARCH_PATH) or {}
    entries = fb_get(OPS_MANUAL_ENTRIES_PATH) or {}
    candidates: Any = {}
    candidate_read_error = ""
    try:
        candidates = fb_get(OPS_MANUAL_CANDIDATES_PATH) or {}
    except Exception as exc:
        # Candidate hints are optional. Their outage must not suppress the
        # canonical manual result that was already read successfully.
        candidate_read_error = compact_error(str(exc), 160)
    entry_lookup = {
        str(item.get("entry_id") or item.get("id") or ""): item
        for item in ops_manual_collection_items(entries, "entry_id")
    }
    query_terms = [part for part in re.split(r"\s+", query.casefold()) if part]
    scored: list[tuple[int, str, dict[str, Any]]] = []
    for row in ops_manual_collection_items(read_model, "entry_id"):
        entry_id = str(row.get("entry_id") or row.get("id") or "")
        entry = entry_lookup.get(entry_id, {})
        blob = ops_manual_search_blob({**entry, **row})
        if not query_terms:
            score = 1
        else:
            score = sum(10 for term in query_terms if term in blob)
            if query.casefold() and query.casefold() in blob:
                score += 50
        if score <= 0:
            continue
        merged = {**row, **entry, "_knowledge_status": "canonical"}
        scored.append((score, entry_id, merged))
    if not scored:
        for entry in entry_lookup.values():
            entry_id = str(entry.get("entry_id") or entry.get("id") or "")
            blob = ops_manual_search_blob(entry)
            score = sum(10 for term in query_terms if term in blob)
            if query.casefold() and query.casefold() in blob:
                score += 50
            if score > 0 or not query_terms:
                scored.append((score or 1, entry_id, {**entry, "_knowledge_status": "canonical"}))
    source_paths = [OPS_MANUAL_READ_MODEL_SEARCH_PATH, OPS_MANUAL_ENTRIES_PATH, OPS_MANUAL_CANDIDATES_PATH]
    for candidate in ops_manual_collection_items(candidates, "candidate_id"):
        status = str(candidate.get("status") or "pending").strip().casefold()
        if status not in {"pending", "previewed", "approved"}:
            continue
        evidence_ids = ops_manual_candidate_evidence_ids(candidate)
        # A single unreviewed utterance is never reusable knowledge. Two or
        # more recorded chat events may be used as an advisory read hint, but
        # never as authority for a write or live action.
        if status != "approved" and len(evidence_ids) < 2:
            continue
        blob = ops_manual_search_blob(candidate)
        score = sum(10 for term in query_terms if term in blob)
        if query.casefold() and query.casefold() in blob:
            score += 50
        if score <= 0 and query_terms:
            continue
        candidate_id = str(candidate.get("candidate_id") or candidate.get("id") or "")
        scored.append(
            (
                max(1, score - 3),
                candidate_id,
                {
                    **candidate,
                    "_knowledge_status": "approved_candidate" if status == "approved" else "context_pattern",
                    "_evidence_ids": evidence_ids,
                },
            )
        )
    if not scored:
        variants = fb_get(KNOWLEDGE_OUTPUT_VARIANTS_PATH) or {}
        source_paths.append(KNOWLEDGE_OUTPUT_VARIANTS_PATH)
        for item in ops_manual_collection_items(variants, "id"):
            if item.get("deleted") or item.get("status") in {"hidden", "held", "output_disabled", "deleted"}:
                continue
            blob = ops_manual_search_blob(item)
            score = sum(10 for term in query_terms if term in blob)
            if query.casefold() and query.casefold() in blob:
                score += 50
            if score > 0 or not query_terms:
                scored.append((score or 1, str(item.get("id") or ""), item))
    scored.sort(key=lambda item: (-item[0], str(item[2].get("updated_at_ms") or ""), item[1]))
    results: list[dict[str, Any]] = []
    for score, entry_id, item in scored[:limit]:
        results.append(
            {
                "entry_id": entry_id,
                "score": score,
                "category": item.get("category") or "general",
                "title": item.get("title") or "",
                "summary": item.get("summary") or "",
                "body": compact_text(item.get("body") or item.get("text") or "", 800),
                "tags": list(item.get("tags") or []),
                "actions": list(item.get("actions") or []),
                "cautions": list(item.get("cautions") or []),
                "updated_at_ms": item.get("updated_at_ms") or 0,
                "verification_status": item.get("_knowledge_status") or "knowledge_variant",
                "advisory_only": (item.get("_knowledge_status") or "") != "canonical",
                "evidence_count": len(item.get("_evidence_ids") or []),
            }
        )
    response = {
        "ok": True,
        "operation": "ops_manual.search",
        "query": query,
        "source_paths": source_paths,
        "results": results,
    }
    if candidate_read_error:
        response["candidate_read_error"] = candidate_read_error
    return response


def build_storebot_operation_knowledge_preview(item: dict[str, Any], query: str = "") -> dict[str, Any]:
    payload = item.get("payload") if isinstance(item.get("payload"), dict) else {}
    text = compact_text(
        item.get("text")
        or item.get("message")
        or item.get("content")
        or payload.get("text")
        or payload.get("message")
        or payload.get("summary")
        or query,
        2000,
    )
    if not text:
        raise WorkerError("operation knowledge preview text missing")
    raw_item = {
        "source": compact_text(item.get("source") or "storebot_codex_worker", 120),
        "channel": compact_text(item.get("channel") or item.get("input_channel") or "kakao", 80),
        "text": text,
        "author": compact_text(item.get("sender") or item.get("author") or "", 80),
        "timestamp": item.get("created_at_ms") or item.get("timestamp") or item.get("ts_ms") or "",
        "tags": item.get("tags") if isinstance(item.get("tags"), list) else [],
        "source_path": REQUESTS_PATH if str(item.get("request_id") or "").strip() else "",
    }
    preview = build_operation_knowledge_preview([raw_item], query=query)
    ensure_write_enabled_adapter_contract(preview["mcp_adapter_contract"])
    structured = preview["structured_summary"]
    variants = preview["output_variants"]
    return {
        "ok": True,
        "operation": "operation_knowledge.preview",
        "mode": preview["mode"],
        "category": structured.get("category") or "",
        "audience": structured.get("audience") or "",
        "summary": structured.get("summary") or "",
        "key_points": list(structured.get("key_points") or []),
        "source_ids": list(structured.get("source_ids") or []),
        "citations": list(structured.get("citations") or []),
        "output_variant_keys": list(variants.keys()),
        "output_variants": variants,
        "canonical_schedule_source": KNOWLEDGE_CANONICAL_SCHEDULE_SOURCE,
        "knowledge_summary_as_schedule_source": False,
        "write_enabled_contract": {
            "resources": preview["mcp_adapter_contract"].get("resources") or [],
            "tools": preview["mcp_adapter_contract"].get("tools") or [],
            "prompts": preview["mcp_adapter_contract"].get("prompts") or [],
            "guards": preview["guards"],
        },
        "side_effects": "none",
    }


def execute_operation_knowledge_preview(action: dict[str, Any]) -> dict[str, Any]:
    raw_items = action.get("raw_items")
    query = compact_text(action.get("query") or action.get("q") or action.get("text"), 160)
    if isinstance(raw_items, list) and raw_items:
        preview = build_operation_knowledge_preview(raw_items, query=query)
        ensure_write_enabled_adapter_contract(preview["mcp_adapter_contract"])
        structured = preview["structured_summary"]
        return {
            "ok": True,
            "operation": "operation_knowledge.preview",
            "mode": preview["mode"],
            "category": structured.get("category") or "",
            "audience": structured.get("audience") or "",
            "summary": structured.get("summary") or "",
            "key_points": list(structured.get("key_points") or []),
            "source_ids": list(structured.get("source_ids") or []),
            "citations": list(structured.get("citations") or []),
            "output_variant_keys": list(preview["output_variants"].keys()),
            "output_variants": preview["output_variants"],
            "canonical_schedule_source": KNOWLEDGE_CANONICAL_SCHEDULE_SOURCE,
            "knowledge_summary_as_schedule_source": False,
            "write_enabled_contract": {
                "resources": preview["mcp_adapter_contract"].get("resources") or [],
                "tools": preview["mcp_adapter_contract"].get("tools") or [],
                "prompts": preview["mcp_adapter_contract"].get("prompts") or [],
                "guards": preview["guards"],
            },
            "side_effects": "none",
        }
    return build_storebot_operation_knowledge_preview(action, query=query)


def operation_knowledge_actor(action: dict[str, Any]) -> str:
    return compact_text(action.get("actor") or action.get("sender") or action.get("author") or "storebot_codex_worker", 120)


def operation_knowledge_channel(action: dict[str, Any]) -> str:
    return compact_text(action.get("channel") or action.get("input_channel") or "storebot", 80)


def operation_knowledge_source(action: dict[str, Any]) -> str:
    return compact_text(action.get("source") or "storebot_codex_worker", 120)


def operation_knowledge_dry_run(action: dict[str, Any]) -> bool:
    return bool(
        truthy(action.get("dry_run"))
        or truthy(action.get("no_write"))
        or truthy(action.get("no_send"))
        or truthy(action.get("mock"))
        or truthy(action.get("payload_only"))
        or truthy(action.get("side_effects_disabled"))
    )


def apply_operation_knowledge_writes(result: dict[str, Any], *, dry_run: bool) -> dict[str, Any]:
    response = dict(result)
    response["dry_run"] = bool(dry_run)
    response["write_performed"] = False
    response["applied_writes"] = []
    if dry_run:
        response["status"] = "prepared_no_write"
        return response
    applied: list[dict[str, Any]] = []
    for write in result.get("writes") or []:
        method = str(write.get("method") or "").strip().lower()
        path = str(write.get("path") or "")
        value = write.get("value")
        if method == "put":
            fb_put(path, value)
        elif method == "patch":
            fb_patch(path, value if isinstance(value, dict) else {})
        elif method == "delete":
            fb_request("DELETE", path)
        else:
            raise WorkerError(f"unsupported operation knowledge write method: {method}")
        applied.append({"method": method, "path": path})
    response["write_performed"] = bool(applied)
    response["applied_writes"] = applied
    response["status"] = "applied"
    return response


def operation_knowledge_raw_item_from_action(action: dict[str, Any]) -> dict[str, Any]:
    raw_item = action.get("raw_item") if isinstance(action.get("raw_item"), dict) else {}
    payload = action.get("payload") if isinstance(action.get("payload"), dict) else {}
    merged = {
        **payload,
        **raw_item,
    }
    for key in ("text", "raw_text", "body", "content", "source", "channel", "author", "sender", "timestamp", "created_at_ms", "tags", "source_path", "id"):
        if key in action and key not in merged:
            merged[key] = action[key]
    return merged


def execute_operation_knowledge_ingest(action: dict[str, Any]) -> dict[str, Any]:
    result = build_operation_knowledge_ingest(
        operation_knowledge_raw_item_from_action(action),
        actor=operation_knowledge_actor(action),
        channel=operation_knowledge_channel(action),
        source=operation_knowledge_source(action),
        priority=safe_int(action.get("priority"), 5),
        requested_outputs=action.get("requested_outputs"),
    )
    return apply_operation_knowledge_writes(result, dry_run=operation_knowledge_dry_run(action))


def operation_knowledge_queue_job_from_action(action: dict[str, Any]) -> dict[str, Any]:
    job = action.get("job") if isinstance(action.get("job"), dict) else None
    if job is None and isinstance(action.get("queue_job"), dict):
        job = action.get("queue_job")
    if job is not None:
        return dict(job)
    job_id = compact_text(action.get("job_id") or action.get("queue_job_id"), 120)
    if not job_id:
        raise WorkerError("operation knowledge process job_id missing")
    fetched = fb_get(f"{KNOWLEDGE_QUEUE_PATH}/{sanitize_key(job_id)}") or {}
    if not isinstance(fetched, dict):
        raise WorkerError("operation knowledge queue job not found")
    fetched.setdefault("job_id", job_id)
    return fetched


def operation_knowledge_raw_item_for_job(action: dict[str, Any], job: dict[str, Any]) -> dict[str, Any] | None:
    raw_item = action.get("raw_item") if isinstance(action.get("raw_item"), dict) else None
    if raw_item is not None:
        return raw_item
    source_id = compact_text(job.get("source_id") or action.get("source_id"), 120)
    if not source_id:
        return None
    fetched = fb_get(f"{KNOWLEDGE_RAW_ITEMS_PATH}/{sanitize_key(source_id)}") or {}
    return fetched if isinstance(fetched, dict) else None


def execute_operation_knowledge_process_job(action: dict[str, Any]) -> dict[str, Any]:
    job = operation_knowledge_queue_job_from_action(action)
    raw_item = operation_knowledge_raw_item_for_job(action, job)
    result = build_operation_knowledge_process_job(
        job,
        raw_item,
        actor=operation_knowledge_actor(action),
        channel=operation_knowledge_channel(action),
        source=operation_knowledge_source(action),
        fail_reason=compact_text(action.get("fail_reason") or action.get("error"), 300),
    )
    return apply_operation_knowledge_writes(result, dry_run=operation_knowledge_dry_run(action))


def operation_knowledge_pending_jobs(action: dict[str, Any]) -> list[dict[str, Any]]:
    raw_jobs = action.get("jobs") if isinstance(action.get("jobs"), list) else None
    if raw_jobs is None:
        queue = fb_get(KNOWLEDGE_QUEUE_PATH) or {}
        raw_jobs = []
        if isinstance(queue, dict):
            for key, value in queue.items():
                if isinstance(value, dict):
                    item = dict(value)
                    item.setdefault("job_id", key)
                    raw_jobs.append(item)
    job_id = compact_text(action.get("job_id") or action.get("queue_job_id"), 120)
    jobs: list[dict[str, Any]] = []
    for job in raw_jobs or []:
        if not isinstance(job, dict):
            continue
        if job.get("status") != "pending":
            continue
        if job_id and job.get("job_id") != job_id:
            continue
        jobs.append(dict(job))
    jobs.sort(key=lambda item: (safe_int(item.get("priority"), 5), safe_int(item.get("created_at_ms") or item.get("created_at"), 0), item.get("job_id") or ""))
    return jobs


def execute_operation_knowledge_process_queue(action: dict[str, Any]) -> dict[str, Any]:
    limit = safe_int(action.get("limit"), 5)
    if limit <= 0:
        limit = 5
    limit = min(limit, 20)
    dry_run = operation_knowledge_dry_run(action)
    results: list[dict[str, Any]] = []
    write_performed = False
    for job in operation_knowledge_pending_jobs(action)[:limit]:
        raw_item = operation_knowledge_raw_item_for_job(action, job)
        result = build_operation_knowledge_process_job(
            job,
            raw_item,
            actor=operation_knowledge_actor(action),
            channel=operation_knowledge_channel(action),
            source=operation_knowledge_source(action),
            fail_reason=compact_text(action.get("fail_reason") or action.get("error"), 300),
        )
        applied = apply_operation_knowledge_writes(result, dry_run=dry_run)
        write_performed = write_performed or bool(applied.get("write_performed"))
        results.append(applied)
    return {
        "ok": True,
        "operation": "operation_knowledge.process_queue",
        "mode": "write_enabled",
        "dry_run": dry_run,
        "write_performed": write_performed,
        "processed_count": len(results),
        "results": results,
        "queue_path": KNOWLEDGE_QUEUE_PATH,
    }


def execute_operation_knowledge_upsert_summary(action: dict[str, Any]) -> dict[str, Any]:
    raw_items = action.get("raw_items")
    summary = action.get("summary") if isinstance(action.get("summary"), dict) else None
    if summary is None and isinstance(action.get("payload"), dict):
        payload = action.get("payload") or {}
        if payload.get("summary") or payload.get("key_points"):
            summary = payload
    if summary is None and isinstance(raw_items, list):
        result = build_operation_knowledge_summary_upsert(
            None,
            raw_items=raw_items,
            actor=operation_knowledge_actor(action),
            channel=operation_knowledge_channel(action),
            source=operation_knowledge_source(action),
        )
    elif summary is not None:
        result = build_operation_knowledge_summary_upsert(
            summary,
            actor=operation_knowledge_actor(action),
            channel=operation_knowledge_channel(action),
            source=operation_knowledge_source(action),
            before=action.get("before"),
        )
    else:
        preview = build_operation_knowledge_preview([operation_knowledge_raw_item_from_action(action)], query=compact_text(action.get("query"), 160))
        result = build_operation_knowledge_summary_upsert(
            preview["structured_summary"],
            actor=operation_knowledge_actor(action),
            channel=operation_knowledge_channel(action),
            source=operation_knowledge_source(action),
        )
    return apply_operation_knowledge_writes(result, dry_run=operation_knowledge_dry_run(action))


def execute_operation_knowledge_render_output(action: dict[str, Any]) -> dict[str, Any]:
    structured = action.get("structured_summary") if isinstance(action.get("structured_summary"), dict) else None
    if structured is None and isinstance(action.get("summary"), dict):
        structured = action.get("summary")
    if structured is None:
        raw_items = action.get("raw_items") if isinstance(action.get("raw_items"), list) else [operation_knowledge_raw_item_from_action(action)]
        structured = build_operation_knowledge_preview(raw_items, query=compact_text(action.get("query"), 160))["structured_summary"]
    result = build_operation_knowledge_render_output(
        structured,
        query=compact_text(action.get("query") or action.get("q"), 160),
        variant_key=compact_text(action.get("variant") or action.get("variant_key"), 80),
        actor=operation_knowledge_actor(action),
        channel=operation_knowledge_channel(action),
        source=operation_knowledge_source(action),
        upsert=bool(truthy(action.get("upsert")) or truthy(action.get("persist"))),
    )
    if result.get("writes"):
        return apply_operation_knowledge_writes(result, dry_run=operation_knowledge_dry_run(action))
    result["dry_run"] = True
    result["write_performed"] = False
    return result


def execute_operation_knowledge_upsert_output(action: dict[str, Any]) -> dict[str, Any]:
    variant = action.get("variant_payload") if isinstance(action.get("variant_payload"), dict) else None
    if variant is None and isinstance(action.get("output_variant"), dict):
        variant = action.get("output_variant")
    if variant is None and isinstance(action.get("payload"), dict):
        variant = action.get("payload")
    if variant is None:
        raise WorkerError("operation knowledge output variant payload missing")
    result = build_operation_knowledge_output_upsert(
        compact_text(action.get("variant") or action.get("variant_key") or variant.get("variant_key"), 80),
        variant,
        actor=operation_knowledge_actor(action),
        channel=operation_knowledge_channel(action),
        source=operation_knowledge_source(action),
        before=action.get("before"),
    )
    return apply_operation_knowledge_writes(result, dry_run=operation_knowledge_dry_run(action))


def execute_operation_knowledge_delete_request(action: dict[str, Any]) -> dict[str, Any]:
    result = build_operation_knowledge_delete_request(
        compact_text(action.get("target_type") or "raw", 40),
        compact_text(action.get("source_id") or action.get("id"), 120),
        actor=operation_knowledge_actor(action),
        channel=operation_knowledge_channel(action),
        source=operation_knowledge_source(action),
        reason=compact_text(action.get("reason") or action.get("delete_reason"), 300),
    )
    return apply_operation_knowledge_writes(result, dry_run=operation_knowledge_dry_run(action))


def execute_operation_knowledge_delete(action: dict[str, Any]) -> dict[str, Any]:
    target_type = compact_text(action.get("target_type") or "raw", 40)
    source_id = compact_text(action.get("source_id") or action.get("id"), 120)
    if not source_id:
        raise WorkerError("operation knowledge delete source_id missing")
    if truthy(action.get("hard")) or truthy(action.get("hard_delete")):
        result = build_operation_knowledge_hard_delete(
            target_type,
            source_id,
            explicit_confirm=compact_text(action.get("explicit_confirm"), 160),
            actor=operation_knowledge_actor(action),
            channel=operation_knowledge_channel(action),
            source=operation_knowledge_source(action),
            reason=compact_text(action.get("reason") or action.get("delete_reason"), 300),
            before=action.get("before"),
        )
    else:
        result = build_operation_knowledge_soft_delete(
            target_type,
            source_id,
            actor=operation_knowledge_actor(action),
            channel=operation_knowledge_channel(action),
            source=operation_knowledge_source(action),
            reason=compact_text(action.get("reason") or action.get("delete_reason"), 300),
            before=action.get("before"),
        )
    return apply_operation_knowledge_writes(result, dry_run=operation_knowledge_dry_run(action))


def execute_operation_knowledge_restore(action: dict[str, Any]) -> dict[str, Any]:
    source_id = compact_text(action.get("source_id") or action.get("id"), 120)
    if not source_id:
        raise WorkerError("operation knowledge restore source_id missing")
    result = build_operation_knowledge_restore(
        compact_text(action.get("target_type") or "raw", 40),
        source_id,
        actor=operation_knowledge_actor(action),
        channel=operation_knowledge_channel(action),
        source=operation_knowledge_source(action),
        before=action.get("before"),
    )
    return apply_operation_knowledge_writes(result, dry_run=operation_knowledge_dry_run(action))


def execute_operation_knowledge_send_reply(action: dict[str, Any], req_id: str = "") -> dict[str, Any]:
    message = compact_text(action.get("message") or action.get("text") or action.get("reply"), 1200)
    room_id = compact_text(action.get("room_id") or action.get("room"), 160)
    room_name = compact_text(action.get("room_name") or "", 160)
    source_id = compact_text(action.get("source_id") or action.get("variant_id") or action.get("id"), 120)
    explicit = truthy(action.get("explicit_action")) or truthy(action.get("confirmed")) or truthy(action.get("execute_send"))
    if not message:
        raise WorkerError("operation knowledge send_reply message missing")
    if not room_id:
        raise WorkerError("operation knowledge send_reply room_id missing")
    if not explicit:
        raise WorkerError("operation knowledge send_reply requires explicit_action")
    no_send = operation_knowledge_dry_run(action) or not truthy(action.get("execute_send")) or not truthy(action.get("kakao_send_enabled"))
    audit = {
        "schema_version": 1,
        "actor": operation_knowledge_actor(action),
        "channel": operation_knowledge_channel(action),
        "source": operation_knowledge_source(action),
        "action": "operation_knowledge.send_reply",
        "source_id": source_id,
        "timestamp": now_ms(),
        "timestamp_ms": now_ms(),
        "before": None,
        "after": {
            "message_preview": redact_room_text_preview(message, 180),
            "room_id": room_id,
            "room_name_hash": short_text_hash(room_name),
            "kakao_send_enabled": bool(truthy(action.get("kakao_send_enabled"))),
            "execute_send": bool(truthy(action.get("execute_send"))),
            "no_send": bool(no_send),
        },
        "status": "prepared_no_send" if no_send else "queued",
    }
    audit["id"] = sanitize_key(f"ok_send_{short_text_hash(json.dumps(audit, ensure_ascii=False, sort_keys=True, default=str))}", "audit")
    result: dict[str, Any] = {
        "ok": True,
        "operation": "operation_knowledge.send_reply",
        "mode": "write_enabled",
        "kakao_send_enabled": True,
        "dry_run": bool(no_send),
        "no_send": bool(no_send),
        "write_performed": False,
        "source_id": source_id,
        "room_id": room_id,
        "audit_record": audit,
        "send_payload": {
            "message": message,
            "source": "operation_knowledge.send_reply",
            "request_id": req_id or compact_text(action.get("request_id"), 120),
            "room_id": room_id,
            "room_name": room_name,
            "sender": operation_knowledge_actor(action),
        },
        "guards": {
            "explicit_action_required": True,
            "room_guard_required": True,
            "mass_send_disabled": True,
            "audit_required": True,
        },
    }
    if no_send:
        result["status"] = "prepared_no_send"
        return result
    fb_put(f"{KNOWLEDGE_AUDIT_PATH}/{audit['id']}", audit)
    outbound_key = publish_outbound_message(
        message,
        source="operation_knowledge.send_reply",
        request_id=req_id or compact_text(action.get("request_id"), 120),
        room_id=room_id,
        room_name=room_name,
        sender=operation_knowledge_actor(action),
    )
    result["status"] = "queued"
    result["write_performed"] = True
    result["outbound_key"] = outbound_key
    return result


def storebot_local_direct_probe_endpoint(action: dict[str, Any]) -> str:
    endpoint = compact_text(
        request_field(action, "endpoint")
        or request_field(action, "url")
        or request_field(action, "request_url")
        or "",
        300,
    )
    if not endpoint:
        return STOREBOT_LOCAL_DIRECT_PROBE_ENDPOINT
    parsed = urllib.parse.urlparse(endpoint)
    if parsed.scheme != "http":
        raise WorkerError("storebot local direct probe endpoint must use http")
    if parsed.hostname not in STOREBOT_LOCAL_DIRECT_PROBE_ALLOWED_HOSTS:
        raise WorkerError("storebot local direct probe endpoint must stay on loopback")
    try:
        port = int(parsed.port or 0)
    except ValueError as exc:
        raise WorkerError("storebot local direct probe endpoint has invalid port") from exc
    if port != 8765:
        raise WorkerError("storebot local direct probe endpoint must use port 8765")
    if parsed.path.rstrip("/") != "/storebot/request":
        raise WorkerError("storebot local direct probe endpoint must use /storebot/request")
    if parsed.params or parsed.query or parsed.fragment:
        raise WorkerError("storebot local direct probe endpoint must not include params, query, or fragment")
    return endpoint


def build_storebot_local_direct_probe_payload(action: dict[str, Any], req_id: str = "") -> dict[str, Any]:
    request_id = compact_text(
        request_field(action, "request_id")
        or req_id
        or f"storebot_local_direct_probe_{now_ms()}_{secrets.token_hex(3)}",
        120,
    )
    room_id = compact_text(request_field(action, "room_id") or request_field(action, "room") or "storebot_local_direct_probe", 160)
    room_name = compact_text(request_field(action, "room_name") or request_field(action, "roomTitle") or room_id, 160)
    sender = compact_text(request_field(action, "sender") or request_field(action, "author") or "storebot_local_direct_probe", 160)
    text = compact_text(
        request_field(action, "text")
        or request_field(action, "message")
        or request_field(action, "body")
        or "storebot local-direct probe",
        1200,
    )
    probe_payload = {
        "request_id": request_id,
        "event_kind": "chat",
        "kind": "chat",
        "source": "storebot_codex_worker_local_direct_probe",
        "transport": "local_direct_probe",
        "room_id": room_id,
        "room_name": room_name,
        "sender": sender,
        "message": text,
        "text": text,
        "created_at_ms": now_ms(),
        "ts": now_ms(),
        "local_direct_probe": True,
        "no_send": True,
        "no_publish": True,
        "publish_disabled": True,
        "no_kakao_send": True,
        "learning_disabled": True,
        "reply_target": {"kakao_publish": False},
    }
    probe_payload["probe"] = True
    probe_payload["contract_probe"] = True
    probe_payload["local_direct"] = True
    return probe_payload


def storebot_local_direct_probe_response_block_reason(response: dict[str, Any]) -> str:
    if not isinstance(response, dict):
        return "response_not_object"
    outbound_key = compact_text(response.get("outbound_key"), 160)
    if outbound_key:
        return "outbound_key_present"
    for key in ("published", "publish", "send", "sent", "queued", "delivered", "outbound_queued"):
        if truthy(response.get(key)):
            return f"{key}_present"
    status = compact_text(response.get("status"), 80).lower()
    response_category = compact_text(
        response.get("response_category") or response.get("output_category") or response.get("category"),
        80,
    ).lower()
    if status in {"published", "publish", "send", "sent", "queued", "delivered"}:
        return f"status_{status}"
    if response_category in {"published", "publish", "send", "sent", "queued", "delivered"}:
        return f"response_category_{response_category}"
    reply_target = response.get("reply_target")
    if isinstance(reply_target, dict) and truthy(reply_target.get("kakao_publish")):
        return "reply_target.kakao_publish=true"
    if response.get("publish_disabled") is False:
        return "publish_disabled_false"
    if response.get("no_publish") is False:
        return "no_publish_false"
    if response.get("no_send") is False:
        return "no_send_false"
    if response.get("no_kakao_send") is False:
        return "no_kakao_send_false"
    return ""


STOREBOT_LOCAL_DIRECT_PROBE_TIMEOUT_SEC = 10
STOREBOT_LOCAL_DIRECT_PROBE_MIRROR_POLL_ATTEMPTS = 3
STOREBOT_LOCAL_DIRECT_PROBE_MIRROR_GET_TIMEOUT_SEC = 2
STOREBOT_LOCAL_DIRECT_PROBE_MIRROR_POLL_SLEEP_SEC = 0.2


def storebot_local_direct_probe_request_path(request_id: str) -> str:
    return f"{REQUESTS_PATH}/{sanitize_key(request_id, 'local_direct')}"


def storebot_local_direct_probe_timeout_error_text(exc: BaseException) -> str:
    if isinstance(exc, (socket.timeout, TimeoutError)):
        return "timed out"
    if isinstance(exc, urllib.error.URLError):
        reason = getattr(exc, "reason", None)
        reason_text = compact_error(str(reason or exc), 200).lower()
        if "timed out" in reason_text or "timeout" in reason_text:
            return "timed out"
    text = compact_error(str(exc), 500)
    lowered = text.lower()
    if "timed out" in lowered or "timeout" in lowered:
        return "timed out"
    return text


def storebot_local_direct_probe_mirror_block_reason(response: Any) -> str:
    if not isinstance(response, dict):
        return "mirror_row_missing"

    status = compact_text(response.get("status") or response.get("response_status") or "", 80).lower()
    if not status:
        return "mirror_row_missing_status"
    if not (status == "done" or status.startswith("completed")):
        if status in {"pending", "queued", "running", "inflight", "processing", "working"}:
            return "mirror_row_running"
        if status in {"error", "failed", "blocked", "cancelled", "canceled"}:
            return f"mirror_row_status_{status}"
        return f"mirror_row_status_{status}"

    if response.get("local_direct") is not True:
        return "local_direct_false"
    if response.get("publish_disabled") is not True:
        return "publish_disabled_false"
    if not (truthy(response.get("no_send")) or truthy(response.get("no_publish"))):
        return "no_send_no_publish_not_true"

    reply_target = response.get("reply_target")
    if not isinstance(reply_target, dict):
        return "reply_target_missing"
    if truthy(reply_target.get("kakao_publish")):
        return "reply_target.kakao_publish=true"

    outbound_key = compact_text(response.get("outbound_key"), 160)
    if outbound_key:
        return "outbound_key_present"

    for key in ("sent", "published", "queued", "delivered", "outbound_queued"):
        if truthy(response.get(key)):
            return f"{key}_present"

    return ""


def storebot_local_direct_probe_poll_mirror(
    request_id: str,
    *,
    attempts: int = STOREBOT_LOCAL_DIRECT_PROBE_MIRROR_POLL_ATTEMPTS,
    timeout_sec: int = STOREBOT_LOCAL_DIRECT_PROBE_MIRROR_GET_TIMEOUT_SEC,
) -> tuple[dict[str, Any] | None, str]:
    mirror_path = storebot_local_direct_probe_request_path(request_id)
    last_reason = ""
    for attempt in range(max(1, attempts)):
        try:
            mirror = fb_get_timeout(mirror_path, timeout=timeout_sec)
        except Exception as exc:  # pragma: no cover - exercised through timeout/network simulations.
            last_reason = storebot_local_direct_probe_timeout_error_text(exc)
        else:
            if isinstance(mirror, dict):
                block_reason = storebot_local_direct_probe_mirror_block_reason(mirror)
                if not block_reason:
                    return mirror, ""
                if block_reason == "mirror_row_running":
                    last_reason = block_reason
                else:
                    return mirror, block_reason
            else:
                last_reason = "mirror_row_missing"

        if attempt + 1 < max(1, attempts):
            time.sleep(STOREBOT_LOCAL_DIRECT_PROBE_MIRROR_POLL_SLEEP_SEC)
    return None, last_reason or "mirror_row_missing"


def storebot_local_direct_probe_timeout_result(
    action: dict[str, Any],
    req_id: str,
    *,
    endpoint: str,
    payload: dict[str, Any],
    started_at_ms: int,
    started: float,
    timeout_sec: int,
    original_error: str,
) -> dict[str, Any]:
    mirror, block_reason = storebot_local_direct_probe_poll_mirror(req_id)
    ended_at_ms = now_ms()
    duration_ms = int((time.perf_counter() - started) * 1000)
    proof_path = storebot_local_direct_probe_request_path(req_id)
    mirror_payload = compact_payload(mirror or {}, 3000)
    mirror_http_status = safe_int(mirror.get("http_status") if isinstance(mirror, dict) else 0, 0)
    if mirror and not block_reason:
        local_direct_elapsed_ms = safe_int(mirror.get("local_direct_elapsed_ms"), duration_ms)
        response_category = compact_text(
            mirror.get("response_category")
            or mirror.get("output_category")
            or mirror.get("category")
            or "mirror_only",
            80,
        )
        response_status = compact_text(
            mirror.get("status")
            or mirror.get("response_status")
            or "done",
            80,
        )
        result: dict[str, Any] = {
            "ok": True,
            "operation": "storebot_local_direct_probe",
            "status": "completed_via_mirror",
            "request_id": payload["request_id"],
            "endpoint": endpoint,
            "http_status": mirror_http_status if mirror_http_status > 0 else None,
            "http_status_source": "mirror" if mirror_http_status > 0 else "mirror_only",
            "response_category": response_category,
            "response_status": response_status,
            "start_at_ms": started_at_ms,
            "end_at_ms": ended_at_ms,
            "duration_ms": duration_ms,
            "local_direct_elapsed_ms": local_direct_elapsed_ms,
            "mirror_path": proof_path,
            "proof_path": proof_path,
            "request_payload": compact_payload(payload, 3000),
            "response_payload": mirror_payload,
            "timeout_sec": timeout_sec,
            "original_error": original_error,
        }
        return result

    if isinstance(mirror, dict):
        response_category_base = mirror.get("response_category") or mirror.get("output_category") or mirror.get("category")
        response_status_base = mirror.get("status") or mirror.get("response_status")
    else:
        response_category_base = ""
        response_status_base = ""
    if block_reason == "mirror_row_running":
        response_category_base = response_category_base or "running"
        response_status_base = response_status_base or "running"
    else:
        response_category_base = response_category_base or "mirror_only"
        response_status_base = response_status_base or "missing"

    result = {
        "ok": False,
        "operation": "storebot_local_direct_probe",
        "status": "timeout",
        "request_id": payload["request_id"],
        "endpoint": endpoint,
        "http_status": mirror_http_status if mirror_http_status > 0 else None,
        "http_status_source": "mirror" if mirror_http_status > 0 else "mirror_only",
        "response_category": compact_text(response_category_base, 80),
        "response_status": compact_text(response_status_base, 80),
        "start_at_ms": started_at_ms,
        "end_at_ms": ended_at_ms,
        "duration_ms": duration_ms,
        "local_direct_elapsed_ms": duration_ms,
        "mirror_path": proof_path,
        "proof_path": proof_path,
        "request_payload": compact_payload(payload, 3000),
        "response_payload": mirror_payload,
        "timeout_sec": timeout_sec,
        "original_error": original_error,
        "block_reason": block_reason,
    }
    return result


def execute_storebot_local_direct_probe(action: dict[str, Any], req_id: str = "") -> dict[str, Any]:
    started_at_ms = now_ms()
    started = time.perf_counter()
    payload = build_storebot_local_direct_probe_payload(action, req_id=req_id)
    endpoint = storebot_local_direct_probe_endpoint(action)
    raw = json.dumps(payload, ensure_ascii=False, separators=(",", ":")).encode("utf-8")
    request = urllib.request.Request(
        endpoint,
        data=raw,
        headers={"Content-Type": "application/json; charset=utf-8", "User-Agent": "StoreBotCodexWorker/1"},
        method="POST",
    )
    http_status = 0
    response_payload: dict[str, Any] = {}
    response_text = ""
    request_error = ""
    try:
        with urllib.request.urlopen(request, timeout=STOREBOT_LOCAL_DIRECT_PROBE_TIMEOUT_SEC) as resp:
            http_status = int(resp.getcode() or 0)
            response_text = resp.read().decode("utf-8", errors="replace")
    except urllib.error.HTTPError as exc:
        http_status = int(exc.code or 0)
        response_text = exc.read().decode("utf-8", errors="replace")
    except (urllib.error.URLError, TimeoutError, socket.timeout) as exc:
        request_error = storebot_local_direct_probe_timeout_error_text(exc)
    except Exception as exc:
        request_error = storebot_local_direct_probe_timeout_error_text(exc)
    if response_text.strip():
        try:
            parsed = json.loads(response_text)
            if isinstance(parsed, dict):
                response_payload = parsed
        except json.JSONDecodeError:
            response_payload = {"response_text": response_text}
    if not response_payload:
        response_payload = {}
    response_block_reason = storebot_local_direct_probe_response_block_reason(response_payload)
    ended_at_ms = now_ms()
    duration_ms = int((time.perf_counter() - started) * 1000)
    mirror_path = compact_text(
        response_payload.get("mirror_path")
        or response_payload.get("proof_path")
        or response_payload.get("source_path")
        or request_field(action, "mirror_path")
        or request_field(action, "proof_path")
        or "",
        300,
    )
    if request_error:
        return storebot_local_direct_probe_timeout_result(
            action,
            payload["request_id"],
            endpoint=endpoint,
            payload=payload,
            started_at_ms=started_at_ms,
            started=started,
            timeout_sec=STOREBOT_LOCAL_DIRECT_PROBE_TIMEOUT_SEC,
            original_error=request_error,
        )
    response_category = compact_text(
        response_payload.get("response_category")
        or response_payload.get("output_category")
        or response_payload.get("category")
        or response_payload.get("status")
        or ("ok" if http_status and 200 <= http_status < 300 else "error"),
        80,
    )
    response_status = compact_text(
        response_payload.get("status")
        or response_payload.get("response_status")
        or ("ok" if response_payload.get("ok") is True else "error"),
        80,
    )
    http_ok = 200 <= http_status < 300
    result: dict[str, Any] = {
        "ok": http_ok and not response_block_reason,
        "operation": "storebot_local_direct_probe",
        "status": "completed" if http_ok and not response_block_reason else "blocked",
        "request_id": payload["request_id"],
        "endpoint": endpoint,
        "http_status": http_status,
        "response_category": response_category,
        "response_status": response_status,
        "start_at_ms": started_at_ms,
        "end_at_ms": ended_at_ms,
        "duration_ms": duration_ms,
        "mirror_path": mirror_path,
        "proof_path": mirror_path,
        "request_payload": compact_payload(payload, 3000),
        "response_payload": compact_payload(response_payload, 3000),
    }
    if response_block_reason:
        result["ok"] = False
        result["status"] = "blocked"
        result["block_reason"] = response_block_reason
    elif not http_ok:
        result["ok"] = False
        result["status"] = "http_error"
    return result


def active_employee_items(employees: dict[str, Any]) -> list[tuple[str, dict[str, Any]]]:
    items: list[tuple[str, dict[str, Any]]] = []
    for emp_id, raw in employees.items():
        if not isinstance(raw, dict):
            continue
        if raw.get("active") is False:
            continue
        items.append((str(emp_id), raw))
    return items


def workschedule_v2_path(*parts: Any) -> str:
    suffix = "/".join(str(part).strip("/") for part in parts if str(part).strip("/"))
    return f"{WORKSCHEDULE_V2_PATH}/{suffix}" if suffix else WORKSCHEDULE_V2_PATH


def read_workschedule_v2_source(path: str) -> Any:
    canonical_path = str(path or "").strip()
    if canonical_path != WORKSCHEDULE_V2_PATH and not canonical_path.startswith(f"{WORKSCHEDULE_V2_PATH}/"):
        raise SourceReadError(
            f"non-canonical schedule source blocked: {canonical_path}",
            code="workschedule_v2_source_forbidden",
            source=WORKSCHEDULE_V2_PATH,
            attempts=0,
            path=canonical_path,
        )
    last_error: Exception | None = None
    for attempt in range(1, SCHEDULE_SOURCE_READ_ATTEMPTS + 1):
        try:
            return fb_get(canonical_path)
        except Exception as exc:
            last_error = exc
            if attempt < SCHEDULE_SOURCE_READ_ATTEMPTS:
                time.sleep(0.05)
    detail = compact_error(str(last_error or "unknown schedule source error"), 220)
    raise SourceReadError(
        f"workschedule_v2 read failed after {SCHEDULE_SOURCE_READ_ATTEMPTS} attempts: {detail}",
        code="workschedule_v2_read_failed",
        source=WORKSCHEDULE_V2_PATH,
        attempts=SCHEDULE_SOURCE_READ_ATTEMPTS,
        path=canonical_path,
    ) from last_error


def require_workschedule_v2_write_ready(dry_run: bool = False) -> None:
    if dry_run:
        return
    meta = fb_get(workschedule_v2_path("meta")) or {}
    if not isinstance(meta, dict) or meta.get("write_ready") is not True:
        raise WorkerError("/workschedule_v2/meta.write_ready is not true")


def employee_labels(emp_id: str, emp: dict[str, Any]) -> list[str]:
    labels = [emp_id, emp.get("name"), emp.get("short_name"), emp.get("nickname")]
    aliases = emp.get("aliases")
    if isinstance(aliases, list):
        labels.extend(aliases)
    return [str(label).strip() for label in labels if str(label or "").strip()]


def find_employee(action: dict[str, Any], employees: dict[str, Any]) -> tuple[str, dict[str, Any]]:
    emp_id = str(action.get("employee_id") or action.get("emp_id") or "").strip()
    if emp_id and isinstance(employees.get(emp_id), dict) and employees[emp_id].get("active") is not False:
        return emp_id, employees[emp_id]

    query = str(action.get("employee") or action.get("name") or action.get("staff") or "").strip()
    normalized = normalize_key_text(query)
    if not normalized:
        raise WorkerError("employee missing")

    exact: list[tuple[str, dict[str, Any]]] = []
    fuzzy: list[tuple[str, dict[str, Any]]] = []
    for candidate_id, emp in active_employee_items(employees):
        labels = [normalize_key_text(label) for label in employee_labels(candidate_id, emp)]
        if normalized in labels:
            exact.append((candidate_id, emp))
            continue
        if len(normalized) >= 2 and any(normalized.endswith(label) or label.endswith(normalized) for label in labels if len(label) >= 2):
            fuzzy.append((candidate_id, emp))

    matches = exact or fuzzy
    if len(matches) == 1:
        return matches[0]
    if len(matches) > 1:
        names = ", ".join(f"{emp_id}:{emp.get('name') or ''}" for emp_id, emp in matches[:5])
        raise WorkerError(f"employee ambiguous: {query} ({names})")
    raise WorkerError(f"employee not found: {query}")


def fetch_employees() -> dict[str, Any]:
    raw = fb_get(workschedule_v2_path("employees")) or {}
    return raw if isinstance(raw, dict) else {}


def next_employee_id(employees: dict[str, Any]) -> str:
    max_id = 0
    for key in employees:
        match = re.fullmatch(r"emp(\d+)", str(key or ""))
        if match:
            max_id = max(max_id, int(match.group(1)))
    return f"emp{max_id + 1}"


def deterministic_employee_color(name: str) -> str:
    palette = ["#00A884", "#5B8DEF", "#FFA94D", "#B388FF", "#45B7D1", "#96CEB4", "#FF6B6B"]
    return palette[sum(ord(ch) for ch in name) % len(palette)]


def clean_new_employee_name(value: Any) -> str:
    name = compact_text(value, 18)
    if not name:
        raise WorkerError("employee missing")
    normalized = normalize_key_text(name)
    if len(normalized) < 2:
        raise WorkerError(f"employee create name too short: {name}")
    if re.search(r"[\s,;/|]", name) or re.search(r"(출근|근무|부터|까지|시간|변경|추가|금요일|내일|오늘)", name):
        raise WorkerError(f"employee create name unclear: {name}")
    return name


def create_employee_for_schedule(
    employees: dict[str, Any],
    action: dict[str, Any],
    role: str,
    dry_run: bool,
) -> tuple[str, dict[str, Any], bool]:
    raw_name = action.get("employee") or action.get("name") or action.get("staff")
    name = clean_new_employee_name(raw_name)
    emp_id = next_employee_id(employees)
    now = now_ms()
    payload: dict[str, Any] = {
        "active": True,
        "aliases": [],
        "capabilities": [role or "주방"],
        "color": deterministic_employee_color(name),
        "created_at": datetime.fromtimestamp(now / 1000, KST).strftime("%Y-%m-%dT%H:%M:%S%z"),
        "name": name,
        "role": role or "주방",
        "short_name": str(action.get("short_name") or name).strip()[:18] or name,
        "source": "storebot_codex_schedule_upsert",
        "updated_at_ms": now,
    }
    aliases = action.get("aliases")
    if isinstance(aliases, list):
        payload["aliases"] = [compact_text(alias, 18) for alias in aliases if compact_text(alias, 18)]
    if not dry_run:
        require_workschedule_v2_write_ready(dry_run)
        fb_put(workschedule_v2_path("employees", sanitize_key(emp_id)), payload)
    return emp_id, payload, True


LAST_SHIFT_MARKER_RE = re.compile(
    r"(마지막\s*(출근|근무|근무일|날)|최종\s*(출근|근무)|last\s*(shift|work\s*day))",
    re.IGNORECASE,
)


def schedule_last_shift_marker(action: dict[str, Any]) -> str:
    for key in ("last_shift", "is_last_shift", "final_shift", "last_work_day", "employment_ends"):
        if truthy(action.get(key)):
            return "마지막 출근"
    for key in ("note", "memo", "reason", "source_text", "message", "text"):
        text = compact_text(action.get(key), 120)
        if text and LAST_SHIFT_MARKER_RE.search(text):
            return text
    return ""


def verify_schedule_upsert_write(
    emp_id: str,
    date_text: str,
    schedule: dict[str, Any],
    *,
    tentative: bool,
    is_last_shift: bool,
) -> dict[str, Any]:
    safe_emp_id = sanitize_key(emp_id)
    override_path = workschedule_v2_path("overrides", date_text, safe_emp_id)
    status_path = workschedule_v2_path("status", date_text, safe_emp_id)

    actual_override = fb_get(override_path)
    status_value = fb_get(status_path)

    errors: list[str] = []
    if not isinstance(actual_override, dict):
        errors.append(f"override expected object got {type(actual_override).__name__}")
    else:
        actual_schedule = actual_override.get("shift") if isinstance(actual_override.get("shift"), dict) else actual_override
        if actual_override.get("state") != "shift":
            errors.append(f"override.state expected 'shift' got {actual_override.get('state')!r}")
        for key, expected in schedule.items():
            if actual_schedule.get(key) != expected:
                errors.append(f"override.shift.{key} expected {expected!r} got {actual_schedule.get(key)!r}")
        if not schedule.get("start") and str(actual_schedule.get("start") or "").strip():
            errors.append(f"override.shift.start expected empty got {actual_schedule.get('start')!r}")
        if not schedule.get("end") and str(actual_schedule.get("end") or "").strip():
            errors.append(f"override.shift.end expected empty got {actual_schedule.get('end')!r}")
        if not is_last_shift:
            for key in ("last_shift", "last_work_date", "note", "source"):
                if actual_schedule.get(key) not in (None, "", False):
                    errors.append(f"override.shift.{key} expected empty got {actual_schedule.get(key)!r}")
        if not tentative:
            if actual_schedule.get("tentative") not in (None, "", False):
                errors.append(f"override.shift.tentative expected false got {actual_schedule.get('tentative')!r}")
            if actual_schedule.get("status") not in (None, ""):
                errors.append(f"override.shift.status expected empty got {actual_schedule.get('status')!r}")
    expected_status = "tentative" if tentative else "confirmed"
    actual_status = status_value.get("status") if isinstance(status_value, dict) else status_value
    if str(actual_status or "").strip() != expected_status:
        errors.append(f"status expected {expected_status!r} got {actual_status!r}")
    if errors:
        raise WorkerError(
            f"schedule upsert verification failed for {date_text}/{emp_id}: "
            + "; ".join(errors[:8])
        )
    return {
        "verified": True,
        "verified_paths": {
            "override": override_path,
            "status": status_path,
        },
    }


def clean_employee_alias(value: Any) -> str:
    alias = compact_text(value, 18)
    if not alias:
        raise WorkerError("employee alias missing")
    normalized = normalize_key_text(alias)
    if len(normalized) < 1:
        raise WorkerError(f"employee alias unclear: {alias}")
    if re.search(r"[\s,;/|]", alias) or re.search(r"(출근|근무|부터|까지|시간|변경|추가|금요일|내일|오늘)", alias):
        raise WorkerError(f"employee alias unclear: {alias}")
    return alias


def execute_employee_add_alias(action: dict[str, Any]) -> dict[str, Any]:
    employees = fetch_employees()
    emp_id, emp = find_employee(action, employees)
    alias_values = as_list(action.get("aliases") or action.get("alias") or action.get("nickname"))
    aliases_to_add = [clean_employee_alias(value) for value in alias_values]
    if not aliases_to_add:
        raise WorkerError("employee alias missing")
    dry_run = bool(action.get("dry_run"))

    existing_aliases = emp.get("aliases")
    aliases = [str(alias).strip() for alias in existing_aliases if str(alias or "").strip()] if isinstance(existing_aliases, list) else []
    existing_norms = {normalize_key_text(label) for label in employee_labels(emp_id, emp)}
    added: list[str] = []
    for alias in aliases_to_add:
        alias_norm = normalize_key_text(alias)
        for other_id, other_emp in active_employee_items(employees):
            if other_id == emp_id:
                continue
            other_labels = {normalize_key_text(label) for label in employee_labels(other_id, other_emp)}
            if alias_norm in other_labels:
                other_name = other_emp.get("name") or other_emp.get("short_name") or other_id
                raise WorkerError(f"employee alias conflicts: {alias} -> {other_name}")
        if alias_norm in existing_norms:
            continue
        aliases.append(alias)
        existing_norms.add(alias_norm)
        added.append(alias)

    if not dry_run and added:
        require_workschedule_v2_write_ready(dry_run)
        fb_patch(
            workschedule_v2_path("employees", sanitize_key(emp_id)),
            {
                "aliases": aliases,
                "updated_at_ms": now_ms(),
                "source": "storebot_employee_add_alias",
            },
        )
        for alias in added:
            fb_put(workschedule_v2_path("aliases", sanitize_key(alias)), emp_id)
    return {
        "ok": True,
        "operation": "employee.add_alias",
        "dry_run": dry_run,
        "employee_id": emp_id,
        "employee": emp.get("name") or emp.get("short_name") or emp_id,
        "added": added,
        "aliases": aliases,
    }


def execute_schedule_upsert(action: dict[str, Any]) -> dict[str, Any]:
    employees = fetch_employees()
    dates = [validate_date_text(value) for value in as_list(action.get("dates") or action.get("date"))]
    if not dates:
        raise WorkerError("date missing")
    start = validate_time_text(action.get("start") or action.get("start_time"), allow_empty=True)
    end = validate_time_text(action.get("end") or action.get("end_time"), allow_empty=True)
    tentative = bool(action.get("tentative")) or not start
    dry_run = bool(action.get("dry_run"))
    role_hint = str(action.get("role") or "주방").strip() or "주방"
    employee_created = False
    try:
        emp_id, emp = find_employee(action, employees)
    except WorkerError as exc:
        if "employee not found" not in str(exc) or not truthy(action.get("allow_create_employee") or action.get("create_employee_if_missing")):
            raise
        emp_id, emp, employee_created = create_employee_for_schedule(employees, action, role_hint, dry_run)
    role = str(action.get("role") or emp.get("role") or role_hint).strip() or "주방"
    last_shift_note = schedule_last_shift_marker(action)
    is_last_shift = bool(last_shift_note)

    writes: list[dict[str, Any]] = []
    require_workschedule_v2_write_ready(dry_run)
    for date_text in dates:
        schedule: dict[str, Any] = {"role": role}
        if start:
            schedule["start"] = start
        if end:
            schedule["end"] = end
        if is_last_shift:
            schedule["last_shift"] = True
            schedule["last_work_date"] = date_text
            schedule["note"] = last_shift_note
            schedule["source"] = "storebot_codex_schedule_last_shift"
        if tentative:
            schedule["tentative"] = True
            schedule["status"] = "일단출근"
        verification: dict[str, Any] = {"verified": False}
        if not dry_run:
            safe_emp_id = sanitize_key(emp_id)
            now = now_ms()
            fb_put(
                workschedule_v2_path("overrides", date_text, safe_emp_id),
                {
                    "state": "shift",
                    "shift": schedule,
                    "start": schedule.get("start", ""),
                    "end": schedule.get("end", ""),
                    "role": schedule.get("role", role),
                    "source": "storebot_codex_schedule_upsert",
                    "updated_at_ms": now,
                },
            )
            fb_patch(
                workschedule_v2_path("status", date_text, safe_emp_id),
                {
                    "status": "tentative" if tentative else "confirmed",
                    "state": "shift",
                    "confirmed": not tentative,
                    "tentative": tentative,
                    "updated_at_ms": now,
                    "source": "storebot_codex_schedule_upsert",
                },
            )
            verification = verify_schedule_upsert_write(
                emp_id,
                date_text,
                schedule,
                tentative=tentative,
                is_last_shift=is_last_shift,
            )
        writes.append(
            {
                "date": date_text,
                "employee_id": emp_id,
                "employee": emp.get("name") or emp.get("short_name") or emp_id,
                "name": emp.get("name") or emp.get("short_name") or emp_id,
                "start": start,
                "end": end,
                "role": role,
                "status": "tentative" if tentative else "confirmed",
                "employee_created": employee_created,
                "last_shift": is_last_shift,
                "last_work_date": date_text if is_last_shift else "",
                **verification,
            }
        )
    employee_patch: dict[str, Any] = {}
    if is_last_shift:
        last_date = max(dates)
        employee_patch = {
            "last_work_date": last_date,
            "last_shift_note": last_shift_note,
            "last_shift_source": "storebot_codex_schedule_upsert",
            "updated_at_ms": now_ms(),
        }
        if not dry_run:
            fb_patch(workschedule_v2_path("employees", sanitize_key(emp_id)), employee_patch)
    return {
        "ok": True,
        "operation": "schedule.upsert_shift",
        "dry_run": dry_run,
        "employee_created": employee_created,
        "employee_id": emp_id,
        "employee": emp.get("name") or emp.get("short_name") or emp_id,
        "name": emp.get("name") or emp.get("short_name") or emp_id,
        "date": dates[0] if len(dates) == 1 else "",
        "dates": dates,
        "start": start,
        "end": end,
        "role": role,
        "verified": False if dry_run else all(bool(write.get("verified")) for write in writes),
        "last_shift": is_last_shift,
        "employee_patch": employee_patch,
        "writes": writes,
    }


def execute_schedule_off(action: dict[str, Any]) -> dict[str, Any]:
    employees = fetch_employees()
    emp_id, emp = find_employee(action, employees)
    dates = [validate_date_text(value) for value in as_list(action.get("dates") or action.get("date"))]
    if not dates:
        raise WorkerError("date missing")
    dry_run = bool(action.get("dry_run"))
    require_workschedule_v2_write_ready(dry_run)
    writes = []
    for date_text in dates:
        if not dry_run:
            safe_emp_id = sanitize_key(emp_id)
            now = now_ms()
            fb_put(
                workschedule_v2_path("overrides", date_text, safe_emp_id),
                {
                    "state": "off",
                    "off": True,
                    "dayoff": True,
                    "work": False,
                    "source": "storebot_codex_schedule_off",
                    "updated_at_ms": now,
                },
            )
            fb_patch(
                workschedule_v2_path("status", date_text, safe_emp_id),
                {
                    "status": "off",
                    "state": "off",
                    "confirmed": True,
                    "updated_at_ms": now,
                    "source": "storebot_codex_schedule_off",
                },
            )
        writes.append({"date": date_text, "employee_id": emp_id, "employee": emp.get("name") or emp_id, "off": True})
    return {"ok": True, "operation": "schedule.off", "dry_run": dry_run, "writes": writes}


def execute_schedule_clear(action: dict[str, Any]) -> dict[str, Any]:
    employees = fetch_employees()
    emp_id, emp = find_employee(action, employees)
    dates = [validate_date_text(value) for value in as_list(action.get("dates") or action.get("date"))]
    if not dates:
        raise WorkerError("date missing")
    dry_run = bool(action.get("dry_run"))
    require_workschedule_v2_write_ready(dry_run)
    writes = []
    for date_text in dates:
        if not dry_run:
            safe_emp_id = sanitize_key(emp_id)
            now = now_ms()
            fb_put(
                workschedule_v2_path("overrides", date_text, safe_emp_id),
                {
                    "state": "clear",
                    "clear": True,
                    "work": False,
                    "off": False,
                    "source": "storebot_codex_schedule_clear",
                    "updated_at_ms": now,
                },
            )
            fb_patch(
                workschedule_v2_path("status", date_text, safe_emp_id),
                {
                    "status": "clear",
                    "state": "clear",
                    "updated_at_ms": now,
                    "source": "storebot_codex_schedule_clear",
                },
            )
        writes.append({"date": date_text, "employee_id": emp_id, "employee": emp.get("name") or emp_id, "cleared": True})
    return {"ok": True, "operation": "schedule.clear", "dry_run": dry_run, "writes": writes}


def is_confirmed_schedule_allowed_target(path: Any) -> bool:
    text = "/" + str(path or "").strip().strip("/")
    return any(text == target or text.startswith(target + "/") for target in CONFIRMED_SCHEDULE_ALLOWED_WRITE_TARGETS)


def is_legacy_schedule_target(path: Any) -> bool:
    text = "/" + str(path or "").strip().strip("/")
    return (
        text == "/workschedule"
        or text.startswith("/workschedule/")
        or text == "/workschedule_v2/attendance"
        or text.startswith("/workschedule_v2/attendance/")
        or text == "/packhelper/storebot_attendance"
        or text.startswith("/packhelper/storebot_attendance/")
    )


def iter_confirmed_schedule_target_paths(request: dict[str, Any]) -> list[str]:
    keys = (
        "target_paths",
        "adapter_allowed_targets",
        "allowed_write_targets",
        "write_paths",
        "write_targets",
        "target_path",
        "write_path",
        "planned_write_target",
        "write_target",
    )
    paths: list[str] = []
    for key in keys:
        value = request.get(key)
        if value is None:
            continue
        values: list[Any]
        if isinstance(value, dict):
            values = list(value.values())
        elif isinstance(value, (list, tuple, set)):
            values = list(value)
        else:
            values = [value]
        for item in values:
            text = str(item or "").strip()
            if text:
                paths.append(text)
    return paths


def normalize_confirmed_schedule_action(action: Any) -> str:
    text = str(action or "").strip().lower()
    if text in {"shift", "upsert_shift", "schedule.upsert", "schedule.upsert_shift", "schedule.set_shift", "work_schedule.upsert"}:
        return "schedule.upsert_shift"
    if text in {"off", "dayoff", "schedule.off", "work_schedule.off"}:
        return "schedule.off"
    if text in {"clear", "schedule.clear", "work_schedule.clear"}:
        return "schedule.clear"
    raise WorkerError(f"unsupported confirmed schedule action: {text}")


def parse_confirmed_shift_text(value: Any) -> tuple[str, str]:
    text = compact_text(value, 60)
    match = re.fullmatch(
        r"\s*([01]?\d|2[0-3])(?::?([0-5]\d))?\s*(?:시)?\s*[-~–—]\s*"
        r"([01]?\d|2[0-3])(?::?([0-5]\d))?\s*(?:시)?\s*",
        text,
    )
    if not match:
        raise WorkerError(f"invalid shift: {text}")
    start = f"{int(match.group(1)):02d}:{match.group(2) or '00'}"
    end = f"{int(match.group(3)):02d}:{match.group(4) or '00'}"
    return validate_time_text(start), validate_time_text(end)


def confirmed_schedule_request_dry_run(request: dict[str, Any]) -> bool:
    dry_run_present = "dry_run" in request
    dry_run = truthy(request.get("dry_run")) if dry_run_present else not truthy(request.get("execute_live_write"))
    execute_live_write = truthy(request.get("execute_live_write"))
    if dry_run and execute_live_write:
        raise WorkerError("confirmed schedule request has conflicting dry_run and execute_live_write")
    if not dry_run and not execute_live_write:
        raise WorkerError("confirmed schedule live dispatch requires execute_live_write=true")
    if not dry_run and truthy(request.get("no_live_write")):
        raise WorkerError("confirmed schedule live dispatch blocked by no_live_write")
    return dry_run


def validate_confirmed_schedule_write_request(request: dict[str, Any]) -> dict[str, Any]:
    if not isinstance(request, dict):
        raise WorkerError("confirmed schedule request must be an object")
    request_type = str(request.get("request_type") or request.get("type") or "").strip().lower()
    if request_type not in {
        CONFIRMED_SCHEDULE_WRITE_REQUEST_TYPE,
        "confirmed_schedule.write",
        "schedule.confirmed_write",
    }:
        raise WorkerError(f"invalid confirmed schedule request_type: {request_type}")

    missing = []
    for field in CONFIRMED_SCHEDULE_REQUIRED_FIELDS:
        if field not in request or request.get(field) is None or str(request.get(field)).strip() == "":
            missing.append(field)
    if missing:
        raise WorkerError("confirmed schedule request missing fields: " + ", ".join(missing))

    confirmation_state = str(request.get("confirmation_state") or "").strip().lower()
    if confirmation_state in {"needs_user_confirmation", "not_confirmed", "pending_confirmation"}:
        raise WorkerError("confirmed schedule request is not confirmed")
    if truthy(request.get("preview_only")) or str(request.get("write_status") or "") == "blocked_until_confirmed":
        raise WorkerError("preview schedule request cannot dispatch")

    confirmed_at_ms = safe_int(request.get("confirmed_at_ms"))
    if confirmed_at_ms <= 0:
        raise WorkerError("confirmed_at_ms missing")
    dry_run_result = request.get("dry_run_result")
    if isinstance(dry_run_result, dict) and dry_run_result.get("ok") is False:
        raise WorkerError("dry_run_result is not ok")

    targets = iter_confirmed_schedule_target_paths(request)
    for target in targets:
        if is_legacy_schedule_target(target):
            raise WorkerError(f"confirmed schedule target forbidden: {target}")
        if not is_confirmed_schedule_allowed_target(target):
            raise WorkerError(f"confirmed schedule target not canonical: {target}")

    date_text = validate_date_text(request.get("date"))
    employee = compact_text(request.get("employee"), 80)
    if not employee:
        raise WorkerError("employee missing")
    action_type = normalize_confirmed_schedule_action(request.get("action"))
    dry_run = confirmed_schedule_request_dry_run(request)
    return {
        "request_type": CONFIRMED_SCHEDULE_WRITE_REQUEST_TYPE,
        "request_id": compact_text(request.get("request_id"), 120),
        "source_event_id": compact_text(request.get("source_event_id"), 120),
        "actor": compact_text(request.get("actor"), 80),
        "confirmed_at_ms": confirmed_at_ms,
        "date": date_text,
        "employee": employee,
        "action_type": action_type,
        "dry_run": dry_run,
    }


def confirmed_schedule_write_request_to_action(request: dict[str, Any]) -> dict[str, Any]:
    meta = validate_confirmed_schedule_write_request(request)
    action: dict[str, Any] = {
        "type": meta["action_type"],
        "date": meta["date"],
        "employee": meta["employee"],
        "dry_run": meta["dry_run"],
        "source": "storebot_termux_confirmed_schedule_image",
        "source_event_id": meta["source_event_id"],
        "confirmation_actor": meta["actor"],
        "confirmed_at_ms": meta["confirmed_at_ms"],
    }
    if meta["action_type"] == "schedule.upsert_shift":
        start = compact_text(request.get("start") or request.get("start_time"), 20)
        end = compact_text(request.get("end") or request.get("end_time"), 20)
        if (not start or not end) and compact_text(request.get("shift"), 60):
            start, end = parse_confirmed_shift_text(request.get("shift"))
        if not start or not end:
            raise WorkerError("shift missing for confirmed schedule upsert")
        action["start"] = validate_time_text(start)
        action["end"] = validate_time_text(end)
        if compact_text(request.get("role"), 40):
            action["role"] = compact_text(request.get("role"), 40)
    elif meta["action_type"] == "schedule.off":
        if not truthy(request.get("off")):
            raise WorkerError("off missing for confirmed schedule off")
        action["off"] = True
    elif meta["action_type"] == "schedule.clear":
        if not truthy(request.get("clear")):
            raise WorkerError("clear missing for confirmed schedule clear")
        action["clear"] = True
    return action


def execute_confirmed_schedule_write_request(
    request: dict[str, Any],
    req_id: str = "",
    args: argparse.Namespace | None = None,
) -> dict[str, Any]:
    action = confirmed_schedule_write_request_to_action(request)
    schedule_result = execute_one_action(action, req_id=req_id, args=args)
    return {
        **schedule_result,
        "operation": CONFIRMED_SCHEDULE_WRITE_REQUEST_TYPE,
        "schedule_operation": schedule_result.get("operation"),
        "confirmed_request_validated": True,
        "source_event_id": action.get("source_event_id"),
        "confirmation_actor": action.get("confirmation_actor"),
        "confirmed_at_ms": action.get("confirmed_at_ms"),
        "canonical_write_targets": list(CONFIRMED_SCHEDULE_ALLOWED_WRITE_TARGETS),
        "confirmed_request_queue_path": CONFIRMED_SCHEDULE_WRITE_REQUEST_QUEUE_PATH,
    }


WEEKDAY_EN_BY_WEB_DAY = {
    0: "sun",
    1: "mon",
    2: "tue",
    3: "wed",
    4: "thu",
    5: "fri",
    6: "sat",
}
DOW_KR_BY_WEEKDAY = ["월", "화", "수", "목", "금", "토", "일"]
DOW_KR_TO_WEEKDAY = {
    "월": 0,
    "월요일": 0,
    "화": 1,
    "화요일": 1,
    "수": 2,
    "수요일": 2,
    "목": 3,
    "목요일": 3,
    "금": 4,
    "금요일": 4,
    "토": 5,
    "토요일": 5,
    "일": 6,
    "일요일": 6,
}
EN_WEEKDAY_TO_WEEKDAY = {
    "monday": 0,
    "tuesday": 1,
    "wednesday": 2,
    "thursday": 3,
    "friday": 4,
    "saturday": 5,
    "sunday": 6,
}


def web_day_for_date(date_text: str) -> int:
    day = datetime.strptime(date_text, "%Y-%m-%d").date()
    return (day.weekday() + 1) % 7


def employee_cutoff_date(emp: dict[str, Any]) -> str:
    for key in (
        "last_work_date",
        "employment_cutoff",
        "employment_cutoff_date",
        "employment_end_date",
        "end_date",
    ):
        text = str(emp.get(key) or "").strip()
        if re.fullmatch(r"\d{4}-\d{2}-\d{2}", text):
            try:
                return validate_date_text(text)
            except WorkerError:
                continue
    return ""


def employee_active_for_schedule_date(emp: dict[str, Any], date_text: str) -> bool:
    cutoff = employee_cutoff_date(emp)
    return not cutoff or date_text <= cutoff


def employee_schedule_keys(emp_id: str, emp: dict[str, Any]) -> list[str]:
    keys: list[str] = []
    for label in [emp_id, emp.get("name"), emp.get("short_name"), emp.get("nickname")]:
        text = str(label or "").strip()
        if text:
            keys.extend([text, sanitize_key(text)])
    aliases = emp.get("aliases")
    if isinstance(aliases, list):
        for alias in aliases:
            text = str(alias or "").strip()
            if text:
                keys.extend([text, sanitize_key(text)])
    return list(dict.fromkeys(keys))


def fixed_schedule_for(emp_id: str, emp: dict[str, Any], date_text: str, fixed_schedules: dict[str, Any]) -> dict[str, Any] | None:
    emp_name = str(emp.get("name") or "").strip()
    if not isinstance(fixed_schedules, dict):
        return None

    fixed = fixed_schedules.get(emp_id)
    if not isinstance(fixed, dict) and emp_name:
        fixed = fixed_schedules.get(sanitize_key(emp_name))
    if not isinstance(fixed, dict):
        fixed = fixed_schedules.get(emp_name)
    if not isinstance(fixed, dict):
        return None

    web_day = web_day_for_date(date_text)
    day_code = WEEKDAY_EN_BY_WEB_DAY.get(web_day, "")
    schedule_type = str(fixed.get("kind") or fixed.get("type") or "fixed").strip()
    if schedule_type == "none":
        return None
    default_start = str(fixed.get("start") or "").strip()
    default_end = str(fixed.get("end") or "").strip()
    default_role = str(fixed.get("role") or emp.get("role") or "주방").strip() or "주방"
    day_times = fixed.get("dayTimes")
    override = day_times.get(day_code) if isinstance(day_times, dict) and day_code else None
    if not isinstance(override, dict):
        override = None

    if schedule_type == "fixed":
        off_days = fixed.get("off")
        if isinstance(off_days, list) and any(safe_int(day, -1) == web_day for day in off_days):
            return None
        start = str((override or {}).get("start") or default_start).strip()
        end = str((override or {}).get("end") or default_end).strip()
        if not start and not end:
            return None
        role = str((override or {}).get("role") or default_role).strip() or default_role
        return {"start": start, "end": end, "role": role}

    if schedule_type == "weekly":
        days = fixed.get("days")
        match = isinstance(days, list) and day_code in [str(day or "").strip() for day in days]
        if not match and override is not None:
            match = True
        if not match:
            return None
        start = str((override or {}).get("start") or default_start).strip()
        end = str((override or {}).get("end") or default_end).strip()
        if not start and not end:
            return None
        role = str((override or {}).get("role") or default_role).strip() or default_role
        return {"start": start, "end": end, "role": role}

    return None


def row_from_weekly_template_value(value: Any, emp: dict[str, Any]) -> dict[str, Any] | None:
    if isinstance(value, str):
        match = re.search(r"(\d{1,2}:\d{2})\s*[~-]\s*(\d{1,2}:\d{2})", value)
        if not match:
            return None
        return {
            "start": validate_time_text(match.group(1)),
            "end": validate_time_text(match.group(2)),
            "role": str(emp.get("role") or "주방").strip() or "주방",
        }
    if not isinstance(value, dict):
        return None
    try:
        start = validate_time_text(value.get("start") or value.get("start_time"), allow_empty=True)
        end = validate_time_text(value.get("end") or value.get("end_time"), allow_empty=True)
    except WorkerError:
        return None
    if not start and not end:
        return None
    return {
        "start": start,
        "end": end,
        "role": str(value.get("role") or emp.get("role") or "주방").strip() or "주방",
        "status": str(value.get("status") or "").strip(),
        "tentative": bool(value.get("tentative")),
    }


def weekly_template_for(
    emp_id: str,
    emp: dict[str, Any],
    date_text: str,
    weekly_template: dict[str, Any],
) -> dict[str, Any] | None:
    if not isinstance(weekly_template, dict):
        return None
    day_code = WEEKDAY_EN_BY_WEB_DAY.get(web_day_for_date(date_text), "")
    if not day_code:
        return None

    for key in employee_schedule_keys(emp_id, emp):
        entry = weekly_template.get(key)
        if isinstance(entry, dict):
            if entry.get("type") in {"fixed", "weekly"} or "days" in entry or "dayTimes" in entry:
                fixed_like = fixed_schedule_for(emp_id, emp, date_text, {str(emp.get("name") or key): entry})
                if fixed_like:
                    return fixed_like
            day_entry = entry.get(day_code)
            row = row_from_weekly_template_value(day_entry, emp)
            if row:
                return row

    day_bucket = weekly_template.get(day_code)
    if isinstance(day_bucket, dict):
        for key in employee_schedule_keys(emp_id, emp):
            row = row_from_weekly_template_value(day_bucket.get(key), emp)
            if row:
                return row
    elif isinstance(day_bucket, list):
        employee_norms = {normalize_key_text(key) for key in employee_schedule_keys(emp_id, emp)}
        for item in day_bucket:
            if not isinstance(item, dict):
                continue
            item_emp = str(item.get("employee_id") or item.get("emp_id") or item.get("employee") or item.get("name") or "").strip()
            if normalize_key_text(item_emp) not in employee_norms:
                continue
            row = row_from_weekly_template_value(item, emp)
            if row:
                return row
    return None


def fixed_schedule_is_off(emp_id: str, emp: dict[str, Any], date_text: str, fixed_schedules: dict[str, Any]) -> bool:
    emp_name = str(emp.get("name") or "").strip()
    if not isinstance(fixed_schedules, dict):
        return False

    fixed = fixed_schedules.get(emp_id)
    if not isinstance(fixed, dict) and emp_name:
        fixed = fixed_schedules.get(sanitize_key(emp_name))
    if not isinstance(fixed, dict):
        fixed = fixed_schedules.get(emp_name)
    if not isinstance(fixed, dict):
        return False

    if str(fixed.get("kind") or fixed.get("type") or "").strip() != "fixed":
        return False
    off_days = fixed.get("off")
    if not isinstance(off_days, list):
        return False
    web_day = web_day_for_date(date_text)
    return any(safe_int(day, -1) == web_day for day in off_days)


def schedule_status_value(value: Any) -> str:
    if isinstance(value, dict):
        raw = value.get("status") or value.get("state") or value.get("type") or ""
    else:
        raw = value
    return str(raw or "").strip().lower()


def schedule_status_is_off(value: Any) -> bool:
    return schedule_status_value(value) in {"off", "dayoff"}


def schedule_status_is_none(value: Any) -> bool:
    return schedule_status_value(value) == "none"


def schedule_status_is_last_shift(value: Any) -> bool:
    normalized = schedule_status_value(value)
    if normalized == "last_shift":
        return True
    if isinstance(value, dict):
        return bool(value.get("last_shift") is True or value.get("is_last_shift") is True)
    return False


def schedule_off_row(emp_id: str, emp: dict[str, Any], origin: str, status_value: str = "") -> dict[str, Any]:
    row = {
        "employee_id": emp_id,
        "employee": emp.get("name") or emp.get("short_name") or emp_id,
        "off": True,
        "source": origin,
    }
    if status_value:
        row["status"] = status_value
    return row


def schedule_row_from_source(emp_id: str, emp: dict[str, Any], source: dict[str, Any], origin: str) -> dict[str, Any]:
    return {
        "employee_id": emp_id,
        "employee": emp.get("name") or emp.get("short_name") or emp_id,
        "start": str(source.get("start") or "").strip(),
        "end": str(source.get("end") or "").strip(),
        "role": str(source.get("role") or emp.get("role") or "주방").strip(),
        "status": str(source.get("status") or "").strip(),
        "tentative": bool(source.get("tentative")),
        "source": origin,
    }


def schedule_row_from_v2_override(emp_id: str, emp: dict[str, Any], value: Any) -> dict[str, Any] | None:
    if value is False:
        return None
    if not isinstance(value, dict):
        return None
    state = str(value.get("state") or value.get("type") or "").strip().lower()
    if state == "off" or value.get("off") is True or value.get("dayoff") is True:
        return schedule_off_row(emp_id, emp, "overrides")
    if state == "clear" or value.get("clear") is True:
        return None
    shift = value.get("shift") if isinstance(value.get("shift"), dict) else value
    if isinstance(shift, dict) and (shift.get("start") or shift.get("end") or shift.get("role")):
        return schedule_row_from_source(emp_id, emp, shift, "overrides")
    return None


def apply_schedule_status_to_row(row: dict[str, Any] | None, status_entry: Any) -> dict[str, Any] | None:
    if not isinstance(row, dict):
        return row
    updated = dict(row)
    status_value = schedule_status_value(status_entry)
    if status_value and status_value not in {"auto", "clear", "shift", "manual_shift"}:
        updated["status"] = status_value
    elif status_value == "confirmed":
        updated["status"] = "confirmed"
    if schedule_status_is_last_shift(status_entry):
        updated["last_shift"] = True
        if isinstance(status_entry, dict):
            note = compact_text(status_entry.get("note") or status_entry.get("memo") or "", 120)
            if note:
                updated["note"] = note
    return updated


def resolve_schedule_query_row(
    emp_id: str,
    emp: dict[str, Any],
    date_text: str,
    overrides: dict[str, Any],
    fixed_schedules: dict[str, Any],
    status_rows: dict[str, Any],
) -> dict[str, Any] | None:
    override = overrides.get(emp_id) if isinstance(overrides, dict) else None
    status_entry = status_rows.get(emp_id) if isinstance(status_rows, dict) else None
    status_value = schedule_status_value(status_entry)

    row = schedule_row_from_v2_override(emp_id, emp, override)
    if row:
        return apply_schedule_status_to_row(row, status_entry)
    if schedule_status_is_off(status_entry):
        return schedule_off_row(emp_id, emp, "status", status_value)
    if schedule_status_is_none(status_entry):
        return None

    if isinstance(override, dict) and str(override.get("state") or "").strip().lower() in {"off", "clear"}:
        if str(override.get("state") or "").strip().lower() == "off":
            return schedule_off_row(emp_id, emp, "overrides", status_value or "off")
        return None
    if fixed_schedule_is_off(emp_id, emp, date_text, fixed_schedules if isinstance(fixed_schedules, dict) else {}):
        return apply_schedule_status_to_row(schedule_off_row(emp_id, emp, "fixed_schedules"), status_entry)
    fixed = fixed_schedule_for(emp_id, emp, date_text, fixed_schedules if isinstance(fixed_schedules, dict) else {})
    if fixed:
        return apply_schedule_status_to_row(schedule_row_from_source(emp_id, emp, fixed, "fixed_schedules"), status_entry)
    return None


def execute_schedule_query(action: dict[str, Any]) -> dict[str, Any]:
    employees_raw = read_workschedule_v2_source(workschedule_v2_path("employees")) or {}
    employees = employees_raw if isinstance(employees_raw, dict) else {}
    date_values = [validate_date_text(value) for value in as_list(action.get("dates") or action.get("date"))]
    emp_filter = None
    if action.get("employee") or action.get("employee_id"):
        emp_filter = find_employee(action, employees)[0]
    if not date_values:
        start_offset = max(0, safe_int(action.get("start_offset_days"), 0))
        requested_count = min(
            max(1, safe_int(action.get("day_count"), DEFAULT_SCHEDULE_IMAGE_DAY_COUNT)),
            MAX_SCHEDULE_QUERY_DAY_COUNT,
        )
        date_values = work_schedule_operational_dates(start_offset, requested_count)

    fixed_schedules = read_workschedule_v2_source(workschedule_v2_path("fixed_schedules")) or {}
    result_days: list[dict[str, Any]] = []
    for date_text in date_values:
        overrides = read_workschedule_v2_source(workschedule_v2_path("overrides", date_text)) or {}
        status_rows = read_workschedule_v2_source(workschedule_v2_path("status", date_text)) or {}
        rows: list[dict[str, Any]] = []
        for emp_id, emp in active_employee_items(employees):
            if emp_filter and emp_id != emp_filter:
                continue
            if not employee_active_for_schedule_date(emp, date_text):
                continue
            row = resolve_schedule_query_row(emp_id, emp, date_text, overrides, fixed_schedules, status_rows)
            if row:
                rows.append(row)
        result_days.append({"date": date_text, "rows": rows})
    return {
        "ok": True,
        "operation": "schedule.query",
        "source": WORKSCHEDULE_V2_PATH,
        "source_error_code": "",
        "days": result_days,
    }


def should_build_schedule_image_request(item: dict[str, Any], answer: str) -> bool:
    if bool(item.get("no_native_image") or item.get("no_image")):
        return False
    if str(answer or "").strip() == "SKIP":
        return False
    if is_schedule_attendance_event(item):
        return False
    event_kind = str(item.get("event_kind") or "")
    if event_kind in SCHEDULE_IMAGE_EVENT_KINDS:
        return True
    payload = item.get("payload")
    if isinstance(payload, dict) and payload.get("native_image") is True:
        return True
    payload = item.get("payload")
    primary_request_values: list[str] = []
    for part in (
        item.get("message"),
        item.get("text"),
        payload.get("message") if isinstance(payload, dict) else "",
        payload.get("query") if isinstance(payload, dict) else "",
    ):
        text = str(part or "").strip()
        if text and text not in primary_request_values:
            primary_request_values.append(text)
    primary_request_text = "\n".join(primary_request_values).strip()
    request_text = "\n".join(
        str(part or "")
        for part in (
            primary_request_text,
            event_kind,
        )
    ).strip()
    haystack = "\n".join(part for part in (str(answer or "").strip(), request_text) if part)
    schedule_like = re.search(r"근무표|스케줄|근무|출근\s*(현황|조회|리스트)", haystack) is not None
    image_like = re.search(r"이미지|사진|표로|보기좋|깔끔|정렬|카드", haystack) is not None
    briefing_like = re.search(
        r"브리핑|출력|조회|현황|전체|이번주|다음주|오늘|내일|기간|날씨|뉴스|스포츠|월드컵|공휴일|보여줘|정리|리스트|보낼|전송",
        haystack,
    ) is not None
    plain_schedule_request = any(
        re.search(r"^\s*(근무|근무표|스케줄)\s*$", value) is not None
        for value in primary_request_values
    )
    explicit_schedule_date_request = (
        re.search(r"근무표|스케줄|출근\s*(현황|조회|리스트)|근무\s*(조회|리스트|현황|보여)", primary_request_text) is not None
    ) and (
        schedule_image_date_offset_days(primary_request_text) is not None
        or schedule_image_weekday_offset_days(primary_request_text) is not None
        or re.search(r"오늘|내일|모레|today|tomorrow", primary_request_text, flags=re.IGNORECASE) is not None
    )
    multiline_schedule = schedule_like and len([line for line in str(answer or "").splitlines() if line.strip()]) >= 3
    row_like = re.search(r"(?m)^\s*[-*•]?\s*[가-힣A-Za-z0-9]{1,12}\s+\d{1,2}:\d{2}\s*[~-]", str(answer or "")) is not None
    return schedule_like and (image_like or briefing_like or plain_schedule_request or explicit_schedule_date_request or multiline_schedule or row_like)


def parse_image_send_enabled(value: Any) -> bool:
    if value is None:
        return True
    if isinstance(value, bool):
        return value
    text = str(value).strip().casefold()
    if not text or text == "null":
        return True
    return text not in {"false", "0", "off", "disabled", "pause", "paused"}


def normalize_image_send_mode(value: Any) -> str:
    text = str(value or "").strip().casefold()
    if text in {"off", "false", "0", "disabled", "pause", "paused"}:
        return "off"
    if text in {"on", "true", "1", "enabled", "force"}:
        return "on"
    return "auto"


def normalize_thermal_state(value: Any) -> str:
    text = str(value or "").strip().casefold().replace("_", "-")
    if text in {"normal", "caution", "hot-risk", "unknown"}:
        return text
    if text in {"hot", "risk", "hotrisk", "overheat", "overheating", "critical"}:
        return "hot-risk"
    if text in {"warm", "warning", "moderate"}:
        return "caution"
    return "unknown"


def storebot_image_send_config(force_refresh: bool = False) -> dict[str, Any]:
    env_value = os.environ.get("STOREBOT_IMAGE_SEND_ENABLED")
    if env_value is not None and env_value.strip():
        enabled = parse_image_send_enabled(env_value)
        mode = normalize_image_send_mode(os.environ.get("STOREBOT_IMAGE_SEND_MODE"))
        thermal_state = normalize_thermal_state(os.environ.get("STOREBOT_THERMAL_STATE"))
        return {
            "enabled": enabled,
            "pause_reason": "" if enabled else os.environ.get("STOREBOT_IMAGE_SEND_PAUSE_REASON", "env_pause"),
            "mode": mode,
            "thermal_state": thermal_state,
            "source": "env",
        }

    now = time.monotonic()
    with _IMAGE_SEND_CONFIG_LOCK:
        if (
            not force_refresh
            and now - float(_IMAGE_SEND_CONFIG_CACHE.get("at") or 0.0) < IMAGE_SEND_CONFIG_CACHE_SEC
        ):
            return {
                "enabled": bool(_IMAGE_SEND_CONFIG_CACHE.get("enabled", True)),
                "pause_reason": str(_IMAGE_SEND_CONFIG_CACHE.get("pause_reason") or ""),
                "mode": str(_IMAGE_SEND_CONFIG_CACHE.get("mode") or "auto"),
                "thermal_state": str(_IMAGE_SEND_CONFIG_CACHE.get("thermal_state") or "unknown"),
                "source": "cache",
            }

    enabled = True
    pause_reason = ""
    mode = "auto"
    thermal_state = "unknown"
    source = "firebase"
    try:
        enabled = parse_image_send_enabled(fb_get_timeout(IMAGE_SEND_ENABLED_PATH, timeout=2))
    except Exception as exc:
        source = "default_on_enabled_read_error"
        log(f"image_send_enabled read failed; default enabled: {compact_error(str(exc), 160)}")
        enabled = True

    if not enabled:
        try:
            pause_reason = str(fb_get_timeout(IMAGE_SEND_PAUSE_REASON_PATH, timeout=2) or "").strip()
        except Exception as exc:
            log(f"image_send_pause_reason read failed: {compact_error(str(exc), 160)}")

    try:
        mode = normalize_image_send_mode(fb_get_timeout(IMAGE_SEND_MODE_PATH, timeout=2))
    except Exception as exc:
        if source == "firebase":
            source = "firebase_partial_default_policy"
        log(f"image_send_mode read failed; default auto: {compact_error(str(exc), 160)}")
        mode = "auto"

    try:
        thermal_state = normalize_thermal_state(fb_get_timeout(THERMAL_STATE_PATH, timeout=2))
    except Exception as exc:
        if source == "firebase":
            source = "firebase_partial_default_policy"
        log(f"thermal_state read failed; default unknown: {compact_error(str(exc), 160)}")
        thermal_state = "unknown"

    with _IMAGE_SEND_CONFIG_LOCK:
        _IMAGE_SEND_CONFIG_CACHE.update(
            {
                "at": time.monotonic(),
                "enabled": enabled,
                "pause_reason": pause_reason,
                "mode": mode,
                "thermal_state": thermal_state,
            }
        )
    return {
        "enabled": enabled,
        "pause_reason": pause_reason,
        "mode": mode,
        "thermal_state": thermal_state,
        "source": source,
    }


def image_send_emergency_kill_active(image_config: dict[str, Any]) -> bool:
    if bool(image_config.get("enabled", True)):
        return False
    reason = str(image_config.get("pause_reason") or "").strip().casefold().replace("_", "-")
    if not reason:
        return False
    return any(
        token in reason
        for token in (
            "emergency",
            "kill",
            "panic",
            "critical",
            "hot-risk",
            "overheat",
            "overheating",
        )
    )


def schedule_image_policy_prebuild_suppression(image_config: dict[str, Any]) -> tuple[str, str]:
    mode = normalize_image_send_mode(image_config.get("mode"))
    thermal_state = normalize_thermal_state(image_config.get("thermal_state"))
    if image_send_emergency_kill_active(image_config):
        return "image_send_emergency_kill", str(image_config.get("pause_reason") or "image_send_enabled=false")
    if mode == "off":
        return "image_send_mode_off", "image_send_mode=off"
    if mode == "auto" and thermal_state == "hot-risk":
        return "image_thermal_hot_risk", "thermal_state=hot-risk"
    return "", ""


def schedule_image_dedupe_ttl_sec(image_config: dict[str, Any]) -> float:
    mode = normalize_image_send_mode(image_config.get("mode"))
    thermal_state = normalize_thermal_state(image_config.get("thermal_state"))
    if mode == "auto" and thermal_state == "caution":
        return SCHEDULE_IMAGE_REQUEST_CAUTION_COOLDOWN_SEC
    return SCHEDULE_IMAGE_REQUEST_DEDUPE_TTL_SEC


def schedule_image_dedupe_reason(image_config: dict[str, Any]) -> str:
    mode = normalize_image_send_mode(image_config.get("mode"))
    thermal_state = normalize_thermal_state(image_config.get("thermal_state"))
    if mode == "auto" and thermal_state == "caution":
        return "image_auto_caution_cooldown"
    return "image_request_dedupe"


def normalize_schedule_image_dedupe_text(value: Any) -> str:
    clean = str(value or "")
    for marker in ("\u200b", "\u200c", "\u200d"):
        clean = clean.replace(marker, " ")
    return re.sub(r"\s+", " ", clean).strip().casefold()[:160]


def schedule_image_scalar(value: Any) -> str:
    if value is None:
        return ""
    if isinstance(value, bool):
        return "true" if value else "false"
    return str(value).strip()


def append_schedule_image_date_key(dates: list[str], value: Any) -> None:
    text = schedule_image_scalar(value)
    if text and text not in dates:
        dates.append(text)


def append_schedule_image_date_values(dates: list[str], values: Any, *, limit: int) -> None:
    if not isinstance(values, list):
        return
    for value in values[:limit]:
        if isinstance(value, dict):
            append_schedule_image_date_key(dates, value.get("date"))
        else:
            append_schedule_image_date_key(dates, value)


def schedule_image_request_date_key(payload: dict[str, Any]) -> str:
    dates: list[str] = []
    for key in ("target_date", "date", "week_start", "week_end", "start_date", "end_date", "range_start", "range_end"):
        append_schedule_image_date_key(dates, payload.get(key))
    append_schedule_image_date_values(dates, payload.get("dates"), limit=14)
    append_schedule_image_date_values(dates, payload.get("target_dates"), limit=14)
    append_schedule_image_date_values(dates, payload.get("days"), limit=8)
    day_count = schedule_image_scalar(payload.get("day_count"))
    start_offset = schedule_image_scalar(payload.get("start_offset_days"))
    suffix = f"count={day_count}|offset={start_offset}" if day_count or start_offset else ""
    return "|".join([*dates, suffix]).strip("|")


def schedule_image_request_dedupe_key(item: dict[str, Any], image_request: dict[str, Any]) -> str:
    if not isinstance(image_request, dict):
        return ""
    payload = image_request.get("payload") if isinstance(image_request.get("payload"), dict) else {}
    date_key = schedule_image_request_date_key(payload)
    text_parts = []
    if not date_key:
        text_parts = [
            item.get("message"),
            item.get("text"),
            payload.get("message"),
            payload.get("query"),
        ]
    normalized_text = "\n".join(
        part for part in (normalize_schedule_image_dedupe_text(value) for value in text_parts) if part
    )
    stable = "|".join(
        [
            str(item.get("room_name") or item.get("room") or item.get("room_id") or ""),
            normalized_text,
            schedule_image_scalar(image_request.get("type")),
            schedule_image_scalar(image_request.get("event_kind") or payload.get("event_kind")),
            schedule_image_scalar(payload.get("mode") or image_request.get("mode")),
            schedule_image_scalar(image_request.get("image_payload_source") or payload.get("days_selection_source")),
            date_key,
        ]
    )
    return f"image:{short_text_hash(stable)}:{compact_text(stable, 180)}"


def mark_schedule_image_request_duplicate(
    item: dict[str, Any],
    image_request: dict[str, Any],
    *,
    ttl_sec: float = SCHEDULE_IMAGE_REQUEST_DEDUPE_TTL_SEC,
) -> tuple[bool, str]:
    key = schedule_image_request_dedupe_key(item, image_request)
    if not key:
        return False, ""
    now = time.monotonic()
    ttl = max(1.0, float(ttl_sec or SCHEDULE_IMAGE_REQUEST_DEDUPE_TTL_SEC))
    with _SCHEDULE_IMAGE_REQUEST_DEDUPE_LOCK:
        for existing_key, seen_at in list(_SCHEDULE_IMAGE_REQUEST_DEDUPE.items()):
            if now - seen_at > max(SCHEDULE_IMAGE_REQUEST_DEDUPE_TTL_SEC, SCHEDULE_IMAGE_REQUEST_CAUTION_COOLDOWN_SEC):
                _SCHEDULE_IMAGE_REQUEST_DEDUPE.pop(existing_key, None)
        if key in _SCHEDULE_IMAGE_REQUEST_DEDUPE:
            if now - _SCHEDULE_IMAGE_REQUEST_DEDUPE[key] < ttl:
                return True, key
            _SCHEDULE_IMAGE_REQUEST_DEDUPE[key] = now
            return False, key
        _SCHEDULE_IMAGE_REQUEST_DEDUPE[key] = now
        return False, key


def suppress_schedule_image_pipeline(
    pipeline: dict[str, Any],
    reason: str,
    *,
    detail: str = "",
    dedupe_key: str = "",
) -> dict[str, Any]:
    updated = dict(pipeline)
    updated["answer"] = ""
    updated["skipped"] = True
    updated["output_category"] = "skip"
    updated["skip_reason"] = reason
    updated["image_request_suppressed"] = True
    updated["image_request_suppressed_reason"] = reason
    if detail:
        updated["image_request_suppressed_detail"] = detail
    if dedupe_key:
        updated["image_request_dedupe_key"] = dedupe_key
    return updated


def schedule_image_pending_reason(reason: str) -> str:
    if reason in {"image_request_dedupe", "image_auto_caution_cooldown"}:
        return "image_retry_cooldown"
    if reason in {"image_send_mode_off", "image_thermal_hot_risk", "image_send_emergency_kill"}:
        return "image_capture_or_generation_pending"
    return reason or "image_capture_or_generation_pending"


def mark_schedule_image_pending_pipeline(
    pipeline: dict[str, Any],
    reason: str,
    *,
    detail: str = "",
    dedupe_key: str = "",
) -> dict[str, Any]:
    updated = suppress_schedule_image_pipeline(pipeline, reason, detail=detail, dedupe_key=dedupe_key)
    pending_reason = schedule_image_pending_reason(reason)
    updated["output_category"] = "schedule_image_pending"
    updated["skip_reason"] = pending_reason
    updated["output_payload"] = {
        "reason": pending_reason,
        "image_request_suppressed_reason": reason,
        "image_pending": True,
        "retry_via": "work_schedule_broadcast_gate_or_image_retry",
    }
    if detail:
        updated["output_payload"]["detail"] = detail
    if dedupe_key:
        updated["output_payload"]["dedupe_key"] = dedupe_key
    return updated


def annotate_schedule_image_suppression(
    pipeline: dict[str, Any],
    result: ScheduleImageBuildResult,
) -> dict[str, Any]:
    if not result.suppressed_reason:
        return pipeline
    updated = dict(pipeline)
    updated["image_request_suppressed"] = True
    updated["image_request_suppressed_reason"] = result.suppressed_reason
    if result.suppressed_detail:
        updated["image_request_suppressed_detail"] = result.suppressed_detail
    if result.dedupe_key:
        updated["image_request_dedupe_key"] = result.dedupe_key
    return updated


def attach_image_request_suppression_metadata(target: dict[str, Any], source: dict[str, Any]) -> None:
    reason = str(source.get("image_request_suppressed_reason") or "")
    if not reason:
        return
    target["image_request_suppressed"] = True
    target["image_request_suppressed_reason"] = reason
    detail = str(source.get("image_request_suppressed_detail") or "")
    if detail:
        target["image_request_suppressed_detail"] = detail
    dedupe_key = str(source.get("image_request_dedupe_key") or "")
    if dedupe_key:
        target["image_request_dedupe_key"] = dedupe_key


def schedule_image_date_offset_days(text: str) -> int | None:
    match = re.search(r"(20\d{2})[-./](\d{1,2})[-./](\d{1,2})", text)
    if not match:
        return None
    date_text = f"{match.group(1)}-{int(match.group(2)):02d}-{int(match.group(3)):02d}"
    try:
        target = datetime.strptime(date_text, "%Y-%m-%d").replace(tzinfo=KST)
        today = work_schedule_operational_day_start()
        return int((target - today).total_seconds() // 86400)
    except Exception:
        return None


def schedule_image_weekday_offset_days(text: str) -> int | None:
    lower = text.lower()
    target_weekday: int | None = None
    for label, weekday in DOW_KR_TO_WEEKDAY.items():
        if len(label) == 1:
            matched = re.search(rf"(?<![가-힣]){re.escape(label)}(?![가-힣])", text) is not None
        else:
            matched = label in text
        if matched:
            target_weekday = weekday
            break
    if target_weekday is None:
        for label, weekday in EN_WEEKDAY_TO_WEEKDAY.items():
            if label in lower:
                target_weekday = weekday
                break
    if target_weekday is None:
        return None
    today_weekday = work_schedule_operational_day_start().weekday()
    offset = (target_weekday - today_weekday + 7) % 7
    if "다음주" in text or "next week" in lower:
        offset += 7
    return offset


def schedule_realtime_haystack(item: dict[str, Any], answer: str) -> str:
    payload = item.get("payload")
    return "\n".join(
        str(part or "")
        for part in (
            item.get("message"),
            item.get("text"),
            answer,
            payload.get("message") if isinstance(payload, dict) else "",
            payload.get("query") if isinstance(payload, dict) else "",
        )
    )


def schedule_weather_brief(day: dict[str, Any]) -> str:
    weather = str(day.get("weather") or "").strip()
    temp_min = day.get("temp_min")
    temp_max = day.get("temp_max")
    rain_probability = day.get("rain_probability")
    rain_mm = day.get("rain_mm")
    parts = []
    if weather:
        parts.append(weather)
    if temp_min is not None or temp_max is not None:
        parts.append(f"{temp_min if temp_min is not None else '?'}~{temp_max if temp_max is not None else '?'}도")
    if rain_probability is not None:
        parts.append(f"강수확률 {rain_probability}%")
    if rain_mm not in (None, "", 0, 0.0):
        parts.append(f"강수 {rain_mm}mm")
    return " / ".join(parts)


def schedule_news_payload_line(result: dict[str, Any]) -> str:
    title = str(result.get("title") or result.get("headline") or result.get("summary") or "").strip()
    source = str(result.get("source") or "").strip()
    if source and title.endswith(f" - {source}"):
        title = title[: -len(source) - 3].strip()
    title = re.sub(r"[\"'“”‘’]", "", title)
    title = re.sub(r"\s+", " ", title)
    title = re.sub(r"\s+-\s+[^-]{2,24}$", "", title).strip()
    title = title.strip(" \"'“”‘’")
    if not title:
        return ""
    # Schedule cards show the source headline itself. Do not ask the model to
    # rewrite it into a prediction or a summary for a future schedule date.
    return compact_text(title, 88).rstrip(" ,.;:…")


def schedule_news_lines_from_results(results: Any) -> list[str]:
    if not isinstance(results, list):
        return []
    lines: list[str] = []
    seen: set[str] = set()
    for result in results:
        if not isinstance(result, dict):
            continue
        line = schedule_news_payload_line(result)
        if not line or line in seen:
            continue
        lines.append(line)
        seen.add(line)
        if len(lines) >= 2:
            break
    return lines


def schedule_news_fresh_evidence(results: Any) -> list[dict[str, Any]]:
    if not isinstance(results, list):
        return []
    evidence: list[dict[str, Any]] = []
    for result in results[:2]:
        if not isinstance(result, dict):
            continue
        evidence.append(
            {
                "source": compact_text(result.get("source"), 40),
                "published_at_ms": normalize_ts_ms(result.get("published_at_ms") or 0),
                "occurred_at_ms": normalize_ts_ms(result.get("occurred_at_ms") or result.get("event_at_ms") or 0),
                "freshness_at_ms": normalize_ts_ms(result.get("freshness_at_ms") or 0),
                "freshness_time_field": str(result.get("freshness_time_field") or ""),
                "source_age_minutes": safe_int(result.get("source_age_minutes"), -1),
            }
        )
    return evidence


def attach_news_to_schedule_days(days: list[dict[str, Any]], news_lines: list[str]) -> None:
    if not days:
        return
    for day in days:
        if isinstance(day, dict):
            day.pop("news", None)
    clean_lines = [str(line or "").strip() for line in news_lines if str(line or "").strip()][:2]
    if not clean_lines:
        clean_lines = ["실시간 뉴스 조회 불가"]
    today_kst = datetime.now(KST).strftime("%Y-%m-%d")
    for day in days:
        if isinstance(day, dict) and (
            day.get("is_today") is True or str(day.get("date") or "").strip() == today_kst
        ):
            day["news"] = clean_lines
            break


def side_job_reference_line(raw: Any) -> str:
    if isinstance(raw, str):
        return compact_text(raw, 90)
    if not isinstance(raw, dict):
        return ""
    explicit = str(raw.get("text") or raw.get("summary") or "").strip()
    if explicit:
        return compact_text(explicit, 90)
    start = validate_time_text(raw.get("start") or raw.get("start_time"), allow_empty=True)
    end = validate_time_text(raw.get("end") or raw.get("end_time"), allow_empty=True)
    label = str(raw.get("label") or raw.get("place") or raw.get("location") or "다른곳").strip()
    note = str(raw.get("note") or raw.get("status") or "출근").strip()
    time_part = f"{start}~{end}" if start and end else start or end
    parts = [part for part in (label, time_part, note) if part]
    return compact_text(" ".join(parts), 90)


def weekly_reference_for_date(reference: dict[str, Any], date_text: str) -> Any:
    weekly = reference.get("weekly")
    if not isinstance(weekly, dict):
        return None
    try:
        date_obj = datetime.strptime(date_text, "%Y-%m-%d")
    except ValueError:
        return None
    weekday_labels = [
        DOW_KR_BY_WEEKDAY[date_obj.weekday()],
        DOW_KR_BY_WEEKDAY[date_obj.weekday()] + "요일",
        ["mon", "tue", "wed", "thu", "fri", "sat", "sun"][date_obj.weekday()],
        ["monday", "tuesday", "wednesday", "thursday", "friday", "saturday", "sunday"][date_obj.weekday()],
    ]
    for label in weekday_labels:
        raw = weekly.get(label)
        if raw is not None:
            return raw
    return None


def optional_time_or_default(value: Any, default: str) -> str:
    try:
        return validate_time_text(value, allow_empty=True) or default
    except WorkerError:
        return default


def cycle_reference_for_date(reference: dict[str, Any], date_text: str) -> Any:
    cycle = reference.get("cycle")
    if not isinstance(cycle, dict):
        return None
    if cycle.get("enabled") is False:
        return None
    cycle_type = str(cycle.get("type") or reference.get("cycle_type") or "").strip()
    if cycle_type not in {"continental_4_2_4_2", "jaehun_continental"}:
        return None
    try:
        target_date = datetime.strptime(date_text, "%Y-%m-%d").date()
        base_date = datetime.strptime(str(cycle.get("base_date") or "2026-06-01").strip(), "%Y-%m-%d").date()
    except ValueError:
        return None
    diff_days = (target_date - base_date).days
    if diff_days < 0:
        return None

    owner = str(reference.get("owner") or cycle.get("owner") or "재훈").strip() or "재훈"
    day_start = optional_time_or_default(cycle.get("day_start"), "08:30")
    day_end = optional_time_or_default(cycle.get("day_end"), "21:00")
    night_start = optional_time_or_default(cycle.get("night_start"), "21:00")
    night_end = optional_time_or_default(cycle.get("night_end"), "08:30")
    phase = diff_days % 12
    if phase < 4:
        return {"text": f"{owner} 콘티(주) {day_start}~{day_end}"}
    if phase < 6:
        return {"text": f"{owner} 콘티(휴)"}
    if phase < 10:
        return {"text": f"{owner} 콘티(야) {night_start}~{night_end}"}
    return {"text": f"{owner} 콘티(휴)"}


def attach_side_job_references(days: list[dict[str, Any]]) -> None:
    if not days:
        return
    try:
        reference = fb_get(f"{SIDE_JOB_REFERENCES_PATH}/jaehun") or {}
    except Exception as exc:
        log(f"side job reference read failed: {compact_error(str(exc), 160)}")
        return
    if not isinstance(reference, dict) or reference.get("enabled") is False:
        return
    dates = reference.get("dates")
    if not isinstance(dates, dict):
        dates = {}
    for day in days:
        if not isinstance(day, dict):
            continue
        date_text = str(day.get("date") or "").strip()
        raw = dates.get(date_text)
        if raw is None:
            raw = cycle_reference_for_date(reference, date_text)
        if raw is None:
            raw = weekly_reference_for_date(reference, date_text)
        line = side_job_reference_line(raw)
        if line:
            day["side_job_reference"] = line


def schedule_realtime_force_refresh_requested(item: dict[str, Any]) -> bool:
    payload = item.get("payload")
    candidates = [
        item.get("force_schedule_realtime_refresh"),
        item.get("force_realtime_refresh"),
        item.get("bypass_schedule_realtime_cache"),
        item.get("schedule_realtime_retry"),
    ]
    if isinstance(payload, dict):
        candidates.extend(
            [
                payload.get("force_schedule_realtime_refresh"),
                payload.get("force_realtime_refresh"),
                payload.get("bypass_schedule_realtime_cache"),
                payload.get("schedule_realtime_retry"),
            ]
        )
    for raw in candidates:
        if raw is True:
            return True
        if isinstance(raw, str) and raw.strip().lower() in {"1", "true", "yes", "y", "on", "force", "retry"}:
            return True
    return False


def schedule_realtime_cache_minutes(item: dict[str, Any]) -> int:
    if schedule_realtime_force_refresh_requested(item):
        return 0
    payload = item.get("payload")
    candidates = []
    if isinstance(payload, dict):
        candidates.extend(
            [
                payload.get("reuse_schedule_realtime_cache_minutes"),
                payload.get("reuse_cache_minutes"),
                payload.get("cache_ttl_minutes"),
            ]
        )
    candidates.extend(
        [
            item.get("reuse_schedule_realtime_cache_minutes"),
            item.get("reuse_cache_minutes"),
            item.get("cache_ttl_minutes"),
        ]
    )
    for raw in candidates:
        try:
            minutes = int(raw)
        except (TypeError, ValueError):
            continue
        return max(1, min(minutes, REALTIME_INFO_MAX_AGE_MINUTES))
    return 0


def schedule_result_source_time(result: dict[str, Any]) -> tuple[int, str]:
    for key in ("occurred_at_ms", "event_at_ms", "published_at_ms"):
        ts_ms = normalize_ts_ms(result.get(key) or 0)
        if ts_ms > 0:
            return ts_ms, key
    return 0, ""


def filter_schedule_fresh_results(
    results: Any,
    max_age_minutes: int,
    *,
    require_source_freshness: bool = False,
) -> tuple[list[dict[str, Any]], dict[str, int]]:
    if not isinstance(results, list):
        return [], {"missing_published": 0, "missing_source_time": 0, "stale": 0}
    accepted: list[dict[str, Any]] = []
    missing_published = 0
    missing_source_time = 0
    stale = 0
    now = now_ms()
    for result in results:
        if not isinstance(result, dict):
            continue
        enriched = dict(result)
        published_at_ms = normalize_ts_ms(result.get("published_at_ms") or 0)
        if published_at_ms <= 0:
            missing_published += 1
            enriched["published_at_ms"] = 0
            enriched["age_minutes"] = -1
        else:
            age_minutes = max(0, int((now - published_at_ms) / 60000))
            enriched["published_at_ms"] = published_at_ms
            enriched["age_minutes"] = age_minutes
        source_time_ms, source_time_field = schedule_result_source_time(enriched)
        source_age_minutes = max(0, int((now - source_time_ms) / 60000)) if source_time_ms > 0 else -1
        enriched["freshness_at_ms"] = source_time_ms
        enriched["freshness_time_field"] = source_time_field
        enriched["source_age_minutes"] = source_age_minutes
        if source_time_ms <= 0:
            missing_source_time += 1
            if require_source_freshness:
                continue
        elif source_age_minutes > max_age_minutes:
            stale += 1
            if require_source_freshness:
                continue
        accepted.append(enriched)
    accepted.sort(
        key=lambda item: normalize_ts_ms(item.get("freshness_at_ms") or item.get("published_at_ms") or 0),
        reverse=True,
    )
    return accepted, {
        "missing_published": missing_published,
        "missing_source_time": missing_source_time,
        "stale": stale,
    }


def execute_schedule_fresh_search(
    item: dict[str, Any],
    kind: str,
    query: str,
    max_results: int,
    freshness_minutes: int,
    *,
    force_refresh: bool = False,
    require_source_freshness: bool = False,
) -> dict[str, Any]:
    force_refresh_requested = bool(force_refresh or schedule_realtime_force_refresh_requested(item))
    cache_minutes = 0 if force_refresh_requested else schedule_realtime_cache_minutes(item)
    result = execute_search(
        {
            "type": f"{kind}.search",
            "query": query,
            "max_results": max_results,
            "cache_ttl_minutes": cache_minutes,
            "force_refresh": force_refresh_requested or cache_minutes <= 0,
        },
        kind,
    )
    raw_results = result.get("results")
    accepted_results, freshness = filter_schedule_fresh_results(
        raw_results,
        freshness_minutes,
        require_source_freshness=require_source_freshness,
    )
    cache_rejected_count = 0
    if force_refresh_requested and result.get("cache_hit") is True:
        cache_rejected_count = len(accepted_results)
        accepted_results = []
    meta = dict(result)
    meta["results"] = accepted_results
    # Kept for response-shape compatibility. Strict source-time filtering
    # rejects stale rows inline and never exposes them as a fallback bucket.
    meta["stale_results"] = []
    meta["relaxed_results"] = []
    meta["freshness_filter"] = {
        "max_age_minutes": freshness_minutes,
        **freshness,
        "accepted": len(accepted_results),
        "cache_reuse_minutes": cache_minutes,
        "cache_bypassed": force_refresh_requested or cache_minutes <= 0,
        "force_refresh": force_refresh_requested,
        "publication_age_filtering": require_source_freshness,
        "source_time_filtering": require_source_freshness,
        "source_time_fields": ["occurred_at_ms", "event_at_ms", "published_at_ms"],
        "cache_freshness_source": "published_or_occurred_at_ms" if require_source_freshness else "fetched_at_ms",
        "cache_rejected_count": cache_rejected_count,
    }
    meta["relaxed_freshness_filter"] = {
        "max_age_minutes": freshness_minutes,
        "disabled": True,
        "accepted": 0,
        "source_time_filtering": True,
    }
    return meta


def attach_schedule_realtime_context(item: dict[str, Any], answer: str, days: list[dict[str, Any]]) -> dict[str, Any]:
    wants_weather = True
    wants_news = True
    for day in days:
        if isinstance(day, dict):
            day.pop("sports", None)
    meta = {
        "freshness_max_age_minutes": REALTIME_INFO_MAX_AGE_MINUTES,
        "requested": {
            "weather": wants_weather,
            "news": wants_news,
        },
        "attached": {
            "weather": False,
            "news": False,
        },
        "errors": {},
    }
    if not days:
        return meta

    if wants_weather:
        try:
            weather_result = execute_weather({"type": "weather.forecast", "location": "이천", "days": len(days)})
            weather_by_date = {
                str(day.get("date") or ""): day
                for day in weather_result.get("days", [])
                if isinstance(day, dict)
            }
            fetched_at_ms = safe_int(weather_result.get("fetched_at_ms"), now_ms())
            valid_until_ms = safe_int(weather_result.get("valid_until_ms"), fetched_at_ms + REALTIME_INFO_MAX_AGE_MINUTES * 60 * 1000)
            attached = False
            for day in days:
                weather_day = weather_by_date.get(str(day.get("date") or ""))
                if not weather_day:
                    continue
                brief = schedule_weather_brief(weather_day)
                if not brief:
                    continue
                day["weather"] = {
                    "brief": brief,
                    "fetched_at_ms": fetched_at_ms,
                    "valid_until_ms": valid_until_ms,
                    "freshness_max_age_minutes": REALTIME_INFO_MAX_AGE_MINUTES,
                    "source": "open-meteo",
                }
                attached = True
            meta["attached"]["weather"] = attached
        except Exception as exc:
            meta["errors"]["weather"] = compact_error(str(exc), 120)
        if not meta["attached"]["weather"]:
            for day in days:
                if isinstance(day, dict) and not isinstance(day.get("weather"), dict):
                    day["weather"] = {
                        "brief": schedule_weather_unavailable_brief(day.get("date")),
                        "fetched_at_ms": now_ms(),
                        "valid_until_ms": now_ms() + REALTIME_INFO_MAX_AGE_MINUTES * 60 * 1000,
                        "freshness_max_age_minutes": REALTIME_INFO_MAX_AGE_MINUTES,
                        "source": "storebot_realtime_status",
                    }
        else:
            for day in days:
                if isinstance(day, dict) and not isinstance(day.get("weather"), dict):
                    day["weather"] = {
                        "brief": schedule_weather_unavailable_brief(day.get("date")),
                        "fetched_at_ms": now_ms(),
                        "valid_until_ms": now_ms() + REALTIME_INFO_MAX_AGE_MINUTES * 60 * 1000,
                        "freshness_max_age_minutes": REALTIME_INFO_MAX_AGE_MINUTES,
                        "source": "storebot_realtime_status",
                    }

    if wants_news:
        news_queries = (
            "이천 SK하이닉스 최신 뉴스 OR 이천 교통 사고",
            "이천 SK하이닉스 뉴스",
            "이천 교통 뉴스",
        )
        meta["news_query"] = news_queries[0]
        query_attempts: list[dict[str, Any]] = []
        selected_news_result: dict[str, Any] = {}
        selected_news_query = ""
        news_lines: list[str] = []
        successful_queries = 0
        query_errors: list[dict[str, Any]] = []
        for news_query in news_queries:
            try:
                news_result = execute_schedule_fresh_search(
                    item,
                    "news",
                    news_query,
                    2,
                    SCHEDULE_NEWS_MAX_AGE_MINUTES,
                    force_refresh=True,
                    require_source_freshness=True,
                )
                successful_queries += 1
                freshness = news_result.get("freshness_filter") if isinstance(news_result.get("freshness_filter"), dict) else {}
                relaxed_freshness = (
                    news_result.get("relaxed_freshness_filter")
                    if isinstance(news_result.get("relaxed_freshness_filter"), dict)
                    else {}
                )
                query_attempts.append(
                    {
                        "query": news_query,
                        "status": "success",
                        "accepted_12h": safe_int(freshness.get("accepted"), 0),
                        "accepted_7d": safe_int(relaxed_freshness.get("accepted"), 0),
                        "source_attempts": safe_int(news_result.get("source_attempts"), 0),
                        "cache_hit": bool(news_result.get("cache_hit")),
                    }
                )
                strict_lines = schedule_news_lines_from_results(news_result.get("results"))
                if strict_lines:
                    news_lines = strict_lines
                    selected_news_result = news_result
                    selected_news_query = news_query
                    break
            except Exception as exc:
                error_entry = {
                    "query": news_query,
                    "status": "error",
                    "error": compact_error(str(exc), 160),
                    **structured_source_error_fields(exc),
                }
                query_attempts.append(error_entry)
                query_errors.append(error_entry)
                continue

        warnings: list[dict[str, Any]] = []
        if news_lines:
            meta["attached"]["news"] = True
            meta["news_lookup_status"] = "fresh_12h"
        elif successful_queries > 0:
            news_lines = ["실시간 뉴스 조회 불가"]
            meta["news_lookup_status"] = "no_fresh_headline"
            warnings.append({"code": "news_no_fresh_headline", "section": "news"})
        else:
            news_lines = ["실시간 뉴스 조회 불가"]
            meta["news_lookup_status"] = "unavailable"
            warnings.append({"code": "news_realtime_unavailable", "section": "news"})

        meta["today_news"] = news_lines
        meta["news_query_attempts"] = query_attempts
        meta["news_alternate_query_attempts"] = query_attempts[1:]
        if selected_news_query and selected_news_query != news_queries[0]:
            meta["news_alternate_query_used"] = selected_news_query
        if query_errors:
            meta["news_query_errors"] = query_errors
            meta["errors"]["news"] = compact_error(query_errors[0].get("error") or "news query failed", 120)
        if warnings:
            meta["warnings"] = warnings
        meta["news_degraded"] = meta["news_lookup_status"] != "fresh_12h"
        meta["news_cache_hit"] = bool(selected_news_result.get("cache_hit"))
        meta["news_cache_age_minutes"] = safe_int(selected_news_result.get("cache_age_minutes"), -1)
        meta["news_freshness"] = selected_news_result.get("freshness_filter") or {}
        meta["news_relaxed_freshness"] = selected_news_result.get("relaxed_freshness_filter") or {}
        meta["news_force_refresh"] = True
        evidence_results = selected_news_result.get("results")
        meta["news_fresh_evidence"] = schedule_news_fresh_evidence(evidence_results)
        attach_news_to_schedule_days(days, meta.get("today_news") if isinstance(meta.get("today_news"), list) else [])

    return meta


def schedule_required_sections_complete(payload: dict[str, Any]) -> bool:
    raw_sections = payload.get("required_sections")
    if not isinstance(raw_sections, list):
        return False
    labels = {str(section or "").strip() for section in raw_sections}
    return all(section in labels for section in SCHEDULE_REQUIRED_SECTIONS)


def schedule_line_text(value: Any) -> str:
    if isinstance(value, dict):
        for key in ("title", "headline", "summary", "text", "message", "brief"):
            text = str(value.get(key) or "").strip()
            if text:
                return text
        return ""
    return str(value or "").strip()


def schedule_list_lines(value: Any) -> list[str]:
    if isinstance(value, list):
        return [schedule_line_text(item) for item in value if schedule_line_text(item)]
    text = schedule_line_text(value)
    return [text] if text else []


def schedule_text_is_placeholder(value: Any, placeholders: tuple[str, ...]) -> bool:
    text = re.sub(r"\s+", " ", str(value or "").strip())
    if not text:
        return True
    return any(placeholder in text for placeholder in placeholders)


def schedule_date_is_past_calendar_date(date_text: Any) -> bool:
    try:
        target_date = datetime.strptime(str(date_text or "").strip(), "%Y-%m-%d").date()
    except (TypeError, ValueError):
        return False
    return target_date < datetime.now(KST).date()


def schedule_weather_unavailable_brief(date_text: Any) -> str:
    if schedule_date_is_past_calendar_date(date_text):
        return "지난 운영일 날씨 조회 불가"
    return "날씨 조회 실패"


def append_missing_schedule_section(
    missing_sections: list[str],
    reasons: list[str],
    section: str,
    reason: str,
) -> None:
    if section not in missing_sections:
        missing_sections.append(section)
    reasons.append(reason)


def schedule_realtime_payload_metadata(image_request: dict[str, Any], payload: dict[str, Any]) -> dict[str, Any]:
    realtime_info = payload.get("realtime_info") if isinstance(payload.get("realtime_info"), dict) else {}
    metadata = {
        "image_payload_source": str(image_request.get("image_payload_source") or ""),
        "generated_at_ms": normalize_ts_ms(payload.get("generated_at_ms") or 0),
        "current_date_kst": str(payload.get("current_date_kst") or ""),
        "days_refreshed_at_ms": normalize_ts_ms(payload.get("days_refreshed_at_ms") or 0),
        "day_count": payload.get("day_count"),
        "days_len": len(payload.get("days")) if isinstance(payload.get("days"), list) else 0,
        "start_date": str(payload.get("start_date") or ""),
        "end_date": str(payload.get("end_date") or ""),
        "date_range": str(payload.get("date_range") or ""),
        "range_label": str(payload.get("range_label") or ""),
        "title": str(payload.get("title") or ""),
        "caption": str(payload.get("caption") or ""),
        "canonical_range": payload.get("canonical_range") if isinstance(payload.get("canonical_range"), dict) else {},
        "schedule_image_day_count_contract": (
            payload.get("schedule_image_day_count_contract")
            if isinstance(payload.get("schedule_image_day_count_contract"), dict)
            else {}
        ),
        "schedule_image_viewport": (
            payload.get("schedule_image_viewport") if isinstance(payload.get("schedule_image_viewport"), dict) else {}
        ),
        "graph_bounds": payload.get("graph_bounds") if isinstance(payload.get("graph_bounds"), dict) else {},
        "required_sections": payload.get("required_sections") if isinstance(payload.get("required_sections"), list) else [],
    }
    if realtime_info:
        metadata["realtime_info"] = compact_payload(
            {
                "freshness_max_age_minutes": realtime_info.get("freshness_max_age_minutes"),
                "requested": realtime_info.get("requested"),
                "attached": realtime_info.get("attached"),
                "errors": realtime_info.get("errors"),
                "news_query": realtime_info.get("news_query"),
                "news_alternate_query_used": realtime_info.get("news_alternate_query_used"),
                "news_alternate_query_attempts": realtime_info.get("news_alternate_query_attempts"),
                "news_query_attempts": realtime_info.get("news_query_attempts"),
                "news_query_errors": realtime_info.get("news_query_errors"),
                "news_cache_hit": realtime_info.get("news_cache_hit"),
                "news_cache_age_minutes": realtime_info.get("news_cache_age_minutes"),
                "news_freshness": realtime_info.get("news_freshness"),
                "news_force_refresh": realtime_info.get("news_force_refresh"),
                "news_lookup_status": realtime_info.get("news_lookup_status"),
                "news_degraded": realtime_info.get("news_degraded"),
                "news_relaxed_freshness": realtime_info.get("news_relaxed_freshness"),
                "news_fresh_evidence": realtime_info.get("news_fresh_evidence"),
                "today_news": realtime_info.get("today_news"),
                "warnings": realtime_info.get("warnings"),
            },
            5000,
        )
    return metadata


def annotate_work_schedule_broadcast_model0_fallback(
    image_request: dict[str, Any],
) -> dict[str, Any]:
    updated = dict(image_request)
    payload = dict(updated.get("payload") if isinstance(updated.get("payload"), dict) else {})
    payload.pop("sports", None)
    raw_days = payload.get("days")
    days: list[dict[str, Any]] = []
    if isinstance(raw_days, list):
        for raw_day in raw_days:
            if not isinstance(raw_day, dict):
                continue
            day = dict(raw_day)
            weather = day.get("weather")
            if not isinstance(weather, dict) or not str(weather.get("brief") or "").strip():
                day["weather"] = {
                    "brief": schedule_weather_unavailable_brief(day.get("date")),
                    "fetched_at_ms": now_ms(),
                    "valid_until_ms": now_ms() + REALTIME_INFO_MAX_AGE_MINUTES * 60 * 1000,
                    "freshness_max_age_minutes": REALTIME_INFO_MAX_AGE_MINUTES,
                    "source": "storebot_model0_fallback",
                }
            day.pop("sports", None)
            days.append(day)
    news_lines = schedule_list_lines(payload.get("today_news"))
    if not news_lines:
        news_lines = ["실시간 뉴스 조회 불가"]
        realtime_info = dict(payload.get("realtime_info") if isinstance(payload.get("realtime_info"), dict) else {})
        realtime_info.update(
            {
                "news_lookup_status": "unavailable",
                "news_degraded": True,
                "warnings": [{"code": "news_realtime_unavailable", "section": "news"}],
            }
        )
        payload["realtime_info"] = realtime_info
    attach_news_to_schedule_days(days, news_lines)
    payload.update(
        {
            "days": days,
            "today_news": news_lines,
            "required_sections": list(SCHEDULE_REQUIRED_SECTIONS),
            "requires_codex_output": False,
            "model0_fallback": {
                "active": True,
                "reason": "resident_codex_runtime_error",
                "lookup_failure_sections_allowed": True,
            },
        }
    )
    updated.update(
        {
            "event_kind": WORK_SCHEDULE_BROADCAST_EVENT_KIND,
            "model0_fallback": True,
            "model0_fallback_reason": "resident_codex_runtime_error",
            "payload": payload,
        }
    )
    return updated


def work_schedule_broadcast_model0_lookup_failures_allowed(
    image_request: dict[str, Any],
    payload: dict[str, Any],
) -> bool:
    fallback = payload.get("model0_fallback")
    return bool(
        image_request.get("model0_fallback") is True
        and str(image_request.get("event_kind") or "") == WORK_SCHEDULE_BROADCAST_EVENT_KIND
        and str(image_request.get("source") or "") == "storebot_codex_worker"
        and isinstance(fallback, dict)
        and fallback.get("active") is True
        and fallback.get("lookup_failure_sections_allowed") is True
        and payload.get("requires_codex_output") is False
    )


def validate_schedule_image_request(image_request: dict[str, Any] | None) -> dict[str, Any]:
    validation: dict[str, Any] = {
        "complete": True,
        "status": "ok",
        "checked_at_ms": now_ms(),
        "missing_sections": [],
        "reasons": [],
        "warnings": [],
        "payload_metadata": {},
    }
    if not isinstance(image_request, dict) or image_request.get("type") != "schedule_briefing":
        return validation
    payload = image_request.get("payload")
    missing_sections: list[str] = []
    reasons: list[str] = []
    if not isinstance(payload, dict):
        for section in ("payload", "days", "weather", "news"):
            append_missing_schedule_section(missing_sections, reasons, section, "payload_missing")
        validation.update({"complete": False, "status": "schedule_realtime_incomplete", "missing_sections": missing_sections, "reasons": reasons})
        return validation

    validation["payload_metadata"] = schedule_realtime_payload_metadata(image_request, payload)
    model0_lookup_failures_allowed = work_schedule_broadcast_model0_lookup_failures_allowed(image_request, payload)
    if not schedule_required_sections_complete(payload):
        append_missing_schedule_section(
            missing_sections,
            reasons,
            "required_sections",
            "required_sections_missing_or_incomplete",
        )

    raw_days = payload.get("days")
    days = [day for day in raw_days if isinstance(day, dict)] if isinstance(raw_days, list) else []
    if not isinstance(raw_days, list) or not days:
        append_missing_schedule_section(missing_sections, reasons, "days", "days_missing_or_empty")
    day_count_raw = payload.get("day_count")
    if day_count_raw is not None:
        day_count = safe_int(day_count_raw, -1)
        if day_count != len(days):
            append_missing_schedule_section(
                missing_sections,
                reasons,
                "days",
                f"day_count_mismatch:{day_count}!={len(days)}",
            )

    bad_weather_dates: list[str] = []
    past_weather_unavailable_dates: list[str] = []
    target_weather_days = days[:1]
    for day in target_weather_days:
        date_text = str(day.get("date") or "").strip()
        weather = day.get("weather")
        brief = ""
        if isinstance(weather, dict):
            brief = str(weather.get("brief") or "").strip()
        past_weather_unavailable = bool(
            brief == "지난 운영일 날씨 조회 불가"
            and schedule_date_is_past_calendar_date(date_text)
        )
        if past_weather_unavailable:
            past_weather_unavailable_dates.append(date_text)
        elif (
            not isinstance(weather, dict)
            or not brief
            or (schedule_text_is_placeholder(brief, SCHEDULE_WEATHER_PLACEHOLDERS) and not model0_lookup_failures_allowed)
        ):
            bad_weather_dates.append(date_text or "unknown")
    if past_weather_unavailable_dates:
        validation["past_weather_unavailable_dates"] = past_weather_unavailable_dates
    if days and bad_weather_dates:
        append_missing_schedule_section(
            missing_sections,
            reasons,
            "weather",
            "weather_missing_or_placeholder_target:" + ",".join(bad_weather_dates[:8]),
        )
    elif not days:
        append_missing_schedule_section(missing_sections, reasons, "weather", "weather_uncheckable_without_days")

    news_lines = schedule_list_lines(payload.get("today_news"))
    for day in days:
        news_lines.extend(schedule_list_lines(day.get("news")))
    news_good = [line for line in news_lines if not schedule_text_is_placeholder(line, SCHEDULE_NEWS_PLACEHOLDERS)]
    realtime_info = payload.get("realtime_info") if isinstance(payload.get("realtime_info"), dict) else {}
    news_lookup_status = str(realtime_info.get("news_lookup_status") or "").strip()
    news_degraded_codes = {
        "no_fresh_headline": "news_no_fresh_headline",
        "unavailable": "news_realtime_unavailable",
    }
    inferred_degraded_code = ""
    if any(line == "실시간 뉴스 조회 불가" for line in news_lines):
        inferred_degraded_code = "news_realtime_unavailable"
    degraded_code = news_degraded_codes.get(news_lookup_status) or inferred_degraded_code
    if degraded_code:
        validation["warnings"].append(
            {
                "section": "news",
                "code": degraded_code,
                "lookup_status": news_lookup_status or "degraded_placeholder",
            }
        )
    if not news_good and not degraded_code and not (model0_lookup_failures_allowed and news_lines):
        append_missing_schedule_section(missing_sections, reasons, "news", "news_empty_or_placeholder_only")

    if missing_sections:
        validation.update(
            {
                "complete": False,
                "status": "schedule_realtime_incomplete",
                "missing_sections": missing_sections,
                "reasons": reasons,
            }
        )
    elif validation["warnings"]:
        validation["status"] = "ok_with_warnings"
    return validation


def schedule_realtime_retry_item(item: dict[str, Any], validation: dict[str, Any]) -> dict[str, Any]:
    retry_item = dict(item)
    payload = item.get("payload")
    retry_payload = dict(payload) if isinstance(payload, dict) else {}
    retry_meta = {
        "attempt": 1,
        "reason": "schedule_realtime_incomplete",
        "missing_sections": validation.get("missing_sections") if isinstance(validation.get("missing_sections"), list) else [],
        "started_at_ms": now_ms(),
        "force_refresh": True,
    }
    retry_payload["force_schedule_realtime_refresh"] = True
    retry_payload["schedule_realtime_retry"] = retry_meta
    retry_item["payload"] = retry_payload
    retry_item["force_schedule_realtime_refresh"] = True
    retry_item["schedule_realtime_retry"] = True
    retry_item["schedule_realtime_retry_meta"] = retry_meta
    return retry_item


def schedule_realtime_incomplete_output(
    validation: dict[str, Any],
    self_fix_request_id: str = "",
) -> dict[str, Any]:
    payload = {
        "category": "schedule_realtime_incomplete",
        "status": "schedule_realtime_incomplete",
        "reason": "required schedule briefing realtime sections incomplete",
        "missing_sections": validation.get("missing_sections") if isinstance(validation.get("missing_sections"), list) else [],
        "reasons": validation.get("reasons") if isinstance(validation.get("reasons"), list) else [],
        "retry_attempted": bool(validation.get("retry_attempted")),
        "retry_completed": bool(validation.get("retry_completed")),
        "self_fix_request_id": self_fix_request_id,
    }
    metadata = validation.get("payload_metadata")
    if isinstance(metadata, dict):
        payload["payload_metadata"] = compact_payload(metadata, 5000)
    return payload


def schedule_image_build_exception_validation(exc: Exception, *, stage: str) -> dict[str, Any]:
    return {
        "complete": False,
        "status": "schedule_realtime_incomplete",
        "checked_at_ms": now_ms(),
        "missing_sections": ["days", "weather", "news"],
        "reasons": [f"{stage}_exception:{compact_error(str(exc), 180)}"],
        "retry_attempted": True,
        "retry_completed": False,
        "payload_metadata": {
            "stage": stage,
            "error": compact_error(str(exc), 500),
        },
    }


def enqueue_schedule_realtime_incomplete_self_fix(
    req_id: str,
    item: dict[str, Any],
    validation: dict[str, Any],
    args: argparse.Namespace | None,
) -> str:
    room_id = str(item.get("room_id") or item.get("room") or "")
    room_name = str(item.get("room_name") or item.get("roomTitle") or "")
    source = str(item.get("source") or "")
    missing_sections = validation.get("missing_sections") if isinstance(validation.get("missing_sections"), list) else []
    metadata = validation.get("payload_metadata") if isinstance(validation.get("payload_metadata"), dict) else {}
    evidence = {
        "request_id": req_id,
        "room_id": room_id,
        "room_name": room_name,
        "source": source,
        "event_kind": str(item.get("event_kind") or item.get("kind") or ""),
        "missing_sections": missing_sections,
        "validation": compact_payload(validation, 6000),
        "payload_metadata": compact_payload(metadata, 6000),
    }
    return enqueue_storebot_cli_diagnostic(
        candidate_type="schedule_image_required_data_incomplete",
        severity="error",
        request_id=req_id,
        item=item,
        evidence=evidence,
        args=args,
        missing_sections=[str(section) for section in missing_sections],
        retry_count=1,
        safe_scope="scripts/storebot_codex_worker.py schedule realtime collection, freshness filtering, and image_request guards. Do not send Kakao messages or fabricate realtime data.",
    )


def realtime_payload_reference_is_fresh(payload: dict[str, Any]) -> bool:
    ts_ms = normalize_ts_ms(payload.get("generated_at_ms") or payload.get("fetched_at_ms") or 0)
    return ts_ms > 0 and now_ms() - ts_ms <= REALTIME_INFO_MAX_AGE_MINUTES * 60 * 1000


def realtime_weather_is_fresh(weather: Any) -> bool:
    if not isinstance(weather, dict):
        return False
    now = now_ms()
    fetched_at_ms = normalize_ts_ms(weather.get("fetched_at_ms") or 0)
    valid_until_ms = normalize_ts_ms(weather.get("valid_until_ms") or 0)
    if fetched_at_ms <= 0 or now - fetched_at_ms > REALTIME_INFO_MAX_AGE_MINUTES * 60 * 1000:
        return False
    return valid_until_ms <= 0 or valid_until_ms >= now


def sanitize_existing_schedule_payload(payload: dict[str, Any]) -> dict[str, Any]:
    sanitized = dict(payload)
    sanitized.pop("sports", None)
    payload_fresh = realtime_payload_reference_is_fresh(payload)
    raw_days = payload.get("days")
    days: list[dict[str, Any]] = []
    if isinstance(raw_days, list):
        for raw_day in raw_days:
            if not isinstance(raw_day, dict):
                continue
            day = dict(raw_day)
            day.pop("sports", None)
            if not payload_fresh:
                for key in ("news", "issues", "operational_issues"):
                    day.pop(key, None)
            days.append(day)
    sanitized["days"] = days
    if not payload_fresh:
        sanitized["today_news"] = []
    sanitized["realtime_info"] = {
        "freshness_max_age_minutes": REALTIME_INFO_MAX_AGE_MINUTES,
        "source": "existing_payload_sanitized",
        "payload_fresh": payload_fresh,
    }
    return sanitized


def preserve_schedule_days_snapshot(payload: dict[str, Any]) -> bool:
    return bool(
        payload.get("historical_snapshot")
        or payload.get("preserve_days_snapshot")
        or payload.get("replay_payload")
    )


def extract_schedule_image_dates(payload: dict[str, Any]) -> list[str]:
    dates: list[str] = []
    raw_days = payload.get("days")
    if isinstance(raw_days, list):
        for raw_day in raw_days:
            if not isinstance(raw_day, dict):
                continue
            append_schedule_date_value(dates, raw_day.get("date"))
    append_schedule_date_value(dates, payload.get("target_date"))
    append_schedule_date_value(dates, payload.get("date"))
    append_schedule_date_values(dates, payload.get("dates"), limit=MAX_SCHEDULE_IMAGE_DAY_COUNT)
    append_schedule_date_values(dates, payload.get("target_dates"), limit=MAX_SCHEDULE_IMAGE_DAY_COUNT)
    if not dates:
        for start_key, end_key in (("start_date", "end_date"), ("range_start", "range_end"), ("week_start", "week_end")):
            for date_text in expand_schedule_date_range(payload.get(start_key), payload.get(end_key)):
                append_schedule_date_value(dates, date_text)
            if dates:
                break
    return dates


def schedule_holiday_name_is_user_content(value: Any) -> bool:
    text = re.sub(r"\s+", " ", str(value or "").strip())
    if not text:
        return False
    blocked_markers = ("조회", "실패", "대기", "출처", "확인 정보 없음", "미확인", "평일", "없음")
    return not any(marker in text for marker in blocked_markers)


def schedule_explicit_holiday_flag(value: Any) -> bool:
    if isinstance(value, bool):
        return value
    if isinstance(value, (int, float)):
        return value == 1
    return str(value or "").strip().casefold() in {"1", "true", "yes", "y", "on", "holiday", "public_holiday"}


def schedule_calendar_holiday_names(overlay: dict[str, Any]) -> list[str]:
    names: list[str] = []

    def append_name(raw: Any) -> None:
        if isinstance(raw, dict):
            raw = raw.get("name") or raw.get("title") or raw.get("label")
        text = str(raw or "").strip()
        if schedule_holiday_name_is_user_content(text) and text not in names:
            names.append(text)

    holiday = overlay.get("holiday")
    nested_holiday = holiday if isinstance(holiday, dict) else {}
    for raw in (
        nested_holiday.get("name"),
        nested_holiday.get("label"),
        overlay.get("holidayName"),
        overlay.get("holiday_name"),
        holiday if isinstance(holiday, str) else "",
    ):
        append_name(raw)
    for raw_names in (
        nested_holiday.get("names"),
        nested_holiday.get("holiday_names"),
        overlay.get("holidayNames"),
        overlay.get("holiday_names"),
    ):
        if isinstance(raw_names, list):
            for raw in raw_names:
                append_name(raw)
        elif isinstance(raw_names, str):
            append_name(raw_names)
    return names


def fetch_kr_public_holidays(year: int) -> dict[str, Any]:
    fetched_at_ms = now_ms()
    with _KR_PUBLIC_HOLIDAY_CACHE_LOCK:
        cached = _KR_PUBLIC_HOLIDAY_CACHE.get(year)
        if isinstance(cached, dict):
            cached_at_ms = normalize_ts_ms(cached.get("fetched_at_ms") or 0)
            if cached_at_ms > 0 and fetched_at_ms - cached_at_ms <= KR_PUBLIC_HOLIDAY_CACHE_TTL_MS:
                return dict(cached)

    source_url = KR_PUBLIC_HOLIDAY_API_URL_TEMPLATE.format(year=year)
    request = urllib.request.Request(source_url, headers={"User-Agent": "StoreBotCodexWorker/1"})
    with urllib.request.urlopen(request, timeout=5) as response:
        raw = response.read().decode("utf-8")
    rows = json.loads(raw)
    if not isinstance(rows, list):
        raise WorkerError("Nager.Date KR holiday response is not a JSON array")

    holidays: dict[str, list[str]] = {}
    for row in rows:
        if not isinstance(row, dict):
            continue
        date_text = normalize_schedule_date_value(row.get("date"))
        if not date_text:
            continue
        name = str(row.get("localName") or row.get("name") or "").strip()
        if name and name not in holidays.setdefault(date_text, []):
            holidays[date_text].append(name)
    result = {
        "year": year,
        "holidays": holidays,
        "fetched_at_ms": fetched_at_ms,
        "source": "nager_date_kr",
        "source_url": source_url,
    }
    with _KR_PUBLIC_HOLIDAY_CACHE_LOCK:
        _KR_PUBLIC_HOLIDAY_CACHE[year] = dict(result)
    return result


def schedule_overlay_has_holiday_contract(overlay: dict[str, Any]) -> bool:
    return any(
        key in overlay
        for key in (
            "holidayName",
            "holiday_name",
            "holidayNames",
            "holiday_names",
            "holiday",
            "isHoliday",
            "isRedDay",
            "is_red_day",
        )
    )


def attach_schedule_calendar_metadata(
    days: list[dict[str, Any]],
    *,
    allow_public_api: bool = False,
    current_date_kst: str = "",
    generated_at_ms: int = 0,
) -> None:
    overlay_read_error = ""
    try:
        overlays = fb_get(workschedule_v2_path("meta", "calendar_overlay")) or {}
    except Exception as exc:
        overlay_read_error = compact_error(str(exc), 160)
        log(f"schedule calendar overlay read failed: {overlay_read_error}")
        overlays = {}
    if not isinstance(overlays, dict):
        overlay_read_error = "calendar_overlay_not_object"
        overlays = {}
    public_holiday_years: dict[int, dict[str, Any] | None] = {}
    public_holiday_year_errors: dict[int, str] = {}
    if allow_public_api:
        for day in days:
            if not isinstance(day, dict):
                continue
            date_text = str(day.get("date") or "").strip()
            overlay = overlays.get(date_text)
            if isinstance(overlay, dict) and schedule_overlay_has_holiday_contract(overlay):
                continue
            try:
                year = datetime.strptime(date_text, "%Y-%m-%d").year
            except Exception:
                continue
            if year in public_holiday_years:
                continue
            try:
                public_holiday_years[year] = fetch_kr_public_holidays(year)
            except Exception as exc:
                public_holiday_years[year] = None
                public_holiday_year_errors[year] = compact_error(str(exc), 160)
                log(f"KR public holiday lookup failed for {year}: {public_holiday_year_errors[year]}")
    calendar_today = normalize_schedule_date_value(current_date_kst)
    reference_ms = normalize_ts_ms(generated_at_ms or 0)
    if not calendar_today and reference_ms > 0:
        calendar_today = datetime.fromtimestamp(reference_ms / 1000, KST).strftime("%Y-%m-%d")
    if not calendar_today:
        calendar_today = datetime.now(KST).strftime("%Y-%m-%d")
    operational_today = work_schedule_operational_day_start().strftime("%Y-%m-%d")
    for day in days:
        if not isinstance(day, dict):
            continue
        date_text = str(day.get("date") or "").strip()
        try:
            weekday_index = datetime.strptime(date_text, "%Y-%m-%d").weekday()
        except Exception:
            weekday_index = -1
        overlay = overlays.get(date_text)
        if not isinstance(overlay, dict):
            overlay = {}
        is_saturday = weekday_index == 5
        is_sunday = bool(weekday_index == 6)
        official_holiday = False
        holiday_names: list[str] = []
        holiday_status = "weekend" if is_saturday or is_sunday else "unknown"
        holiday_source = ""
        holiday_fetched_at_ms = 0
        holiday_source_url = ""
        warning_code = ""
        source_error = ""
        has_overlay_contract = schedule_overlay_has_holiday_contract(overlay)
        if not (is_saturday or is_sunday) and has_overlay_contract:
            nested_holiday = overlay.get("holiday") if isinstance(overlay.get("holiday"), dict) else {}
            holiday_names = schedule_calendar_holiday_names(overlay)
            official_holiday = bool(
                holiday_names
                or schedule_explicit_holiday_flag(overlay.get("isHoliday"))
                or schedule_explicit_holiday_flag(overlay.get("is_holiday"))
                or schedule_explicit_holiday_flag(overlay.get("is_public_holiday"))
                or schedule_explicit_holiday_flag(overlay.get("isRedDay"))
                or schedule_explicit_holiday_flag(overlay.get("is_red_day"))
                or schedule_explicit_holiday_flag(nested_holiday.get("is_holiday"))
                or schedule_explicit_holiday_flag(nested_holiday.get("is_public_holiday"))
                or schedule_explicit_holiday_flag(nested_holiday.get("is_red_day"))
            )
            holiday_source = "workschedule_v2_calendar_overlay"
            holiday_fetched_at_ms = normalize_ts_ms(
                nested_holiday.get("fetched_at_ms")
                or overlay.get("updated_at_ms")
                or overlay.get("fetched_at_ms")
                or overlay.get("generated_at_ms")
                or 0
            ) or now_ms()
            holiday_status = "verified_holiday" if official_holiday else "verified_not_holiday"
            if not official_holiday and any(
                key in overlay for key in ("holidayName", "holiday_name", "holidayNames", "holiday_names", "holiday")
            ) and not holiday_names:
                warning_code = "holiday_name_rejected_or_missing"
        elif not (is_saturday or is_sunday) and allow_public_api and weekday_index >= 0:
            year = datetime.strptime(date_text, "%Y-%m-%d").year
            public_result = public_holiday_years.get(year)
            if isinstance(public_result, dict):
                raw_holidays = public_result.get("holidays")
                if isinstance(raw_holidays, dict):
                    holiday_names = [
                        str(name).strip()
                        for name in raw_holidays.get(date_text, [])
                        if schedule_holiday_name_is_user_content(name)
                    ]
                official_holiday = bool(holiday_names)
                holiday_source = "nager_date_kr"
                holiday_fetched_at_ms = normalize_ts_ms(public_result.get("fetched_at_ms") or 0) or now_ms()
                holiday_source_url = str(public_result.get("source_url") or "")
                holiday_status = "verified_holiday" if official_holiday else "verified_not_holiday"
            else:
                holiday_status = "lookup_unavailable"
                warning_code = "holiday_lookup_failed"
                source_error = public_holiday_year_errors.get(year) or "public_holiday_result_missing"
        elif not (is_saturday or is_sunday):
            holiday_status = "lookup_unavailable" if overlay_read_error else "not_checked"
            warning_code = "holiday_overlay_read_failed" if overlay_read_error else "holiday_not_checked"
            source_error = overlay_read_error
        is_red_day = bool(is_saturday or is_sunday or official_holiday)
        calendar_status = {
            "holiday_status": holiday_status,
            "warning_code": warning_code,
            "source": holiday_source,
            "source_error": source_error,
            "holiday_names": holiday_names,
            "fetched_at_ms": holiday_fetched_at_ms,
            "source_url": holiday_source_url,
            "source_path": f"{WORKSCHEDULE_V2_PATH}/meta/calendar_overlay/{date_text}",
        }
        for public_key in (
            "holiday",
            "holidayName",
            "holidayNames",
            "holiday_name",
            "holiday_names",
            "holiday_source",
            "holiday_status",
            "holiday_error",
            "holiday_log",
            "holiday_fetched_at_ms",
            "holiday_source_url",
            "calendar_overlay_source_path",
        ):
            day.pop(public_key, None)
        day.update(
            {
                "is_today": date_text == calendar_today,
                "is_operational_today": date_text == operational_today,
                "weekday_index": weekday_index,
                "is_saturday": is_saturday,
                "is_sunday": is_sunday,
                "is_red_day": is_red_day,
                "calendar_status": calendar_status,
            }
        )


def build_schedule_image_days(
    dates: list[str],
    *,
    include_public_holidays: bool = False,
    current_date_kst: str = "",
    generated_at_ms: int = 0,
) -> list[dict[str, Any]]:
    query = execute_schedule_query({"type": "schedule.query", "dates": dates})
    days: list[dict[str, Any]] = []
    for day in query.get("days", []):
        if not isinstance(day, dict):
            continue
        date_text = str(day.get("date") or "").strip()
        if not date_text:
            continue
        try:
            date_obj = datetime.strptime(date_text, "%Y-%m-%d")
            dow = DOW_KR_BY_WEEKDAY[date_obj.weekday()]
        except Exception:
            dow = ""
        shifts: list[dict[str, Any]] = []
        dayoffs: list[str] = []
        for row in day.get("rows", []):
            if not isinstance(row, dict):
                continue
            if row.get("off") is True:
                off_name = str(row.get("employee") or row.get("employee_name") or row.get("employee_id") or "").strip()
                if off_name:
                    dayoffs.append(off_name)
                continue
            shifts.append(
                {
                    "employee_id": str(row.get("employee_id") or ""),
                    "employee_name": str(row.get("employee") or row.get("employee_name") or row.get("employee_id") or ""),
                    "start": str(row.get("start") or ""),
                    "end": str(row.get("end") or ""),
                    "role": str(row.get("role") or ""),
                    "status": str(row.get("status") or ""),
                    "source": str(row.get("source") or ""),
                }
            )
        days.append({"date": date_text, "dow": dow, "shifts": shifts, "dayoffs": dayoffs})
    attach_schedule_calendar_metadata(
        days,
        allow_public_api=include_public_holidays,
        current_date_kst=current_date_kst,
        generated_at_ms=generated_at_ms,
    )
    return days


def resolve_schedule_image_dates(item: dict[str, Any], answer: str) -> tuple[str, list[str], str]:
    canonical_range = resolve_schedule_image_canonical_range(item, answer)
    return canonical_range.mode, list(canonical_range.dates), canonical_range.source


def resolve_schedule_image_canonical_range(item: dict[str, Any], answer: str) -> WorkScheduleCanonicalRange:
    payload = item.get("payload")
    if request_event_kind(item) == WORK_SCHEDULE_BROADCAST_EVENT_KIND:
        start_offset = max(0, safe_int(payload.get("start_offset_days"), 0)) if isinstance(payload, dict) else 0
        return WorkScheduleCanonicalRange(
            "auto_broadcast",
            tuple(work_schedule_operational_dates(start_offset, WORK_SCHEDULE_BROADCAST_DAY_COUNT)),
            "work_schedule_broadcast_7_days",
        )
    if isinstance(payload, dict):
        payload_dates = extract_schedule_image_dates(payload)
        resolved_count, _count_source, _viewport = resolve_schedule_image_day_count_contract(
            item,
            payload,
            explicit_dates_count=len(payload_dates),
        )
        if payload_dates:
            return work_schedule_canonical_range_from_dates(
                schedule_normalize_mode(payload.get("mode"), "payload_dates"),
                payload_dates,
                "payload_explicit_dates",
                day_count=resolved_count,
            )
        if schedule_payload_is_legacy_day_only_fallback(payload):
            start_offset = 1 if str(payload.get("mode") or "").strip().casefold() == "tomorrow" else max(0, safe_int(payload.get("start_offset_days"), 0))
            return work_schedule_canonical_range_from_offsets(
                "chat_default_week" if start_offset == 0 else "chat_week",
                start_offset,
                resolved_count,
                "legacy_day_only_fallback_disabled",
            )
        if schedule_payload_has_offset_range(payload):
            raw_mode = schedule_normalize_mode(payload.get("mode"), "payload")
            return work_schedule_canonical_range_from_offsets(
                raw_mode,
                payload.get("start_offset_days", 0),
                resolved_count,
                "payload_offset_range",
            )
    mode, start_offset, day_count = resolve_schedule_image_target(item, answer)
    return work_schedule_canonical_range_from_offsets(mode, start_offset, day_count, "resolved_target")


def schedule_start_offset_days_from_dates(dates: list[str]) -> int:
    if not dates:
        return 0
    try:
        first_date = datetime.strptime(str(dates[0]).strip(), "%Y-%m-%d").replace(tzinfo=KST)
    except Exception:
        return 0
    today = work_schedule_operational_day_start()
    return max(0, int((first_date - today).total_seconds() // 86400))


def apply_schedule_canonical_range_metadata(payload: dict[str, Any], canonical_range: WorkScheduleCanonicalRange) -> None:
    metadata = canonical_range.metadata()
    payload["canonical_range"] = metadata
    payload["start_date"] = canonical_range.start_date
    payload["end_date"] = canonical_range.end_date
    payload["date_range"] = canonical_range.date_range
    payload["range_label"] = canonical_range.range_label
    payload["title"] = canonical_range.title
    payload["caption"] = canonical_range.caption
    payload["file_prefix"] = canonical_range.file_prefix
    payload["day_count"] = canonical_range.day_count
    payload["start_offset_days"] = schedule_start_offset_days_from_dates(list(canonical_range.dates))


def apply_schedule_image_contract_metadata(
    output_payload: dict[str, Any],
    item: dict[str, Any],
    canonical_range: WorkScheduleCanonicalRange,
) -> None:
    request_payload = item.get("payload") if isinstance(item.get("payload"), dict) else {}
    explicit_dates_count = len(extract_schedule_image_dates(request_payload))
    selected_count, count_source, viewport = resolve_schedule_image_day_count_contract(
        item,
        request_payload,
        explicit_dates_count=explicit_dates_count,
    )
    if request_event_kind(item) == WORK_SCHEDULE_BROADCAST_EVENT_KIND:
        selected_count = WORK_SCHEDULE_BROADCAST_DAY_COUNT
        count_source = "broadcast_fixed_7_days"
    output_payload["schedule_image_day_count_contract"] = {
        "min": MIN_SCHEDULE_IMAGE_DAY_COUNT,
        "max": MAX_SCHEDULE_IMAGE_DAY_COUNT,
        "default": DEFAULT_SCHEDULE_IMAGE_DAY_COUNT,
        "selected": canonical_range.day_count,
        "requested": selected_count,
        "source": count_source,
        "explicit_4_to_7_priority": True,
        "viewport_contract": "schedule_image_viewport.width_px+height_px",
        "viewport_scalar_aliases": ["viewport_width_px", "viewport_height_px"],
    }
    if viewport:
        output_payload["schedule_image_viewport"] = viewport


def trim_schedule_payload_days_to_range(payload: dict[str, Any], canonical_range: WorkScheduleCanonicalRange) -> None:
    days = payload.get("days")
    if not isinstance(days, list):
        return
    allowed_dates = set(canonical_range.dates)
    trimmed_days: list[dict[str, Any]] = []
    for day in days:
        if not isinstance(day, dict):
            continue
        date_text = str(day.get("date") or "").strip()
        if date_text in allowed_dates:
            trimmed_days.append(day)
        if len(trimmed_days) >= canonical_range.day_count:
            break
    payload["days"] = trimmed_days


def apply_schedule_graph_bounds_metadata(payload: dict[str, Any]) -> None:
    days = payload.get("days")
    if not isinstance(days, list):
        return
    graph_bounds = schedule_graph_bounds_from_days([day for day in days if isinstance(day, dict)])
    if not graph_bounds:
        payload.pop("graph_bounds", None)
        return
    payload["graph_bounds"] = graph_bounds
    summary = str(graph_bounds.get("summary") or "").strip()
    if summary:
        base_caption = str(payload.get("caption") or "").strip()
        graph_caption = f"그래프 {summary}"
        payload["caption"] = f"{base_caption} | {graph_caption}" if base_caption else graph_caption
        canonical_range = payload.get("canonical_range")
        if isinstance(canonical_range, dict):
            canonical_range["graph_bounds"] = graph_bounds


def resolve_schedule_image_target(item: dict[str, Any], answer: str) -> tuple[str, int, int]:
    payload = item.get("payload")
    resolved_count, _count_source, _viewport = resolve_schedule_image_day_count_contract(
        item,
        payload if isinstance(payload, dict) else {},
    )
    if isinstance(payload, dict):
        raw_mode = str(payload.get("mode") or "").strip()
        if raw_mode.casefold() in LEGACY_DAY_ONLY_SCHEDULE_MODES:
            return "chat_default_week", 1 if raw_mode.casefold() == "tomorrow" else 0, resolved_count
        if raw_mode == "tomorrow_21":
            return raw_mode, 1, resolved_count
        if schedule_payload_has_offset_range(payload):
            start_offset = max(0, safe_int(payload.get("start_offset_days"), 0))
            return raw_mode or "payload", start_offset, resolved_count
    text = "\n".join(str(part or "") for part in (item.get("message"), item.get("text")))
    lower = text.lower()
    target_tomorrow = "내일" in text or "tomorrow" in lower
    target_day_after = "모레" in text
    target_today = "오늘" in text or "today" in lower
    date_offset = schedule_image_date_offset_days(text)
    weekday_offset = schedule_image_weekday_offset_days(text)
    target_from = "부터" in text or "from" in lower
    target_week = re.search(r"이번주|다음주|주간|7일|전체|일주일", text) is not None or "week" in lower
    has_day_filter = target_today or target_tomorrow or target_day_after or date_offset is not None or weekday_offset is not None
    no_filter_default_week = not has_day_filter and not target_week

    if date_offset is not None:
        start_offset = max(0, date_offset)
    elif weekday_offset is not None:
        start_offset = max(0, weekday_offset)
    elif target_tomorrow:
        start_offset = 1
    elif target_day_after:
        start_offset = 2
    elif target_week and ("다음주" in text or "next week" in lower):
        start_offset = 7
    else:
        start_offset = 0

    day_count = resolved_count
    if target_tomorrow:
        mode = "chat_tomorrow"
    elif target_week or target_from:
        mode = "chat_week"
    elif no_filter_default_week:
        mode = "chat_default_week"
    else:
        mode = "chat_day"
    return mode, start_offset, day_count


def build_schedule_image_request_candidate(
    item: dict[str, Any],
    answer: str,
    *,
    force_rebuild_days: bool = False,
) -> dict[str, Any] | None:
    if not should_build_schedule_image_request(item, answer):
        return None
    event_kind = str(item.get("event_kind") or "").strip()
    if event_kind not in SCHEDULE_IMAGE_EVENT_KINDS:
        event_kind = WORK_SCHEDULE_BROADCAST_EVENT_KIND
    is_work_schedule_broadcast = request_event_kind(item) == WORK_SCHEDULE_BROADCAST_EVENT_KIND
    existing_payload = item.get("payload")
    if (
        not force_rebuild_days
        and isinstance(existing_payload, dict)
        and preserve_schedule_days_snapshot(existing_payload)
        and isinstance(existing_payload.get("days"), list)
    ):
        sanitized_payload = sanitize_existing_schedule_payload(existing_payload)
        sanitized_payload["event_kind"] = event_kind
        generated_at_ms = schedule_image_generated_at_ms(item, sanitized_payload)
        current_date_kst = schedule_image_current_date_kst(
            item,
            sanitized_payload,
            generated_at_ms=generated_at_ms,
        )
        sanitized_payload["generated_at_ms"] = generated_at_ms
        sanitized_payload["current_date_kst"] = current_date_kst
        days = sanitized_payload.get("days")
        if isinstance(days, list):
            schedule_days = [day for day in days if isinstance(day, dict)]
            attach_schedule_calendar_metadata(
                schedule_days,
                allow_public_api=is_work_schedule_broadcast,
                current_date_kst=current_date_kst,
                generated_at_ms=generated_at_ms,
            )
            attach_side_job_references(schedule_days)
            realtime_meta = attach_schedule_realtime_context(
                item,
                answer,
                schedule_days,
            )
            if is_work_schedule_broadcast:
                canonical_range = resolve_schedule_image_canonical_range(item, answer)
            else:
                existing_dates = extract_schedule_image_dates(sanitized_payload)
                existing_count, _existing_count_source, _existing_viewport = resolve_schedule_image_day_count_contract(
                    item,
                    sanitized_payload,
                    explicit_dates_count=len(existing_dates),
                )
                canonical_range = work_schedule_canonical_range_from_dates(
                    schedule_normalize_mode(sanitized_payload.get("mode"), "payload_dates"),
                    existing_dates,
                    "existing_payload_dates",
                    day_count=existing_count,
                )
            apply_schedule_canonical_range_metadata(sanitized_payload, canonical_range)
            apply_schedule_image_contract_metadata(sanitized_payload, item, canonical_range)
            trim_schedule_payload_days_to_range(sanitized_payload, canonical_range)
            apply_schedule_graph_bounds_metadata(sanitized_payload)
            sanitized_payload["realtime_info"] = realtime_meta
            if isinstance(realtime_meta.get("today_news"), list):
                sanitized_payload["today_news"] = realtime_meta.get("today_news")
            sanitized_payload["required_sections"] = ["근무", "날씨", "뉴스"]
        return {
            "type": "schedule_briefing",
            "event_kind": event_kind,
            "source": "storebot_codex_worker",
            "image_payload_source": "existing_payload",
            "send_policy": "image_first",
            "fallback_policy": SCHEDULE_IMAGE_FALLBACK_POLICY,
            "app_role": "renderer_transport_only",
            "required": True,
            "payload": sanitized_payload,
        }
    canonical_range = resolve_schedule_image_canonical_range(item, answer)
    mode = canonical_range.mode
    selection_source = canonical_range.source
    dates = list(canonical_range.dates)
    generated_at_ms = schedule_image_generated_at_ms(item, existing_payload if isinstance(existing_payload, dict) else {})
    current_date_kst = schedule_image_current_date_kst(
        item,
        existing_payload if isinstance(existing_payload, dict) else {},
        generated_at_ms=generated_at_ms,
    )
    days = build_schedule_image_days(
        dates,
        include_public_holidays=is_work_schedule_broadcast,
        current_date_kst=current_date_kst,
        generated_at_ms=generated_at_ms,
    )
    attach_side_job_references(days)
    realtime_meta = attach_schedule_realtime_context(item, answer, days)
    payload = {
        "schema": "storebot_codex_event_v1",
        "event_kind": event_kind,
        "mode": mode,
        "generated_at_ms": generated_at_ms,
        "current_date_kst": current_date_kst,
        "days_refreshed_at_ms": now_ms(),
        "days_selection_source": selection_source,
        "days": days,
        "today_news": realtime_meta.get("today_news") if isinstance(realtime_meta.get("today_news"), list) else [],
        "realtime_info": realtime_meta,
        "required_sections": ["근무", "날씨", "뉴스"],
        "requires_codex_output": False,
    }
    apply_schedule_canonical_range_metadata(payload, canonical_range)
    apply_schedule_image_contract_metadata(payload, item, canonical_range)
    apply_schedule_graph_bounds_metadata(payload)
    return {
        "type": "schedule_briefing",
        "event_kind": event_kind,
        "source": "storebot_codex_worker",
        "image_payload_source": f"worker_schedule_query:{selection_source}",
        "send_policy": "image_first",
        "fallback_policy": SCHEDULE_IMAGE_FALLBACK_POLICY,
        "app_role": "renderer_transport_only",
        "required": True,
        "payload": payload,
    }


def annotate_schedule_image_validation(
    image_request: dict[str, Any],
    validation: dict[str, Any],
    *,
    retry_attempted: bool,
) -> None:
    payload = image_request.get("payload")
    if not isinstance(payload, dict):
        return
    payload["schedule_realtime_validation"] = {
        "complete": bool(validation.get("complete")),
        "status": str(validation.get("status") or ""),
        "checked_at_ms": validation.get("checked_at_ms") or now_ms(),
        "retry_attempted": retry_attempted,
        "warnings": validation.get("warnings") if isinstance(validation.get("warnings"), list) else [],
    }
    if retry_attempted:
        payload["schedule_realtime_retry"] = {
            "attempted": True,
            "completed": bool(validation.get("complete")),
            "checked_at_ms": now_ms(),
        }


def build_schedule_image_request_result(
    item: dict[str, Any],
    answer: str,
    *,
    req_id: str = "",
    args: argparse.Namespace | None = None,
    model0_fallback: bool = False,
    record_dedupe: bool = True,
) -> ScheduleImageBuildResult:
    if not should_build_schedule_image_request(item, answer):
        return ScheduleImageBuildResult()

    image_config = storebot_image_send_config()
    suppressed_reason, suppressed_detail = schedule_image_policy_prebuild_suppression(image_config)
    if suppressed_reason:
        log(
            "schedule image_request suppressed by policy "
            f"request={req_id} reason={suppressed_reason} detail={suppressed_detail}"
        )
        return ScheduleImageBuildResult(suppressed_reason=suppressed_reason, suppressed_detail=suppressed_detail)

    image_request = build_schedule_image_request_candidate(
        item,
        answer,
        force_rebuild_days=model0_fallback,
    )
    if image_request and model0_fallback:
        image_request = annotate_work_schedule_broadcast_model0_fallback(image_request)
    validation = validate_schedule_image_request(image_request)
    dedupe_ttl_sec = schedule_image_dedupe_ttl_sec(image_config)
    dedupe_reason = schedule_image_dedupe_reason(image_config)
    if image_request and validation.get("complete") is True:
        if record_dedupe:
            duplicate, dedupe_key = mark_schedule_image_request_duplicate(item, image_request, ttl_sec=dedupe_ttl_sec)
            if duplicate:
                log(f"schedule image_request duplicate suppressed request={req_id} reason={dedupe_reason} key={dedupe_key[:120]}")
                return ScheduleImageBuildResult(suppressed_reason=dedupe_reason, dedupe_key=dedupe_key)
        annotate_schedule_image_validation(image_request, validation, retry_attempted=False)
        return ScheduleImageBuildResult(image_request=image_request)

    retry_item = schedule_realtime_retry_item(item, validation)
    retry_image_request = build_schedule_image_request_candidate(retry_item, answer, force_rebuild_days=True)
    if retry_image_request and model0_fallback:
        retry_image_request = annotate_work_schedule_broadcast_model0_fallback(retry_image_request)
    retry_validation = validate_schedule_image_request(retry_image_request)
    retry_validation["retry_attempted"] = True
    retry_validation["initial_missing_sections"] = validation.get("missing_sections") if isinstance(validation.get("missing_sections"), list) else []
    retry_validation["initial_reasons"] = validation.get("reasons") if isinstance(validation.get("reasons"), list) else []
    retry_validation["retry_completed"] = bool(retry_validation.get("complete"))
    if retry_image_request and retry_validation.get("complete") is True:
        if record_dedupe:
            duplicate, dedupe_key = mark_schedule_image_request_duplicate(item, retry_image_request, ttl_sec=dedupe_ttl_sec)
            if duplicate:
                log(
                    f"schedule image_request duplicate suppressed after retry request={req_id} "
                    f"reason={dedupe_reason} key={dedupe_key[:120]}"
                )
                return ScheduleImageBuildResult(suppressed_reason=dedupe_reason, dedupe_key=dedupe_key)
        annotate_schedule_image_validation(retry_image_request, retry_validation, retry_attempted=True)
        return ScheduleImageBuildResult(image_request=retry_image_request)

    self_fix_request_id = ""
    try:
        self_fix_request_id = enqueue_schedule_realtime_incomplete_self_fix(req_id, item, retry_validation, args)
    except Exception as exc:
        log(f"schedule realtime incomplete self_fix enqueue failed request={req_id}: {compact_error(str(exc), 200)}")
    return ScheduleImageBuildResult(
        image_request=None,
        incomplete=retry_validation,
        self_fix_request_id=self_fix_request_id,
    )


def build_schedule_image_request(item: dict[str, Any], answer: str) -> dict[str, Any] | None:
    return build_schedule_image_request_result(item, answer).image_request


def schedule_text_date_label(date_text: str, dow: str = "") -> str:
    try:
        date_obj = datetime.strptime(str(date_text or "").strip(), "%Y-%m-%d")
        label = f"{date_obj.month}/{date_obj.day}"
        resolved_dow = dow or DOW_KR_BY_WEEKDAY[date_obj.weekday()]
        return f"{label}({resolved_dow})" if resolved_dow else label
    except Exception:
        return str(date_text or "").strip()


def schedule_text_time_range(start: Any, end: Any) -> str:
    start_text = str(start or "").strip()
    end_text = str(end or "").strip()
    if start_text and end_text:
        return f"{start_text}~{end_text}"
    if start_text:
        return f"{start_text}~퇴근미정"
    if end_text:
        return f"출근미정~{end_text}"
    return "시간미정"


def schedule_text_shift_sort_key(shift: dict[str, Any]) -> tuple[int, str, int]:
    start_minutes = parse_time_minutes(str(shift.get("start") or ""))
    end_minutes = parse_time_minutes(str(shift.get("end") or ""))
    name = str(shift.get("employee_name") or shift.get("employee") or shift.get("employee_id") or "")
    return (
        start_minutes if start_minutes is not None else 99999,
        name,
        end_minutes if end_minutes is not None else 99999,
    )


def schedule_text_list_values(value: Any) -> list[str]:
    if not isinstance(value, list):
        return []
    out: list[str] = []
    for item in value:
        text = str(item or "").strip()
        if text:
            out.append(text)
    return out


def schedule_text_is_morning_shift(shift: dict[str, Any]) -> bool:
    start_minutes = parse_time_minutes(str(shift.get("start") or ""))
    return start_minutes is not None and start_minutes < 17 * 60


def schedule_text_fallback_from_image_request(image_request: dict[str, Any] | None) -> str:
    if not isinstance(image_request, dict):
        return ""
    if image_request.get("type") != "schedule_briefing":
        return ""
    if str(image_request.get("fallback_policy") or "") != "explicit_text_mode":
        return ""
    payload = image_request.get("payload")
    if not isinstance(payload, dict):
        return ""
    raw_days = payload.get("days")
    if not isinstance(raw_days, list) or not raw_days:
        return ""

    days = [day for day in raw_days if isinstance(day, dict)]
    if not days:
        return ""
    first_label = schedule_text_date_label(str(days[0].get("date") or ""), str(days[0].get("dow") or ""))
    last_label = schedule_text_date_label(str(days[-1].get("date") or ""), str(days[-1].get("dow") or ""))
    if len(days) == 1 or first_label == last_label:
        lines = [f"근무표 {first_label}"]
    else:
        lines = [f"근무표 {first_label}~{last_label}"]

    for day in days[:7]:
        label = schedule_text_date_label(str(day.get("date") or ""), str(day.get("dow") or ""))
        shifts_raw = day.get("shifts")
        shifts = [shift for shift in shifts_raw if isinstance(shift, dict)] if isinstance(shifts_raw, list) else []
        shifts.sort(key=schedule_text_shift_sort_key)
        morning_shifts = [shift for shift in shifts if schedule_text_is_morning_shift(shift)]
        afternoon_shifts = [shift for shift in shifts if not schedule_text_is_morning_shift(shift)]
        lines.append("")
        lines.append(f"{label} 오전 {len(morning_shifts)}명 / 오후 {len(afternoon_shifts)}명" if shifts else f"{label} 근무 없음")
        for section_name, section_shifts in (("오전", morning_shifts), ("오후", afternoon_shifts)):
            if section_shifts:
                lines.append(f"{section_name} {len(section_shifts)}명")
            for shift in section_shifts:
                name = str(shift.get("employee_name") or shift.get("employee") or shift.get("employee_id") or "").strip()
                if not name:
                    name = "이름없음"
                time_range = schedule_text_time_range(shift.get("start"), shift.get("end"))
                status = str(shift.get("status") or "").strip()
                if status.lower() in {"confirmed", "확정"}:
                    status = ""
                tail = status
                lines.append(f"- {time_range} {name}" + (f" {tail}" if tail else ""))
        dayoffs = schedule_text_list_values(day.get("dayoffs"))
        if dayoffs:
            lines.append("휴무: " + ", ".join(dayoffs[:12]))

        weather = day.get("weather")
        if isinstance(weather, dict):
            brief = str(weather.get("brief") or "").strip()
            if brief:
                lines.append(f"날씨: {brief}")
        holiday_name = str(day.get("holiday_name") or "").strip()
        if holiday_name:
            lines.append(f"공휴일: {holiday_name}")
        news = schedule_text_list_values(day.get("news") or day.get("issues") or day.get("operational_issues"))
        if news:
            lines.append("뉴스:")
            for item in news[:5]:
                lines.append(f"- {item}")

    if len(days) > 7:
        lines.append("")
        lines.append(f"... {len(days) - 7}일 더 있음")

    return "\n".join(lines).strip()


def normalize_attendance_field(value: Any) -> str:
    text = normalize_key_text(value)
    if text in {"actual_start", "start", "check_in", "checkin", "clock_in", "in", "출근", "출근확정", "도착"}:
        return "actual_start"
    if text in {"actual_end", "end", "check_out", "checkout", "clock_out", "out", "퇴근", "퇴근확정", "마감"}:
        return "actual_end"
    raise WorkerError(f"invalid attendance field: {value}")


def parse_time_minutes(value: str) -> int | None:
    match = re.fullmatch(r"([01]?\d|2[0-3]):([0-5]\d)", str(value or "").strip())
    if not match:
        return None
    return int(match.group(1)) * 60 + int(match.group(2))


def attendance_diff_minutes(scheduled: str, actual: str) -> int | None:
    sched_min = parse_time_minutes(scheduled)
    actual_min = parse_time_minutes(actual)
    if sched_min is None or actual_min is None:
        return None
    diff = actual_min - sched_min
    if diff > 720:
        diff -= 1440
    elif diff < -720:
        diff += 1440
    return diff


def default_attendance_date(field: str) -> str:
    when = datetime.now(KST)
    if field == "actual_end" and when.hour < 8:
        when -= timedelta(days=1)
    return when.strftime("%Y-%m-%d")


def normalize_attendance_time_category(value: Any, confirmed: Any = None) -> str:
    text = normalize_key_text(value)
    if text in {"past_confirmed", "pastconfirmed", "confirmed_past", "confirmedpast", "과거확정", "확정과거", "기록확정", "actual"}:
        return "past_confirmed"
    if text in {"past", "과거", "past_unconfirmed", "pastunconfirmed", "unconfirmed_past", "unconfirmedpast"}:
        return "past"
    if text in {"future", "scheduled", "schedule", "planned", "미래", "예정"}:
        return "future"
    if confirmed is True:
        return "past_confirmed"
    if confirmed is False:
        return "past"
    return ""


def execute_attendance_record(action: dict[str, Any]) -> dict[str, Any]:
    employees = fetch_employees()
    emp_id, emp = find_employee(action, employees)
    field = normalize_attendance_field(action.get("field") or action.get("kind") or action.get("attendance_type") or "actual_start")
    time_category = normalize_attendance_time_category(
        action.get("time_category") or action.get("category") or action.get("record_type"),
        action.get("confirmed"),
    )
    if time_category != "past_confirmed":
        raise WorkerError("attendance.record requires time_category=past_confirmed")
    date_text = validate_date_text(action.get("date") or action.get("attendance_date") or default_attendance_date(field))
    time_text = validate_time_text(action.get("time") or action.get("value") or datetime.now(KST).strftime("%H:%M"))
    source = compact_text(action.get("source") or "codex", 40) or "codex"
    dry_run = bool(action.get("dry_run"))
    force = bool(action.get("force") or action.get("overwrite"))

    path = workschedule_v2_path("attendance", date_text, sanitize_key(emp_id))
    existing = fb_get(path)
    existing_obj = existing if isinstance(existing, dict) else {}
    previous_value = str(existing_obj.get(field) or "").strip()
    if previous_value and not force:
        return {
            "ok": True,
            "operation": "attendance.record",
            "already_recorded": True,
            "dry_run": dry_run,
            "date": date_text,
            "employee_id": emp_id,
            "employee": emp.get("name") or emp.get("short_name") or emp_id,
            "field": field,
            "time_category": time_category,
            "time": previous_value,
        }

    now = datetime.now(KST)
    now_hm = now.strftime("%H:%M")
    recorded_at = now.strftime("%Y-%m-%dT%H:%M:%S%z")
    payload: dict[str, Any] = {
        "record_schema_version": 2,
        "employee_id": emp_id,
        "attendance_date": date_text,
        field: time_text,
        f"{field}_source": source,
        f"{field}_at": now_hm,
        f"{field}_at_ms": int(now.timestamp() * 1000),
        f"{field}_date": date_text,
        f"{field}_recorded_at": recorded_at,
        "updated_at": recorded_at,
        "updated_at_ms": int(now.timestamp() * 1000),
    }
    override = fb_get(workschedule_v2_path("overrides", date_text, sanitize_key(emp_id)))
    if isinstance(override, dict):
        schedule = override.get("shift") if isinstance(override.get("shift"), dict) else override
        baseline = str((schedule.get("start") if field == "actual_start" else schedule.get("end")) or "").strip()
        diff = attendance_diff_minutes(baseline, time_text)
        if diff is not None:
            payload["diff_start" if field == "actual_start" else "diff_end"] = diff
    if not dry_run:
        fb_patch(path, payload)
    return {
        "ok": True,
        "operation": "attendance.record",
        "dry_run": dry_run,
        "date": date_text,
        "employee_id": emp_id,
        "employee": emp.get("name") or emp.get("short_name") or emp_id,
        "field": field,
        "time_category": time_category,
        "time": time_text,
        "overwritten": bool(previous_value and force),
    }


def execute_attendance_query(action: dict[str, Any]) -> dict[str, Any]:
    employees = fetch_employees()
    dates = [validate_date_text(value) for value in as_list(action.get("dates") or action.get("date"))]
    if not dates:
        dates = [datetime.now(KST).strftime("%Y-%m-%d")]
    emp_filter = None
    if action.get("employee") or action.get("employee_id") or action.get("emp_id"):
        emp_filter = find_employee(action, employees)[0]
    days: list[dict[str, Any]] = []
    for date_text in dates:
        raw = fb_get(workschedule_v2_path("attendance", date_text)) or {}
        rows = []
        if isinstance(raw, dict):
            for emp_id, item in raw.items():
                if emp_filter and emp_id != emp_filter:
                    continue
                if not isinstance(item, dict):
                    continue
                emp = employees.get(emp_id) if isinstance(employees.get(emp_id), dict) else {}
                rows.append(
                    {
                        "employee_id": emp_id,
                        "employee": emp.get("name") or emp.get("short_name") or emp_id,
                        "actual_start": item.get("actual_start") or "",
                        "actual_end": item.get("actual_end") or "",
                        "actual_start_source": item.get("actual_start_source") or "",
                        "actual_end_source": item.get("actual_end_source") or "",
                    }
                )
        days.append({"date": date_text, "rows": rows})
    return {"ok": True, "operation": "attendance.query", "days": days}


def recent_mmdd(window_days: int) -> list[str]:
    when = datetime.now(KST)
    out: list[str] = []
    for offset in range(max(1, window_days)):
        out.append((when - timedelta(days=offset)).strftime("%m%d"))
    return out


def capture_sort_key(key: str, data: dict[str, Any]) -> tuple[int, str]:
    for field in ("captured_at", "order_time", "updated_at"):
        dt = parse_kst_datetime(data.get(field))
        if dt is not None:
            return (int(dt.timestamp() * 1000), key)
    parts = key.split("_")
    if len(parts) >= 3:
        hhmm = parts[2]
        if re.fullmatch(r"\d{4}", hhmm) and re.fullmatch(r"\d{4}", parts[0]):
            today = datetime.now(KST)
            try:
                dt = datetime(today.year, int(parts[0][:2]), int(parts[0][2:]), int(hhmm[:2]), int(hhmm[2:]), tzinfo=KST)
                return (int(dt.timestamp() * 1000), key)
            except ValueError:
                pass
    return (0, key)


def fetch_recent_captures(window_days: int, scan_limit: int) -> list[tuple[str, dict[str, Any]]]:
    raw = fb_get_query(
        CAPTURE_PATH,
        {
            "orderBy": json.dumps("$key"),
            "limitToLast": max(10, min(scan_limit, 200)),
        },
    ) or {}
    if not isinstance(raw, dict):
        return []
    prefixes = tuple(f"{day}_" for day in recent_mmdd(window_days))
    rows: list[tuple[str, dict[str, Any]]] = []
    for key, item in raw.items():
        if not isinstance(item, dict):
            continue
        if prefixes and not str(key).startswith(prefixes):
            continue
        rows.append((str(key), item))
    rows.sort(key=lambda pair: capture_sort_key(pair[0], pair[1]), reverse=True)
    return rows


def capture_matches_query(key: str, data: dict[str, Any], query: str) -> bool:
    if not query:
        return True
    tokens = [normalize_key_text(token) for token in re.split(r"[\s,./#-]+", query) if len(token.strip()) >= 2]
    if not tokens:
        return True
    haystacks = [
        key,
        data.get("order_no"),
        data.get("normalized_order_no"),
        data.get("display_code"),
        data.get("channel"),
        data.get("order_type"),
        data.get("payment"),
        data.get("address"),
        data.get("road_address"),
        data.get("menus_text"),
        data.get("customer_request"),
        data.get("raw_text"),
    ]
    normalized_haystack = " ".join(normalize_key_text(value) for value in haystacks if value)
    return all(token in normalized_haystack for token in tokens[:4])


def payment_needs_attention(data: dict[str, Any]) -> bool:
    charge = safe_int(data.get("charge_amount"))
    if charge > 0:
        return True
    payment = normalize_key_text(data.get("payment"))
    raw = normalize_key_text(data.get("raw_text"))
    if any(word in payment for word in ("카드", "현금", "후불", "만나서", "현장")):
        return True
    return any(word in raw for word in ("결제방식카드", "결제방식현금", "만나서결제", "후불"))


def infer_receipt_delta(raw_text: str) -> dict[str, Any]:
    lines = [line.strip() for line in str(raw_text or "").splitlines() if line.strip()]
    plus_lines = []
    minus_lines = []
    for line in lines:
        if re.search(r"(^|[\s(])\+\s*\d+", line) or re.search(r"\b추가\b", line):
            plus_lines.append(compact_text(line, 100))
        if re.search(r"(^|[\s(])-+\s*\d+", line) or re.search(r"\b(취소|삭제|반품)\b", line):
            minus_lines.append(compact_text(line, 100))
    summary = ""
    if plus_lines or minus_lines:
        summary = f"plus={len(plus_lines)}, minus={len(minus_lines)}"
    return {
        "plus_count_hint": len(plus_lines),
        "minus_count_hint": len(minus_lines),
        "plus_lines": plus_lines[:6],
        "minus_lines": minus_lines[:6],
        "summary": summary,
    }


def summarize_order_capture(key: str, data: dict[str, Any], include_raw: bool) -> dict[str, Any]:
    order_dt = parse_kst_datetime(data.get("captured_at") or data.get("order_time") or data.get("updated_at"))
    age_min = None
    if order_dt is not None:
        age_min = max(0, round((datetime.now(KST) - order_dt).total_seconds() / 60))
    raw_text = str(data.get("raw_text") or "")
    row: dict[str, Any] = {
        "capture_key": key,
        "order_no": compact_text(data.get("order_no") or data.get("normalized_order_no"), 16),
        "display_code": compact_text(data.get("display_code"), 24),
        "channel": compact_text(data.get("channel"), 20),
        "order_type": compact_text(data.get("order_type"), 16),
        "payment": compact_text(data.get("payment"), 24),
        "payment_attention": payment_needs_attention(data),
        "charge_amount": safe_int(data.get("charge_amount")),
        "total_amount": safe_int(data.get("total_amount")),
        "order_time": compact_text(data.get("order_time") or data.get("captured_at"), 32),
        "age_min": age_min,
        "address": compact_address(data.get("road_address") or data.get("address"), 48),
        "menus": compact_text(data.get("menus_text") or data.get("menus"), 140),
        "customer_request": compact_text(data.get("customer_request"), 140),
        "kds_state": compact_text(data.get("kds_state"), 24),
        "pack_ready_at": compact_text(data.get("pack_ready_at"), 32),
        "cook_started_at": compact_text(data.get("cook_started_at"), 32),
        "estimated_cook_minutes": safe_int(data.get("estimated_cook_minutes")),
        "delivery_candidate_status": compact_text(data.get("delivery_candidate_status"), 24),
        "receipt_delta_hint": infer_receipt_delta(raw_text),
    }
    if include_raw:
        row["raw_text"] = raw_text[:1800]
    return row


def execute_order_recent(action: dict[str, Any]) -> dict[str, Any]:
    try:
        limit = max(1, min(int(action.get("limit") or 5), 12))
    except (TypeError, ValueError):
        limit = 5
    try:
        scan_limit = max(limit, min(int(action.get("scan_limit") or 80), 200))
    except (TypeError, ValueError):
        scan_limit = 80
    try:
        window_days = max(1, min(int(action.get("window_days") or 2), 7))
    except (TypeError, ValueError):
        window_days = 2
    query = str(action.get("query") or action.get("text") or "").strip()
    include_raw = bool(action.get("include_raw") or action.get("raw") or action.get("receipt_raw"))
    only_attention = bool(action.get("only_attention") or action.get("attention_only"))
    rows = []
    for key, data in fetch_recent_captures(window_days, scan_limit):
        if not capture_matches_query(key, data, query):
            continue
        row = summarize_order_capture(key, data, include_raw=include_raw)
        if only_attention and not (row.get("payment_attention") or safe_int(row.get("age_min")) >= 45 or row.get("receipt_delta_hint", {}).get("minus_count_hint")):
            continue
        rows.append(row)
        if len(rows) >= limit:
            break
    return {
        "ok": True,
        "operation": "order.recent",
        "query": query,
        "window_days": window_days,
        "include_raw": include_raw,
        "count": len(rows),
        "orders": rows,
        "note": "최근 전표 요약입니다. 결제/주소/취소/추가/지연 판단은 이 결과와 카톡 문맥을 함께 보고 하세요.",
    }


def clean_alert_message(value: Any, limit: int = 500) -> str:
    text = re.sub(r"\s+", " ", str(value or "").strip())
    return text[:limit]


def execute_alert_schedule(action: dict[str, Any], req_id: str) -> dict[str, Any]:
    raw_at = action.get("alert_at") or action.get("at") or action.get("datetime")
    if not raw_at and (action.get("date") and action.get("time")):
        raw_at = f"{action.get('date')} {action.get('time')}"
    alert_at, alert_at_ms = validate_kst_datetime_text(raw_at)
    now = now_ms()
    if alert_at_ms < now - 60_000:
        raise WorkerError(f"alert time is in the past: {alert_at}")
    if alert_at_ms > now + 366 * 24 * 60 * 60 * 1000:
        raise WorkerError("alert time is too far")
    message = clean_alert_message(action.get("message") or action.get("output_text") or action.get("text"))
    if not message:
        raise WorkerError("alert message missing")
    room_id = str(action.get("room_id") or action.get("room") or "storebot_group").strip()
    room_name = str(action.get("room_name") or action.get("roomTitle") or "BBQ하이닉스점 10").strip()
    event_at = ""
    event_at_ms = 0
    raw_event_at = action.get("event_at") or action.get("target_at")
    if raw_event_at:
        event_at, event_at_ms = validate_kst_datetime_text(raw_event_at)
    key = f"alert_{alert_at_ms}_{now}_{secrets.token_hex(3)}"
    payload = {
        "status": "pending",
        "cancelled": False,
        "fired": False,
        "alert_at": alert_at,
        "alert_at_ms": alert_at_ms,
        "event_at": event_at,
        "event_at_ms": event_at_ms,
        "message": message,
        "room_id": room_id,
        "room_name": room_name,
        "created_at_ms": now,
        "created_at": kst_text(now),
        "created_by": str(action.get("created_by") or action.get("sender") or "codex").strip()[:80],
        "source": "storebot_codex",
        "source_request_id": req_id,
        "reason": clean_alert_message(action.get("reason") or action.get("rationale"), 180),
    }
    if bool(action.get("dry_run")):
        return {"ok": True, "operation": "alert.schedule", "dry_run": True, "id": key, "alert": payload}
    fb_put(f"{TEMP_ALERTS_PATH}/{sanitize_key(key)}", payload)
    fb_put(TEMP_ALERTS_LATEST_PATH, {"id": key, **payload})
    return {"ok": True, "operation": "alert.schedule", "id": key, "alert_at": alert_at, "message": message}


def execute_alert_query(action: dict[str, Any]) -> dict[str, Any]:
    try:
        limit = max(1, min(int(action.get("limit") or 12), 50))
    except (TypeError, ValueError):
        limit = 12
    include_done = bool(action.get("include_done") or action.get("include_fired"))
    raw = fb_get(TEMP_ALERTS_PATH) or {}
    if not isinstance(raw, dict):
        raw = {}
    rows: list[dict[str, Any]] = []
    for key, item in raw.items():
        if not isinstance(item, dict) or str(key) == "latest":
            continue
        status = str(item.get("status") or "pending")
        if not include_done and status in {"fired", "cancelled"}:
            continue
        rows.append(
            {
                "id": str(key),
                "status": status,
                "alert_at": str(item.get("alert_at") or ""),
                "event_at": str(item.get("event_at") or ""),
                "message": clean_alert_message(item.get("message"), 140),
                "room_name": str(item.get("room_name") or ""),
                "created_by": str(item.get("created_by") or ""),
            }
        )
    rows.sort(key=lambda row: (row.get("alert_at") or "", row.get("id") or ""))
    return {"ok": True, "operation": "alert.query", "count": len(rows), "alerts": rows[:limit]}


def execute_alert_cancel(action: dict[str, Any], req_id: str) -> dict[str, Any]:
    alert_id = sanitize_key(str(action.get("id") or action.get("alert_id") or "").strip(), "")
    if not alert_id:
        raise WorkerError("alert id missing")
    raw = fb_get(f"{TEMP_ALERTS_PATH}/{alert_id}")
    if not isinstance(raw, dict):
        raise WorkerError(f"alert not found: {alert_id}")
    if str(raw.get("status") or "") == "fired" or raw.get("fired") is True:
        raise WorkerError(f"alert already fired: {alert_id}")
    payload = {
        "status": "cancelled",
        "cancelled": True,
        "cancelled_at_ms": now_ms(),
        "cancelled_by_request_id": req_id,
    }
    if bool(action.get("dry_run")):
        return {"ok": True, "operation": "alert.cancel", "dry_run": True, "id": alert_id, "patch": payload}
    fb_patch(f"{TEMP_ALERTS_PATH}/{alert_id}", payload)
    return {"ok": True, "operation": "alert.cancel", "id": alert_id}


def action_results_list(value: Any) -> list[dict[str, Any]]:
    if isinstance(value, list):
        return [item for item in value if isinstance(item, dict)]
    if isinstance(value, dict):
        return [value]
    return []


def collect_schedule_writes(action_results: list[dict[str, Any]]) -> list[dict[str, Any]]:
    writes: list[dict[str, Any]] = []
    for result in action_results:
        operation = str(result.get("operation") or "")
        if operation not in {"schedule.upsert_shift", "schedule.off", "schedule.clear", "work_schedule.upsert"}:
            continue
        raw_writes = result.get("writes")
        if not isinstance(raw_writes, list):
            continue
        for raw in raw_writes:
            if not isinstance(raw, dict):
                continue
            writes.append(
                {
                    "date": raw.get("date") or "",
                    "employee": raw.get("employee") or raw.get("employee_id") or "",
                    "start": raw.get("start") or "",
                    "end": raw.get("end") or "",
                    "role": raw.get("role") or "",
                    "status": raw.get("status") or "",
                    "off": bool(raw.get("off")),
                    "cleared": bool(raw.get("cleared")),
                }
            )
    return writes[:8]


def request_issue(item: dict[str, Any], age_ms: int, action_results: list[dict[str, Any]]) -> str:
    status = str(item.get("status") or "pending").lower()
    if status == "pending":
        return "pending"
    if status == "running":
        return "stale_running" if age_ms > 10 * 60 * 1000 else "running"
    if status == "error":
        return "error"
    if status != "done":
        return f"status_{status or 'unknown'}"
    if any(result.get("ok") is not True for result in action_results):
        return "action_error"
    reply_skipped = bool(item.get("reply_skipped"))
    publish_disabled = bool(item.get("publish_disabled"))
    outbound_key = str(item.get("outbound_key") or "")
    if not reply_skipped and not publish_disabled and not outbound_key:
        return "publish_missing"
    return ""


def action_result_domain(result: dict[str, Any]) -> str:
    operation = str(result.get("operation") or result.get("type") or "").lower()
    if "schedule" in operation or "workschedule" in operation:
        return "schedule"
    if "weather" in operation:
        return "weather"
    if "news" in operation or "search" in operation or "sports" in operation:
        return "search_realtime"
    return ""


def request_cli_diagnostic_candidate(
    req_id: str,
    item: dict[str, Any],
    issue: str,
    action_results: list[dict[str, Any]],
    age_ms: int,
) -> dict[str, Any] | None:
    if issue in {"stale_running", "publish_missing"}:
        return {
            "candidate_type": "request_stale_running_or_publish_missing",
            "severity": "error",
            "request_id": req_id,
            "domain": "storebot",
            "evidence": {
                "issue": issue,
                "status": str(item.get("status") or ""),
                "age_ms": age_ms,
                "outbound_key": str(item.get("outbound_key") or ""),
                "publish_disabled": bool(item.get("publish_disabled")),
                "reply_skipped": bool(item.get("reply_skipped")),
                "source": str(item.get("source") or ""),
                "event_kind": str(item.get("event_kind") or item.get("kind") or ""),
            },
            "safe_scope": "StoreBot request lifecycle, stale running recovery, publish bookkeeping. Do not send Kakao messages directly.",
        }

    if issue == "action_error":
        domains = sorted({domain for result in action_results if (domain := action_result_domain(result))})
        if domains:
            return {
                "candidate_type": "action_tool_failure_repeated",
                "severity": "warning",
                "request_id": req_id,
                "domain": "storebot",
                "action_domains": domains,
                "evidence": {
                    "issue": issue,
                    "action_domains": domains,
                    "action_results": compact_payload(action_results, 2500),
                    "source": str(item.get("source") or ""),
                    "event_kind": str(item.get("event_kind") or item.get("kind") or ""),
                },
                "safe_scope": "StoreBot action tool diagnostics for schedule/search/weather failures. Do not fabricate data or send Kakao messages.",
            }

    output_payload = item.get("output_payload") if isinstance(item.get("output_payload"), dict) else {}
    reason = str(output_payload.get("reason") or item.get("skip_reason") or "")
    if reason in {"internal_action_protocol_blocked", "malformed_storebot_output_blocked"}:
        return {
            "candidate_type": "bridge_protocol_suppressed",
            "severity": "warning",
            "request_id": req_id,
            "domain": "storebot",
            "evidence": {
                "reason": reason,
                "output_category": str(item.get("output_category") or ""),
                "source": str(item.get("source") or ""),
                "event_kind": str(item.get("event_kind") or item.get("kind") or ""),
            },
            "safe_scope": "StoreBot output contract and bridge suppression diagnostics. Do not send suppressed protocol text to Kakao.",
        }

    if str(item.get("output_category") or "") == "schedule_realtime_incomplete":
        return {
            "candidate_type": "schedule_image_required_data_incomplete",
            "severity": "error",
            "request_id": req_id,
            "domain": "storebot",
            "missing_sections": output_payload.get("missing_sections") if isinstance(output_payload.get("missing_sections"), list) else [],
            "evidence": {
                "output_category": "schedule_realtime_incomplete",
                "output_payload": compact_payload(output_payload, 3000),
                "source": str(item.get("source") or ""),
                "event_kind": str(item.get("event_kind") or item.get("kind") or ""),
            },
            "safe_scope": "StoreBot schedule image realtime data collection and guard diagnostics. Do not fabricate realtime data.",
        }
    return None


def runtime_cli_diagnostic_candidates(snapshot: dict[str, Any]) -> list[dict[str, Any]]:
    candidates: list[dict[str, Any]] = []
    runtime = snapshot.get("runtime") if isinstance(snapshot.get("runtime"), dict) else {}
    heartbeat = runtime.get("heartbeat") if isinstance(runtime.get("heartbeat"), dict) else {}
    self_sync = runtime.get("self_sync") if isinstance(runtime.get("self_sync"), dict) else {}
    metrics = snapshot.get("metrics") if isinstance(snapshot.get("metrics"), dict) else {}
    samples = snapshot.get("samples") if isinstance(snapshot.get("samples"), dict) else {}
    issue_counts = metrics.get("issue_counts") if isinstance(metrics.get("issue_counts"), dict) else {}

    local_direct = metrics.get("local_direct") if isinstance(metrics.get("local_direct"), dict) else {}
    slow_samples = samples.get("slow_local_direct") if isinstance(samples.get("slow_local_direct"), list) else []
    if heartbeat.get("local_direct_listening") is not True or safe_int(local_direct.get("elapsed_p95_ms")) > 180_000 or len(slow_samples) >= 2:
        candidates.append(
            {
                "candidate_type": "local_direct_unavailable_or_timeout",
                "severity": "error",
                "domain": "storebot",
                "evidence": {
                    "heartbeat": compact_payload(heartbeat, 1500),
                    "local_direct": compact_payload(local_direct, 1200),
                    "slow_samples": compact_payload(slow_samples[:5], 2000),
                },
                "safe_scope": "StoreBot local-direct health, timeout, and local recovery diagnostics only.",
            }
        )

    self_sync_error = str(self_sync.get("error") or "")
    heartbeat_bundle_sha = str(heartbeat.get("bundle_sha256") or heartbeat.get("bundle_sha") or "")
    self_sync_bundle_sha = str(self_sync.get("bundle_sha256") or self_sync.get("bundle_sha") or "")
    if (
        str(self_sync.get("status") or "").lower() == "error"
        or "unexpected file" in self_sync_error.lower()
        or bool(heartbeat_bundle_sha and self_sync_bundle_sha and heartbeat_bundle_sha != self_sync_bundle_sha)
    ):
        candidates.append(
            {
                "candidate_type": "worker_bundle_adoption_mismatch",
                "severity": "error",
                "domain": "storebot",
                "evidence": {
                    "heartbeat_bundle_version": heartbeat.get("bundle_version"),
                    "heartbeat_bundle_sha256": heartbeat_bundle_sha,
                    "self_sync": compact_payload(self_sync, 1500),
                },
                "safe_scope": "StoreBot worker bundle self-sync/adoption diagnostics. Do not force reset or overwrite unrelated files.",
            }
        )

    if safe_int(issue_counts.get("stale_running")) > 0 or safe_int(issue_counts.get("publish_missing")) > 0:
        candidates.append(
            {
                "candidate_type": "request_stale_running_or_publish_missing",
                "severity": "error",
                "domain": "storebot",
                "evidence": {
                    "issue_counts": compact_payload(issue_counts, 1200),
                    "recent_errors": compact_payload((samples.get("recent_errors") or [])[:6], 2400),
                },
                "safe_scope": "StoreBot request lifecycle diagnostics. Do not send Kakao messages directly.",
            }
        )

    return candidates


def outbound_schedule_image_stale_candidates(hours: float) -> list[dict[str, Any]]:
    try:
        raw = fb_get(OUTBOUND_PATH) or {}
    except Exception as exc:
        log(f"outbound schedule image stale scan failed: {compact_error(str(exc), 160)}")
        return []
    if not isinstance(raw, dict):
        return []
    cutoff = now_ms() - int(max(1.0, hours) * 60 * 60 * 1000)
    stale_after_ms = 10 * 60 * 1000
    samples: list[dict[str, Any]] = []
    for key, item in raw.items():
        if not isinstance(item, dict):
            continue
        image_request = item.get("image_request")
        if not isinstance(image_request, dict) or str(image_request.get("type") or "") != "schedule_briefing":
            continue
        if item.get("sent") is True:
            continue
        ts_ms = normalize_ts_ms(item.get("created_at_ms") or item.get("queued_at_ms") or 0)
        if ts_ms <= 0:
            ts_sec = safe_int(item.get("ts"))
            ts_ms = ts_sec * 1000 if ts_sec > 0 else 0
        if ts_ms <= 0 or ts_ms < cutoff or now_ms() - ts_ms < stale_after_ms:
            continue
        samples.append(
            {
                "outbound_key": str(key),
                "request_id": str(item.get("request_id") or ""),
                "room_id": str(item.get("room_id") or ""),
                "room_name": str(item.get("room_name") or ""),
                "age_min": int((now_ms() - ts_ms) / 60000),
                "image_send_policy": str(item.get("image_send_policy") or ""),
                "image_fallback_policy": str(item.get("image_fallback_policy") or ""),
            }
        )
    if not samples:
        return []
    return [
        {
            "candidate_type": "schedule_image_render_or_send_failed",
            "severity": "error",
            "domain": "storebot",
            "evidence": {
                "stale_after_minutes": int(stale_after_ms / 60000),
                "count": len(samples),
                "samples": compact_payload(samples[:8], 3000),
            },
            "safe_scope": "StoreBotTermux schedule image renderer/transport and pending queue diagnostics. Do not send Kakao messages directly.",
        }
    ]


def dedupe_cli_diagnostic_candidates(candidates: list[dict[str, Any]]) -> list[dict[str, Any]]:
    seen: set[str] = set()
    out: list[dict[str, Any]] = []
    for candidate in candidates:
        if not isinstance(candidate, dict):
            continue
        candidate_type = str(candidate.get("candidate_type") or "")
        domain = str(candidate.get("domain") or "storebot")
        request_id = str(candidate.get("request_id") or "")
        key = f"{candidate_type}:{domain}:{request_id or short_text_hash(json.dumps(compact_payload(candidate.get('evidence') or {}, 1200), ensure_ascii=False, sort_keys=True))}"
        if key in seen:
            continue
        seen.add(key)
        out.append(candidate)
    return out


def compact_message_preview(item: dict[str, Any], include_messages: bool) -> str:
    if not include_messages:
        return ""
    if item.get("message_redacted") is True:
        return ""
    message = str(item.get("message") or item.get("text") or "").strip()
    if not message:
        return ""
    return message[:120]


def execute_missed_chat_query(action: dict[str, Any]) -> dict[str, Any]:
    try:
        hours = max(1.0, min(float(action.get("hours") or 24), 168.0))
    except (TypeError, ValueError):
        hours = 24.0
    try:
        limit = max(1, min(int(action.get("limit") or 20), 50))
    except (TypeError, ValueError):
        limit = 20
    include_ok = bool(action.get("include_ok") or action.get("include_done"))
    include_stamp_gaps = bool(action.get("include_stamp_gaps") or action.get("include_learning_gaps"))
    include_tests = bool(action.get("include_tests"))
    include_messages = bool(action.get("include_messages"))
    room_filter = str(action.get("room_id") or action.get("room") or "").strip()

    raw = fb_get(REQUESTS_PATH) or {}
    if not isinstance(raw, dict):
        raw = {}
    cutoff = now_ms() - int(hours * 60 * 60 * 1000)
    rows: list[dict[str, Any]] = []
    summary = {
        "checked": 0,
        "pending": 0,
        "running": 0,
        "stale_running": 0,
        "error": 0,
        "action_error": 0,
        "learning_stamp_missing": 0,
        "learning_stamp_error": 0,
        "publish_missing": 0,
        "ok_done": 0,
        "schedule_write_count": 0,
    }
    recent_schedule_writes: list[dict[str, Any]] = []

    for req_id, item in raw.items():
        if not isinstance(item, dict):
            continue
        ts_ms = normalize_ts_ms(item.get("ts") or item.get("created_at_ms") or item.get("started_at_ms"))
        if ts_ms < cutoff:
            continue
        if not include_tests and str(item.get("source") or "").startswith("manual_test"):
            continue
        if room_filter and str(item.get("room_id") or item.get("room") or "") != room_filter:
            continue
        summary["checked"] += 1
        action_results = action_results_list(item.get("last_action_results"))
        age_ms = now_ms() - normalize_ts_ms(item.get("started_at_ms") or item.get("created_at_ms") or ts_ms)
        issue = request_issue(item, age_ms, action_results)
        stamp_status = str(item.get("learning_stamp_status") or "")
        if stamp_status and stamp_status != "written":
            summary["learning_stamp_error"] += 1
            if include_stamp_gaps and not issue:
                issue = "learning_stamp_error"
        elif stamp_status != "written":
            summary["learning_stamp_missing"] += 1
            if include_stamp_gaps and not issue:
                issue = "learning_stamp_missing"
        schedule_writes = collect_schedule_writes(action_results)
        if schedule_writes:
            summary["schedule_write_count"] += len(schedule_writes)
            for write in schedule_writes:
                recent_schedule_writes.append({"request_id": str(req_id), **write})
        if issue:
            if issue in summary:
                summary[issue] += 1
        else:
            summary["ok_done"] += 1
            if not include_ok:
                continue
        rows.append(
            {
                "request_id": str(req_id),
                "status": str(item.get("status") or "pending"),
                "issue": issue or "ok",
                "event_kind": str(item.get("event_kind") or "chat"),
                "source": str(item.get("source") or ""),
                "room_id": str(item.get("room_id") or item.get("room") or ""),
                "sender": str(item.get("sender") or item.get("from") or ""),
                "ts_kst": kst_text(ts_ms),
                "age_min": max(0, round(age_ms / 60000)),
                "reply_skipped": bool(item.get("reply_skipped")),
                "outbound_queued": bool(item.get("outbound_key")),
                "publish_disabled": bool(item.get("publish_disabled")),
                "learning_stamp_status": str(item.get("learning_stamp_status") or ""),
                "action_count": int(item.get("last_action_count") or 0),
                "schedule_writes": schedule_writes,
                "message_preview": compact_message_preview(item, include_messages),
                "error": compact_error(item.get("error") or item.get("learning_stamp_error") or "", 200),
            }
        )

    rows.sort(key=lambda row: (row["issue"] == "ok", row["ts_kst"], row["request_id"]), reverse=True)
    return {
        "ok": True,
        "operation": "missed_chat.query",
        "window_hours": hours,
        "limit": limit,
        "summary": summary,
        "items": rows[:limit],
        "recent_schedule_writes": recent_schedule_writes[-10:],
        "note": "Firebase requests queue 기준입니다. 카카오 화면에는 있었지만 큐에 안 들어온 원문은 사진/복사 텍스트로 chat_replay 재주입이 필요합니다.",
    }


GUIDANCE_SCOPES = {
    "general",
    "briefing",
    "tool_use",
    "reply_style",
    "skip_rule",
    "schedule",
    "task",
    "payment",
    "logistics",
    "order",
    "delivery",
    "dinein",
    "receipt",
    "sports",
    "weather",
    "alert",
    "memory",
    "safety",
}


def clean_guidance_scope(value: Any) -> str:
    scope = normalize_key_text(str(value or "general")) or "general"
    return scope if scope in GUIDANCE_SCOPES else "general"


def clean_guidance_text(value: Any, limit: int = 240) -> str:
    text = re.sub(r"\s+", " ", str(value or "").strip())
    return text[:limit]


def enabled_dynamic_guidance_rules(limit: int = 24) -> list[dict[str, Any]]:
    raw = fb_get(DYNAMIC_GUIDANCE_RULES_PATH) or {}
    if not isinstance(raw, dict):
        return []
    rules: list[dict[str, Any]] = []
    for key, item in raw.items():
        if not isinstance(item, dict):
            continue
        if item.get("enabled") is False:
            continue
        rule = clean_guidance_text(item.get("rule") or item.get("text"), 240)
        if not rule:
            continue
        rules.append(
            {
                "id": str(key),
                "scope": clean_guidance_scope(item.get("scope")),
                "rule": rule,
                "rationale": clean_guidance_text(item.get("rationale") or "", 160),
                "created_at_ms": normalize_ts_ms(item.get("created_at_ms") or 0),
                "last_seen_at_ms": normalize_ts_ms(item.get("last_seen_at_ms") or item.get("created_at_ms") or 0),
                "source_request_id": str(item.get("source_request_id") or ""),
            }
        )
    rules.sort(key=lambda item: (int(item.get("last_seen_at_ms") or 0), item.get("id") or ""))
    return rules[-limit:]


def build_dynamic_guidance_overlay() -> str:
    rules = enabled_dynamic_guidance_rules()
    if not rules:
        return ""
    lines = [
        "## 동적 운영 기준",
        "아래 기준은 Firebase runtime guidance overlay에서 온 최신 운영 기준이다. 기본 스킬/MD와 충돌하면 더 구체적이고 최신인 기준을 우선하되, 실행은 여전히 허용 action 안에서만 한다.",
    ]
    for item in rules:
        lines.append(f"- [{item['scope']}] {item['rule']}")
    return "\n".join(lines)


def build_runtime_guide(base_guide: str, args: argparse.Namespace) -> str:
    skill_path, skill = read_skill(getattr(args, "skill_name", "") or "")
    if skill:
        if env_bool("STOREBOT_CODEX_FULL_GUIDE", False):
            guide = (
                f"{base_guide.rstrip()}\n\n"
                f"## StoreBot Kakao Reply Skill SOT\n"
                f"아래는 카카오 답변 판단과 근무표 브리핑 세부 규칙의 단일 기준 원문이다: {skill_path}\n\n"
                f"{skill}\n"
            )
        else:
            guide = (
                "## StoreBot Codex Bridge Contract\n"
                "- 카카오톡 원문에 대한 첫 판단은 항상 Codex AI가 한다.\n"
                "- StoreBotTermux/worker는 Codex가 고른 action 실행, DB 조회, PNG payload 생성, 카톡 운반만 맡는다.\n"
                "- 이 세션에는 직접 MCP 도구가 없으므로 외부 DB/검색/알람/가이드 작업은 `STOREBOT_ACTIONS` JSON으로 요청한다.\n"
                "- 답변이 필요 없으면 정확히 `SKIP`만 출력한다.\n"
                "- 근무표/브리핑 세부 규칙은 아래 `SKILL.md` 원문만 단일 기준으로 본다.\n\n"
                f"## StoreBot Kakao Reply Skill SOT\n"
                f"source: {skill_path}\n\n"
                f"{skill}\n"
            )
    else:
        guide = base_guide
    if not getattr(args, "dynamic_guidance", True):
        return guide
    try:
        overlay = build_dynamic_guidance_overlay()
    except Exception as exc:
        log(f"dynamic guidance load failed: {compact_error(str(exc), 180)}")
        return guide
    if not overlay:
        return guide
    return f"{guide.rstrip()}\n\n{overlay}\n"


def execute_guidance_query(action: dict[str, Any]) -> dict[str, Any]:
    try:
        limit = max(1, min(int(action.get("limit") or 12), 30))
    except (TypeError, ValueError):
        limit = 12
    scope = str(action.get("scope") or "").strip()
    rules = enabled_dynamic_guidance_rules(limit=30)
    if scope:
        cleaned_scope = clean_guidance_scope(scope)
        rules = [rule for rule in rules if rule.get("scope") == cleaned_scope]
    return {
        "ok": True,
        "operation": "guidance.query",
        "rules": rules[-limit:],
        "count": len(rules),
    }


def find_exact_guidance_rule(scope: str, rule: str) -> tuple[str, dict[str, Any]]:
    raw = fb_get(DYNAMIC_GUIDANCE_RULES_PATH) or {}
    if not isinstance(raw, dict):
        return "", {}
    matches: list[tuple[str, dict[str, Any]]] = []
    for key, value in raw.items():
        if not isinstance(value, dict):
            continue
        if clean_guidance_scope(value.get("scope")) != scope:
            continue
        if clean_guidance_text(value.get("rule") or value.get("text"), 260) != rule:
            continue
        matches.append((str(key), dict(value)))
    if not matches:
        return "", {}
    matches.sort(
        key=lambda pair: (
            normalize_ts_ms(pair[1].get("last_seen_at_ms") or pair[1].get("created_at_ms") or 0),
            pair[0],
        ),
        reverse=True,
    )
    return matches[0]


def guidance_occurrence_count(value: Any, default: int = 0) -> int:
    try:
        return max(0, int(value))
    except (TypeError, ValueError):
        return default


def guidance_source_request_ids(existing: dict[str, Any], req_id: str) -> list[str]:
    raw = existing.get("source_request_ids")
    values = [str(value).strip() for value in raw] if isinstance(raw, list) else []
    legacy = str(existing.get("source_request_id") or "").strip()
    if legacy:
        values.append(legacy)
    if req_id:
        values.append(req_id)
    unique: list[str] = []
    for value in values:
        if value and value not in unique:
            unique.append(value[:120])
    return unique[-12:]


def execute_guidance_add_rule(
    action: dict[str, Any],
    req_id: str,
    args: argparse.Namespace,
    item: dict[str, Any] | None = None,
) -> dict[str, Any]:
    rule = clean_guidance_text(action.get("rule") or action.get("text"), 260)
    if not rule:
        raise WorkerError("guidance rule missing")
    rationale = clean_guidance_text(action.get("rationale") or action.get("reason") or "", 200)
    scope = clean_guidance_scope(action.get("scope"))
    observed_at_ms = now_ms()
    rule_fingerprint = hashlib.sha256(f"{scope}\n{rule}".encode("utf-8")).hexdigest()
    key = f"rule_{rule_fingerprint[:20]}"
    existing_key = ""
    existing: dict[str, Any] = {}
    if not bool(action.get("dry_run")):
        existing_key, existing = find_exact_guidance_rule(scope, rule)
        if existing_key:
            key = existing_key
    created_at_ms = normalize_ts_ms(existing.get("created_at_ms") or 0) or observed_at_ms
    first_seen_at_ms = normalize_ts_ms(existing.get("first_seen_at_ms") or 0) or created_at_ms
    prior_occurrence_count = guidance_occurrence_count(existing.get("occurrence_count"), 1 if existing else 0)
    occurrence_count = prior_occurrence_count + 1
    feedback_count = guidance_occurrence_count(existing.get("feedback_count"), prior_occurrence_count) + 1
    request_item = item if isinstance(item, dict) else {}
    feedback_text = clean_guidance_text(
        action.get("feedback") or request_item.get("message") or request_item.get("text") or rationale,
        400,
    )
    feedback_event = {
        "request_id": req_id[:120],
        "corrected_request_id": str(request_item.get("_previous_turn_request_id") or "")[:120],
        "corrected_reply_sha256": str(request_item.get("_previous_turn_reply_sha256") or "")[:64],
        "feedback_text_sha256": clean_reply_sha256(feedback_text) if feedback_text else "",
        "feedback_text_len": len(feedback_text),
        "recorded_at_ms": observed_at_ms,
    }
    feedback_history = existing.get("feedback_history")
    bounded_feedback_history = [entry for entry in feedback_history if isinstance(entry, dict)][-11:] if isinstance(feedback_history, list) else []
    bounded_feedback_history.append(feedback_event)
    payload = dict(existing)
    payload.update({
        "enabled": True,
        "scope": scope,
        "rule": rule,
        "rationale": rationale or clean_guidance_text(existing.get("rationale") or "", 200),
        "source_request_id": req_id,
        "source_request_ids": guidance_source_request_ids(existing, req_id),
        "created_at_ms": created_at_ms,
        "first_seen_at_ms": first_seen_at_ms,
        "last_seen_at_ms": observed_at_ms,
        "occurrence_count": occurrence_count,
        "feedback_count": feedback_count,
        "last_feedback": feedback_event,
        "feedback_history": bounded_feedback_history,
        "rule_fingerprint": rule_fingerprint,
        "worker": args.node,
        "model": model_label(args),
        "reasoning_effort": reasoning_label(args),
    })
    if bool(action.get("dry_run")):
        return {"ok": True, "operation": "guidance.add_rule", "dry_run": True, "rule": payload}
    fb_put(f"{DYNAMIC_GUIDANCE_RULES_PATH}/{sanitize_key(key)}", payload)
    fb_put(DYNAMIC_GUIDANCE_LATEST_PATH, {"id": key, **payload})
    return {
        "ok": True,
        "operation": "guidance.add_rule",
        "id": key,
        "scope": scope,
        "rule": rule,
        "deduplicated": bool(existing_key),
        "occurrence_count": occurrence_count,
        "feedback_count": feedback_count,
    }


def parse_rss_published_ms(value: str) -> int:
    text = str(value or "").strip()
    if not text:
        return 0
    try:
        parsed = parsedate_to_datetime(text)
        if parsed.tzinfo is None:
            parsed = parsed.replace(tzinfo=timezone.utc)
        return int(parsed.timestamp() * 1000)
    except Exception:
        return 0


def fetch_rss_items(query: str, max_results: int) -> tuple[list[dict[str, Any]], int]:
    params = urllib.parse.urlencode({"q": query, "hl": "ko", "gl": "KR", "ceid": "KR:ko"})
    url = f"https://news.google.com/rss/search?{params}"
    req = urllib.request.Request(url, headers={"User-Agent": "StoreBotCodexWorker/1"})
    fetched_at_ms = now_ms()
    with urllib.request.urlopen(req, timeout=15) as resp:
        raw = resp.read()
    root = ET.fromstring(raw)
    items: list[dict[str, Any]] = []
    missing_published_count = 0
    for item in root.findall(".//item"):
        title = "".join(item.findtext("title") or "").strip()
        link = "".join(item.findtext("link") or "").strip()
        published = "".join(item.findtext("pubDate") or "").strip()
        published_at_ms = parse_rss_published_ms(published)
        if not published_at_ms:
            missing_published_count += 1
        source = ""
        source_node = item.find("{http://www.google.com/schemas/sitemap-news/0.9}source")
        if source_node is not None and source_node.text:
            source = source_node.text.strip()
        items.append(
            {
                "title": title,
                "source": source,
                "published": published,
                "published_at_ms": published_at_ms,
                "fetched_at_ms": fetched_at_ms,
                "age_minutes": max(0, int((fetched_at_ms - published_at_ms) / 60000)) if published_at_ms else None,
                "link": link,
            }
        )
        if len(items) >= max_results:
            break
    return items, missing_published_count


def fetch_rss_items_with_retry(query: str, max_results: int, kind: str) -> tuple[list[dict[str, Any]], int, int]:
    last_error: Exception | None = None
    for attempt in range(1, SEARCH_SOURCE_READ_ATTEMPTS + 1):
        try:
            results, missing_published_count = fetch_rss_items(query, max_results)
            return results, missing_published_count, attempt
        except Exception as exc:
            last_error = exc
            if attempt < SEARCH_SOURCE_READ_ATTEMPTS:
                time.sleep(0.05)
    detail = compact_error(str(last_error or "unknown RSS error"), 220)
    raise SourceReadError(
        f"{kind} RSS fetch failed after {SEARCH_SOURCE_READ_ATTEMPTS} attempts: {detail}",
        code=f"{sanitize_key(kind, 'search')}_rss_fetch_failed",
        source="google_news_rss",
        attempts=SEARCH_SOURCE_READ_ATTEMPTS,
        query=query,
    ) from last_error


def realtime_search_cache_key(kind: str, query: str, max_results: int) -> str:
    raw = f"{kind}\0{query}\0{max_results}".encode("utf-8")
    return hashlib.sha256(raw).hexdigest()[:24]


def cached_search_payload(kind: str, query: str, max_results: int, cache_ttl_minutes: int) -> dict[str, Any] | None:
    cache_key = realtime_search_cache_key(kind, query, max_results)
    path = f"{REALTIME_CACHE_PATH}/search/{sanitize_key(kind)}/{cache_key}"
    try:
        cached = fb_get(path)
    except Exception as exc:
        log(f"search cache read failed kind={kind}: {compact_error(str(exc), 160)}")
        return None
    if not isinstance(cached, dict):
        return None
    fetched_at_ms = normalize_ts_ms(cached.get("fetched_at_ms") or 0)
    if fetched_at_ms <= 0:
        return None
    cache_age_minutes = max(0, int((now_ms() - fetched_at_ms) / 60000))
    if cache_age_minutes > max(1, cache_ttl_minutes):
        return None
    payload = dict(cached)
    payload.update(
        {
            "ok": True,
            "operation": f"{kind}.search",
            "query": query,
            "cache_hit": True,
            "cache_age_minutes": cache_age_minutes,
            "cache_ttl_minutes": cache_ttl_minutes,
            "refresh_ttl_minutes": cache_ttl_minutes,
            "source_attempts": 0,
        }
    )
    return payload


def write_search_cache(kind: str, query: str, max_results: int, payload: dict[str, Any]) -> None:
    cache_key = realtime_search_cache_key(kind, query, max_results)
    path = f"{REALTIME_CACHE_PATH}/search/{sanitize_key(kind)}/{cache_key}"
    cache_payload = dict(payload)
    cache_payload["cache_key"] = cache_key
    try:
        fb_put(path, cache_payload)
    except Exception as exc:
        log(f"search cache write failed kind={kind}: {compact_error(str(exc), 160)}")


def execute_search(action: dict[str, Any], kind: str) -> dict[str, Any]:
    query = str(action.get("query") or "").strip()
    if not query:
        default_queries = {
            "news": "SK하이닉스 이천 최신 뉴스",
            "sports": "오늘 축구 일정 한국 시간",
            "web": "이천 하이닉스 주변 정보",
        }
        query = default_queries.get(kind, "이천 하이닉스")
    try:
        max_results = max(1, min(int(action.get("max_results") or 5), 8))
    except (TypeError, ValueError):
        max_results = 5
    cache_ttl_minutes = 0
    if (
        action.get("cache_ttl_minutes") is not None
        or action.get("reuse_cache_minutes") is not None
        or action.get("max_age_minutes") is not None
    ):
        try:
            cache_ttl_minutes = max(
                1,
                min(
                    int(
                        action.get("cache_ttl_minutes")
                        or action.get("reuse_cache_minutes")
                        or action.get("max_age_minutes")
                    ),
                    REALTIME_INFO_MAX_AGE_MINUTES,
                ),
            )
        except (TypeError, ValueError):
            cache_ttl_minutes = REALTIME_INFO_MAX_AGE_MINUTES
    if cache_ttl_minutes > 0 and not bool(action.get("force_refresh")):
        cached = cached_search_payload(kind, query, max_results, cache_ttl_minutes)
        if cached is not None:
            return cached
    results, missing_published_count, source_attempts = fetch_rss_items_with_retry(query, max_results, kind)
    payload = {
        "ok": True,
        "operation": f"{kind}.search",
        "query": query,
        "results": results,
        "fetched_at_ms": now_ms(),
        "cache_hit": False,
        "cache_age_minutes": 0,
        "cache_ttl_minutes": cache_ttl_minutes,
        "refresh_ttl_minutes": cache_ttl_minutes,
        "missing_published_count": missing_published_count,
        "source_attempts": source_attempts,
        "source": "google_news_rss",
        "source_error_code": "",
        "note": "검색 결과는 cache_ttl_minutes 안 재출력 시 캐시를 재사용합니다. published_at_ms는 표시용이며 freshness 필터로 버리지 않습니다.",
    }
    if bool(action.get("dry_run")):
        payload["dry_run"] = True
        payload["cache_write_disabled"] = True
    elif cache_ttl_minutes > 0:
        write_search_cache(kind, query, max_results, payload)
    return payload


WEATHER_CODES = {
    0: "맑음",
    1: "대체로 맑음",
    2: "구름 조금",
    3: "흐림",
    45: "안개",
    48: "서리 안개",
    51: "약한 이슬비",
    53: "이슬비",
    55: "강한 이슬비",
    61: "약한 비",
    63: "비",
    65: "강한 비",
    71: "약한 눈",
    73: "눈",
    75: "강한 눈",
    80: "소나기",
    81: "소나기",
    82: "강한 소나기",
    95: "뇌우",
}


def execute_weather(action: dict[str, Any]) -> dict[str, Any]:
    location = str(action.get("location") or "이천").strip()
    fetched_at_ms = now_ms()
    geo_url = "https://geocoding-api.open-meteo.com/v1/search?" + urllib.parse.urlencode(
        {"name": location, "count": 1, "language": "ko", "format": "json"}
    )
    geo = fetch_json_url(geo_url)
    results = geo.get("results") if isinstance(geo, dict) else None
    if not isinstance(results, list) or not results:
        raise WorkerError(f"weather location not found: {location}")
    place = results[0]
    lat = place.get("latitude")
    lon = place.get("longitude")
    try:
        forecast_days = max(1, min(int(action.get("days") or 4), 16))
    except (TypeError, ValueError):
        forecast_days = 4
    forecast_url = "https://api.open-meteo.com/v1/forecast?" + urllib.parse.urlencode(
        {
            "latitude": lat,
            "longitude": lon,
            "daily": "weather_code,temperature_2m_max,temperature_2m_min,precipitation_sum,precipitation_probability_max",
            "forecast_days": forecast_days,
            "timezone": "Asia/Seoul",
        }
    )
    forecast = fetch_json_url(forecast_url)
    daily = forecast.get("daily") if isinstance(forecast, dict) else {}
    days = []
    if isinstance(daily, dict):
        times = daily.get("time") or []
        def daily_at(key: str, idx: int) -> Any:
            values = daily.get(key) or []
            return values[idx] if isinstance(values, list) and idx < len(values) else None
        for idx, date_text in enumerate(times):
            code = daily_at("weather_code", idx)
            days.append(
                {
                    "date": date_text,
                    "weather": WEATHER_CODES.get(code, str(code)),
                    "temp_min": daily_at("temperature_2m_min", idx),
                    "temp_max": daily_at("temperature_2m_max", idx),
                    "rain_mm": daily_at("precipitation_sum", idx),
                    "rain_probability": daily_at("precipitation_probability_max", idx),
                    "fetched_at_ms": fetched_at_ms,
                    "valid_until_ms": fetched_at_ms + REALTIME_INFO_MAX_AGE_MINUTES * 60 * 1000,
                }
            )
    return {
        "ok": True,
        "operation": "weather.forecast",
        "location": place.get("name") or location,
        "country": place.get("country") or "",
        "fetched_at_ms": fetched_at_ms,
        "valid_until_ms": fetched_at_ms + REALTIME_INFO_MAX_AGE_MINUTES * 60 * 1000,
        "freshness_max_age_minutes": REALTIME_INFO_MAX_AGE_MINUTES,
        "days": days,
    }


def execute_one_action(
    action: dict[str, Any],
    req_id: str = "",
    args: argparse.Namespace | None = None,
    item: dict[str, Any] | None = None,
) -> dict[str, Any]:
    action_type = str(action.get("type") or action.get("action") or "").strip().lower()
    request_type = str(action.get("request_type") or "").strip().lower()
    if request_type == CONFIRMED_SCHEDULE_WRITE_REQUEST_TYPE or action_type in {
        CONFIRMED_SCHEDULE_WRITE_REQUEST_TYPE,
        "confirmed_schedule.write",
        "schedule.confirmed_write",
    }:
        return execute_confirmed_schedule_write_request(action, req_id=req_id, args=args)
    if not action_type:
        raise WorkerError("action type missing")
    if action_type in {"employee.add_alias", "employee.alias", "staff.add_alias", "staff.alias"}:
        return execute_employee_add_alias(action)
    if action_type in {"schedule.upsert", "schedule.upsert_shift", "schedule.set_shift", "work_schedule.upsert"}:
        return execute_schedule_upsert(action)
    if action_type in {"schedule.off", "work_schedule.off"}:
        return execute_schedule_off(action)
    if action_type in {"schedule.clear", "work_schedule.clear"}:
        return execute_schedule_clear(action)
    if action_type in {"schedule.query", "work_schedule.query"}:
        return execute_schedule_query(action)
    if action_type in {"attendance.record", "attendance.set", "attendance.check"}:
        return execute_attendance_record(action)
    if action_type in {"attendance.query", "attendance.status"}:
        return execute_attendance_query(action)
    if action_type in {"missed_chat.query", "chat_replay.query", "storebot.missed_query"}:
        return execute_missed_chat_query(action)
    if action_type in {"order.recent", "receipt.recent", "dinein.recent", "delivery.recent"}:
        return execute_order_recent(action)
    if action_type in {"ops_manual.search", "ops_manual.query", "manual.search", "manual.query"}:
        return execute_ops_manual_search(action)
    if action_type in {"operation_knowledge.preview", "ops_knowledge.preview", "site_knowledge.preview"}:
        return execute_operation_knowledge_preview(action)
    if action_type in {"operation_knowledge.ingest", "ops_knowledge.ingest"}:
        return execute_operation_knowledge_ingest(action)
    if action_type in {"operation_knowledge.process_job", "ops_knowledge.process_job"}:
        return execute_operation_knowledge_process_job(action)
    if action_type in {"operation_knowledge.process_queue", "ops_knowledge.process_queue"}:
        return execute_operation_knowledge_process_queue(action)
    if action_type in {"operation_knowledge.upsert", "operation_knowledge.upsert_summary", "ops_knowledge.upsert_summary"}:
        return execute_operation_knowledge_upsert_summary(action)
    if action_type in {"operation_knowledge.render_output", "operation_knowledge.upsert_output", "operation_knowledge.upsert_output_variant"}:
        if action_type in {"operation_knowledge.upsert_output", "operation_knowledge.upsert_output_variant"}:
            return execute_operation_knowledge_upsert_output(action)
        return execute_operation_knowledge_render_output(action)
    if action_type in {"operation_knowledge.delete_request", "operation_knowledge.request_delete", "ops_knowledge.request_delete"}:
        return execute_operation_knowledge_delete_request(action)
    if action_type in {"operation_knowledge.delete", "operation_knowledge.soft_delete"}:
        return execute_operation_knowledge_delete(action)
    if action_type == "operation_knowledge.restore":
        return execute_operation_knowledge_restore(action)
    if action_type in {"operation_knowledge.send_reply", "kakao.send_reply"}:
        return execute_operation_knowledge_send_reply(action, req_id=req_id)
    if action_type in STOREBOT_LOCAL_DIRECT_PROBE_ACTION_TYPES:
        return execute_storebot_local_direct_probe(action, req_id=req_id)
    if action_type in {"alert.schedule", "temp_alert.schedule", "reminder.schedule"}:
        return execute_alert_schedule(action, req_id)
    if action_type in {"alert.query", "temp_alert.query", "reminder.query"}:
        return execute_alert_query(action)
    if action_type in {"alert.cancel", "temp_alert.cancel", "reminder.cancel"}:
        return execute_alert_cancel(action, req_id)
    if action_type == "firebase.get":
        path = clean_firebase_path(action.get("path"))
        data = sanitize_firebase_get_payload(path, fb_get(path))
        return {"ok": True, "operation": "firebase.get", "path": path, "data": compact_payload(data)}
    if action_type in {"weather.query", "weather.forecast"}:
        return execute_weather(action)
    if action_type in {"news.search", "search.news"}:
        return execute_search(action, "news")
    if action_type in {"sports.search", "search.sports"}:
        return execute_search(action, "sports")
    if action_type in {"web.search", "search.web"}:
        return execute_search(action, "web")
    if action_type in {"guidance.query", "md.guidance.query", "memory.guidance.query"}:
        return execute_guidance_query(action)
    if action_type in {"guidance.add_rule", "md.guidance.add_rule", "memory.guidance.add_rule"}:
        if args is None:
            raise WorkerError("guidance add args missing")
        return execute_guidance_add_rule(action, req_id, args, item=item)
    raise WorkerError(f"unsupported action type: {action_type}")


def mcp_args() -> argparse.Namespace:
    return argparse.Namespace(
        node=os.environ.get("STOREBOT_CODEX_NODE", "storebot_mcp"),
        model=os.environ.get("STOREBOT_CODEX_MODEL", DEFAULT_MODEL),
        reasoning_effort=os.environ.get("STOREBOT_CODEX_REASONING_EFFORT", DEFAULT_REASONING_EFFORT),
        max_actions=int(os.environ.get("STOREBOT_CODEX_MAX_ACTIONS", "8")),
    )


def mcp_req_id(prefix: str = "mcp") -> str:
    return f"{prefix}_{now_ms()}_{secrets.token_hex(3)}"


def mcp_json(value: Any, limit: int = 6000) -> str:
    return json.dumps(compact_payload(value, limit), ensure_ascii=False, indent=2)


def run_storebot_mcp_action(action: dict[str, Any], req_id: str | None = None) -> str:
    action_to_run = enforce_mcp_request_context(action)
    try:
        args = mcp_args()
        result = execute_one_action(action_to_run, req_id=req_id or mcp_req_id(), args=args)
        annotate_mcp_result(result, action_to_run)
        result.setdefault("worker", args.node)
        result.setdefault("model", model_label(args))
        result.setdefault("reasoning_effort", reasoning_label(args))
        return mcp_json(result)
    except WorkerError as exc:
        result = {
            "ok": False,
            "operation": str(action_to_run.get("type") or action_to_run.get("action") or ""),
            "error": compact_error(str(exc), 350),
        }
        result.update(structured_source_error_fields(exc))
        return mcp_json(annotate_mcp_result(result, action_to_run))
    except Exception as exc:
        result = {
            "ok": False,
            "operation": str(action_to_run.get("type") or action_to_run.get("action") or ""),
            "error": compact_error(str(exc), 350),
        }
        result.update(structured_source_error_fields(exc))
        return mcp_json(annotate_mcp_result(result, action_to_run))


def mcp_dates_payload(date: str = "", dates_json: str = "") -> dict[str, Any]:
    action: dict[str, Any] = {}
    if str(dates_json or "").strip():
        try:
            parsed = json.loads(str(dates_json))
        except json.JSONDecodeError as exc:
            raise WorkerError(f"invalid dates_json: {exc}") from exc
        action["dates"] = parsed if isinstance(parsed, list) else [parsed]
    elif str(date or "").strip():
        action["date"] = str(date).strip()
    return action


def run_mcp_server(args: argparse.Namespace | None = None) -> int:
    if args is not None:
        set_mcp_request_context(parse_mcp_context(getattr(args, "mcp_context_json", "")))
    try:
        from mcp.server.fastmcp import FastMCP
    except Exception as exc:
        raise SystemExit(f"mcp package missing: {compact_error(str(exc), 200)}") from exc

    mcp = FastMCP("firebase-hub")

    @mcp.tool()
    def storebot_tool(action_json: str) -> str:
        """Run one allowlisted StoreBot tool action and return JSON."""
        try:
            action = json.loads(action_json)
        except json.JSONDecodeError as exc:
            return mcp_json({"ok": False, "error": f"invalid action_json: {exc}"})
        if not isinstance(action, dict):
            return mcp_json({"ok": False, "error": "action_json must be an object"})
        return run_storebot_mcp_action(action)

    @mcp.tool()
    def storebot_firebase_get(path: str) -> str:
        """Read an allowlisted StoreBot/WorkSchedule Firebase path."""
        return run_storebot_mcp_action({"type": "firebase.get", "path": path})

    @mcp.tool()
    def storebot_ops_manual_search(query: str = "", limit: int = 5) -> str:
        """Search approved ops manual entries through the canonical read model."""
        return run_storebot_mcp_action({"type": "ops_manual.search", "query": query, "limit": limit})

    @mcp.tool()
    def storebot_operation_knowledge_preview(
        raw_text: str = "",
        raw_items_json: str = "",
        query: str = "",
        source: str = "storebot_mcp",
        channel: str = "site",
    ) -> str:
        """Preview operation knowledge structure and output variants with write-enabled contract metadata."""
        action: dict[str, Any] = {"type": "operation_knowledge.preview", "query": query}
        if raw_items_json.strip():
            try:
                raw_items = json.loads(raw_items_json)
            except json.JSONDecodeError as exc:
                return mcp_json({"ok": False, "error": f"invalid raw_items_json: {exc}"})
            action["raw_items"] = raw_items if isinstance(raw_items, list) else [raw_items]
        else:
            action.update({"text": raw_text, "source": source, "channel": channel})
        return run_storebot_mcp_action(action)

    @mcp.tool()
    def storebot_operation_knowledge_ingest(raw_item_json: str, actor: str = "storebot_mcp", dry_run: bool = False) -> str:
        """Persist one operation knowledge raw input and queue a background summary job."""
        try:
            raw_item = json.loads(raw_item_json)
        except json.JSONDecodeError as exc:
            return mcp_json({"ok": False, "operation": "operation_knowledge.ingest", "error": f"invalid raw_item_json: {exc}"})
        return run_storebot_mcp_action({"type": "operation_knowledge.ingest", "raw_item": raw_item, "actor": actor, "dry_run": dry_run})

    @mcp.tool()
    def storebot_operation_knowledge_process_queue(limit: int = 5, actor: str = "storebot_mcp", dry_run: bool = False) -> str:
        """Process pending operation knowledge summary/output jobs."""
        return run_storebot_mcp_action({"type": "operation_knowledge.process_queue", "limit": limit, "actor": actor, "dry_run": dry_run})

    @mcp.tool()
    def storebot_operation_knowledge_upsert_summary(summary_json: str = "", raw_items_json: str = "", actor: str = "storebot_mcp", dry_run: bool = False) -> str:
        """Persist a structured summary, or derive it from raw_items_json before writing."""
        action: dict[str, Any] = {"type": "operation_knowledge.upsert_summary", "actor": actor, "dry_run": dry_run}
        try:
            if summary_json.strip():
                action["summary"] = json.loads(summary_json)
            if raw_items_json.strip():
                parsed = json.loads(raw_items_json)
                action["raw_items"] = parsed if isinstance(parsed, list) else [parsed]
        except json.JSONDecodeError as exc:
            return mcp_json({"ok": False, "operation": "operation_knowledge.upsert_summary", "error": f"invalid json: {exc}"})
        return run_storebot_mcp_action(action)

    @mcp.tool()
    def storebot_operation_knowledge_render_output(
        structured_summary_json: str,
        variant: str = "",
        query: str = "",
        upsert: bool = False,
        actor: str = "storebot_mcp",
        dry_run: bool = False,
    ) -> str:
        """Render output variants and optionally persist one variant with audit."""
        try:
            structured_summary = json.loads(structured_summary_json)
        except json.JSONDecodeError as exc:
            return mcp_json({"ok": False, "operation": "operation_knowledge.render_output", "error": f"invalid structured_summary_json: {exc}"})
        return run_storebot_mcp_action(
            {
                "type": "operation_knowledge.render_output",
                "structured_summary": structured_summary,
                "variant": variant,
                "query": query,
                "upsert": upsert,
                "actor": actor,
                "dry_run": dry_run,
            }
        )

    @mcp.tool()
    def storebot_operation_knowledge_request_delete(target_type: str, source_id: str, reason: str = "", actor: str = "storebot_mcp", dry_run: bool = False) -> str:
        """Create a delete request; hard delete remains disabled by default."""
        return run_storebot_mcp_action(
            {
                "type": "operation_knowledge.request_delete",
                "target_type": target_type,
                "source_id": source_id,
                "reason": reason,
                "actor": actor,
                "dry_run": dry_run,
            }
        )

    @mcp.tool()
    def storebot_operation_knowledge_restore(target_type: str, source_id: str, actor: str = "storebot_mcp", dry_run: bool = False) -> str:
        """Restore a soft-deleted operation knowledge item."""
        return run_storebot_mcp_action(
            {"type": "operation_knowledge.restore", "target_type": target_type, "source_id": source_id, "actor": actor, "dry_run": dry_run}
        )

    @mcp.tool()
    def storebot_operation_knowledge_send_reply(
        message: str,
        room_id: str,
        room_name: str = "",
        source_id: str = "",
        actor: str = "storebot_mcp",
        kakao_send_enabled: bool = True,
        execute_send: bool = False,
        no_send: bool = True,
    ) -> str:
        """Prepare or queue one guarded Kakao reply; no_send is the safe default."""
        return run_storebot_mcp_action(
            {
                "type": "operation_knowledge.send_reply",
                "message": message,
                "room_id": room_id,
                "room_name": room_name,
                "source_id": source_id,
                "actor": actor,
                "kakao_send_enabled": kakao_send_enabled,
                "execute_send": execute_send,
                "explicit_action": True,
                "no_send": no_send,
            }
        )

    @mcp.tool()
    def storebot_schedule_query(date: str = "", dates_json: str = "", employee: str = "", employee_id: str = "") -> str:
        """Read StoreBot work schedule rows for a date, dates JSON array, or employee."""
        action = {"type": "schedule.query", **mcp_dates_payload(date, dates_json)}
        if employee.strip():
            action["employee"] = employee.strip()
        if employee_id.strip():
            action["employee_id"] = employee_id.strip()
        return run_storebot_mcp_action(action)

    @mcp.tool()
    def storebot_schedule_upsert_shift(
        employee: str,
        date: str = "",
        dates_json: str = "",
        start: str = "",
        end: str = "",
        role: str = "",
        tentative: bool = False,
        last_shift: bool = False,
        note: str = "",
        allow_create_employee: bool = False,
        dry_run: bool = False,
    ) -> str:
        """Write a temporary StoreBot schedule shift after Codex has resolved the intent; optionally mark it as the employee's last shift."""
        action = {"type": "schedule.upsert_shift", "employee": employee, **mcp_dates_payload(date, dates_json)}
        if start.strip():
            action["start"] = start.strip()
        if end.strip():
            action["end"] = end.strip()
        if role.strip():
            action["role"] = role.strip()
        if tentative:
            action["tentative"] = True
        if last_shift:
            action["last_shift"] = True
        if note.strip():
            action["note"] = note.strip()
        if allow_create_employee:
            action["allow_create_employee"] = True
        if dry_run:
            action["dry_run"] = True
        return run_storebot_mcp_action(action)

    @mcp.tool()
    def storebot_schedule_off(employee: str, date: str = "", dates_json: str = "", dry_run: bool = False) -> str:
        """Mark a StoreBot employee off for one date or a dates JSON array."""
        action = {"type": "schedule.off", "employee": employee, **mcp_dates_payload(date, dates_json)}
        if dry_run:
            action["dry_run"] = True
        return run_storebot_mcp_action(action)

    @mcp.tool()
    def storebot_schedule_clear(employee: str, date: str = "", dates_json: str = "", dry_run: bool = False) -> str:
        """Clear a temporary StoreBot schedule/off flag for one date or a dates JSON array."""
        action = {"type": "schedule.clear", "employee": employee, **mcp_dates_payload(date, dates_json)}
        if dry_run:
            action["dry_run"] = True
        return run_storebot_mcp_action(action)

    @mcp.tool()
    def storebot_employee_add_alias(employee: str, alias: str, aliases_json: str = "", dry_run: bool = False) -> str:
        """Add nickname/typo aliases to an existing StoreBot employee after Codex resolved the correction."""
        action: dict[str, Any] = {"type": "employee.add_alias", "employee": employee}
        if str(aliases_json or "").strip():
            try:
                parsed = json.loads(str(aliases_json))
            except json.JSONDecodeError as exc:
                return mcp_json({"ok": False, "operation": "employee.add_alias", "error": f"invalid aliases_json: {exc}"})
            action["aliases"] = parsed if isinstance(parsed, list) else [parsed]
        else:
            action["alias"] = alias
        if dry_run:
            action["dry_run"] = True
        return run_storebot_mcp_action(action)

    @mcp.tool()
    def storebot_attendance_record(
        employee: str,
        time_category: str,
        field: str = "actual_start",
        date: str = "",
        time: str = "",
        source: str = "codex",
        force: bool = False,
        dry_run: bool = False,
    ) -> str:
        """Record a past-confirmed StoreBot attendance start/end stamp for an employee."""
        action = {
            "type": "attendance.record",
            "employee": employee,
            "time_category": time_category,
            "field": field,
            "source": source,
            "force": force,
            "dry_run": dry_run,
        }
        if date.strip():
            action["date"] = date.strip()
        if time.strip():
            action["time"] = time.strip()
        return run_storebot_mcp_action(action)

    @mcp.tool()
    def storebot_attendance_query(date: str = "", dates_json: str = "", employee: str = "", employee_id: str = "") -> str:
        """Read StoreBot attendance stamps for one date, dates JSON array, or employee."""
        action = {"type": "attendance.query", **mcp_dates_payload(date, dates_json)}
        if employee.strip():
            action["employee"] = employee.strip()
        if employee_id.strip():
            action["employee_id"] = employee_id.strip()
        return run_storebot_mcp_action(action)

    @mcp.tool()
    def storebot_missed_chat_query(
        hours: float = 24,
        limit: int = 20,
        room_id: str = "",
        include_ok: bool = False,
        include_stamp_gaps: bool = False,
        include_tests: bool = False,
    ) -> str:
        """Summarize recent StoreBot Codex request gaps from the Firebase mirror queue."""
        return run_storebot_mcp_action(
            {
                "type": "missed_chat.query",
                "hours": hours,
                "limit": limit,
                "room_id": room_id,
                "include_ok": include_ok,
                "include_stamp_gaps": include_stamp_gaps,
                "include_tests": include_tests,
            }
        )

    @mcp.tool()
    def storebot_order_recent(
        query: str = "",
        limit: int = 5,
        window_days: int = 2,
        only_attention: bool = False,
        include_raw: bool = False,
    ) -> str:
        """Read recent StoreBot printer/order captures for delivery, dine-in correction, payment, address, delay, or receipt risk."""
        return run_storebot_mcp_action(
            {
                "type": "order.recent",
                "query": query,
                "limit": limit,
                "window_days": window_days,
                "only_attention": only_attention,
                "include_raw": include_raw,
            }
        )

    @mcp.tool()
    def storebot_alert_schedule(
        alert_at: str,
        message: str,
        event_at: str = "",
        room_id: str = "storebot_group",
        room_name: str = "BBQ하이닉스점 10",
        reason: str = "",
        dry_run: bool = False,
    ) -> str:
        """Create a one-off StoreBot temporary alert with the final Kakao message already written."""
        return run_storebot_mcp_action(
            {
                "type": "alert.schedule",
                "alert_at": alert_at,
                "message": message,
                "event_at": event_at,
                "room_id": room_id,
                "room_name": room_name,
                "reason": reason,
                "dry_run": dry_run,
            }
        )

    @mcp.tool()
    def storebot_alert_query(limit: int = 12, include_done: bool = False) -> str:
        """List pending StoreBot temporary alerts."""
        return run_storebot_mcp_action({"type": "alert.query", "limit": limit, "include_done": include_done})

    @mcp.tool()
    def storebot_alert_cancel(alert_id: str, dry_run: bool = False) -> str:
        """Cancel a pending StoreBot temporary alert."""
        return run_storebot_mcp_action({"type": "alert.cancel", "id": alert_id, "dry_run": dry_run})

    @mcp.tool()
    def storebot_guidance_query(scope: str = "", limit: int = 12) -> str:
        """Read current StoreBot runtime guidance rules."""
        return run_storebot_mcp_action({"type": "guidance.query", "scope": scope, "limit": limit})

    @mcp.tool()
    def storebot_guidance_add_rule(rule: str, scope: str = "general", rationale: str = "", dry_run: bool = False) -> str:
        """Add a concise StoreBot runtime guidance rule from user correction or repeated output pattern."""
        return run_storebot_mcp_action(
            {"type": "guidance.add_rule", "rule": rule, "scope": scope, "rationale": rationale, "dry_run": dry_run}
        )

    @mcp.tool()
    def storebot_weather_forecast(location: str = "이천", days: int = 4) -> str:
        """Fetch weather forecast for StoreBot operational briefing."""
        return run_storebot_mcp_action({"type": "weather.forecast", "location": location, "days": days})

    @mcp.tool()
    def storebot_news_search(query: str, max_results: int = 5, cache_ttl_minutes: int = REALTIME_INFO_MAX_AGE_MINUTES) -> str:
        """Search current Korean news; cache_ttl_minutes only controls cache reuse and does not hide older results."""
        return run_storebot_mcp_action({"type": "news.search", "query": query, "max_results": max_results, "cache_ttl_minutes": cache_ttl_minutes})

    @mcp.tool()
    def storebot_sports_search(query: str, max_results: int = 5, cache_ttl_minutes: int = REALTIME_INFO_MAX_AGE_MINUTES) -> str:
        """Search sports schedules/news; cache_ttl_minutes only controls cache reuse and does not hide older results."""
        return run_storebot_mcp_action({"type": "sports.search", "query": query, "max_results": max_results, "cache_ttl_minutes": cache_ttl_minutes})

    @mcp.tool()
    def storebot_web_search(query: str, max_results: int = 5, cache_ttl_minutes: int = REALTIME_INFO_MAX_AGE_MINUTES) -> str:
        """Search general web/RSS results; cache_ttl_minutes only controls cache reuse and does not hide older results."""
        return run_storebot_mcp_action({"type": "web.search", "query": query, "max_results": max_results, "cache_ttl_minutes": cache_ttl_minutes})

    mcp.run()
    return 0


def execute_action_request(
    req_id: str,
    action_request: dict[str, Any],
    args: argparse.Namespace,
    *,
    audit: bool = True,
    item: dict[str, Any] | None = None,
    event_id: str = "",
    route_metadata: dict[str, Any] | None = None,
) -> list[dict[str, Any]]:
    raw_actions = action_request.get("actions")
    if not isinstance(raw_actions, list) or not raw_actions:
        raise WorkerError("empty action request")
    action_limit = max(1, min(int(getattr(args, "max_actions", 5) or 5), 10))
    results: list[dict[str, Any]] = []
    ledger_item = item if isinstance(item, dict) else {}
    for idx, raw_action in enumerate(raw_actions[:action_limit]):
        if not isinstance(raw_action, dict):
            result = {"ok": False, "index": idx, "error": "action is not an object"}
            results.append(result)
            if ledger_item:
                ledger_id = append_action_ledger_entry(
                    req_id,
                    ledger_item,
                    args,
                    event_id=event_id,
                    kind="action",
                    status="failed",
                    route_metadata=route_metadata,
                    proposed_action={},
                    result=result,
                    action_index=idx,
                    shadow_only=False,
                    adapter_action_execution=False,
                )
                if ledger_id:
                    result["ledger_id"] = ledger_id
            continue
        action_to_run = enforce_request_action_dry_run(ledger_item, raw_action)
        try:
            result = execute_one_action(action_to_run, req_id=req_id, args=args, item=ledger_item)
            result["index"] = idx
            result.update(safety_result_flags_from_action(action_to_run))
            results.append(result)
        except Exception as exc:
            result = {
                "ok": False,
                "index": idx,
                "operation": str(action_to_run.get("type") or action_to_run.get("action") or ""),
                "error": compact_error(str(exc), 350),
            }
            result.update(structured_source_error_fields(exc))
            result.update(safety_result_flags_from_action(action_to_run))
            results.append(result)
        if ledger_item:
            ledger_id = append_action_ledger_entry(
                req_id,
                ledger_item,
                args,
                event_id=event_id,
                kind="action",
                status="succeeded" if result.get("ok") is True else "failed",
                route_metadata=route_metadata,
                proposed_action=action_to_run,
                result=result,
                action_index=idx,
                shadow_only=False,
                adapter_action_execution=True,
            )
            if ledger_id:
                result["ledger_id"] = ledger_id
    if not audit:
        return results
    try:
        fb_patch(
            f"{REQUESTS_PATH}/{req_id}",
            {
                "last_action_at_ms": now_ms(),
                "last_action_count": len(results),
                "last_action_results": compact_payload(redact_payload_for_audit(results), 3000),
            },
        )
    except Exception as exc:
        log(f"action result audit write failed request={req_id}: {compact_error(str(exc), 200)}")
    return results


def explicit_local_direct_action_list(item: dict[str, Any]) -> tuple[str, list[Any]]:
    for field_name in STOREBOT_EXPLICIT_LOCAL_DIRECT_ACTION_FIELDS:
        raw_actions = request_field(item, field_name)
        if isinstance(raw_actions, list):
            return field_name, raw_actions  # type: ignore[return-value]
    return "", []


def explicit_local_direct_action_block_reason(actions: list[Any]) -> str:
    if not actions:
        return "explicit action request empty"
    for idx, action in enumerate(actions):
        if not isinstance(action, dict):
            return f"explicit action {idx} is not an object"
        action_type = action_type_name(action)
        if action_type not in STOREBOT_LOCAL_DIRECT_PROBE_ACTION_TYPES:
            return f"unsupported explicit action type: {action_type or 'missing'}"
    return ""


def normalize_local_direct_explicit_request(item: dict[str, Any]) -> dict[str, Any]:
    payload = dict(item)
    reply_target = payload.get("reply_target")
    if isinstance(reply_target, dict):
        reply_target = dict(reply_target)
    else:
        reply_target = {}
    reply_target["kakao_publish"] = False
    payload.update(
        {
            "local_direct": True,
            "no_send": True,
            "no_publish": True,
            "publish_disabled": True,
            "reply_target": reply_target,
            "outbound_key": "",
        }
    )
    return payload


def run_local_direct_explicit_actions(
    req_id: str,
    item: dict[str, Any],
    args: argparse.Namespace,
    *,
    route_metadata: dict[str, Any] | None = None,
) -> tuple[dict[str, Any], dict[str, Any]]:
    field_name, raw_actions = explicit_local_direct_action_list(item)
    explicit_item = normalize_local_direct_explicit_request(item)
    if not raw_actions:
        raise WorkerError("explicit action request empty")
    block_reason = explicit_local_direct_action_block_reason(raw_actions)
    if block_reason:
        action_results = [
            {
                "ok": False,
                "index": 0,
                "status": "blocked",
                "operation": "",
                "error": block_reason,
                "explicit_action_field": field_name,
                "requested_action_count": len(raw_actions),
            }
        ]
    else:
        action_results = execute_action_request(
            req_id,
            {"actions": raw_actions},
            args,
            audit=False,
            item=explicit_item,
            event_id=str(explicit_item.get("_room_event_id") or ""),
            route_metadata=route_metadata,
        )
    action_count = len(action_results)
    action_ok_count = sum(1 for result in action_results if result.get("ok") is True)
    action_error_count = sum(1 for result in action_results if result.get("ok") is not True)
    pipeline = {
        "answer": "",
        "skipped": True,
        "output_category": "skip",
        "output_payload": {},
        "self_fix_request_id": "",
        "session_id": "explicit_local_direct_action",
        "room_id": str(explicit_item.get("room_id") or explicit_item.get("room") or "default"),
        "room_name": str(explicit_item.get("room_name") or explicit_item.get("roomTitle") or ""),
        "room_key": sanitize_key(
            str(
                explicit_item.get("room_id")
                or explicit_item.get("room")
                or explicit_item.get("room_name")
                or explicit_item.get("roomTitle")
                or "default"
            )
        ),
        "action_count": action_count,
        "action_ok_count": action_ok_count,
        "action_error_count": action_error_count,
        "direct_tool_count": 0,
        "direct_tool_ok_count": 0,
        "direct_tool_error_count": 0,
        "last_action_results": action_results,
        "brain_metadata": {
            "brain_route": "explicit_action",
            "reply_source": "explicit_action",
            "fallback_used": False,
            "worker_role": "explicit_action_executor",
            "cli_direct": True,
            "resident_required": False,
            "explicit_action_field": field_name,
            "explicit_action_blocked": bool(block_reason),
            "explicit_action_block_reason": block_reason,
        },
        "route_metadata": route_metadata if isinstance(route_metadata, dict) else {},
        "publish_disabled": True,
        "no_send": True,
        "no_publish": True,
        "reply_target": {"kakao_publish": False},
        "outbound_key": "",
    }
    return explicit_item, pipeline


def finalize_explicit_local_direct_poll_request(
    req_id: str,
    item: dict[str, Any],
    explicit_item: dict[str, Any],
    pipeline: dict[str, Any],
    args: argparse.Namespace,
    guide: str,
    *,
    route_metadata: dict[str, Any] | None = None,
    event_id: str = "",
) -> None:
    action_results = action_results_list(pipeline.get("last_action_results"))
    action_count = int(pipeline.get("action_count") or len(action_results))
    action_ok_count = int(pipeline.get("action_ok_count") or sum(1 for result in action_results if result.get("ok") is True))
    action_error_count = int(pipeline.get("action_error_count") or sum(1 for result in action_results if result.get("ok") is not True))
    direct_tool_count = int(pipeline.get("direct_tool_count") or 0)
    direct_tool_ok_count = int(pipeline.get("direct_tool_ok_count") or 0)
    direct_tool_error_count = int(pipeline.get("direct_tool_error_count") or 0)
    session_id = str(pipeline.get("session_id") or "explicit_local_direct_action")
    output_category = str(pipeline.get("output_category") or "skip")
    output_payload = pipeline.get("output_payload") if isinstance(pipeline.get("output_payload"), dict) else {}
    self_fix_request_id = str(pipeline.get("self_fix_request_id") or "")
    brain_metadata = pipeline.get("brain_metadata") if isinstance(pipeline.get("brain_metadata"), dict) else {}
    explicit_block_reason = str(brain_metadata.get("explicit_action_block_reason") or "")
    action_failure_reason = ""
    for result in action_results:
        if result.get("ok") is not True:
            action_failure_reason = str(result.get("error") or result.get("block_reason") or result.get("status") or "")
            break
    final_error = compact_error(explicit_block_reason or action_failure_reason, 500)
    failed = bool(final_error)
    now_value = now_ms()
    payload: dict[str, Any] = dict(item)
    payload.update(
        {
            "status": "error" if failed else "done",
            "failed_at_ms" if failed else "finished_at_ms": now_value,
            "worker": args.node,
            "model": model_label(args),
            "reasoning_effort": reasoning_label(args),
            "model_override_reason": getattr(args, "model_override_reason", ""),
            "session_id": session_id,
            "reply_skipped": True,
            "publish_disabled": True,
            "no_send": True,
            "no_publish": True,
            "reply_target": {"kakao_publish": False},
            "outbound_key": "",
            "output_category": output_category,
            "self_fix_request_id": self_fix_request_id,
            "action_count": action_count,
            "action_ok_count": action_ok_count,
            "action_error_count": action_error_count,
            "direct_tool_count": direct_tool_count,
            "direct_tool_ok_count": direct_tool_ok_count,
            "direct_tool_error_count": direct_tool_error_count,
            "last_action_at_ms": now_value,
            "last_action_count": len(action_results),
            "last_action_results": compact_explicit_action_result_payload(
                redact_payload_for_audit(action_results),
                3000,
            ),
        }
    )
    if output_payload:
        payload["output_payload"] = compact_payload(output_payload, 3000)
    if route_metadata:
        payload["route_metadata"] = compact_payload(route_metadata, 3000)
    if brain_metadata:
        payload.update(compact_payload(brain_metadata, 1200))
    apply_clean_reply_contract_metadata(
        payload,
        "",
        item,
        skipped=True,
        output_category=output_category,
        publish_disabled=True,
        block_reason=final_error if failed else "",
    )
    payload["skip_reason"] = final_error or str(payload.get("skip_reason") or "")
    payload.update(request_learning_suppression_context(args, explicit_item))
    if args.redact_done:
        payload.update(
            {
                "message": None,
                "text": None,
                "reply": None,
                "reply_redacted": True,
                "message_redacted": True,
                "reply_len": 0,
            }
        )
    else:
        payload["reply"] = ""
    if failed:
        payload["error"] = final_error
    fb_patch(request_record_path(req_id, item), payload)

    ledger_ids = [
        str(result.get("ledger_id"))
        for result in action_results
        if str(result.get("ledger_id") or "").strip()
    ]
    decision_ledger_id = append_decision_ledger(
        req_id,
        item,
        pipeline,
        args,
        event_id=event_id,
        route_metadata=route_metadata if isinstance(route_metadata, dict) else {},
    )
    if decision_ledger_id:
        ledger_ids.append(decision_ledger_id)

    final_route_metadata = route_metadata if isinstance(route_metadata, dict) else {}
    reconciliation_status = "error" if failed else reconciliation_status_for_pipeline(final_route_metadata, ledger_ids)
    write_reconciliation_status(
        req_id,
        item,
        args,
        status=reconciliation_status,
        event_id=event_id,
        ledger_ids=ledger_ids,
        route_metadata=final_route_metadata,
        error=final_error if failed else "",
    )
    save_room_turn_context(
        req_id,
        item,
        pipeline,
        "",
        skipped=True,
        publish_disabled=True,
        args=args,
    )
    learning_suppression = request_learning_suppression_context(args, explicit_item)
    decision = stamp_decision(True, "", action_count, error=final_error)
    if learning_suppression:
        mark_learning_stamp_status(req_id, args, "skipped", error=learning_suppression["learning_write_skipped_reason"])
    else:
        try:
            write_learning_stamp(
                req_id,
                build_learning_stamp(
                    req_id,
                    item,
                    args,
                    guide,
                    decision=decision,
                    answer="",
                    skipped=True,
                    publish_disabled=True,
                    action_count=action_count,
                    action_ok_count=action_ok_count,
                    action_error_count=action_error_count,
                ),
                args,
            )
        except Exception as exc:
            log(f"explicit action learning stamp write failed request={req_id}: {compact_error(str(exc), 200)}")
            mark_learning_stamp_status(req_id, args, "error", error=str(exc))
    safe_record_stage(
        req_id,
        item,
        args,
        "outbound_publish",
        "error" if failed else "skipped",
        message="explicit action blocked" if failed else "explicit action result ready",
        evidence={
            "explicit_action_blocked": failed,
            "explicit_action_block_reason": final_error,
            "action_count": action_count,
            "last_action_count": len(action_results),
        },
    )
    log(
        "done explicit action request="
        f"{req_id} status={'error' if failed else 'done'} action_count={action_count}"
        + (f" reason={final_error}" if final_error else "")
    )


def action_request_types(action_request: dict[str, Any]) -> list[str]:
    actions = action_request.get("actions")
    if not isinstance(actions, list):
        return []
    return [str(action.get("type") or "") for action in actions if isinstance(action, dict)]


def should_skip_schedule_query_followup(item: dict[str, Any], action_request: dict[str, Any], action_results: list[dict[str, Any]]) -> bool:
    if item.get("local_direct") is not True:
        return False
    action_types = action_request_types(action_request)
    result_ops = [str(result.get("operation") or "") for result in action_results if isinstance(result, dict)]
    if action_types != ["schedule.query"] and result_ops != ["schedule.query"]:
        return False
    if not action_results or any(result.get("ok") is not True for result in action_results):
        return False
    return should_build_schedule_image_request(item, "근무표")


def is_missing_session_error(text: str) -> bool:
    lower = text.lower()
    return any(
        marker in lower
        for marker in (
            "not found",
            "no session",
            "no rollout found",
            "thread/resume failed",
        )
    )


def read_guide(path: Path) -> str:
    if not path.exists():
        raise WorkerError(f"guide not found: {path}")
    return path.read_text(encoding="utf-8").strip()


def guide_hash(guide: str) -> str:
    return hashlib.sha256(guide.encode("utf-8")).hexdigest()


def short_text_hash(value: Any) -> str:
    text = str(value or "")
    if not text:
        return ""
    return hashlib.sha256(text.encode("utf-8")).hexdigest()[:16]


def room_agent_write_enabled(args: argparse.Namespace | None = None) -> bool:
    return not bool(getattr(args, "dry_run", False))


def room_agent_room_values(item: dict[str, Any]) -> tuple[str, str, str]:
    room_id = str(
        item.get("room_id")
        or item.get("room")
        or item.get("briefing_channel_room_id")
        or "storebot_group"
    ).strip()
    room_name = str(item.get("room_name") or item.get("roomTitle") or room_id).strip()
    room_key = sanitize_key(room_id or room_name, "storebot_group")
    return room_id, room_name, room_key


def context_bundle_v1_hash(bundle: dict[str, Any]) -> str:
    payload = {key: value for key, value in bundle.items() if key != "context_hash"}
    raw = json.dumps(payload, ensure_ascii=False, sort_keys=True, separators=(",", ":"), default=str).encode("utf-8")
    return hashlib.sha256(raw).hexdigest()


def build_context_bundle_v1(
    request_id: str,
    item: dict[str, Any] | None = None,
    *,
    recent_messages: list[Any] | None = None,
    app_state: dict[str, Any] | None = None,
    latency_stages: dict[str, Any] | None = None,
    fast_draft: Any = None,
    safety_class: str = "no_live_no_write",
) -> dict[str, Any]:
    source = item if isinstance(item, dict) else {}
    resolved_request_id = str(request_id or source.get("request_id") or source.get("id") or "").strip()
    room_id = str(source.get("room_id") or source.get("room") or "").strip()
    room_name = str(source.get("room_name") or source.get("roomTitle") or "").strip()
    room_key = str(source.get("room_key") or "").strip()
    if not room_key and (room_id or room_name):
        room_key = sanitize_key(room_id or room_name, "storebot_group")
    thread_key = str(source.get("thread_key") or source.get("thread_id") or source.get("session_id") or "").strip()
    messages_value = recent_messages if recent_messages is not None else source.get("recent_messages")
    state_value = app_state if app_state is not None else source.get("app_state")
    if not isinstance(state_value, dict):
        state_value = source.get("app_state_summary")
    stages_value = latency_stages if latency_stages is not None else source.get("latency_stages")
    bundle = {
        "version": CONTEXT_BUNDLE_V1_VERSION,
        "request_id": resolved_request_id,
        "room_id": room_id,
        "room_key": room_key,
        "thread_key": thread_key,
        "recent_messages": messages_value if isinstance(messages_value, list) else [],
        "app_state": state_value if isinstance(state_value, dict) else {},
        "safety_class": str(safety_class or source.get("safety_class") or "no_live_no_write").strip() or "no_live_no_write",
        "latency_stages": stages_value if isinstance(stages_value, dict) else {},
        "fast_draft": fast_draft,
        "no_live": True,
        "no_write": True,
    }
    bundle["context_hash"] = context_bundle_v1_hash(bundle)
    return bundle


def build_no_live_context_bundle_v1(
    request_id: str,
    item: dict[str, Any] | None = None,
    *,
    recent_messages: list[Any] | None = None,
    app_state: dict[str, Any] | None = None,
    latency_stages: dict[str, Any] | None = None,
) -> dict[str, Any]:
    source = dict(item) if isinstance(item, dict) else {}
    source.setdefault("request_id", request_id)
    return build_context_bundle_v1(
        request_id,
        source,
        recent_messages=recent_messages,
        app_state=app_state,
        latency_stages=latency_stages,
        fast_draft=None,
        safety_class="no_live_no_write",
    )


def build_no_live_context_bundle_debug_output(req_id: str, item: dict[str, Any]) -> dict[str, Any]:
    bundle = build_no_live_context_bundle_v1(req_id, item)
    return {
        "request_id": req_id,
        "room_id": bundle.get("room_id") or "",
        "room_key": bundle.get("room_key") or "",
        "context_bundle_v1": bundle,
    }


def redact_room_text_preview(value: Any, limit: int = 160) -> str:
    text = re.sub(r"\s+", " ", str(value or "").strip())
    if not text:
        return ""
    text = re.sub(r"\b01[016789][-\s.]?\d{3,4}[-\s.]?\d{4}\b", "[phone]", text)
    text = re.sub(
        r"(?i)(비번|비밀번호|공동현관|password|passcode|pin)\s*[:=]?\s*[0-9A-Za-z가-힣#*._-]{2,24}",
        lambda match: f"{match.group(1)} [redacted]",
        text,
    )
    text = re.sub(r"\b\d{3,}\b", lambda match: f"[num:{len(match.group(0))}]", text)
    return text[: max(1, limit)]


def room_event_text(item: dict[str, Any]) -> str:
    for key in ("message", "text", "content", "message_preview", "query"):
        value = str(item.get(key) or "").strip()
        if value:
            return value
    payload = item.get("payload")
    if isinstance(payload, dict):
        for key in ("message", "text", "summary", "title", "customer_request"):
            value = str(payload.get(key) or "").strip()
            if value:
                return value
    return ""


def room_event_sender(item: dict[str, Any]) -> str:
    return compact_text(item.get("sender") or item.get("sender_name") or item.get("from") or "", 40)


def room_event_transport(item: dict[str, Any]) -> str:
    return compact_text(item.get("transport") or item.get("source") or "firebase_queue", 80)


def build_room_event_duplicate_key(req_id: str, item: dict[str, Any]) -> str:
    room_id, room_name, _room_key = room_agent_room_values(item)
    text = room_event_text(item)
    sender = room_event_sender(item)
    event_kind = str(item.get("event_kind") or item.get("kind") or item.get("event_type") or "chat")
    ts_ms = normalize_ts_ms(
        item.get("message_ts_ms")
        or item.get("ts_ms")
        or item.get("ts")
        or item.get("created_at_ms")
        or item.get("createdAt")
        or 0
    )
    bucket_ms = int(ts_ms / 60_000) * 60_000 if ts_ms > 0 else 0
    basis = "|".join(
        [
            sanitize_key(room_id or room_name, "room"),
            event_kind,
            short_text_hash(sender),
            short_text_hash(text),
            str(bucket_ms),
            str(req_id or item.get("request_id") or ""),
        ]
    )
    return sanitize_key(f"dup_{short_text_hash(basis)}", "duplicate")


def build_room_event_id(req_id: str, item: dict[str, Any]) -> str:
    raw = str(item.get("_room_event_id") or item.get("room_event_id") or item.get("event_id") or "").strip()
    if raw:
        return sanitize_key(raw, "event")
    duplicate_key = build_room_event_duplicate_key(req_id, item)
    return sanitize_key(f"evt_{req_id or item.get('request_id') or duplicate_key}_{duplicate_key}", "event")


def compact_route_metadata(route_metadata: dict[str, Any] | None) -> dict[str, Any]:
    if not isinstance(route_metadata, dict):
        return {}
    allowed = {
        "selected_capability_id",
        "score",
        "mode_band",
        "primary_axis",
        "privacy_risk",
        "side_effect_risk",
        "shadow_only",
        "adapter_action_execution",
        "catalog_version",
        "catalog_capability_count",
        "catalog_load_error",
        "evidence",
        "top_candidates",
        "freshness_sla",
    }
    return compact_payload({key: route_metadata.get(key) for key in allowed if key in route_metadata}, 3000)


def route_risk_level(route_metadata: dict[str, Any] | None) -> str:
    if not isinstance(route_metadata, dict) or not route_metadata.get("selected_capability_id"):
        return "unknown"
    if str(route_metadata.get("privacy_risk") or "").lower() == "high":
        return "high"
    side_effect = str(route_metadata.get("side_effect_risk") or "").lower()
    if side_effect in {"high", "critical"}:
        return "high"
    if str(route_metadata.get("mode_band") or "").lower() == "needs_review":
        return "review"
    return "low"


def route_needs_review(route_metadata: dict[str, Any] | None) -> bool:
    if not isinstance(route_metadata, dict):
        return False
    return (
        str(route_metadata.get("mode_band") or "").lower() == "needs_review"
        or str(route_metadata.get("privacy_risk") or "").lower() == "high"
        or str(route_metadata.get("side_effect_risk") or "").lower() in {"high", "critical"}
    )


def build_room_event_journal_entry(
    req_id: str,
    item: dict[str, Any],
    args: argparse.Namespace | None = None,
    *,
    route_metadata: dict[str, Any] | None = None,
    event_id: str = "",
) -> dict[str, Any]:
    room_id, room_name, room_key = room_agent_room_values(item)
    text = room_event_text(item)
    sender = room_event_sender(item)
    created_ms = normalize_ts_ms(
        item.get("message_ts_ms")
        or item.get("ts_ms")
        or item.get("ts")
        or item.get("created_at_ms")
        or item.get("createdAt")
        or 0
    )
    received_ms = now_ms()
    resolved_event_id = sanitize_key(event_id or build_room_event_id(req_id, item), "event")
    duplicate_key = build_room_event_duplicate_key(req_id, item)
    entry = {
        "schema_version": 1,
        "event_id": resolved_event_id,
        "duplicate_key": duplicate_key,
        "request_id": str(req_id or item.get("request_id") or ""),
        "room_id": room_id,
        "room_key": room_key,
        "room_name_hash": short_text_hash(room_name),
        "room_name_preview": redact_room_text_preview(room_name, 80),
        "sender": sender,
        "sender_hash": short_text_hash(sender),
        "sender_label_redacted": redact_room_text_preview(sender, 60),
        "event_kind": str(item.get("event_kind") or item.get("kind") or item.get("event_type") or "chat"),
        "source": str(item.get("source") or ""),
        "transport": room_event_transport(item),
        "captured_at_ms": created_ms,
        "received_at_ms": received_ms,
        "text_hash": short_text_hash(text),
        "text_preview": redact_room_text_preview(text, 180),
        "text_len": len(text),
        "privacy_level": "redacted_preview",
        "raw_text_stored": False,
        "local_direct": bool(item.get("local_direct") is True),
        "worker": getattr(args, "node", "") if args is not None else "",
        "route_metadata": compact_route_metadata(route_metadata),
    }
    for key in ("ingress_claim_key", "android_package_name", "android_hot_path_owner", "briefing_channel_room_id"):
        value = item.get(key)
        if value not in (None, ""):
            entry[key] = compact_text(value, 160)
    return entry


def append_room_event_journal(
    req_id: str,
    item: dict[str, Any],
    args: argparse.Namespace | None = None,
    *,
    route_metadata: dict[str, Any] | None = None,
    event_id: str = "",
) -> str:
    entry = build_room_event_journal_entry(req_id, item, args, route_metadata=route_metadata, event_id=event_id)
    resolved_event_id = str(entry.get("event_id") or "")
    if not room_agent_write_enabled(args):
        return resolved_event_id
    room_key = str(entry.get("room_key") or "storebot_group")
    try:
        fb_put(f"{ROOM_EVENT_JOURNAL_PATH}/events/{resolved_event_id}", entry)
        fb_put(f"{ROOM_EVENT_JOURNAL_PATH}/rooms/{room_key}/recent/{resolved_event_id}", entry)
        fb_put(f"{ROOM_EVENT_JOURNAL_PATH}/rooms/{room_key}/latest", entry)
        fb_put(f"{ROOM_EVENT_JOURNAL_PATH}/latest", entry)
    except Exception as exc:
        log(f"room event journal write failed request={req_id}: {compact_error(str(exc), 180)}")
    return resolved_event_id


def action_type_text(action: dict[str, Any] | None) -> str:
    if not isinstance(action, dict):
        return ""
    return str(action.get("type") or action.get("action") or "").strip().lower()


def ledger_idempotency_key(req_id: str, event_id: str, kind: str, payload: Any) -> str:
    redacted = redact_payload_for_audit(payload)
    payload_hash = short_text_hash(json.dumps(redacted, ensure_ascii=False, sort_keys=True, default=str))
    return sanitize_key(f"idem_{req_id}_{event_id}_{kind}_{payload_hash}", "idem")


def build_action_ledger_entry(
    req_id: str,
    item: dict[str, Any],
    args: argparse.Namespace | None,
    *,
    event_id: str = "",
    kind: str,
    status: str,
    route_metadata: dict[str, Any] | None = None,
    proposed_action: dict[str, Any] | None = None,
    result: dict[str, Any] | None = None,
    action_index: int | None = None,
    output_category: str = "",
    shadow_only: bool | None = None,
    adapter_action_execution: bool | None = None,
) -> dict[str, Any]:
    room_id, room_name, room_key = room_agent_room_values(item)
    event_id = event_id or str(item.get("_room_event_id") or "")
    action_type = action_type_text(proposed_action)
    selected_capability = str((route_metadata or {}).get("selected_capability_id") or "")
    idempotency_key = ledger_idempotency_key(
        req_id,
        event_id,
        f"{kind}:{action_index if action_index is not None else ''}:{action_type}:{output_category}",
        proposed_action or {"kind": kind, "output_category": output_category, "status": status},
    )
    action_id = sanitize_key(f"ledger_{short_text_hash(idempotency_key)}", "ledger")
    route_shadow = bool((route_metadata or {}).get("shadow_only") is True)
    route_adapter_execution = bool((route_metadata or {}).get("adapter_action_execution") is True)
    if shadow_only is None:
        shadow_only = route_shadow or kind == "decision"
    if adapter_action_execution is None:
        adapter_action_execution = kind == "action" and status in {"succeeded", "failed"}
    entry: dict[str, Any] = {
        "schema_version": 1,
        "ledger_id": action_id,
        "idempotency_key": idempotency_key,
        "request_id": str(req_id),
        "event_id": event_id,
        "room_id": room_id,
        "room_key": room_key,
        "room_name_hash": short_text_hash(room_name),
        "kind": kind,
        "status": status,
        "risk": route_risk_level(route_metadata),
        "selected_capability_id": selected_capability,
        "mode_band": str((route_metadata or {}).get("mode_band") or ""),
        "output_category": output_category,
        "shadow_only": bool(shadow_only),
        "adapter_action_execution": bool(adapter_action_execution or route_adapter_execution),
        "created_at_ms": now_ms(),
        "worker": getattr(args, "node", "") if args is not None else "",
        "route_metadata": compact_route_metadata(route_metadata),
    }
    if action_index is not None:
        entry["action_index"] = action_index
    if proposed_action is not None:
        entry["proposed_action"] = compact_payload(redact_payload_for_audit(proposed_action), 2000)
        entry["proposed_action_type"] = action_type
    if result is not None:
        entry["result"] = compact_payload(redact_payload_for_audit(result), 2500)
        entry["result_ok"] = bool(result.get("ok") is True)
        if result.get("error"):
            entry["failure_reason"] = compact_error(str(result.get("error") or ""), 350)
    return entry


def persist_action_ledger_entry(entry: dict[str, Any], args: argparse.Namespace | None = None) -> str:
    ledger_id = str(entry.get("ledger_id") or "")
    if not ledger_id:
        return ""
    if not room_agent_write_enabled(args):
        return ledger_id
    req_id = sanitize_key(str(entry.get("request_id") or ""), "request")
    room_key = sanitize_key(str(entry.get("room_key") or ""), "room")
    try:
        fb_put(f"{ACTION_LEDGER_PATH}/entries/{ledger_id}", entry)
        fb_put(f"{ACTION_LEDGER_PATH}/requests/{req_id}/{ledger_id}", entry)
        fb_put(f"{ACTION_LEDGER_PATH}/rooms/{room_key}/recent/{ledger_id}", entry)
        fb_put(f"{ACTION_LEDGER_PATH}/latest", entry)
    except Exception as exc:
        log(f"action ledger write failed request={req_id}: {compact_error(str(exc), 180)}")
    return ledger_id


def append_action_ledger_entry(
    req_id: str,
    item: dict[str, Any],
    args: argparse.Namespace | None,
    **kwargs: Any,
) -> str:
    entry = build_action_ledger_entry(req_id, item, args, **kwargs)
    return persist_action_ledger_entry(entry, args)


def append_decision_ledger(
    req_id: str,
    item: dict[str, Any],
    pipeline: dict[str, Any],
    args: argparse.Namespace | None,
    *,
    event_id: str = "",
    route_metadata: dict[str, Any] | None = None,
) -> str:
    route_metadata = route_metadata if isinstance(route_metadata, dict) else pipeline.get("route_metadata")
    if not isinstance(route_metadata, dict):
        route_metadata = {}
    output_category = str(pipeline.get("output_category") or ("skip" if pipeline.get("skipped") else "kakao_reply"))
    status = "review_required" if route_needs_review(route_metadata) else "decided"
    if int(pipeline.get("action_error_count") or 0) > 0:
        status = "action_error"
    return append_action_ledger_entry(
        req_id,
        item,
        args,
        event_id=event_id or str(item.get("_room_event_id") or ""),
        kind="decision",
        status=status,
        route_metadata=route_metadata,
        output_category=output_category,
        shadow_only=bool(route_metadata.get("shadow_only", True)),
        adapter_action_execution=bool(route_metadata.get("adapter_action_execution") is True),
    )


def reconciliation_status_for_pipeline(route_metadata: dict[str, Any] | None, ledger_ids: list[str], error: str = "") -> str:
    if error:
        return "error"
    if route_needs_review(route_metadata):
        return "needs_review"
    return "matched"


def write_reconciliation_status(
    req_id: str,
    item: dict[str, Any],
    args: argparse.Namespace | None,
    *,
    status: str,
    event_id: str = "",
    ledger_ids: list[str] | None = None,
    route_metadata: dict[str, Any] | None = None,
    error: str = "",
) -> None:
    if not room_agent_write_enabled(args):
        return
    room_id, room_name, room_key = room_agent_room_values(item)
    route_id = str((route_metadata or {}).get("selected_capability_id") or "")
    payload = {
        "schema_version": 1,
        "status": status,
        "request_id": str(req_id),
        "event_id": event_id or str(item.get("_room_event_id") or ""),
        "ledger_ids": [str(value) for value in (ledger_ids or []) if str(value or "").strip()][:12],
        "route_id": route_id,
        "room_id": room_id,
        "room_key": room_key,
        "room_name_hash": short_text_hash(room_name),
        "updated_at_ms": now_ms(),
        "worker": getattr(args, "node", "") if args is not None else "",
    }
    if route_metadata:
        payload["route_metadata"] = compact_route_metadata(route_metadata)
    if error:
        payload["error"] = compact_error(error, 500)
    try:
        fb_put(f"{RECONCILIATION_PATH}/requests/{sanitize_key(req_id, 'request')}", payload)
        fb_put(f"{RECONCILIATION_PATH}/rooms/{room_key}/latest", payload)
        fb_put(f"{RECONCILIATION_PATH}/latest", payload)
    except Exception as exc:
        log(f"reconciliation write failed request={req_id}: {compact_error(str(exc), 180)}")


def fb_get_room_agent_context(path: str) -> Any:
    return fb_request("GET", path, timeout=3)


def _recent_dict_items(raw: Any, limit: int) -> list[dict[str, Any]]:
    if not isinstance(raw, dict):
        return []
    rows = [value for value in raw.values() if isinstance(value, dict)]
    rows.sort(
        key=lambda row: normalize_ts_ms(
            row.get("captured_at_ms")
            or row.get("ts_ms")
            or row.get("received_at_ms")
            or row.get("created_at_ms")
            or row.get("updated_at_ms")
            or 0
        ),
        reverse=True,
    )
    return rows[: max(0, limit)]


def build_recent_room_context(room_id: str, room_name: str, *, limit: int = ROOM_AGENT_CONTEXT_MAX_EVENTS, max_chars: int = ROOM_AGENT_CONTEXT_MAX_CHARS) -> str:
    if not env_bool("STOREBOT_ROOM_AGENT_CONTEXT_ENRICH", True):
        return ""
    room_key = sanitize_key(room_id or room_name, "storebot_group")
    lines: list[str] = []
    try:
        last_turn = fb_get_room_agent_context(f"{ROOM_CONTEXT_PATH}/{room_key}") or {}
    except Exception as exc:
        log(f"recent room reply context load failed room={room_key}: {compact_error(str(exc), 120)}")
        last_turn = {}
    if isinstance(last_turn, dict):
        last_user_message = redact_room_text_preview(last_turn.get("user_message") or "", 160)
        last_reply = redact_room_text_preview(last_turn.get("reply") or "", 220)
        if last_user_message or last_reply:
            lines.append("- previous user: " + last_user_message if last_user_message else "- previous user: <empty>")
            lines.append("- previous StoreBot reply: " + last_reply if last_reply else "- previous StoreBot reply: <empty>")
    try:
        raw_events = fb_get_room_agent_context(f"{ROOM_EVENT_JOURNAL_PATH}/rooms/{room_key}/recent") or {}
        events = _recent_dict_items(raw_events, limit)
    except Exception as exc:
        log(f"recent room journal context load failed room={room_key}: {compact_error(str(exc), 120)}")
        events = []
    try:
        raw_ledger = fb_get_room_agent_context(f"{ACTION_LEDGER_PATH}/rooms/{room_key}/recent") or {}
        ledger = _recent_dict_items(raw_ledger, limit)
    except Exception as exc:
        log(f"recent room ledger context load failed room={room_key}: {compact_error(str(exc), 120)}")
        ledger = []
    previous_event_ms = 0
    episode_index = 1
    for event in reversed(events):
        preview = redact_room_text_preview(event.get("text_preview") or "", 120)
        if not preview:
            continue
        sender = redact_room_text_preview(event.get("sender_label_redacted") or event.get("sender") or "", 40)
        event_kind = compact_text(event.get("event_kind") or "chat", 40)
        event_ms = normalize_ts_ms(
            event.get("captured_at_ms")
            or event.get("received_at_ms")
            or event.get("created_at_ms")
            or event.get("updated_at_ms")
            or 0
        )
        if previous_event_ms > 0 and event_ms > 0 and event_ms - previous_event_ms > ROOM_EPISODE_GAP_MS:
            episode_index += 1
            lines.append(f"- episode_boundary gap_min={(event_ms - previous_event_ms) // 60000}")
        time_label = kst_text(event_ms) if event_ms > 0 else "time_unknown"
        lines.append(f"- episode{episode_index} {time_label} event {event_kind} {sender}: {preview}")
        if event_ms > 0:
            previous_event_ms = event_ms
    for entry in reversed(ledger):
        status = compact_text(entry.get("status") or "", 40)
        capability = compact_text(entry.get("selected_capability_id") or entry.get("proposed_action_type") or "", 80)
        output_category = compact_text(entry.get("output_category") or "", 40)
        if status or capability or output_category:
            lines.append(f"- ledger {status} {capability} {output_category}".strip())
    if not lines:
        return ""
    text = "\n".join(lines)
    if len(text) > max_chars:
        text = text[-max_chars:]
    return "## 최근 방 원장 요약(redacted, bounded, episode-aware)\n" + text


def context_sensitive_turn_hint() -> str:
    return (
        "## 맥락 민감 입력 판단 힌트\n"
        "- worker는 전달/실행자일 뿐이다. 업무 의미, 답변/SKIP, action/domain/slot 판단은 StoreBot skill/Codex가 한다.\n"
        "- 짧은 입력, 초성/오타처럼 보이는 입력, 후속 정정은 단독 문장으로 SKIP하지 말고 최근 방 원장, 직전 사용자 입력, 직전 StoreBot 답변과 함께 판단하라.\n"
        "- 같은 방에서 15분 안에 이어진 인물/주문/결제/근무/메뉴 메시지는 하나의 에피소드로 우선 결합하고, 단편별로 별도 질문하지 마라.\n"
        "- 직원들끼리 정정하고 최종 결론을 낸 반복 가능한 운영정보는 사용자가 따로 가르치지 않아도 ops_manual_collect 검토 후보로 남긴다. 이미 결론난 대화에는 불필요하게 끼어들지 마라.\n"
        "- 확신이 낮아도 읽기/검색/최근 주문·근무 조회/맥락 복원처럼 안전한 도움은 진행한다. 금융·주문 확정·영업 영향·파괴적 쓰기만 명확한 근거나 승인을 요구한다.\n"
        "- 한글 건물/아파트명 뒤에 동/호 숫자가 붙은 축약(예: 진우104.1808)은 근무시간이 아니라 주소 후보를 우선한다. 안전한 조회로 문맥을 보강하고, 위험한 쓰기에 필요한 핵심값만 남았을 때 짧게 확인한다."
    )


def sha256_bytes(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def skill_paths(skill_name: str) -> list[Path]:
    return [
        BASE_DIR / ".agents" / "skills" / skill_name / "SKILL.md",
        Path.home() / ".agents" / "skills" / skill_name / "SKILL.md",
    ]


def read_skill(skill_name: str) -> tuple[Path | None, str]:
    for path in skill_paths(skill_name):
        if path.exists():
            return path, path.read_text(encoding="utf-8").strip()
    return None, ""


def extract_markdown_section(markdown: str, heading: str) -> str:
    lines = str(markdown or "").splitlines()
    start = -1
    target = heading.strip()
    for idx, line in enumerate(lines):
        if line.strip() == target:
            start = idx
            break
    if start < 0:
        return ""
    end = len(lines)
    for idx in range(start + 1, len(lines)):
        line = lines[idx]
        if line.startswith("## ") and not line.startswith("### "):
            end = idx
            break
    return "\n".join(lines[start:end]).strip()


def build_fast_router_guide(args: argparse.Namespace) -> tuple[str, Path | None]:
    skill_path, skill = read_skill(getattr(args, "skill_name", "") or "")
    sections = [
        extract_markdown_section(skill, heading)
        for heading in ("## Role", "## Reply Rules", "## Fast Router Contract")
    ]
    if not all(sections):
        return "", skill_path
    selected_guide = "\n\n".join(sections)
    guide = (
        "## StoreBot Resident Fast Router\n"
        "- This is the first AI judgment for Kakao input. The worker must not decide intent before this answer.\n"
        "- The worker only executes `STOREBOT_ACTIONS`, renders images, mirrors status, and transports Kakao messages.\n"
        "- Use KST for relative dates. Keep output machine-readable and short.\n"
        f"- Source of truth: {skill_path}\n\n"
        f"{selected_guide}\n"
    )
    if not getattr(args, "dynamic_guidance", True):
        return guide, skill_path
    try:
        overlay = build_dynamic_guidance_overlay()
    except Exception as exc:
        log(f"fast router guidance load failed: {compact_error(str(exc), 180)}")
        return guide, skill_path
    if overlay:
        guide = f"{guide.rstrip()}\n\n{overlay}\n"
    return guide, skill_path


def fast_router_instruction_hash(router_guide: str, args: argparse.Namespace) -> str:
    payload = {
        "router_guide_sha256": guide_hash(router_guide),
        "skill_name": args.skill_name,
        "storebot_mcp_tools": False,
        "version": 1,
    }
    return guide_hash(json.dumps(payload, ensure_ascii=False, sort_keys=True))


def fast_router_session_key(args: argparse.Namespace, room_identity: str = "default") -> str:
    host = socket.gethostname() or "host"
    identity = json.dumps(
        {
            "host": host,
            "node": str(getattr(args, "node", "") or "node"),
            "model": model_label(args),
            "reasoning_effort": reasoning_label(args),
            "room_id": str(room_identity or "default"),
        },
        ensure_ascii=False,
        separators=(",", ":"),
        sort_keys=True,
    )
    identity_digest = hashlib.sha256(identity.encode("utf-8")).hexdigest()
    return f"{FAST_ROUTER_SESSION_KEY[:15]}_{identity_digest}"


def fast_router_room_lock(session_key: str) -> threading.RLock:
    digest = hashlib.sha256(str(session_key or FAST_ROUTER_SESSION_KEY).encode("utf-8")).digest()
    return _FAST_ROUTER_ROOM_LOCKS[int.from_bytes(digest[:2], "big") % len(_FAST_ROUTER_ROOM_LOCKS)]


def _positive_env_int(name: str, default: int, *, maximum: int = 1_000_000_000) -> int:
    try:
        return min(maximum, max(1, int(os.environ.get(name, str(default)))))
    except (TypeError, ValueError):
        return default


def fast_router_room_turn_limit() -> int:
    return _positive_env_int("STOREBOT_CODEX_FAST_ROUTER_ROOM_TURN_LIMIT", DEFAULT_FAST_ROUTER_ROOM_TURN_LIMIT)


def fast_router_total_token_limit() -> int:
    return _positive_env_int("STOREBOT_CODEX_FAST_ROUTER_TOTAL_TOKEN_LIMIT", DEFAULT_FAST_ROUTER_TOTAL_TOKEN_LIMIT)


def fast_router_prior_turn_duration_limit_ms() -> int:
    return _positive_env_int(
        "STOREBOT_CODEX_FAST_ROUTER_PRIOR_TURN_DURATION_LIMIT_MS",
        DEFAULT_FAST_ROUTER_PRIOR_TURN_DURATION_LIMIT_MS,
    )


def fast_router_runtime_room_limit() -> int:
    return _positive_env_int(
        "STOREBOT_CODEX_FAST_ROUTER_RUNTIME_ROOM_LIMIT",
        DEFAULT_FAST_ROUTER_RUNTIME_ROOM_LIMIT,
        maximum=64,
    )


def fast_router_rotation_reason(meta: dict[str, Any]) -> str:
    if safe_int(meta.get("turn_count")) >= fast_router_room_turn_limit():
        return "turn_count"
    if safe_int(meta.get("reported_total_tokens")) >= fast_router_total_token_limit():
        return "reported_total_tokens"
    if safe_int(meta.get("prior_turn_duration_ms")) >= fast_router_prior_turn_duration_limit_ms():
        return "prior_turn_duration_ms"
    return ""


def _evict_fast_router_runtime_lru_locked(*, protected_key: str = "") -> list[dict[str, Any]]:
    limit = fast_router_runtime_room_limit()
    evicted: list[dict[str, Any]] = []
    while len(_FAST_ROUTER_RUNTIME_SESSIONS) > limit:
        candidates = [
            (safe_int(meta.get("last_used_at_ms")), key)
            for key, meta in _FAST_ROUTER_RUNTIME_SESSIONS.items()
            if key != protected_key and key not in _FAST_ROUTER_ACTIVE_SESSION_KEYS
        ]
        if not candidates:
            return evicted
        _last_used_at_ms, evicted_key = min(candidates)
        evicted_meta = _FAST_ROUTER_RUNTIME_SESSIONS.pop(evicted_key, None)
        if isinstance(evicted_meta, dict):
            evicted.append(dict(evicted_meta))
    return evicted


def fast_router_runtime_metadata(
    args: argparse.Namespace,
    room_identity: str,
    session_id: str = "",
) -> dict[str, Any]:
    session_key = fast_router_session_key(args, room_identity)
    with _FAST_ROUTER_RUNTIME_LOCK:
        meta = _FAST_ROUTER_RUNTIME_SESSIONS.get(session_key) or {}
        if session_id and str(meta.get("session_id") or "") != session_id:
            return {}
        return dict(meta)


def mark_fast_router_room_active(session_key: str, active: bool) -> None:
    evicted: list[dict[str, Any]] = []
    with _FAST_ROUTER_RUNTIME_LOCK:
        if active:
            _FAST_ROUTER_ACTIVE_SESSION_KEYS.add(session_key)
            return
        _FAST_ROUTER_ACTIVE_SESSION_KEYS.discard(session_key)
        evicted = _evict_fast_router_runtime_lru_locked()
    cleanup_fast_router_evictions(evicted)


def record_fast_router_turn(
    args: argparse.Namespace,
    room_identity: str,
    session_id: str,
    result: CodexResult,
    prompt_telemetry: dict[str, Any],
) -> dict[str, Any]:
    session_key = fast_router_session_key(args, room_identity)
    reported_total_tokens = safe_int(result.metadata.get("resident_reported_total_tokens"))
    prior_turn_duration_ms = safe_int(result.metadata.get("resident_turn_duration_ms"))
    evicted: list[dict[str, Any]] = []
    telemetry: dict[str, Any] = {}
    with _FAST_ROUTER_RUNTIME_LOCK:
        meta = _FAST_ROUTER_RUNTIME_SESSIONS.get(session_key) or {}
        if str(meta.get("session_id") or "") != session_id:
            return {}
        meta = dict(meta)
        reported_total_tokens = max(safe_int(meta.get("reported_total_tokens")), reported_total_tokens)
        meta.update(
            {
                "turn_count": safe_int(meta.get("turn_count")) + 1,
                "reported_total_tokens": reported_total_tokens,
                "prior_turn_duration_ms": prior_turn_duration_ms,
                "last_used_at_ms": now_ms(),
                "prompt_total_chars": safe_int(prompt_telemetry.get("fast_router_prompt_total_chars")),
                "prompt_component_chars": dict(prompt_telemetry.get("fast_router_prompt_component_chars") or {}),
            }
        )
        _FAST_ROUTER_RUNTIME_SESSIONS[session_key] = meta
        evicted = _evict_fast_router_runtime_lru_locked(protected_key=session_key)
        telemetry = {
            "fast_router_prompt_total_chars": safe_int(meta.get("prompt_total_chars")),
            "fast_router_prompt_component_chars": dict(meta.get("prompt_component_chars") or {}),
            "fast_router_reported_total_tokens": safe_int(meta.get("reported_total_tokens")),
            "fast_router_max_subturn_duration_ms": safe_int(meta.get("prior_turn_duration_ms")),
            "fast_router_turn_count": safe_int(meta.get("turn_count")),
            "fast_router_rotation_reason": str(meta.get("rotation_reason") or "new"),
            "fast_router_session_generation": safe_int(meta.get("session_generation"), 1),
        }
    cleanup_fast_router_evictions(evicted)
    telemetry.update(fast_router_cleanup_telemetry())
    return telemetry


def fast_router_aggregate_subturn_result(results: list[CodexResult]) -> CodexResult:
    latest = results[-1]
    metadata = dict(latest.metadata)
    metadata["resident_turn_duration_ms"] = max(
        (safe_int(result.metadata.get("resident_turn_duration_ms")) for result in results),
        default=0,
    )
    metadata["resident_reported_total_tokens"] = max(
        (safe_int(result.metadata.get("resident_reported_total_tokens")) for result in results),
        default=0,
    )
    return CodexResult(
        final=latest.final,
        thread_id=latest.thread_id,
        tool_call_count=latest.tool_call_count,
        tool_ok_count=latest.tool_ok_count,
        tool_error_count=latest.tool_error_count,
        metadata=metadata,
    )


def instruction_hash(guide: str, args: argparse.Namespace) -> str:
    skill_path, skill = read_skill(args.skill_name)
    payload = {
        "guide_sha256": guide_hash(guide),
        "skill_name": args.skill_name,
        "skill_path": str(skill_path) if skill_path else "",
        "skill_sha256": guide_hash(skill) if skill else "",
        "storebot_mcp_tools": bool(env_bool("STOREBOT_CODEX_MCP_TOOLS", True)),
        "version": 7,
    }
    return guide_hash(json.dumps(payload, ensure_ascii=False, sort_keys=True))


def skill_prompt_prefix(args: argparse.Namespace) -> str:
    if not args.skill_name:
        return ""
    return (
        f"가능하면 ${args.skill_name} 스킬을 사용하세요.\n"
        "스킬이 보이지 않거나 사용할 수 없으면 아래 MD 기준을 fallback으로 사용하세요.\n"
    )


def mcp_tools_instruction() -> str:
    if not env_bool("STOREBOT_CODEX_MCP_TOOLS", True):
        return ""
    return (
        "현재 StoreBot worker 실행에는 StoreBot MCP 도구가 활성화되어 있습니다.\n"
        "외부 DB/검색/알람/가이드 작업이 필요하면 StoreBot MCP 도구를 우선 사용하세요.\n"
        "도구가 보이지 않거나 tool call이 불안정하면 STOREBOT_ACTIONS fallback으로 같은 의도를 요청해도 됩니다.\n"
    )


def common_codex_args(
    output_path: str,
    model: str | None,
    reasoning_effort: str | None,
    mcp_context: dict[str, Any] | None = None,
) -> list[str]:
    args = [
        "--ignore-user-config",
        "--json",
        "-o",
        output_path,
        "--disable",
        "shell_tool",
        "-c",
        'web_search="disabled"',
        "-c",
        "tools.web_search=false",
        "-c",
        'sandbox_mode="read-only"',
        "-c",
        'approval_policy="never"',
        "--skip-git-repo-check",
        "--ignore-rules",
    ]
    if env_bool("STOREBOT_CODEX_MCP_TOOLS", True):
        mcp_script = BASE_DIR / "scripts" / "storebot_codex_worker.py"
        mcp_server_args = [str(mcp_script), "--mcp-server"]
        if mcp_context:
            mcp_server_args.extend(
                [
                    "--mcp-context-json",
                    json.dumps(mcp_context, ensure_ascii=False, separators=(",", ":")),
                ]
            )
        args.extend(
            [
                "-c",
                "mcp_servers.firebase-hub.enabled=true",
                "-c",
                'mcp_servers.firebase-hub.command="python3"',
                "-c",
                f"mcp_servers.firebase-hub.args={json.dumps(mcp_server_args)}",
                "-c",
                'mcp_servers.firebase-hub.default_tools_approval_mode="approve"',
                "-c",
                f"mcp_servers.firebase-hub.enabled_tools={json.dumps(STOREBOT_MCP_ENABLED_TOOLS)}",
                "-c",
                "mcp_servers.firebase-hub.required=false",
            ]
        )
    if model:
        args.extend(["-m", model])
    if reasoning_effort:
        args.extend(["-c", f'model_reasoning_effort="{reasoning_effort}"'])
    return args


def model_label(args: argparse.Namespace) -> str:
    return args.model or "codex_default"


def reasoning_label(args: argparse.Namespace) -> str:
    return args.reasoning_effort or "codex_default"


def clone_args(args: argparse.Namespace) -> argparse.Namespace:
    return argparse.Namespace(**vars(args))


def first_request_string(item: dict[str, Any], *keys: str) -> str:
    for key in keys:
        value = item.get(key)
        if value is None:
            continue
        text = str(value).strip()
        if text:
            return text
    return ""


def normalize_effort(value: Any, fallback: str | None) -> str | None:
    text = str(value or "").strip().lower()
    if text in {"", "auto", "default", "codex_default"}:
        return fallback
    if text in ALLOWED_REASONING_EFFORTS:
        return text
    return fallback


def request_text_for_model_policy(item: dict[str, Any]) -> str:
    parts = [
        first_request_string(item, "message", "text", "prompt", "query"),
        first_request_string(item, "event_kind", "source"),
    ]
    payload = item.get("payload")
    if isinstance(payload, dict):
        for key in ("message", "text", "query", "reason", "event_kind"):
            if payload.get(key):
                parts.append(str(payload.get(key)))
    return "\n".join(part for part in parts if part)


def wants_escalated_model(item: dict[str, Any]) -> bool:
    text = normalize_key_text(request_text_for_model_policy(item))
    if not text:
        return False
    markers = (
        "상위모델",
        "고급모델",
        "최고모델",
        "상위ai",
        "고급ai",
        "다른답변",
        "답변다시",
        "다시답변",
        "다시분석",
        "재분석",
        "정밀분석",
        "정밀하게",
        "더자세히",
        "더낫게",
        "제대로다시",
        "깊게봐",
    )
    return any(marker in text for marker in markers)


def effective_request_args(item: dict[str, Any], args: argparse.Namespace) -> argparse.Namespace:
    effective = clone_args(args)
    reason = ""
    explicit_model = first_request_string(item, "codex_model", "model_override", "model")
    explicit_effort = first_request_string(item, "codex_reasoning_effort", "reasoning_effort")
    tier = first_request_string(item, "model_tier", "codex_model_tier").lower()
    payload = item.get("payload")
    if isinstance(payload, dict):
        explicit_model = explicit_model or first_request_string(payload, "codex_model", "model_override", "model")
        explicit_effort = explicit_effort or first_request_string(payload, "codex_reasoning_effort", "reasoning_effort")
        tier = tier or first_request_string(payload, "model_tier", "codex_model_tier").lower()

    if explicit_model:
        effective.model = explicit_model
        reason = "explicit_model"
    elif tier in {"high", "upper", "premium", "gpt-5.5", "5.5"} or wants_escalated_model(item):
        effective.model = os.environ.get("STOREBOT_CODEX_ESCALATION_MODEL", DEFAULT_ESCALATION_MODEL).strip() or DEFAULT_ESCALATION_MODEL
        effective.reasoning_effort = normalize_effort(
            os.environ.get("STOREBOT_CODEX_ESCALATION_REASONING_EFFORT", DEFAULT_ESCALATION_REASONING_EFFORT),
            DEFAULT_ESCALATION_REASONING_EFFORT,
        )
        reason = "user_requested_escalation"

    if explicit_effort:
        effective.reasoning_effort = normalize_effort(explicit_effort, effective.reasoning_effort)

    effective.model_override_reason = reason
    return effective


def fast_router_effective_args(args: argparse.Namespace) -> argparse.Namespace:
    effective = clone_args(args)
    router_model = str(os.environ.get("STOREBOT_CODEX_FAST_ROUTER_MODEL") or "").strip()
    if router_model:
        effective.model = router_model
    router_effort = normalize_effort(
        os.environ.get("STOREBOT_CODEX_FAST_ROUTER_REASONING_EFFORT", "low"),
        "low",
    )
    effective.reasoning_effort = router_effort
    return effective


def parse_thread_id(stdout: str) -> str | None:
    for line in stdout.splitlines():
        line = line.strip()
        if not line:
            continue
        try:
            event = json.loads(line)
        except json.JSONDecodeError:
            continue
        if not isinstance(event, dict):
            continue
        if event.get("type") == "thread.started":
            thread_id = event.get("thread_id") or event.get("session_id")
            if isinstance(thread_id, str) and thread_id:
                return thread_id
            thread = event.get("thread")
            if isinstance(thread, dict):
                nested_id = thread.get("id")
                if isinstance(nested_id, str) and nested_id:
                    return nested_id
        for key in ("thread_id", "session_id"):
            value = event.get(key)
            if isinstance(value, str) and re.fullmatch(r"[0-9a-fA-F-]{20,}", value):
                return value
    return None


def parse_codex_event_summary(stdout: str) -> tuple[str | None, int, int, int]:
    thread_id = parse_thread_id(stdout)
    tool_count = 0
    tool_ok_count = 0
    tool_error_count = 0
    for line in stdout.splitlines():
        line = line.strip()
        if not line:
            continue
        try:
            event = json.loads(line)
        except json.JSONDecodeError:
            continue
        if not isinstance(event, dict) or event.get("type") != "item.completed":
            continue
        item = event.get("item")
        if not isinstance(item, dict):
            continue
        item_type = str(item.get("type") or "").lower()
        tool_name = str(item.get("name") or item.get("tool_name") or item.get("tool") or "")
        server_name = str(item.get("server") or item.get("server_name") or item.get("mcp_server") or "")
        if not (
            ("mcp" in item_type and "tool" in item_type)
            or tool_name.startswith("storebot_")
            or server_name == "firebase-hub"
        ):
            continue
        tool_count += 1
        status = str(item.get("status") or "").lower()
        if status in {"failed", "error"} or item.get("error"):
            tool_error_count += 1
        else:
            tool_ok_count += 1
    return thread_id, tool_count, tool_ok_count, tool_error_count


RESIDENT_CODEX_STATE: dict[str, Any] = {
    "enabled": False,
    "active": False,
    "pid": 0,
    "started_at_ms": 0,
    "last_error": "",
    "last_turn_duration_ms": 0,
    "last_total_tokens": 0,
    "session_preboot_enabled": False,
    "session_preboot_ready": False,
    "session_preboot_started_at_ms": 0,
    "session_preboot_ready_at_ms": 0,
    "session_preboot_room_key": "",
    "session_preboot_room_id": "",
    "session_preboot_room_name": "",
    "session_preboot_session_id": "",
    "session_preboot_error": "",
    "session_preboot_in_progress": False,
    "session_preboot_reason": "",
    "session_watchdog_enabled": False,
    "session_watchdog_interval_sec": 0,
    "session_keepalive_interval_sec": 0,
    "session_last_health_check_ms": 0,
    "session_last_keepalive_at_ms": 0,
    "session_health_ok": False,
    "session_health_error": "",
    "last_response_health_error": "",
    "last_response_health": {},
    "session_revive_count": 0,
    "session_last_revived_at_ms": 0,
    "session_last_revive_reason": "",
}
_RESIDENT_CODEX_CLIENT: "ResidentCodexAppServer | None" = None
_RESIDENT_CODEX_LOCK = threading.RLock()
_RESIDENT_SESSION_PREBOOT_LOCK = threading.Lock()
_FAST_ROUTER_RUNTIME_SESSIONS: dict[str, dict[str, Any]] = {}
_FAST_ROUTER_RUNTIME_LOCK = threading.RLock()
_FAST_ROUTER_ROOM_LOCKS = tuple(threading.RLock() for _ in range(32))
_FAST_ROUTER_ACTIVE_SESSION_KEYS: set[str] = set()
_FAST_ROUTER_CLEANUP_LOCK = threading.Lock()
_FAST_ROUTER_CLEANUP_STATE: dict[str, Any] = {
    "supported": True,
    "method": FAST_ROUTER_THREAD_CLEANUP_METHOD,
    "attempt_count": 0,
    "ok_count": 0,
    "failure_count": 0,
    "created_thread_count": 0,
    "evicted_thread_count": 0,
    "last_status": "not_attempted",
    "last_error": "",
    "last_duration_ms": 0,
}
_FAST_ROUTER_REFRESH_LOCK = threading.Lock()
_FAST_ROUTER_REFRESH_IN_PROGRESS: set[str] = set()
_RESIDENT_RECOVERY_LOCK = threading.Lock()
_RESIDENT_RECOVERY_LAST_ATTEMPT_MS = 0
_LOCAL_DIRECT_DEFERRED_LOCK = threading.Lock()
_LOCAL_DIRECT_DEFERRED_REQUESTS: set[str] = set()
_TELEGRAM_BACKPLANE_ADAPTER_LOCK = threading.Lock()
_TELEGRAM_BACKPLANE_ADAPTER: StoreBotTelegramWorkerAdapter | None = None
_TELEGRAM_BACKPLANE_ADAPTER_KEY_HASH = ""


def parse_quoted_config_value(value: str) -> str:
    text = str(value or "").strip()
    if "=" in text:
        text = text.split("=", 1)[1].strip()
    if len(text) >= 2 and text[0] == text[-1] and text[0] in {"'", '"'}:
        return text[1:-1]
    return text


def parse_codex_exec_command(cmd: list[str]) -> dict[str, Any] | None:
    if len(cmd) < 2 or cmd[0] != "codex" or cmd[1] != "exec":
        return None
    mode = "exec"
    index = 2
    if len(cmd) > 2 and cmd[2] == "resume":
        mode = "resume"
        index = 3
    model = ""
    effort = ""
    cwd = DEFAULT_CODEX_CWD
    session_id = ""
    while index < len(cmd):
        part = cmd[index]
        if part in {"-m", "--model"} and index + 1 < len(cmd):
            model = cmd[index + 1]
            index += 2
            continue
        if part in {"-C", "--cd"} and index + 1 < len(cmd):
            cwd = cmd[index + 1]
            index += 2
            continue
        if part in {"-c", "--config"} and index + 1 < len(cmd):
            config_value = cmd[index + 1]
            if str(config_value).startswith("model_reasoning_effort="):
                effort = parse_quoted_config_value(config_value)
            index += 2
            continue
        if mode == "resume" and part != "-" and not part.startswith("-"):
            session_id = part
        index += 1
    return {
        "mode": mode,
        "model": model or None,
        "effort": effort or None,
        "cwd": cwd,
        "session_id": session_id,
    }


def ensure_storebot_codex_home(env_name: str = "STOREBOT_CODEX_HOME", fallback_env_name: str = "") -> Path:
    configured = os.environ.get(env_name)
    if not configured and fallback_env_name:
        configured = os.environ.get(fallback_env_name)
    home = Path(configured or DEFAULT_STOREBOT_CODEX_HOME).expanduser()
    home.mkdir(parents=True, exist_ok=True)
    auth_path = home / "auth.json"
    if not auth_path.exists():
        default_auth = Path.home() / ".codex" / "auth.json"
        if default_auth.exists():
            try:
                auth_path.symlink_to(default_auth)
            except (FileExistsError, OSError):
                if not auth_path.exists():
                    shutil.copy2(default_auth, auth_path)
    source_models = Path.home() / ".codex" / "models_cache.json"
    target_models = home / "models_cache.json"
    try:
        same_models = source_models.exists() and target_models.exists() and source_models.samefile(target_models)
    except OSError:
        same_models = False
    try:
        if (
            source_models.exists()
            and not same_models
            and (
                not target_models.exists()
                or source_models.stat().st_mtime > target_models.stat().st_mtime
            )
        ):
            shutil.copy2(source_models, target_models)
    except OSError as exc:
        log(f"codex model cache sync warning: {compact_error(str(exc), 160)}")
    return home


def ensure_resident_codex_home() -> Path:
    return ensure_storebot_codex_home("STOREBOT_CODEX_RESIDENT_CODEX_HOME", "STOREBOT_CODEX_HOME")


def storebot_codex_subprocess_env() -> dict[str, str]:
    env = os.environ.copy()
    env["CODEX_HOME"] = str(ensure_storebot_codex_home())
    return env


def terminate_process_group(proc: subprocess.Popen[str] | None) -> None:
    if not proc or proc.poll() is not None:
        return
    try:
        os.killpg(os.getpgid(proc.pid), signal.SIGTERM)
    except Exception:
        proc.terminate()
    try:
        proc.wait(timeout=5)
        return
    except Exception:
        pass
    try:
        os.killpg(os.getpgid(proc.pid), signal.SIGKILL)
    except Exception:
        proc.kill()
    try:
        proc.wait(timeout=5)
    except Exception:
        pass


def run_codex_process(
    cmd: list[str],
    *,
    input_text: str | None,
    timeout_sec: int,
    cwd: str,
) -> subprocess.CompletedProcess[str]:
    proc = subprocess.Popen(
        cmd,
        stdin=subprocess.PIPE if input_text is not None else None,
        stdout=subprocess.PIPE,
        stderr=subprocess.PIPE,
        text=True,
        cwd=cwd,
        env=storebot_codex_subprocess_env(),
        start_new_session=True,
    )
    try:
        stdout, stderr = proc.communicate(input=input_text, timeout=timeout_sec)
    except subprocess.TimeoutExpired:
        terminate_process_group(proc)
        raise
    return subprocess.CompletedProcess(cmd, proc.returncode, stdout, stderr)


class ResidentCodexAppServer:
    def __init__(self) -> None:
        self.proc: subprocess.Popen[str] | None = None
        self.lock = threading.RLock()
        self.thread_ids: set[str] = set()

    def close(self) -> None:
        with self.lock:
            proc = self.proc
            self.proc = None
            self.thread_ids.clear()
            RESIDENT_CODEX_STATE.update({"active": False, "pid": 0})
            self._terminate_proc_locked(proc)

    @staticmethod
    def _terminate_proc_locked(proc: subprocess.Popen[str] | None) -> None:
        if proc and proc.poll() is None:
            try:
                try:
                    os.killpg(os.getpgid(proc.pid), signal.SIGTERM)
                except Exception:
                    proc.terminate()
                proc.wait(timeout=5)
            except Exception:
                try:
                    try:
                        os.killpg(os.getpgid(proc.pid), signal.SIGKILL)
                    except Exception:
                        proc.kill()
                    proc.wait(timeout=5)
                except Exception:
                    pass

    def _start_locked(self, model: str | None, effort: str | None) -> None:
        if self.proc and self.proc.poll() is None:
            return
        home = ensure_resident_codex_home()
        if not (home / "auth.json").exists():
            raise WorkerError(f"resident codex auth missing: {home / 'auth.json'}")
        env = os.environ.copy()
        env["CODEX_HOME"] = str(home)
        cmd = [
            "codex",
            "app-server",
            "--listen",
            "stdio://",
            "-c",
            f'model="{model or DEFAULT_MODEL}"',
            "-c",
            f'model_reasoning_effort="{effort or DEFAULT_REASONING_EFFORT}"',
            "-c",
            'sandbox_mode="read-only"',
            "-c",
            'approval_policy="never"',
            "-c",
            'web_search="disabled"',
            "-c",
            "tools.web_search=false",
        ]
        self.proc = subprocess.Popen(
            cmd,
            stdin=subprocess.PIPE,
            stdout=subprocess.PIPE,
            stderr=subprocess.DEVNULL,
            text=True,
            encoding="utf-8",
            errors="strict",
            bufsize=1,
            cwd=DEFAULT_CODEX_CWD,
            env=env,
            start_new_session=True,
        )
        RESIDENT_CODEX_STATE.update(
            {
                "enabled": True,
                "active": True,
                "pid": int(self.proc.pid or 0),
                "started_at_ms": now_ms(),
                "last_error": "",
            }
        )
        init_id = self._request_locked(
            "initialize",
            {
                "clientInfo": {
                    "name": "storebot-resident-worker",
                    "title": "StoreBot Resident Worker",
                    "version": "0.1",
                },
                "capabilities": {
                    "experimentalApi": True,
                    "requestAttestation": False,
                    "optOutNotificationMethods": [
                        "command/exec/outputDelta",
                        "item/agentMessage/delta",
                        "item/plan/delta",
                        "item/fileChange/outputDelta",
                        "item/reasoning/summaryTextDelta",
                        "item/reasoning/textDelta",
                    ],
                },
            },
            timeout_sec=20,
        )
        if init_id.get("error"):
            raise WorkerError(compact_error(str(init_id.get("error")), 300))
        self._send_locked({"method": "initialized"})
        log(f"resident codex app-server started pid={self.proc.pid}")

    def _send_locked(self, payload: dict[str, Any]) -> None:
        if not self.proc or not self.proc.stdin:
            raise WorkerError("resident codex not started")
        self.proc.stdin.write(json.dumps(payload, ensure_ascii=False, separators=(",", ":")) + "\n")
        self.proc.stdin.flush()

    def _read_json_locked(self, timeout_sec: float) -> dict[str, Any]:
        if not self.proc or not self.proc.stdout:
            raise WorkerError("resident codex not started")
        deadline = time.monotonic() + max(0.2, timeout_sec)
        while time.monotonic() < deadline:
            if self.proc.poll() is not None:
                raise WorkerError(f"resident codex exited {self.proc.returncode}")
            ready, _, _ = select.select([self.proc.stdout], [], [], min(0.2, max(0.0, deadline - time.monotonic())))
            if not ready:
                continue
            line = self.proc.stdout.readline()
            if not line:
                continue
            try:
                msg = json.loads(line)
            except json.JSONDecodeError:
                continue
            if isinstance(msg, dict):
                return msg
        raise WorkerError(f"resident codex timeout after {int(timeout_sec)}s")

    def _request_locked(self, method: str, params: dict[str, Any], timeout_sec: int) -> dict[str, Any]:
        req_id = str(uuid.uuid4())
        self._send_locked({"id": req_id, "method": method, "params": params})
        deadline = time.monotonic() + max(1, timeout_sec)
        while time.monotonic() < deadline:
            msg = self._read_json_locked(max(0.2, deadline - time.monotonic()))
            if msg.get("id") != req_id:
                continue
            if msg.get("error"):
                raise WorkerError(compact_error(json.dumps(msg.get("error"), ensure_ascii=False), 500))
            return msg
        raise WorkerError(f"resident codex request timeout method={method}")

    def _send_request_locked(self, method: str, params: dict[str, Any]) -> str:
        req_id = str(uuid.uuid4())
        self._send_locked({"id": req_id, "method": method, "params": params})
        return req_id

    @staticmethod
    def _turn_id_from_response(msg: dict[str, Any]) -> str:
        result = msg.get("result") if isinstance(msg.get("result"), dict) else {}
        turn = result.get("turn") if isinstance(result.get("turn"), dict) else {}
        return str(
            turn.get("id")
            or turn.get("turnId")
            or result.get("turnId")
            or msg.get("turnId")
            or ""
        ).strip()

    @staticmethod
    def _event_scope(params: dict[str, Any], item: dict[str, Any] | None = None, turn: dict[str, Any] | None = None) -> tuple[str, str]:
        item = item if isinstance(item, dict) else {}
        turn = turn if isinstance(turn, dict) else {}
        thread_id = str(
            params.get("threadId")
            or params.get("thread_id")
            or item.get("threadId")
            or item.get("thread_id")
            or turn.get("threadId")
            or turn.get("thread_id")
            or ""
        ).strip()
        turn_id = str(
            params.get("turnId")
            or params.get("turn_id")
            or item.get("turnId")
            or item.get("turn_id")
            or turn.get("id")
            or turn.get("turnId")
            or turn.get("turn_id")
            or ""
        ).strip()
        return thread_id, turn_id

    @classmethod
    def _matches_current_turn(
        cls,
        params: dict[str, Any],
        thread_id: str,
        expected_turn_id: str,
        *,
        item: dict[str, Any] | None = None,
        turn: dict[str, Any] | None = None,
    ) -> bool:
        event_thread_id, event_turn_id = cls._event_scope(params, item=item, turn=turn)
        if event_thread_id and event_thread_id != thread_id:
            return False
        if expected_turn_id and event_turn_id and event_turn_id != expected_turn_id:
            return False
        return True

    def _thread_params(
        self,
        model: str | None,
        effort: str | None,
        cwd: str,
        developer_instructions: str | None = None,
    ) -> dict[str, Any]:
        params: dict[str, Any] = {
            "model": model or DEFAULT_MODEL,
            "cwd": cwd or DEFAULT_CODEX_CWD,
            "approvalPolicy": "never",
            "sandbox": "read-only",
            "runtimeWorkspaceRoots": [cwd or DEFAULT_CODEX_CWD],
            "developerInstructions": developer_instructions or (
                "StoreBot 전용 상주 답변 세션이다. 도구가 보이지 않으면 STOREBOT_ACTIONS fallback을 쓰고, "
                "최종 카카오톡 답변만 짧게 출력한다."
            ),
            "ephemeral": False,
        }
        if effort:
            params["config"] = {"model_reasoning_effort": effort}
        return params

    def _thread_start_timeout(self) -> int:
        try:
            return max(30, int(os.environ.get("STOREBOT_CODEX_RESIDENT_THREAD_START_TIMEOUT_SEC", "60")))
        except (TypeError, ValueError):
            return 60

    def create_thread(
        self,
        model: str | None,
        effort: str | None,
        cwd: str,
        developer_instructions: str,
        timeout_sec: int,
    ) -> str:
        with self.lock:
            self._start_locked(model, effort)
            response = self._request_locked(
                "thread/start",
                self._thread_params(model, effort, cwd, developer_instructions),
                timeout_sec=max(self._thread_start_timeout(), min(max(30, timeout_sec), 180)),
            )
            thread = (response.get("result") or {}).get("thread") or {}
            thread_id = str(thread.get("id") or "")
            if not thread_id:
                raise WorkerError("resident codex thread id missing")
            self.thread_ids.add(thread_id)
            return thread_id

    def _turn_params(
        self,
        thread_id: str,
        prompt: str,
        model: str | None,
        effort: str | None,
        cwd: str,
        image_paths: list[str] | None = None,
    ) -> dict[str, Any]:
        inputs: list[dict[str, Any]] = [{"type": "text", "text": prompt, "text_elements": []}]
        workspace_roots = [cwd or DEFAULT_CODEX_CWD]
        for image_path in image_paths or []:
            inputs.append({"type": "localImage", "path": image_path, "detail": "original"})
            image_parent = str(Path(image_path).parent)
            if image_parent not in workspace_roots:
                workspace_roots.append(image_parent)
        params: dict[str, Any] = {
            "threadId": thread_id,
            "input": inputs,
            "model": model or DEFAULT_MODEL,
            "cwd": cwd or DEFAULT_CODEX_CWD,
            "runtimeWorkspaceRoots": workspace_roots,
            "approvalPolicy": "never",
            "sandboxPolicy": {"type": "readOnly", "networkAccess": False},
        }
        if effort:
            params["effort"] = effort
        return params

    def start_thread(
        self,
        prompt: str,
        model: str | None,
        effort: str | None,
        cwd: str,
        timeout_sec: int,
        image_paths: list[str] | None = None,
    ) -> CodexResult:
        with self.lock:
            self._start_locked(model, effort)
            response = self._request_locked("thread/start", self._thread_params(model, effort, cwd), timeout_sec=self._thread_start_timeout())
            thread = (response.get("result") or {}).get("thread") or {}
            thread_id = str(thread.get("id") or "")
            if not thread_id:
                raise WorkerError("resident codex thread id missing")
            self.thread_ids.add(thread_id)
            return self.turn(
                thread_id,
                prompt,
                model,
                effort,
                cwd,
                timeout_sec,
                already_locked=True,
                image_paths=image_paths,
            )

    def resume_thread(self, thread_id: str, model: str | None, effort: str | None, cwd: str, timeout_sec: int) -> None:
        if thread_id in self.thread_ids:
            return
        params = self._thread_params(model, effort, cwd)
        params.update({"threadId": thread_id, "excludeTurns": True})
        response = self._request_locked("thread/resume", params, timeout_sec=min(30, max(10, timeout_sec)))
        thread = (response.get("result") or {}).get("thread") or {}
        resumed_id = str(thread.get("id") or thread_id)
        self.thread_ids.add(resumed_id)

    def prepare_thread(self, thread_id: str, model: str | None, effort: str | None, cwd: str, timeout_sec: int) -> None:
        with self.lock:
            self._start_locked(model, effort)
            self.resume_thread(thread_id, model, effort, cwd, timeout_sec)

    def unsubscribe_thread(self, thread_id: str, timeout_sec: int = FAST_ROUTER_THREAD_CLEANUP_TIMEOUT_SEC) -> str:
        bounded_timeout = max(1, min(int(timeout_sec or FAST_ROUTER_THREAD_CLEANUP_TIMEOUT_SEC), 10))
        if not self.lock.acquire(timeout=bounded_timeout):
            raise WorkerError("resident codex thread cleanup busy timeout")
        try:
            if not self.proc or self.proc.poll() is not None:
                raise WorkerError("resident codex thread cleanup requires active app-server")
            response = self._request_locked(
                FAST_ROUTER_THREAD_CLEANUP_METHOD,
                {"threadId": thread_id},
                timeout_sec=bounded_timeout,
            )
            result = response.get("result") if isinstance(response.get("result"), dict) else {}
            status = str(result.get("status") or "")
            if status not in FAST_ROUTER_THREAD_CLEANUP_ACK_STATUSES:
                raise WorkerError(f"resident codex thread cleanup invalid status: {status or 'missing'}")
            self.thread_ids.discard(thread_id)
            return status
        finally:
            self.lock.release()

    def turn(
        self,
        thread_id: str,
        prompt: str,
        model: str | None,
        effort: str | None,
        cwd: str,
        timeout_sec: int,
        *,
        already_locked: bool = False,
        image_paths: list[str] | None = None,
    ) -> CodexResult:
        if already_locked:
            return self._turn_locked(thread_id, prompt, model, effort, cwd, timeout_sec, image_paths=image_paths)
        with self.lock:
            self._start_locked(model, effort)
            self.resume_thread(thread_id, model, effort, cwd, timeout_sec)
            return self._turn_locked(thread_id, prompt, model, effort, cwd, timeout_sec, image_paths=image_paths)

    def _turn_locked(
        self,
        thread_id: str,
        prompt: str,
        model: str | None,
        effort: str | None,
        cwd: str,
        timeout_sec: int,
        *,
        image_paths: list[str] | None = None,
    ) -> CodexResult:
        submit_started = time.perf_counter()
        turn_start_req_id = self._send_request_locked(
            "turn/start",
            self._turn_params(thread_id, prompt, model, effort, cwd, image_paths=image_paths),
        )
        resident_submit_ms = int((time.perf_counter() - submit_started) * 1000)
        started = time.perf_counter()
        deadline = time.monotonic() + max(1, timeout_sec)
        expected_turn_id = ""
        answer = ""
        duration_ms = 0
        total_tokens = 0
        tool_count = 0
        tool_ok_count = 0
        tool_error_count = 0
        stale_event_discard_count = 0
        event_order = 0
        event_diagnostics: list[dict[str, Any]] = []
        delta_parts: list[str] = []
        delta_text_len = 0

        def remember_event(
            method: str,
            *,
            item_type: str = "",
            text: str = "",
            turn_status: str = "",
            stale: bool = False,
        ) -> None:
            nonlocal event_order
            event_order += 1
            text_value = str(text or "")
            event_diagnostics.append(
                {
                    "method": method,
                    "item_type": item_type,
                    "order": event_order,
                    "has_text": bool(text_value),
                    "text_len": len(text_value),
                    "text_sha256": clean_reply_sha256(text_value) if text_value else "",
                    "turn_status": turn_status,
                    "stale": bool(stale),
                }
            )
            if len(event_diagnostics) > 40:
                del event_diagnostics[:-40]

        def response_health_failure(turn_status: str = "") -> WorkerError:
            wait_ms = duration_ms or int((time.perf_counter() - started) * 1000)
            total_ms = int((time.perf_counter() - submit_started) * 1000)
            error_code = "resident_response_health_empty_final"
            safe_metadata = {
                "error_code": error_code,
                "brain_route": "resident",
                "reply_source": "resident_session",
                "fallback_used": False,
                "worker_role": "thin_bridge",
                "cli_direct": True,
                "resident_required": True,
                "bounded_worker_exec_fallback": False,
                "resident_submit_ms": resident_submit_ms,
                "resident_wait_ms": wait_ms,
                "resident_turn_duration_ms": wait_ms,
                "resident_session_id": thread_id,
                "resident_turn_id": expected_turn_id,
                "resident_app_server_pid": int(RESIDENT_CODEX_STATE.get("pid") or 0),
                "resident_stale_event_discard_count": stale_event_discard_count,
                "resident_event_diagnostics": event_diagnostics,
                "resident_turn_status": turn_status,
                "clean_extract_ms": 0,
                "total_ms": total_ms,
            }
            RESIDENT_CODEX_STATE.update(
                {
                    "active": False,
                    "last_error": error_code,
                    "session_health_ok": False,
                    "session_health_error": error_code,
                    "last_turn_duration_ms": wait_ms,
                    "last_total_tokens": total_tokens,
                    "last_turn_id": expected_turn_id,
                    "last_stale_event_discard_count": stale_event_discard_count,
                    "last_response_health_error": error_code,
                    "last_response_health": compact_payload(safe_metadata, 3000),
                }
            )
            self.close()
            return WorkerError(f"{error_code} turn_id={expected_turn_id or 'unknown'}")

        while time.monotonic() < deadline:
            msg = self._read_json_locked(max(0.2, deadline - time.monotonic()))
            if msg.get("id") == turn_start_req_id:
                if msg.get("error"):
                    raise WorkerError(compact_error(json.dumps(msg.get("error"), ensure_ascii=False), 500))
                expected_turn_id = self._turn_id_from_response(msg) or expected_turn_id
                continue
            method = str(msg.get("method") or "")
            params = msg.get("params") if isinstance(msg.get("params"), dict) else {}
            if method == "item/completed":
                item = params.get("item") if isinstance(params, dict) else {}
                if not isinstance(item, dict):
                    continue
                if not self._matches_current_turn(params, thread_id, expected_turn_id, item=item):
                    stale_event_discard_count += 1
                    remember_event(method, item_type=str(item.get("type") or ""), text=str(item.get("text") or ""), stale=True)
                    continue
                item_type = str(item.get("type") or "")
                text = str(item.get("text") or "")
                remember_event(method, item_type=item_type, text=text)
                if item_type == "agentMessage":
                    answer = str(text or answer).strip()
                elif "tool" in item_type.lower() or str(item.get("toolName") or item.get("name") or "").startswith("storebot_"):
                    tool_count += 1
                    status = str(item.get("status") or "").lower()
                    if status in {"failed", "error"} or item.get("error"):
                        tool_error_count += 1
                    else:
                        tool_ok_count += 1
            elif method == "item/agentMessage/delta":
                if not self._matches_current_turn(params, thread_id, expected_turn_id):
                    stale_event_discard_count += 1
                    remember_event(method, item_type="agentMessage", text=str(params.get("delta") or params.get("text") or ""), stale=True)
                    continue
                delta_text = str(params.get("delta") or params.get("text") or "")
                remember_event(method, item_type="agentMessage", text=delta_text)
                if delta_text and delta_text_len < 4096:
                    remaining = 4096 - delta_text_len
                    delta_parts.append(delta_text[:remaining])
                    delta_text_len += min(len(delta_text), remaining)
            elif method == "thread/tokenUsage/updated":
                if not self._matches_current_turn(params, thread_id, expected_turn_id):
                    stale_event_discard_count += 1
                    remember_event(method, stale=True)
                    continue
                usage = params.get("tokenUsage") if isinstance(params, dict) else {}
                if isinstance(usage, dict):
                    total = usage.get("total")
                    if isinstance(total, dict):
                        total_tokens = safe_int(total.get("totalTokens"))
            elif method == "turn/completed":
                turn = params.get("turn") if isinstance(params, dict) else {}
                if not self._matches_current_turn(params, thread_id, expected_turn_id, turn=turn if isinstance(turn, dict) else {}):
                    stale_event_discard_count += 1
                    remember_event(method, stale=True)
                    continue
                turn_status = ""
                if isinstance(turn, dict):
                    duration_ms = safe_int(turn.get("durationMs"))
                    error = turn.get("error")
                    turn_status = str(turn.get("status") or "")
                    remember_event(method, turn_status=turn_status)
                    if error or turn_status.lower() == "failed":
                        raise WorkerError(compact_error(json.dumps(error or turn, ensure_ascii=False), 500))
                if not answer and delta_parts:
                    answer = "".join(delta_parts).strip()
                if not answer:
                    raise response_health_failure(turn_status)
                RESIDENT_CODEX_STATE.update(
                    {
                        "last_error": "",
                        "session_health_ok": True,
                        "session_health_error": "",
                        "last_response_health_error": "",
                        "last_turn_duration_ms": duration_ms or int((time.perf_counter() - started) * 1000),
                        "last_total_tokens": total_tokens,
                        "last_turn_id": expected_turn_id,
                        "last_stale_event_discard_count": stale_event_discard_count,
                    }
                )
                return CodexResult(
                    final=answer,
                    thread_id=thread_id,
                    tool_call_count=tool_count,
                    tool_ok_count=tool_ok_count,
                    tool_error_count=tool_error_count,
                    metadata={
                        "brain_route": "resident",
                        "reply_source": "resident_session",
                        "fallback_used": False,
                        "worker_role": "thin_bridge",
                        "cli_direct": True,
                        "resident_required": True,
                        "default_model_policy": "thin_bridge_cli_direct_resident_required",
                        "fast_brain_hot_path": False,
                        "bounded_worker_exec_fallback": False,
                        "resident_submit_ms": resident_submit_ms,
                        "resident_wait_ms": duration_ms or int((time.perf_counter() - started) * 1000),
                        "resident_turn_duration_ms": duration_ms or int((time.perf_counter() - started) * 1000),
                        "resident_reported_total_tokens": total_tokens,
                        "resident_session_id": thread_id,
                        "resident_turn_id": expected_turn_id,
                        "resident_app_server_pid": int(RESIDENT_CODEX_STATE.get("pid") or 0),
                        "resident_stale_event_discard_count": stale_event_discard_count,
                    },
                )
        error = f"resident codex timeout after {timeout_sec}s"
        RESIDENT_CODEX_STATE.update(
            {
                "active": False,
                "last_error": error,
                "session_health_ok": False,
                "session_health_error": error,
                "last_turn_id": expected_turn_id,
                "last_stale_event_discard_count": stale_event_discard_count,
            }
        )
        self.close()
        raise WorkerError(error)


def resident_codex_client() -> ResidentCodexAppServer:
    global _RESIDENT_CODEX_CLIENT
    with _RESIDENT_CODEX_LOCK:
        if _RESIDENT_CODEX_CLIENT is None:
            _RESIDENT_CODEX_CLIENT = ResidentCodexAppServer()
        return _RESIDENT_CODEX_CLIENT


def fast_router_cleanup_telemetry() -> dict[str, Any]:
    with _FAST_ROUTER_CLEANUP_LOCK:
        state = dict(_FAST_ROUTER_CLEANUP_STATE)
    return {
        "fast_router_thread_cleanup_supported": bool(state.get("supported")),
        "fast_router_thread_cleanup_method": str(state.get("method") or ""),
        "fast_router_thread_cleanup_attempt_count": safe_int(state.get("attempt_count")),
        "fast_router_thread_cleanup_ok_count": safe_int(state.get("ok_count")),
        "fast_router_thread_cleanup_failure_count": safe_int(state.get("failure_count")),
        "fast_router_thread_cleanup_created_count": safe_int(state.get("created_thread_count")),
        "fast_router_thread_cleanup_evicted_count": safe_int(state.get("evicted_thread_count")),
        "fast_router_thread_cleanup_last_status": str(state.get("last_status") or ""),
        "fast_router_thread_cleanup_last_error": compact_error(str(state.get("last_error") or ""), 180),
        "fast_router_thread_cleanup_last_duration_ms": safe_int(state.get("last_duration_ms")),
    }


def cleanup_fast_router_evictions(evicted: list[dict[str, Any]]) -> None:
    for meta in evicted:
        session_id = str(meta.get("session_id") or "").strip()
        if not session_id:
            continue
        started = time.perf_counter()
        with _FAST_ROUTER_CLEANUP_LOCK:
            _FAST_ROUTER_CLEANUP_STATE["attempt_count"] = safe_int(_FAST_ROUTER_CLEANUP_STATE.get("attempt_count")) + 1
            _FAST_ROUTER_CLEANUP_STATE["evicted_thread_count"] = safe_int(
                _FAST_ROUTER_CLEANUP_STATE.get("evicted_thread_count")
            ) + 1
        try:
            status = resident_codex_client().unsubscribe_thread(
                session_id,
                FAST_ROUTER_THREAD_CLEANUP_TIMEOUT_SEC,
            )
        except Exception as exc:
            duration_ms = int((time.perf_counter() - started) * 1000)
            with _FAST_ROUTER_CLEANUP_LOCK:
                _FAST_ROUTER_CLEANUP_STATE.update(
                    {
                        "failure_count": safe_int(_FAST_ROUTER_CLEANUP_STATE.get("failure_count")) + 1,
                        "last_status": "failed",
                        "last_error": compact_error(str(exc), 180),
                        "last_duration_ms": duration_ms,
                    }
                )
            log(f"fast router thread cleanup failed: {compact_error(str(exc), 180)}")
            continue
        duration_ms = int((time.perf_counter() - started) * 1000)
        with _FAST_ROUTER_CLEANUP_LOCK:
            _FAST_ROUTER_CLEANUP_STATE.update(
                {
                    "ok_count": safe_int(_FAST_ROUTER_CLEANUP_STATE.get("ok_count")) + 1,
                    "last_status": status,
                    "last_error": "",
                    "last_duration_ms": duration_ms,
                }
            )


def shutdown_resident_codex() -> None:
    global _RESIDENT_CODEX_CLIENT
    with _RESIDENT_CODEX_LOCK:
        client = _RESIDENT_CODEX_CLIENT
        _RESIDENT_CODEX_CLIENT = None
        with _FAST_ROUTER_RUNTIME_LOCK:
            _FAST_ROUTER_RUNTIME_SESSIONS.clear()
            _FAST_ROUTER_ACTIVE_SESSION_KEYS.clear()
        if client:
            client.close()


def resident_codex_process_alive() -> bool:
    with _RESIDENT_CODEX_LOCK:
        client = _RESIDENT_CODEX_CLIENT
    if not client:
        RESIDENT_CODEX_STATE.update({"active": False, "pid": 0})
        return False
    with client.lock:
        proc = client.proc
        alive = bool(proc and proc.poll() is None)
        RESIDENT_CODEX_STATE.update(
            {
                "active": alive,
                "pid": int(proc.pid or 0) if alive and proc else 0,
            }
        )
        return alive


def record_resident_session_revive(reason: str) -> None:
    RESIDENT_CODEX_STATE.update(
        {
            "session_revive_count": int(RESIDENT_CODEX_STATE.get("session_revive_count") or 0) + 1,
            "session_last_revived_at_ms": now_ms(),
            "session_last_revive_reason": str(reason or "unknown"),
        }
    )


atexit.register(shutdown_resident_codex)


def run_codex_resident(
    full_cmd: list[str],
    prompt: str,
    timeout_sec: int,
    image_paths: list[str] | None = None,
) -> CodexResult:
    spec = parse_codex_exec_command(full_cmd)
    if not spec:
        raise WorkerError("resident codex unsupported command")
    client = resident_codex_client()
    model = spec.get("model")
    effort = spec.get("effort")
    cwd = str(spec.get("cwd") or DEFAULT_CODEX_CWD)
    if spec.get("mode") == "resume":
        session_id = str(spec.get("session_id") or "").strip()
        if not session_id:
            raise WorkerError("resident codex resume missing session id")
        return client.turn(session_id, prompt, model, effort, cwd, timeout_sec, image_paths=image_paths)
    return client.start_thread(prompt, model, effort, cwd, timeout_sec, image_paths=image_paths)


def append_codex_image_args(full_cmd: list[str], image_paths: list[str] | None) -> list[str]:
    if not image_paths:
        return list(full_cmd)
    insertion = 3 if len(full_cmd) > 2 and full_cmd[2] == "resume" else 2
    image_args: list[str] = []
    for image_path in image_paths:
        image_args.extend(["--image", image_path])
    return list(full_cmd[:insertion]) + image_args + list(full_cmd[insertion:])


def run_codex(
    cmd: list[str],
    prompt: str,
    timeout_sec: int,
    image_paths: list[str] | None = None,
) -> CodexResult:
    output_file = tempfile.NamedTemporaryFile(prefix="storebot_codex_", suffix=".txt", delete=False)
    output_path = output_file.name
    output_file.close()
    full_cmd = [part if part != "{OUTPUT}" else output_path for part in cmd]
    started_at = time.monotonic()
    resident_fallback_error = ""

    def remaining_timeout(minimum: int = 1) -> int:
        remaining = int(timeout_sec - (time.monotonic() - started_at))
        return max(minimum, remaining)

    try:
        if env_bool("STOREBOT_CODEX_RESIDENT_APP_SERVER", True):
            RESIDENT_CODEX_STATE["enabled"] = True
            try:
                return run_codex_resident(full_cmd, prompt, timeout_sec, image_paths=image_paths)
            except Exception as exc:
                error = compact_error(str(exc), 400)
                root_exc: Exception = exc
                RESIDENT_CODEX_STATE.update(
                    {
                        "active": False,
                        "last_error": error,
                        "session_health_ok": False,
                        "session_health_error": error,
                    }
                )
                shutdown_resident_codex()
                if env_bool("STOREBOT_CODEX_RESIDENT_REVIVE_ON_FAILURE", True):
                    record_resident_session_revive("request_failure")
                    log(f"resident codex failed; reviving resident session once: {error}")
                    if remaining_timeout(0) <= 5:
                        raise WorkerError(error) from root_exc
                    try:
                        result = run_codex_resident(
                            full_cmd,
                            prompt,
                            remaining_timeout(5),
                            image_paths=image_paths,
                        )
                        RESIDENT_CODEX_STATE.update(
                            {
                                "last_error": "",
                                "session_health_ok": True,
                                "session_health_error": "",
                            }
                        )
                        return result
                    except Exception as retry_exc:
                        root_exc = retry_exc
                        error = compact_error(str(retry_exc), 400)
                        RESIDENT_CODEX_STATE.update(
                            {
                                "active": False,
                                "last_error": error,
                                "session_health_ok": False,
                                "session_health_error": error,
                            }
                        )
                        shutdown_resident_codex()
                if not resident_exec_fallback_enabled():
                    raise WorkerError(error) from root_exc
                resident_fallback_error = error
                log(f"resident codex failed; falling back to codex exec: {error}")
        exec_timeout = remaining_timeout(5)
        try:
            proc = run_codex_process(
                append_codex_image_args(full_cmd, image_paths),
                input_text=prompt,
                timeout_sec=exec_timeout,
                cwd=str(BASE_DIR),
            )
            final = Path(output_path).read_text(encoding="utf-8", errors="replace").strip()
            thread_id, tool_count, tool_ok_count, tool_error_count = parse_codex_event_summary(proc.stdout)
            if proc.returncode != 0:
                detail = compact_error(proc.stderr or proc.stdout or "codex exec failed")
                raise WorkerError(detail)
            spec = parse_codex_exec_command(full_cmd) or {}
            exec_route = "codex_exec_resume" if spec.get("mode") == "resume" else "codex_exec"
            metadata = {
                "brain_route": "codex_exec_fallback" if resident_fallback_error else exec_route,
                "reply_source": "codex_exec_resume" if spec.get("mode") == "resume" else "codex_exec_session",
                "fallback_used": bool(resident_fallback_error),
                "codex_exec_duration_ms": int((time.monotonic() - started_at) * 1000),
            }
            if resident_fallback_error:
                metadata["resident_fallback_error"] = resident_fallback_error
            return CodexResult(
                final=final,
                thread_id=thread_id,
                tool_call_count=tool_count,
                tool_ok_count=tool_ok_count,
                tool_error_count=tool_error_count,
                metadata=metadata,
            )
        except subprocess.TimeoutExpired as exc:
            raise WorkerError(f"codex timeout after {timeout_sec}s") from exc
    finally:
        try:
            Path(output_path).unlink()
        except FileNotFoundError:
            pass


def archive_session(session_id: str, args: argparse.Namespace) -> tuple[bool, str]:
    session_id = session_id.strip()
    if not session_id:
        return False, "empty session id"
    try:
        proc = run_codex_process(
            ["codex", "archive", session_id],
            input_text=None,
            timeout_sec=30,
            cwd=str(BASE_DIR),
        )
    except subprocess.TimeoutExpired:
        return False, "archive timeout"
    except Exception as exc:
        return False, compact_error(str(exc), 250)
    if proc.returncode != 0:
        return False, compact_error(proc.stderr or proc.stdout or "archive failed", 250)
    return True, ""


def read_json_file(path: Path) -> dict[str, Any]:
    try:
        data = json.loads(path.read_text(encoding="utf-8"))
    except (FileNotFoundError, json.JSONDecodeError):
        return {}
    return data if isinstance(data, dict) else {}


def write_json_atomic(path: Path, payload: dict[str, Any]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    tmp = path.with_name(f"{path.name}.tmp.{os.getpid()}")
    tmp.write_text(json.dumps(payload, ensure_ascii=False, indent=2, sort_keys=True) + "\n", encoding="utf-8")
    os.replace(tmp, path)


def briefing_channel_dir() -> Path:
    return Path(os.environ.get("STOREBOT_BRIEFING_CHANNEL_DIR", BRIEFING_CHANNEL_DEFAULT_DIR)).expanduser()


def briefing_channel_remote_mirror_enabled() -> bool:
    return env_bool("STOREBOT_BRIEFING_CHANNEL_FIREBASE_MIRROR", False)


def briefing_channel_preview(value: Any, limit: int = 240) -> str:
    text = re.sub(r"\s+", " ", str(value or "")).strip()
    return text[: max(1, limit)]


def briefing_channel_event_id(event: dict[str, Any]) -> str:
    raw_id = str(event.get("event_id") or "").strip()
    if raw_id:
        return sanitize_key(raw_id, "event")
    event_type = str(event.get("event_type") or "event")
    request_id = str(event.get("request_id") or "")
    created_at = normalize_ts_ms(event.get("created_at_ms") or now_ms())
    return sanitize_key(f"event_{created_at}_{request_id}_{event_type}", "event")


def briefing_channel_room_key(event: dict[str, Any]) -> str:
    raw = (
        event.get("briefing_channel_room_id")
        or event.get("room_id")
        or event.get("room_name")
        or "storebot_group"
    )
    return sanitize_key(str(raw), "kakao_storebot_group")


def is_briefing_channel_transport_noise(event: dict[str, Any]) -> bool:
    if event.get("transport_noise") is True:
        return True
    if str(event.get("event_type") or "") != "inbound_message":
        return False
    if str(event.get("event_kind") or "").strip() == CHAT_IMAGE_EVENT_KIND:
        return False
    text = briefing_channel_preview(event.get("message") or event.get("text") or "", 120)
    if not text:
        return True
    exact_noise = {
        "사진을 보냈습니다.",
        "사진을 보냈습니다",
        "동영상을 보냈습니다.",
        "동영상을 보냈습니다",
        "파일을 보냈습니다.",
        "파일을 보냈습니다",
        "삭제된 메시지입니다.",
        "삭제된 메시지입니다",
    }
    return text in exact_noise


def build_briefing_channel_text(room: dict[str, Any]) -> str:
    room_label = str(room.get("room_name") or room.get("briefing_channel_room_id") or room.get("room_id") or "")
    status = str(room.get("processing_status") or "")
    sender = str(room.get("last_sender") or "")
    message = briefing_channel_preview(room.get("last_message_preview") or room.get("last_message") or "", 180)
    summary = briefing_channel_preview(room.get("summary_context") or "", 260)
    outbound = str(room.get("outbound_intent") or room.get("last_outbound_category") or "")
    last_reply = briefing_channel_preview(room.get("last_ai_response") or "", 220)
    failure_status = str(room.get("failure_status") or room.get("missing_status") or "")
    failure_reason = briefing_channel_preview(room.get("failure_reason") or "", 180)
    lines: list[str] = []
    if room_label:
        lines.append(f"[방] {room_label}")
    if status:
        lines.append(f"[상태] {status}")
    if message:
        prefix = f"{sender}: " if sender else ""
        lines.append(f"[최근 입력] {prefix}{message}")
    if summary:
        lines.append(f"[요약 맥락] {summary}")
    if outbound:
        lines.append(f"[출력 의도] {outbound}")
    if last_reply:
        lines.append(f"[마지막 응답] {last_reply}")
    if failure_status or failure_reason:
        detail = f"{failure_status} {failure_reason}".strip()
        lines.append(f"[누락/실패] {detail}")
    return "\n".join(lines)


def update_briefing_channel_event(item: dict[str, Any], args: argparse.Namespace) -> dict[str, Any]:
    event = dict(item)
    created_at = normalize_ts_ms(event.get("created_at_ms") or event.get("updated_at_ms") or now_ms())
    updated_at = now_ms()
    event["schema_version"] = int(event.get("schema_version") or 1)
    event["created_at_ms"] = created_at
    event["updated_at_ms"] = updated_at
    event["channel_owner"] = "storebot_codex_worker"
    event["remote_mirror_enabled"] = briefing_channel_remote_mirror_enabled()

    event_id = briefing_channel_event_id(event)
    room_key = briefing_channel_room_key(event)
    room_dir = briefing_channel_dir() / "rooms"
    event_dir = briefing_channel_dir() / "events"
    room_path = room_dir / f"{room_key}.json"
    event_path = event_dir / f"{event_id}.json"

    if is_briefing_channel_transport_noise(event):
        event["ignored"] = True
        event["ignore_reason"] = "transport_noise"
        write_json_atomic(event_path, event)
        write_json_atomic(briefing_channel_dir() / "latest.json", event)
        journal_event_id = append_room_event_journal(
            str(event.get("request_id") or event_id),
            event,
            args,
            event_id=event_id,
        )
        return {
            "ok": True,
            "briefing_channel": True,
            "ignored": True,
            "ignore_reason": "transport_noise",
            "event_id": event_id,
            "room_event_journal_event_id": journal_event_id,
            "event_path": str(event_path),
        }

    room = read_json_file(room_path)
    now = updated_at
    if not room:
        room = {
            "schema_version": 1,
            "room_id": str(event.get("room_id") or "storebot_group"),
            "briefing_channel_room_id": str(event.get("briefing_channel_room_id") or room_key),
            "room_name": str(event.get("room_name") or ""),
            "source": "storebot_codex_worker",
            "recent_messages": [],
            "created_at_ms": now,
        }

    room.update(
        {
            "schema_version": 1,
            "room_id": str(event.get("room_id") or room.get("room_id") or "storebot_group"),
            "briefing_channel_room_id": str(event.get("briefing_channel_room_id") or room.get("briefing_channel_room_id") or room_key),
            "room_name": str(event.get("room_name") or room.get("room_name") or ""),
            "processing_status": str(event.get("processing_status") or room.get("processing_status") or ""),
            "last_request_id": str(event.get("request_id") or room.get("last_request_id") or ""),
            "transport": str(event.get("transport") or room.get("transport") or ""),
            "source": "storebot_codex_worker",
            "updated_at_ms": now,
        }
    )

    event_type = str(event.get("event_type") or "")
    if event_type == "inbound_message":
        message = str(event.get("message") or event.get("text") or "")
        entry = {
            "event_id": event_id,
            "request_id": str(event.get("request_id") or ""),
            "sender": str(event.get("sender") or ""),
            "message": message[:1200],
            "message_preview": briefing_channel_preview(message, 180),
            "message_hash": str(event.get("message_hash") or short_text_hash(message)),
            "created_at_ms": created_at,
            "message_ts_ms": normalize_ts_ms(event.get("message_ts_ms") or created_at),
            "transport": str(event.get("transport") or ""),
        }
        recent = room.get("recent_messages")
        if not isinstance(recent, list):
            recent = []
        recent = [msg for msg in recent if isinstance(msg, dict)]
        recent.append(entry)
        room["recent_messages"] = recent[-BRIEFING_CHANNEL_MAX_RECENT:]
        room["last_inbound_event_id"] = event_id
        room["last_sender"] = entry["sender"]
        room["last_message"] = entry["message"]
        room["last_message_preview"] = entry["message_preview"]
        room["last_message_hash"] = entry["message_hash"]
        room["missing_status"] = ""
        room["failure_status"] = ""
        room["failure_reason"] = ""
    elif event_type == "outbound_intent":
        category = str(event.get("outbound_category") or event.get("output_category") or "log_only")
        room["last_outbound_intent_event_id"] = event_id
        room["last_outbound_category"] = category
        room["outbound_intent"] = category
        room["last_ai_response"] = str(event.get("reply_preview") or "")
        room["last_ai_response_hash"] = str(event.get("reply_hash") or "")
        room["last_ai_response_len"] = int(event.get("reply_len") or 0)
        room["skipped"] = bool(event.get("skipped") is True)
        room["deferred"] = bool(event.get("deferred") is True)
        room["image_request_type"] = str(event.get("image_request_type") or "")
        room["image_required"] = bool(event.get("image_required") is True)
        room["failure_status"] = ""
        room["failure_reason"] = ""
    elif event_type == "transport_failure":
        failure_status = str(event.get("failure_status") or event.get("processing_status") or "transport_failure")
        room["last_failure_event_id"] = event_id
        room["failure_status"] = failure_status
        room["failure_reason"] = briefing_channel_preview(event.get("failure_reason") or "", 240)
        room["missing_status"] = failure_status

    room["briefing_text"] = build_briefing_channel_text(room)
    event["event_id"] = event_id
    event["briefing_channel_room_key"] = room_key
    event["room_state_path"] = str(room_path)

    write_json_atomic(event_path, event)
    write_json_atomic(room_path, room)
    write_json_atomic(briefing_channel_dir() / "latest.json", {"event": event, "room": room})

    if briefing_channel_remote_mirror_enabled():
        try:
            fb_put(f"{BRIEFING_CHANNEL_REMOTE_PATH}/events/{event_id}", event)
            fb_put(f"{BRIEFING_CHANNEL_REMOTE_PATH}/events/latest", event)
            fb_put(f"{BRIEFING_CHANNEL_REMOTE_PATH}/rooms/{room_key}", room)
        except Exception as exc:
            log(f"briefing-channel remote mirror failed event={event_id}: {compact_error(str(exc), 180)}")

    journal_event_id = append_room_event_journal(
        str(event.get("request_id") or event_id),
        event,
        args,
        event_id=event_id,
    )

    return {
        "ok": True,
        "briefing_channel": True,
        "event_id": event_id,
        "room_event_journal_event_id": journal_event_id,
        "room_key": room_key,
        "room_path": str(room_path),
        "event_path": str(event_path),
        "remote_mirror_enabled": briefing_channel_remote_mirror_enabled(),
    }


def briefing_channel_room_id_from_item(item: dict[str, Any]) -> str:
    raw = str(item.get("briefing_channel_room_id") or "").strip()
    if raw:
        return raw
    room_name = str(item.get("room_name") or item.get("roomTitle") or item.get("room_id") or item.get("room") or "")
    key = sanitize_key(room_name, "storebot_group")
    if not key.startswith("kakao_"):
        key = f"kakao_{key}"
    return key[:96]


def briefing_channel_base_event(req_id: str, item: dict[str, Any], event_type: str) -> dict[str, Any]:
    created_at = now_ms()
    message_ts = normalize_ts_ms(item.get("ts_ms") or item.get("message_ts_ms") or item.get("created_at_ms") or created_at)
    return {
        "schema_version": 1,
        "event_type": event_type,
        "event_id": sanitize_key(f"worker_{req_id}_{event_type}_{created_at}", "event"),
        "source": "storebot_codex_worker_local_direct",
        "request_id": str(req_id or item.get("request_id") or ""),
        "room_id": str(item.get("room_id") or item.get("room") or "storebot_group"),
        "briefing_channel_room_id": briefing_channel_room_id_from_item(item),
        "room_name": str(item.get("room_name") or item.get("roomTitle") or ""),
        "sender": str(item.get("sender") or ""),
        "transport": str(item.get("transport") or "local_direct"),
        "ingress_claim_key": str(item.get("ingress_claim_key") or ""),
        "message_ts_ms": message_ts,
        "created_at_ms": created_at,
        "updated_at_ms": created_at,
        "local_direct": True,
        "shadow_only": False,
        "channel_owner": "storebot_codex_worker",
    }


def briefing_channel_outbound_category(response: dict[str, Any]) -> str:
    image_request = response.get("image_request")
    if isinstance(image_request, dict) and str(image_request.get("type") or "") == "schedule_briefing":
        return "schedule_image"
    category = str(response.get("output_category") or "").strip().lower().replace("-", "_")
    if response.get("skipped") is True or category == "skip":
        return "skip"
    if category.startswith("system_"):
        return category
    if category in {"report", "log_only", "self_heal", "self_fix", "kakao_reply"}:
        return category
    reply = str(response.get("reply") or "")
    return "kakao_reply" if reply.strip() else "log_only"


def briefing_channel_outbound_status(category: str, response: dict[str, Any]) -> str:
    if response.get("deferred") is True:
        return "deferred_no_kakao_send"
    if (
        category == "skip"
        or category in {"report", "log_only", "self_heal", "self_fix"}
        or category.startswith("system_")
    ):
        return "no_kakao_send"
    return "outbound_intent_ready"


def mirror_briefing_channel_inbound(req_id: str, item: dict[str, Any], args: argparse.Namespace) -> None:
    try:
        event = briefing_channel_base_event(req_id, item, "inbound_message")
        message = str(item.get("message") or item.get("text") or "")
        event.update(
            {
                "processing_status": "local_direct_inflight",
                "message": message,
                "message_preview": briefing_channel_preview(message, 180),
                "message_hash": short_text_hash(message),
            }
        )
        update_briefing_channel_event(event, args)
    except Exception as exc:
        log(f"briefing-channel inbound mirror failed request={req_id}: {compact_error(str(exc), 180)}")


def mirror_briefing_channel_outbound(
    req_id: str,
    item: dict[str, Any],
    args: argparse.Namespace,
    response: dict[str, Any],
) -> None:
    try:
        event = briefing_channel_base_event(req_id, item, "outbound_intent")
        category = briefing_channel_outbound_category(response)
        reply = str(response.get("reply") or "")
        event.update(
            {
                "processing_status": briefing_channel_outbound_status(category, response),
                "outbound_category": category,
                "output_category": str(response.get("output_category") or ""),
                "reply_preview": briefing_channel_preview(reply, 240),
                "reply_hash": short_text_hash(reply) if reply else "",
                "reply_len": len(reply),
                "skipped": bool(response.get("skipped") is True),
                "deferred": bool(response.get("deferred") is True),
                "self_fix_request_id": str(response.get("self_fix_request_id") or ""),
                "actual_send_owner": "storebot_termux_existing_transport",
                "publish_queue": False,
            }
        )
        image_request = response.get("image_request")
        if isinstance(image_request, dict):
            event["image_request_type"] = str(image_request.get("type") or "")
            event["image_required"] = bool(response.get("image_required") or image_request.get("required") or False)
            event["image_send_policy"] = str(response.get("image_send_policy") or image_request.get("send_policy") or "")
            event["image_fallback_policy"] = str(image_request.get("fallback_policy") or "")
        update_briefing_channel_event(event, args)
    except Exception as exc:
        log(f"briefing-channel outbound mirror failed request={req_id}: {compact_error(str(exc), 180)}")


def mirror_briefing_channel_failure(
    req_id: str,
    item: dict[str, Any],
    args: argparse.Namespace,
    status: str,
    reason: str,
) -> None:
    try:
        event = briefing_channel_base_event(req_id, item, "transport_failure")
        event.update(
            {
                "processing_status": str(status or "transport_failure"),
                "failure_status": str(status or "transport_failure"),
                "failure_reason": briefing_channel_preview(reason, 240),
            }
        )
        update_briefing_channel_event(event, args)
    except Exception as exc:
        log(f"briefing-channel failure mirror failed request={req_id}: {compact_error(str(exc), 180)}")


def _openclaw_text_from_content(content: Any) -> str:
    if isinstance(content, str):
        return content.strip()
    if isinstance(content, list):
        parts: list[str] = []
        for part in content:
            if isinstance(part, str):
                text = part.strip()
            elif isinstance(part, dict) and str(part.get("type") or "") == "text":
                text = str(part.get("text") or "").strip()
            else:
                text = ""
            if text:
                parts.append(text)
        return "\n\n".join(parts).strip()
    return ""


def extract_openclaw_final_from_trajectory(path: Path) -> dict[str, Any]:
    last: dict[str, Any] = {}
    try:
        with path.open("r", encoding="utf-8", errors="replace") as handle:
            for line_no, line in enumerate(handle, start=1):
                line = line.strip()
                if not line:
                    continue
                try:
                    event = json.loads(line)
                except json.JSONDecodeError:
                    continue
                if not isinstance(event, dict) or event.get("type") != "model.completed":
                    continue
                data = event.get("data")
                if not isinstance(data, dict):
                    data = {}
                if data.get("timedOut") is True or data.get("aborted") is True:
                    continue
                assistant_texts = data.get("assistantTexts")
                text = _openclaw_text_from_content(assistant_texts)
                if not text:
                    continue
                last = {
                    "ok": True,
                    "source": "trajectory",
                    "path": str(path),
                    "line": line_no,
                    "final": text,
                    "session_id": str(event.get("sessionId") or data.get("sessionId") or ""),
                    "session_key": str(event.get("sessionKey") or data.get("sessionKey") or ""),
                    "run_id": str(event.get("runId") or data.get("runId") or ""),
                    "thread_id": str(data.get("threadId") or ""),
                    "turn_id": str(data.get("turnId") or ""),
                    "model": str(event.get("modelId") or data.get("modelId") or ""),
                    "ts": str(event.get("ts") or ""),
                }
    except FileNotFoundError:
        return {"ok": False, "error": "file not found", "path": str(path)}
    except OSError as exc:
        return {"ok": False, "error": compact_error(str(exc), 300), "path": str(path)}
    if last:
        return last
    return {"ok": False, "error": "no completed assistantTexts", "path": str(path)}


def extract_openclaw_final_from_session(path: Path) -> dict[str, Any]:
    last: dict[str, Any] = {}
    try:
        with path.open("r", encoding="utf-8", errors="replace") as handle:
            for line_no, line in enumerate(handle, start=1):
                line = line.strip()
                if not line:
                    continue
                try:
                    event = json.loads(line)
                except json.JSONDecodeError:
                    continue
                if not isinstance(event, dict) or event.get("type") != "message":
                    continue
                message = event.get("message")
                if not isinstance(message, dict) or message.get("role") != "assistant":
                    continue
                text = _openclaw_text_from_content(message.get("content"))
                if not text:
                    continue
                meta = message.get("__openclaw") if isinstance(message.get("__openclaw"), dict) else {}
                last = {
                    "ok": True,
                    "source": "session",
                    "path": str(path),
                    "line": line_no,
                    "final": text,
                    "session_id": str(event.get("sessionId") or meta.get("sessionId") or ""),
                    "thread_id": str(event.get("threadId") or ""),
                    "turn_id": str(event.get("turnId") or ""),
                    "model": str(event.get("modelId") or ""),
                    "ts": str(event.get("ts") or ""),
                }
    except FileNotFoundError:
        return {"ok": False, "error": "file not found", "path": str(path)}
    except OSError as exc:
        return {"ok": False, "error": compact_error(str(exc), 300), "path": str(path)}
    if last:
        return last
    return {"ok": False, "error": "no assistant message", "path": str(path)}


def extract_openclaw_final_from_path(path: Path) -> dict[str, Any]:
    if path.name.endswith(".trajectory.jsonl"):
        return extract_openclaw_final_from_trajectory(path)
    result = extract_openclaw_final_from_session(path)
    if result.get("ok") is True:
        return result
    trajectory = path.with_name(path.name.removesuffix(".jsonl") + ".trajectory.jsonl")
    if trajectory != path and trajectory.exists():
        return extract_openclaw_final_from_trajectory(trajectory)
    return result


def latest_openclaw_final(sessions_dir: Path, limit: int = 80) -> dict[str, Any]:
    if not sessions_dir.exists():
        return {"ok": False, "error": "sessions dir not found", "path": str(sessions_dir)}
    files = [
        path
        for path in sessions_dir.glob("*.jsonl")
        if path.is_file() and (path.name.endswith(".trajectory.jsonl") or not path.name.endswith(".events.jsonl"))
    ]
    files.sort(key=lambda path: path.stat().st_mtime, reverse=True)
    errors: list[str] = []
    for path in files[: max(1, limit)]:
        result = extract_openclaw_final_from_path(path)
        if result.get("ok") is True:
            return result
        if result.get("error"):
            errors.append(f"{path.name}:{result.get('error')}")
    return {
        "ok": False,
        "error": "no OpenClaw final answer found",
        "path": str(sessions_dir),
        "checked": min(len(files), max(1, limit)),
        "last_errors": errors[:5],
    }


def read_bundle_state() -> dict[str, Any]:
    return read_json_file(SELF_SYNC_STATE_FILE)


def fetch_json_url(url: str, timeout: int = 15) -> dict[str, Any]:
    req = urllib.request.Request(url, headers={"User-Agent": "StoreBotCodexWorker/1"})
    with urllib.request.urlopen(req, timeout=timeout) as resp:
        raw = resp.read().decode("utf-8")
    data = json.loads(raw)
    if not isinstance(data, dict):
        raise WorkerError("self-sync manifest is not a JSON object")
    return data


def fetch_bytes_url(url: str, timeout: int = 30) -> bytes:
    req = urllib.request.Request(url, headers={"User-Agent": "StoreBotCodexWorker/1"})
    with urllib.request.urlopen(req, timeout=timeout) as resp:
        return resp.read()


def manifest_file_hashes(manifest: dict[str, Any]) -> dict[str, str]:
    raw_files = manifest.get("files") or {}
    hashes: dict[str, str] = {}
    if isinstance(raw_files, dict):
        for name, value in raw_files.items():
            if isinstance(value, str):
                hashes[str(name)] = value
            elif isinstance(value, dict) and isinstance(value.get("sha256"), str):
                hashes[str(name)] = str(value["sha256"])
    elif isinstance(raw_files, list):
        for item in raw_files:
            if not isinstance(item, dict):
                continue
            name = item.get("path") or item.get("name")
            digest = item.get("sha256")
            if isinstance(name, str) and isinstance(digest, str):
                hashes[name] = digest
    return hashes


def bundle_targets_for(source_name: str) -> list[Path]:
    targets = BUNDLE_FILE_TARGETS.get(source_name)
    if targets is not None:
        return targets
    if not source_name.startswith(CONTEXT_BUNDLE_PREFIX):
        return []
    parts = source_name.split("/")
    if any(part in {"", ".", ".."} for part in parts):
        return []
    return [BASE_DIR.joinpath(*parts)]


def required_bundle_hashes(manifest: dict[str, Any]) -> dict[str, str]:
    hashes = manifest_file_hashes(manifest)
    if manifest.get("legacy_compatible") is True:
        supported = {name: digest for name, digest in hashes.items() if bundle_targets_for(name)}
        if not supported:
            raise WorkerError("self-sync legacy manifest has no supported file hashes")
        return supported
    missing = [name for name in BUNDLE_FILE_TARGETS if name not in hashes]
    if missing:
        raise WorkerError(f"self-sync manifest missing file hashes: {', '.join(missing[:3])}")
    return {name: digest for name, digest in hashes.items() if bundle_targets_for(name)}


def installed_bundle_files_match(file_hashes: dict[str, str]) -> bool:
    for source_name, expected in file_hashes.items():
        targets = bundle_targets_for(source_name)
        if not targets:
            return False
        for target in targets:
            try:
                data = target.read_bytes()
            except FileNotFoundError:
                return False
            if sha256_bytes(data) != expected:
                return False
    return True


def automation_runtime_expected_hashes(file_hashes: dict[str, str]) -> dict[str, str]:
    missing = [name for name in AUTOMATION_RUNTIME_BUNDLE_PATHS if name not in file_hashes]
    if missing:
        raise WorkerError(f"automation runtime manifest hash missing: {missing[0]}")
    return {
        relative_path: file_hashes[source_name]
        for source_name, relative_path in AUTOMATION_RUNTIME_BUNDLE_PATHS.items()
    }


def verify_automation_runtime_files(file_hashes: dict[str, str]) -> dict[str, str]:
    expected = automation_runtime_expected_hashes(file_hashes)
    verified: dict[str, str] = {}
    for relative_path, expected_hash in expected.items():
        target = BASE_DIR / relative_path
        try:
            actual_hash = sha256_bytes(target.read_bytes())
        except OSError as exc:
            raise WorkerError(f"automation runtime file missing: {relative_path}") from exc
        if actual_hash != expected_hash:
            raise WorkerError(f"automation runtime installed hash mismatch: {relative_path}")
        verified[relative_path] = actual_hash
    return verified


def bundle_revision(manifest: dict[str, Any]) -> str:
    return str(manifest.get("source_revision") or manifest.get("code_revision") or "").strip()


def applying_bundle_state(manifest: dict[str, Any], bundle_hash: str, manifest_url: str = "") -> dict[str, Any]:
    revision = bundle_revision(manifest)
    return {
        "schema_version": 2,
        "status": "applying",
        "target_bundle_version": str(manifest.get("version") or ""),
        "target_bundle_sha256": bundle_hash,
        "target_source_revision": revision,
        "target_code_revision": revision,
        "manifest_url": manifest_url,
        "apply_started_at_ms": now_ms(),
        "automation_runtime_files": {},
    }


def failed_bundle_state(
    manifest: dict[str, Any], bundle_hash: str, error: str, manifest_url: str = ""
) -> dict[str, Any]:
    state = applying_bundle_state(manifest, bundle_hash, manifest_url)
    state.update(
        {
            "status": "failed",
            "failed_at_ms": now_ms(),
            "error": compact_error(error, 500),
        }
    )
    return state


def verified_bundle_state(
    manifest: dict[str, Any],
    bundle_hash: str,
    runtime_files: dict[str, str],
    manifest_url: str = "",
    status: str = "applied",
) -> dict[str, Any]:
    revision = bundle_revision(manifest)
    return {
        "schema_version": 2,
        "status": status,
        "bundle_version": str(manifest.get("version") or ""),
        "bundle_sha256": bundle_hash,
        "source_revision": revision,
        "code_revision": revision,
        "manifest_url": manifest_url,
        "applied_at_ms": now_ms(),
        "automation_runtime_files": dict(sorted(runtime_files.items())),
    }


def bundle_state_is_usable(
    state: dict[str, Any], bundle_hash: str, revision: str, runtime_files: dict[str, str]
) -> bool:
    return (
        state.get("schema_version") == 2
        and state.get("status") in {"applied", "native_sync", "verified_current"}
        and state.get("bundle_sha256") == bundle_hash
        and state.get("source_revision") == revision
        and state.get("code_revision") == revision
        and state.get("automation_runtime_files") == dict(sorted(runtime_files.items()))
    )


@contextmanager
def deployment_lock(path: Path | None = None, timeout_sec: float = DEPLOYMENT_LOCK_TIMEOUT_SEC):
    if fcntl is None:
        raise WorkerError("deployment lock unavailable")
    lock_path = path or DEPLOYMENT_LOCK_FILE
    lock_path.parent.mkdir(parents=True, exist_ok=True)
    handle = lock_path.open("a+b")
    deadline = time.monotonic() + max(0.1, float(timeout_sec))
    try:
        while True:
            try:
                fcntl.flock(handle.fileno(), fcntl.LOCK_EX | fcntl.LOCK_NB)
                break
            except BlockingIOError:
                if time.monotonic() >= deadline:
                    raise WorkerError("deployment lock timeout")
                time.sleep(0.05)
        yield
    finally:
        try:
            fcntl.flock(handle.fileno(), fcntl.LOCK_UN)
        finally:
            handle.close()


def write_file_atomic(path: Path, data: bytes, executable: bool) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    tmp = path.with_name(f"{path.name}.tmp.{os.getpid()}")
    tmp.write_bytes(data)
    if executable:
        tmp.chmod(0o755)
    else:
        tmp.chmod(0o644)
    os.replace(tmp, path)


def record_self_sync_status(args: argparse.Namespace, status: str, manifest: dict[str, Any], error: str = "") -> None:
    if args.dry_run:
        return
    payload = {
        "status": status,
        "ts": now_ms(),
        "node": args.node,
        "manifest_url": args.self_sync_manifest_url,
        "bundle_version": str(manifest.get("version") or ""),
        "bundle_sha256": str(manifest.get("bundle_sha256") or manifest.get("sha256") or ""),
        "error": compact_error(error, 250) if error else "",
    }
    try:
        fb_put(SELF_SYNC_STATUS_PATH, payload)
    except Exception as exc:
        log(f"self-sync status write failed: {compact_error(str(exc), 250)}")


def apply_self_sync_bundle(
    manifest: dict[str, Any], bundle_bytes: bytes, *, manifest_url: str = ""
) -> dict[str, Any]:
    expected_bundle_hash = str(manifest.get("bundle_sha256") or manifest.get("sha256") or "").strip()
    actual_bundle_hash = sha256_bytes(bundle_bytes)
    if not expected_bundle_hash:
        raise WorkerError("self-sync manifest missing bundle_sha256")
    if actual_bundle_hash != expected_bundle_hash:
        raise WorkerError("self-sync bundle hash mismatch")
    if not bundle_revision(manifest):
        raise WorkerError("self-sync manifest missing source revision")

    file_hashes = required_bundle_hashes(manifest)
    prepared: dict[str, tuple[bytes, bool, list[Path]]] = {}
    with zipfile.ZipFile(io.BytesIO(bundle_bytes)) as archive:
        names = set(archive.namelist())
        extra = sorted(name for name in names if name not in file_hashes and name != "bundle_manifest.json")
        if extra:
            raise WorkerError(f"self-sync bundle contains unexpected file: {extra[0]}")
        for source_name, expected_hash in file_hashes.items():
            if source_name not in names:
                raise WorkerError(f"self-sync bundle missing file: {source_name}")
            data = archive.read(source_name)
            if sha256_bytes(data) != expected_hash:
                raise WorkerError(f"self-sync file hash mismatch: {source_name}")
            targets = bundle_targets_for(source_name)
            if not targets:
                raise WorkerError(f"self-sync file has no install target: {source_name}")
            prepared[source_name] = (data, source_name in EXECUTABLE_BUNDLE_FILES, targets)

    automation_runtime_expected_hashes(file_hashes)
    with deployment_lock():
        write_json_atomic(SELF_SYNC_STATE_FILE, applying_bundle_state(manifest, expected_bundle_hash, manifest_url))
        try:
            for data, executable, targets in prepared.values():
                for target in targets:
                    write_file_atomic(target, data, executable)
            runtime_files = verify_automation_runtime_files(file_hashes)
            final_state = verified_bundle_state(
                manifest,
                expected_bundle_hash,
                runtime_files,
                manifest_url,
                status="applied",
            )
            write_json_atomic(SELF_SYNC_STATE_FILE, final_state)
            return final_state
        except Exception as exc:
            write_json_atomic(
                SELF_SYNC_STATE_FILE,
                failed_bundle_state(manifest, expected_bundle_hash, str(exc), manifest_url),
            )
            raise


def maybe_self_sync(args: argparse.Namespace) -> bool:
    if not args.self_sync or args.dry_run:
        return False
    manifest = fetch_json_url(args.self_sync_manifest_url)
    if manifest.get("enabled") is False:
        record_self_sync_status(args, "disabled", manifest)
        return False

    bundle_url = str(manifest.get("bundle_url") or manifest.get("bundleUrl") or manifest.get("url") or "").strip()
    if not bundle_url:
        raise WorkerError("self-sync manifest missing bundle_url")
    bundle_url = urllib.parse.urljoin(args.self_sync_manifest_url, bundle_url)
    bundle_hash = str(manifest.get("bundle_sha256") or manifest.get("sha256") or "").strip()
    if not bundle_hash:
        raise WorkerError("self-sync manifest missing bundle_sha256")
    revision = bundle_revision(manifest)
    if not revision:
        raise WorkerError("self-sync manifest missing source revision")

    file_hashes = required_bundle_hashes(manifest)
    state = read_bundle_state()
    runtime_files: dict[str, str] = {}
    try:
        runtime_files = verify_automation_runtime_files(file_hashes)
    except WorkerError:
        pass
    if (
        installed_bundle_files_match(file_hashes)
        and runtime_files
        and bundle_state_is_usable(state, bundle_hash, revision, runtime_files)
    ):
        record_self_sync_status(args, "current", manifest)
        return False
    if installed_bundle_files_match(file_hashes):
        previous_hash = str(state.get("bundle_sha256") or "").strip()
        should_restart = previous_hash != bundle_hash
        with deployment_lock():
            write_json_atomic(
                SELF_SYNC_STATE_FILE,
                applying_bundle_state(manifest, bundle_hash, args.self_sync_manifest_url),
            )
            try:
                runtime_files = verify_automation_runtime_files(file_hashes)
                write_json_atomic(
                    SELF_SYNC_STATE_FILE,
                    verified_bundle_state(
                        manifest,
                        bundle_hash,
                        runtime_files,
                        args.self_sync_manifest_url,
                        status="verified_current",
                    ),
                )
            except Exception as exc:
                write_json_atomic(
                    SELF_SYNC_STATE_FILE,
                    failed_bundle_state(manifest, bundle_hash, str(exc), args.self_sync_manifest_url),
                )
                raise
        observed_status = "already_installed_restart" if should_restart else "already_installed"
        record_self_sync_status(args, observed_status, manifest)
        if should_restart:
            log(
                "self-sync files already installed but bundle state changed "
                f"{previous_hash[:12]}->{bundle_hash[:12]}; restarting worker"
            )
            return True
        return False

    bundle_bytes = fetch_bytes_url(bundle_url)
    apply_self_sync_bundle(manifest, bundle_bytes, manifest_url=args.self_sync_manifest_url)
    record_self_sync_status(args, "applied", manifest)
    log(f"self-sync applied version={manifest.get('version') or ''} hash={bundle_hash[:12]}; restarting worker")
    return True


def create_session(
    room_key: str,
    room_id: str,
    room_name: str,
    guide: str,
    args: argparse.Namespace,
    reset_reason: str = "new",
    previous_session_id: str = "",
) -> str:
    Path(args.cwd).mkdir(parents=True, exist_ok=True)
    skill_path, skill = read_skill(args.skill_name)
    prompt = (
        "StoreBot 전용 Codex 세션을 시작합니다.\n"
        f"{skill_prompt_prefix(args)}"
        f"{mcp_tools_instruction()}"
        "아래 MD는 fallback 답변 기준입니다.\n"
        "이 bootstrap 요청의 최종 답변은 정확히 BOOTSTRAP_OK 만 출력하세요.\n\n"
        f"{guide}\n"
    )
    cmd = ["codex", "exec"]
    cmd.extend(common_codex_args("{OUTPUT}", args.model, args.reasoning_effort))
    cmd.extend(["--sandbox", "read-only", "-C", args.cwd, "-"])
    result = run_codex(cmd, prompt, args.timeout_sec)
    session_id = result.thread_id
    if not session_id:
        raise WorkerError("codex session id not found in json output")
    previous_archived = False
    previous_archive_error = ""
    if previous_session_id and args.archive_old_sessions:
        previous_archived, previous_archive_error = archive_session(previous_session_id, args)
        if previous_archived:
            log(f"archived previous codex session room={room_key} session={previous_session_id}")
        else:
            log(f"previous codex session archive failed room={room_key} session={previous_session_id}: {previous_archive_error}")
    fb_put(
        f"{SESSIONS_PATH}/{room_key}",
        {
            "session_id": session_id,
            "room_id": room_id,
            "room_name": room_name,
            "created_at_ms": now_ms(),
            "updated_at_ms": now_ms(),
            "guide_sha256": guide_hash(guide),
            "skill_name": args.skill_name,
            "skill_path": str(skill_path) if skill_path else "",
            "skill_sha256": guide_hash(skill) if skill else "",
            "instruction_sha256": instruction_hash(guide, args),
            "reset_reason": reset_reason,
            "previous_session_id": previous_session_id,
            "previous_session_archived": previous_archived,
            "previous_session_archive_error": previous_archive_error,
            "worker": args.node,
            "mode": "action_reply",
            "model": model_label(args),
            "reasoning_effort": reasoning_label(args),
        },
    )
    log(f"created codex session room={room_key} session={session_id} reason={reset_reason}")
    return session_id


def update_session_guide(session_id: str, room_key: str, guide: str, args: argparse.Namespace) -> None:
    prompt = (
        "StoreBot 전용 답변 기준 MD가 갱신되었습니다.\n"
        "아래 내용을 이 세션의 최신 기준으로 유지하세요.\n"
        "이 갱신 요청의 최종 답변은 정확히 GUIDE_UPDATED 만 출력하세요.\n\n"
        f"{guide}\n"
    )
    result = resume_session(session_id, prompt, args)
    if result.final.strip() != "GUIDE_UPDATED":
        log(f"guide update reply ignored room={room_key}: {result.final[:40]}")
    fb_patch(
        f"{SESSIONS_PATH}/{room_key}",
        {
            "guide_sha256": guide_hash(guide),
            "guide_updated_at_ms": now_ms(),
            "updated_at_ms": now_ms(),
        },
    )


def get_or_create_session(room_key: str, room_id: str, room_name: str, guide: str, args: argparse.Namespace) -> str:
    meta = fb_get(f"{SESSIONS_PATH}/{room_key}") or {}
    current_hash = instruction_hash(guide, args)
    if isinstance(meta, dict):
        session_id = meta.get("session_id")
        if isinstance(session_id, str) and session_id.strip():
            session_id = session_id.strip()
            stored_hash = meta.get("instruction_sha256") or meta.get("guide_sha256")
            if stored_hash != current_hash:
                log(f"instructions changed; restarting room session room={room_key}")
                return create_session(
                    room_key,
                    room_id,
                    room_name,
                    guide,
                    args,
                    reset_reason="instructions_changed",
                    previous_session_id=session_id,
                )
            return session_id
    return create_session(room_key, room_id, room_name, guide, args)


def build_previous_turn_context(req_id: str, item: dict[str, Any], room_id: str, room_name: str) -> str:
    event_kind = str(item.get("event_kind") or item.get("kind") or "chat").strip()
    if event_kind != "chat":
        return ""
    room_key = sanitize_key(room_id or room_name)
    parts = [
        "## 직전 turn bounded packet",
        "이 packet은 모든 chat turn에 제공되는 사실 맥락이다. 현재 입력의 의미나 교정 여부는 StoreBot skill/Codex가 판단하라.",
        "사용자 교정이 재사용 가능한 출력 기준, 포함 정보, 우선순위, 스킵 기준, 도구 선택 기준이면 guidance.add_rule로 다음 turn에도 반영하라.",
        "직원 별칭/오타 정정이면 guidance가 아니라 employee.add_alias로 저장하라.",
    ]
    receipt = item.get("previous_turn_receipt")
    context: dict[str, Any] = {}
    receipt_packet: dict[str, Any] = {}
    if isinstance(receipt, dict):
        receipt_actions = receipt.get("action_results")
        bounded_actions: list[dict[str, Any]] = []
        if isinstance(receipt_actions, list):
            for raw_action in receipt_actions[:3]:
                if not isinstance(raw_action, dict):
                    continue
                bounded_action: dict[str, Any] = {}
                if raw_action.get("ok") not in (None, ""):
                    bounded_action["ok"] = bool(raw_action.get("ok"))
                for key, limit in (("status", 40), ("type", 48), ("request_id", 64)):
                    if raw_action.get(key) not in (None, ""):
                        bounded_action[key] = str(raw_action.get(key))[:limit]
                bounded_actions.append(bounded_action)
        receipt_packet = {
            "request_id": str(receipt.get("request_id") or "")[:80],
            "previous_user_input": str(receipt.get("previous_user_input") or "")[:240],
            "actual_sent_reply": str(receipt.get("actual_sent_reply") or "")[:320],
            "action_results": bounded_actions,
            "outcome": clean_guidance_text(receipt.get("outcome"), 48),
            "recorded_at_ms": normalize_ts_ms(receipt.get("recorded_at_ms") or 0),
        }
        context = {
            "request_id": receipt_packet["request_id"],
            "user_message": receipt_packet["previous_user_input"],
            "reply": receipt_packet["actual_sent_reply"],
            "last_action_results": receipt_packet["action_results"],
            "outcome": receipt_packet["outcome"],
            "updated_at_ms": receipt_packet["recorded_at_ms"],
            "source": "android_previous_turn_receipt",
        }
    else:
        try:
            context = fb_get(f"{ROOM_CONTEXT_PATH}/{room_key}") or {}
        except Exception as exc:
            log(f"previous turn context load failed room={room_key}: {compact_error(str(exc), 160)}")
            context = {}
    if not isinstance(context, dict):
        context = {}
    previous_request_id = str(context.get("request_id") or "").strip()
    updated_at_ms = normalize_ts_ms(context.get("updated_at_ms") or 0)
    context_is_current_request = bool(previous_request_id and previous_request_id == req_id)
    context_is_stale = (
        context.get("source") != "android_previous_turn_receipt"
        and (updated_at_ms <= 0 or now_ms() - updated_at_ms > CORRECTION_CONTEXT_MAX_AGE_MS)
    )
    if not context or context_is_current_request or context_is_stale:
        parts.append("직전 turn: 사용 가능한 이전 응답 없음")
        return "\n".join(parts)
    previous_message = str(context.get("user_message") or "").strip()
    previous_reply = str(context.get("reply") or "").strip()
    action_results = context.get("last_action_results")
    item["_previous_turn_request_id"] = previous_request_id
    item["_previous_turn_reply_sha256"] = clean_reply_sha256(previous_reply) if previous_reply else ""
    parts.append(f"source: {str(context.get('source') or 'worker_room_context')}")
    if receipt_packet:
        parts.append("previous_turn_receipt(JSON):")
        parts.append(json.dumps(receipt_packet, ensure_ascii=False, separators=(",", ":")))
        return "\n".join(parts)
    parts.append(f"직전 request_id: {previous_request_id[:120]}")
    if context.get("outcome") not in (None, ""):
        parts.append(f"직전 outcome: {clean_guidance_text(context.get('outcome'), 120)}")
    if updated_at_ms > 0:
        parts.append(f"직전 recorded_at_ms: {updated_at_ms}")
    if previous_message:
        parts.append(f"직전 사용자 입력: {previous_message[:RESIDENT_CORRECTION_USER_MAX_CHARS]}")
    if previous_reply:
        parts.append(f"직전 StoreBot 답변: {previous_reply[:RESIDENT_CORRECTION_REPLY_MAX_CHARS]}")
    if action_results:
        parts.append("직전 작업 결과(JSON):")
        parts.append(json.dumps(action_results, ensure_ascii=False, separators=(",", ":"))[:RESIDENT_CORRECTION_ACTION_MAX_CHARS])
    return "\n".join(parts)


def save_room_turn_context(
    req_id: str,
    item: dict[str, Any],
    pipeline: dict[str, Any],
    answer: str,
    *,
    skipped: bool,
    publish_disabled: bool,
    args: argparse.Namespace,
    force: bool = False,
) -> None:
    if args.dry_run or skipped or (publish_disabled and not force):
        return
    message = str(item.get("message") or item.get("text") or "").strip()
    if not answer.strip():
        return
    room_id = str(pipeline.get("room_id") or item.get("room_id") or item.get("room") or "")
    room_name = str(pipeline.get("room_name") or item.get("room_name") or item.get("roomTitle") or "")
    room_key = str(pipeline.get("room_key") or sanitize_key(room_id or room_name))
    payload = {
        "updated_at_ms": now_ms(),
        "request_id": req_id,
        "session_id": str(pipeline.get("session_id") or ""),
        "room_id": room_id,
        "room_name": room_name,
        "event_kind": str(item.get("event_kind") or item.get("kind") or "chat"),
        "sender_hash": short_text_hash(str(item.get("sender") or item.get("from") or "")),
        "user_message": message[:1000],
        "reply": answer.strip()[:1400],
        "last_action_results": compact_payload(
            redact_payload_for_audit(pipeline.get("last_action_results") or []),
            2500,
        ),
        "action_count": int(pipeline.get("action_count") or 0),
        "worker": args.node,
    }
    try:
        fb_put(f"{ROOM_CONTEXT_PATH}/{room_key}", payload)
    except Exception as exc:
        log(f"room turn context save failed request={req_id}: {compact_error(str(exc), 160)}")


def resume_session(
    session_id: str,
    prompt: str,
    args: argparse.Namespace,
    item: dict[str, Any] | None = None,
) -> CodexResult:
    cmd = ["codex", "exec", "resume"]
    cmd.extend(common_codex_args("{OUTPUT}", args.model, args.reasoning_effort, mcp_context_for_request(item or {})))
    cmd.extend([session_id, "-"])
    image_paths, image_error = resolve_chat_vision_image_paths(item or {})
    if image_error:
        raise WorkerError(f"chat vision input rejected: {image_error}")
    return run_codex(cmd, prompt, args.timeout_sec, image_paths=image_paths)


def fast_router_timeout_sec() -> int:
    try:
        return max(10, int(os.environ.get("STOREBOT_CODEX_FAST_ROUTER_TIMEOUT_SEC", "540")))
    except (TypeError, ValueError):
        return 540


def fast_router_stateless_exec_enabled() -> bool:
    return env_bool("STOREBOT_CODEX_FAST_ROUTER_STATELESS_EXEC", False)


def fast_router_refresh_after_action_enabled() -> bool:
    return env_bool("STOREBOT_CODEX_FAST_ROUTER_REFRESH_AFTER_ACTION", False)


def direct_mcp_retry_enabled() -> bool:
    return False


def create_fast_router_session(
    router_guide: str,
    args: argparse.Namespace,
    reset_reason: str = "new",
    previous_session_id: str = "",
    *,
    room_identity: str = "default",
    session_generation: int = 0,
    expected_previous_session_id: str | None = None,
) -> str:
    if not router_guide.strip():
        raise WorkerError("fast router guide missing")
    Path(args.cwd).mkdir(parents=True, exist_ok=True)
    session_key = fast_router_session_key(args, room_identity)
    if expected_previous_session_id is not None:
        with _FAST_ROUTER_RUNTIME_LOCK:
            current_session_id = str(
                (_FAST_ROUTER_RUNTIME_SESSIONS.get(session_key) or {}).get("session_id") or ""
            )
        if current_session_id and current_session_id != expected_previous_session_id:
            return current_session_id
    if env_bool("STOREBOT_CODEX_RESIDENT_APP_SERVER", True):
        session_id = resident_codex_client().create_thread(
            args.model,
            args.reasoning_effort,
            args.cwd,
            "StoreBot resident fast router session.\n"
            "Use the following compact StoreBot router contract as the standing instruction for every turn.\n\n"
            f"{router_guide}\n",
            fast_router_timeout_sec(),
        )
    else:
        prompt = (
            "StoreBot resident fast router session bootstrap.\n"
            "Memorize the compact router contract below for this session.\n"
            "The final answer to this bootstrap must be exactly ROUTER_BOOTSTRAP_OK.\n\n"
            f"{router_guide}\n"
        )
        cmd = ["codex", "exec"]
        cmd.extend(common_codex_args("{OUTPUT}", args.model, args.reasoning_effort))
        cmd.extend(["--sandbox", "read-only", "-C", args.cwd, "-"])
        result = run_codex(cmd, prompt, fast_router_timeout_sec())
        session_id = result.thread_id
    if not session_id:
        raise WorkerError("fast router session id not found")
    created_at_ms = now_ms()
    evicted: list[dict[str, Any]] = []
    with _FAST_ROUTER_RUNTIME_LOCK:
        current = _FAST_ROUTER_RUNTIME_SESSIONS.get(session_key) or {}
        current_session_id = str(current.get("session_id") or "")
        if expected_previous_session_id is not None and current_session_id != expected_previous_session_id:
            if current_session_id:
                log(f"discarded stale fast router thread swap reason={reset_reason}")
                return current_session_id
        generation = session_generation or max(1, safe_int(current.get("session_generation")) + 1)
        runtime_meta: dict[str, Any] = {
            "session_id": session_id,
            "instruction_sha256": fast_router_instruction_hash(router_guide, args),
            "session_generation": generation,
            "rotation_reason": reset_reason,
            "turn_count": 0,
            "reported_total_tokens": 0,
            "prior_turn_duration_ms": 0,
            "created_at_ms": created_at_ms,
            "last_used_at_ms": created_at_ms,
        }
        if current_session_id and current_session_id != session_id:
            evicted.append(dict(current))
        _FAST_ROUTER_RUNTIME_SESSIONS[session_key] = runtime_meta
        evicted.extend(_evict_fast_router_runtime_lru_locked(protected_key=session_key))
    with _FAST_ROUTER_CLEANUP_LOCK:
        _FAST_ROUTER_CLEANUP_STATE["created_thread_count"] = safe_int(
            _FAST_ROUTER_CLEANUP_STATE.get("created_thread_count")
        ) + 1
    cleanup_fast_router_evictions(evicted)
    try:
        fb_put(
            f"{SESSIONS_PATH}/{session_key}",
            {
                "session_id": session_id,
                "session_key": session_key,
                "host": socket.gethostname() or "",
                "created_at_ms": created_at_ms,
                "updated_at_ms": created_at_ms,
                "router_guide_sha256": guide_hash(router_guide),
                "instruction_sha256": fast_router_instruction_hash(router_guide, args),
                "reset_reason": reset_reason,
                "previous_session_id": previous_session_id,
                "session_generation": generation,
                "worker": args.node,
                "mode": "fast_router_room_scoped",
                "model": model_label(args),
                "reasoning_effort": reasoning_label(args),
            },
        )
    except Exception as exc:
        log(f"fast router session metadata mirror failed: {compact_error(str(exc), 180)}")
    log(f"created fast router session generation={generation} reason={reset_reason}")
    return session_id


def get_or_create_fast_router_session(
    router_guide: str,
    args: argparse.Namespace,
    room_identity: str = "default",
) -> str:
    current_hash = fast_router_instruction_hash(router_guide, args)
    session_key = fast_router_session_key(args, room_identity)
    with fast_router_room_lock(session_key):
        with _FAST_ROUTER_RUNTIME_LOCK:
            runtime_meta = dict(_FAST_ROUTER_RUNTIME_SESSIONS.get(session_key) or {})
        runtime_session_id = str(runtime_meta.get("session_id") or "").strip()
        runtime_hash = str(runtime_meta.get("instruction_sha256") or "")
        if runtime_session_id and runtime_hash == current_hash:
            rotation_reason = fast_router_rotation_reason(runtime_meta)
            if not rotation_reason:
                with _FAST_ROUTER_RUNTIME_LOCK:
                    current = _FAST_ROUTER_RUNTIME_SESSIONS.get(session_key)
                    if current is not None and str(current.get("session_id") or "") == runtime_session_id:
                        current["last_used_at_ms"] = now_ms()
                return runtime_session_id
            return create_fast_router_session(
                router_guide,
                args,
                reset_reason=rotation_reason,
                previous_session_id=runtime_session_id,
                room_identity=room_identity,
                session_generation=safe_int(runtime_meta.get("session_generation"), 1) + 1,
                expected_previous_session_id=runtime_session_id,
            )
        if runtime_session_id:
            return create_fast_router_session(
                router_guide,
                args,
                reset_reason="instructions_changed",
                previous_session_id=runtime_session_id,
                room_identity=room_identity,
                session_generation=safe_int(runtime_meta.get("session_generation"), 1) + 1,
                expected_previous_session_id=runtime_session_id,
            )
        meta = fb_get(f"{SESSIONS_PATH}/{session_key}") or {}
        stored_session_id = str(meta.get("session_id") or "").strip() if isinstance(meta, dict) else ""
        stored_hash = str(meta.get("instruction_sha256") or meta.get("router_guide_sha256") or "") if isinstance(meta, dict) else ""
        if env_bool("STOREBOT_CODEX_RESIDENT_APP_SERVER", True):
            reason = "resident_runtime_start"
            if stored_session_id and stored_hash and stored_hash != current_hash:
                reason = "instructions_changed"
            return create_fast_router_session(
                router_guide,
                args,
                reset_reason=reason,
                previous_session_id=stored_session_id,
                room_identity=room_identity,
                session_generation=safe_int(meta.get("session_generation"), 0) + 1 if isinstance(meta, dict) else 1,
                expected_previous_session_id="",
            )
        if isinstance(meta, dict):
            session_id = str(meta.get("session_id") or "").strip()
            if session_id:
                if stored_hash == current_hash:
                    return session_id
                log("fast router instructions changed; restarting router session")
                return create_fast_router_session(
                    router_guide,
                    args,
                    reset_reason="instructions_changed",
                    previous_session_id=session_id,
                    room_identity=room_identity,
                )
        return create_fast_router_session(router_guide, args, room_identity=room_identity)


def should_refresh_fast_router_after_pipeline(pipeline: dict[str, Any]) -> bool:
    if not fast_router_refresh_after_action_enabled():
        return False
    if int(pipeline.get("action_count") or 0) > 0:
        return True
    answer = str(pipeline.get("answer") or "")
    return len(answer) > 1200


def start_fast_router_refresh(
    router_guide: str,
    args: argparse.Namespace,
    previous_session_id: str,
    reason: str,
    room_identity: str = "default",
) -> None:
    if not env_bool("STOREBOT_CODEX_RESIDENT_APP_SERVER", True):
        return
    session_key = fast_router_session_key(args, room_identity)
    with _FAST_ROUTER_REFRESH_LOCK:
        if session_key in _FAST_ROUTER_REFRESH_IN_PROGRESS:
            return
        _FAST_ROUTER_REFRESH_IN_PROGRESS.add(session_key)

    def runner() -> None:
        try:
            with fast_router_room_lock(session_key):
                with _FAST_ROUTER_RUNTIME_LOCK:
                    meta = dict(_FAST_ROUTER_RUNTIME_SESSIONS.get(session_key) or {})
                if str(meta.get("session_id") or "") != previous_session_id:
                    return
                create_fast_router_session(
                    router_guide,
                    args,
                    reset_reason=reason,
                    previous_session_id=previous_session_id,
                    room_identity=room_identity,
                    session_generation=safe_int(meta.get("session_generation"), 1) + 1,
                    expected_previous_session_id=previous_session_id,
                )
                log(f"fast router session refreshed reason={reason}")
        except Exception as exc:
            log(f"fast router session refresh failed reason={reason}: {compact_error(str(exc), 250)}")
        finally:
            with _FAST_ROUTER_REFRESH_LOCK:
                _FAST_ROUTER_REFRESH_IN_PROGRESS.discard(session_key)

    threading.Thread(target=runner, daemon=True, name="fast-router-refresh").start()


def resume_fast_router_session(
    session_id: str,
    prompt: str,
    args: argparse.Namespace,
    item: dict[str, Any] | None = None,
) -> CodexResult:
    cmd = ["codex", "exec", "resume"]
    cmd.extend(common_codex_args("{OUTPUT}", args.model, args.reasoning_effort, mcp_context_for_request(item or {})))
    cmd.extend([session_id, "-"])
    return run_codex(cmd, prompt, fast_router_timeout_sec())


def run_fast_router_stateless_prompt(
    prompt_body: str,
    router_guide: str,
    args: argparse.Namespace,
    item: dict[str, Any] | None = None,
) -> CodexResult:
    prompt = (
        "StoreBot fast router stateless turn.\n"
        "Use the compact router contract below for this one request only. "
        "Do not output bootstrap text or explanations.\n\n"
        "## Fast Router Contract\n"
        f"{router_guide}\n\n"
        f"{prompt_body}\n"
    )
    cmd = ["codex", "exec"]
    cmd.extend(common_codex_args("{OUTPUT}", args.model, args.reasoning_effort, mcp_context_for_request(item or {})))
    cmd.extend(["--sandbox", "read-only", "-C", args.cwd, "-"])
    return run_codex(cmd, prompt, fast_router_timeout_sec())


def build_turn_prompt(item: dict[str, Any], room_id: str, room_name: str) -> str:
    sender = str(item.get("sender") or item.get("from") or "unknown")
    message = str(item.get("message") or item.get("text") or "").strip()
    event_kind = str(item.get("event_kind") or item.get("kind") or "chat").strip()
    ts = item.get("ts") or item.get("created_at_ms") or item.get("createdAt")
    ts_ms = normalize_ts_ms(ts)
    parts = [
        f"[카톡방: {room_name or room_id} / room_id: {room_id} / "
        f"보낸사람: {sender} / 시간: {kst_text(ts_ms)} / 이벤트: {event_kind}]",
        message,
    ]
    payload = item.get("payload") or item.get("order_payload") or item.get("capture")
    if isinstance(payload, dict):
        parts.append("이벤트 데이터(JSON):")
        parts.append(json.dumps(payload, ensure_ascii=False, separators=(",", ":"))[:RESIDENT_PROMPT_PAYLOAD_MAX_CHARS])
    if is_chat_image_event(item):
        parts.append(
            "## 채팅창 이미지 증거\n"
            "이 turn에는 카카오에서 파일을 자동 다운로드한 원본이 아니라, 해당 방을 열어 채팅 영역만 임시 캡처한 localImage가 첨부되어 있다. "
            "가장 최근에 사용자가 올린 사진과 그 주변 대화를 함께 보고 업무상 의미와 지금 줄 수 있는 도움을 판단하라. "
            "프로필 사진, UI 버튼, 오래된 근무표 카드처럼 대상이 아닌 화면 요소는 배제하라. "
            "이미지가 불명확해도 안전한 읽기/조회/맥락 설명은 제공하고, 금융·주문 확정·영업 영향 쓰기는 증거가 부족하면 실행하지 마라."
        )
    if request_action_dry_run_required(item):
        parts.append(
            "HynixOps test-safe 요청입니다. 카카오 직접 조작/전송과 근무표/출근/알람/가이드 쓰기 작업은 금지입니다.\n"
            "worker request context는 dry_run_enforced=true, publish_disabled=true, side_effects_disabled=true로 강제됩니다. "
            "조회/요약은 가능하지만, StoreBot MCP 쓰기 도구를 직접 호출하지 마세요. "
            "`STOREBOT_ACTIONS` fallback을 써야 한다면 모든 쓰기성 action에는 반드시 dry_run:true를 넣으세요."
        )
    previous_turn_context = str(item.get("_previous_turn_context") or "").strip()
    if previous_turn_context:
        parts.append(previous_turn_context)
    parts.append(context_sensitive_turn_hint())
    recent_room_context = str(item.get("_recent_room_context") or "").strip()
    if not recent_room_context:
        recent_room_context = build_recent_room_context(room_id, room_name)
    if recent_room_context:
        parts.append(recent_room_context)
    if event_kind and event_kind != "chat":
        parts.append(
            "이 입력은 사용자 채팅이 아니라 StoreBot 앱이 발화 시점에 수집한 시스템 이벤트입니다.\n"
            "앱은 카톡 문구를 만들지 않았고, 최종 발송 문구는 반드시 Codex가 이벤트 데이터 기준으로 생성해야 합니다.\n"
            "데이터가 부족하거나 최신 조회가 필요하면 StoreBot MCP 도구를 직접 호출하고, 보낼 가치가 없으면 SKIP만 출력하세요.\n"
            "MCP 도구가 보이지 않을 때만 STOREBOT_ACTIONS fallback을 출력하세요."
        )
    parts.append(
        "위 입력에 대해 StoreBot Kakao reply 기준으로 카카오톡에 보낼 최종 답변만 출력하세요.\n"
        f"{mcp_tools_instruction()}"
        "답변할 필요가 없으면 SKIP만 출력하세요.\n"
        "근무표 DB 수정/조회, Firebase 조회, 날씨/뉴스/스포츠/웹 검색이 필요하면 StoreBot MCP 도구를 직접 호출한 뒤 최종답변을 출력하세요.\n"
        "운영메뉴얼 조회/검색/질문은 canonical entries/read-model 기반 `storebot_ops_manual_search` 또는 fallback `ops_manual.search`만 쓰고, 카카오 전용 복사본을 만들지 마세요.\n"
        "운영정보, 레시피 기준, 반복 지시, 정정, 규칙성 있는 내용이 운영메뉴얼에 남길 가치가 있으면 카카오 답변과 별개로 "
        "`STOREBOT_OUTPUT` JSON에 `ops_manual_collect`를 넣어 운영메뉴얼 후보 큐에 남길 수 있습니다. "
        "답변도 필요하면 category `kakao_reply`와 message를 함께 쓰고, 답변이 필요 없으면 `log_only` 또는 `report`로 두세요. "
        "원본 entries에 직접 쓰지 말고 검토 가능한 요약 후보로만 남기세요.\n"
        "MCP 도구가 보이지 않거나 tool call이 불안정하면 최종답변 대신 `STOREBOT_ACTIONS` 한 줄과 JSON 객체를 출력하세요."
    )
    return "\n".join(part for part in parts if part)


def build_fast_router_turn_prompt_with_telemetry(
    item: dict[str, Any],
    room_id: str,
    room_name: str,
) -> tuple[str, dict[str, Any]]:
    sender = str(item.get("sender") or item.get("from") or "unknown")
    message = str(item.get("message") or item.get("text") or "").strip()
    event_kind = str(item.get("event_kind") or item.get("kind") or "chat").strip()
    ts = item.get("ts") or item.get("created_at_ms") or item.get("createdAt")
    ts_ms = normalize_ts_ms(ts)
    components: list[tuple[str, str]] = [
        (
            "envelope",
            "\n".join(
                [
                    "## Kakao input",
                    f"room={room_name or room_id}",
                    f"room_id={room_id}",
                    f"sender={sender}",
                    f"time_kst={kst_text(ts_ms)}",
                    f"event_kind={event_kind}",
                ]
            ),
        ),
        ("message", f"message={message}"),
    ]
    payload = item.get("payload") or item.get("order_payload") or item.get("capture")
    if isinstance(payload, dict):
        components.append(
            (
                "payload",
                "payload_json=" + json.dumps(payload, ensure_ascii=False, separators=(",", ":"))[:FAST_ROUTER_PAYLOAD_MAX_CHARS],
            )
        )
    if request_action_dry_run_required(item):
        components.append(
            (
                "safety",
                "hynixops_test_safe=true; do not publish/send Kakao directly; do not call write MCP tools; "
                "request_context dry_run_enforced=true publish_disabled=true side_effects_disabled=true; "
                "fallback STOREBOT_ACTIONS write actions must include dry_run:true.",
            )
        )
    previous_turn_context = str(item.get("_previous_turn_context") or "").strip()
    if previous_turn_context:
        components.append(("previous_turn_context", previous_turn_context[:FAST_ROUTER_CONTEXT_MAX_CHARS]))
    components.append(("context_hint", context_sensitive_turn_hint()))
    recent_room_context = str(item.get("_recent_room_context") or "").strip()
    if not recent_room_context:
        recent_room_context = build_recent_room_context(room_id, room_name)
    if recent_room_context:
        components.append(("recent_room_context", recent_room_context[:ROOM_AGENT_CONTEXT_MAX_CHARS]))
    components.append(
        (
            "output_contract",
            "Apply the Fast Router Contract from this session. Output only SKIP, ROUTE_FULL, final short Kakao text, "
            "STOREBOT_ACTIONS plus one JSON object, or STOREBOT_OUTPUT plus one JSON object. "
            "Ops manual lookup must use canonical entries/read-model through ops_manual.search; do not create a Kakao-only copy. "
            "If the chat contains reusable operational info, recipe standards, repeated instructions, corrections, or rules, "
            "STOREBOT_OUTPUT may include ops_manual_collect to enqueue a review candidate. Do not explain.",
        )
    )
    prompt = "\n".join(text for _name, text in components if text)
    component_chars = {name: len(text) for name, text in components if text}
    return prompt, {
        "fast_router_prompt_total_chars": len(prompt),
        "fast_router_prompt_component_chars": component_chars,
    }


def build_fast_router_turn_prompt(item: dict[str, Any], room_id: str, room_name: str) -> str:
    prompt, _telemetry = build_fast_router_turn_prompt_with_telemetry(item, room_id, room_name)
    return prompt


def run_stateless_turn(item: dict[str, Any], room_id: str, room_name: str, guide: str, args: argparse.Namespace) -> CodexResult:
    prompt = (
        "StoreBot 전용 답변을 1회 처리합니다.\n"
        "이 요청은 기존 운영방 세션을 resume하지 않는 1회 처리입니다.\n"
        f"{skill_prompt_prefix(args)}"
        "스킬 또는 fallback MD와 입력을 기준으로 카카오톡 최종 답변만 출력하세요.\n\n"
        f"{guide}\n\n"
        "## 입력\n"
        f"{build_turn_prompt(item, room_id, room_name)}\n"
    )
    cmd = ["codex", "exec"]
    cmd.extend(common_codex_args("{OUTPUT}", args.model, args.reasoning_effort, mcp_context_for_request(item)))
    cmd.extend(["--sandbox", "read-only", "-C", args.cwd, "-"])
    image_paths, image_error = resolve_chat_vision_image_paths(item)
    if image_error:
        raise WorkerError(f"chat vision input rejected: {image_error}")
    return run_codex(cmd, prompt, args.timeout_sec, image_paths=image_paths)


def run_stateless_prompt(
    prompt_body: str,
    guide: str,
    args: argparse.Namespace,
    item: dict[str, Any] | None = None,
) -> CodexResult:
    prompt = (
        "StoreBot 전용 답변을 1회 처리합니다.\n"
        f"{skill_prompt_prefix(args)}"
        "스킬 또는 fallback MD와 입력을 기준으로 카카오톡 최종 답변만 출력하세요.\n\n"
        f"{guide}\n\n"
        f"{prompt_body}\n"
    )
    cmd = ["codex", "exec"]
    cmd.extend(common_codex_args("{OUTPUT}", args.model, args.reasoning_effort, mcp_context_for_request(item or {})))
    cmd.extend(["--sandbox", "read-only", "-C", args.cwd, "-"])
    image_paths, image_error = resolve_chat_vision_image_paths(item or {})
    if image_error:
        raise WorkerError(f"chat vision input rejected: {image_error}")
    return run_codex(cmd, prompt, args.timeout_sec, image_paths=image_paths)


def build_action_result_prompt(
    item: dict[str, Any],
    room_id: str,
    room_name: str,
    action_request: dict[str, Any],
    action_results: list[dict[str, Any]],
) -> str:
    return (
        "방금 요청에서 필요한 외부 동작을 worker가 실행했습니다.\n"
        "아래 실행 결과만 확정 사실로 보고 카카오톡에 보낼 최종 답변만 출력하세요.\n"
        "실행 결과에 ok:false가 하나라도 있으면 절대 반영 완료/수정 완료/등록 완료처럼 성공으로 답하지 말고, 실패 이유나 다시 확인할 항목만 짧게 말하세요.\n"
        "추가 외부 동작이 꼭 필요하면 다시 STOREBOT_ACTIONS JSON만 출력하세요.\n\n"
        "## 원래 입력\n"
        f"{build_turn_prompt(item, room_id, room_name)}\n\n"
        "## 실행 요청(JSON)\n"
        f"{json.dumps(action_request, ensure_ascii=False, separators=(',', ':'))[:4000]}\n\n"
        "## 실행 결과(JSON)\n"
        f"{json.dumps(action_results, ensure_ascii=False, separators=(',', ':'))[:6000]}\n"
    )


def build_direct_mcp_retry_prompt(
    item: dict[str, Any],
    room_id: str,
    room_name: str,
    action_request: dict[str, Any],
) -> str:
    return (
        "방금 응답은 `STOREBOT_ACTIONS` fallback 형식이었습니다.\n"
        "현재 이 세션에는 StoreBot MCP 도구가 활성화되어 있으므로, worker fallback 실행 전에 "
        "지금 같은 의도를 StoreBot MCP 도구 호출로 직접 처리해야 합니다.\n"
        "이번 응답에서는 `STOREBOT_ACTIONS`를 다시 출력하지 마세요. 필요한 StoreBot MCP 도구를 직접 호출한 뒤 "
        "카카오톡에 보낼 최종 답변만 출력하세요.\n\n"
        "## 원래 입력\n"
        f"{build_turn_prompt(item, room_id, room_name)}\n\n"
        "## 방금 fallback으로 출력한 작업(JSON)\n"
        f"{json.dumps(action_request, ensure_ascii=False, separators=(',', ':'))[:4000]}\n"
    )


def android_metadata_value(item: dict[str, Any], key: str) -> Any:
    if key in item:
        return item.get(key)
    payload = item.get("payload")
    if isinstance(payload, dict) and key in payload:
        return payload.get(key)
    return None


def android_freshness_domains(item: dict[str, Any]) -> list[str]:
    raw = android_metadata_value(item, "android_freshness_domains")
    if isinstance(raw, list):
        values = raw
    elif isinstance(raw, str):
        values = re.split(r"[,/\s]+", raw)
    else:
        values = []
    domains: list[str] = []
    for value in values:
        text = str(value or "").strip()
        if text:
            domains.append(text)
    return domains


def fresh_tool_required_reason(item: dict[str, Any]) -> str:
    if not truthy(android_metadata_value(item, "android_freshness_required")):
        return ""
    domains = android_freshness_domains(item)
    received_at_ms = safe_int(android_metadata_value(item, "android_received_at_ms"), 0)
    package_name = str(android_metadata_value(item, "android_package_name") or "").strip()
    owner = str(android_metadata_value(item, "android_hot_path_owner") or "").strip()
    parts = ["Android metadata requested fresh tool result"]
    if domains:
        parts.append(f"domains={','.join(domains)}")
    if received_at_ms > 0:
        parts.append(f"received_at_ms={received_at_ms}")
    if package_name:
        parts.append(f"package={package_name}")
    if owner:
        parts.append(f"owner={owner}")
    return "; ".join(parts)


def fresh_tool_result_exists(direct_tool_ok_count: int, action_results: list[dict[str, Any]]) -> bool:
    if direct_tool_ok_count > 0:
        return True
    for result in action_results:
        if isinstance(result, dict) and result.get("ok") is True:
            return True
    return False


def build_fresh_tool_retry_prompt(
    item: dict[str, Any],
    room_id: str,
    room_name: str,
    reason: str,
    previous_answer: str,
) -> str:
    return (
        "방금 답변은 StoreBot 도구 조회 없이 생성됐습니다.\n"
        f"Android 입력 metadata가 `{reason}`로 표시했으므로 최신 도구 결과 없이 답하면 안 됩니다.\n"
        "지금 StoreBot MCP 도구를 직접 호출해 최신 사실을 확인한 뒤 카카오톡에 보낼 최종 답변만 출력하세요.\n"
        "`STOREBOT_ACTIONS`는 MCP 도구가 정말 보이지 않을 때만 쓰세요.\n\n"
        "## 원래 입력\n"
        f"{build_turn_prompt(item, room_id, room_name)}\n\n"
        "## 도구 없이 만든 직전 답변\n"
        f"{previous_answer[:2000]}\n"
    )


def normalize_ts_ms(value: Any) -> int:
    try:
        numeric = int(float(value))
    except (TypeError, ValueError):
        return now_ms()
    if numeric < 10_000_000_000:
        return numeric * 1000
    return numeric


def request_queue_base_path(item: dict[str, Any] | None = None) -> str:
    if isinstance(item, dict):
        path = str(item.get("_request_queue_path") or "").strip().rstrip("/")
        if path.startswith("/"):
            return path
    return REQUESTS_PATH


def request_record_path(req_id: str, item: dict[str, Any] | None = None) -> str:
    return f"{request_queue_base_path(item)}/{req_id}"


def is_confirmed_schedule_queue_item(item: dict[str, Any] | None) -> bool:
    if not isinstance(item, dict):
        return False
    return str(item.get("_request_queue_kind") or "").strip().lower() == CONFIRMED_SCHEDULE_WRITE_REQUEST_TYPE


def pending_queue_sort_ts(item: dict[str, Any]) -> int:
    return normalize_ts_ms(
        item.get("ts")
        or item.get("created_at_ms")
        or item.get("queued_at_ms")
        or item.get("confirmed_at_ms")
        or item.get("started_at_ms")
        or 0
    )


def _append_pending_from_queue(
    pending: list[tuple[str, dict[str, Any]]],
    queue_path: str,
    queue_kind: str,
    *,
    require_message: bool,
    reclaim_ms: int,
    reclaim_inflight_ms: int,
    current_ms: int,
    explicit_only: bool = False,
) -> None:
    raw = fb_get(queue_path) or {}
    if not isinstance(raw, dict):
        return
    for key, item in raw.items():
        if not isinstance(item, dict):
            continue
        if explicit_only:
            explicit_field_name, explicit_actions = explicit_local_direct_action_list(item)
            if not explicit_field_name or not explicit_actions:
                continue
        status = str(item.get("status") or "").lower()
        if require_message:
            message = str(item.get("message") or item.get("text") or "").strip()
            if not message:
                continue
            if (
                item.get("local_direct") is True
                or item.get("local_direct_inflight") is True
                or str(item.get("ingress_status") or "").lower() == "local_direct_inflight"
            ):
                if request_no_send_contract_probe(item):
                    pass
                else:
                    # StoreBotTermux local-direct owns the live reply. Firebase rows here
                    # are mirrors/audit state and must never be re-polled into pending
                    # queue, otherwise accessibility screen scans can loop as replies.
                    continue
        if not status:
            status = "pending"
        prepared = dict(item)
        prepared.setdefault("request_id", str(item.get("request_id") or key))
        prepared["_request_queue_path"] = queue_path
        prepared["_request_queue_kind"] = queue_kind
        if status == "running" and reclaim_ms > 0:
            started_ms = normalize_ts_ms(item.get("started_at_ms") or item.get("created_at_ms") or item.get("ts"))
            if current_ms - started_ms > reclaim_ms:
                prepared["_reclaimed_running"] = True
                prepared["_previous_started_at_ms"] = started_ms
                pending.append((str(key), prepared))
                continue
        if status == "local_direct_inflight" and reclaim_inflight_ms > 0:
            created_ms = normalize_ts_ms(item.get("updated_at_ms") or item.get("created_at_ms") or item.get("ts_ms") or item.get("ts"))
            if current_ms - created_ms > reclaim_inflight_ms:
                prepared["_reclaimed_inflight"] = True
                prepared["_previous_inflight_at_ms"] = created_ms
                prepared["status"] = "pending"
                prepared["local_direct_fallback"] = True
                prepared["fallback_reason"] = "local_direct_inflight_stale_reclaimed"
                pending.append((str(key), prepared))
                continue
        if status != "pending":
            continue
        pending.append((str(key), prepared))


def explicit_pending_priority(item: dict[str, Any]) -> int:
    explicit_field_name, explicit_actions = explicit_local_direct_action_list(item)
    if explicit_field_name and explicit_actions:
        return 0
    return 1


def load_pending(
    limit: int,
    reclaim_running_sec: float = 0,
    reclaim_inflight_sec: float = 0,
) -> list[tuple[str, dict[str, Any]]]:
    pending: list[tuple[str, dict[str, Any]]] = []
    reclaim_ms = max(0, int(float(reclaim_running_sec or 0) * 1000))
    reclaim_inflight_ms = max(0, int(float(reclaim_inflight_sec or 0) * 1000))
    current_ms = now_ms()
    _append_pending_from_queue(
        pending,
        REQUESTS_PATH,
        "storebot_codex_request",
        require_message=True,
        reclaim_ms=reclaim_ms,
        reclaim_inflight_ms=reclaim_inflight_ms,
        current_ms=current_ms,
    )
    _append_pending_from_queue(
        pending,
        CONFIRMED_SCHEDULE_WRITE_REQUEST_QUEUE_PATH,
        CONFIRMED_SCHEDULE_WRITE_REQUEST_TYPE,
        require_message=False,
        reclaim_ms=reclaim_ms,
        reclaim_inflight_ms=0,
        current_ms=current_ms,
    )
    pending.sort(key=lambda pair: (explicit_pending_priority(pair[1]), pending_queue_sort_ts(pair[1]), pair[0]))
    return pending[:limit]


def load_explicit_pending(
    limit: int,
    reclaim_running_sec: float = 0,
    reclaim_inflight_sec: float = 0,
) -> list[tuple[str, dict[str, Any]]]:
    pending: list[tuple[str, dict[str, Any]]] = []
    reclaim_ms = max(0, int(float(reclaim_running_sec or 0) * 1000))
    reclaim_inflight_ms = max(0, int(float(reclaim_inflight_sec or 0) * 1000))
    current_ms = now_ms()
    _append_pending_from_queue(
        pending,
        EXPLICIT_ACTION_REQUESTS_PATH,
        "storebot_explicit_action_request",
        require_message=False,
        reclaim_ms=reclaim_ms,
        reclaim_inflight_ms=reclaim_inflight_ms,
        current_ms=current_ms,
        explicit_only=True,
    )
    pending.sort(key=lambda pair: (pending_queue_sort_ts(pair[1]), pair[0]))
    return pending[:limit]


def publish_outbound_message(
    message: str,
    *,
    source: str = "storebot_codex_worker",
    request_id: str = "",
    alert_id: str = "",
    room_id: str = "",
    room_name: str = "",
    sender: str = "",
    image_request: dict[str, Any] | None = None,
    image_required: bool = False,
    image_send_policy: str = "",
    broadcast_meta: dict[str, Any] | None = None,
    queue_key: str = "",
) -> str:
    if isinstance(image_request, dict) and str(image_request.get("type") or "") == "schedule_briefing":
        validation = validate_schedule_image_request(image_request)
        if validation.get("complete") is not True:
            missing = ",".join(str(section) for section in validation.get("missing_sections") or [])
            raise WorkerError(f"blocked incomplete schedule image_request before pending publish: {missing}")
    normalized_broadcast_meta = normalize_work_schedule_broadcast_ack_meta(broadcast_meta)
    key = sanitize_key(queue_key, "codex_outbound") if queue_key else f"codex_{now_ms()}_{secrets.token_hex(3)}"
    payload = {
        "message": message,
        "sent": False,
        "ts": int(time.time()),
        "source": source,
        "request_id": request_id,
        "alert_id": alert_id,
        "room_id": room_id,
        "room_name": room_name,
        "sender": sender,
    }
    if normalized_broadcast_meta:
        payload["broadcast_meta"] = dict(normalized_broadcast_meta)
    if isinstance(image_request, dict) and image_request:
        outbound_image_request = dict(image_request)
        if normalized_broadcast_meta:
            outbound_image_request.setdefault("broadcast_meta", dict(normalized_broadcast_meta))
            nested_payload = outbound_image_request.get("payload")
            if isinstance(nested_payload, dict) and not isinstance(nested_payload.get("broadcast_meta"), dict):
                outbound_image_request["payload"] = {**nested_payload, "broadcast_meta": dict(normalized_broadcast_meta)}
        payload["image_request"] = outbound_image_request
        payload["image_required"] = bool(image_required or image_request.get("required") is True)
        payload["image_send_policy"] = image_send_policy or str(image_request.get("send_policy") or "image_first")
        payload["image_fallback_policy"] = str(image_request.get("fallback_policy") or "")
    fb_put(f"{OUTBOUND_PATH}/{key}", payload)
    return key


def publish_reply(
    req_id: str,
    item: dict[str, Any],
    answer: str,
    image_request: dict[str, Any] | None = None,
    *,
    queue_key: str = "",
) -> str:
    broadcast_meta = work_schedule_broadcast_ack_meta_from_item(item, image_request=image_request)
    return publish_outbound_message(
        answer,
        source="storebot_codex_worker",
        request_id=req_id,
        room_id=str(item.get("room_id") or item.get("room") or ""),
        room_name=str(item.get("room_name") or ""),
        sender=str(item.get("sender") or item.get("from") or ""),
        image_request=image_request,
        image_required=bool(image_request),
        image_send_policy=str(image_request.get("send_policy") or "image_first") if isinstance(image_request, dict) else "",
        broadcast_meta=broadcast_meta,
        queue_key=queue_key,
    )


def _first_openclaw_outbound_text(value: Any, depth: int = 0) -> str:
    if depth > 4 or value is None:
        return ""
    if isinstance(value, str):
        return value.strip()
    if isinstance(value, list):
        parts = [_first_openclaw_outbound_text(item, depth + 1) for item in value]
        return "\n\n".join(part for part in parts if part).strip()
    if not isinstance(value, dict):
        return ""

    for key in ("message", "text", "reply", "answer", "final"):
        text = _first_openclaw_outbound_text(value.get(key), depth + 1)
        if text:
            return text
    text = _openclaw_text_from_content(value.get("assistantTexts"))
    if text:
        return text
    text = _openclaw_text_from_content(value.get("content"))
    if text:
        return text
    for key in ("payload", "data", "presentation", "body"):
        text = _first_openclaw_outbound_text(value.get(key), depth + 1)
        if text:
            return text
    return ""


def process_openclaw_outbound(req_id: str, item: dict[str, Any], args: argparse.Namespace) -> dict[str, Any]:
    def contains_backplane_contract(value: Any) -> bool:
        stack: list[tuple[Any, int]] = [(value, 0)]
        visited_nodes = 0
        while stack:
            current, depth = stack.pop()
            visited_nodes += 1
            if visited_nodes > 256 or depth > 24:
                return True
            if isinstance(current, list):
                stack.extend((entry, depth + 1) for entry in current if isinstance(entry, (dict, list)))
                continue
            if not isinstance(current, dict):
                continue
            schema = str(current.get("schema") or "").strip().lower()
            source = str(current.get("source") or "").strip().lower()
            if schema.startswith("storebot.telegram_"):
                return True
            if source.startswith("storebot_telegram_") or source in {"telegram_backplane", "storebot.telegram_backplane"}:
                return True
            if {"telegram_backplane", "source_projection", "recovery_decision", "backplane_envelope"} & set(current):
                return True
            stack.extend((entry, depth + 1) for entry in current.values() if isinstance(entry, (dict, list)))
        return False

    if contains_backplane_contract(item):
        raise WorkerError("telegram backplane contract is not an OpenClaw outbound payload")
    text = _first_openclaw_outbound_text(item)
    if not text:
        raise WorkerError("empty openclaw outbound text")

    room_id = str(item.get("room_id") or item.get("room") or item.get("target") or "storebot_group")
    room_name = str(item.get("room_name") or item.get("roomTitle") or item.get("roomName") or "운영방")
    sender = str(item.get("sender") or item.get("from") or item.get("source") or "openclaw")
    skipped = text == "SKIP"
    publish_disabled = bool(args.no_publish or item.get("no_publish") is True or item.get("dry_run") is True)
    outbound_key = ""
    if not skipped and not publish_disabled:
        outbound_key = publish_outbound_message(
            text,
            source="openclaw_outbound",
            request_id=req_id,
            room_id=room_id,
            room_name=room_name,
            sender=sender,
        )
    return {
        "ok": True,
        "request_id": req_id,
        "queued": bool(outbound_key),
        "outbound_key": outbound_key,
        "skipped": skipped,
        "publish_disabled": publish_disabled,
        "room_id": room_id,
        "room_name": room_name,
        "chars": len(text),
        "source": "openclaw_outbound",
    }


def temp_alert_due_ms(item: dict[str, Any]) -> int:
    if item.get("alert_at_ms"):
        return normalize_ts_ms(item.get("alert_at_ms"))
    dt = parse_kst_datetime(item.get("alert_at"))
    return int(dt.timestamp() * 1000) if dt else 0


def process_due_temp_alerts(args: argparse.Namespace) -> int:
    raw = fb_get(TEMP_ALERTS_PATH) or {}
    if not isinstance(raw, dict):
        return 0
    now = now_ms()
    fired_count = 0
    for alert_id, item in raw.items():
        if not isinstance(item, dict) or str(alert_id) == "latest":
            continue
        status = str(item.get("status") or "pending")
        if item.get("cancelled") is True or status == "cancelled" or item.get("fired") is True or status == "fired":
            continue
        due_ms = temp_alert_due_ms(item)
        if due_ms <= 0:
            continue
        firing_at = normalize_ts_ms(item.get("firing_at_ms") or 0)
        stale_firing = status == "firing" and now - firing_at > 2 * 60 * 1000
        if due_ms > now and not stale_firing:
            continue
        message = clean_alert_message(item.get("message"), 500)
        if not message:
            if not args.dry_run:
                fb_patch(
                    f"{TEMP_ALERTS_PATH}/{sanitize_key(str(alert_id))}",
                    {"status": "error", "error": "empty alert message", "error_at_ms": now},
                )
            continue
        if args.dry_run:
            log(f"dry-run due temp alert id={alert_id} alert_at={item.get('alert_at') or due_ms}")
            fired_count += 1
            continue
        alert_path = f"{TEMP_ALERTS_PATH}/{sanitize_key(str(alert_id))}"
        try:
            fb_patch(alert_path, {"status": "firing", "firing_at_ms": now, "worker": args.node})
            outbound_key = publish_outbound_message(
                message,
                source="storebot_codex_temp_alert",
                alert_id=str(alert_id),
                room_id=str(item.get("room_id") or "storebot_group"),
                room_name=str(item.get("room_name") or "BBQ하이닉스점 10"),
                sender=str(item.get("created_by") or "codex"),
            )
            fb_patch(
                alert_path,
                {
                    "status": "fired",
                    "fired": True,
                    "fired_at_ms": now_ms(),
                    "outbound_key": outbound_key,
                    "error": "",
                },
            )
            fired_count += 1
            log(f"temp alert fired id={alert_id} outbound={outbound_key}")
        except Exception as exc:
            error = compact_error(str(exc), 250)
            try:
                fb_patch(alert_path, {"status": "error", "error": error, "error_at_ms": now_ms(), "worker": args.node})
            except Exception:
                pass
            log(f"temp alert fire failed id={alert_id}: {error}")
    return fired_count


def schedule_timer_room(args: argparse.Namespace) -> tuple[str, str]:
    room_id = str(getattr(args, "schedule_timer_room_id", "") or os.environ.get("STOREBOT_SCHEDULE_ROOM_ID") or "storebot_group").strip()
    room_name = str(getattr(args, "schedule_timer_room_name", "") or os.environ.get("STOREBOT_SCHEDULE_ROOM_NAME") or "BBQ하이닉스점 10").strip()
    return room_id or "storebot_group", room_name or "BBQ하이닉스점 10"


def schedule_timer_date_time_ms(date_text: str, time_text: Any) -> int:
    try:
        clean_time = validate_time_text(time_text)
        hour_text, minute_text = clean_time.split(":", 1)
        date_obj = datetime.strptime(date_text, "%Y-%m-%d")
    except Exception:
        return 0
    dt = date_obj.replace(hour=int(hour_text), minute=int(minute_text), second=0, microsecond=0, tzinfo=KST)
    return int(dt.timestamp() * 1000)


def schedule_timer_due(now_ms_value: int, due_ms: int, catchup_minutes: int) -> bool:
    if due_ms <= 0 or due_ms > now_ms_value:
        return False
    return now_ms_value - due_ms <= max(0, catchup_minutes) * 60 * 1000


def schedule_timer_marker_path(date_text: str, event_kind: str, target_key: str) -> str:
    return (
        f"{SCHEDULE_TIMER_PATH}/fired/{sanitize_key(date_text, 'date')}/"
        f"{sanitize_key(event_kind, 'event')}/{sanitize_key(target_key, 'target')}"
    )


def schedule_timer_request_id(event_kind: str, date_text: str, target_key: str) -> str:
    return sanitize_key(f"sched_{event_kind}_{date_text}_{target_key}", "schedule_timer")


def schedule_timer_seen(req_id: str, marker_path: str) -> bool:
    marker = fb_get(marker_path)
    if marker not in (None, False, "", {}):
        return True
    existing = fb_get(f"{REQUESTS_PATH}/{req_id}")
    if isinstance(existing, dict):
        return True
    return False


def enqueue_schedule_timer_request(
    req_id: str,
    marker_path: str,
    payload: dict[str, Any],
    args: argparse.Namespace,
) -> bool:
    if args.dry_run:
        log(f"dry-run schedule timer request={req_id} event={payload.get('event_kind')} message={payload.get('message')}")
        return True
    if schedule_timer_seen(req_id, marker_path):
        return False
    fb_put(f"{REQUESTS_PATH}/{req_id}", payload)
    fired_at = now_ms()
    fb_put(
        marker_path,
        {
            "request_id": req_id,
            "event_kind": payload.get("event_kind") or "",
            "fired_at_ms": fired_at,
            "due_at_ms": payload.get("due_at_ms") or 0,
            "source": "storebot_codex_schedule_timer",
        },
    )
    fb_put(
        SCHEDULE_TIMER_LATEST_PATH,
        {
            "request_id": req_id,
            "event_kind": payload.get("event_kind") or "",
            "message": payload.get("message") or "",
            "fired_at_ms": fired_at,
            "due_at_ms": payload.get("due_at_ms") or 0,
        },
    )
    safe_record_stage(
        req_id,
        payload,
        args,
        "schedule_fire",
        "done",
        message="schedule timer enqueued request",
        evidence={"marker_path": marker_path, "due_at_ms": payload.get("due_at_ms") or 0},
    )
    log(f"schedule timer enqueued request={req_id} event={payload.get('event_kind')}")
    return True


def schedule_timer_attendance_recorded(date_text: str, emp_id: str) -> bool:
    raw = fb_get(workschedule_v2_path("attendance", date_text, sanitize_key(emp_id)))
    if not isinstance(raw, dict):
        return False
    return bool(str(raw.get("actual_start") or raw.get("in") or "").strip() or raw.get("check_in") is not None)


def schedule_timer_shift_payload(row: dict[str, Any]) -> dict[str, Any]:
    return {
        "employee_id": str(row.get("employee_id") or ""),
        "employee_name": str(row.get("employee") or row.get("employee_name") or row.get("employee_id") or ""),
        "start": str(row.get("start") or ""),
        "end": str(row.get("end") or ""),
        "role": str(row.get("role") or ""),
        "status": str(row.get("status") or ""),
        "source": str(row.get("source") or ""),
    }


def schedule_timer_days_payload(start_offset_days: int, day_count: int) -> list[dict[str, Any]]:
    dates = work_schedule_operational_dates(start_offset_days, day_count)
    query = execute_schedule_query({"type": "schedule.query", "dates": dates})
    days: list[dict[str, Any]] = []
    for day in query.get("days", []):
        if not isinstance(day, dict):
            continue
        date_text = str(day.get("date") or "").strip()
        if not date_text:
            continue
        try:
            date_obj = datetime.strptime(date_text, "%Y-%m-%d")
            dow = DOW_KR_BY_WEEKDAY[date_obj.weekday()]
        except Exception:
            dow = ""
        shifts: list[dict[str, Any]] = []
        dayoffs: list[str] = []
        for row in day.get("rows", []):
            if not isinstance(row, dict):
                continue
            if row.get("off") is True:
                off_name = str(row.get("employee") or row.get("employee_name") or row.get("employee_id") or "").strip()
                if off_name:
                    dayoffs.append(off_name)
                continue
            shifts.append(schedule_timer_shift_payload(row))
        days.append({"date": date_text, "dow": dow, "shifts": shifts, "dayoffs": dayoffs})
    attach_side_job_references(days)
    return days


def work_schedule_broadcast_state_path() -> str:
    return WORK_SCHEDULE_BROADCAST_STATE_PATH


def work_schedule_broadcast_hash_view(value: Any) -> Any:
    if isinstance(value, dict):
        normalized: dict[str, Any] = {}
        for key in sorted(value.keys(), key=lambda item: str(item)):
            text_key = str(key)
            if text_key in WORK_SCHEDULE_BROADCAST_HASH_IGNORED_KEYS:
                continue
            normalized[text_key] = work_schedule_broadcast_hash_view(value.get(key))
        return normalized
    if isinstance(value, list):
        return [work_schedule_broadcast_hash_view(item) for item in value]
    return value


def work_schedule_broadcast_source_snapshot() -> dict[str, Any]:
    return {
        key: fb_get(workschedule_v2_path(key)) or {}
        for key in WORK_SCHEDULE_BROADCAST_PLANNING_KEYS
    }


def work_schedule_broadcast_schedule_hash(source_snapshot: dict[str, Any]) -> str:
    # The broadcast image is derived only from canonical planning data.  Keep
    # read-models and operational metadata (calendar sync/outbox, overlays,
    # attendance and worker timestamps) out of its change detector even when a
    # caller passes a wider /workschedule_v2 snapshot.
    planning_snapshot = {
        key: source_snapshot.get(key) if source_snapshot.get(key) is not None else {}
        for key in WORK_SCHEDULE_BROADCAST_PLANNING_KEYS
    }
    normalized = work_schedule_broadcast_hash_view(planning_snapshot)
    raw = json.dumps(normalized, ensure_ascii=False, sort_keys=True, separators=(",", ":"), default=str)
    return hashlib.sha256(raw.encode("utf-8")).hexdigest()


def work_schedule_broadcast_publish_gate(args: argparse.Namespace) -> bool:
    return not bool(args.dry_run or getattr(args, "no_publish", False))


def work_schedule_broadcast_anchor_ms(state: dict[str, Any]) -> int:
    return max(
        normalize_ts_ms(state.get("last_sent_at_ms") or 0),
        normalize_ts_ms(state.get("last_outbound_queued_at_ms") or 0),
    )


def work_schedule_broadcast_state_changed(previous: dict[str, Any], current: dict[str, Any]) -> bool:
    def cleaned(value: dict[str, Any]) -> dict[str, Any]:
        return {key: payload for key, payload in value.items() if key != "updated_at_ms"}

    return cleaned(previous) != cleaned(current)


def write_work_schedule_broadcast_state(state: dict[str, Any], previous: dict[str, Any] | None = None) -> None:
    if previous is not None and not work_schedule_broadcast_state_changed(previous, state):
        return
    payload = dict(state)
    payload["updated_at_ms"] = now_ms()
    fb_put(work_schedule_broadcast_state_path(), payload)


def normalize_work_schedule_broadcast_ack_meta(value: Any) -> dict[str, Any]:
    if not isinstance(value, dict):
        return {}
    broadcast_id = str(value.get("broadcast_id") or "").strip()
    state_path = str(value.get("broadcast_state_path") or value.get("state_path") or "").strip()
    schedule_hash = str(value.get("schedule_hash") or "").strip()
    due_reason = str(value.get("due_reason") or value.get("broadcast_due_reason") or "").strip()
    source_path = str(value.get("source_path") or "").strip() or WORKSCHEDULE_V2_PATH
    interval_ms = safe_int(value.get("interval_ms") or 0) or WORK_SCHEDULE_BROADCAST_INTERVAL_MS
    if not any((broadcast_id, state_path, schedule_hash, due_reason)):
        return {}
    return {
        "broadcast_id": broadcast_id,
        "broadcast_state_path": state_path or work_schedule_broadcast_state_path(),
        "schedule_hash": schedule_hash,
        "due_reason": due_reason,
        "source_path": source_path,
        "interval_ms": interval_ms,
    }


def build_work_schedule_broadcast_ack_meta(
    broadcast_id: str,
    due_reason: str,
    schedule_hash: str,
) -> dict[str, Any]:
    return normalize_work_schedule_broadcast_ack_meta(
        {
            "broadcast_id": broadcast_id,
            "broadcast_state_path": work_schedule_broadcast_state_path(),
            "schedule_hash": schedule_hash,
            "due_reason": due_reason,
            "source_path": WORKSCHEDULE_V2_PATH,
            "interval_ms": WORK_SCHEDULE_BROADCAST_INTERVAL_MS,
        }
    )


def work_schedule_broadcast_ack_meta_from_item(
    item: dict[str, Any] | None,
    *,
    image_request: dict[str, Any] | None = None,
) -> dict[str, Any]:
    candidates: list[Any] = [item]
    if isinstance(item, dict):
        candidates.append(item.get("payload"))
        candidates.append(item.get("broadcast_meta"))
    if isinstance(image_request, dict):
        candidates.append(image_request)
        candidates.append(image_request.get("payload"))
        candidates.append(image_request.get("broadcast_meta"))
    for candidate in candidates:
        meta = normalize_work_schedule_broadcast_ack_meta(candidate)
        if meta:
            return meta
        if isinstance(candidate, dict):
            nested = normalize_work_schedule_broadcast_ack_meta(candidate.get("broadcast_meta"))
            if nested:
                return nested
    return {}


def build_work_schedule_broadcast_request(
    due_reason: str,
    schedule_hash: str,
    args: argparse.Namespace,
) -> tuple[str, dict[str, Any]]:
    created_ms = now_ms()
    reason_key = "edit" if due_reason == "edit_debounce_elapsed" else "periodic"
    label = "수정 반영" if reason_key == "edit" else "6시간 경과"
    room_id, room_name = schedule_timer_room(args)
    req_id = sanitize_key(
        f"sched_work_schedule_broadcast_auto_{reason_key}_{created_ms}_{schedule_hash[:12] or 'none'}",
        "schedule_broadcast",
    )
    broadcast_meta = build_work_schedule_broadcast_ack_meta(req_id, due_reason, schedule_hash)
    payload = {
        "status": "pending",
        "source": "storebot_codex_work_schedule_broadcast",
        "event_kind": WORK_SCHEDULE_BROADCAST_EVENT_KIND,
        "message": f"자동 근무표 알림: {label}",
        "room_id": room_id,
        "room_name": room_name,
        "sender": "근무표자동발송",
        "ts": created_ms,
        "created_at_ms": created_ms,
        "due_at_ms": created_ms,
        "requires_codex_output": True,
        "broadcast_meta": dict(broadcast_meta),
        "payload": {
            "schema": "storebot_codex_event_v1",
            "event_kind": WORK_SCHEDULE_BROADCAST_EVENT_KIND,
            "mode": "auto_broadcast",
            "broadcast_due_reason": due_reason,
            "schedule_hash": schedule_hash,
            "broadcast_meta": dict(broadcast_meta),
            "generated_at_ms": created_ms,
            "start_offset_days": 0,
            "day_count": WORK_SCHEDULE_BROADCAST_DAY_COUNT,
            "days": schedule_timer_days_payload(0, WORK_SCHEDULE_BROADCAST_DAY_COUNT),
            "requires_codex_output": True,
        },
    }
    return req_id, payload


def outbound_work_schedule_image_delivery_succeeded(outbound: dict[str, Any]) -> bool:
    image_required = bool(outbound.get("image_required") or isinstance(outbound.get("image_request"), dict))
    if not image_required:
        return True
    fallback_policy = str(outbound.get("image_fallback_policy") or "").strip()
    if fallback_policy == "explicit_text_mode":
        return True
    for key in (
        "image_sent",
        "image_send_succeeded",
        "image_delivery_ok",
        "attachment_sent",
        "attachment_send_succeeded",
    ):
        if outbound.get(key) is True:
            return True
    status_values = [
        outbound.get("image_send_status"),
        outbound.get("image_delivery_status"),
        outbound.get("attachment_status"),
        outbound.get("attachment_uri_status"),
    ]
    image_result = outbound.get("image_result")
    if isinstance(image_result, dict):
        status_values.extend(
            [
                image_result.get("status"),
                image_result.get("send_status"),
                image_result.get("attachment_status"),
            ]
        )
    for value in status_values:
        text = str(value or "").strip().casefold().replace("_", "-")
        if text in {"sent", "success", "succeeded", "delivered", "attached", "image-sent"}:
            return True
    return False


def work_schedule_broadcast_retry_status(status: Any) -> bool:
    return str(status or "").strip() in {
        "image_capture_or_generation_pending",
        "request_failed",
        "publish_skipped",
    }


def reconcile_work_schedule_broadcast_delivery(state: dict[str, Any], current_schedule_hash: str) -> dict[str, Any]:
    updated = dict(state)
    request_id = str(updated.get("inflight_request_id") or "").strip()
    if request_id:
        request = fb_get(f"{REQUESTS_PATH}/{request_id}")
        if isinstance(request, dict):
            request_status = str(request.get("status") or "").strip().lower()
            updated["inflight_request_status"] = request_status
            if request_status in WORK_SCHEDULE_BROADCAST_REQUEST_TERMINAL_STATUSES:
                outbound_key = str(request.get("outbound_key") or updated.get("inflight_outbound_key") or "").strip()
                if outbound_key:
                    updated["inflight_outbound_key"] = outbound_key
                    queued_at_ms = normalize_ts_ms(
                        request.get("finished_at_ms")
                        or request.get("updated_at_ms")
                        or request.get("started_at_ms")
                        or request.get("created_at_ms")
                        or request.get("ts")
                        or 0
                    )
                    if queued_at_ms > 0:
                        updated["last_outbound_queued_at_ms"] = max(
                            normalize_ts_ms(updated.get("last_outbound_queued_at_ms") or 0),
                            queued_at_ms,
                        )
                    updated["status"] = "queued"
                    updated["inflight_request_id"] = ""
                else:
                    updated["inflight_request_id"] = ""
                    updated["inflight_schedule_hash"] = ""
                    if request_status == "done":
                        if str(request.get("output_category") or "") == "schedule_image_pending":
                            output_payload = request.get("output_payload")
                            pending_reason = "image_capture_or_generation_pending"
                            if isinstance(output_payload, dict):
                                pending_reason = str(output_payload.get("reason") or pending_reason)
                            updated["status"] = "image_capture_or_generation_pending"
                            updated["last_error"] = compact_error(pending_reason, 250)
                            updated["last_image_pending_at_ms"] = normalize_ts_ms(
                                request.get("finished_at_ms")
                                or request.get("updated_at_ms")
                                or request.get("started_at_ms")
                                or request.get("created_at_ms")
                                or request.get("ts")
                                or now_ms()
                            )
                            updated["next_due_at_ms"] = updated["last_image_pending_at_ms"] + WORK_SCHEDULE_BROADCAST_BLOCKED_RETRY_MS
                        else:
                            updated["status"] = "publish_skipped"
                            updated["next_due_at_ms"] = now_ms() + WORK_SCHEDULE_BROADCAST_BLOCKED_RETRY_MS
                    else:
                        updated["status"] = "request_failed"
                        updated["last_error"] = compact_error(
                            request.get("error") or f"request_{request_status}",
                            250,
                        )
                        updated["next_due_at_ms"] = now_ms() + WORK_SCHEDULE_BROADCAST_BLOCKED_RETRY_MS
            else:
                updated["status"] = "request_inflight"
        else:
            updated["inflight_request_status"] = ""
    outbound_key = str(updated.get("inflight_outbound_key") or "").strip()
    if outbound_key:
        outbound = fb_get(f"{OUTBOUND_PATH}/{outbound_key}")
        if isinstance(outbound, dict):
            queued_at_ms = normalize_ts_ms(outbound.get("created_at_ms") or outbound.get("queued_at_ms") or 0)
            if queued_at_ms <= 0:
                ts_sec = safe_int(outbound.get("ts"))
                queued_at_ms = ts_sec * 1000 if ts_sec > 0 else 0
            if queued_at_ms > 0:
                updated["last_outbound_queued_at_ms"] = max(
                    normalize_ts_ms(updated.get("last_outbound_queued_at_ms") or 0),
                    queued_at_ms,
                )
            if outbound.get("sent") is True:
                if not outbound_work_schedule_image_delivery_succeeded(outbound):
                    updated["status"] = "image_capture_or_generation_pending"
                    updated["last_error"] = "image_capture_or_generation_pending"
                    updated["last_image_pending_at_ms"] = now_ms()
                    updated["inflight_request_id"] = ""
                    updated["inflight_outbound_key"] = ""
                    updated["inflight_schedule_hash"] = ""
                    updated["due_reason"] = ""
                    updated["next_due_at_ms"] = now_ms() + WORK_SCHEDULE_BROADCAST_BLOCKED_RETRY_MS
                    return updated
                sent_ms = normalize_ts_ms(outbound.get("sent_at_ms") or queued_at_ms or 0)
                sent_hash = str(
                    updated.get("inflight_schedule_hash")
                    or updated.get("last_schedule_hash")
                    or current_schedule_hash
                    or ""
                ).strip()
                if sent_ms > 0:
                    updated["last_sent_at_ms"] = sent_ms
                if sent_hash:
                    updated["last_sent_schedule_hash"] = sent_hash
                updated["inflight_request_id"] = ""
                updated["inflight_outbound_key"] = ""
                updated["inflight_schedule_hash"] = ""
                updated["status"] = "sent"
                updated["due_reason"] = ""
                updated["last_error"] = ""
                anchor_ms = work_schedule_broadcast_anchor_ms(updated)
                updated["next_due_at_ms"] = anchor_ms + WORK_SCHEDULE_BROADCAST_INTERVAL_MS if anchor_ms > 0 else 0
            else:
                updated["status"] = "queued"
    return updated


def process_due_work_schedule_broadcast(args: argparse.Namespace) -> int:
    now_value = now_ms()
    current_state = fb_get(work_schedule_broadcast_state_path()) or {}
    if not isinstance(current_state, dict):
        current_state = {}
    source_snapshot = work_schedule_broadcast_source_snapshot()
    current_schedule_hash = work_schedule_broadcast_schedule_hash(source_snapshot)
    previous_schedule_hash = str(
        current_state.get("current_schedule_hash") or current_state.get("last_schedule_hash") or ""
    ).strip()
    previous_schema_version = safe_int(current_state.get("schema_version"))
    hash_contract_rebaseline = bool(
        current_state and previous_schema_version < WORK_SCHEDULE_BROADCAST_SCHEMA_VERSION
    )
    room_id, room_name = schedule_timer_room(args)
    publish_gate = work_schedule_broadcast_publish_gate(args)
    state: dict[str, Any] = {
        **current_state,
        "schema_version": WORK_SCHEDULE_BROADCAST_SCHEMA_VERSION,
        "source_path": WORKSCHEDULE_V2_PATH,
        "interval_ms": WORK_SCHEDULE_BROADCAST_INTERVAL_MS,
        "debounce_ms": WORK_SCHEDULE_BROADCAST_DEBOUNCE_MS,
        "current_schedule_hash": current_schedule_hash,
        "room_id": room_id,
        "room_name": room_name,
        "publish_gate": publish_gate,
        "dry_run": bool(args.dry_run),
        "worker": args.node,
    }
    state.setdefault("status", "idle")
    state.setdefault("last_schedule_hash", previous_schedule_hash or current_schedule_hash)
    state.setdefault("last_sent_schedule_hash", "")
    state.setdefault("last_sent_at_ms", 0)
    state.setdefault("last_outbound_queued_at_ms", 0)
    state.setdefault("last_edit_at_ms", 0)
    state.setdefault("pending_edit_debounce_until_ms", 0)
    state.setdefault("next_due_at_ms", 0)
    state.setdefault("due_reason", "")
    state.setdefault("inflight_request_id", "")
    state.setdefault("inflight_outbound_key", "")
    state.setdefault("inflight_schedule_hash", "")
    state.setdefault("last_error", "")
    if hash_contract_rebaseline:
        # Version 1 included /workschedule_v2/meta in the hash.  Adopt the
        # planning-only hash without treating the contract change itself as a
        # schedule edit.  Existing inflight/retry evidence remains intact.
        previous_schedule_hash = current_schedule_hash
        state["last_schedule_hash"] = current_schedule_hash
        state["hash_contract_migrated_from_version"] = previous_schema_version
        state["hash_contract_migrated_at_ms"] = now_value
        if str(state.get("status") or "") == "pending_edit_debounce":
            state["status"] = "idle"
            state["pending_edit_debounce_until_ms"] = 0
            state["due_reason"] = ""
    state = reconcile_work_schedule_broadcast_delivery(state, current_schedule_hash)

    if not current_state:
        state["status"] = "initialized"
        state["last_schedule_hash"] = current_schedule_hash
        state["next_due_at_ms"] = now_value + WORK_SCHEDULE_BROADCAST_INTERVAL_MS
        write_work_schedule_broadcast_state(state, {})
        return 0

    if current_schedule_hash and current_schedule_hash != previous_schedule_hash:
        state["last_schedule_hash"] = current_schedule_hash
        state["last_edit_at_ms"] = now_value
        state["pending_edit_debounce_until_ms"] = now_value + WORK_SCHEDULE_BROADCAST_DEBOUNCE_MS
        state["next_due_at_ms"] = state["pending_edit_debounce_until_ms"]
        state["status"] = "pending_edit_debounce"
        state["due_reason"] = ""
        state["last_error"] = ""

    inflight_active = bool(
        str(state.get("inflight_request_id") or "").strip() or str(state.get("inflight_outbound_key") or "").strip()
    )
    due_reason = ""
    pending_until_ms = normalize_ts_ms(state.get("pending_edit_debounce_until_ms") or 0)
    last_sent_hash = str(state.get("last_sent_schedule_hash") or "").strip()
    if (
        pending_until_ms > 0
        and now_value >= pending_until_ms
        and current_schedule_hash
        and current_schedule_hash != last_sent_hash
    ):
        due_reason = "edit_debounce_elapsed"
    retry_due_ms = normalize_ts_ms(state.get("next_due_at_ms") or 0)
    if (
        not due_reason
        and work_schedule_broadcast_retry_status(state.get("status"))
        and retry_due_ms > 0
        and now_value >= retry_due_ms
        and current_schedule_hash
        and current_schedule_hash != last_sent_hash
    ):
        due_reason = str(state.get("due_reason") or "image_retry_elapsed")
    if not due_reason:
        anchor_ms = work_schedule_broadcast_anchor_ms(state)
        if anchor_ms > 0 and now_value >= anchor_ms + WORK_SCHEDULE_BROADCAST_INTERVAL_MS:
            due_reason = "periodic_elapsed"
        elif anchor_ms <= 0 and normalize_ts_ms(state.get("next_due_at_ms") or 0) > 0 and now_value >= normalize_ts_ms(
            state.get("next_due_at_ms") or 0
        ):
            due_reason = "periodic_elapsed"

    if inflight_active:
        if not str(state.get("status") or "").strip():
            state["status"] = "queued"
        write_work_schedule_broadcast_state(state, current_state)
        return 0

    if not due_reason:
        if str(state.get("status") or "") == "pending_edit_debounce" and pending_until_ms > now_value:
            state["next_due_at_ms"] = pending_until_ms
        elif work_schedule_broadcast_retry_status(state.get("status")):
            state["next_due_at_ms"] = retry_due_ms or (now_value + WORK_SCHEDULE_BROADCAST_BLOCKED_RETRY_MS)
        elif str(state.get("status") or "") not in {"queued", "request_inflight", "sent"}:
            anchor_ms = work_schedule_broadcast_anchor_ms(state)
            state["status"] = "idle"
            if anchor_ms > 0:
                state["next_due_at_ms"] = anchor_ms + WORK_SCHEDULE_BROADCAST_INTERVAL_MS
        write_work_schedule_broadcast_state(state, current_state)
        return 0

    state["due_reason"] = due_reason
    if not publish_gate:
        state["status"] = "blocked_publish_gate"
        state["next_due_at_ms"] = now_value + WORK_SCHEDULE_BROADCAST_BLOCKED_RETRY_MS
        write_work_schedule_broadcast_state(state, current_state)
        return 0

    req_id, payload = build_work_schedule_broadcast_request(due_reason, current_schedule_hash, args)
    fb_put(f"{REQUESTS_PATH}/{req_id}", payload)
    state["status"] = "queued_request"
    state["inflight_request_id"] = req_id
    state["inflight_outbound_key"] = ""
    state["inflight_schedule_hash"] = current_schedule_hash
    state["last_outbound_queued_at_ms"] = now_value
    state["next_due_at_ms"] = now_value + WORK_SCHEDULE_BROADCAST_INTERVAL_MS
    state["last_error"] = ""
    write_work_schedule_broadcast_state(state, current_state)
    safe_record_stage(
        req_id,
        payload,
        args,
        "schedule_fire",
        "done",
        message="work schedule broadcast enqueued request",
        evidence={"due_reason": due_reason, "schedule_hash": current_schedule_hash[:16]},
    )
    log(f"work schedule broadcast enqueued request={req_id} reason={due_reason}")
    return 1


def build_schedule_timer_attendance_request(
    date_text: str,
    rows: list[dict[str, Any]],
    event_kind: str,
    payload_kind: str,
    label: str,
    due_ms: int,
    start_ms: int,
    args: argparse.Namespace,
) -> tuple[str, str, dict[str, Any]]:
    room_id, room_name = schedule_timer_room(args)
    clean_rows = [row for row in rows if isinstance(row, dict)]
    first_row = clean_rows[0] if clean_rows else {}
    first_emp_id = str(first_row.get("employee_id") or "").strip()
    first_emp_name = str(first_row.get("employee") or first_row.get("employee_name") or first_emp_id).strip() or first_emp_id
    start_label = datetime.fromtimestamp(start_ms / 1000, KST).strftime("%H%M") if start_ms > 0 else "unknown"
    target_key = f"start_{start_label}_{payload_kind}"
    req_id = schedule_timer_request_id(event_kind, date_text, target_key)
    marker_path = schedule_timer_marker_path(date_text, event_kind, target_key)
    created_ms = now_ms()
    employee_items: list[dict[str, Any]] = []
    for row in clean_rows:
        emp_id = str(row.get("employee_id") or "").strip()
        emp_name = str(row.get("employee") or row.get("employee_name") or emp_id).strip() or emp_id
        employee_items.append(
            {
                "id": emp_id,
                "name": emp_name,
                "shift": {
                    "start": str(row.get("start") or ""),
                    "start_at_ms": start_ms,
                    "end": str(row.get("end") or ""),
                    "role": str(row.get("role") or ""),
                    "status": str(row.get("status") or ""),
                    "source": str(row.get("source") or ""),
                },
            }
        )
    attendance_payload: dict[str, Any] = {
        "schema": "storebot_codex_event_v1",
        "event_kind": payload_kind,
        "generated_at_ms": created_ms,
        "date": date_text,
        "employee": {"id": first_emp_id, "name": first_emp_name},
        "employees": employee_items,
        "employee_count": len(employee_items),
        "shift": {
            "start": str(first_row.get("start") or ""),
            "start_at_ms": start_ms,
            "end": str(first_row.get("end") or ""),
            "role": str(first_row.get("role") or ""),
            "status": str(first_row.get("status") or ""),
            "source": str(first_row.get("source") or ""),
        },
        "requires_codex_output": True,
    }
    if payload_kind != "attendance_pre":
        attendance_payload["checked_in"] = False
    names = [item["name"] for item in employee_items if str(item.get("name") or "").strip()]
    if len(names) == 1:
        message_label = f"{names[0]} {label}"
    else:
        display_start = str(first_row.get("start") or "").strip()
        if not display_start and start_ms > 0:
            display_start = datetime.fromtimestamp(start_ms / 1000, KST).strftime("%H:%M")
        message_label = f"{display_start} {label} {len(names)}명"
    return (
        req_id,
        marker_path,
        {
            "status": "pending",
            "source": "storebot_codex_schedule_timer",
            "event_kind": event_kind,
            "message": f"예약 근무알림: {message_label}",
            "room_id": room_id,
            "room_name": room_name,
            "sender": "근무알림예약",
            "ts": created_ms,
            "created_at_ms": created_ms,
            "due_at_ms": due_ms,
            "requires_codex_output": True,
            "payload": attendance_payload,
        },
    )


def process_due_schedule_timer_events(args: argparse.Namespace) -> int:
    global SCHEDULE_TIMER_LAST_CHECK_KEY
    if not getattr(args, "schedule_timer", True):
        return 0
    now_dt = datetime.now(KST)
    check_key = now_dt.strftime("%Y-%m-%dT%H:%M")
    if not args.dry_run and SCHEDULE_TIMER_LAST_CHECK_KEY == check_key:
        return 0
    SCHEDULE_TIMER_LAST_CHECK_KEY = check_key

    current_ms = int(now_dt.timestamp() * 1000)
    today_text = now_dt.strftime("%Y-%m-%d")
    fired_count = 0
    attendance_catchup = int(getattr(args, "schedule_timer_attendance_catchup_min", 10) or 10)

    query = execute_schedule_query({"type": "schedule.query", "dates": [today_text]})
    today_rows: list[dict[str, Any]] = []
    for day in query.get("days", []):
        if isinstance(day, dict) and str(day.get("date") or "") == today_text:
            today_rows = [row for row in day.get("rows", []) if isinstance(row, dict)]
            break
    checked_cache: dict[str, bool] = {}
    attendance_groups: dict[tuple[str, str, int, int, str], list[dict[str, Any]]] = {}
    for row in today_rows:
        if row.get("off") is True:
            continue
        emp_id = str(row.get("employee_id") or "").strip()
        if not emp_id:
            continue
        start_ms = schedule_timer_date_time_ms(today_text, row.get("start"))
        if start_ms <= 0:
            continue
        for event_kind, payload_kind, offset_minutes, label in SCHEDULE_ATTENDANCE_EVENTS:
            due_ms = start_ms - offset_minutes * 60 * 1000
            if not schedule_timer_due(current_ms, due_ms, attendance_catchup):
                continue
            if payload_kind != "attendance_pre":
                if emp_id not in checked_cache:
                    checked_cache[emp_id] = schedule_timer_attendance_recorded(today_text, emp_id)
                if checked_cache[emp_id]:
                    continue
            group_key = (event_kind, payload_kind, due_ms, start_ms, label)
            attendance_groups.setdefault(group_key, []).append(row)
    for (event_kind, payload_kind, due_ms, start_ms, label), rows in attendance_groups.items():
        if not rows:
            continue
        req_id, marker_path, payload = build_schedule_timer_attendance_request(
            today_text,
            rows,
            event_kind,
            payload_kind,
            label,
            due_ms,
            start_ms,
            args,
        )
        if enqueue_schedule_timer_request(req_id, marker_path, payload, args):
            fired_count += 1
    if fired_count:
        log(f"schedule timer fired count={fired_count}")
    return fired_count


CORRECTION_MARKERS = (
    "아니",
    "그게아니라",
    "그거말고",
    "다른",
    "틀렸",
    "틀림",
    "잘못",
    "수정",
    "다시",
    "재분석",
    "이게아니",
    "그게맞",
)


def safe_rate(numerator: int, denominator: int) -> float:
    if denominator <= 0:
        return 0.0
    return round(numerator / denominator, 4)


def percentile(values: list[int], pct: float) -> int:
    if not values:
        return 0
    ordered = sorted(values)
    index = min(len(ordered) - 1, max(0, int(round((len(ordered) - 1) * pct))))
    return int(ordered[index])


def increment_counter(counter: dict[str, int], key: Any, default: str = "unknown") -> None:
    text = str(key or default).strip() or default
    counter[text] = counter.get(text, 0) + 1


def correction_like(item: dict[str, Any]) -> bool:
    message = normalize_key_text(str(item.get("message") or item.get("text") or ""))
    if not message:
        return False
    return any(marker in message for marker in CORRECTION_MARKERS)


def sample_request(item_id: str, item: dict[str, Any], issue: str = "") -> dict[str, Any]:
    message = str(item.get("message") or item.get("text") or "")
    created_ms = normalize_ts_ms(item.get("created_at_ms") or item.get("ts") or item.get("started_at_ms"))
    finished_ms = normalize_ts_ms(item.get("finished_at_ms") or item.get("failed_at_ms") or 0)
    sample = {
        "request_id": item_id,
        "status": str(item.get("status") or "pending"),
        "issue": issue,
        "event_kind": str(item.get("event_kind") or "chat"),
        "source": str(item.get("source") or ""),
        "room_key": sanitize_key(str(item.get("room_id") or item.get("room_name") or ""), "room"),
        "message_hash": short_text_hash(message),
        "message_len": len(message),
        "message_preview": compact_message_preview(item, True),
        "created_kst": kst_text(created_ms),
        "age_min": max(0, int((now_ms() - created_ms) / 60000)),
        "model": str(item.get("model") or ""),
        "reasoning_effort": str(item.get("reasoning_effort") or ""),
        "error": compact_error(str(item.get("error") or item.get("learning_stamp_error") or ""), 180),
    }
    if finished_ms > 0 and finished_ms >= created_ms:
        sample["duration_ms"] = finished_ms - created_ms
    if item.get("local_direct_elapsed_ms"):
        sample["local_direct_elapsed_ms"] = safe_int(item.get("local_direct_elapsed_ms"))
    return sample


def count_rules(raw: Any) -> int:
    if not isinstance(raw, dict):
        return 0
    return sum(1 for value in raw.values() if isinstance(value, dict) and value.get("enabled") is not False)


def collect_improvement_snapshot(args: argparse.Namespace) -> dict[str, Any]:
    hours = max(1.0, min(float(args.improvement_report_hours or 24), 168.0))
    cutoff = now_ms() - int(hours * 60 * 60 * 1000)
    raw_requests = fb_get(REQUESTS_PATH) or {}
    if not isinstance(raw_requests, dict):
        raw_requests = {}

    status_counts: dict[str, int] = {}
    issue_counts: dict[str, int] = {}
    source_counts: dict[str, int] = {}
    event_counts: dict[str, int] = {}
    model_counts: dict[str, int] = {}
    learning_counts = {"written": 0, "missing": 0, "error": 0}
    local_direct = {
        "count": 0,
        "skipped": 0,
        "action_error": 0,
        "elapsed_avg_ms": 0,
        "elapsed_p95_ms": 0,
        "elapsed_max_ms": 0,
    }
    elapsed_values: list[int] = []
    recent_errors: list[dict[str, Any]] = []
    correction_samples: list[dict[str, Any]] = []
    slow_samples: list[dict[str, Any]] = []
    checked = 0
    hard_error_count = 0
    publish_missing_count = 0
    action_error_count = 0
    pending_or_running_count = 0
    correction_count = 0
    cli_candidates: list[dict[str, Any]] = []
    action_failure_samples_by_domain: dict[str, list[dict[str, Any]]] = {}
    bridge_protocol_samples: list[dict[str, Any]] = []

    for req_id, raw_item in raw_requests.items():
        if not isinstance(raw_item, dict):
            continue
        ts_ms = normalize_ts_ms(raw_item.get("created_at_ms") or raw_item.get("ts") or raw_item.get("started_at_ms"))
        if ts_ms < cutoff:
            continue
        checked += 1
        status = str(raw_item.get("status") or "pending").lower()
        increment_counter(status_counts, status)
        increment_counter(source_counts, raw_item.get("source") or "")
        increment_counter(event_counts, raw_item.get("event_kind") or "chat")
        increment_counter(model_counts, raw_item.get("model") or "")

        action_results = action_results_list(raw_item.get("last_action_results"))
        age_ms = now_ms() - normalize_ts_ms(raw_item.get("started_at_ms") or raw_item.get("created_at_ms") or ts_ms)
        issue = request_issue(raw_item, age_ms, action_results)
        if issue:
            increment_counter(issue_counts, issue)
        if status == "error" or issue in {"error", "stale_running"}:
            hard_error_count += 1
        if issue == "publish_missing":
            publish_missing_count += 1
        if issue == "action_error":
            action_error_count += 1
        if status in {"pending", "running"}:
            pending_or_running_count += 1

        stamp_status = str(raw_item.get("learning_stamp_status") or "")
        if stamp_status == "written":
            learning_counts["written"] += 1
        elif stamp_status == "error":
            learning_counts["error"] += 1
        else:
            learning_counts["missing"] += 1

        if raw_item.get("local_direct") is True:
            local_direct["count"] += 1
            if raw_item.get("reply_skipped") is True:
                local_direct["skipped"] += 1
            if safe_int(raw_item.get("action_error_count")) > 0:
                local_direct["action_error"] += 1
            elapsed = safe_int(raw_item.get("local_direct_elapsed_ms"))
            if elapsed > 0:
                elapsed_values.append(elapsed)
                if elapsed > 180_000:
                    slow_samples.append(sample_request(str(req_id), raw_item, "slow_local_direct"))

        if correction_like(raw_item):
            correction_count += 1
            correction_samples.append(sample_request(str(req_id), raw_item, "user_correction"))

        if issue or status == "error" or raw_item.get("learning_stamp_status") == "error":
            recent_errors.append(sample_request(str(req_id), raw_item, issue or status))
        candidate = request_cli_diagnostic_candidate(str(req_id), raw_item, issue, action_results, age_ms)
        if candidate:
            candidate_type = str(candidate.get("candidate_type") or "")
            if candidate_type == "action_tool_failure_repeated":
                for domain in candidate.get("action_domains") or []:
                    action_failure_samples_by_domain.setdefault(str(domain), []).append(candidate)
            elif candidate_type == "bridge_protocol_suppressed":
                bridge_protocol_samples.append(candidate)
            else:
                cli_candidates.append(candidate)

    elapsed_sum = sum(elapsed_values)
    if elapsed_values:
        local_direct["elapsed_avg_ms"] = int(elapsed_sum / len(elapsed_values))
        local_direct["elapsed_p95_ms"] = percentile(elapsed_values, 0.95)
        local_direct["elapsed_max_ms"] = max(elapsed_values)

    heartbeat = fb_get(HEARTBEAT_PATH) or {}
    if not isinstance(heartbeat, dict):
        heartbeat = {}
    self_sync = fb_get(SELF_SYNC_STATUS_PATH) or {}
    if not isinstance(self_sync, dict):
        self_sync = {}
    dynamic_latest = fb_get(DYNAMIC_GUIDANCE_LATEST_PATH) or {}
    if not isinstance(dynamic_latest, dict):
        dynamic_latest = {}
    dynamic_rules = fb_get(DYNAMIC_GUIDANCE_RULES_PATH) or {}

    for domain, samples in action_failure_samples_by_domain.items():
        if len(samples) < 2:
            continue
        cli_candidates.append(
            {
                "candidate_type": "action_tool_failure_repeated",
                "severity": "error",
                "domain": "storebot",
                "action_domain": domain,
                "evidence": {
                    "action_domain": domain,
                    "count": len(samples),
                    "samples": compact_payload(samples[:5], 4000),
                },
                "safe_scope": "Repeated StoreBot schedule/search/weather action failure diagnostics. Do not fabricate data or send Kakao messages.",
            }
        )
    if len(bridge_protocol_samples) >= 2:
        cli_candidates.append(
            {
                "candidate_type": "bridge_protocol_suppressed",
                "severity": "error",
                "domain": "storebot",
                "evidence": {
                    "count": len(bridge_protocol_samples),
                    "samples": compact_payload(bridge_protocol_samples[:5], 3000),
                },
                "safe_scope": "Repeated StoreBot output protocol suppression diagnostics. Do not send suppressed protocol text to Kakao.",
            }
        )

    quality_signal_count = correction_count + learning_counts["error"] + action_error_count + publish_missing_count
    snapshot = {
        "schema_version": 1,
        "app": args.improvement_report_app,
        "generated_at_ms": now_ms(),
        "generated_at_kst": kst_text(),
        "period_hours": hours,
        "review_routes": {
            "common_latest": f"{APP_IMPROVEMENT_REPORTS_PATH}/{sanitize_key(args.improvement_report_app)}/latest",
            "common_history": f"{APP_IMPROVEMENT_REPORTS_PATH}/{sanitize_key(args.improvement_report_app)}/history",
            "storebot_latest": IMPROVEMENT_REPORT_LATEST_PATH,
            "storebot_history": f"{IMPROVEMENT_REPORTS_PATH}/history",
        },
        "metrics": {
            "checked": checked,
            "status_counts": status_counts,
            "issue_counts": issue_counts,
            "source_counts": source_counts,
            "event_counts": event_counts,
            "model_counts": model_counts,
            "hard_error_count": hard_error_count,
            "hard_error_rate": safe_rate(hard_error_count, checked),
            "quality_signal_count": quality_signal_count,
            "quality_signal_rate": safe_rate(quality_signal_count, checked),
            "publish_missing_count": publish_missing_count,
            "action_error_count": action_error_count,
            "pending_or_running_count": pending_or_running_count,
            "correction_count": correction_count,
            "correction_rate": safe_rate(correction_count, checked),
            "learning_counts": learning_counts,
            "local_direct": local_direct,
        },
        "runtime": {
            "heartbeat": {
                "alive": heartbeat.get("alive"),
                "status": heartbeat.get("status"),
                "queue_size": heartbeat.get("queue_size"),
                "model": heartbeat.get("model"),
                "reasoning_effort": heartbeat.get("reasoning_effort"),
                "local_direct_enabled": heartbeat.get("local_direct_enabled"),
                "local_direct_listening": heartbeat.get("local_direct_listening"),
                "local_direct_host": heartbeat.get("local_direct_host"),
                "local_direct_port": heartbeat.get("local_direct_port"),
                "last_error": compact_error(str(heartbeat.get("last_error") or heartbeat.get("local_direct_last_error") or ""), 180),
                "bundle_version": heartbeat.get("bundle_version"),
                "bundle_sha256": heartbeat.get("bundle_sha256") or heartbeat.get("bundle_sha"),
                "bundle_status": heartbeat.get("bundle_status"),
            },
            "self_sync": {
                "status": self_sync.get("status"),
                "bundle_version": self_sync.get("bundle_version"),
                "bundle_sha256": self_sync.get("bundle_sha256") or self_sync.get("bundle_sha"),
                "error": compact_error(str(self_sync.get("error") or ""), 180),
                "ts": self_sync.get("ts"),
            },
            "dynamic_guidance": {
                "active_rule_count": count_rules(dynamic_rules),
                "latest": compact_payload(dynamic_latest, 1200),
            },
        },
        "samples": {
            "recent_errors": sorted(recent_errors, key=lambda item: item.get("age_min", 0))[:12],
            "corrections": sorted(correction_samples, key=lambda item: item.get("age_min", 0))[:12],
            "slow_local_direct": sorted(slow_samples, key=lambda item: int(item.get("local_direct_elapsed_ms") or 0), reverse=True)[:8],
        },
    }
    snapshot["cli_diagnostic_candidates"] = dedupe_cli_diagnostic_candidates(
        cli_candidates + runtime_cli_diagnostic_candidates(snapshot) + outbound_schedule_image_stale_candidates(hours)
    )[:12]
    return snapshot


def build_improvement_report_prompt(snapshot: dict[str, Any]) -> str:
    return (
        "너는 StoreBotTermux와 이후 DeliveryHelper/PosDelay에도 같은 방식으로 쓰일 앱 개선 분석기다.\n"
        "입력은 운영 메트릭, 오류, 사용자 교정, 학습 후보 신호다.\n"
        "목표는 현재 Codex 세션이 바로 검토하고 코딩할 수 있는 개선 보고서를 만드는 것이다.\n"
        "카톡 원문을 장황하게 반복하지 말고, 증거는 request_id/카운트/짧은 preview 중심으로만 써라.\n"
        "학습 개선 의도는 반드시 별도 항목으로 다뤄라: 알게 된 정보 후보, 사용자 패턴, 반복 니즈, 답변 선호, 룰 승격 후보를 분리해라.\n"
        "출력은 JSON 객체 하나만 허용한다. 마크다운 금지.\n"
        "필수 키: summary, health_level, error_rate_assessment, kill_stability, kakao_path, learning_improvements, code_improvement_candidates, next_codex_actions, needs_user_confirmation.\n"
        "health_level은 ok/watch/risk/critical 중 하나다. code_improvement_candidates와 next_codex_actions는 우선순위 P0/P1/P2를 포함한 배열로 써라.\n\n"
        "## 운영 스냅샷 JSON\n"
        f"{json.dumps(snapshot, ensure_ascii=False, separators=(',', ':'))[:30000]}\n"
    )


def analyze_improvement_snapshot(snapshot: dict[str, Any], args: argparse.Namespace) -> tuple[dict[str, Any] | None, str, dict[str, Any]]:
    model = str(args.improvement_report_model or DEFAULT_IMPROVEMENT_REPORT_MODEL).strip()
    effort = normalize_effort(args.improvement_report_reasoning_effort, DEFAULT_IMPROVEMENT_REPORT_REASONING_EFFORT)
    prompt = build_improvement_report_prompt(snapshot)
    cmd = ["codex", "exec"]
    cmd.extend(common_codex_args("{OUTPUT}", model, effort))
    cmd.extend(["--sandbox", "read-only", "-C", args.cwd, "-"])
    result = run_codex(cmd, prompt, int(args.improvement_report_timeout_sec))
    parsed = parse_json_object_text(result.final)
    metadata = {
        "model": model,
        "reasoning_effort": effort,
        "thread_id": result.thread_id or "",
        "tool_call_count": result.tool_call_count,
        "tool_ok_count": result.tool_ok_count,
        "tool_error_count": result.tool_error_count,
    }
    return parsed, result.final, metadata


def firebase_safe_payload(value: Any) -> Any:
    if isinstance(value, dict):
        safe: dict[str, Any] = {}
        for key, item in value.items():
            safe_key = sanitize_key(str(key), "key")
            safe[safe_key] = firebase_safe_payload(item)
        return safe
    if isinstance(value, list):
        return [firebase_safe_payload(item) for item in value]
    return value


def write_improvement_report(report: dict[str, Any], args: argparse.Namespace) -> None:
    app_key = sanitize_key(args.improvement_report_app)
    report_id = str(report.get("report_id") or f"report_{now_ms()}_{secrets.token_hex(3)}")
    day = stamp_day_key(report.get("generated_at_ms") if isinstance(report.get("generated_at_ms"), int) else None)
    report["report_id"] = report_id
    report["app_key"] = app_key
    firebase_report = firebase_safe_payload(report)
    fb_put(IMPROVEMENT_REPORT_LATEST_PATH, firebase_report)
    fb_put(f"{IMPROVEMENT_REPORTS_PATH}/history/{day}/{report_id}", firebase_report)
    fb_put(f"{APP_IMPROVEMENT_REPORTS_PATH}/{app_key}/latest", firebase_report)
    fb_put(f"{APP_IMPROVEMENT_REPORTS_PATH}/{app_key}/history/{day}/{report_id}", firebase_report)
    fb_put(f"{APP_IMPROVEMENT_REPORTS_PATH}/latest/{app_key}", firebase_report)


def improvement_report_daily_time_text(args: argparse.Namespace) -> str:
    return str(getattr(args, "improvement_report_time_kst", "") or "04:30").strip()


def parse_hhmm_time(text: str, default: str = "04:30") -> tuple[int, int]:
    candidate = str(text or default).strip()
    match = re.fullmatch(r"(\d{1,2}):?(\d{2})", candidate)
    if not match:
        candidate = default
        match = re.fullmatch(r"(\d{1,2}):?(\d{2})", candidate)
    if not match:
        return 4, 30
    hour = max(0, min(23, int(match.group(1))))
    minute = max(0, min(59, int(match.group(2))))
    return hour, minute


def seconds_until_kst_time(time_text: str, *, min_delay_sec: float = 60.0) -> float:
    hour, minute = parse_hhmm_time(time_text)
    now = datetime.now(KST)
    target = now.replace(hour=hour, minute=minute, second=0, microsecond=0)
    if target <= now + timedelta(seconds=max(0.0, min_delay_sec)):
        target += timedelta(days=1)
    return max(0.0, (target - now).total_seconds())


def latest_improvement_report_generated_ms(args: argparse.Namespace) -> int:
    app_key = sanitize_key(args.improvement_report_app)
    try:
        return normalize_ts_ms(fb_get(f"{APP_IMPROVEMENT_REPORTS_PATH}/{app_key}/latest/generated_at_ms"))
    except Exception as exc:
        log(f"improvement report latest read failed: {compact_error(str(exc), 200)}")
        return 0


def improvement_report_ran_today(args: argparse.Namespace) -> bool:
    generated_ms = latest_improvement_report_generated_ms(args)
    if generated_ms <= 0:
        return False
    generated_day = datetime.fromtimestamp(generated_ms / 1000, KST).strftime("%Y%m%d")
    today = datetime.now(KST).strftime("%Y%m%d")
    return generated_day == today


def improvement_report_low_load_ready(args: argparse.Namespace) -> tuple[bool, str]:
    try:
        if load_pending(1, args.reclaim_running_sec, args.reclaim_inflight_sec):
            return False, "pending_request"
    except Exception as exc:
        return False, f"pending_check_error:{compact_error(str(exc), 120)}"

    try:
        heartbeat = fb_get(HEARTBEAT_PATH) or {}
    except Exception as exc:
        return False, f"heartbeat_error:{compact_error(str(exc), 120)}"
    if not isinstance(heartbeat, dict):
        return False, "heartbeat_missing"

    queue_size = safe_int(heartbeat.get("queue_size"))
    if queue_size > 0:
        return False, f"queue_size_{queue_size}"
    status = str(heartbeat.get("status") or "").lower()
    if status and status != "idle":
        return False, f"status_{status}"
    if heartbeat.get("local_direct_listening") is not True:
        return False, "local_direct_not_listening"
    if heartbeat.get("fast_router_enabled") is False:
        return False, "fast_router_disabled"
    if heartbeat.get("resident_app_server_enabled") is True:
        if heartbeat.get("resident_app_server_active") is not True:
            return False, "resident_app_server_not_active"
        if heartbeat.get("resident_session_health_ok") is False:
            return False, "resident_health_not_ok"
    return True, "idle"


def run_improvement_report_when_quiet(args: argparse.Namespace) -> bool:
    if improvement_report_ran_today(args):
        log("improvement report daily skipped: already generated today")
        return False

    defer_sec = max(300.0, float(getattr(args, "improvement_report_defer_sec", 1800.0) or 1800.0))
    max_defer_sec = max(defer_sec, float(getattr(args, "improvement_report_max_defer_sec", 14400.0) or 14400.0))
    deadline = time.monotonic() + max_defer_sec
    while True:
        ready, reason = improvement_report_low_load_ready(args)
        if ready:
            run_improvement_report_once(args)
            return True
        if time.monotonic() + defer_sec > deadline:
            log(f"improvement report daily skipped: low-load window missed reason={reason}")
            return False
        log(f"improvement report daily deferred reason={reason} retry={int(defer_sec)}s")
        time.sleep(defer_sec)


def run_improvement_report_once(args: argparse.Namespace) -> dict[str, Any]:
    snapshot = collect_improvement_snapshot(args)
    generated_ms = now_ms()
    report: dict[str, Any] = {
        "schema_version": 1,
        "report_id": f"report_{generated_ms}_{secrets.token_hex(3)}",
        "app": args.improvement_report_app,
        "generated_at_ms": generated_ms,
        "generated_at_kst": kst_text(generated_ms),
        "period_hours": snapshot.get("period_hours"),
        "review_routes": snapshot.get("review_routes"),
        "snapshot": snapshot,
        "analysis_status": "pending",
    }
    try:
        analysis, analysis_text, model_meta = analyze_improvement_snapshot(snapshot, args)
        report["analysis_status"] = "done" if analysis is not None else "text_only"
        report["analysis"] = analysis if analysis is not None else {}
        report["analysis_text"] = "" if analysis is not None else analysis_text[:6000]
        report["analysis_model"] = model_meta
    except Exception as exc:
        report["analysis_status"] = "error"
        report["analysis_error"] = compact_error(str(exc), 600)
        report["analysis_model"] = {
            "model": str(args.improvement_report_model or DEFAULT_IMPROVEMENT_REPORT_MODEL),
            "reasoning_effort": str(args.improvement_report_reasoning_effort or DEFAULT_IMPROVEMENT_REPORT_REASONING_EFFORT),
        }
    if not args.dry_run:
        write_improvement_report(report, args)
    log(
        "improvement report "
        f"status={report['analysis_status']} app={args.improvement_report_app} "
        f"checked={snapshot.get('metrics', {}).get('checked')} route={snapshot.get('review_routes', {}).get('common_latest')}"
    )
    return report


def start_improvement_report_thread(args: argparse.Namespace) -> None:
    def worker() -> None:
        if getattr(args, "improvement_report_daily", True):
            while True:
                delay = seconds_until_kst_time(improvement_report_daily_time_text(args))
                log(
                    "improvement report daily scheduled "
                    f"time={improvement_report_daily_time_text(args)} delay={int(delay)}s"
                )
                time.sleep(delay)
                try:
                    run_improvement_report_when_quiet(args)
                except Exception as exc:
                    log(f"improvement report daily loop error: {compact_error(str(exc), 500)}")
                time.sleep(60)

        delay = max(0.0, float(args.improvement_report_initial_delay_sec or 0))
        if delay:
            time.sleep(delay)
        while True:
            try:
                run_improvement_report_once(args)
            except Exception as exc:
                log(f"improvement report loop error: {compact_error(str(exc), 500)}")
            time.sleep(max(300.0, float(args.improvement_report_interval_sec or 1800)))

    thread = threading.Thread(target=worker, daemon=True, name="storebot-improvement-report")
    thread.start()
    log(
        "storebot improvement report thread started "
        f"app={args.improvement_report_app} daily={getattr(args, 'improvement_report_daily', True)} "
        f"time={improvement_report_daily_time_text(args)} interval={args.improvement_report_interval_sec}s "
        f"model={args.improvement_report_model}/{args.improvement_report_reasoning_effort}"
    )


def stamp_day_key(ts_ms: int | None = None) -> str:
    return datetime.fromtimestamp((ts_ms or now_ms()) / 1000, KST).strftime("%Y%m%d")


def compact_keys(value: Any) -> list[str]:
    if not isinstance(value, dict):
        return []
    return sorted(str(key) for key in value.keys())[:30]


def stamp_decision(skipped: bool, outbound_key: str | None, action_count: int, error: str = "") -> str:
    if error:
        return "error"
    if action_count > 0 and skipped:
        return "action_then_skip"
    if action_count > 0 and outbound_key:
        return "action_then_reply"
    if action_count > 0:
        return "action_only"
    if skipped:
        return "skip"
    if outbound_key:
        return "reply"
    return "reply_no_publish"


def build_learning_stamp(
    req_id: str,
    item: dict[str, Any],
    args: argparse.Namespace,
    guide: str,
    *,
    decision: str,
    answer: str = "",
    session_id: str = "",
    outbound_key: str | None = None,
    skipped: bool = False,
    publish_disabled: bool = False,
    action_count: int = 0,
    action_ok_count: int = 0,
    action_error_count: int = 0,
    error: str = "",
) -> dict[str, Any]:
    message = str(item.get("message") or item.get("text") or "")
    payload = item.get("payload")
    room_id = str(item.get("room_id") or item.get("room") or "")
    room_name = str(item.get("room_name") or item.get("roomTitle") or "")
    sender = str(item.get("sender") or item.get("from") or "")
    stamp = {
        "stamp_version": 1,
        "request_id": req_id,
        "ts": now_ms(),
        "source": str(item.get("source") or ""),
        "event_kind": str(item.get("event_kind") or "chat"),
        "room_id": room_id,
        "room_name": room_name,
        "room_key": sanitize_key(room_id or room_name),
        "sender_hash": short_text_hash(sender),
        "is_owner": bool(item.get("is_owner")),
        "is_1on1": bool(item.get("is_1on1")),
        "message_hash": short_text_hash(message),
        "message_len": len(message),
        "payload_keys": compact_keys(payload),
        "decision": decision,
        "reply_skipped": skipped,
        "reply_len": len(answer),
        "reply_hash": short_text_hash(answer) if answer and not skipped else "",
        "outbound_key": outbound_key or "",
        "outbound_queued": bool(outbound_key),
        "publish_disabled": publish_disabled,
        "action_count": action_count,
        "action_ok_count": action_ok_count,
        "action_error_count": action_error_count,
        "session_id": session_id,
        "worker": args.node,
        "model": model_label(args),
        "reasoning_effort": reasoning_label(args),
        "model_override_reason": getattr(args, "model_override_reason", ""),
        "guide_sha256": guide_hash(guide),
        "instruction_sha256": instruction_hash(guide, args),
        "redacted": True,
        "error": compact_error(error, 250) if error else "",
    }
    apply_request_side_effect_safety(stamp, item)
    return stamp


def write_learning_stamp(req_id: str, stamp: dict[str, Any], args: argparse.Namespace) -> None:
    if args.dry_run:
        return
    day = stamp_day_key(stamp.get("ts"))
    key = sanitize_key(req_id, "request")
    stamp_path = f"{LEARNING_STAMPS_PATH}/{day}/{key}"
    fb_put(stamp_path, stamp)
    fb_put(LEARNING_STAMP_LATEST_PATH, stamp)
    mark_learning_stamp_status(req_id, args, "written", stamp_path=stamp_path)


def mark_learning_stamp_status(
    req_id: str,
    args: argparse.Namespace,
    status: str,
    *,
    stamp_path: str = "",
    error: str = "",
) -> None:
    if args.dry_run:
        return
    payload: dict[str, Any] = {
        "learning_stamp_status": status,
        "learning_stamp_at_ms": now_ms(),
    }
    if stamp_path:
        payload["learning_stamp_path"] = stamp_path
    if error:
        payload["learning_stamp_error"] = compact_error(error, 250)
    try:
        fb_patch(f"{REQUESTS_PATH}/{req_id}", payload)
    except Exception as exc:
        log(f"learning stamp status write failed request={req_id}: {compact_error(str(exc), 200)}")


def emit_storebot_ca_receipt(
    req_id: str,
    transition: str,
    status: str,
    args: argparse.Namespace,
    *,
    occurred_at_ms: int,
    duration_ms: int = 0,
    severity: str = "info",
    failure_code: str = "none",
    action_count: int = 0,
    action_ok_count: int = 0,
    action_error_count: int = 0,
) -> None:
    """Best-effort typed observability; failure never blocks the Kakao hot path."""

    if bool(getattr(args, "dry_run", False)) or not env_bool("STOREBOT_CA_PROJECTION_ENABLED", False) or env_bool("STOREBOT_CA_KILL_SWITCH", False):
        return
    node = str(getattr(args, "node", "") or "")
    if not node.startswith("subphone"):
        return
    try:
        try:
            import storebot_ca_log as ca_log
            from codex_ops_worker import firebase_conditional_put, firebase_get_with_etag
        except ModuleNotFoundError:  # pragma: no cover - repo package imports.
            from scripts import storebot_ca_log as ca_log
            from scripts.codex_ops_worker import firebase_conditional_put, firebase_get_with_etag
        repository = ca_log.FirebaseStoreBotCaRepository(
            read_with_etag=firebase_get_with_etag,
            conditional_put=firebase_conditional_put,
        )
        producer = ca_log.StoreBotCaLog(identity_key=ca_log.read_identity_key(), repository=repository)
        producer.produce(
            {
                "private_task_ref": str(req_id),
                "transition": transition,
                "status": status,
                "resource_id": ca_log.SERVERPHONE_RESOURCE,
                "occurred_at_ms": int(occurred_at_ms),
                "duration_ms": max(0, int(duration_ms)),
                "severity": severity,
                "failure_code": failure_code,
                "action_count": max(0, int(action_count)),
                "action_ok_count": max(0, int(action_ok_count)),
                "action_error_count": max(0, int(action_error_count)),
            }
        )
    except Exception as exc:
        log(f"StoreBot CA typed receipt skipped request={sanitize_key(req_id)} reason={type(exc).__name__}")


def mark_running(req_id: str, args: argparse.Namespace, item: dict[str, Any] | None = None) -> None:
    started_at_ms = now_ms()
    payload = {
        "status": "running",
        "worker": args.node,
        "model": model_label(args),
        "reasoning_effort": reasoning_label(args),
        "model_override_reason": getattr(args, "model_override_reason", ""),
        "started_at_ms": started_at_ms,
    }
    if isinstance(item, dict):
        apply_request_side_effect_safety(payload, item)
    fb_patch(
        request_record_path(req_id, item),
        payload,
    )
    emit_storebot_ca_receipt(
        req_id,
        "worker_started",
        "running",
        args,
        occurred_at_ms=started_at_ms,
    )


def mark_reclaimed_running(req_id: str, item: dict[str, Any], args: argparse.Namespace) -> None:
    if item.get("_reclaimed_running") is not True and item.get("_reclaimed_inflight") is not True:
        return
    previous_started_at_ms = normalize_ts_ms(
        item.get("_previous_started_at_ms")
        or item.get("_previous_inflight_at_ms")
        or item.get("started_at_ms")
        or item.get("updated_at_ms")
        or item.get("created_at_ms")
        or 0
    )
    fb_patch(
        request_record_path(req_id, item),
        {
            "reclaimed_running": bool(item.get("_reclaimed_running")),
            "reclaimed_inflight": bool(item.get("_reclaimed_inflight")),
            "reclaimed_at_ms": now_ms(),
            "previous_started_at_ms": previous_started_at_ms,
            "reclaimed_by": args.node,
            "local_direct_fallback": True,
            "fallback_reason": item.get("fallback_reason") or "stale_reclaimed",
        },
    )


def mark_done(
    req_id: str,
    answer: str,
    session_id: str,
    outbound_key: str | None,
    skipped: bool,
    publish_disabled: bool,
    args: argparse.Namespace,
    *,
    output_category: str = "",
    output_payload: dict[str, Any] | None = None,
    self_fix_request_id: str = "",
    route_metadata: dict[str, Any] | None = None,
    image_request: dict[str, Any] | None = None,
    image_required: bool = False,
    image_send_policy: str = "",
    image_request_suppressed_reason: str = "",
    image_request_suppressed_detail: str = "",
    image_request_dedupe_key: str = "",
    item: dict[str, Any] | None = None,
    clean_reply_block_reason: str = "",
    brain_metadata: dict[str, Any] | None = None,
) -> None:
    finished_at_ms = now_ms()
    payload: dict[str, Any] = {
        "status": "done",
        "finished_at_ms": finished_at_ms,
        "worker": args.node,
        "model": model_label(args),
        "reasoning_effort": reasoning_label(args),
        "model_override_reason": getattr(args, "model_override_reason", ""),
        "session_id": session_id,
        "reply_skipped": skipped,
        "outbound_key": outbound_key or "",
        "publish_disabled": publish_disabled,
        "output_category": output_category or ("skip" if skipped else "kakao_reply"),
        "self_fix_request_id": self_fix_request_id,
    }
    if isinstance(item, dict):
        apply_request_side_effect_safety(payload, item)
        payload.update(request_learning_suppression_context(args, item))
    apply_clean_reply_contract_metadata(
        payload,
        answer,
        item,
        skipped=skipped,
        output_category=str(payload.get("output_category") or ""),
        has_image_request=isinstance(image_request, dict) and bool(image_request),
        publish_disabled=publish_disabled,
        block_reason=clean_reply_block_reason,
    )
    if clean_reply_block_reason:
        payload["skip_reason"] = clean_reply_block_reason
    if output_payload:
        payload["output_payload"] = compact_payload(output_payload, 3000)
    if payload["output_category"] == "schedule_realtime_incomplete":
        payload["data_status"] = "schedule_realtime_incomplete"
        payload["processing_status"] = "schedule_realtime_incomplete"
        payload["schedule_realtime_incomplete"] = True
    if route_metadata:
        payload["route_metadata"] = compact_payload(route_metadata, 3000)
    if isinstance(brain_metadata, dict) and brain_metadata:
        payload.update(compact_payload(brain_metadata, 1200))
    if isinstance(image_request, dict) and image_request:
        payload["image_request"] = compact_payload(image_request, 20000)
        payload["image_required"] = bool(image_required or image_request.get("required") is True)
        payload["image_send_policy"] = image_send_policy or str(image_request.get("send_policy") or "image_first")
        payload["image_fallback_policy"] = str(image_request.get("fallback_policy") or "")
    if image_request_suppressed_reason:
        payload["image_request_suppressed"] = True
        payload["image_request_suppressed_reason"] = image_request_suppressed_reason
        if image_request_suppressed_detail:
            payload["image_request_suppressed_detail"] = image_request_suppressed_detail
        if image_request_dedupe_key:
            payload["image_request_dedupe_key"] = image_request_dedupe_key
    if args.redact_done:
        payload.update(
            {
                "message": None,
                "text": None,
                "reply": None,
                "reply_redacted": True,
                "message_redacted": True,
                "reply_len": len(answer),
            }
        )
    else:
        payload["reply"] = answer
    fb_patch(request_record_path(req_id, item), payload)
    started_at_ms = normalize_ts_ms((item or {}).get("started_at_ms") or (item or {}).get("created_at_ms") or 0)
    emit_storebot_ca_receipt(
        req_id,
        "result",
        "completed",
        args,
        occurred_at_ms=finished_at_ms,
        duration_ms=max(0, finished_at_ms - started_at_ms) if started_at_ms > 0 else 0,
    )


def mark_error(
    req_id: str,
    error: str,
    args: argparse.Namespace,
    item: dict[str, Any] | None = None,
    *,
    event_id: str = "",
    route_metadata: dict[str, Any] | None = None,
    ledger_ids: list[str] | None = None,
) -> None:
    failed_at_ms = now_ms()
    payload = {
        "status": "error",
        "worker": args.node,
        "model": model_label(args),
        "reasoning_effort": reasoning_label(args),
        "model_override_reason": getattr(args, "model_override_reason", ""),
        "failed_at_ms": failed_at_ms,
        "error": compact_error(error),
    }
    if isinstance(item, dict):
        apply_request_side_effect_safety(payload, item)
    fb_patch(
        request_record_path(req_id, item),
        payload,
    )
    started_at_ms = normalize_ts_ms((item or {}).get("started_at_ms") or (item or {}).get("created_at_ms") or 0)
    emit_storebot_ca_receipt(
        req_id,
        "error",
        "failed",
        args,
        occurred_at_ms=failed_at_ms,
        duration_ms=max(0, failed_at_ms - started_at_ms) if started_at_ms > 0 else 0,
        severity="error",
        failure_code="worker_error",
    )
    if isinstance(item, dict):
        try:
            resolved_event_id = event_id or str(item.get("_room_event_id") or "")
            if not resolved_event_id:
                resolved_event_id = append_room_event_journal(req_id, item, args, route_metadata=route_metadata)
            write_reconciliation_status(
                req_id,
                item,
                args,
                status="error",
                event_id=resolved_event_id,
                ledger_ids=ledger_ids or [],
                route_metadata=route_metadata or {},
                error=error,
            )
        except Exception as exc:
            log(f"mark_error reconciliation failed request={req_id}: {compact_error(str(exc), 180)}")


def work_schedule_broadcast_has_no_outbound(
    req_id: str,
    item: dict[str, Any],
) -> bool:
    if request_event_kind(item) != WORK_SCHEDULE_BROADCAST_EVENT_KIND:
        return False
    if str(item.get("outbound_key") or "").strip():
        return False
    try:
        request = fb_get(request_record_path(req_id, item))
        state = fb_get(work_schedule_broadcast_state_path())
        model0_outbound = fb_get(f"{OUTBOUND_PATH}/{work_schedule_broadcast_model0_outbound_key(req_id)}")
    except Exception as exc:
        log(f"model0 schedule fallback evidence read failed request={req_id}: {compact_error(str(exc), 180)}")
        return False
    if isinstance(request, dict) and str(request.get("outbound_key") or "").strip():
        return False
    if isinstance(model0_outbound, dict):
        return False
    if not isinstance(state, dict):
        return False
    return bool(
        str(state.get("inflight_request_id") or "").strip() == str(req_id).strip()
        and not str(state.get("inflight_outbound_key") or "").strip()
    )


def work_schedule_broadcast_model0_outbound_key(req_id: str) -> str:
    return sanitize_key(f"codex_schedule_model0_{short_text_hash(req_id)}", "codex_schedule_model0")


def work_schedule_broadcast_existing_outbound_key(req_id: str, item: dict[str, Any]) -> str:
    item_key = str(item.get("outbound_key") or "").strip()
    if item_key:
        return item_key
    try:
        request = fb_get(request_record_path(req_id, item))
        state = fb_get(work_schedule_broadcast_state_path())
        model0_key = work_schedule_broadcast_model0_outbound_key(req_id)
        model0_outbound = fb_get(f"{OUTBOUND_PATH}/{model0_key}")
    except Exception as exc:
        log(f"model0 schedule outbound evidence read failed request={req_id}: {compact_error(str(exc), 180)}")
        return ""
    request_key = str(request.get("outbound_key") or "").strip() if isinstance(request, dict) else ""
    if request_key:
        return request_key
    if isinstance(state, dict) and str(state.get("inflight_request_id") or "").strip() == str(req_id).strip():
        state_key = str(state.get("inflight_outbound_key") or "").strip()
        if state_key:
            return state_key
    if isinstance(model0_outbound, dict) and str(model0_outbound.get("request_id") or "").strip() == str(req_id).strip():
        return model0_key
    return ""


def maybe_process_work_schedule_broadcast_model0_fallback(
    req_id: str,
    item: dict[str, Any],
    resident_error: Exception | None,
    args: argparse.Namespace,
    *,
    route_metadata: dict[str, Any] | None = None,
    event_id: str = "",
    primary_route: bool = False,
) -> bool:
    if request_event_kind(item) != WORK_SCHEDULE_BROADCAST_EVENT_KIND:
        return False
    if not primary_route and not is_resident_codex_runtime_error(resident_error):
        return False
    route_label = "primary" if primary_route else "fallback"
    if not work_schedule_broadcast_has_no_outbound(req_id, item):
        existing_outbound_key = work_schedule_broadcast_existing_outbound_key(req_id, item)
        if primary_route and existing_outbound_key:
            publish_disabled = bool(getattr(args, "dry_run", False) or request_publish_disabled(args, item))
            mark_done(
                req_id,
                "",
                "model0:work_schedule_broadcast",
                existing_outbound_key,
                True,
                publish_disabled,
                args,
                output_category="schedule_image_already_queued",
                output_payload={"reason": "existing_outbound_evidence", "execution_lane": "model0"},
                route_metadata=route_metadata,
                item=item,
                brain_metadata={"brain_route": "model0_schedule_primary", "ai_call_count": 0},
            )
            write_reconciliation_status(
                req_id,
                item,
                args,
                status="matched",
                event_id=event_id,
                ledger_ids=[],
                route_metadata=route_metadata or {},
            )
            log(f"model0 schedule primary reused outbound request={req_id} outbound={existing_outbound_key}")
            return True
        log(f"model0 schedule {route_label} skipped request={req_id} reason=outbound_not_proven_absent")
        if primary_route:
            raise WorkerError("model0 schedule primary blocked: outbound absence not proven")
        return False

    route_reason = "fixed_event_primary" if primary_route else "resident_codex_runtime_error"
    brain_route = "model0_schedule_primary" if primary_route else "model0_schedule_fallback"
    error_text = compact_error(str(resident_error), 500) if resident_error else ""
    publish_disabled = bool(getattr(args, "dry_run", False) or request_publish_disabled(args, item))
    started_at_ms = now_ms()
    safe_record_stage(
        req_id,
        item,
        args,
        "realtime_data",
        "started",
        message=f"model0 schedule {route_label} canonical refresh started",
        evidence={"model0_reason": route_reason, "ai_call_count": 0},
    )
    image_result = build_schedule_image_request_result(
        item,
        "",
        req_id=req_id,
        args=args,
        model0_fallback=True,
        record_dedupe=not publish_disabled,
    )
    if image_result.incomplete:
        safe_record_stage(
            req_id,
            item,
            args,
            "realtime_data",
            "error",
            message=f"model0 schedule {route_label} canonical image incomplete",
            evidence=image_result.incomplete,
            elapsed_ms=now_ms() - started_at_ms,
            retry_count=1,
        )
        safe_record_stage(
            req_id,
            item,
            args,
            "image_build",
            "error",
            message=f"model0 schedule {route_label} image blocked",
            evidence=image_result.incomplete,
            elapsed_ms=now_ms() - started_at_ms,
            retry_count=1,
        )
        mark_done(
            req_id,
            "",
            "model0:work_schedule_broadcast",
            None,
            True,
            publish_disabled,
            args,
            output_category="schedule_realtime_incomplete",
            output_payload={
                **schedule_realtime_incomplete_output(image_result.incomplete, image_result.self_fix_request_id),
                "execution_lane": "model0",
                "model0_reason": route_reason,
                "model0_elapsed_ms": max(0, now_ms() - started_at_ms),
                **({"resident_error": error_text} if error_text else {}),
            },
            self_fix_request_id=image_result.self_fix_request_id,
            route_metadata=route_metadata,
            item=item,
            brain_metadata={
                "brain_route": brain_route,
                "fallback_used": not primary_route,
                "ai_call_count": 0,
                **({"resident_fallback_error": error_text} if error_text else {}),
            },
        )
        write_reconciliation_status(
            req_id,
            item,
            args,
            status="matched",
            event_id=event_id,
            ledger_ids=[],
            route_metadata=route_metadata or {},
        )
        return True

    image_request = image_result.image_request
    if not isinstance(image_request, dict):
        pending_reason = schedule_image_pending_reason(image_result.suppressed_reason)
        safe_record_stage(
            req_id,
            item,
            args,
            "image_build",
            "skipped",
            message=f"model0 schedule {route_label} image pending",
            evidence={
                "reason": pending_reason,
                "image_request_suppressed_reason": image_result.suppressed_reason,
                "image_request_dedupe_key": image_result.dedupe_key,
            },
            elapsed_ms=now_ms() - started_at_ms,
        )
        safe_record_stage(
            req_id,
            item,
            args,
            "outbound_publish",
            "skipped",
            message=f"model0 schedule {route_label} publish deferred",
            evidence={"reason": pending_reason},
        )
        mark_done(
            req_id,
            "",
            "model0:work_schedule_broadcast",
            None,
            True,
            publish_disabled,
            args,
            output_category="schedule_image_pending",
            output_payload={
                "reason": pending_reason,
                "image_request_suppressed_reason": image_result.suppressed_reason,
                "image_request_dedupe_key": image_result.dedupe_key,
                "image_pending": True,
                "execution_lane": "model0",
                "model0_reason": route_reason,
                "model0_elapsed_ms": max(0, now_ms() - started_at_ms),
                **({"resident_error": error_text} if error_text else {}),
            },
            route_metadata=route_metadata,
            image_request_suppressed_reason=image_result.suppressed_reason,
            image_request_suppressed_detail=image_result.suppressed_detail,
            image_request_dedupe_key=image_result.dedupe_key,
            item=item,
            brain_metadata={
                "brain_route": brain_route,
                "fallback_used": not primary_route,
                "ai_call_count": 0,
                **({"resident_fallback_error": error_text} if error_text else {}),
            },
        )
        write_reconciliation_status(
            req_id,
            item,
            args,
            status="matched",
            event_id=event_id,
            ledger_ids=[],
            route_metadata=route_metadata or {},
        )
        return True

    validation = validate_schedule_image_request(image_request)
    if validation.get("complete") is not True:
        raise WorkerError(f"model0 schedule {route_label} image validation failed")
    safe_record_stage(
        req_id,
        item,
        args,
        "realtime_data",
        "done",
        message=f"model0 schedule {route_label} canonical context ready",
        evidence=schedule_realtime_payload_metadata(image_request, image_request.get("payload") or {}),
        elapsed_ms=now_ms() - started_at_ms,
    )
    safe_record_stage(
        req_id,
        item,
        args,
        "image_build",
        "done",
        message=f"model0 schedule {route_label} image_request ready",
        evidence={
            "image_request_type": image_request.get("type"),
            "image_payload_source": image_request.get("image_payload_source"),
            "execution_lane": "model0",
        },
        elapsed_ms=now_ms() - started_at_ms,
    )

    outbound_key: str | None = None
    if publish_disabled:
        safe_record_stage(
            req_id,
            item,
            args,
            "outbound_publish",
            "skipped",
            message=f"model0 schedule {route_label} publish disabled",
        )
    else:
        if not work_schedule_broadcast_has_no_outbound(req_id, item):
            log(f"model0 schedule {route_label} skipped request={req_id} reason=outbound_appeared_before_publish")
            return False
        outbound_started_at_ms = now_ms()
        safe_record_stage(
            req_id,
            item,
            args,
            "outbound_publish",
            "started",
            message=f"model0 schedule {route_label} pending queue publish started",
        )
        outbound_key = publish_reply(
            req_id,
            item,
            "",
            image_request=image_request,
            queue_key=work_schedule_broadcast_model0_outbound_key(req_id),
        )
        safe_record_stage(
            req_id,
            item,
            args,
            "outbound_publish",
            "done",
            message=f"model0 schedule {route_label} pending queue publish done",
            evidence={
                "outbound_key": outbound_key,
                "image_required": True,
                "image_request_type": image_request.get("type"),
                "execution_lane": "model0",
            },
            elapsed_ms=now_ms() - outbound_started_at_ms,
        )

    mark_done(
        req_id,
        "",
        "model0:work_schedule_broadcast",
        outbound_key,
        publish_disabled,
        publish_disabled,
        args,
        output_category=(
            "schedule_image_pending"
            if publish_disabled
            else "schedule_image_model0_primary"
            if primary_route
            else "schedule_image_model0_fallback"
        ),
        output_payload={
            "reason": "publish_disabled" if publish_disabled else route_reason,
            "execution_lane": "model0",
            "image_first": True,
            "ai_call_count": 0,
            "model0_elapsed_ms": max(0, now_ms() - started_at_ms),
            **({"resident_error": error_text} if error_text else {}),
        },
        route_metadata=route_metadata,
        image_request=image_request,
        image_required=True,
        image_send_policy="image_first",
        item=item,
        brain_metadata={
            "brain_route": brain_route,
            "fallback_used": not primary_route,
            "ai_call_count": 0,
            **({"resident_fallback_error": error_text} if error_text else {}),
        },
    )
    write_reconciliation_status(
        req_id,
        item,
        args,
        status="matched",
        event_id=event_id,
        ledger_ids=[],
        route_metadata=route_metadata or {},
    )
    log(
        f"model0 schedule {route_label} completed "
        f"request={req_id} published={bool(outbound_key)} outbound={outbound_key or ''}"
    )
    return True


def mark_rejected(req_id: str, error: str, args: argparse.Namespace, item: dict[str, Any] | None = None) -> None:
    payload = {
        "status": "rejected",
        "worker": args.node,
        "model": model_label(args),
        "reasoning_effort": reasoning_label(args),
        "model_override_reason": getattr(args, "model_override_reason", ""),
        "failed_at_ms": now_ms(),
        "error": compact_error(error),
    }
    if isinstance(item, dict):
        apply_request_side_effect_safety(payload, item)
    fb_patch(request_record_path(req_id, item), payload)


def mark_confirmed_schedule_done(
    req_id: str,
    item: dict[str, Any],
    result: dict[str, Any],
    args: argparse.Namespace,
) -> None:
    dry_run = bool(result.get("dry_run"))
    writes = result.get("writes")
    payload: dict[str, Any] = {
        "status": "done",
        "finished_at_ms": now_ms(),
        "worker": args.node,
        "model": model_label(args),
        "reasoning_effort": reasoning_label(args),
        "model_override_reason": getattr(args, "model_override_reason", ""),
        "reply_skipped": True,
        "publish_disabled": True,
        "operation": CONFIRMED_SCHEDULE_WRITE_REQUEST_TYPE,
        "schedule_operation": str(result.get("schedule_operation") or result.get("operation") or ""),
        "confirmed_request_validated": bool(result.get("confirmed_request_validated") is True),
        "dispatch_result": compact_payload(result, 3000),
        "dry_run_completed": dry_run,
        "live_write_performed": not dry_run,
        "write_count": len(writes) if isinstance(writes, list) else 0,
        "canonical_write_targets": list(CONFIRMED_SCHEDULE_ALLOWED_WRITE_TARGETS),
    }
    apply_request_side_effect_safety(payload, item)
    fb_patch(request_record_path(req_id, item), payload)


def stale_schedule_event_reason(item: dict[str, Any]) -> str:
    event_kind = str(item.get("event_kind") or "")
    if not event_kind.startswith("schedule_"):
        return ""
    created_ms = normalize_ts_ms(item.get("created_at_ms") or item.get("ts") or 0)
    age_ms = now_ms() - created_ms
    if age_ms < 0:
        return ""
    if event_kind in {"schedule_attendance_pre", "schedule_attendance_nag", "schedule_attendance_final"}:
        if age_ms > 60 * 60 * 1000:
            return f"stale_{event_kind}_{age_ms // 60000}m"
    if event_kind in {LEGACY_SCHEDULE_FIXED_BRIEFING_EVENT_KIND, WORK_SCHEDULE_BROADCAST_EVENT_KIND}:
        if age_ms > 90 * 60 * 1000:
            return f"stale_{event_kind}_{age_ms // 60000}m"
    return ""


def kakao_screen_noise_reason(item: dict[str, Any]) -> str:
    text = str(
        item.get("message")
        or item.get("text")
        or item.get("message_preview")
        or item.get("content")
        or ""
    ).strip()
    compact_text = re.sub(r"\s+", "", text)

    sender = str(item.get("sender") or item.get("sender_name") or "").strip()
    transport = str(item.get("transport") or "").lower()
    source = str(item.get("source") or "").lower()
    room_name = str(item.get("room_name") or item.get("roomTitle") or "").strip()
    room_compact = re.sub(r"\s+", "", room_name)
    pseudo_screen_sender = sender in {"카카오화면", "kakao_screen", "screen", "screen_scan"}
    screen_scan_source = (
        sender == "accessibility_foreground_scan"
        or "screen_scan" in transport
        or "accessibility_screen" in transport
        or "accessibility_foreground_scan" in transport
        or "screen_scan" in source
        or "kakao_screen" in source
        or "accessibility_foreground_scan" in source
    )
    if not pseudo_screen_sender and not screen_scan_source:
        return ""
    if pseudo_screen_sender:
        return f"kakao_screen_sender_noise_{compact_text[:40] or 'blank'}"
    lower_text = compact_text.lower()
    if (
        re.fullmatch(r"\d{1,2}", compact_text)
        or lower_text == "lee"
        or is_decorative_kakao_screen_label(text, compact_text)
        or is_kakao_screen_profile_label(text)
        or (room_compact and compact_text == room_compact)
        or compact_text in KAKAO_SCREEN_UI_TOKENS
    ):
        return f"kakao_screen_ui_noise_{compact_text}"
    return ""


KAKAO_SCREEN_UI_TOKENS = {
    "BBQ하이닉스점",
    "BBQSK하이닉스점",
    "BBQ하이닉스점10",
    "공유하기",
    "친구",
    "채팅",
    "오픈채팅",
    "쇼핑",
    "더보기",
    "전체보기",
    "접기",
    "이전메시지전체보기",
}


def is_decorative_kakao_screen_label(text: str, compact_text: str) -> bool:
    if not compact_text or len(compact_text) > 40 or re.search(r"\s", text):
        return False
    if re.search(r"[가-힣]", compact_text):
        return False
    if re.search(r"[A-Za-z]", compact_text) is None:
        return False
    return any(is_decorative_symbol(ch) for ch in compact_text)


def is_decorative_symbol(ch: str) -> bool:
    code = ord(ch)
    return (
        0x1F000 <= code <= 0x1FAFF
        or ch in {"❤", "♥", "♡", "💕", "💖", "💗", "💓", "💞", "💘", "⭐", "★", "☆", "✨"}
    )


def is_kakao_screen_profile_label(text: str) -> bool:
    clean = " ".join(str(text or "").split())
    if not clean or len(clean) > 40:
        return False
    if re.match(r"^[ㄱ-ㅎㅏ-ㅣ]\s+\S+", clean) is None:
        return False
    parts = clean.split()
    if len(parts) < 2 or len(parts) > 4:
        return False
    return all(re.fullmatch(r"[가-힣A-Za-z0-9._+&-]{1,16}", part) is not None for part in parts[1:])


def mark_stale_schedule_done(req_id: str, item: dict[str, Any], reason: str, args: argparse.Namespace) -> None:
    fb_patch(
        f"{REQUESTS_PATH}/{req_id}",
        {
            "status": "done",
            "finished_at_ms": now_ms(),
            "worker": args.node,
            "reply_skipped": True,
            "publish_disabled": True,
            "skip_reason": reason,
            "stale_schedule_event": True,
            "event_kind": str(item.get("event_kind") or ""),
        },
    )


def mark_screen_noise_done(
    req_id: str,
    item: dict[str, Any],
    reason: str,
    args: argparse.Namespace,
    *,
    local_direct: bool = False,
    elapsed_ms: int = 0,
) -> None:
    payload = dict(item) if local_direct else {}
    payload.update(
        {
            "status": "done",
            "finished_at_ms": now_ms(),
            "worker": args.node,
            "model": model_label(args),
            "reasoning_effort": reasoning_label(args),
            "model_override_reason": getattr(args, "model_override_reason", ""),
            "reply_skipped": True,
            "publish_disabled": True,
            "skip_reason": reason,
            "screen_noise_event": True,
            "output_category": "skip",
            "reply": "",
        }
    )
    if local_direct:
        payload["local_direct"] = True
        payload["local_direct_elapsed_ms"] = elapsed_ms
        payload["source"] = str(item.get("source") or "storebot_android") + "_local_direct"
        fb_put(f"{REQUESTS_PATH}/{sanitize_key(req_id, 'local_direct')}", payload)
        return
    fb_patch(f"{REQUESTS_PATH}/{req_id}", payload)


def write_heartbeat(args: argparse.Namespace, queue_size: int, status: str, last_error: str = "") -> None:
    bundle_state = read_bundle_state()
    local_direct_state = dict(LOCAL_DIRECT_STATE)
    cleanup_telemetry = fast_router_cleanup_telemetry()
    if env_bool("STOREBOT_CODEX_RESIDENT_APP_SERVER", True):
        resident_codex_process_alive()
    fast_brain_status = fast_brain_config_status()
    payload = {
        "alive": True,
        "ts": now_ms(),
        "node": args.node,
        "mode": "action_reply",
        "bridge_mode": STOREBOT_BRIDGE_MODE,
        "reply_contract_version": STOREBOT_REPLY_CONTRACT_VERSION,
        "dedicated_room": True,
        "default_model_policy": "thin_bridge_cli_direct_resident_required",
        "status": status,
        "queue_size": queue_size,
        "last_error": compact_error(last_error, 250) if last_error else "",
        "redact_done": args.redact_done,
        "model": model_label(args),
        "reasoning_effort": reasoning_label(args),
        "fast_brain": fast_brain_status,
        "fast_brain_enabled": bool(fast_brain_enabled()),
        "fast_brain_default": False,
        "fast_brain_guarded_hot_path": bool(guarded_fast_brain_hot_path_enabled()),
        "fast_brain_fallback_route": "guarded_side_path_only_resident_cli_primary",
        **fast_brain_secret_mirrors(fast_brain_status),
        "mcp_tools_enabled": bool(env_bool("STOREBOT_CODEX_MCP_TOOLS", True)),
        "resident_app_server_enabled": bool(env_bool("STOREBOT_CODEX_RESIDENT_APP_SERVER", True)),
        "resident_app_server_active": bool(RESIDENT_CODEX_STATE.get("active")),
        "resident_app_server_pid": int(RESIDENT_CODEX_STATE.get("pid") or 0),
        "resident_app_server_started_at_ms": int(RESIDENT_CODEX_STATE.get("started_at_ms") or 0),
        "resident_app_server_last_error": compact_error(str(RESIDENT_CODEX_STATE.get("last_error") or ""), 250),
        "resident_app_server_last_turn_duration_ms": int(RESIDENT_CODEX_STATE.get("last_turn_duration_ms") or 0),
        "resident_app_server_last_total_tokens": int(RESIDENT_CODEX_STATE.get("last_total_tokens") or 0),
        "resident_app_server_last_turn_id": str(RESIDENT_CODEX_STATE.get("last_turn_id") or ""),
        "resident_app_server_last_stale_event_discard_count": int(RESIDENT_CODEX_STATE.get("last_stale_event_discard_count") or 0),
        "resident_session_preboot_enabled": bool(RESIDENT_CODEX_STATE.get("session_preboot_enabled")),
        "resident_session_preboot_ready": bool(RESIDENT_CODEX_STATE.get("session_preboot_ready")),
        "resident_session_preboot_started_at_ms": int(RESIDENT_CODEX_STATE.get("session_preboot_started_at_ms") or 0),
        "resident_session_preboot_ready_at_ms": int(RESIDENT_CODEX_STATE.get("session_preboot_ready_at_ms") or 0),
        "resident_session_preboot_room_key": str(RESIDENT_CODEX_STATE.get("session_preboot_room_key") or ""),
        "resident_session_preboot_room_id": str(RESIDENT_CODEX_STATE.get("session_preboot_room_id") or ""),
        "resident_session_preboot_room_name": str(RESIDENT_CODEX_STATE.get("session_preboot_room_name") or ""),
        "resident_session_preboot_session_id": str(RESIDENT_CODEX_STATE.get("session_preboot_session_id") or ""),
        "resident_session_preboot_error": compact_error(str(RESIDENT_CODEX_STATE.get("session_preboot_error") or ""), 250),
        "resident_session_preboot_in_progress": bool(RESIDENT_CODEX_STATE.get("session_preboot_in_progress")),
        "resident_session_preboot_reason": str(RESIDENT_CODEX_STATE.get("session_preboot_reason") or ""),
        "resident_session_watchdog_enabled": bool(RESIDENT_CODEX_STATE.get("session_watchdog_enabled")),
        "resident_session_watchdog_interval_sec": float(RESIDENT_CODEX_STATE.get("session_watchdog_interval_sec") or 0),
        "resident_session_keepalive_interval_sec": float(RESIDENT_CODEX_STATE.get("session_keepalive_interval_sec") or 0),
        "resident_session_last_health_check_ms": int(RESIDENT_CODEX_STATE.get("session_last_health_check_ms") or 0),
        "resident_session_last_keepalive_at_ms": int(RESIDENT_CODEX_STATE.get("session_last_keepalive_at_ms") or 0),
        "resident_session_health_ok": bool(RESIDENT_CODEX_STATE.get("session_health_ok")),
        "resident_session_health_error": compact_error(str(RESIDENT_CODEX_STATE.get("session_health_error") or ""), 250),
        "resident_session_revive_count": int(RESIDENT_CODEX_STATE.get("session_revive_count") or 0),
        "resident_session_last_revived_at_ms": int(RESIDENT_CODEX_STATE.get("session_last_revived_at_ms") or 0),
        "resident_session_last_revive_reason": str(RESIDENT_CODEX_STATE.get("session_last_revive_reason") or ""),
        "fast_router_enabled": bool(env_bool("STOREBOT_CODEX_FAST_ROUTER", True)),
        "fast_router_stateless_exec": bool(fast_router_stateless_exec_enabled()),
        **cleanup_telemetry,
        "thin_bridge_cli_direct": bool(thin_bridge_cli_direct_enabled()),
        "resident_exec_fallback_enabled": bool(resident_exec_fallback_enabled()),
        "bounded_worker_exec_fallback_enabled": bool(fast_router_stateless_exec_enabled() or resident_exec_fallback_enabled()),
        "bounded_worker_exec_fallback_status": "enabled" if (fast_router_stateless_exec_enabled() or resident_exec_fallback_enabled()) else "disabled_resident_required",
        "fast_router_refresh_after_action": bool(fast_router_refresh_after_action_enabled()),
        "fast_router_timeout_sec": int(fast_router_timeout_sec()),
        "improvement_report_enabled": bool(env_bool("STOREBOT_IMPROVEMENT_REPORT_ENABLED", True)),
        "improvement_report_daily": bool(getattr(args, "improvement_report_daily", True)),
        "improvement_report_time_kst": improvement_report_daily_time_text(args),
        "improvement_report_defer_sec": float(getattr(args, "improvement_report_defer_sec", 0) or 0),
        "improvement_report_max_defer_sec": float(getattr(args, "improvement_report_max_defer_sec", 0) or 0),
        "schedule_timer_enabled": bool(getattr(args, "schedule_timer", True)),
        "schedule_timer_attendance_catchup_min": int(getattr(args, "schedule_timer_attendance_catchup_min", 10) or 10),
        "schedule_timer_briefing_catchup_min": int(getattr(args, "schedule_timer_briefing_catchup_min", 30) or 30),
        "self_sync_enabled": args.self_sync,
        "bundle_version": bundle_state.get("bundle_version") or "",
        "bundle_sha256": bundle_state.get("bundle_sha256") or "",
        "bundle_source_revision": bundle_state.get("source_revision") or bundle_state.get("code_revision") or "",
        "bundle_code_revision": bundle_state.get("code_revision") or bundle_state.get("source_revision") or "",
        "bundle_status": bundle_state.get("status") or "",
        "bundle_applied_at_ms": bundle_state.get("applied_at_ms") or 0,
        "bundle_manifest_url": bundle_state.get("manifest_url") or (args.self_sync_manifest_url if args.self_sync else ""),
        "local_direct_enabled": bool(args.local_direct_server),
        "local_direct_listening": bool(local_direct_state.get("listening")),
        "local_direct_host": str(local_direct_state.get("host") or args.local_direct_host or ""),
        "local_direct_port": int(local_direct_state.get("port") or args.local_direct_port or 0),
        "local_direct_sync_timeout_sec": float(local_direct_sync_timeout_sec()),
        "local_direct_deferred_publish": bool(local_direct_deferred_publish_enabled()),
        "local_direct_started_at_ms": int(local_direct_state.get("started_at_ms") or 0),
        "local_direct_last_error": compact_error(local_direct_state.get("last_error") or "", 250),
    }
    fb_put(HEARTBEAT_PATH, payload)


def route_full_requested(answer: str) -> bool:
    return re.fullmatch(r"\s*ROUTE_FULL\s*", str(answer or "").strip(), flags=re.IGNORECASE) is not None


def fast_router_skip_requires_full(item: dict[str, Any], answer: str) -> bool:
    if re.fullmatch(r"\s*SKIP\s*", str(answer or "").strip(), flags=re.IGNORECASE) is None:
        return False
    event_kind = str(item.get("event_kind") or item.get("kind") or "").strip()
    if not event_kind:
        payload = item.get("payload")
        if isinstance(payload, dict):
            event_kind = str(payload.get("event_kind") or payload.get("kind") or "").strip()
    return event_kind in FAST_ROUTER_SKIP_FULL_FALLBACK_EVENT_KINDS


def codex_result_route_metadata(result: CodexResult | None) -> dict[str, Any]:
    if result is None or not isinstance(result.metadata, dict):
        return {}
    allowed = (
        "brain_route",
        "reply_source",
        "fallback_used",
        "escalation_used",
        "context_source",
        "context_hash",
        "context_build_ms",
        "api_submit_ms",
        "api_wait_ms",
        "fast_brain_provider",
        "fast_brain_model",
        "fast_brain_policy",
        "fast_brain_attempts",
        "fast_brain_fallback_reason",
        "fast_brain_escalation_reason",
        "resident_submit_ms",
        "resident_wait_ms",
        "clean_extract_ms",
        "publish_gate_ms",
        "total_ms",
        "bottleneck_stage",
        "resident_turn_duration_ms",
        "resident_reported_total_tokens",
        "resident_session_id",
        "resident_app_server_pid",
        "resident_fallback_error",
        "codex_exec_duration_ms",
        "fast_router_prompt_total_chars",
        "fast_router_prompt_component_chars",
        "fast_router_reported_total_tokens",
        "fast_router_max_subturn_duration_ms",
        "fast_router_turn_count",
        "fast_router_rotation_reason",
        "fast_router_session_generation",
        "fast_router_thread_cleanup_supported",
        "fast_router_thread_cleanup_method",
        "fast_router_thread_cleanup_attempt_count",
        "fast_router_thread_cleanup_ok_count",
        "fast_router_thread_cleanup_failure_count",
        "fast_router_thread_cleanup_created_count",
        "fast_router_thread_cleanup_evicted_count",
        "fast_router_thread_cleanup_last_status",
        "fast_router_thread_cleanup_last_error",
        "fast_router_thread_cleanup_last_duration_ms",
    )
    metadata = {key: result.metadata.get(key) for key in allowed if key in result.metadata}
    if "fallback_used" in metadata:
        metadata["fallback_used"] = bool(metadata["fallback_used"])
    return compact_payload(metadata, 1200)


def finish_codex_pipeline_from_result(
    req_id: str,
    item: dict[str, Any],
    room_id: str,
    room_name: str,
    room_key: str,
    session_id: str,
    result: CodexResult,
    args: argparse.Namespace,
    continue_turn: Callable[[str], CodexResult],
    *,
    audit_actions: bool = True,
    allow_direct_mcp_retry: bool = True,
    fallback_on_event_skip: bool = False,
    route_metadata: dict[str, Any] | None = None,
) -> dict[str, Any]:
    answer = result.final.strip()
    brain_metadata = codex_result_route_metadata(result)
    if route_full_requested(answer):
        raise FastRouterFullFallback("fast router requested full StoreBot session")
    request_safety = request_side_effect_safety(item)
    if request_safety:
        allow_direct_mcp_retry = False
    direct_tool_count = int(result.tool_call_count or 0)
    direct_tool_ok_count = int(result.tool_ok_count or 0)
    direct_tool_error_count = int(result.tool_error_count or 0)
    action_count = direct_tool_count
    action_ok_count = direct_tool_ok_count
    action_error_count = direct_tool_error_count
    last_action_results: list[dict[str, Any]] = []
    direct_mcp_retry_done = False
    required_reason = fresh_tool_required_reason(item)
    if (
        allow_direct_mcp_retry
        and required_reason
        and env_bool("STOREBOT_CODEX_MCP_TOOLS", True)
        and direct_mcp_retry_enabled()
        and direct_tool_count == 0
        and parse_action_request(answer) is None
    ):
        log(f"tool-less reply intercepted for direct MCP retry request={req_id} reason={required_reason}")
        retry_prompt = build_fresh_tool_retry_prompt(item, room_id, room_name, required_reason, answer)
        result = continue_turn(retry_prompt)
        brain_metadata = codex_result_route_metadata(result) or brain_metadata
        session_id = result.thread_id or session_id
        direct_tool_count += int(result.tool_call_count or 0)
        direct_tool_ok_count += int(result.tool_ok_count or 0)
        direct_tool_error_count += int(result.tool_error_count or 0)
        action_count += int(result.tool_call_count or 0)
        action_ok_count += int(result.tool_ok_count or 0)
        action_error_count += int(result.tool_error_count or 0)
        answer = result.final.strip()
        if route_full_requested(answer):
            raise FastRouterFullFallback("fast router requested full StoreBot session")
    for action_round in range(max(0, int(args.action_rounds or 0))):
        action_request = parse_action_request(answer)
        if action_request is None:
            break
        if (
            allow_direct_mcp_retry
            and not direct_mcp_retry_done
            and env_bool("STOREBOT_CODEX_MCP_TOOLS", True)
            and direct_mcp_retry_enabled()
            and direct_tool_count == 0
        ):
            direct_mcp_retry_done = True
            log(f"fallback action intercepted for direct MCP retry request={req_id}")
            retry_prompt = build_direct_mcp_retry_prompt(item, room_id, room_name, action_request)
            result = continue_turn(retry_prompt)
            brain_metadata = codex_result_route_metadata(result) or brain_metadata
            session_id = result.thread_id or session_id
            direct_tool_count += int(result.tool_call_count or 0)
            direct_tool_ok_count += int(result.tool_ok_count or 0)
            direct_tool_error_count += int(result.tool_error_count or 0)
            action_count += int(result.tool_call_count or 0)
            action_ok_count += int(result.tool_ok_count or 0)
            action_error_count += int(result.tool_error_count or 0)
            answer = result.final.strip()
            if route_full_requested(answer):
                raise FastRouterFullFallback("fast router requested full StoreBot session")
            action_request = parse_action_request(answer)
            if action_request is None:
                break
        log(f"action request detected request={req_id} round={action_round + 1}")
        action_results = execute_action_request(
            req_id,
            action_request,
            args,
            audit=audit_actions,
            item=item,
            event_id=str(item.get("_room_event_id") or ""),
            route_metadata=route_metadata,
        )
        last_action_results = action_results
        action_count += len(action_results)
        action_ok_count += sum(1 for result_item in action_results if result_item.get("ok") is True)
        action_error_count += sum(1 for result_item in action_results if result_item.get("ok") is not True)
        if should_skip_schedule_query_followup(item, action_request, action_results):
            answer = "근무표"
            log(f"schedule image followup skipped request={req_id}")
            break
        followup_prompt = build_action_result_prompt(item, room_id, room_name, action_request, action_results)
        result = continue_turn(followup_prompt)
        brain_metadata = codex_result_route_metadata(result) or brain_metadata
        session_id = result.thread_id or session_id
        direct_tool_count += int(result.tool_call_count or 0)
        direct_tool_ok_count += int(result.tool_ok_count or 0)
        direct_tool_error_count += int(result.tool_error_count or 0)
        action_count += int(result.tool_call_count or 0)
        action_ok_count += int(result.tool_ok_count or 0)
        action_error_count += int(result.tool_error_count or 0)
        answer = result.final.strip()
        if route_full_requested(answer):
            raise FastRouterFullFallback("fast router requested full StoreBot session")
    if parse_action_request(answer) is not None:
        raise WorkerError("too many action rounds")
    if fallback_on_event_skip and fast_router_skip_requires_full(item, answer):
        event_kind = str(item.get("event_kind") or item.get("kind") or "")
        raise FastRouterFullFallback(f"fast router skipped operational event event_kind={event_kind}")
    if required_reason and not fresh_tool_result_exists(direct_tool_ok_count, last_action_results):
        log(
            "android freshness required without fresh tool result; preserving Codex final decision "
            f"request={req_id} reason={required_reason}"
        )
    if not answer:
        raise WorkerError("empty codex reply")
    output_contract = apply_storebot_output_contract(req_id, item, answer, args)
    answer = str(output_contract.get("answer") or "")
    skipped = bool(output_contract.get("skipped"))
    pipeline = {
        "answer": answer,
        "skipped": skipped,
        "output_category": str(output_contract.get("output_category") or ("skip" if skipped else "kakao_reply")),
        "output_payload": output_contract.get("output_payload") if isinstance(output_contract.get("output_payload"), dict) else {},
        "self_fix_request_id": str(output_contract.get("self_fix_request_id") or ""),
        "session_id": session_id,
        "room_id": room_id,
        "room_name": room_name,
        "room_key": room_key,
        "action_count": action_count,
        "action_ok_count": action_ok_count,
        "action_error_count": action_error_count,
        "direct_tool_count": direct_tool_count,
        "direct_tool_ok_count": direct_tool_ok_count,
        "direct_tool_error_count": direct_tool_error_count,
        "last_action_results": last_action_results,
        "brain_metadata": brain_metadata,
    }
    pipeline.update(brain_metadata)
    pipeline.update(request_safety)
    return pipeline


def should_use_fast_router(item: dict[str, Any]) -> bool:
    if not env_bool("STOREBOT_CODEX_FAST_ROUTER", True):
        return False
    if is_chat_image_event(item):
        return False
    if request_no_send_contract_probe(item):
        return True
    if item.get("local_direct") is not True and not env_bool("STOREBOT_CODEX_FAST_ROUTER_FOR_QUEUE", False):
        return False
    event_kind = str(item.get("event_kind") or item.get("kind") or "chat")
    return bool(event_kind)


def should_use_resident_cli_direct(item: dict[str, Any]) -> bool:
    if not thin_bridge_cli_direct_enabled():
        return False
    return should_use_fast_router(item)


def pipeline_uses_resident_cli_direct(pipeline: dict[str, Any]) -> bool:
    brain_metadata = pipeline.get("brain_metadata") if isinstance(pipeline.get("brain_metadata"), dict) else {}
    brain_route = str(pipeline.get("brain_route") or brain_metadata.get("brain_route") or "")
    reply_source = str(pipeline.get("reply_source") or brain_metadata.get("reply_source") or "")
    return brain_route == "resident" and reply_source == "resident_session"


def mark_pipeline_resident_cli_direct(pipeline: dict[str, Any]) -> dict[str, Any]:
    if not pipeline_uses_resident_cli_direct(pipeline):
        return pipeline
    metadata = dict(pipeline.get("brain_metadata") if isinstance(pipeline.get("brain_metadata"), dict) else {})
    metadata.update(
        {
            "brain_route": "resident",
            "reply_source": "resident_session",
            "fallback_used": False,
            "worker_role": "thin_bridge",
            "cli_direct": True,
            "resident_required": True,
            "default_model_policy": "thin_bridge_cli_direct_resident_required",
            "fast_brain_hot_path": False,
            "bounded_worker_exec_fallback": False,
        }
    )
    pipeline["brain_metadata"] = compact_payload(metadata, 1200)
    pipeline.update(metadata)
    return pipeline


def run_resident_cli_direct_pipeline(
    req_id: str,
    item: dict[str, Any],
    args: argparse.Namespace,
    *,
    audit_actions: bool = True,
    route_metadata: dict[str, Any] | None = None,
) -> dict[str, Any]:
    return run_fast_router_pipeline(
        req_id,
        item,
        args,
        audit_actions=audit_actions,
        route_metadata=route_metadata,
    )


def run_fast_brain_pipeline(
    req_id: str,
    item: dict[str, Any],
    args: argparse.Namespace,
    *,
    audit_actions: bool = True,
    route_metadata: dict[str, Any] | None = None,
) -> dict[str, Any]:
    router_args = fast_router_effective_args(args)
    router_guide, _skill_path = build_fast_router_guide(router_args)
    if not router_guide.strip():
        raise FastRouterFullFallback("fast brain guide missing")
    room_id = str(item.get("room_id") or item.get("room") or "default")
    room_name = str(item.get("room_name") or item.get("roomTitle") or room_id)
    room_key = sanitize_key(room_id or room_name)
    item = dict(item)
    previous_turn_context = build_previous_turn_context(req_id, item, room_id, room_name)
    if previous_turn_context:
        item["_previous_turn_context"] = previous_turn_context
    result = run_fast_brain_api_turn(req_id, item, room_id, room_name, router_guide)

    def continue_fast_brain(prompt_body: str) -> CodexResult:
        return run_fast_brain_api_prompt(req_id, item, room_id, room_name, router_guide, prompt_body)

    return finish_codex_pipeline_from_result(
        req_id,
        item,
        room_id,
        room_name,
        room_key,
        result.thread_id or "fast_api",
        result,
        args,
        continue_fast_brain,
        audit_actions=audit_actions,
        allow_direct_mcp_retry=False,
        fallback_on_event_skip=True,
        route_metadata=route_metadata,
    )


def run_fast_router_pipeline(
    req_id: str,
    item: dict[str, Any],
    args: argparse.Namespace,
    *,
    audit_actions: bool = True,
    route_metadata: dict[str, Any] | None = None,
) -> dict[str, Any]:
    router_args = fast_router_effective_args(args)
    router_guide, _skill_path = build_fast_router_guide(router_args)
    if not router_guide.strip():
        raise FastRouterFullFallback("fast router guide missing")
    room_id = str(item.get("room_id") or item.get("room") or "default")
    room_name = str(item.get("room_name") or item.get("roomTitle") or room_id)
    room_key = sanitize_key(room_id or room_name)
    room_identity = room_id or room_name
    item = dict(item)
    previous_turn_context = build_previous_turn_context(req_id, item, room_id, room_name)
    if previous_turn_context:
        item["_previous_turn_context"] = previous_turn_context
    if fast_router_stateless_exec_enabled():
        session_id = "stateless_exec"
        prompt, prompt_telemetry = build_fast_router_turn_prompt_with_telemetry(item, room_id, room_name)
        result = run_fast_router_stateless_prompt(prompt, router_guide, router_args, item)
        result.metadata.update(prompt_telemetry)

        def continue_router(prompt_body: str) -> CodexResult:
            return run_fast_router_stateless_prompt(prompt_body, router_guide, router_args, item)

        return finish_codex_pipeline_from_result(
            req_id,
            item,
            room_id,
            room_name,
            room_key,
            session_id,
            result,
            args,
            continue_router,
            audit_actions=audit_actions,
            allow_direct_mcp_retry=False,
            fallback_on_event_skip=True,
            route_metadata=route_metadata,
        )
    session_key = fast_router_session_key(router_args, room_identity)
    room_lock = fast_router_room_lock(session_key)
    with room_lock:
        mark_fast_router_room_active(session_key, True)
        try:
            session_id = get_or_create_fast_router_session(router_guide, router_args, room_identity)
            prompt, prompt_telemetry = build_fast_router_turn_prompt_with_telemetry(item, room_id, room_name)
            try:
                result = resume_fast_router_session(session_id, prompt, router_args, item)
            except WorkerError as exc:
                if not is_missing_session_error(str(exc)):
                    raise
                log("fast router session missing; recreating")
                previous_meta = fast_router_runtime_metadata(router_args, room_identity, session_id)
                session_id = create_fast_router_session(
                    router_guide,
                    router_args,
                    reset_reason="session_missing",
                    previous_session_id=session_id,
                    room_identity=room_identity,
                    session_generation=safe_int(previous_meta.get("session_generation"), 1) + 1,
                    expected_previous_session_id=session_id,
                )
                result = resume_fast_router_session(session_id, prompt, router_args, item)
            turn_results = [result]

            def continue_router(prompt_body: str) -> CodexResult:
                continued = resume_fast_router_session(session_id, prompt_body, router_args, item)
                turn_results.append(continued)
                return continued

            pipeline = finish_codex_pipeline_from_result(
                req_id,
                item,
                room_id,
                room_name,
                room_key,
                session_id,
                result,
                args,
                continue_router,
                audit_actions=audit_actions,
                allow_direct_mcp_retry=False,
                fallback_on_event_skip=True,
                route_metadata=route_metadata,
            )
            turn_telemetry = record_fast_router_turn(
                router_args,
                room_identity,
                session_id,
                fast_router_aggregate_subturn_result(turn_results),
                prompt_telemetry,
            )
            if turn_telemetry:
                brain_metadata = dict(pipeline.get("brain_metadata") if isinstance(pipeline.get("brain_metadata"), dict) else {})
                brain_metadata.update(turn_telemetry)
                pipeline["brain_metadata"] = compact_payload(brain_metadata, 1600)
                pipeline.update(turn_telemetry)
            if should_refresh_fast_router_after_pipeline(pipeline):
                start_fast_router_refresh(
                    router_guide,
                    router_args,
                    session_id,
                    "after_action_or_long_reply",
                    room_identity,
                )
            return pipeline
        finally:
            mark_fast_router_room_active(session_key, False)


def prewarm_fast_router(args: argparse.Namespace) -> None:
    if not env_bool("STOREBOT_CODEX_FAST_ROUTER", True) or not env_bool("STOREBOT_CODEX_FAST_ROUTER_PREWARM", True):
        return
    if fast_router_stateless_exec_enabled():
        log("fast router prewarm skipped: stateless exec enabled")
        return
    router_args = fast_router_effective_args(args)
    router_guide, _skill_path = build_fast_router_guide(router_args)
    if not router_guide.strip():
        return
    room_id, _room_name, _room_key = resident_session_preboot_room(args)
    session_id = get_or_create_fast_router_session(router_guide, router_args, room_id)
    prompt = (
        "## Fast router prewarm\n"
        "This is an internal readiness turn, not a Kakao user message.\n"
        "Answer exactly SKIP."
    )
    result = resume_fast_router_session(session_id, prompt, router_args)
    if result.final.strip() != "SKIP":
        log(f"fast router prewarm reply ignored: {result.final[:80]}")
    else:
        log(f"fast router prewarmed session={session_id}")


def ensure_resident_app_server_started(args: argparse.Namespace, reason: str) -> None:
    if not env_bool("STOREBOT_CODEX_RESIDENT_APP_SERVER", True):
        return
    router_args = fast_router_effective_args(args)
    client = resident_codex_client()
    with client.lock:
        client._start_locked(router_args.model, router_args.reasoning_effort)
    RESIDENT_CODEX_STATE.update(
        {
            "last_error": "",
            "session_health_error": "",
        }
    )
    log(f"resident codex app-server ensured reason={reason}")


def maybe_recover_resident_app_server(args: argparse.Namespace, reason: str) -> None:
    if not env_bool("STOREBOT_CODEX_RESIDENT_APP_SERVER", True):
        return
    alive = resident_codex_process_alive()
    last_error = str(RESIDENT_CODEX_STATE.get("last_error") or "").strip()
    if alive and not last_error:
        return
    global _RESIDENT_RECOVERY_LAST_ATTEMPT_MS
    now = now_ms()
    with _RESIDENT_RECOVERY_LOCK:
        if now - int(_RESIDENT_RECOVERY_LAST_ATTEMPT_MS or 0) < 60_000:
            return
        _RESIDENT_RECOVERY_LAST_ATTEMPT_MS = now
    try:
        if last_error:
            shutdown_resident_codex()
        ensure_resident_app_server_started(args, reason)
        log(f"resident app-server recovered reason={reason} previous_error={compact_error(last_error, 160)}")
    except Exception as exc:
        RESIDENT_CODEX_STATE["last_error"] = compact_error(str(exc), 250)
        log(f"resident app-server recovery failed reason={reason}: {compact_error(str(exc), 250)}")


def start_fast_router_prewarm_thread(args: argparse.Namespace) -> None:
    if not env_bool("STOREBOT_CODEX_FAST_ROUTER", True) or not env_bool("STOREBOT_CODEX_FAST_ROUTER_PREWARM", True):
        return

    def runner() -> None:
        try:
            prewarm_fast_router(args)
        except Exception as exc:
            log(f"fast router prewarm failed: {compact_error(str(exc), 250)}")
            try:
                ensure_resident_app_server_started(args, "fast_router_prewarm_failed")
            except Exception as start_exc:
                log(f"resident app-server ensure after prewarm failed: {compact_error(str(start_exc), 250)}")

    threading.Thread(target=runner, daemon=True, name="fast-router-prewarm").start()


def run_codex_pipeline(
    req_id: str,
    item: dict[str, Any],
    guide: str,
    args: argparse.Namespace,
    *,
    audit_actions: bool = True,
    route_metadata: dict[str, Any] | None = None,
) -> dict[str, Any]:
    route_metadata = route_metadata if isinstance(route_metadata, dict) else plan_storebot_capability_route(item)
    fast_brain_fallback_reason = ""
    if (
        not is_chat_image_event(item)
        and guarded_fast_brain_hot_path_enabled()
        and fast_brain_enabled()
        and not request_no_send_contract_probe(item)
        and fast_brain_candidates()
    ):
        fast_brain_escalation_reason = fast_brain_should_escalate(item, route_metadata)
        if not fast_brain_escalation_reason:
            try:
                pipeline = run_fast_brain_pipeline(req_id, item, args, audit_actions=audit_actions, route_metadata=route_metadata)
                pipeline["session_id"] = f"fast_api:{pipeline.get('session_id') or ''}"
                pipeline["route_metadata"] = route_metadata
                return pipeline
            except FastRouterFullFallback as exc:
                fast_brain_fallback_reason = compact_error(str(exc), 250)
                log(f"optional fast brain failed; continuing resident request={req_id}: {fast_brain_fallback_reason}")
    if should_use_resident_cli_direct(item):
        try:
            pipeline = run_resident_cli_direct_pipeline(req_id, item, args, audit_actions=audit_actions, route_metadata=route_metadata)
            pipeline = mark_pipeline_resident_cli_direct(pipeline)
            session_prefix = "resident_cli" if pipeline_uses_resident_cli_direct(pipeline) else "fast_router"
            pipeline["session_id"] = f"{session_prefix}:{pipeline.get('session_id') or ''}"
            pipeline["route_metadata"] = route_metadata
            if fast_brain_fallback_reason:
                brain_metadata = dict(pipeline.get("brain_metadata") if isinstance(pipeline.get("brain_metadata"), dict) else {})
                brain_metadata.update(
                    {
                        "fallback_used": True,
                        "escalation_used": True,
                        "fast_brain_fallback_reason": fast_brain_fallback_reason,
                        "fast_brain_escalation_reason": fast_brain_fallback_reason,
                    }
                )
                pipeline["brain_metadata"] = compact_payload(brain_metadata, 1200)
                pipeline.update(codex_result_route_metadata(CodexResult("", None, metadata=brain_metadata)))
            return pipeline
        except FastRouterFullFallback as exc:
            if not env_bool("STOREBOT_CODEX_FAST_ROUTER_FALLBACK_FULL", True):
                raise WorkerError(str(exc)) from exc
            log(f"resident CLI direct fell back to full session request={req_id}: {compact_error(str(exc), 200)}")
        except Exception as exc:
            if item.get("local_direct") is True and is_retryable_codex_runtime_error(exc):
                if not env_bool("STOREBOT_CODEX_FAST_ROUTER_FALLBACK_FULL", True):
                    raise WorkerError(compact_error(str(exc), 500)) from exc
                diagnostic_id = enqueue_local_direct_codex_runtime_diagnostic(
                    req_id,
                    item,
                    args,
                    exc,
                    "fast_router",
                )
                suffix = f" diagnostic={diagnostic_id}" if diagnostic_id else ""
                log(
                    "resident CLI direct retryable Codex runtime failure; "
                    f"falling back to full session request={req_id}: {compact_error(str(exc), 200)}{suffix}"
                )
            elif not env_bool("STOREBOT_CODEX_FAST_ROUTER_FALLBACK_ON_ERROR", False):
                raise
            else:
                log(f"resident CLI direct failed; falling back to full session request={req_id}: {compact_error(str(exc), 200)}")

    room_id = str(item.get("room_id") or item.get("room") or "default")
    room_name = str(item.get("room_name") or item.get("roomTitle") or room_id)
    room_key = sanitize_key(room_id or room_name)
    item = dict(item)
    previous_turn_context = build_previous_turn_context(req_id, item, room_id, room_name)
    if previous_turn_context:
        item["_previous_turn_context"] = previous_turn_context
    if args.stateless:
        result = run_stateless_turn(item, room_id, room_name, guide, args)
        session_id = result.thread_id or "stateless"
    else:
        session_id = get_or_create_session(room_key, room_id, room_name, guide, args)
        prompt = build_turn_prompt(item, room_id, room_name)

        try:
            result = resume_session(session_id, prompt, args, item)
        except WorkerError as exc:
            if not is_missing_session_error(str(exc)):
                raise
            log(f"session missing; recreating room={room_key}")
            session_id = create_session(room_key, room_id, room_name, guide, args)
            result = resume_session(session_id, prompt, args, item)

    def continue_full(prompt_body: str) -> CodexResult:
        nonlocal session_id
        if args.stateless:
            followup = run_stateless_prompt(prompt_body, guide, args, item)
            session_id = followup.thread_id or session_id or "stateless"
            return followup
        return resume_session(session_id, prompt_body, args, item)

    pipeline = finish_codex_pipeline_from_result(
        req_id,
        item,
        room_id,
        room_name,
        room_key,
        session_id,
        result,
        args,
        continue_full,
        audit_actions=audit_actions,
        allow_direct_mcp_retry=True,
        route_metadata=route_metadata,
    )
    pipeline["route_metadata"] = route_metadata
    if fast_brain_fallback_reason:
        brain_metadata = dict(pipeline.get("brain_metadata") if isinstance(pipeline.get("brain_metadata"), dict) else {})
        brain_metadata.update(
            {
                "fallback_used": True,
                "escalation_used": True,
                "fast_brain_fallback_reason": fast_brain_fallback_reason,
                "fast_brain_escalation_reason": fast_brain_fallback_reason,
            }
        )
        pipeline["brain_metadata"] = compact_payload(brain_metadata, 1200)
        pipeline.update(codex_result_route_metadata(CodexResult("", None, metadata=brain_metadata)))
    return pipeline


def process_one(req_id: str, item: dict[str, Any], guide: str, args: argparse.Namespace) -> None:
    run_args = effective_request_args(item, args)
    item = dict(item)
    room_id = str(item.get("room_id") or item.get("room") or "default")
    room_name = str(item.get("room_name") or item.get("roomTitle") or room_id)
    room_key = sanitize_key(room_id or room_name)
    route_metadata = plan_storebot_capability_route(item)
    event_id = append_room_event_journal(req_id, item, run_args, route_metadata=route_metadata)
    item["_room_event_id"] = event_id
    explicit_field_name, explicit_actions = explicit_local_direct_action_list(item)
    if explicit_actions and item.get("local_direct") is not True:
        mirror_briefing_channel_inbound(req_id, item, run_args)
        pickup_started = now_ms()
        safe_record_stage(
            req_id,
            item,
            run_args,
            "worker_pickup",
            "started",
            message="poll worker accepted explicit action request",
            evidence_key=event_id,
        )
        mark_running(req_id, run_args, item)
        mark_reclaimed_running(req_id, item, run_args)
        safe_record_stage(
            req_id,
            item,
            run_args,
            "worker_pickup",
            "done",
            message="explicit action request marked running",
            evidence_key=event_id,
            elapsed_ms=now_ms() - pickup_started,
        )
        explicit_item, pipeline = run_local_direct_explicit_actions(
            req_id,
            item,
            run_args,
            route_metadata=route_metadata,
        )
        safe_record_stage(
            req_id,
            item,
            run_args,
            "outbound_publish",
            "error"
            if any(result.get("ok") is not True for result in action_results_list(pipeline.get("last_action_results")))
            or bool(
                (pipeline.get("brain_metadata") if isinstance(pipeline.get("brain_metadata"), dict) else {}).get(
                    "explicit_action_block_reason"
                )
            )
            else "skipped",
            message="explicit action blocked"
            if any(result.get("ok") is not True for result in action_results_list(pipeline.get("last_action_results")))
            or bool(
                (pipeline.get("brain_metadata") if isinstance(pipeline.get("brain_metadata"), dict) else {}).get(
                    "explicit_action_block_reason"
                )
            )
            else "explicit action result ready",
            evidence={
                "explicit_action_field": explicit_field_name,
                "explicit_action_count": len(explicit_actions),
                "output_category": pipeline.get("output_category") or "skip",
            },
        )
        finalize_explicit_local_direct_poll_request(
            req_id,
            item,
            explicit_item,
            pipeline,
            run_args,
            guide,
            route_metadata=route_metadata,
            event_id=event_id,
        )
        return
    stale_reason = stale_schedule_event_reason(item)
    if stale_reason:
        mark_stale_schedule_done(req_id, item, stale_reason, run_args)
        write_reconciliation_status(
            req_id,
            item,
            run_args,
            status="matched",
            event_id=event_id,
            ledger_ids=[],
            route_metadata=route_metadata,
        )
        try:
            write_learning_stamp(
                req_id,
                build_learning_stamp(
                    req_id,
                    item,
                    run_args,
                    guide,
                    decision="stale_schedule_skip",
                    skipped=True,
                    publish_disabled=True,
                ),
                run_args,
            )
        except Exception as exc:
            log(f"stale schedule stamp failed request={req_id}: {compact_error(str(exc), 200)}")
        log(f"stale schedule skipped request={req_id} reason={stale_reason}")
        return
    no_reply_reason = storebot_contextless_no_reply_reason(item)
    if no_reply_reason:
        mark_done(
            req_id,
            "SKIP",
            "",
            None,
            True,
            True,
            run_args,
            output_category="skip",
            output_payload={
                "reason": no_reply_reason,
                "event_kind": request_event_kind(item),
                "reply_policy": "no_reply_without_user_context",
            },
            route_metadata=route_metadata,
            item=item,
        )
        write_reconciliation_status(
            req_id,
            item,
            run_args,
            status="matched",
            event_id=event_id,
            ledger_ids=[],
            route_metadata=route_metadata,
        )
        safe_record_stage(req_id, item, run_args, "outbound_publish", "skipped", message=no_reply_reason)
        try:
            write_learning_stamp(
                req_id,
                build_learning_stamp(
                    req_id,
                    item,
                    run_args,
                    guide,
                    decision="contextless_no_reply_skip",
                    answer="SKIP",
                    skipped=True,
                    publish_disabled=True,
                ),
                run_args,
            )
        except Exception as exc:
            log(f"contextless no-reply stamp failed request={req_id}: {compact_error(str(exc), 200)}")
        log(f"contextless event skipped request={req_id} reason={no_reply_reason}")
        return
    screen_noise_reason = kakao_screen_noise_reason(item)
    if screen_noise_reason:
        mark_screen_noise_done(req_id, item, screen_noise_reason, run_args)
        write_reconciliation_status(
            req_id,
            item,
            run_args,
            status="matched",
            event_id=event_id,
            ledger_ids=[],
            route_metadata=route_metadata,
        )
        try:
            write_learning_stamp(
                req_id,
                build_learning_stamp(
                    req_id,
                    item,
                    run_args,
                    guide,
                    decision="screen_noise_skip",
                    skipped=True,
                    publish_disabled=True,
                ),
                run_args,
            )
        except Exception as exc:
            log(f"screen noise stamp failed request={req_id}: {compact_error(str(exc), 200)}")
        log(f"screen noise skipped request={req_id} reason={screen_noise_reason}")
        return
    pickup_started = now_ms()
    safe_record_stage(
        req_id,
        item,
        run_args,
        "worker_pickup",
        "started",
        message="poll worker accepted request",
        evidence_key=event_id,
    )
    mark_running(req_id, run_args, item)
    mark_reclaimed_running(req_id, item, run_args)
    safe_record_stage(
        req_id,
        item,
        run_args,
        "worker_pickup",
        "done",
        message="request marked running",
        evidence_key=event_id,
        elapsed_ms=now_ms() - pickup_started,
    )

    if request_event_kind(item) == WORK_SCHEDULE_BROADCAST_EVENT_KIND:
        if maybe_process_work_schedule_broadcast_model0_fallback(
            req_id,
            item,
            None,
            run_args,
            route_metadata=route_metadata,
            event_id=event_id,
            primary_route=True,
        ):
            return
        raise WorkerError("model0 schedule primary route did not handle fixed broadcast event")

    try:
        pipeline = run_codex_pipeline(req_id, item, guide, run_args, audit_actions=True, route_metadata=route_metadata)
    except WorkerError as exc:
        if maybe_process_work_schedule_broadcast_model0_fallback(
            req_id,
            item,
            exc,
            run_args,
            route_metadata=route_metadata,
            event_id=event_id,
        ):
            return
        raise
    answer = str(pipeline["answer"])
    skipped = bool(pipeline["skipped"])
    image_request = None
    if not skipped:
        schedule_image_needed = should_build_schedule_image_request(item, answer)
        realtime_started = now_ms()
        if schedule_image_needed:
            safe_record_stage(
                req_id,
                item,
                run_args,
                "realtime_data",
                "started",
                message="schedule realtime context collection started",
            )
            safe_record_stage(
                req_id,
                item,
                run_args,
                "image_build",
                "started",
                message="schedule image_request build started",
            )
        try:
            image_result = build_schedule_image_request_result(item, answer, req_id=req_id, args=run_args)
            if image_result.incomplete:
                safe_record_stage(
                    req_id,
                    item,
                    run_args,
                    "realtime_data",
                    "error",
                    message="required schedule realtime sections incomplete",
                    evidence=image_result.incomplete,
                    elapsed_ms=now_ms() - realtime_started,
                    retry_count=1,
                )
                safe_record_stage(
                    req_id,
                    item,
                    run_args,
                    "image_build",
                    "error",
                    message="schedule image_request blocked by incomplete realtime data",
                    evidence=image_result.incomplete,
                    elapsed_ms=now_ms() - realtime_started,
                    retry_count=1,
                )
                pipeline = dict(pipeline)
                incomplete_output = schedule_realtime_incomplete_output(
                    image_result.incomplete,
                    self_fix_request_id=image_result.self_fix_request_id,
                )
                pipeline["answer"] = ""
                pipeline["skipped"] = True
                pipeline["output_category"] = "schedule_realtime_incomplete"
                pipeline["output_payload"] = incomplete_output
                pipeline["self_fix_request_id"] = image_result.self_fix_request_id
                answer = ""
                skipped = True
                log(
                    "schedule image incomplete blocked request="
                    f"{req_id} missing={','.join(incomplete_output.get('missing_sections') or [])} "
                    f"self_fix={image_result.self_fix_request_id}"
                )
            else:
                image_request = image_result.image_request
                if schedule_image_needed:
                    realtime_evidence = {}
                    if isinstance(image_request, dict) and isinstance(image_request.get("payload"), dict):
                        realtime_evidence = schedule_realtime_payload_metadata(image_request, image_request["payload"])
                    safe_record_stage(
                        req_id,
                        item,
                        run_args,
                        "realtime_data",
                        "done",
                        message="schedule realtime context attached",
                        evidence=realtime_evidence,
                        elapsed_ms=now_ms() - realtime_started,
                        retry_count=1 if isinstance(image_request, dict)
                        and isinstance(image_request.get("payload"), dict)
                        and isinstance(image_request["payload"].get("schedule_realtime_retry"), dict)
                        else 0,
                    )
                    safe_record_stage(
                        req_id,
                        item,
                        run_args,
                        "image_build",
                        "done",
                        message=(
                            "schedule image_request ready"
                            if image_request
                            else "schedule image_request suppressed"
                            if image_result.suppressed_reason
                            else "schedule image_request not required"
                        ),
                        evidence={
                            "image_request_type": image_request.get("type") if isinstance(image_request, dict) else "",
                            "image_payload_source": image_request.get("image_payload_source") if isinstance(image_request, dict) else "",
                            "image_request_suppressed_reason": image_result.suppressed_reason,
                            "image_request_dedupe_key": image_result.dedupe_key,
                        },
                        elapsed_ms=now_ms() - realtime_started,
                    )
                    if image_result.suppressed_reason:
                        pipeline = mark_schedule_image_pending_pipeline(
                            annotate_schedule_image_suppression(pipeline, image_result),
                            image_result.suppressed_reason,
                            detail=image_result.suppressed_detail,
                            dedupe_key=image_result.dedupe_key,
                        )
                        answer = ""
                        skipped = True
                fallback_answer = schedule_text_fallback_from_image_request(image_request)
                if fallback_answer:
                    answer = fallback_answer
                    pipeline = dict(pipeline)
                    pipeline["answer"] = answer
                    pipeline["schedule_text_fallback"] = True
                if image_request:
                    pipeline = dict(pipeline)
                    pipeline["image_request"] = image_request
                    pipeline["image_required"] = True
                    pipeline["image_send_policy"] = "image_first"
        except Exception as exc:
            log(f"poll image request build failed request={req_id}: {compact_error(str(exc), 200)}")
            if schedule_image_needed:
                validation = schedule_image_build_exception_validation(exc, stage="poll_image_request_build")
                safe_record_stage(
                    req_id,
                    item,
                    run_args,
                    "realtime_data",
                    "error",
                    message="schedule realtime/image build exception",
                    evidence=validation,
                    elapsed_ms=now_ms() - realtime_started,
                )
                safe_record_stage(
                    req_id,
                    item,
                    run_args,
                    "image_build",
                    "error",
                    message="schedule image_request build exception",
                    evidence=validation,
                    elapsed_ms=now_ms() - realtime_started,
                )
                self_fix_id = ""
                try:
                    self_fix_id = enqueue_schedule_realtime_incomplete_self_fix(req_id, item, validation, run_args)
                except Exception as enqueue_exc:
                    log(f"poll image exception self_fix enqueue failed request={req_id}: {compact_error(str(enqueue_exc), 200)}")
                pipeline = dict(pipeline)
                pipeline["answer"] = ""
                pipeline["skipped"] = True
                pipeline["output_category"] = "schedule_realtime_incomplete"
                pipeline["output_payload"] = schedule_realtime_incomplete_output(validation, self_fix_id)
                pipeline["self_fix_request_id"] = self_fix_id
                answer = ""
                skipped = True
    session_id = str(pipeline["session_id"])
    action_count = int(pipeline["action_count"])
    action_ok_count = int(pipeline["action_ok_count"])
    action_error_count = int(pipeline["action_error_count"])
    output_category = str(pipeline.get("output_category") or ("skip" if skipped else "kakao_reply"))
    output_payload = pipeline.get("output_payload") if isinstance(pipeline.get("output_payload"), dict) else {}
    self_fix_request_id = str(pipeline.get("self_fix_request_id") or "")
    clean_reply_metadata = validate_clean_reply_contract(
        reply_candidate_texts(answer),
        skipped=skipped,
        has_image_request=isinstance(image_request, dict) and bool(image_request),
        output_category=output_category,
    )
    clean_reply_block_reason = str(clean_reply_metadata.get("clean_reply_block_reason") or "")
    if clean_reply_block_reason:
        answer = ""
        skipped = True
        output_category = "report"
        pipeline = dict(pipeline)
        pipeline["answer"] = ""
        pipeline["skipped"] = True
        pipeline["output_category"] = output_category
        pipeline["reply_contract_violation"] = True
        pipeline["skip_reason"] = clean_reply_block_reason
        safe_record_stage(
            req_id,
            item,
            run_args,
            "clean_reply_gate",
            "blocked",
            message="clean reply contract blocked outbound candidate",
            evidence={key: value for key, value in clean_reply_metadata.items() if key != "reply_text_sha256"},
        )
    publish_disabled = request_publish_disabled(args, item)
    outbound_key = None
    if skipped:
        safe_record_stage(req_id, item, run_args, "outbound_publish", "skipped", message="output skipped")
    elif publish_disabled:
        safe_record_stage(req_id, item, run_args, "outbound_publish", "skipped", message="publish disabled")
    else:
        outbound_started = now_ms()
        safe_record_stage(req_id, item, run_args, "outbound_publish", "started", message="pending queue publish started")
        try:
            outbound_key = publish_reply(req_id, item, answer, image_request=image_request)
            safe_record_stage(
                req_id,
                item,
                run_args,
                "outbound_publish",
                "done",
                message="pending queue publish done",
                evidence={
                    "outbound_key": outbound_key,
                    "image_required": bool(image_request),
                    "image_request_type": image_request.get("type") if isinstance(image_request, dict) else "",
                },
                elapsed_ms=now_ms() - outbound_started,
            )
        except Exception as exc:
            safe_record_stage(
                req_id,
                item,
                run_args,
                "outbound_publish",
                "error",
                message="pending queue publish failed",
                evidence={"error": compact_error(str(exc), 500), "image_required": bool(image_request)},
                elapsed_ms=now_ms() - outbound_started,
            )
            raise
    if not args.stateless and not session_id.startswith(("fast_router:", "resident_cli:")):
        fb_patch(
            f"{SESSIONS_PATH}/{room_key}",
            {
                "session_id": session_id,
                "room_id": room_id,
                "room_name": room_name,
                "updated_at_ms": now_ms(),
                "last_request_id": req_id,
                "model": model_label(run_args),
                "reasoning_effort": reasoning_label(run_args),
                "model_override_reason": getattr(run_args, "model_override_reason", ""),
            },
        )
    elif session_id.startswith(("fast_router:", "resident_cli:")):
        resident_cli = session_id.startswith("resident_cli:")
        route_session_id = session_id.removeprefix("resident_cli:" if resident_cli else "fast_router:")
        route_payload = {
            "room_id": room_id,
            "room_name": room_name,
            "updated_at_ms": now_ms(),
            "last_request_id": req_id,
            "last_reply_route": "resident_cli_direct" if resident_cli else "fast_router",
            "model": model_label(run_args),
            "reasoning_effort": reasoning_label(run_args),
            "model_override_reason": getattr(run_args, "model_override_reason", ""),
        }
        if resident_cli:
            route_payload.update(
                {
                    "last_resident_cli_session_id": route_session_id,
                    "last_resident_cli_at_ms": now_ms(),
                    "last_worker_role": "thin_bridge",
                }
            )
        else:
            route_payload.update(
                {
                    "last_fast_router_session_id": route_session_id,
                    "last_fast_router_at_ms": now_ms(),
                }
            )
        fb_patch(
            f"{SESSIONS_PATH}/{room_key}",
            route_payload,
        )
    mark_done(
        req_id,
        answer,
        session_id,
        outbound_key,
        skipped,
        publish_disabled,
        run_args,
        output_category=output_category,
        output_payload=output_payload,
        self_fix_request_id=self_fix_request_id,
        route_metadata=pipeline.get("route_metadata") if isinstance(pipeline.get("route_metadata"), dict) else None,
        image_request=image_request,
        image_required=bool(image_request),
        image_send_policy=str(image_request.get("send_policy") or "image_first") if isinstance(image_request, dict) else "",
        image_request_suppressed_reason=str(pipeline.get("image_request_suppressed_reason") or ""),
        image_request_suppressed_detail=str(pipeline.get("image_request_suppressed_detail") or ""),
        image_request_dedupe_key=str(pipeline.get("image_request_dedupe_key") or ""),
        item=item,
        clean_reply_block_reason=clean_reply_block_reason,
        brain_metadata=pipeline.get("brain_metadata") if isinstance(pipeline.get("brain_metadata"), dict) else {},
    )
    ledger_ids = [
        str(result.get("ledger_id"))
        for result in action_results_list(pipeline.get("last_action_results"))
        if str(result.get("ledger_id") or "").strip()
    ]
    decision_ledger_id = append_decision_ledger(
        req_id,
        item,
        pipeline,
        run_args,
        event_id=event_id,
        route_metadata=pipeline.get("route_metadata") if isinstance(pipeline.get("route_metadata"), dict) else route_metadata,
    )
    if decision_ledger_id:
        ledger_ids.append(decision_ledger_id)
    final_route_metadata = pipeline.get("route_metadata") if isinstance(pipeline.get("route_metadata"), dict) else route_metadata
    write_reconciliation_status(
        req_id,
        item,
        run_args,
        status=reconciliation_status_for_pipeline(final_route_metadata, ledger_ids),
        event_id=event_id,
        ledger_ids=ledger_ids,
        route_metadata=final_route_metadata,
    )
    save_room_turn_context(
        req_id,
        item,
        pipeline,
        answer,
        skipped=skipped,
        publish_disabled=publish_disabled,
        args=run_args,
    )
    decision = stamp_decision(skipped, outbound_key, action_count)
    learning_suppression = request_learning_suppression_context(run_args, item)
    if learning_suppression:
        mark_learning_stamp_status(req_id, run_args, "skipped", error=learning_suppression["learning_write_skipped_reason"])
    else:
        try:
            write_learning_stamp(
                req_id,
                build_learning_stamp(
                    req_id,
                    item,
                    run_args,
                    guide,
                    decision=decision,
                    answer=answer,
                    session_id=session_id,
                    outbound_key=outbound_key,
                    skipped=skipped,
                    publish_disabled=publish_disabled,
                    action_count=action_count,
                    action_ok_count=action_ok_count,
                    action_error_count=action_error_count,
                ),
                run_args,
            )
        except Exception as exc:
            log(f"learning stamp write failed request={req_id}: {compact_error(str(exc), 200)}")
            mark_learning_stamp_status(req_id, run_args, "error", error=str(exc))
    state = "skipped" if skipped else "reply_no_publish" if publish_disabled else f"published={outbound_key}"
    log(f"done request={req_id} room={room_key} {state}")


def process_confirmed_schedule_queue_item(req_id: str, item: dict[str, Any], args: argparse.Namespace) -> None:
    request = dict(item)
    request.setdefault("request_id", str(item.get("request_id") or req_id))
    mark_running(req_id, args, request)
    mark_reclaimed_running(req_id, request, args)
    result = execute_confirmed_schedule_write_request(request, req_id=req_id, args=args)
    mark_confirmed_schedule_done(req_id, request, result, args)
    mode = "dry_run" if result.get("dry_run") else "live_write"
    operation = str(result.get("schedule_operation") or result.get("operation") or "")
    log(f"done confirmed schedule request={req_id} mode={mode} operation={operation}")


def local_direct_decision(skipped: bool, action_count: int) -> str:
    if skipped:
        return "local_direct_skip"
    if action_count > 0:
        return "local_direct_action_reply"
    return "local_direct_reply"


def reply_contract_fields(item: dict[str, Any]) -> dict[str, Any]:
    return {
        "turn_seq": safe_int(item.get("turn_seq")),
        "correlation_id": str(item.get("correlation_id") or ""),
        "session_lease": str(item.get("session_lease") or ""),
        "fencing_token": str(item.get("fencing_token") or ""),
        "reply_contract_version": STOREBOT_REPLY_CONTRACT_VERSION,
        "dedicated_room": bool(item.get("dedicated_room") is True),
    }


def unsafe_reply_reason(text: str) -> str:
    reply = str(text or "").strip()
    if not reply:
        return "reply_empty"
    if len(reply) > STOREBOT_REPLY_MAX_CHARS:
        return f"reply_too_long_{len(reply)}"
    lower = reply.lower()
    compact = reply.replace("\r", "").strip()
    if compact.startswith("```") or compact.endswith("```"):
        return "reply_code_fence"
    if compact.startswith("{") or compact.startswith("[") or compact.startswith('"'):
        return "reply_json_or_trace_like"
    if looks_like_action_protocol(reply) or looks_like_storebot_output_protocol(reply):
        return "reply_internal_protocol"
    markers = (
        "storebot_actions",
        "storebot_output",
        "tool_call",
        "tool trace",
        "system:",
        "assistant:",
        "stdout",
        "stderr",
        "traceback",
        "```json",
    )
    for marker in markers:
        if marker in lower:
            return f"reply_marker_{sanitize_key(marker, 'marker')}"
    return ""


def clean_reply_sha256(text: str) -> str:
    return hashlib.sha256(str(text or "").encode("utf-8")).hexdigest() if text else ""


def reply_candidate_texts(value: Any) -> list[str]:
    if value is None:
        return []
    if isinstance(value, str):
        text = value.strip()
        return [text] if text else []
    if isinstance(value, list):
        result: list[str] = []
        for item in value:
            if isinstance(item, str):
                text = item.strip()
            elif isinstance(item, dict):
                text = str(item.get("reply_text") or item.get("reply") or item.get("text") or "").strip()
            else:
                text = str(item or "").strip()
            if text:
                result.append(text)
        return result
    if isinstance(value, dict):
        return reply_candidate_texts(value.get("reply_candidates") or value.get("candidates") or value.get("reply_text") or value.get("reply"))
    text = str(value or "").strip()
    return [text] if text else []


def request_contract_mismatch_reason(contracted: dict[str, Any], item: dict[str, Any]) -> str:
    for key in ("turn_seq", "correlation_id", "session_lease", "fencing_token"):
        if key not in contracted or contracted.get(key) in (None, ""):
            continue
        expected = safe_int(item.get(key)) if key == "turn_seq" else str(item.get(key) or "")
        actual = safe_int(contracted.get(key)) if key == "turn_seq" else str(contracted.get(key) or "")
        if expected not in (None, "") and actual != expected:
            return f"reply_contract_{key}_mismatch"
    return ""


def validate_clean_reply_contract(
    candidates: list[str],
    *,
    skipped: bool = False,
    has_image_request: bool = False,
    output_category: str = "",
    mismatch_reason: str = "",
) -> dict[str, Any]:
    normalized = [str(item or "").strip() for item in candidates if str(item or "").strip()]
    category = str(output_category or "").strip().lower()
    validation_required = not skipped and not has_image_request and category not in {"skip", "report", "log_only", "self_heal", "self_fix"}
    reason = str(mismatch_reason or "")
    if not reason and validation_required:
        if len(normalized) != 1:
            reason = "reply_candidate_count_invalid" if normalized else "reply_empty"
        else:
            reason = unsafe_reply_reason(normalized[0])
    valid = not reason
    reply_text = normalized[0] if len(normalized) == 1 else ""
    return {
        "reply_contract_version": STOREBOT_REPLY_CONTRACT_VERSION,
        "reply_contract_valid": valid,
        "clean_reply_gate_passed": valid,
        "clean_reply_block_reason": reason,
        "reply_text_len": len(reply_text) if valid else 0,
        "reply_text_sha256": clean_reply_sha256(reply_text) if valid else "",
        "reply_text_candidate_count": len(normalized),
        "reply_text_redacted": True,
    }


def apply_clean_reply_contract_metadata(
    payload: dict[str, Any],
    answer: str,
    item: dict[str, Any] | None,
    *,
    skipped: bool,
    output_category: str,
    has_image_request: bool = False,
    publish_disabled: bool = False,
    block_reason: str = "",
) -> None:
    payload.update(reply_contract_fields(item or {}))
    metadata = validate_clean_reply_contract(
        reply_candidate_texts(answer),
        skipped=skipped,
        has_image_request=has_image_request,
        output_category=output_category,
        mismatch_reason=block_reason,
    )
    payload.update(metadata)
    payload["reply_envelope"] = {
        "version": STOREBOT_REPLY_CONTRACT_VERSION,
        "reply_text": None,
        "reply_text_redacted": True,
        "reply_text_len": metadata["reply_text_len"],
        "reply_text_sha256": metadata["reply_text_sha256"],
        "candidate_count": metadata["reply_text_candidate_count"],
        "clean_reply_gate_passed": metadata["clean_reply_gate_passed"],
        "clean_reply_block_reason": metadata["clean_reply_block_reason"],
        "no_send_reason": "publish_disabled" if publish_disabled else str(payload.get("skip_reason") or ""),
    }


def attach_storebot_reply_contract(response: dict[str, Any], item: dict[str, Any], args: argparse.Namespace) -> dict[str, Any]:
    contracted = dict(response)
    contracted.update(reply_contract_fields(item))
    contracted["bridge_mode"] = STOREBOT_BRIDGE_MODE
    contracted["reply_source"] = str(contracted.get("reply_source") or "reply_envelope")
    contracted["stdout_log_separated"] = True
    contracted["bounded_worker_exec_fallback"] = bool(
        contracted.get("fallback_used") is True
        or fast_router_stateless_exec_enabled()
        or resident_exec_fallback_enabled()
    )
    contracted["default_model_policy"] = {
        "default_model": model_label(args),
        "default_reasoning_effort": reasoning_label(args),
        "policy": "thin_bridge_cli_direct_resident_required",
        "worker_role": "thin_bridge",
        "api_fast_brain_guard": "STOREBOT_FAST_BRAIN_GUARDED_HOT_PATH",
        "api_fast_brain_default": False,
        "api_fast_brain_hot_path": bool(guarded_fast_brain_hot_path_enabled()),
        "exec_fallback_default": bool(resident_exec_fallback_enabled()),
    }
    skipped = bool(contracted.get("skipped"))
    reply_text = str(contracted.get("reply") or "").strip()
    category = str(contracted.get("output_category") or "").strip().lower()
    has_image_request = isinstance(contracted.get("image_request"), dict)
    candidate_source = contracted.get("reply_candidates")
    if candidate_source is None and isinstance(contracted.get("reply_envelope"), dict):
        candidate_source = contracted["reply_envelope"].get("reply_candidates")
    candidates = reply_candidate_texts(candidate_source if candidate_source is not None else reply_text)
    metadata = validate_clean_reply_contract(
        candidates,
        skipped=skipped,
        has_image_request=has_image_request,
        output_category=category,
        mismatch_reason=request_contract_mismatch_reason(response, item),
    )
    reason = str(metadata.get("clean_reply_block_reason") or "")
    if reason:
        contracted["reply"] = ""
        contracted["skipped"] = True
        contracted["skip_reason"] = reason
        contracted["output_category"] = "report"
        contracted["reply_contract_violation"] = True
        reply_text = ""
        candidates = []
    else:
        reply_text = candidates[0] if candidates else ""
    contracted.update(metadata)
    contracted["reply_envelope"] = {
        "version": STOREBOT_REPLY_CONTRACT_VERSION,
        "reply_text": reply_text or None,
        "reply_text_redacted": not bool(reply_text),
        "reply_text_len": metadata["reply_text_len"],
        "reply_text_sha256": metadata["reply_text_sha256"],
        "candidate_count": metadata["reply_text_candidate_count"],
        "clean_reply_gate_passed": metadata["clean_reply_gate_passed"],
        "clean_reply_block_reason": metadata["clean_reply_block_reason"],
        "no_send_reason": str(contracted.get("skip_reason") or reason or ""),
    }
    return contracted


def local_direct_sync_timeout_sec() -> float:
    try:
        return max(0.0, float(os.environ.get("STOREBOT_CODEX_LOCAL_DIRECT_SYNC_TIMEOUT_SEC", "0")))
    except (TypeError, ValueError):
        return 0.0


def local_direct_deferred_publish_enabled() -> bool:
    # Deprecated permanently: late local-direct results must never re-enter the publish queue.
    return False


def read_telegram_backplane_identity_key_file() -> bytes | None:
    key_path = str(os.environ.get("STOREBOT_TELEGRAM_BACKPLANE_IDENTITY_KEY_FILE") or "").strip()
    if not key_path:
        return None
    flags = os.O_RDONLY | getattr(os, "O_CLOEXEC", 0) | getattr(os, "O_NOFOLLOW", 0)
    try:
        descriptor = os.open(key_path, flags)
    except OSError:
        return None
    try:
        metadata = os.fstat(descriptor)
        if not stat.S_ISREG(metadata.st_mode) or stat.S_IMODE(metadata.st_mode) != 0o600:
            return None
        if metadata.st_size < 32 or metadata.st_size > 4096:
            return None
        value = os.read(descriptor, 4097)
        if len(value) < 32 or len(value) > 4096:
            return None
        return value
    except OSError:
        return None
    finally:
        os.close(descriptor)


def telegram_backplane_worker_adapter() -> StoreBotTelegramWorkerAdapter | None:
    if env_bool("STOREBOT_TELEGRAM_BACKPLANE_KILL_SWITCH", False):
        return None
    if not env_bool("STOREBOT_TELEGRAM_BACKPLANE_DRY_RUN", False):
        return None
    if StoreBotTelegramWorkerAdapter is None:
        return None
    identity_key = read_telegram_backplane_identity_key_file()
    if identity_key is None:
        return None
    key_hash = hashlib.sha256(identity_key).hexdigest()
    global _TELEGRAM_BACKPLANE_ADAPTER, _TELEGRAM_BACKPLANE_ADAPTER_KEY_HASH
    with _TELEGRAM_BACKPLANE_ADAPTER_LOCK:
        if _TELEGRAM_BACKPLANE_ADAPTER is None or _TELEGRAM_BACKPLANE_ADAPTER_KEY_HASH != key_hash:
            _TELEGRAM_BACKPLANE_ADAPTER = StoreBotTelegramWorkerAdapter(
                enabled=True,
                identity_key=identity_key,
            )
            _TELEGRAM_BACKPLANE_ADAPTER_KEY_HASH = key_hash
        return _TELEGRAM_BACKPLANE_ADAPTER


def build_telegram_backplane_failure_envelope(
    req_id: str,
    item: dict[str, Any],
    failure_kind: str,
    event_at_ms: int,
) -> dict[str, Any] | None:
    adapter = telegram_backplane_worker_adapter()
    if adapter is None:
        return None
    try:
        trusted_item = dict(item)
        trusted_item["_backplane_trusted_source"] = "storebot_codex_worker_local_direct"
        trusted_item["_backplane_source_capability"] = "storebot_telegram_projection_v1"
        return adapter.observe_local_direct_failure(
            request_id=req_id,
            item=trusted_item,
            failure_kind=failure_kind,
            now_ms=int(event_at_ms),
        )
    except Exception as exc:
        log(f"telegram backplane proposal rejected: {compact_error(str(exc), 160)}")
        return None


def mark_local_direct_deferred(req_id: str) -> None:
    if not req_id:
        return
    with _LOCAL_DIRECT_DEFERRED_LOCK:
        _LOCAL_DIRECT_DEFERRED_REQUESTS.add(req_id)


def pop_local_direct_deferred(req_id: str) -> bool:
    if not req_id:
        return False
    with _LOCAL_DIRECT_DEFERRED_LOCK:
        if req_id not in _LOCAL_DIRECT_DEFERRED_REQUESTS:
            return False
        _LOCAL_DIRECT_DEFERRED_REQUESTS.remove(req_id)
        return True


def is_local_direct_deferred(req_id: str) -> bool:
    if not req_id:
        return False
    with _LOCAL_DIRECT_DEFERRED_LOCK:
        return req_id in _LOCAL_DIRECT_DEFERRED_REQUESTS


def mirror_local_direct_deferred(req_id: str, item: dict[str, Any], args: argparse.Namespace, elapsed_ms: int) -> None:
    if not req_id or not isinstance(item, dict) or not item:
        return
    payload = dict(item)
    payload.update(
        {
            "status": "running",
            "source": str(item.get("source") or "storebot_android") + "_local_direct",
            "updated_at_ms": now_ms(),
            "worker": args.node,
            "model": model_label(args),
            "reasoning_effort": reasoning_label(args),
            "reply_skipped": False,
            "publish_disabled": True,
            "local_direct": True,
            "local_direct_deferred": True,
            "local_direct_elapsed_ms": elapsed_ms,
            "output_category": "system_progress",
            "reply": local_direct_deferred_reply(),
        }
    )
    apply_request_side_effect_safety(payload, item)
    try:
        fb_put(f"{REQUESTS_PATH}/{sanitize_key(req_id, 'local_direct')}", payload)
    except Exception as exc:
        log(f"local-direct deferred mirror failed request={req_id}: {compact_error(str(exc), 200)}")


def mirror_local_direct_result(
    req_id: str,
    item: dict[str, Any],
    guide: str,
    pipeline: dict[str, Any],
    args: argparse.Namespace,
    elapsed_ms: int,
) -> None:
    answer = str(pipeline.get("answer") or "")
    skipped = bool(pipeline.get("skipped"))
    action_count = int(pipeline.get("action_count") or 0)
    action_ok_count = int(pipeline.get("action_ok_count") or 0)
    action_error_count = int(pipeline.get("action_error_count") or 0)
    direct_tool_count = int(pipeline.get("direct_tool_count") or 0)
    session_id = str(pipeline.get("session_id") or "")
    output_category = str(pipeline.get("output_category") or ("skip" if skipped else "kakao_reply"))
    output_payload = pipeline.get("output_payload") if isinstance(pipeline.get("output_payload"), dict) else {}
    image_request = pipeline.get("image_request") if isinstance(pipeline.get("image_request"), dict) else None
    self_fix_request_id = str(pipeline.get("self_fix_request_id") or "")
    route_metadata = pipeline.get("route_metadata") if isinstance(pipeline.get("route_metadata"), dict) else {}
    brain_metadata = pipeline.get("brain_metadata") if isinstance(pipeline.get("brain_metadata"), dict) else {}
    event_id = str(item.get("_room_event_id") or "")
    deferred = pop_local_direct_deferred(req_id)
    outbound_key = None
    publish_disabled = True
    if (
        deferred
        and local_direct_deferred_publish_enabled()
        and not skipped
        and answer
        and not request_publish_disabled(args, item)
        and item.get("dry_run") is not True
    ):
        try:
            outbound_key = publish_reply(req_id, item, answer, image_request=image_request)
            publish_disabled = False
            log(f"local-direct deferred result published request={req_id} outbound={outbound_key}")
        except Exception as exc:
            log(f"local-direct deferred publish failed request={req_id}: {compact_error(str(exc), 200)}")
    elif deferred and answer and not skipped:
        log(f"local-direct deferred result mirrored without pending publish request={req_id}")
    if deferred:
        response = {
            "ok": True,
            "request_id": req_id,
            "reply": answer,
            "skipped": skipped,
            "output_category": output_category,
            "self_fix_request_id": self_fix_request_id,
            "session_id": session_id,
            "model": model_label(args),
            "reasoning_effort": reasoning_label(args),
            "action_count": action_count,
            "action_ok_count": action_ok_count,
            "action_error_count": action_error_count,
            "direct_tool_count": direct_tool_count,
            "elapsed_ms": elapsed_ms,
        }
        if brain_metadata:
            response.update(compact_payload(brain_metadata, 1200))
        if image_request:
            response["image_request"] = image_request
            response["image_required"] = True
            response["image_send_policy"] = "image_first"
        attach_image_request_suppression_metadata(response, pipeline)
        if route_metadata:
            response["route_metadata"] = compact_payload(route_metadata, 3000)
        apply_request_side_effect_safety(response, item)
        mirror_briefing_channel_outbound(req_id, item, args, response)
    payload = dict(item)
    payload.update(
        {
            "status": "done",
            "source": str(item.get("source") or "storebot_android") + "_local_direct",
            "finished_at_ms": now_ms(),
            "worker": args.node,
            "model": model_label(args),
            "reasoning_effort": reasoning_label(args),
            "model_override_reason": getattr(args, "model_override_reason", ""),
            "session_id": session_id,
            "reply_skipped": skipped,
            "publish_disabled": publish_disabled,
            "local_direct": True,
            "local_direct_deferred": deferred,
            "local_direct_elapsed_ms": elapsed_ms,
            "action_count": action_count,
            "action_ok_count": action_ok_count,
            "action_error_count": action_error_count,
            "direct_tool_count": direct_tool_count,
            "output_category": output_category,
            "self_fix_request_id": self_fix_request_id,
        }
    )
    apply_request_side_effect_safety(payload, item)
    payload.update(request_learning_suppression_context(args, item))
    if outbound_key:
        payload["outbound_key"] = outbound_key
    if output_payload:
        payload["output_payload"] = compact_payload(output_payload, 3000)
    if output_category == "schedule_realtime_incomplete":
        payload["data_status"] = "schedule_realtime_incomplete"
        payload["processing_status"] = "schedule_realtime_incomplete"
        payload["schedule_realtime_incomplete"] = True
    if route_metadata:
        payload["route_metadata"] = compact_payload(route_metadata, 3000)
    if brain_metadata:
        payload.update(compact_payload(brain_metadata, 1200))
    apply_clean_reply_contract_metadata(
        payload,
        answer,
        item,
        skipped=skipped,
        output_category=output_category or ("skip" if skipped else "kakao_reply"),
        has_image_request=bool(image_request),
        publish_disabled=publish_disabled,
    )
    if pipeline.get("last_action_results"):
        payload["last_action_at_ms"] = now_ms()
        payload["last_action_count"] = len(action_results_list(pipeline.get("last_action_results")))
        payload["last_action_results"] = compact_explicit_action_result_payload(
            redact_payload_for_audit(pipeline.get("last_action_results") or []),
            3000,
        )
    if pipeline.get("image_required"):
        payload["image_required"] = True
        payload["image_send_policy"] = str(pipeline.get("image_send_policy") or "image_first")
    if image_request:
        payload["image_request"] = compact_payload(image_request, 20000)
    attach_image_request_suppression_metadata(payload, pipeline)
    if args.redact_done:
        payload.update(
            {
                "message": None,
                "text": None,
                "reply": None,
                "reply_redacted": True,
                "message_redacted": True,
                "reply_len": len(answer),
            }
        )
    else:
        payload["reply"] = answer
    try:
        fb_put(f"{REQUESTS_PATH}/{sanitize_key(req_id, 'local_direct')}", payload)
        ledger_ids = [
            str(result.get("ledger_id"))
            for result in action_results_list(pipeline.get("last_action_results"))
            if str(result.get("ledger_id") or "").strip()
        ]
        decision_ledger_id = append_decision_ledger(
            req_id,
            item,
            pipeline,
            args,
            event_id=event_id,
            route_metadata=route_metadata,
        )
        if decision_ledger_id:
            ledger_ids.append(decision_ledger_id)
        write_reconciliation_status(
            req_id,
            item,
            args,
            status=reconciliation_status_for_pipeline(route_metadata, ledger_ids),
            event_id=event_id,
            ledger_ids=ledger_ids,
            route_metadata=route_metadata,
        )
        learning_suppression = request_learning_suppression_context(args, item)
        if learning_suppression:
            mark_learning_stamp_status(req_id, args, "skipped", error=learning_suppression["learning_write_skipped_reason"])
        else:
            write_learning_stamp(
                req_id,
                build_learning_stamp(
                    req_id,
                    item,
                    args,
                    guide,
                    decision=local_direct_decision(skipped, action_count),
                    answer=answer,
                    session_id=session_id,
                    outbound_key=outbound_key,
                    skipped=skipped,
                    publish_disabled=publish_disabled,
                    action_count=action_count,
                    action_ok_count=action_ok_count,
                    action_error_count=action_error_count,
                ),
                args,
            )
        save_room_turn_context(
            req_id,
            item,
            pipeline,
            answer,
            skipped=skipped,
            publish_disabled=publish_disabled,
            force=True,
            args=args,
        )
    except Exception as exc:
        log(f"local-direct mirror failed request={req_id}: {compact_error(str(exc), 200)}")


def process_local_direct(req_id: str, item: dict[str, Any], args: argparse.Namespace) -> dict[str, Any]:
    started = time.perf_counter()
    pickup_started = now_ms()
    item = dict(item)
    item["local_direct"] = True
    item["_local_direct_started_at_ms"] = now_ms()
    run_args = effective_request_args(item, args)
    route_metadata = plan_storebot_capability_route(item)
    event_id = append_room_event_journal(req_id, item, run_args, route_metadata=route_metadata)
    item["_room_event_id"] = event_id
    safe_record_stage(
        req_id,
        item,
        run_args,
        "worker_pickup",
        "started",
        message="local-direct worker accepted request",
        evidence_key=event_id,
    )
    safe_record_stage(
        req_id,
        item,
        run_args,
        "worker_pickup",
        "done",
        message="local-direct request entered worker",
        evidence_key=event_id,
        elapsed_ms=now_ms() - pickup_started,
    )
    no_reply_reason = storebot_contextless_no_reply_reason(item)
    if no_reply_reason:
        elapsed_ms = int((time.perf_counter() - started) * 1000)
        try:
            mark_done(
                req_id,
                "SKIP",
                "",
                None,
                True,
                True,
                run_args,
                output_category="skip",
                output_payload={
                    "reason": no_reply_reason,
                    "event_kind": request_event_kind(item),
                    "reply_policy": "no_reply_without_user_context",
                },
                route_metadata=route_metadata,
                item=item,
            )
            write_reconciliation_status(
                req_id,
                item,
                run_args,
                status="matched",
                event_id=event_id,
                ledger_ids=[],
                route_metadata=route_metadata,
            )
        except Exception as exc:
            log(f"local-direct contextless no-reply mirror failed request={req_id}: {compact_error(str(exc), 200)}")
        log(f"local-direct contextless event skipped request={req_id} reason={no_reply_reason}")
        safe_record_stage(req_id, item, run_args, "outbound_publish", "skipped", message=no_reply_reason)
        return attach_storebot_reply_contract({
            "ok": True,
            "request_id": req_id,
            "reply": "",
            "skipped": True,
            "output_category": "skip",
            "self_fix_request_id": "",
            "session_id": "",
            "model": model_label(run_args),
            "reasoning_effort": reasoning_label(run_args),
            "model_override_reason": getattr(run_args, "model_override_reason", ""),
            "action_count": 0,
            "action_ok_count": 0,
            "action_error_count": 0,
            "direct_tool_count": 0,
            "elapsed_ms": elapsed_ms,
            "skip_reason": no_reply_reason,
        }, item, run_args)
    screen_noise_reason = kakao_screen_noise_reason(item)
    if screen_noise_reason:
        elapsed_ms = int((time.perf_counter() - started) * 1000)
        try:
            mark_screen_noise_done(req_id, item, screen_noise_reason, run_args, local_direct=True, elapsed_ms=elapsed_ms)
            write_reconciliation_status(
                req_id,
                item,
                run_args,
                status="matched",
                event_id=event_id,
                ledger_ids=[],
                route_metadata=route_metadata,
            )
        except Exception as exc:
            log(f"local-direct screen noise mirror failed request={req_id}: {compact_error(str(exc), 200)}")
        log(f"local-direct screen noise skipped request={req_id} reason={screen_noise_reason}")
        safe_record_stage(req_id, item, run_args, "outbound_publish", "skipped", message=screen_noise_reason)
        response = {
            "ok": True,
            "request_id": req_id,
            "reply": "",
            "skipped": True,
            "output_category": "skip",
            "self_fix_request_id": "",
            "session_id": "",
            "model": model_label(run_args),
            "reasoning_effort": reasoning_label(run_args),
            "model_override_reason": getattr(run_args, "model_override_reason", ""),
            "action_count": 0,
            "action_ok_count": 0,
            "action_error_count": 0,
            "direct_tool_count": 0,
            "elapsed_ms": elapsed_ms,
            "skip_reason": screen_noise_reason,
        }
        return attach_storebot_reply_contract(response, item, run_args)
    mirror_briefing_channel_inbound(req_id, item, run_args)
    explicit_field_name, explicit_actions = explicit_local_direct_action_list(item)
    if explicit_actions:
        explicit_item, pipeline = run_local_direct_explicit_actions(
            req_id,
            item,
            run_args,
            route_metadata=route_metadata,
        )
        elapsed_ms = int((time.perf_counter() - started) * 1000)
        safe_record_stage(
            req_id,
            explicit_item,
            run_args,
            "outbound_publish",
            "done",
            message="local-direct explicit action result ready",
            evidence={
                "explicit_action_field": explicit_field_name,
                "explicit_action_count": len(explicit_actions),
                "output_category": pipeline.get("output_category") or "skip",
            },
            elapsed_ms=elapsed_ms,
        )
        brain_metadata = dict(pipeline.get("brain_metadata") if isinstance(pipeline.get("brain_metadata"), dict) else {})
        brain_metadata["total_ms"] = elapsed_ms
        brain_metadata.setdefault("clean_extract_ms", 0)
        publish_gate_started = time.perf_counter()
        brain_metadata["publish_gate_ms"] = int((time.perf_counter() - publish_gate_started) * 1000)
        brain_metadata["bottleneck_stage"] = timing_bottleneck_stage(brain_metadata)
        pipeline["brain_metadata"] = compact_payload(brain_metadata, 1200)
        pipeline.update(compact_timing_metadata(brain_metadata))
        threading.Thread(
            target=mirror_local_direct_result,
            args=(req_id, explicit_item, "", pipeline, run_args, elapsed_ms),
            daemon=True,
            name="local-direct-mirror",
        ).start()
        response = {
            "ok": True,
            "request_id": req_id,
            "reply": "",
            "skipped": True,
            "output_category": pipeline.get("output_category") or "skip",
            "self_fix_request_id": "",
            "session_id": pipeline.get("session_id") or "",
            "model": model_label(run_args),
            "reasoning_effort": reasoning_label(run_args),
            "model_override_reason": getattr(run_args, "model_override_reason", ""),
            "action_count": int(pipeline.get("action_count") or 0),
            "action_ok_count": int(pipeline.get("action_ok_count") or 0),
            "action_error_count": int(pipeline.get("action_error_count") or 0),
            "direct_tool_count": int(pipeline.get("direct_tool_count") or 0),
            "elapsed_ms": elapsed_ms,
        }
        route_metadata = pipeline.get("route_metadata") if isinstance(pipeline.get("route_metadata"), dict) else {}
        brain_metadata = pipeline.get("brain_metadata") if isinstance(pipeline.get("brain_metadata"), dict) else {}
        if brain_metadata:
            response.update(compact_payload(brain_metadata, 1200))
        if route_metadata:
            response["route_metadata"] = compact_payload(route_metadata, 3000)
        clean_extract_started = time.perf_counter()
        response = attach_storebot_reply_contract(response, explicit_item, run_args)
        response["clean_extract_ms"] = int((time.perf_counter() - clean_extract_started) * 1000)
        response["bottleneck_stage"] = timing_bottleneck_stage(response)
        mirror_briefing_channel_outbound(req_id, explicit_item, run_args, response)
        return response
    guide = build_runtime_guide(read_guide(Path(run_args.guide)), run_args)
    image_request = None
    pipeline = run_codex_pipeline(req_id, item, guide, run_args, audit_actions=False, route_metadata=route_metadata)
    schedule_image_needed = should_build_schedule_image_request(item, str(pipeline.get("answer") or ""))
    realtime_started = now_ms()
    if schedule_image_needed:
        safe_record_stage(
            req_id,
            item,
            run_args,
            "realtime_data",
            "started",
            message="schedule realtime context collection started",
        )
        safe_record_stage(
            req_id,
            item,
            run_args,
            "image_build",
            "started",
            message="schedule image_request build started",
        )
    try:
        image_result = build_schedule_image_request_result(
            item,
            str(pipeline.get("answer") or ""),
            req_id=req_id,
            args=run_args,
        )
        if image_result.incomplete:
            safe_record_stage(
                req_id,
                item,
                run_args,
                "realtime_data",
                "error",
                message="required schedule realtime sections incomplete",
                evidence=image_result.incomplete,
                elapsed_ms=now_ms() - realtime_started,
                retry_count=1,
            )
            safe_record_stage(
                req_id,
                item,
                run_args,
                "image_build",
                "error",
                message="schedule image_request blocked by incomplete realtime data",
                evidence=image_result.incomplete,
                elapsed_ms=now_ms() - realtime_started,
                retry_count=1,
            )
            pipeline = dict(pipeline)
            incomplete_output = schedule_realtime_incomplete_output(
                image_result.incomplete,
                self_fix_request_id=image_result.self_fix_request_id,
            )
            pipeline["answer"] = ""
            pipeline["skipped"] = True
            pipeline["output_category"] = "schedule_realtime_incomplete"
            pipeline["output_payload"] = incomplete_output
            pipeline["self_fix_request_id"] = image_result.self_fix_request_id
            log(
                "local-direct schedule image incomplete blocked request="
                f"{req_id} missing={','.join(incomplete_output.get('missing_sections') or [])} "
                f"self_fix={image_result.self_fix_request_id}"
            )
        else:
            image_request = image_result.image_request
            if schedule_image_needed:
                realtime_evidence = {}
                if isinstance(image_request, dict) and isinstance(image_request.get("payload"), dict):
                    realtime_evidence = schedule_realtime_payload_metadata(image_request, image_request["payload"])
                safe_record_stage(
                    req_id,
                    item,
                    run_args,
                    "realtime_data",
                    "done",
                    message="schedule realtime context attached",
                    evidence=realtime_evidence,
                    elapsed_ms=now_ms() - realtime_started,
                    retry_count=1 if isinstance(image_request, dict)
                    and isinstance(image_request.get("payload"), dict)
                    and isinstance(image_request["payload"].get("schedule_realtime_retry"), dict)
                    else 0,
                )
                safe_record_stage(
                    req_id,
                    item,
                    run_args,
                    "image_build",
                    "done",
                    message=(
                        "schedule image_request ready"
                        if image_request
                        else "schedule image_request suppressed"
                        if image_result.suppressed_reason
                        else "schedule image_request not required"
                    ),
                    evidence={
                        "image_request_type": image_request.get("type") if isinstance(image_request, dict) else "",
                        "image_payload_source": image_request.get("image_payload_source") if isinstance(image_request, dict) else "",
                        "image_request_suppressed_reason": image_result.suppressed_reason,
                        "image_request_dedupe_key": image_result.dedupe_key,
                    },
                    elapsed_ms=now_ms() - realtime_started,
                )
                if image_result.suppressed_reason:
                    pipeline = mark_schedule_image_pending_pipeline(
                        annotate_schedule_image_suppression(pipeline, image_result),
                        image_result.suppressed_reason,
                        detail=image_result.suppressed_detail,
                        dedupe_key=image_result.dedupe_key,
                    )
            fallback_answer = schedule_text_fallback_from_image_request(image_request)
            if fallback_answer:
                pipeline = dict(pipeline)
                pipeline["answer"] = fallback_answer
                pipeline["schedule_text_fallback"] = True
            if image_request:
                pipeline = dict(pipeline)
                pipeline["image_request"] = image_request
                pipeline["image_required"] = True
                pipeline["image_send_policy"] = "image_first"
    except Exception as exc:
        log(f"local-direct image request build failed request={req_id}: {compact_error(str(exc), 200)}")
        if schedule_image_needed:
            validation = schedule_image_build_exception_validation(exc, stage="local_direct_image_request_build")
            safe_record_stage(
                req_id,
                item,
                run_args,
                "realtime_data",
                "error",
                message="schedule realtime/image build exception",
                evidence=validation,
                elapsed_ms=now_ms() - realtime_started,
            )
            safe_record_stage(
                req_id,
                item,
                run_args,
                "image_build",
                "error",
                message="schedule image_request build exception",
                evidence=validation,
                elapsed_ms=now_ms() - realtime_started,
            )
            self_fix_id = ""
            try:
                self_fix_id = enqueue_schedule_realtime_incomplete_self_fix(req_id, item, validation, run_args)
            except Exception as enqueue_exc:
                log(f"local-direct image exception self_fix enqueue failed request={req_id}: {compact_error(str(enqueue_exc), 200)}")
            pipeline = dict(pipeline)
            pipeline["answer"] = ""
            pipeline["skipped"] = True
            pipeline["output_category"] = "schedule_realtime_incomplete"
            pipeline["output_payload"] = schedule_realtime_incomplete_output(validation, self_fix_id)
            pipeline["self_fix_request_id"] = self_fix_id
    elapsed_ms = int((time.perf_counter() - started) * 1000)
    pipeline = dict(pipeline)
    brain_metadata = dict(pipeline.get("brain_metadata") if isinstance(pipeline.get("brain_metadata"), dict) else {})
    brain_metadata["total_ms"] = elapsed_ms
    brain_metadata.setdefault("clean_extract_ms", 0)
    publish_gate_started = time.perf_counter()
    safe_record_stage(
        req_id,
        item,
        run_args,
        "outbound_publish",
        "done",
        message="local-direct response ready for StoreBotTermux",
        evidence={
            "image_required": bool(image_request),
            "image_request_type": image_request.get("type") if isinstance(image_request, dict) else "",
            "output_category": pipeline.get("output_category") or ("skip" if pipeline.get("skipped") else "kakao_reply"),
        },
        elapsed_ms=elapsed_ms,
    )
    brain_metadata["publish_gate_ms"] = int((time.perf_counter() - publish_gate_started) * 1000)
    brain_metadata["bottleneck_stage"] = timing_bottleneck_stage(brain_metadata)
    pipeline["brain_metadata"] = compact_payload(brain_metadata, 1200)
    pipeline.update(compact_timing_metadata(brain_metadata))
    threading.Thread(
        target=mirror_local_direct_result,
        args=(req_id, item, guide, pipeline, run_args, elapsed_ms),
        daemon=True,
        name="local-direct-mirror",
    ).start()
    response = {
        "ok": True,
        "request_id": req_id,
        "reply": pipeline.get("answer") or "",
        "skipped": bool(pipeline.get("skipped")),
        "output_category": pipeline.get("output_category") or ("skip" if pipeline.get("skipped") else "kakao_reply"),
        "self_fix_request_id": pipeline.get("self_fix_request_id") or "",
        "session_id": pipeline.get("session_id") or "",
        "model": model_label(run_args),
        "reasoning_effort": reasoning_label(run_args),
        "model_override_reason": getattr(run_args, "model_override_reason", ""),
        "action_count": int(pipeline.get("action_count") or 0),
        "action_ok_count": int(pipeline.get("action_ok_count") or 0),
        "action_error_count": int(pipeline.get("action_error_count") or 0),
        "direct_tool_count": int(pipeline.get("direct_tool_count") or 0),
        "elapsed_ms": elapsed_ms,
    }
    route_metadata = pipeline.get("route_metadata") if isinstance(pipeline.get("route_metadata"), dict) else {}
    brain_metadata = pipeline.get("brain_metadata") if isinstance(pipeline.get("brain_metadata"), dict) else {}
    if brain_metadata:
        response.update(compact_payload(brain_metadata, 1200))
    if route_metadata:
        response["route_metadata"] = compact_payload(route_metadata, 3000)
    if image_request:
        response["image_request"] = image_request
        response["image_required"] = True
        response["image_send_policy"] = "image_first"
    attach_image_request_suppression_metadata(response, pipeline)
    clean_extract_started = time.perf_counter()
    response = attach_storebot_reply_contract(response, item, run_args)
    response["clean_extract_ms"] = int((time.perf_counter() - clean_extract_started) * 1000)
    response["bottleneck_stage"] = timing_bottleneck_stage(response)
    mirror_briefing_channel_outbound(req_id, item, run_args, response)
    return response


def process_local_direct_with_deadline(req_id: str, item: dict[str, Any], args: argparse.Namespace) -> dict[str, Any]:
    sync_timeout = local_direct_sync_timeout_sec()
    if sync_timeout <= 0:
        return process_local_direct(req_id, item, args)

    started = time.perf_counter()
    box: dict[str, Any] = {}

    def runner() -> None:
        try:
            box["result"] = process_local_direct(req_id, item, args)
        except Exception as exc:
            box["error"] = exc
            if is_local_direct_deferred(req_id):
                elapsed_ms = int((time.perf_counter() - started) * 1000)
                if is_retryable_codex_runtime_error(exc):
                    diagnostic_item = dict(item)
                    diagnostic_item["local_direct"] = True
                    diagnostic_item["_local_direct_elapsed_ms"] = elapsed_ms
                    enqueue_local_direct_codex_runtime_diagnostic(
                        req_id,
                        diagnostic_item,
                        args,
                        exc,
                        "local_direct_deferred_worker",
                    )
                mirror_local_direct_error(req_id, item, args, compact_error(str(exc), 500), elapsed_ms)
                mirror_briefing_channel_failure(req_id, item, args, "local_direct_deferred_failed", compact_error(str(exc), 500))
                pop_local_direct_deferred(req_id)

    thread = threading.Thread(target=runner, daemon=True, name=f"local-direct-worker-{req_id[:24]}")
    thread.start()
    thread.join(sync_timeout)
    if thread.is_alive():
        elapsed_ms = int((time.perf_counter() - started) * 1000)
        timeout_at_ms = now_ms()
        mark_local_direct_deferred(req_id)
        threading.Thread(
            target=mirror_local_direct_deferred,
            args=(req_id, item, args, elapsed_ms),
            daemon=True,
            name="local-direct-deferred-mirror",
        ).start()
        log(f"local-direct deferred request={req_id} elapsed_ms={elapsed_ms} sync_timeout_sec={sync_timeout:g}")
        response = {
            "ok": True,
            "degraded": True,
            "deferred": True,
            "request_id": req_id,
            "reply": local_direct_deferred_reply(),
            "skipped": False,
            "output_category": "system_progress",
            "self_fix_request_id": "",
            "session_id": "",
            "model": model_label(args),
            "reasoning_effort": reasoning_label(args),
            "action_count": 0,
            "action_ok_count": 0,
            "action_error_count": 0,
            "direct_tool_count": 0,
            "elapsed_ms": elapsed_ms,
        }
        telegram_backplane = build_telegram_backplane_failure_envelope(
            req_id,
            item,
            "local_direct_timeout",
            timeout_at_ms,
        )
        if telegram_backplane is not None:
            response["telegram_backplane"] = telegram_backplane
        response = attach_storebot_reply_contract(response, item, args)
        mirror_briefing_channel_outbound(req_id, item, args, response)
        return response
    if box.get("error"):
        raise box["error"]
    result = box.get("result")
    if not isinstance(result, dict):
        raise WorkerError("local-direct worker returned no result")
    return result


def local_direct_deferred_reply() -> str:
    return str(os.environ.get("STOREBOT_CODEX_LOCAL_DIRECT_DEFERRED_REPLY") or "").strip()


def local_direct_error_reply() -> str:
    return str(os.environ.get("STOREBOT_CODEX_LOCAL_DIRECT_ERROR_REPLY") or "").strip()


def mirror_local_direct_error(req_id: str, item: dict[str, Any], args: argparse.Namespace, error: str, elapsed_ms: int) -> None:
    if not req_id or not isinstance(item, dict) or not item:
        return
    finished_at = now_ms()
    error_text = compact_error(error, 500)
    payload = dict(item)
    payload.update(
        {
            "status": "error",
            "source": str(item.get("source") or "storebot_android") + "_local_direct",
            "finished_at_ms": finished_at,
            "worker": args.node,
            "model": model_label(args),
            "reasoning_effort": reasoning_label(args),
            "reply_skipped": False,
            "publish_disabled": True,
            "local_direct": True,
            "local_direct_elapsed_ms": elapsed_ms,
            "output_category": "system_recovery",
            "error": error_text,
            "reply": local_direct_error_reply(),
        }
    )
    if is_local_direct_deferred(req_id):
        telegram_backplane = build_telegram_backplane_failure_envelope(
            req_id,
            item,
            "local_direct_deferred_error",
            finished_at,
        )
        if telegram_backplane is not None:
            payload["telegram_backplane"] = telegram_backplane
    try:
        event_id = str(item.get("_room_event_id") or "")
        if not event_id:
            event_id = append_room_event_journal(req_id, item, args)
        fb_put(f"{REQUESTS_PATH}/{sanitize_key(req_id, 'local_direct')}", payload)
        write_reconciliation_status(
            req_id,
            item,
            args,
            status="error",
            event_id=event_id,
            ledger_ids=[],
            route_metadata={},
            error=error,
        )
        fb_patch(
            INPUT_HEALTH_PATH,
            {
                "last_request_error_id": sanitize_key(req_id, "local_direct"),
                "last_request_error_at_ms": finished_at,
                "last_request_error": error_text,
                "last_request_error_status": "error",
                "last_request_error_source": "storebot_codex_worker_local_direct",
            },
        )
    except Exception as exc:
        log(f"local-direct error mirror failed request={req_id}: {compact_error(str(exc), 200)}")


def start_local_direct_server(args: argparse.Namespace) -> None:
    host = str(args.local_direct_host or "127.0.0.1")
    port = int(args.local_direct_port or 8765)
    LOCAL_DIRECT_STATE.update(
        {
            "enabled": True,
            "listening": False,
            "host": host,
            "port": port,
            "started_at_ms": 0,
            "last_error": "",
        }
    )

    def is_allowed_client(address: str) -> bool:
        try:
            return ipaddress.ip_address(address).is_loopback
        except ValueError:
            return address in {"localhost", "::1"}

    def local_direct_health() -> tuple[int, dict[str, Any]]:
        resident_enabled = bool(env_bool("STOREBOT_CODEX_RESIDENT_APP_SERVER", True))
        if resident_enabled:
            resident_codex_process_alive()
        resident_active = bool(RESIDENT_CODEX_STATE.get("active"))
        resident_error = compact_error(str(RESIDENT_CODEX_STATE.get("last_error") or ""), 250)
        resident_ready = (not resident_enabled) or (resident_active and not resident_error)
        fast_brain_status = fast_brain_config_status()
        payload = {
            "ok": resident_ready,
            "mode": "local_direct",
            "bridge_mode": STOREBOT_BRIDGE_MODE,
            "reply_contract_version": STOREBOT_REPLY_CONTRACT_VERSION,
            "dedicated_room": True,
            "default_model_policy": "thin_bridge_cli_direct_resident_required",
            "ts": now_ms(),
            "fast_brain": fast_brain_status,
            "fast_brain_enabled": bool(fast_brain_enabled()),
            "fast_brain_default": False,
            "fast_brain_guarded_hot_path": bool(guarded_fast_brain_hot_path_enabled()),
            "fast_brain_fallback_route": "guarded_side_path_only_resident_cli_primary",
            **fast_brain_secret_mirrors(fast_brain_status),
            "fast_router_stateless_exec": bool(fast_router_stateless_exec_enabled()),
            "thin_bridge_cli_direct": bool(thin_bridge_cli_direct_enabled()),
            "resident_exec_fallback_enabled": bool(resident_exec_fallback_enabled()),
            "bounded_worker_exec_fallback_enabled": bool(fast_router_stateless_exec_enabled() or resident_exec_fallback_enabled()),
            "fast_router_refresh_after_action": bool(fast_router_refresh_after_action_enabled()),
            "local_direct_sync_timeout_sec": float(local_direct_sync_timeout_sec()),
            "local_direct_deferred_publish": bool(local_direct_deferred_publish_enabled()),
            "resident_app_server_enabled": resident_enabled,
            "resident_app_server_active": resident_active,
            "resident_app_server_last_error": resident_error,
            "resident_ready": resident_ready,
        }
        return (200 if resident_ready else 503), payload

    class StoreBotLocalDirectHandler(http.server.BaseHTTPRequestHandler):
        server_version = "StoreBotLocalDirect/1"

        def log_message(self, fmt: str, *values: Any) -> None:
            log("local-direct " + (fmt % values))

        def send_json(self, code: int, payload: dict[str, Any]) -> None:
            body = json.dumps(payload, ensure_ascii=False, separators=(",", ":")).encode("utf-8")
            self.send_response(code)
            self.send_header("Content-Type", "application/json; charset=utf-8")
            self.send_header("Content-Length", str(len(body)))
            self.end_headers()
            self.wfile.write(body)

        def do_GET(self) -> None:
            if not is_allowed_client(str(self.client_address[0])):
                self.send_json(403, {"ok": False, "error": "forbidden"})
                return
            if self.path.rstrip("/") in {"", "/health", "/storebot/health"}:
                code, payload = local_direct_health()
                self.send_json(code, payload)
            else:
                self.send_json(404, {"ok": False, "error": "not found"})

        def do_POST(self) -> None:
            if not is_allowed_client(str(self.client_address[0])):
                self.send_json(403, {"ok": False, "error": "forbidden"})
                return
            path = self.path.rstrip("/")
            if path not in {
                "/request",
                "/storebot/request",
                "/openclaw/outbound",
                "/storebot/openclaw/outbound",
                "/briefing-channel/event",
                "/storebot/briefing-channel/event",
            }:
                self.send_json(404, {"ok": False, "error": "not found"})
                return
            try:
                length = int(self.headers.get("Content-Length") or "0")
            except ValueError:
                self.send_json(400, {"ok": False, "error": "invalid content length"})
                return
            if length <= 0 or length > 256 * 1024:
                self.send_json(413, {"ok": False, "error": "invalid payload size"})
                return
            try:
                raw = self.rfile.read(length).decode("utf-8")
                item = json.loads(raw)
                if not isinstance(item, dict):
                    raise ValueError("payload must be object")
                req_id = sanitize_key(str(item.get("request_id") or f"local_{now_ms()}_{secrets.token_hex(3)}"))
            except Exception as exc:
                error = compact_error(str(exc), 500)
                log(f"local-direct request failed: {error}")
                self.send_json(500, {"ok": False, "error": error})
                return
            started = time.perf_counter()
            try:
                if path in {"/briefing-channel/event", "/storebot/briefing-channel/event"}:
                    item.setdefault("request_id", req_id)
                    result = update_briefing_channel_event(item, args)
                elif path in {"/openclaw/outbound", "/storebot/openclaw/outbound"}:
                    result = process_openclaw_outbound(req_id, item, args)
                else:
                    result = process_local_direct_with_deadline(req_id, item, args)
            except Exception as exc:
                error = compact_error(str(exc), 500)
                elapsed_ms = int((time.perf_counter() - started) * 1000)
                log(f"local-direct request failed: {error}")
                if path in {"/request", "/storebot/request"} and is_retryable_codex_runtime_error(error):
                    diagnostic_item = dict(item)
                    diagnostic_item["local_direct"] = True
                    diagnostic_item["_local_direct_elapsed_ms"] = elapsed_ms
                    enqueue_local_direct_codex_runtime_diagnostic(
                        req_id,
                        diagnostic_item,
                        args,
                        error,
                        "local_direct_request_failed",
                    )
                mirror_briefing_channel_failure(req_id, item, args, "local_direct_failed", error)
                threading.Thread(
                    target=mirror_local_direct_error,
                    args=(req_id, item, args, error, elapsed_ms),
                    daemon=True,
                    name="local-direct-error-mirror",
                ).start()
                result = attach_storebot_reply_contract({
                    "ok": True,
                    "degraded": True,
                    "request_id": req_id,
                    "reply": local_direct_error_reply(),
                    "skipped": False,
                    "output_category": "system_recovery",
                    "self_fix_request_id": "",
                    "session_id": "",
                    "model": model_label(args),
                    "reasoning_effort": reasoning_label(args),
                    "action_count": 0,
                    "action_ok_count": 0,
                    "action_error_count": 0,
                    "direct_tool_count": 0,
                    "elapsed_ms": elapsed_ms,
                    "error": error,
                }, item, args)
            try:
                self.send_json(200, result)
            except (BrokenPipeError, ConnectionError, OSError) as exc:
                log(f"local-direct client disconnected request={req_id}: {compact_error(str(exc), 160)}")

    try:
        server = http.server.ThreadingHTTPServer((host, port), StoreBotLocalDirectHandler)
    except OSError as exc:
        LOCAL_DIRECT_STATE.update({"listening": False, "last_error": str(exc)})
        raise
    LOCAL_DIRECT_STATE.update({"listening": True, "started_at_ms": now_ms(), "last_error": ""})
    thread = threading.Thread(target=server.serve_forever, daemon=True, name="local-direct-http")
    thread.start()
    log(f"local-direct server listening http://{host}:{port}/storebot/request")


def enqueue_test(args: argparse.Namespace) -> None:
    key = f"manual_{now_ms()}_{secrets.token_hex(3)}"
    payload = {
        "status": "pending",
        "source": "manual_test",
        "room_id": args.room_id,
        "room_name": args.room_name,
        "sender": args.sender,
        "message": args.enqueue_test,
        "ts": now_ms(),
        "created_at_ms": now_ms(),
    }
    if args.enqueue_no_publish:
        payload["no_publish"] = True
    if args.dry_run:
        debug_payload = dict(payload)
        debug_payload["context_bundle_v1"] = build_no_live_context_bundle_v1(key, debug_payload)
        log(f"dry-run enqueue {key}: {json.dumps(debug_payload, ensure_ascii=False, sort_keys=True)}")
        return
    fb_put(f"{REQUESTS_PATH}/{key}", payload)
    log(f"enqueued test request={key}")


def bootstrap_only(args: argparse.Namespace) -> None:
    guide = build_runtime_guide(read_guide(Path(args.guide)), args)
    room_id = args.room_id
    room_name = args.room_name or room_id
    room_key = sanitize_key(room_id or room_name)
    if args.dry_run:
        log(f"dry-run bootstrap room={room_key}")
        return
    session_id = get_or_create_session(room_key, room_id, room_name, guide, args)
    log(f"bootstrap ready room={room_key} session={session_id}")


def resident_session_preboot_enabled() -> bool:
    return env_bool("STOREBOT_CODEX_RESIDENT_SESSION_PREBOOT", True)


def resident_session_preboot_timeout_sec() -> int:
    try:
        return max(30, int(os.environ.get("STOREBOT_CODEX_RESIDENT_SESSION_PREBOOT_TIMEOUT_SEC", "180")))
    except (TypeError, ValueError):
        return 180


def resident_session_watchdog_enabled() -> bool:
    return env_bool("STOREBOT_CODEX_RESIDENT_SESSION_WATCHDOG", resident_session_preboot_enabled())


def resident_session_watchdog_interval_sec() -> float:
    try:
        return max(30.0, float(os.environ.get("STOREBOT_CODEX_RESIDENT_SESSION_WATCHDOG_INTERVAL_SEC", "120")))
    except (TypeError, ValueError):
        return 120.0


def resident_session_keepalive_interval_sec() -> float:
    try:
        return max(180.0, float(os.environ.get("STOREBOT_CODEX_RESIDENT_SESSION_KEEPALIVE_INTERVAL_SEC", "600")))
    except (TypeError, ValueError):
        return 600.0


def resident_session_preboot_room(args: argparse.Namespace) -> tuple[str, str, str]:
    configured_room_id = str(os.environ.get("STOREBOT_CODEX_PREBOOT_ROOM_ID") or "").strip()
    configured_room_name = str(os.environ.get("STOREBOT_CODEX_PREBOOT_ROOM_NAME") or "").strip()
    room_id = configured_room_id or str(getattr(args, "room_id", "") or "").strip() or "storebot_group"
    room_name = configured_room_name or str(getattr(args, "room_name", "") or "").strip() or room_id
    return room_id, room_name, sanitize_key(room_id or room_name)


def preboot_resident_ai_session(args: argparse.Namespace, reason: str = "startup") -> None:
    if not env_bool("STOREBOT_CODEX_RESIDENT_APP_SERVER", True):
        return
    if not _RESIDENT_SESSION_PREBOOT_LOCK.acquire(blocking=False):
        return
    room_id, room_name, room_key = resident_session_preboot_room(args)
    started_at = now_ms()
    RESIDENT_CODEX_STATE.update(
        {
            "session_preboot_enabled": True,
            "session_preboot_ready": False,
            "session_preboot_in_progress": True,
            "session_preboot_reason": reason,
            "session_preboot_started_at_ms": started_at,
            "session_preboot_ready_at_ms": 0,
            "session_preboot_room_key": room_key,
            "session_preboot_room_id": room_id,
            "session_preboot_room_name": room_name,
            "session_preboot_session_id": "",
            "session_preboot_error": "",
        }
    )
    try:
        guide = build_runtime_guide(read_guide(Path(args.guide)), args)
        session_id = get_or_create_session(room_key, room_id, room_name, guide, args)
        resident_codex_client().prepare_thread(
            session_id,
            args.model,
            args.reasoning_effort,
            args.cwd,
            resident_session_preboot_timeout_sec(),
        )
        RESIDENT_CODEX_STATE.update(
            {
                "session_preboot_ready": True,
                "session_preboot_in_progress": False,
                "session_preboot_ready_at_ms": now_ms(),
                "session_preboot_session_id": session_id,
                "session_preboot_error": "",
                "session_health_ok": True,
                "session_health_error": "",
            }
        )
        fb_patch(
            f"{SESSIONS_PATH}/{room_key}",
            {
                "resident_preboot_ready": True,
                "resident_preboot_ready_at_ms": now_ms(),
                "resident_preboot_worker": args.node,
                "resident_preboot_reason": reason,
            },
        )
        log(f"resident AI session preboot ready room={room_key} session={session_id} reason={reason}")
    except Exception as exc:
        error = compact_error(str(exc), 400)
        RESIDENT_CODEX_STATE.update(
            {
                "session_preboot_ready": False,
                "session_preboot_in_progress": False,
                "session_preboot_error": error,
                "last_error": error,
                "session_health_ok": False,
                "session_health_error": error,
            }
        )
        log(f"resident AI session preboot failed room={room_key}: {error}")
    finally:
        RESIDENT_CODEX_STATE["session_preboot_in_progress"] = False
        _RESIDENT_SESSION_PREBOOT_LOCK.release()


def keepalive_resident_ai_session(args: argparse.Namespace) -> bool:
    session_id = str(RESIDENT_CODEX_STATE.get("session_preboot_session_id") or "").strip()
    if not session_id:
        return False
    resident_codex_client().prepare_thread(
        session_id,
        args.model,
        args.reasoning_effort,
        args.cwd,
        min(60, resident_session_preboot_timeout_sec()),
    )
    RESIDENT_CODEX_STATE.update(
        {
            "session_last_keepalive_at_ms": now_ms(),
            "session_health_ok": True,
            "session_health_error": "",
        }
    )
    return True


def resident_session_watchdog_loop(args: argparse.Namespace) -> None:
    interval = resident_session_watchdog_interval_sec()
    keepalive_interval = resident_session_keepalive_interval_sec()
    RESIDENT_CODEX_STATE.update(
        {
            "session_watchdog_enabled": True,
            "session_watchdog_interval_sec": interval,
            "session_keepalive_interval_sec": keepalive_interval,
        }
    )
    while True:
        time.sleep(interval)
        if args.dry_run or not resident_session_watchdog_enabled():
            continue
        try:
            RESIDENT_CODEX_STATE["session_last_health_check_ms"] = now_ms()
            if bool(RESIDENT_CODEX_STATE.get("session_preboot_in_progress")):
                continue
            alive = resident_codex_process_alive()
            ready = bool(RESIDENT_CODEX_STATE.get("session_preboot_ready"))
            if not alive or not ready:
                reason = "watchdog_process_dead" if not alive else "watchdog_preboot_not_ready"
                record_resident_session_revive(reason)
                shutdown_resident_codex()
                preboot_resident_ai_session(args, reason=reason)
                continue
            last_keepalive = int(RESIDENT_CODEX_STATE.get("session_last_keepalive_at_ms") or 0)
            if now_ms() - last_keepalive >= int(keepalive_interval * 1000):
                keepalive_resident_ai_session(args)
        except Exception as exc:
            error = compact_error(str(exc), 400)
            RESIDENT_CODEX_STATE.update(
                {
                    "session_health_ok": False,
                    "session_health_error": error,
                    "last_error": error,
                    "session_preboot_ready": False,
                }
            )
            log(f"resident AI session watchdog failed: {error}")
            record_resident_session_revive("watchdog_error")
            shutdown_resident_codex()


def start_resident_session_preboot_thread(args: argparse.Namespace) -> None:
    RESIDENT_CODEX_STATE["session_preboot_enabled"] = resident_session_preboot_enabled()
    if args.dry_run or not resident_session_preboot_enabled():
        return
    thread = threading.Thread(
        target=lambda: preboot_resident_ai_session(args),
        daemon=True,
        name="resident-ai-session-preboot",
    )
    thread.start()


def start_resident_session_watchdog_thread(args: argparse.Namespace) -> None:
    RESIDENT_CODEX_STATE["session_watchdog_enabled"] = resident_session_watchdog_enabled()
    if args.dry_run or not resident_session_watchdog_enabled():
        return
    thread = threading.Thread(
        target=lambda: resident_session_watchdog_loop(args),
        daemon=True,
        name="resident-ai-session-watchdog",
    )
    thread.start()


def run_once(args: argparse.Namespace) -> int:
    guide = build_runtime_guide(read_guide(Path(args.guide)), args)
    explicit_pending = load_explicit_pending(args.limit, args.reclaim_running_sec, args.reclaim_inflight_sec)
    if explicit_pending:
        if args.dry_run:
            log(f"dry-run explicit_pending={len(explicit_pending)} path={EXPLICIT_ACTION_REQUESTS_PATH}")
            for req_id, item in explicit_pending:
                explicit_field_name, explicit_actions = explicit_local_direct_action_list(item)
                log(
                    "pending explicit_action_request="
                    f"{req_id} field={explicit_field_name} actions={len(explicit_actions)} "
                    f"room={sanitize_key(str(item.get('room_id') or item.get('room_name') or 'default'))}"
                )
            return len(explicit_pending)

        write_heartbeat(args, len(explicit_pending), "processing")
        for req_id, item in explicit_pending:
            try:
                process_one(req_id, item, guide, args)
            except WorkerError as exc:
                error = compact_error(str(exc))
                try:
                    route_metadata = plan_storebot_capability_route(item)
                except Exception:
                    route_metadata = {}
                mark_error(req_id, error, args, item, route_metadata=route_metadata)
                try:
                    write_heartbeat(args, len(explicit_pending), "error", error)
                except Exception:
                    pass
                log(f"error explicit_action_request={req_id}: {error}")
        return len(explicit_pending)

    due_alerts = process_due_temp_alerts(args)
    try:
        due_schedule_events = process_due_schedule_timer_events(args)
    except Exception as exc:
        due_schedule_events = 0
        error = compact_error(str(exc), 300)
        log(f"schedule timer failed: {error}")
        if not args.dry_run:
            try:
                fb_put(SCHEDULE_TIMER_LATEST_PATH, {"status": "error", "error": error, "error_at_ms": now_ms()})
            except Exception:
                pass
    try:
        due_work_schedule_broadcast = process_due_work_schedule_broadcast(args)
    except Exception as exc:
        due_work_schedule_broadcast = 0
        error = compact_error(str(exc), 300)
        log(f"work schedule broadcast failed: {error}")
    pending = load_pending(args.limit, args.reclaim_running_sec, args.reclaim_inflight_sec)
    if args.dry_run:
        log(
            "dry-run pending="
            f"{len(pending)} due_temp_alerts={due_alerts} due_schedule_events={due_schedule_events} "
            f"due_work_schedule_broadcast={due_work_schedule_broadcast}"
        )
        for req_id, item in pending:
            if is_confirmed_schedule_queue_item(item):
                log(
                    "pending confirmed_schedule_write_request="
                    f"{req_id} date={item.get('date') or ''} employee={compact_text(item.get('employee'), 80)} "
                    f"mode={'dry_run' if confirmed_schedule_request_dry_run(item) else 'live_write'}"
                )
                continue
            room_id = str(item.get("room_id") or item.get("room") or "default")
            room_name = str(item.get("room_name") or item.get("roomTitle") or room_id)
            log(f"pending request={req_id} room={sanitize_key(room_id or room_name)}")
            bundle_debug = build_no_live_context_bundle_debug_output(req_id, item)
            log(f"dry-run context_bundle_v1 {json.dumps(bundle_debug, ensure_ascii=False, sort_keys=True, default=str)}")
        return len(pending)

    write_heartbeat(args, len(pending), "idle" if not pending else "processing")
    for req_id, item in pending:
        try:
            if is_confirmed_schedule_queue_item(item):
                process_confirmed_schedule_queue_item(req_id, item, args)
            else:
                process_one(req_id, item, guide, args)
        except WorkerError as exc:
            error = compact_error(str(exc))
            if is_confirmed_schedule_queue_item(item):
                mark_rejected(req_id, error, args, item)
                write_heartbeat(args, len(pending), "error", error)
                log(f"rejected confirmed schedule request={req_id}: {error}")
                continue
            try:
                route_metadata = plan_storebot_capability_route(item)
            except Exception:
                route_metadata = {}
            mark_error(req_id, error, args, item, route_metadata=route_metadata)
            try:
                write_learning_stamp(
                    req_id,
                    build_learning_stamp(
                        req_id,
                        item,
                        args,
                        guide,
                        decision=stamp_decision(False, None, 0, error),
                        error=error,
                    ),
                    args,
                )
            except Exception as stamp_exc:
                log(f"learning error stamp write failed request={req_id}: {compact_error(str(stamp_exc), 200)}")
                mark_learning_stamp_status(req_id, args, "error", error=str(stamp_exc))
            write_heartbeat(args, len(pending), "error", error)
            log(f"error request={req_id}: {error}")
        except Exception as exc:  # keep the daemon alive and expose a concise failure.
            error = compact_error(str(exc))
            if is_confirmed_schedule_queue_item(item):
                mark_error(req_id, error, args, item)
                write_heartbeat(args, len(pending), "error", error)
                log(f"error confirmed schedule request={req_id}: {error}")
                continue
            try:
                route_metadata = plan_storebot_capability_route(item)
            except Exception:
                route_metadata = {}
            mark_error(req_id, error, args, item, route_metadata=route_metadata)
            try:
                write_learning_stamp(
                    req_id,
                    build_learning_stamp(
                        req_id,
                        item,
                        args,
                        guide,
                        decision=stamp_decision(False, None, 0, error),
                        error=error,
                    ),
                    args,
                )
            except Exception as stamp_exc:
                log(f"learning error stamp write failed request={req_id}: {compact_error(str(stamp_exc), 200)}")
                mark_learning_stamp_status(req_id, args, "error", error=str(stamp_exc))
            write_heartbeat(args, len(pending), "error", error)
            log(f"error request={req_id}: {error}")
    return len(pending)


def parse_args(argv: list[str]) -> argparse.Namespace:
    parser = argparse.ArgumentParser(description="StoreBot Firebase queue -> Codex session reply worker")
    parser.add_argument("--watch", action="store_true", help="keep polling")
    parser.add_argument("--once", action="store_true", help="process one polling cycle")
    parser.add_argument("--dry-run", action="store_true", help="read only; do not write Firebase or call Codex")
    parser.add_argument("--no-publish", action="store_true", help="do not publish replies to StoreBot pending queue")
    parser.add_argument("--stateless", action="store_true", help="process without resuming or updating the room session")
    parser.add_argument("--redact-done", action=argparse.BooleanOptionalAction, default=env_bool("STOREBOT_CODEX_REDACT_DONE", True))
    parser.add_argument("--archive-old-sessions", action=argparse.BooleanOptionalAction, default=env_bool("STOREBOT_CODEX_ARCHIVE_OLD_SESSIONS", True))
    parser.add_argument("--poll-sec", type=float, default=float(os.environ.get("STOREBOT_CODEX_POLL_SEC", "5")))
    parser.add_argument("--limit", type=int, default=int(os.environ.get("STOREBOT_CODEX_LIMIT", "3")))
    parser.add_argument("--action-rounds", type=int, default=int(os.environ.get("STOREBOT_CODEX_ACTION_ROUNDS", "3")))
    parser.add_argument("--max-actions", type=int, default=int(os.environ.get("STOREBOT_CODEX_MAX_ACTIONS", "8")))
    parser.add_argument("--timeout-sec", type=int, default=int(os.environ.get("STOREBOT_CODEX_TIMEOUT_SEC", "540")))
    parser.add_argument("--schedule-timer", action=argparse.BooleanOptionalAction, default=env_bool("STOREBOT_CODEX_SCHEDULE_TIMER", True))
    parser.add_argument(
        "--schedule-timer-attendance-catchup-min",
        type=int,
        default=int(os.environ.get("STOREBOT_CODEX_SCHEDULE_TIMER_ATTENDANCE_CATCHUP_MIN", "10")),
    )
    parser.add_argument(
        "--schedule-timer-briefing-catchup-min",
        type=int,
        default=int(os.environ.get("STOREBOT_CODEX_SCHEDULE_TIMER_BRIEFING_CATCHUP_MIN", "30")),
    )
    parser.add_argument("--schedule-timer-room-id", default=os.environ.get("STOREBOT_SCHEDULE_ROOM_ID", "storebot_group"))
    parser.add_argument("--schedule-timer-room-name", default=os.environ.get("STOREBOT_SCHEDULE_ROOM_NAME", "BBQ하이닉스점 10"))
    parser.add_argument(
        "--reclaim-running-sec",
        type=float,
        default=float(os.environ.get("STOREBOT_CODEX_RECLAIM_RUNNING_SEC", "0")),
        help="reprocess requests stuck in running after this many seconds; 0 uses timeout-sec + 180",
    )
    parser.add_argument(
        "--reclaim-inflight-sec",
        type=float,
        default=float(os.environ.get("STOREBOT_CODEX_RECLAIM_INFLIGHT_SEC", "300")),
        help="reprocess local_direct_inflight requests after this many seconds; 0 disables",
    )
    parser.add_argument("--model", default=os.environ.get("STOREBOT_CODEX_MODEL", DEFAULT_MODEL))
    parser.add_argument("--reasoning-effort", default=os.environ.get("STOREBOT_CODEX_REASONING_EFFORT", DEFAULT_REASONING_EFFORT))
    parser.add_argument("--cwd", default=os.environ.get("STOREBOT_CODEX_CWD", DEFAULT_CODEX_CWD))
    parser.add_argument("--guide", default=os.environ.get("STOREBOT_CODEX_GUIDE", str(DEFAULT_GUIDE)))
    parser.add_argument("--skill-name", default=os.environ.get("STOREBOT_CODEX_SKILL", DEFAULT_SKILL_NAME))
    parser.add_argument("--dynamic-guidance", action=argparse.BooleanOptionalAction, default=env_bool("STOREBOT_CODEX_DYNAMIC_GUIDANCE", True))
    parser.add_argument("--local-direct-server", action=argparse.BooleanOptionalAction, default=env_bool("STOREBOT_CODEX_LOCAL_DIRECT_SERVER", True))
    parser.add_argument("--local-direct-host", default=os.environ.get("STOREBOT_CODEX_LOCAL_DIRECT_HOST", "127.0.0.1"))
    parser.add_argument("--local-direct-port", type=int, default=int(os.environ.get("STOREBOT_CODEX_LOCAL_DIRECT_PORT", "8765")))
    parser.add_argument("--node", default=os.environ.get("STOREBOT_CODEX_NODE", "subphone_termux"))
    parser.add_argument("--self-sync", action=argparse.BooleanOptionalAction, default=env_bool("STOREBOT_CODEX_SELF_SYNC", True))
    parser.add_argument(
        "--self-sync-manifest-url",
        default=os.environ.get("STOREBOT_CODEX_SELF_SYNC_MANIFEST_URL", DEFAULT_SELF_SYNC_MANIFEST_URL),
    )
    parser.add_argument(
        "--self-sync-interval-sec",
        type=float,
        default=float(os.environ.get("STOREBOT_CODEX_SELF_SYNC_INTERVAL_SEC", "600")),
    )
    parser.add_argument("--sync-once", action="store_true", help="check/apply worker bundle self-sync, then exit")
    parser.add_argument("--bootstrap-only", action="store_true", help="create or verify a room session, then exit")
    parser.add_argument("--mcp-server", action="store_true", help="run StoreBot tool MCP server over stdio")
    parser.add_argument("--mcp-context-json", default=os.environ.get("STOREBOT_MCP_REQUEST_CONTEXT_JSON", ""))
    parser.add_argument("--openclaw-latest-final", action="store_true", help="diagnostic only: print latest OpenClaw final assistant text from local session logs")
    parser.add_argument("--openclaw-final-path", default="", help="diagnostic only: print OpenClaw final assistant text from one session or trajectory JSONL")
    parser.add_argument(
        "--openclaw-sessions-dir",
        default=default_openclaw_sessions_dir(),
    )
    parser.add_argument("--improvement-report-once", action="store_true", help="write one StoreBotTermux improvement report")
    parser.add_argument("--improvement-report-watch", action="store_true", help="write StoreBotTermux improvement reports periodically")
    parser.add_argument(
        "--improvement-report-daily",
        action=argparse.BooleanOptionalAction,
        default=env_bool("STOREBOT_IMPROVEMENT_REPORT_DAILY", True),
        help="run improvement analysis once per KST day at the configured quiet time",
    )
    parser.add_argument(
        "--improvement-report-time-kst",
        default=os.environ.get("STOREBOT_IMPROVEMENT_REPORT_TIME_KST", "04:30"),
        help="KST HH:MM quiet-time target for daily improvement analysis",
    )
    parser.add_argument(
        "--improvement-report-defer-sec",
        type=float,
        default=float(os.environ.get("STOREBOT_IMPROVEMENT_REPORT_DEFER_SEC", "1800")),
        help="defer by this many seconds when the daily low-load check fails",
    )
    parser.add_argument(
        "--improvement-report-max-defer-sec",
        type=float,
        default=float(os.environ.get("STOREBOT_IMPROVEMENT_REPORT_MAX_DEFER_SEC", "14400")),
        help="skip the daily report after this many low-load deferral seconds",
    )
    parser.add_argument(
        "--improvement-report-interval-sec",
        type=float,
        default=float(os.environ.get("STOREBOT_IMPROVEMENT_REPORT_INTERVAL_SEC", "1800")),
    )
    parser.add_argument(
        "--improvement-report-initial-delay-sec",
        type=float,
        default=float(os.environ.get("STOREBOT_IMPROVEMENT_REPORT_INITIAL_DELAY_SEC", "180")),
    )
    parser.add_argument(
        "--improvement-report-hours",
        type=float,
        default=float(os.environ.get("STOREBOT_IMPROVEMENT_REPORT_HOURS", "24")),
    )
    parser.add_argument(
        "--improvement-report-app",
        default=os.environ.get("STOREBOT_IMPROVEMENT_REPORT_APP", DEFAULT_IMPROVEMENT_APP_NAME),
    )
    parser.add_argument(
        "--improvement-report-model",
        default=os.environ.get("STOREBOT_IMPROVEMENT_REPORT_MODEL", DEFAULT_IMPROVEMENT_REPORT_MODEL),
    )
    parser.add_argument(
        "--improvement-report-reasoning-effort",
        default=os.environ.get("STOREBOT_IMPROVEMENT_REPORT_REASONING_EFFORT", DEFAULT_IMPROVEMENT_REPORT_REASONING_EFFORT),
    )
    parser.add_argument(
        "--improvement-report-timeout-sec",
        type=int,
        default=int(os.environ.get("STOREBOT_IMPROVEMENT_REPORT_TIMEOUT_SEC", "420")),
    )
    parser.add_argument("--enqueue-test", default="", help="write a manual test request, then exit")
    parser.add_argument("--enqueue-no-publish", action="store_true", help="mark an enqueued manual test as no_publish")
    parser.add_argument("--room-id", default="storebot_default")
    parser.add_argument("--room-name", default="StoreBot")
    parser.add_argument("--sender", default="manual")
    args = parser.parse_args(argv)
    if args.reclaim_running_sec <= 0:
        args.reclaim_running_sec = max(float(args.timeout_sec) + 180.0, 300.0)
    if args.reclaim_inflight_sec < 0:
        args.reclaim_inflight_sec = 0
    if str(args.model).strip().lower() in {"", "auto", "default", "codex_default"}:
        args.model = None
    elif args.model:
        args.model = str(args.model).strip()
    raw_effort = str(args.reasoning_effort).strip().lower()
    if raw_effort in {"", "auto", "default", "codex_default"}:
        args.reasoning_effort = None
    elif raw_effort in ALLOWED_REASONING_EFFORTS:
        args.reasoning_effort = raw_effort
    else:
        raise SystemExit(
            "--reasoning-effort must be one of: "
            + ", ".join(sorted(ALLOWED_REASONING_EFFORTS))
        )
    report_effort = normalize_effort(args.improvement_report_reasoning_effort, DEFAULT_IMPROVEMENT_REPORT_REASONING_EFFORT)
    if report_effort not in ALLOWED_REASONING_EFFORTS:
        raise SystemExit(
            "--improvement-report-reasoning-effort must be one of: "
            + ", ".join(sorted(ALLOWED_REASONING_EFFORTS))
        )
    args.improvement_report_reasoning_effort = report_effort
    if not (
        args.watch
        or args.once
        or args.bootstrap_only
        or args.mcp_server
        or args.enqueue_test
        or args.sync_once
        or args.openclaw_latest_final
        or args.openclaw_final_path
        or args.improvement_report_once
        or args.improvement_report_watch
    ):
        args.once = True
    return args


def main(argv: list[str]) -> int:
    args = parse_args(argv)
    if args.mcp_server:
        return run_mcp_server(args)
    if args.openclaw_latest_final or args.openclaw_final_path:
        if args.openclaw_final_path:
            result = extract_openclaw_final_from_path(Path(args.openclaw_final_path).expanduser())
        else:
            result = latest_openclaw_final(Path(args.openclaw_sessions_dir).expanduser())
        print(json.dumps(result, ensure_ascii=False, indent=2, sort_keys=True))
        return 0 if result.get("ok") is True else 1
    if args.enqueue_test:
        enqueue_test(args)
        return 0
    if args.bootstrap_only:
        bootstrap_only(args)
        return 0
    if args.improvement_report_once:
        run_improvement_report_once(args)
        return 0
    if args.improvement_report_watch:
        log(
            "storebot improvement report watcher started "
            f"app={args.improvement_report_app} interval={args.improvement_report_interval_sec}s "
            f"model={args.improvement_report_model}/{args.improvement_report_reasoning_effort}"
        )
        while True:
            try:
                run_improvement_report_once(args)
            except KeyboardInterrupt:
                log("storebot improvement report watcher stopped")
                return 130
            except Exception as exc:
                log(f"improvement report loop error: {compact_error(str(exc), 500)}")
            time.sleep(max(300.0, float(args.improvement_report_interval_sec or 1800)))
    if args.sync_once:
        return SELF_SYNC_EXIT_CODE if maybe_self_sync(args) else 0
    if args.self_sync and not args.dry_run:
        try:
            if maybe_self_sync(args):
                return SELF_SYNC_EXIT_CODE
        except Exception as exc:
            error = compact_error(str(exc))
            write_heartbeat(args, 0, "self_sync_error", error)
            record_self_sync_status(args, "error", {}, error)
            log(f"self-sync error: {error}")
    if args.watch:
        log("storebot codex worker started")
        if args.local_direct_server and not args.dry_run:
            start_local_direct_server(args)
        start_resident_session_preboot_thread(args)
        start_resident_session_watchdog_thread(args)
        if not args.dry_run:
            start_fast_router_prewarm_thread(args)
        if env_bool("STOREBOT_IMPROVEMENT_REPORT_ENABLED", True) and not args.dry_run:
            start_improvement_report_thread(args)
        next_sync_check = time.monotonic() + max(args.self_sync_interval_sec, 60)
        while True:
            try:
                if args.self_sync and not args.dry_run and time.monotonic() >= next_sync_check:
                    next_sync_check = time.monotonic() + max(args.self_sync_interval_sec, 60)
                    if maybe_self_sync(args):
                        return SELF_SYNC_EXIT_CODE
                if not args.dry_run:
                    maybe_recover_resident_app_server(args, "watch_loop_resident_recovery")
                run_once(args)
            except KeyboardInterrupt:
                log("storebot codex worker stopped")
                return 130
            except Exception as exc:
                error = compact_error(str(exc))
                if not args.dry_run:
                    write_heartbeat(args, 0, "error", error)
                log(f"loop error: {error}")
            time.sleep(args.poll_sec)
    run_once(args)
    return 0


if __name__ == "__main__":
    raise SystemExit(main(sys.argv[1:]))
