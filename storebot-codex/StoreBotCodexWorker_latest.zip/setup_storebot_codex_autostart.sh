#!/system/bin/sh
if [ -z "${STOREBOT_CODEX_BASH_REEXEC:-}" ]; then
  for candidate in "${STOREBOT_TERMUX_DATA_DIR:-}" /data/data/com.sbotux /data/data/com.termux; do
    [ -n "$candidate" ] || continue
    if [ -x "$candidate/files/usr/bin/bash" ]; then
      export STOREBOT_CODEX_BASH_REEXEC=1
      exec "$candidate/files/usr/bin/bash" "$0" "$@"
    fi
  done
fi
set -euo pipefail

resolve_termux_data_dir() {
  if [ -n "${STOREBOT_TERMUX_DATA_DIR:-}" ] && [ -x "$STOREBOT_TERMUX_DATA_DIR/files/usr/bin/bash" ]; then
    printf '%s\n' "$STOREBOT_TERMUX_DATA_DIR"
    return 0
  fi
  for candidate in /data/data/com.sbotux /data/data/com.termux; do
    if [ -x "$candidate/files/usr/bin/bash" ]; then
      printf '%s\n' "$candidate"
      return 0
    fi
  done
  printf '%s\n' "/data/data/com.sbotux"
}

APP_DATA_DIR="$(resolve_termux_data_dir)"
APP_PREFIX="$APP_DATA_DIR/files/usr"
export PREFIX="${PREFIX:-$APP_PREFIX}"
export PATH="$APP_PREFIX/bin:$APP_PREFIX/bin/applets:/system/bin:/system/xbin:$PATH"

DEFAULT_TERMUX_HOME="$APP_DATA_DIR/files/home"
TERMUX_HOME="${TERMUX_HOME:-}"
if [ -d "$DEFAULT_TERMUX_HOME" ]; then
  TERMUX_HOME="$DEFAULT_TERMUX_HOME"
elif [ -z "$TERMUX_HOME" ]; then
  TERMUX_HOME="${HOME:-}"
fi
if [ -z "$TERMUX_HOME" ] || [ "$TERMUX_HOME" = "/" ] || [ "$TERMUX_HOME" = "/root" ] || [ "$TERMUX_HOME" = "/data/user/0/com.sbotux" ] || [ "$TERMUX_HOME" = "/data/user/0/com.termux" ]; then
  TERMUX_HOME="$DEFAULT_TERMUX_HOME"
fi

ROOT_COPY="${STOREBOT_CODEX_ROOT_COPY:-/sdcard/Download/storebot_codex_worker}"
BOOT_DIR="$TERMUX_HOME/.termux/boot"
AUTOSTART_DIR="$TERMUX_HOME/.termux/storebot-codex"
PROPERTIES="$TERMUX_HOME/.termux/termux.properties"
BASHRC="$TERMUX_HOME/.bashrc"

mkdir -p "$BOOT_DIR" "$AUTOSTART_DIR" "$ROOT_COPY"

chmod +x \
  "$ROOT_COPY/launch_storebot_codex_background.sh" \
  "$ROOT_COPY/restart_storebot_codex_worker.sh" \
  "$ROOT_COPY/watch_storebot_codex_worker.sh" \
  "$ROOT_COPY/run_storebot_codex_worker.sh" \
  "$ROOT_COPY/harden_storebottermux_power.sh" \
  "$ROOT_COPY/check_storebot_codex_worker.sh" \
  "$ROOT_COPY/install_storebot_codex_termux.sh" \
  "$ROOT_COPY/fix_storebot_codex_copy.sh" 2>/dev/null || true

cat > "$BOOT_DIR/10-storebot-codex.sh" <<'EOF'
#!/system/bin/sh
case "${STOREBOT_CODEX_TERMUX_BOOT_AUTOSTART:-0}" in
  1|true|True|yes|Yes) ;;
  *) exit 0 ;;
esac
for candidate in "${STOREBOT_TERMUX_DATA_DIR:-}" /data/data/com.sbotux /data/data/com.termux; do
  [ -n "$candidate" ] || continue
  if [ -x "$candidate/files/usr/bin/bash" ]; then
    exec "$candidate/files/usr/bin/bash" /sdcard/Download/storebot_codex_worker/launch_storebot_codex_background.sh boot
  fi
done
exit 1
EOF
chmod +x "$BOOT_DIR/10-storebot-codex.sh"

cat > "$BOOT_DIR/11-storebot-codex-watchdog.sh" <<'EOF'
#!/system/bin/sh
case "${STOREBOT_CODEX_SHELL_WATCHDOG_AUTOSTART:-0}" in
  1|true|True|yes|Yes) ;;
  *) exit 0 ;;
esac
for candidate in "${STOREBOT_TERMUX_DATA_DIR:-}" /data/data/com.sbotux /data/data/com.termux; do
  [ -n "$candidate" ] || continue
  if [ -x "$candidate/files/usr/bin/bash" ]; then
    nohup "$candidate/files/usr/bin/bash" /sdcard/Download/storebot_codex_worker/watch_storebot_codex_worker.sh boot >/sdcard/Download/storebot_codex_worker/watchdog_boot.log 2>&1 &
    exit 0
  fi
done
exit 1
EOF
chmod +x "$BOOT_DIR/11-storebot-codex-watchdog.sh"

cat > "$AUTOSTART_DIR/autostart.sh" <<'EOF'
# StoreBot Codex shell-open fallback. StoreBotTermux app supervisor is the primary owner.
case "${STOREBOT_CODEX_SHELL_AUTOSTART:-0}" in
  1|true|True|yes|Yes) ;;
  *) return 0 2>/dev/null || exit 0 ;;
esac

if [ -r /sdcard/Download/storebot_codex_worker/launch_storebot_codex_background.sh ]; then
  STOREBOT_CODEX_BASH_PATH=""
  for candidate in "${STOREBOT_TERMUX_DATA_DIR:-}" /data/data/com.sbotux /data/data/com.termux; do
    [ -n "$candidate" ] || continue
    if [ -x "$candidate/files/usr/bin/bash" ]; then
      STOREBOT_CODEX_BASH_PATH="$candidate/files/usr/bin/bash"
      break
    fi
  done
  if [ -n "$STOREBOT_CODEX_BASH_PATH" ]; then
    "$STOREBOT_CODEX_BASH_PATH" /sdcard/Download/storebot_codex_worker/launch_storebot_codex_background.sh shell >/dev/null 2>&1 || true
  fi
fi
case "${STOREBOT_CODEX_SHELL_WATCHDOG_AUTOSTART:-0}" in
  1|true|True|yes|Yes)
    if [ -r /sdcard/Download/storebot_codex_worker/watch_storebot_codex_worker.sh ]; then
      if [ -n "${STOREBOT_CODEX_BASH_PATH:-}" ]; then
        nohup "$STOREBOT_CODEX_BASH_PATH" /sdcard/Download/storebot_codex_worker/watch_storebot_codex_worker.sh shell >/sdcard/Download/storebot_codex_worker/watchdog_shell.log 2>&1 &
      fi
    fi
    ;;
esac
EOF

if [ ! -f "$BASHRC" ]; then
  : > "$BASHRC"
fi
if ! grep -Fq "storebot-codex/autostart.sh" "$BASHRC"; then
  {
    echo
    echo "# StoreBot Codex worker autostart"
    echo '[ -r "$HOME/.termux/storebot-codex/autostart.sh" ] && . "$HOME/.termux/storebot-codex/autostart.sh"'
  } >> "$BASHRC"
fi

mkdir -p "$(dirname "$PROPERTIES")"
if [ -f "$PROPERTIES" ] && grep -q '^allow-external-apps=' "$PROPERTIES"; then
  sed -i 's/^allow-external-apps=.*/allow-external-apps=true/' "$PROPERTIES"
else
  {
    echo
    echo "allow-external-apps=true"
  } >> "$PROPERTIES"
fi

termux-reload-settings >/dev/null 2>&1 || true
termux-wake-lock >/dev/null 2>&1 || true

echo "StoreBot Codex autostart configured."
echo "Boot script: $BOOT_DIR/10-storebot-codex.sh (disabled unless STOREBOT_CODEX_TERMUX_BOOT_AUTOSTART=1)"
echo "Emergency watchdog script: $BOOT_DIR/11-storebot-codex-watchdog.sh (disabled unless STOREBOT_CODEX_SHELL_WATCHDOG_AUTOSTART=1)"
echo "Shell fallback: $AUTOSTART_DIR/autostart.sh (disabled unless STOREBOT_CODEX_SHELL_AUTOSTART=1)"
