#!/bin/sh
set -eu

ROOT_DIR="$(CDPATH= cd -- "$(dirname -- "$0")/.." && pwd)"
APP_DIR="${POSDELAY_APP_DIR:-/root/PosDelay}"
HOST_DIR="${POSDELAY_HOST_DIR:-$ROOT_DIR/AttendanceBoard/docs/posdelay}"
APK_SOURCE="$APP_DIR/app/build/outputs/apk/debug/app-debug.apk"
META_FILE="$APP_DIR/app/build/outputs/apk/debug/output-metadata.json"
HOSTED_APK_NAME="PosDelay_latest.bin"
APK_URL="https://poskds-attendance.web.app/posdelay/$HOSTED_APK_NAME"

cleanup() {
  sh "$APP_DIR/gradlew" -p "$APP_DIR" --stop >/dev/null 2>&1 || true
}
trap cleanup EXIT

mkdir -p "$HOST_DIR"

# Release contract lock: source changes cannot reach the update center unless
# the full JVM suite (including HumanDelay/BaeminBid lock tests) passes first.
sh "$APP_DIR/gradlew" -p "$APP_DIR" :app:testDebugUnitTest

if [ "${POSDELAY_SKIP_BUILD:-0}" != "1" ]; then
  sh "$APP_DIR/gradlew" -p "$APP_DIR" :app:assembleDebug
fi

VERSION_CODE="$(python3 -c 'import json,sys; print(json.load(open(sys.argv[1]))["elements"][0]["versionCode"])' "$META_FILE")"
VERSION_NAME="$(python3 -c 'import json,sys; print(json.load(open(sys.argv[1]))["elements"][0]["versionName"])' "$META_FILE")"
SHA256="$(sha256sum "$APK_SOURCE" | awk '{print $1}')"
UPDATED_AT="$(TZ=Asia/Seoul date +%Y-%m-%dT%H:%M:%S%z)"
RELEASE_NOTES="${POSDELAY_RELEASE_NOTES:-PosDelay 자동 업데이트}"

cp "$APK_SOURCE" "$HOST_DIR/$HOSTED_APK_NAME"

python3 "$ROOT_DIR/scripts/write_update_manifest.py" \
  --host-dir "$HOST_DIR" \
  --channel-id "posdelay" \
  --label "PosDelay" \
  --version-code "$VERSION_CODE" \
  --version-name "$VERSION_NAME" \
  --artifact-url "$APK_URL" \
  --artifact-sha256 "$SHA256" \
  --release-notes "$RELEASE_NOTES" \
  --updated-at "$UPDATED_AT"

cat > "$HOST_DIR/index.html" <<EOF
<!doctype html>
<html lang="ko">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>PosDelay 업데이트</title>
  <style>
    body { margin:0; min-height:100vh; display:grid; place-items:center; background:#10140f; color:#f8fff6; font-family:sans-serif; }
    main { width:min(92vw, 460px); padding:32px; border:1px solid #2f4e2e; border-radius:20px; background:#172414; box-shadow:0 20px 70px rgba(0,0,0,.35); }
    h1 { margin:0 0 8px; font-size:28px; }
    p { color:#c7d7c2; line-height:1.55; }
    a { display:block; margin-top:24px; padding:18px; border-radius:14px; background:#85df54; color:#071606; text-align:center; font-weight:700; text-decoration:none; }
    small { display:block; margin-top:18px; color:#8fa38b; word-break:break-all; }
  </style>
</head>
<body>
  <main>
    <h1>PosDelay 업데이트</h1>
    <p>버전 $VERSION_NAME ($VERSION_CODE)</p>
    <p>$RELEASE_NOTES</p>
    <a href="$HOSTED_APK_NAME" download="PosDelay_latest.apk">PosDelay APK 다운로드</a>
    <small>SHA-256: $SHA256</small>
  </main>
</body>
</html>
EOF

(cd "$ROOT_DIR" && firebase deploy --only hosting:attendance --project poskds-4ba60)

printf 'PosDelay auto-update deployed: %s (%s)\n%s\n' "$VERSION_NAME" "$VERSION_CODE" "$APK_URL"
