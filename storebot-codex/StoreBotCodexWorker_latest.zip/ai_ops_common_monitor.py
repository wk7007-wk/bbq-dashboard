#!/usr/bin/env python3
"""Common low-load AI ops monitor for project heartbeats, queues, and self-fix.

This script does not make app-specific business decisions. It only turns broad
operational symptoms into a report and, when requested, a codex_ops self_fix
task so the AI session can inspect the project with its own context.
"""

from __future__ import annotations

import argparse
import datetime as dt
import hashlib
import json
import os
import re
import secrets
import subprocess
import sys
import time
import urllib.parse
import urllib.request
from typing import Any

try:
    from .diagnostic_redaction import redact_diagnostic_payload
except ImportError:  # Direct script execution from scripts/.
    from diagnostic_redaction import redact_diagnostic_payload


def env_int(name: str, default: int) -> int:
    try:
        return int(os.environ.get(name, str(default)))
    except (TypeError, ValueError):
        return default


def current_git_revision(repo: str = "/root/my-first-project") -> str:
    try:
        return subprocess.check_output(
            ["git", "-C", repo, "rev-parse", "--short=12", "HEAD"],
            text=True,
            stderr=subprocess.DEVNULL,
            timeout=5,
        ).strip()
    except Exception:
        return ""


def file_mtime_ms(path: str) -> int:
    try:
        return int(os.path.getmtime(path) * 1000)
    except OSError:
        return 0


FB_URL = os.environ.get(
    "AI_OPS_FB_URL",
    "https://poskds-4ba60-default-rtdb.asia-southeast1.firebasedatabase.app",
).rstrip("/")

AI_OPS_BASE_PATH = os.environ.get("AI_OPS_BASE_PATH", "/packhelper/ai_ops_monitor_v2").rstrip("/")
OUT_PATH = f"{AI_OPS_BASE_PATH}/latest"
PROJECTS_PATH = f"{AI_OPS_BASE_PATH}/projects"
HEARTBEAT_PATH = f"{AI_OPS_BASE_PATH}/heartbeat"
SELF_FIX_STATE_PATH = f"{AI_OPS_BASE_PATH}/self_fix"
CODEX_OPS_BASE_PATH = os.environ.get("CODEX_OPS_BASE_PATH", "/packhelper/codex_ops_v2").rstrip("/")
CODEX_OPS_REQUESTS_PATH = f"{CODEX_OPS_BASE_PATH}/requests"
CODEX_OPS_HEARTBEAT_PATH = f"{CODEX_OPS_BASE_PATH}/heartbeat/subphone_termux_ops"
PC_CODEX_CLI_REQUESTS_PATH = os.environ.get(
    "PC_CODEX_CLI_REQUESTS_PATH", "/packhelper/pc_codex_cli/requests"
).rstrip("/")
POSDELAY_RUNTIME_SELF_HEAL_PATH = f"{AI_OPS_BASE_PATH}/self_heal/posdelay_runtime"
POSDELAY_CMD_PATH = "/subphone/cmd/posdelay"
STOREBOT_BRIEFING_CHANNEL_DIR = os.environ.get(
    "STOREBOT_BRIEFING_CHANNEL_DIR",
    "/sdcard/Download/StoreBotTermux/briefing_channel",
).rstrip("/")
STOREBOT_CODEX_BUNDLE_MANIFEST_URL = os.environ.get(
    "STOREBOT_CODEX_BUNDLE_MANIFEST_URL",
    "https://wk7007-ops-static-2026.web.app/storebot-codex/bundle.json",
)
SOLNOTE_ANALYSIS_WORKER_STATUS_PATH = os.environ.get(
    "SOLNOTE_ANALYSIS_WORKER_STATUS_PATH",
    "/sdcard/Download/solnote_analysis_worker/status.json",
)

KST = dt.timezone(dt.timedelta(hours=9))
SEVERITY_SCORE = {"ok": 0, "info": 0, "warn": 1, "error": 2, "critical": 3}
OK_STATUSES = {"idle", "watching", "processing", "active", "alive", "ok", "server", "sse_listener"}
FB_FORBIDDEN_KEY_CHARS = set(".#$[]/")
DEFAULT_SELF_FIX_PROFILE = os.environ.get("AI_OPS_SELF_FIX_PROFILE", "patch")
DEFAULT_SELF_FIX_MODEL = os.environ.get("AI_OPS_SELF_FIX_MODEL", "gpt-5.5")
DEFAULT_SELF_FIX_REASONING_EFFORT = os.environ.get("AI_OPS_SELF_FIX_REASONING_EFFORT", "xhigh")
DEFAULT_SELF_FIX_TIMEOUT_SEC = env_int("AI_OPS_SELF_FIX_TIMEOUT_SEC", 1200)
DEFAULT_SELF_FIX_TTL_MS = env_int("AI_OPS_SELF_FIX_TTL_MS", 6 * 60 * 60 * 1000)
PAUSED_EXTERNAL_REQUEST_STATUSES = {"paused_external_session"}
POSDELAY_CA_EXTERNAL_NODES = {
    "subphone_ai_ops_monitor",
    "subphone_sbotux_ai_ops_monitor",
    "subphone_termux_ops",
    "pc_codex_resource_01",
}
STOREBOT_CA_EXTERNAL_NODES = {
    "subphone_ai_ops_monitor",
    "subphone_sbotux_ai_ops_monitor",
    "subphone_termux_ops",
    "pc_codex_resource_01",
}
PROJECT_CA_EXTERNAL_NODES = frozenset(STOREBOT_CA_EXTERNAL_NODES)
PROJECT_CA_PERSONAL_NODES = {"personal_main"}
PROJECT_CA_SAFE_FAILURE_REASONS = frozenset(
    {
        "project_ca_identity_not_configured",
        "project_ca_storebot_seed_not_configured",
        "project_ca_storebot_seed_unavailable",
        "project_ca_storebot_seed_not_private",
        "project_ca_storebot_seed_length_invalid",
        "project_ca_identity_not_private",
        "project_ca_identity_length_invalid",
        "project_ca_registry_invalid",
        "project_ca_snapshot_invalid",
        "project_ca_room_registry_invalid",
        "project_ca_lifecycle_setup_invalid",
        "project_ca_lifecycle_projection_failed",
    }
)
POSDELAY_RUNTIME_SELF_HEAL_COOLDOWN_MIN = env_int("POSDELAY_RUNTIME_SELF_HEAL_COOLDOWN_MIN", 10)
POSDELAY_RUNTIME_ISSUE_CODES = {
    "kds_sync_stale",
    "kds_accessibility_off",
    "delay_accessibility_off",
    "no_accessibility",
}
STOREBOT_CODEX_REQUESTS_PATH = "/packhelper/storebot_codex/requests"
STOREBOT_PENDING_QUEUE_PATH = "/packhelper/storebot_pending_queue"
STOREBOT_WORK_SCHEDULE_BROADCAST_STATE_PATH = "/packhelper/storebot_termux/work_schedule_broadcast_state"
STOREBOT_WORK_SCHEDULE_BROADCAST_INTERVAL_MS = 6 * 60 * 60 * 1000
STOREBOT_BRIEFING_MISSING_GRACE_MIN = env_int("STOREBOT_BRIEFING_MISSING_GRACE_MIN", 5)
STOREBOT_BRIEFING_STALE_MIN = env_int("STOREBOT_BRIEFING_STALE_MIN", 30)
STOREBOT_BROADCAST_ACTIVE_REQUEST_STATUSES = {
    "pending",
    "local_direct_inflight",
    "local_recovery_pending",
    "running",
    "processing",
}
STOREBOT_BROADCAST_TERMINAL_REQUEST_STATUSES = {
    "done",
    "error",
    "failed_timeout",
    "stale_killed",
    "rejected",
    "expired",
}


PROJECT_CONFIGS: dict[str, dict[str, Any]] = {
    "CoreOps": {
        "cwd": "/root/my-first-project",
        "domain": "common_ai_ops",
        "safety": "codex_ops 실행자와 공용 모니터만 점검한다. 앱 데이터 원본을 직접 바꾸지 않는다.",
        "heartbeats": [
            {
                "name": "codex_ops_worker",
                "path": CODEX_OPS_HEARTBEAT_PATH,
                "max_age_min": 5,
                "required": True,
                "require": {"status": ["idle", "processing"]},
            }
        ],
        "queues": [
            {
                "name": "codex_ops_requests",
                "path": CODEX_OPS_REQUESTS_PATH,
                "statuses": ["pending"],
                "running_statuses": ["running"],
                "target_host": "subphone",
                "target_node": "subphone_termux_ops",
                "max_pending_age_min": 75,
                "max_running_age_min": 90,
                "check_local_claim_pid": True,
                "limit": 200,
            }
        ],
    },
    "SolNote": {
        "cwd": "/root/solnote-codex-gemini-XKswTk/SolNote",
        "domain": "solnote_analysis",
        "safety": (
            "개인 note 원문, encrypted packet, token, key를 monitor/self_fix/Telegram에 넣지 않는다. "
            "worker 상태와 content-free receipt만 진단하며 credential 생성·복사·live enable은 자동화하지 않는다."
        ),
        "self_fix": {
            "profile": "read_only",
            "mode": "read_only_diagnosis",
            "repair_scope": "solnote_worker_health_only_no_credentials_no_provider_no_live_write",
        },
        "local_json_checks": [
            {
                "name": "solnote_analysis_worker_availability",
                "path": SOLNOTE_ANALYSIS_WORKER_STATUS_PATH,
                "ts_fields": ["updated_at_ms"],
                "status_fields": ["status"],
                "bad_statuses": ["LIVE_DISABLED", "OFFLINE_UNPROVISIONED"],
                "bad_severity": "warn",
                "missing_severity": "warn",
                "max_age_min": 10,
                "stale_severity": "warn",
            },
            {
                "name": "solnote_analysis_worker_failure",
                "path": SOLNOTE_ANALYSIS_WORKER_STATUS_PATH,
                "ts_fields": ["updated_at_ms"],
                "status_fields": ["status"],
                "failure_fields": ["last_receipt_status"],
                "bad_statuses": ["FAILED_CLOSED"],
                "bad_severity": "error",
                "missing_ok": True,
            },
        ],
    },
    "StoreBot": {
        "cwd": "/root/my-first-project",
        "domain": "storebot_kakao",
        "safety": "첫 판단은 Codex AI가 한다. 카톡 답변 외 운반, PNG 렌더, Firebase 상태 복구만 자동화하고 카톡 원문 선분류 하드코딩을 추가하지 않는다.",
        "heartbeats": [
            {
                "name": "storebot_codex_worker",
                "path": "/packhelper/storebot_codex/heartbeat",
                "max_age_min": 5,
                "required": True,
                "require": {
                    "alive": True,
                    "local_direct_listening": True,
                },
                "require_any": [
                    {
                        "fast_router_stateless_exec": False,
                        "resident_app_server_enabled": False,
                    },
                    {
                        "resident_app_server_enabled": True,
                        "resident_app_server_active": True,
                    },
                ],
            },
            {
                "name": "storebot_termux_transport",
                "path": "/packhelper/storebot_termux/heartbeat",
                "max_age_min": 3,
                "required": True,
                "require": {
                    "alive": True,
                    "accessibility_enabled": True,
                    "notification_listener_enabled": True,
                    "legacy_storebot_accessibility_present": False,
                },
            }
        ],
        "queues": [
            {
                "name": "storebot_requests",
                "path": "/packhelper/storebot_codex/requests",
                "statuses": ["pending", "local_direct_inflight", "local_recovery_pending"],
                "running_statuses": ["running", "processing"],
                "max_pending_age_min": 12,
                "max_running_age_min": 12,
                "limit": 240,
            },
            {
                "name": "storebot_pending_queue",
                "path": "/packhelper/storebot_pending_queue",
                "unsent_message_queue": True,
                "max_pending_age_min": 5,
                "limit": 240,
            },
        ],
        "kakao_reply_flows": [
            {
                "name": "storebot_kakao_reply_flow",
                "claim_path": "/packhelper/storebot_termux/kakao_ingress_claims/latest",
                "request_path": "/packhelper/storebot_codex/requests",
                "transport_heartbeat_path": "/packhelper/storebot_termux/heartbeat",
                "input_health_path": "/packhelper/storebot_termux/input_health/latest",
                "bridge_latest_path": "/packhelper/storebot_termux/kakao_bridge_log/latest",
                "recent_window_min": 30,
                "recent_error_window_min": 120,
                "max_claim_to_request_min": 2,
                "max_inflight_min": 10,
                "max_running_min": 10,
                "max_deferred_running_min": 12,
                "max_done_elapsed_ms": 600000,
                "max_skip_elapsed_ms": 60000,
                "max_claim_gap_with_scan_warn_min": 180,
                "max_claim_gap_with_scan_error_min": 24 * 60,
                "max_active_scan_age_min": 5,
                "slow_skip_severity": "info",
            }
        ],
        "bundle_sync_checks": [
            {
                "name": "storebot_worker_bundle_sync",
                "heartbeat_path": "/packhelper/storebot_codex/heartbeat",
                "command_path": "/subphone/cmd/storebot",
                "manifest_url": STOREBOT_CODEX_BUNDLE_MANIFEST_URL,
                "max_command_done_lag_min": 5,
                "max_manifest_lag_min": 60,
            }
        ],
        "events": [
            {
                "name": "storebot_subphone_alerts",
                "path": "/subphone/alerts/latest",
                "lookback_min": 12 * 60,
                "limit": 1,
                "severity": "warn",
                "bad_events": ["error", "failed", "stale", "경고", "오류", "실패"],
                "ignore_resolved": True,
            },
            {
                "name": "storebot_bridge_warning_events",
                "path": "/packhelper/storebot_termux/kakao_bridge_log/events",
                "lookback_min": 15,
                "limit": 160,
                "severity": "warn",
                "error_recent_count": 3,
                "ignore_events": [
                    "fallback full",
                    "kakao notification without title/text",
                    "active kakao scan",
                    "termux service wakelock requested",
                    "pending queue legacy scan failed",
                ],
                "bad_events": [
                    "failed",
                    "error",
                    "alert failed",
                    "guard failed",
                    "read failed",
                    "permission",
                    "unauthorized",
                    "경고",
                    "오류",
                    "실패",
                ],
            },
            {
                "name": "storebot_user_visible_warning_queue",
                "path": "/packhelper/storebot_pending_queue",
                "lookback_min": 12 * 60,
                "limit": 120,
                "severity": "warn",
                "error_recent_count": 3,
                "bad_events": ["[배터리 경고]", "경고", "오류", "실패"],
            },
        ],
        "local_json_checks": [
            {
                "name": "storebot_briefing_channel_latest",
                "path": f"{STOREBOT_BRIEFING_CHANNEL_DIR}/latest.json",
                "missing_ok": True,
                "ts_fields": ["room.updated_at_ms", "event.updated_at_ms", "updated_at_ms", "created_at_ms"],
                "status_fields": ["room.processing_status", "event.processing_status", "processing_status"],
                "failure_fields": ["room.failure_status", "room.missing_status", "event.failure_status", "failure_status"],
                "pending_statuses": ["local_direct_inflight"],
                "bad_statuses": [
                    "transport_failure",
                    "local_direct_failed",
                    "local_direct_deferred_failed",
                    "image_send_failed",
                    "send_failed",
                    "error",
                    "failed",
                ],
                "max_pending_age_min": 10,
            },
        ],
    },
    "DeliveryHelper": {
        "cwd": "/root/DeliveryHelper",
        "domain": "deliveryhelper",
        "safety": "주소, 비밀번호, 동호 확정값은 DeliveryHelper의 기존 재검토/보정 경계를 통과해야 한다. 실시간 주문 화면을 동기 대기하거나 임의 확정하지 않는다.",
        "heartbeats": [
            {
                "name": "gpt_reanalyze_worker",
                "path": "/packhelper/deliveryhelper/gpt_reanalyze/heartbeat",
                "max_age_min": 8,
                "required": True,
            },
            {
                "name": "deliveryhelper_mesh",
                "path": "/packhelper/heartbeat/deliveryhelper",
                "max_age_min": 20,
                "required": False,
            },
            {
                "name": "deliveryhelper_app_monitor",
                "path": "/monitor/deliveryhelper/status",
                "max_age_min": 12 * 60,
                "required": False,
                "fresh_only": True,
                # Legacy AppMonitor writes on app init/crash setup only; MeshHealthAgent
                # is the live DeliveryHelper heartbeat source.
                "stale_ok": True,
            },
        ],
        "queues": [
            {
                "name": "gpt_reanalyze_requests",
                "path": "/packhelper/deliveryhelper/gpt_reanalyze/requests",
                "statuses": ["pending"],
                "running_statuses": ["running", "processing"],
                "max_pending_age_min": 30,
                "max_running_age_min": 90,
                "limit": 200,
            }
        ],
        "events": [
            {
                "name": "deliveryhelper_error_judge_counter",
                "path": "/packhelper/ai_monitor/apps/DeliveryHelper/groq_error_judge",
                "lookback_min": 60,
                "limit": 1,
                "severity": "warn",
            },
            {
                "name": "deliveryhelper_crashes",
                "path": "/monitor/deliveryhelper/crashes",
                "lookback_min": 12 * 60,
                "limit": 20,
                "severity": "error",
            },
            {
                "name": "deliveryhelper_update_status",
                "path": "/packhelper/deliveryhelper/update_status/latest",
                "lookback_min": 12 * 60,
                "limit": 1,
                "severity": "warn",
                "bad_events": ["error", "failed", "install_failed", "download_failed", "unauthorized"],
            },
            {
                "name": "gpt_reanalyze_request_errors",
                "path": "/packhelper/deliveryhelper/gpt_reanalyze/requests",
                "lookback_min": 180,
                "limit": 50,
                "severity": "error",
                "min_recent_count": 1,
                "bad_events": [
                    "error",
                    "failed",
                    "codex",
                    "no such file",
                    "invalid data",
                    "firebase put",
                    "firebase 400",
                    "timeout",
                ],
                "ignore_resolved": True,
            },
        ],
        "status_checks": [
            {
                "name": "deliveryhelper_address_book_runner",
                "path": "/packhelper/system_health/latest/targets/address_book_runner",
                "field": "status",
                "ok_states": ["ok"],
                "pending_states": ["running", "processing", "building"],
                "bad_states": ["error", "failed"],
                "unknown_severity": "warn",
                "missing_ok": True,
            },
            {
                "name": "deliveryhelper_map_knowledge_runner",
                "path": "/packhelper/system_health/latest/targets/map_knowledge_runner",
                "field": "status",
                "ok_states": ["ok"],
                "pending_states": ["running", "processing", "building"],
                "bad_states": ["error", "failed"],
                "unknown_severity": "warn",
                "missing_ok": True,
            },
        ],
    },
    "PosDelay": {
        "cwd": "/root/PosDelay",
        "domain": "posdelay",
        "safety": "AI ops는 원인 분석, 설정/코드/문서/self_fix까지만 맡는다. 배민/쿠팡 실행은 기존 엔진 큐, 충돌 그룹, 휴먼 딜레이 경계를 통과해야 한다.",
        "heartbeats": [
            {
                "name": "posdelay_app_heartbeat",
                "path": "/posdelay/app_heartbeat",
                "max_age_min": 15,
                "required": True,
            },
            {
                "name": "posdelay_mesh",
                "path": "/packhelper/heartbeat/posdelay",
                "max_age_min": 10,
                "required": True,
            },
            {
                "name": "posdelay_app_monitor",
                "path": "/monitor/posdelay/status",
                "max_age_min": 12 * 60,
                "required": False,
                "fresh_only": True,
            },
            {
                "name": "posdelay_pc_macro",
                "path": "/posdelay/pc_macro/status",
                "max_age_min": 4,
                "required": True,
                "require": {
                    "alive": True,
                    "health": "OK",
                    "config_source": "firebase_v2",
                    "force_update_pending": False,
                },
            },
        ],
        "events": [
            {
                "name": "posdelay_error_reports",
                "path": "/posdelay/error_reports",
                "lookback_min": 60,
                "limit": 20,
                "severity": "warn",
            },
            {
                "name": "posdelay_crashes",
                "path": "/monitor/posdelay/crashes",
                "lookback_min": 12 * 60,
                "limit": 20,
                "severity": "error",
            },
            {
                "name": "posdelay_update_status",
                "path": "/posdelay/update_status/latest",
                "lookback_min": 12 * 60,
                "limit": 1,
                "severity": "warn",
                "bad_events": ["error", "failed", "install_failed", "download_failed"],
            },
        ],
        "metric_checks": [
            {
                "name": "posdelay_kds_amount_live",
                "path": "/posdelay/kds_amount_weight_test/latest",
                "max_age_min": 45,
                "min_orders": 1,
                "min_error_orders": 3,
                "warn_match_error_pct": 10,
                "error_match_error_pct": 35,
                "warn_delta_pct": 50,
                "error_delta_pct": 150,
                "expected_apply_to_live": True,
            }
        ],
        "consistency_checks": [
            {
                "name": "posdelay_pc_macro_kds_weighted_signal",
                "left_path": "/posdelay/pc_macro/status",
                "left_field": "kds_weighted_count",
                "left_ts_field": "ts_epoch_ms",
                "right_path": "/posdelay/signal_snapshot/kds",
                "right_field": "weighted_count",
                "right_ts_field": "updated_at",
                "max_delta": 0,
                "grace_sec": 90,
                "severity": "error",
            },
            {
                "name": "posdelay_pc_macro_command_ack",
                "left_path": "/posdelay/pc_macro/command",
                "left_field": "nonce",
                "left_ts_field": "requested_at",
                "right_path": "/posdelay/pc_macro/command_ack",
                "right_field": "nonce",
                "right_ts_field": "ts_epoch_ms",
                "grace_sec": 180,
                "left_missing_ok_status": "idle_no_command",
                "right_missing_grace_status": "waiting_for_ack",
                "severity": "error",
            }
        ],
    },
    "BankTotal": {
        "cwd": "/root/BankTotal",
        "domain": "banktotal",
        "safety": "금융 원본, 회차, 금액 확정 변경은 repository/local API/사용자 확인 경계를 통과해야 한다. AI ops는 조회, 불일치 후보, 수정안, 코드/설정 보정까지만 자동화한다.",
        "heartbeats": [
            {
                "name": "banktotal_app_monitor",
                "path": "/monitor/banktotal/status",
                "max_age_min": 7 * 24 * 60,
                "required": False,
                "fresh_only": True,
                "stale_ok": True,
            }
        ],
        "events": [
            {
                "name": "banktotal_crashes",
                "path": "/monitor/banktotal/crashes",
                "lookback_min": 12 * 60,
                "limit": 20,
                "severity": "error",
            },
            {
                "name": "banktotal_update_status",
                "path": "/banktotal/update_status/latest",
                "lookback_min": 12 * 60,
                "limit": 1,
                "severity": "warn",
                "bad_events": ["error", "failed", "install_failed", "download_failed"],
            }
        ],
    },
    "MainPC": {
        "cwd": "/root/SiteBot",
        "domain": "main_pc_sitebot",
        "safety": "메인PC/SiteBot/PC 서비스 상태와 요청 정체를 감시한다. 실제 사이트 조작이나 플랫폼 실행은 기존 SiteBot 명령 큐와 토큰/플랫폼 안전 경계를 통과해야 한다.",
        "self_fix": {
            "target_host": "pc",
            "target_node": "pc_codex_resource_01",
            "profile": "read_only",
            "mode": "read_only_diagnosis",
            "repair_scope": "pc_read_only_diagnosis_only_no_patch_no_write",
        },
        "heartbeats": [
            {
                "name": "main_pc_status",
                "path": "/monitor/main_pc/status",
                "max_age_min": 10,
                "required": True,
                "fresh_only": True,
                "require": {
                    "services.fire_capture.alive": True,
                    "services.fire_capture.port_8585": True,
                    "services.fire_capture.port_9100": True,
                },
            },
            {
                "name": "main_pc_storebot_server",
                "path": "/monitor/main_pc/status",
                "max_age_min": 10,
                "required": False,
                "fresh_only": True,
                "require": {
                    "services.storebot_server.alive": True,
                },
            },
        ],
        "queues": [
            {
                "name": "pc_codex_cli_requests",
                "path": PC_CODEX_CLI_REQUESTS_PATH,
                "statuses": ["pending"],
                "running_statuses": ["running"],
                "target_node": "pc_codex_resource_01",
                "max_pending_age_min": 75,
                "max_running_age_min": 90,
                "detect_finished_without_terminal": True,
                "finished_terminal_grace_min": 2,
                "limit": 200,
            }
        ],
        "single_requests": [
            {
                "name": "main_pc_sfa_order_request",
                "path": "/monitor/main_pc/sfa_order_request",
                "ts_field": "requestedAt",
                "max_age_min": 5,
            }
        ],
        "status_checks": [
            {
                "name": "main_pc_sfa_order_status",
                "path": "/monitor/main_pc/status",
                "field": "sfa_order.state",
                "ts_field": "sfa_order.updated_at",
                "ok_states": ["ok", "idle", "no_file", "applied", "already_applied"],
                "pending_states": ["requested", "pending", "waiting", "running", "analyzing", "processing"],
                "bad_states": ["error", "failed", "request_error", "analysis_error", "timeout"],
                "max_pending_age_min": 5,
                "required": True,
            }
        ],
    },
    "OrderHelper": {
        "cwd": "/root/OrderHelper",
        "domain": "orderhelper",
        "safety": "발주 품목, 단위, 환산, SFA 실발주 원본은 자동 확정하지 않는다. PC/SiteBot이 SFA 파일 스캔 실행자이고, Termux AI ops는 요청/상태 정체와 코드/설정/문서 보정까지만 맡는다.",
        "self_fix": {
            "target_host": "pc",
            "target_node": "pc_codex_resource_01",
            "profile": "read_only",
            "mode": "read_only_diagnosis",
            "repair_scope": "pc_read_only_diagnosis_only_no_patch_no_write",
        },
        "heartbeats": [
            {
                "name": "orderhelper_main_pc_status",
                "path": "/monitor/main_pc/status",
                "max_age_min": 20,
                "required": True,
                "fresh_only": True,
                "require": {
                    "services.fire_capture.alive": True,
                    "sfa_order.enabled": True,
                },
            }
        ],
        "single_requests": [
            {
                "name": "orderhelper_sfa_order_request",
                "path": "/monitor/main_pc/sfa_order_request",
                "ts_field": "requestedAt",
                "max_age_min": 5,
            }
        ],
        "status_checks": [
            {
                "name": "orderhelper_sfa_order_status",
                "path": "/monitor/main_pc/status",
                "field": "sfa_order.state",
                "ts_field": "sfa_order.updated_at",
                "ok_states": ["ok", "idle", "no_file", "applied", "already_applied"],
                "pending_states": ["requested", "pending", "waiting", "running", "analyzing", "processing"],
                "bad_states": ["error", "failed", "request_error", "analysis_error", "timeout"],
                "max_pending_age_min": 5,
                "required": True,
            }
        ],
    },
}


def now_ms() -> int:
    return int(dt.datetime.now(dt.timezone.utc).timestamp() * 1000)


def kst_text(ts_ms: int | None = None) -> str:
    value = dt.datetime.fromtimestamp((ts_ms or now_ms()) / 1000, KST)
    return value.strftime("%Y-%m-%d %H:%M:%S KST")


def fb_url(path: str, query: dict[str, Any] | None = None) -> str:
    safe = "/".join(urllib.parse.quote(part, safe="") for part in path.split("/") if part)
    url = f"{FB_URL}/{safe}.json"
    if query:
        url += "?" + urllib.parse.urlencode(query)
    return url


def fb_get(path: str, query: dict[str, Any] | None = None) -> Any:
    with urllib.request.urlopen(fb_url(path, query=query), timeout=20) as resp:
        body = resp.read().decode("utf-8")
    if not body or body == "null":
        return None
    return json.loads(body)


def fetch_json_url(url: str, timeout: float = 15.0) -> Any:
    with urllib.request.urlopen(url, timeout=timeout) as resp:
        body = resp.read().decode("utf-8")
    if not body:
        return None
    return json.loads(body)


def fb_write(method: str, path: str, data: Any) -> None:
    payload = json.dumps(firebase_safe(data), ensure_ascii=False, separators=(",", ":")).encode("utf-8")
    req = urllib.request.Request(
        fb_url(path),
        data=payload,
        method=method,
        headers={"Content-Type": "application/json; charset=utf-8"},
    )
    with urllib.request.urlopen(req, timeout=20) as resp:
        resp.read()


def fb_put(path: str, data: Any) -> None:
    fb_write("PUT", path, data)


def fb_patch(path: str, data: dict[str, Any]) -> None:
    fb_write("PATCH", path, data)


def firebase_safe_key(value: Any) -> str:
    text = str(value)
    return "".join("_" if ch in FB_FORBIDDEN_KEY_CHARS else ch for ch in text)


def firebase_safe(value: Any) -> Any:
    if isinstance(value, dict):
        return {firebase_safe_key(key): firebase_safe(item) for key, item in value.items()}
    if isinstance(value, list):
        return [firebase_safe(item) for item in value]
    return value


def normalize_ts_ms(value: Any) -> int:
    if isinstance(value, bool):
        return 0
    if isinstance(value, (int, float)):
        ts = int(value)
        if 0 < ts < 100_000_000_000:
            return ts * 1000
        return ts
    if isinstance(value, str):
        return parse_time_text(value)
    return 0


def parse_time_text(raw: str) -> int:
    text = raw.strip()
    if not text:
        return 0
    if text.isdigit():
        return normalize_ts_ms(int(text))
    normalized = text.replace("Z", "+00:00")
    try:
        parsed = dt.datetime.fromisoformat(normalized)
        if parsed.tzinfo is None:
            parsed = parsed.replace(tzinfo=KST)
        return int(parsed.timestamp() * 1000)
    except ValueError:
        pass
    for fmt in ("%Y-%m-%d %H:%M:%S", "%Y-%m-%d %H:%M", "%Y%m%d_%H%M%S"):
        try:
            parsed = dt.datetime.strptime(text[: len(fmt)], fmt)
            parsed = parsed.replace(tzinfo=KST)
            return int(parsed.timestamp() * 1000)
        except ValueError:
            continue
    return 0


def extract_ts_ms(data: Any, key: str = "") -> int:
    if not isinstance(data, dict):
        return parse_time_text(key)
    for field in (
        "ts",
        "ts_ms",
        "timestamp",
        "updated_at_ms",
        "finished_at_ms",
        "created_at_ms",
        "started_at_ms",
        "last_ts",
        "lastActive",
        "last",
        "time",
        "captured_at",
    ):
        ts = normalize_ts_ms(data.get(field))
        if ts > 0:
            return ts
    heartbeat = data.get("heartbeat")
    if isinstance(heartbeat, dict):
        ts = extract_ts_ms(heartbeat, key)
        if ts > 0:
            return ts
    return parse_time_text(key)


def age_min(ts_ms: int) -> float | None:
    if ts_ms <= 0:
        return None
    return round(max(0, now_ms() - ts_ms) / 60000, 1)


def compact(value: Any, limit: int = 240) -> str:
    text = " ".join(str(value or "").split())
    return text[:limit]


def status_text(data: dict[str, Any]) -> str:
    return str(data.get("status") or data.get("mode") or data.get("event") or "").strip()


def number_value(data: dict[str, Any], field: str, default: float = 0.0) -> float:
    try:
        value = data.get(field)
        if isinstance(value, bool) or value is None:
            return default
        return float(value)
    except (TypeError, ValueError):
        return default


def looks_alive(data: dict[str, Any]) -> bool:
    text = status_text(data).lower()
    heartbeat = data.get("heartbeat") if isinstance(data.get("heartbeat"), dict) else {}
    if data.get("ok") is True or data.get("alive") is True or heartbeat.get("alive") is True:
        return True
    if data.get("keep_alive") is True or data.get("reply_capable") is True:
        return True
    return text in OK_STATUSES


def child_records(data: Any) -> list[tuple[str, dict[str, Any]]]:
    if not isinstance(data, dict):
        return []
    if extract_ts_ms(data) > 0 or status_text(data) or "alive" in data or "ok" in data:
        return [("", data)]
    records = []
    for key, value in data.items():
        if isinstance(value, dict):
            records.append((str(key), value))
    return records


def get_field(data: dict[str, Any], path: str) -> Any:
    if not path:
        return data
    current: Any = data
    for part in path.split("."):
        if not isinstance(current, dict):
            return None
        current = current.get(part)
    return current


def extract_field_ts_ms(data: Any, field: str = "", fallback_key: str = "") -> int:
    if isinstance(data, dict) and field:
        ts = normalize_ts_ms(get_field(data, field))
        if ts > 0:
            return ts
    return extract_ts_ms(data, fallback_key)


def requirement_ok(value: Any, expected: Any) -> bool:
    if isinstance(expected, list):
        return value in expected
    return value == expected


def issue(severity: str, code: str, message: str, source: str, details: dict[str, Any] | None = None) -> dict[str, Any]:
    return {
        "severity": severity,
        "code": code,
        "source": source,
        "message": message,
        "details": details or {},
    }


def evaluate_heartbeat(source: dict[str, Any]) -> tuple[dict[str, Any], list[dict[str, Any]]]:
    name = source["name"]
    path = source["path"]
    max_age = int(source.get("max_age_min") or 10)
    required = bool(source.get("required"))
    source_issues: list[dict[str, Any]] = []
    try:
        raw = fb_get(path)
    except Exception as exc:
        severity = "error" if required else "warn"
        source_issues.append(issue(severity, "heartbeat_read_error", f"{name} heartbeat 읽기 실패", name, {"error": compact(exc)}))
        return {"name": name, "path": path, "ok": False, "status": "read_error", "age_min": None}, source_issues

    records = child_records(raw)
    if not records:
        severity = "error" if required else "warn"
        source_issues.append(issue(severity, "heartbeat_missing", f"{name} heartbeat 없음", name))
        return {"name": name, "path": path, "ok": False, "status": "missing", "age_min": None}, source_issues

    selected_key, selected = max(records, key=lambda pair: extract_ts_ms(pair[1], pair[0]))
    ts_ms = extract_ts_ms(selected, selected_key)
    age = age_min(ts_ms)
    fresh = ts_ms > 0 and now_ms() - ts_ms <= max_age * 60000
    alive = fresh if source.get("fresh_only") else fresh and looks_alive(selected)
    ok = alive if required else (fresh or alive)
    stale_ok = bool(source.get("stale_ok"))
    if not fresh and not stale_ok:
        severity = "error" if required else "warn"
        source_issues.append(
            issue(
                severity,
                "heartbeat_stale",
                f"{name} heartbeat stale",
                name,
                {"age_min": age, "max_age_min": max_age, "node": selected_key},
            )
        )
    elif required and not source.get("fresh_only") and not looks_alive(selected):
        source_issues.append(
            issue("error", "heartbeat_not_alive", f"{name} heartbeat는 있으나 alive 상태가 아님", name, {"status": status_text(selected)})
        )

    failed_requirements: dict[str, Any] = {}
    for field, expected in (source.get("require") or {}).items():
        value = get_field(selected, field)
        if not requirement_ok(value, expected):
            failed_requirements[field] = {"actual": value, "expected": expected}
    any_requirements = [item for item in (source.get("require_any") or []) if isinstance(item, dict)]
    if any_requirements:
        failed_alternatives: list[dict[str, Any]] = []
        for requirements in any_requirements:
            failed_alternative: dict[str, Any] = {}
            for field, expected in requirements.items():
                value = get_field(selected, field)
                if not requirement_ok(value, expected):
                    failed_alternative[field] = {"actual": value, "expected": expected}
            if not failed_alternative:
                failed_alternatives = []
                break
            failed_alternatives.append(failed_alternative)
        if failed_alternatives:
            failed_requirements["require_any"] = failed_alternatives
    if failed_requirements:
        source_issues.append(
            issue(
                "error" if required else "warn",
                "heartbeat_requirement_failed",
                f"{name} 필수 상태값 불일치",
                name,
                failed_requirements,
            )
        )
        ok = False

    summary_status = "ok" if not source_issues else "warn" if not required else "error"
    if not fresh and stale_ok:
        summary_status = "inactive"
    summary = {
        "name": name,
        "path": path,
        "node": selected_key or None,
        "ok": not source_issues if required else ok,
        "status": summary_status,
        "age_min": age,
        "ts": ts_ms,
        "text": status_text(selected),
        "version": selected.get("version") or selected.get("version_name") or selected.get("ver"),
        "queue_size": selected.get("queue_size"),
        "local_direct_listening": selected.get("local_direct_listening"),
        "local_direct_sync_timeout_sec": selected.get("local_direct_sync_timeout_sec"),
        "local_direct_deferred_publish": selected.get("local_direct_deferred_publish"),
        "fast_router_stateless_exec": selected.get("fast_router_stateless_exec"),
        "resident_app_server_enabled": selected.get("resident_app_server_enabled"),
        "resident_app_server_active": selected.get("resident_app_server_active"),
        "accessibility_enabled": selected.get("accessibility_enabled"),
        "notification_listener_enabled": selected.get("notification_listener_enabled"),
        "legacy_storebot_accessibility_present": selected.get("legacy_storebot_accessibility_present"),
    }
    return summary, source_issues


def item_status(item: dict[str, Any]) -> str:
    return str(item.get("status") or item.get("local_recovery_status") or item.get("ingress_status") or "pending").strip()


def pid_is_alive(pid: Any) -> bool:
    try:
        value = int(pid)
    except (TypeError, ValueError):
        return False
    if value <= 0:
        return False
    try:
        os.kill(value, 0)
        return True
    except ProcessLookupError:
        return False
    except PermissionError:
        return True
    except OSError:
        return False


def running_request_has_recent_activity(req_id: str, item: dict[str, Any], source: dict[str, Any]) -> bool:
    grace_min = int(source.get("dead_pid_activity_grace_min") or 3)
    if grace_min <= 0:
        return False
    cutoff = now_ms() - grace_min * 60000
    live_status = item.get("live_status") if isinstance(item.get("live_status"), dict) else {}
    live_ts = normalize_ts_ms(live_status.get("updated_at_ms"))
    live_phase = str(live_status.get("phase") or item.get("current_phase") or "")
    if live_ts >= cutoff and live_phase in {"starting_codex_exec", "codex_exec_running"}:
        return True

    heartbeat_path = str(source.get("worker_heartbeat_path") or "")
    if not heartbeat_path and source.get("path") == CODEX_OPS_REQUESTS_PATH:
        heartbeat_path = CODEX_OPS_HEARTBEAT_PATH
    if not heartbeat_path:
        return False
    try:
        heartbeat = fb_get(heartbeat_path)
    except Exception:
        return False
    if not isinstance(heartbeat, dict):
        return False
    heartbeat_ts = extract_ts_ms(heartbeat, "")
    return (
        heartbeat_ts >= cutoff
        and str(heartbeat.get("current_request") or "") == req_id
        and str(heartbeat.get("current_phase") or "") in {"starting_codex_exec", "codex_exec_running"}
        and status_text(heartbeat) in {"processing", "active", "alive", "ok"}
    )


def queue_item_ts_ms(data: dict[str, Any], key: str, running: bool) -> int:
    fields = (
        ("started_at_ms", "updated_at_ms", "current_started_at_ms", "created_at_ms")
        if running
        else ("created_at_ms", "updated_at_ms", "ts", "ts_ms", "timestamp")
    )
    for field in fields:
        ts = normalize_ts_ms(data.get(field))
        if ts > 0:
            return ts
    return extract_ts_ms(data, key)


def is_unsent_message(item: dict[str, Any]) -> bool:
    return item.get("sent") is not True and bool(item.get("message") or item.get("text") or item.get("reply"))


def queue_items(path: str, limit: int) -> dict[str, Any]:
    query = {"orderBy": json.dumps("$key"), "limitToLast": int(limit)}
    data = fb_get(path, query=query)
    return data if isinstance(data, dict) else {}


def queue_item_matches_target(item: dict[str, Any], source: dict[str, Any]) -> bool:
    target_host = str(source.get("target_host") or "").strip().lower()
    item_host = str(item.get("target_host") or "").strip().lower()
    if target_host == "pc":
        if item_host not in {"pc", "any"}:
            return False
    elif target_host == "subphone":
        if item_host not in {"", "subphone", "any"}:
            return False
    elif target_host == "any":
        pass
    elif target_host:
        return False

    target_node = str(source.get("target_node") or "").strip()
    item_node = str(item.get("target_node") or "").strip()
    if target_node and item_node and item_node != target_node:
        return False
    return True


def evaluate_queue(source: dict[str, Any]) -> tuple[dict[str, Any], list[dict[str, Any]]]:
    name = source["name"]
    path = source["path"]
    max_pending = int(source.get("max_pending_age_min") or 30)
    max_running = int(source.get("max_running_age_min") or max_pending)
    limit = int(source.get("limit") or 100)
    source_issues: list[dict[str, Any]] = []
    try:
        data = queue_items(path, limit)
    except Exception as exc:
        source_issues.append(issue("warn", "queue_read_error", f"{name} queue 읽기 실패", name, {"error": compact(exc)}))
        return {"name": name, "path": path, "ok": False, "status": "read_error"}, source_issues

    pending_statuses = set(str(v) for v in source.get("statuses") or ["pending"])
    running_statuses = set(str(v) for v in source.get("running_statuses") or ["running"])
    pending_count = 0
    running_count = 0
    oldest_pending = 0
    oldest_running = 0
    finished_without_terminal_count = 0
    sample_keys: list[str] = []

    for key, value in data.items():
        if not isinstance(value, dict):
            continue
        if not queue_item_matches_target(value, source):
            continue
        pending = is_unsent_message(value) if source.get("unsent_message_queue") else item_status(value) in pending_statuses
        running = item_status(value) in running_statuses
        if pending:
            ts_ms = queue_item_ts_ms(value, str(key), running=False)
            pending_count += 1
            sample_keys.append(str(key))
            if ts_ms > 0 and (oldest_pending == 0 or ts_ms < oldest_pending):
                oldest_pending = ts_ms
        if running:
            ts_ms = queue_item_ts_ms(value, str(key), running=True)
            running_count += 1
            sample_keys.append(str(key))
            if ts_ms > 0 and (oldest_running == 0 or ts_ms < oldest_running):
                oldest_running = ts_ms
            live_status = value.get("live_status") if isinstance(value.get("live_status"), dict) else {}
            live_phase = str(live_status.get("phase") or value.get("current_phase") or "")
            live_ts = normalize_ts_ms(live_status.get("updated_at_ms")) or ts_ms
            finished_age = age_min(live_ts)
            if (
                source.get("detect_finished_without_terminal")
                and live_phase == "finished"
                and value.get("result") in (None, {})
                and finished_age is not None
                and finished_age > int(source.get("finished_terminal_grace_min") or 2)
            ):
                finished_without_terminal_count += 1
                source_issues.append(
                    issue(
                        "error",
                        "queue_finished_without_terminal",
                        f"{name} subprocess 종료 후 terminal result 미기록",
                        name,
                        {
                            "request_status": item_status(value),
                            "live_phase": "finished",
                            "finished_age_min": finished_age,
                        },
                    )
                )
            claim_pid = int(value.get("claim_pid") or 0)
            if (
                source.get("check_local_claim_pid")
                and claim_pid > 0
                and not pid_is_alive(claim_pid)
                and not running_request_has_recent_activity(str(key), value, source)
            ):
                source_issues.append(
                    issue(
                        "error",
                        "queue_running_dead_pid",
                        f"{name} running 요청의 worker PID가 없음",
                        name,
                        {
                            "request_id": str(key),
                            "claim_pid": claim_pid,
                            "project": value.get("project"),
                            "started_age_min": age_min(ts_ms),
                        },
                    )
                )

    pending_age = age_min(oldest_pending)
    running_age = age_min(oldest_running)
    if pending_count and pending_age is not None and pending_age > max_pending:
        source_issues.append(
            issue(
                "error",
                "queue_pending_stale",
                f"{name} pending queue 정체",
                name,
                {"pending_count": pending_count, "oldest_age_min": pending_age, "max_age_min": max_pending, "sample_keys": sample_keys[:5]},
            )
        )
    if running_count and running_age is not None and running_age > max_running:
        source_issues.append(
            issue(
                "error",
                "queue_running_stale",
                f"{name} running queue 장시간 지속",
                name,
                {"running_count": running_count, "oldest_age_min": running_age, "max_age_min": max_running, "sample_keys": sample_keys[:5]},
            )
        )

    summary = {
        "name": name,
        "path": path,
        "ok": not source_issues,
        "status": "ok" if not source_issues else "error",
        "pending_count": pending_count,
        "running_count": running_count,
        "oldest_pending_age_min": pending_age,
        "oldest_running_age_min": running_age,
        "finished_without_terminal_count": finished_without_terminal_count,
        "sampled_limit": limit,
    }
    return summary, source_issues


def latest_event_records(path: str, limit: int) -> dict[str, Any]:
    if limit <= 1:
        data = fb_get(path)
        return {"latest": data} if data is not None else {}
    query = {"orderBy": json.dumps("$key"), "limitToLast": int(limit)}
    data = fb_get(path, query=query)
    return data if isinstance(data, dict) else {}


def event_text(value: Any) -> str:
    if isinstance(value, dict):
        return " ".join(str(value.get(k) or "") for k in ("event", "status", "type", "message", "error", "last_error", "reason")).lower()
    return str(value).lower()


def event_is_bad(
    value: Any,
    bad_events: list[str] | None,
    ignore_resolved: bool = False,
    ignore_events: list[str] | None = None,
) -> bool:
    if ignore_resolved and isinstance(value, dict) and value.get("resolved") is True:
        return False
    text = event_text(value)
    if ignore_events and any(ignore.lower() in text for ignore in ignore_events):
        return False
    if not bad_events:
        return True
    return any(bad.lower() in text for bad in bad_events)


def evaluate_events(source: dict[str, Any]) -> tuple[dict[str, Any], list[dict[str, Any]]]:
    name = source["name"]
    path = source["path"]
    limit = int(source.get("limit") or 20)
    lookback = int(source.get("lookback_min") or 60)
    severity = str(source.get("severity") or "warn")
    min_recent_count = int(source.get("min_recent_count") or 1)
    error_recent_count = int(source.get("error_recent_count") or 0)
    ignore_resolved = bool(source.get("ignore_resolved"))
    bad_events = source.get("bad_events")
    ignore_events = source.get("ignore_events")
    source_issues: list[dict[str, Any]] = []
    try:
        data = latest_event_records(path, limit)
    except Exception as exc:
        source_issues.append(issue("warn", "event_read_error", f"{name} 이벤트 읽기 실패", name, {"error": compact(exc)}))
        return {"name": name, "path": path, "ok": False, "status": "read_error"}, source_issues

    recent_count = 0
    latest_ts = 0
    latest_key = ""
    for key, value in data.items():
        if not event_is_bad(value, bad_events, ignore_resolved, ignore_events):
            continue
        ts_ms = extract_ts_ms(value, str(key))
        if ts_ms > latest_ts:
            latest_ts = ts_ms
            latest_key = str(key)
        if ts_ms > 0 and now_ms() - ts_ms <= lookback * 60000:
            recent_count += 1

    latest_age = age_min(latest_ts)
    if recent_count >= min_recent_count:
        issue_severity = "error" if error_recent_count > 0 and recent_count >= error_recent_count else severity
        source_issues.append(
            issue(
                issue_severity,
                "recent_error_event",
                f"{name} 최근 오류 이벤트 감지",
                name,
                {
                    "recent_count": recent_count,
                    "lookback_min": lookback,
                    "min_recent_count": min_recent_count,
                    "error_recent_count": error_recent_count or None,
                    "latest_key": latest_key,
                    "latest_age_min": latest_age,
                },
            )
        )

    summary = {
        "name": name,
        "path": path,
        "ok": recent_count < min_recent_count,
        "status": "ok" if recent_count < min_recent_count else ("error" if error_recent_count > 0 and recent_count >= error_recent_count else severity),
        "recent_count": recent_count,
        "min_recent_count": min_recent_count,
        "error_recent_count": error_recent_count or None,
        "latest_key": latest_key or None,
        "latest_age_min": latest_age,
    }
    return summary, source_issues


def first_configured_field(data: dict[str, Any], fields: list[Any]) -> Any:
    for field in fields:
        value = get_field(data, str(field))
        if value not in (None, ""):
            return value
    return None


def configured_ts_ms(data: dict[str, Any], fields: list[Any]) -> int:
    for field in fields:
        ts = extract_field_ts_ms(data, str(field))
        if ts > 0:
            return ts
    return extract_ts_ms(data)


def evaluate_local_json_check(source: dict[str, Any]) -> tuple[dict[str, Any], list[dict[str, Any]]]:
    name = source["name"]
    path = os.path.expanduser(str(source["path"]))
    source_issues: list[dict[str, Any]] = []
    if not os.path.exists(path):
        if not source.get("missing_ok"):
            source_issues.append(issue(str(source.get("missing_severity") or "warn"), "local_json_missing", f"{name} 로컬 상태 파일 없음", name, {"path": path}))
        return {"name": name, "path": path, "ok": not source_issues, "status": "missing", "age_min": None}, source_issues
    if not os.path.isfile(path):
        source_issues.append(issue("warn", "local_json_not_file", f"{name} 로컬 상태 경로가 파일이 아님", name, {"path": path}))
        return {"name": name, "path": path, "ok": False, "status": "not_file", "age_min": None}, source_issues
    try:
        with open(path, "r", encoding="utf-8") as fh:
            data = json.load(fh)
    except Exception as exc:
        source_issues.append(issue("warn", "local_json_read_error", f"{name} 로컬 상태 읽기 실패", name, {"path": path, "error": compact(exc)}))
        return {"name": name, "path": path, "ok": False, "status": "read_error", "age_min": None}, source_issues
    if not isinstance(data, dict):
        source_issues.append(issue("warn", "local_json_unexpected_value", f"{name} 로컬 상태 값 형식 비정상", name, {"path": path}))
        return {"name": name, "path": path, "ok": False, "status": "unexpected", "age_min": None}, source_issues

    ts_ms = configured_ts_ms(data, list(source.get("ts_fields") or []))
    age = age_min(ts_ms)
    status = str(first_configured_field(data, list(source.get("status_fields") or [])) or status_text(data) or "").strip()
    failure_status = str(first_configured_field(data, list(source.get("failure_fields") or [])) or "").strip()
    status_l = status.lower()
    failure_l = failure_status.lower()
    bad_statuses = {str(value).lower() for value in source.get("bad_statuses") or []}
    pending_statuses = {str(value).lower() for value in source.get("pending_statuses") or []}

    bad_state = bool((status_l and status_l in bad_statuses) or (failure_l and failure_l in bad_statuses))
    if not bad_state and source.get("bad_texts"):
        text = event_text(data)
        bad_state = any(str(value).lower() in text for value in source.get("bad_texts") or [])
    if bad_state:
        source_issues.append(
            issue(
                str(source.get("bad_severity") or "error"),
                "local_json_bad_state",
                f"{name} 로컬 상태 오류",
                name,
                {"path": path, "status": status, "failure_status": failure_status, "age_min": age},
            )
        )

    max_pending = int(source.get("max_pending_age_min") or 0)
    if max_pending > 0 and status_l in pending_statuses and (ts_ms <= 0 or (age is not None and age > max_pending)):
        source_issues.append(
            issue(
                str(source.get("pending_stale_severity") or "error"),
                "local_json_pending_stale",
                f"{name} 로컬 대기 상태 장시간 지속",
                name,
                {"path": path, "status": status, "age_min": age, "max_age_min": max_pending},
            )
        )

    max_age = int(source.get("max_age_min") or 0)
    if max_age > 0 and (ts_ms <= 0 or (age is not None and age > max_age)):
        source_issues.append(
            issue(
                str(source.get("stale_severity") or "warn"),
                "local_json_stale",
                f"{name} 로컬 상태 stale",
                name,
                {"path": path, "status": status, "age_min": age, "max_age_min": max_age},
            )
        )

    return {
        "name": name,
        "path": path,
        "ok": not source_issues,
        "status": status or failure_status or "ok",
        "failure_status": failure_status or None,
        "age_min": age,
        "ts": ts_ms,
    }, source_issues


def evaluate_single_request(source: dict[str, Any]) -> tuple[dict[str, Any], list[dict[str, Any]]]:
    name = source["name"]
    path = source["path"]
    max_age = int(source.get("max_age_min") or 10)
    source_issues: list[dict[str, Any]] = []
    try:
        data = fb_get(path)
    except Exception as exc:
        source_issues.append(issue("warn", "request_read_error", f"{name} 요청 경로 읽기 실패", name, {"error": compact(exc)}))
        return {"name": name, "path": path, "ok": False, "status": "read_error"}, source_issues

    if data is None:
        return {"name": name, "path": path, "ok": True, "status": "empty", "age_min": None}, source_issues
    if not isinstance(data, dict):
        source_issues.append(issue("warn", "request_unexpected_value", f"{name} 요청 경로 값 형식 비정상", name))
        return {"name": name, "path": path, "ok": False, "status": "unexpected"}, source_issues

    ts_ms = extract_field_ts_ms(data, str(source.get("ts_field") or ""))
    age = age_min(ts_ms)
    if ts_ms <= 0:
        source_issues.append(issue("warn", "request_timestamp_missing", f"{name} 요청 timestamp 없음", name))
    elif age is not None and age > max_age:
        source_issues.append(
            issue(
                str(source.get("stale_severity") or "error"),
                "request_stale",
                f"{name} 요청이 처리되지 않고 남아 있음",
                name,
                {"age_min": age, "max_age_min": max_age, "source": data.get("source"), "mode": data.get("mode")},
            )
        )

    return {
        "name": name,
        "path": path,
        "ok": not source_issues,
        "status": "active" if not source_issues else max_severity(source_issues),
        "age_min": age,
        "ts": ts_ms,
        "source": data.get("source"),
        "mode": data.get("mode"),
    }, source_issues


def evaluate_status_check(source: dict[str, Any]) -> tuple[dict[str, Any], list[dict[str, Any]]]:
    name = source["name"]
    path = source["path"]
    field = str(source.get("field") or "state")
    required = bool(source.get("required"))
    max_pending = int(source.get("max_pending_age_min") or 10)
    source_issues: list[dict[str, Any]] = []
    try:
        data = fb_get(path)
    except Exception as exc:
        severity = "error" if required else "warn"
        source_issues.append(issue(severity, "status_read_error", f"{name} 상태 읽기 실패", name, {"error": compact(exc)}))
        return {"name": name, "path": path, "ok": False, "status": "read_error"}, source_issues

    if not isinstance(data, dict):
        if not source.get("missing_ok"):
            severity = "error" if required else "warn"
            source_issues.append(issue(severity, "status_missing", f"{name} 상태 없음", name))
        return {"name": name, "path": path, "ok": not source_issues, "status": "missing"}, source_issues

    raw_state = get_field(data, field)
    state = str(raw_state or "").strip()
    state_l = state.lower()
    ok_states = {str(v).lower() for v in source.get("ok_states") or ["ok", "idle"]}
    pending_states = {str(v).lower() for v in source.get("pending_states") or ["pending", "running", "processing"]}
    bad_states = {str(v).lower() for v in source.get("bad_states") or ["error", "failed"]}
    ts_ms = extract_field_ts_ms(data, str(source.get("ts_field") or ""))
    age = age_min(ts_ms)

    if not state:
        severity = "error" if required else "warn"
        source_issues.append(issue(severity, "status_state_missing", f"{name} 상태값 없음", name, {"field": field}))
    elif state_l in bad_states:
        source_issues.append(
            issue(
                str(source.get("bad_severity") or "error"),
                "status_bad_state",
                f"{name} 오류 상태",
                name,
                {"state": state, "age_min": age},
            )
        )
    elif state_l in pending_states:
        if ts_ms <= 0 or (age is not None and age > max_pending):
            source_issues.append(
                issue(
                    str(source.get("pending_stale_severity") or "error"),
                    "status_pending_stale",
                    f"{name} 대기 상태 장시간 지속",
                    name,
                    {"state": state, "age_min": age, "max_age_min": max_pending},
                )
            )
    elif state_l not in ok_states:
        source_issues.append(issue(str(source.get("unknown_severity") or "warn"), "status_unknown_state", f"{name} 알 수 없는 상태", name, {"state": state}))

    return {
        "name": name,
        "path": path,
        "field": field,
        "ok": not source_issues,
        "status": state or "missing",
        "age_min": age,
        "ts": ts_ms,
    }, source_issues


def evaluate_metric_check(source: dict[str, Any]) -> tuple[dict[str, Any], list[dict[str, Any]]]:
    name = source["name"]
    path = source["path"]
    max_age = int(source.get("max_age_min") or 60)
    min_orders = int(source.get("min_orders") or 1)
    min_error_orders = int(source.get("min_error_orders") or min_orders)
    warn_match = float(source.get("warn_match_error_pct") or 0)
    error_match = float(source.get("error_match_error_pct") or 0)
    warn_delta = float(source.get("warn_delta_pct") or 0)
    error_delta = float(source.get("error_delta_pct") or 0)
    source_issues: list[dict[str, Any]] = []
    try:
        data = fb_get(path)
    except Exception as exc:
        source_issues.append(issue("warn", "metric_read_error", f"{name} metric 읽기 실패", name, {"error": compact(exc)}))
        return {"name": name, "path": path, "ok": False, "status": "read_error"}, source_issues

    if not isinstance(data, dict):
        source_issues.append(issue("warn", "metric_missing", f"{name} metric 없음", name))
        return {"name": name, "path": path, "ok": False, "status": "missing"}, source_issues

    ts_ms = extract_ts_ms(data)
    age = age_min(ts_ms)
    if ts_ms <= 0 or (age is not None and age > max_age):
        source_issues.append(
            issue(
                str(source.get("stale_severity") or "warn"),
                "metric_stale",
                f"{name} metric stale",
                name,
                {"age_min": age, "max_age_min": max_age},
            )
        )

    if "expected_apply_to_live" in source and data.get("apply_to_live") is not source["expected_apply_to_live"]:
        source_issues.append(
            issue(
                "error",
                "metric_live_flag_mismatch",
                f"{name} live 적용 플래그 불일치",
                name,
                {"apply_to_live": data.get("apply_to_live"), "expected": source["expected_apply_to_live"]},
            )
        )
    elif source.get("require_apply_to_live_false") and data.get("apply_to_live") is not False:
        source_issues.append(
            issue(
                "error",
                "metric_live_flag_unsafe",
                f"{name} shadow 안전 플래그 불일치",
                name,
                {"apply_to_live": data.get("apply_to_live")},
            )
        )

    raw_count = int(number_value(data, "raw_count", 0))
    orders_count = int(number_value(data, "orders_count", 0))
    matched_count = int(number_value(data, "matched_count", 0))
    missing_count = int(number_value(data, "missing_count", 0))
    zero_amount_count = int(number_value(data, "zero_amount_count", 0))
    unresolved_count = int(number_value(data, "unresolved_count", missing_count + zero_amount_count))
    skipped_count = int(number_value(data, "skipped_count", 0))
    skipped_negative_count = int(number_value(data, "skipped_negative_count", 0))
    skipped_hall_count = int(number_value(data, "skipped_hall_count", 0))
    skipped_small_amount_count = int(number_value(data, "skipped_small_amount_count", 0))
    weighted_count = int(number_value(data, "weighted_count_with_fallback", raw_count))
    match_error = number_value(data, "match_error_rate_pct", 0)
    delta = number_value(data, "delta_vs_raw_pct", 0)

    if data.get("orders_available") is False and raw_count > 0:
        source_issues.append(
            issue(
                "warn",
                "metric_orders_unavailable",
                f"{name} raw count는 있으나 KDS orders 없음",
                name,
                {"raw_count": raw_count},
            )
        )
    if orders_count >= min_orders:
        if error_match > 0 and match_error >= error_match and orders_count >= min_error_orders:
            source_issues.append(
                issue(
                    "error",
                    "metric_match_error_high",
                    f"{name} 금액 매칭 오차율 높음",
                    name,
                    {"match_error_rate_pct": match_error, "threshold_pct": error_match, "orders_count": orders_count},
                )
            )
        elif warn_match > 0 and match_error >= warn_match:
            source_issues.append(
                issue(
                    "warn",
                    "metric_match_error_warn",
                    f"{name} 금액 매칭 오차율 주의",
                    name,
                    {"match_error_rate_pct": match_error, "threshold_pct": warn_match, "orders_count": orders_count},
                )
            )
        if unresolved_count > 0:
            source_issues.append(
                issue(
                    "warn",
                    "metric_unresolved_orders",
                    f"{name} 금액 매칭 미해결 주문 있음",
                    name,
                    {
                        "missing_count": missing_count,
                        "zero_amount_count": zero_amount_count,
                        "unresolved_count": unresolved_count,
                    },
                )
            )
        if error_delta > 0 and delta >= error_delta:
            source_issues.append(
                issue(
                    "warn",
                    "metric_delta_large",
                    f"{name} raw 대비 금액환산 차이 큼",
                    name,
                    {"delta_vs_raw_pct": delta, "threshold_pct": error_delta, "raw_count": raw_count, "weighted_count": weighted_count},
                )
            )
        elif warn_delta > 0 and delta >= warn_delta:
            source_issues.append(
                issue(
                    "info",
                    "metric_delta_candidate",
                    f"{name} 금액환산 개선 후보",
                    name,
                    {"delta_vs_raw_pct": delta, "threshold_pct": warn_delta, "raw_count": raw_count, "weighted_count": weighted_count},
                )
            )

    return {
        "name": name,
        "path": path,
        "ok": not [item for item in source_issues if SEVERITY_SCORE.get(str(item.get("severity")), 0) >= 1],
        "status": max_severity(source_issues),
        "age_min": age,
        "ts": ts_ms,
        "raw_count": raw_count,
        "weighted_count_with_fallback": weighted_count,
        "orders_count": orders_count,
        "matched_count": matched_count,
        "unresolved_count": unresolved_count,
        "skipped_count": skipped_count,
        "skipped_negative_count": skipped_negative_count,
        "skipped_hall_count": skipped_hall_count,
        "skipped_small_amount_count": skipped_small_amount_count,
        "match_error_rate_pct": match_error,
        "delta_vs_raw_pct": delta,
        "apply_to_live": data.get("apply_to_live"),
    }, source_issues


def evaluate_posdelay_pc_recovery_context() -> tuple[dict[str, Any], list[dict[str, Any]]]:
    name = "posdelay_pc_macro_recovery_context"
    source_issues: list[dict[str, Any]] = []
    main_pc_status: Any = None
    pending_cmd: Any = None
    watchdog_last: Any = None
    read_errors: dict[str, str] = {}
    try:
        main_pc_status = fb_get("/monitor/main_pc/status")
    except Exception as exc:
        read_errors["main_pc_status"] = compact(exc)
    try:
        pending_cmd = fb_get("/monitor/main_pc/cmd")
    except Exception as exc:
        read_errors["main_pc_cmd"] = compact(exc)
    try:
        watchdog_last = fb_get("/monitor/main_pc/watchdog_last")
    except Exception as exc:
        read_errors["watchdog_last"] = compact(exc)

    if read_errors:
        source_issues.append(
            issue(
                "warn",
                "pc_dependency_read_error",
                "PosDelay PC 복구 의존성 일부 읽기 실패",
                name,
                read_errors,
            )
        )

    main_ts = extract_ts_ms(main_pc_status) if isinstance(main_pc_status, dict) else 0
    main_age = age_min(main_ts)
    main_fresh = main_ts > 0 and now_ms() - main_ts <= 10 * 60000
    main_services = main_pc_status.get("services") if isinstance(main_pc_status, dict) else {}
    watchdog_ts = extract_ts_ms(watchdog_last) if isinstance(watchdog_last, dict) else 0
    watchdog_age = age_min(watchdog_ts)
    recovery_path = (
        "/monitor/main_pc/cmd=restart_posdelay_pc"
        if main_fresh
        else "external_pc_or_network_watchdog"
    )

    if not main_fresh:
        source_issues.append(
            issue(
                "warn",
                "pc_dependency_stale",
                "PosDelay PC 매크로 복구 경계: main_pc heartbeat stale",
                name,
                {
                    "main_pc_age_min": main_age,
                    "max_age_min": 10,
                    "pending_cmd": pending_cmd if isinstance(pending_cmd, str) else None,
                    "recovery_path": recovery_path,
                },
            )
        )
        if isinstance(pending_cmd, str) and pending_cmd:
            source_issues.append(
                issue(
                    "warn",
                    "pc_recovery_command_unconsumed",
                    "MainPC 원격 명령이 소비되지 않고 남아 있음",
                    name,
                    {"pending_cmd": pending_cmd},
                )
            )

    return {
        "name": name,
        "ok": not source_issues,
        "status": "main_pc_alive" if main_fresh else "main_pc_stale",
        "main_pc_age_min": main_age,
        "main_pc_ts": main_ts,
        "main_pc_services": main_services if isinstance(main_services, dict) else {},
        "pending_cmd": pending_cmd if isinstance(pending_cmd, str) else None,
        "watchdog_age_min": watchdog_age,
        "watchdog_status": status_text(watchdog_last) if isinstance(watchdog_last, dict) else "",
        "recovery_path": recovery_path,
    }, source_issues


def storebot_broadcast_interval_ms(state: dict[str, Any]) -> int:
    try:
        value = int(state.get("interval_ms") or 0)
    except (TypeError, ValueError):
        value = 0
    return value if value > 0 else STOREBOT_WORK_SCHEDULE_BROADCAST_INTERVAL_MS


def storebot_broadcast_latest_ts_ms(value: Any) -> int:
    if not isinstance(value, dict):
        return 0
    return max(
        (
            normalize_ts_ms(value.get(field))
            for field in (
                "updated_at_ms",
                "finished_at_ms",
                "started_at_ms",
                "created_at_ms",
                "queued_at_ms",
                "sent_at_ms",
                "ts_ms",
                "ts",
            )
        ),
        default=0,
    )


def storebot_broadcast_image_delivery_succeeded(outbound: Any) -> bool:
    if not isinstance(outbound, dict) or outbound.get("sent") is not True:
        return False
    for key in (
        "image_sent",
        "image_send_succeeded",
        "image_delivery_ok",
        "attachment_sent",
        "attachment_send_succeeded",
    ):
        if outbound.get(key) is True:
            return True
    status_values = [
        outbound.get("image_send_status"),
        outbound.get("image_delivery_status"),
        outbound.get("attachment_status"),
        outbound.get("attachment_uri_status"),
    ]
    image_result = outbound.get("image_result")
    if isinstance(image_result, dict):
        status_values.extend(
            (
                image_result.get("status"),
                image_result.get("send_status"),
                image_result.get("attachment_status"),
            )
        )
    return any(
        str(value or "").strip().casefold().replace("_", "-")
        in {"sent", "success", "succeeded", "delivered", "attached", "image-sent"}
        for value in status_values
    )


def storebot_ca_flag(name: str) -> bool:
    return str(os.environ.get(name) or "").strip().lower() in {"1", "true", "yes", "on"}


def storebot_broadcast_ca_projection_input(
    *,
    source_issues: list[dict[str, Any]],
    record: dict[str, Any],
    now_value_ms: int,
) -> dict[str, Any] | None:
    mappings = {
        "storebot_broadcast_state_missing": ("schedule_fire", "missing", "missing_stage"),
        "storebot_broadcast_hash_unsent": ("schedule_fire", "missing", "missing_stage"),
        "storebot_broadcast_periodic_overdue": ("schedule_fire", "missing", "missing_stage"),
        "storebot_broadcast_changed_without_due": ("schedule_fire", "missing", "missing_stage"),
        "storebot_broadcast_request_missing": ("worker_pickup", "missing", "missing_stage"),
        "storebot_broadcast_request_stale": ("worker_pickup", "timeout", "worker_timeout"),
        "storebot_broadcast_request_unknown_stale": ("worker_pickup", "timeout", "worker_timeout"),
        "storebot_broadcast_request_terminal_failure": ("worker_pickup", "error", "worker_error"),
        "storebot_broadcast_done_without_outbound": ("outbound_publish", "missing", "missing_stage"),
        "storebot_broadcast_outbound_missing": ("outbound_publish", "missing", "missing_stage"),
        "storebot_broadcast_outbound_stale": ("phone_receive", "timeout", "phone_timeout"),
        "storebot_broadcast_outbound_terminal_failure": ("phone_receive", "error", "phone_timeout"),
        "storebot_broadcast_image_ack_missing": ("ack", "missing", "kakao_ack_timeout"),
        "storebot_broadcast_recovery_overdue": ("outbound_publish", "timeout", "worker_timeout"),
    }
    selected: dict[str, Any] | None = None
    for severity in ("critical", "error", "warn"):
        selected = next(
            (
                item
                for item in source_issues
                if str(item.get("severity") or "") == severity and str(item.get("code") or "") in mappings
            ),
            None,
        )
        if selected:
            break
    if not selected:
        return None
    stage, stage_result, failure_code = mappings[str(selected["code"])]
    age_candidates = (
        record.get("request_age_min"),
        record.get("outbound_age_min"),
        record.get("next_due_age_min"),
    )
    age_minutes = max(
        (float(value) for value in age_candidates if isinstance(value, (int, float)) and value > 0),
        default=0.0,
    )
    private_ref = str(record.get("inflight_request_id") or record.get("inflight_outbound_key") or "").strip()
    if not private_ref:
        hash_ref = str(record.get("current_schedule_hash") or "state")[:32]
        private_ref = f"work_schedule_broadcast:{hash_ref}"
    severity = "critical" if selected.get("severity") == "critical" else "error"
    return {
        "private_task_ref": private_ref[:240],
        "transition": "schedule_timeout",
        "status": "failed",
        "resource_id": "subphone_termux_ops",
        "occurred_at_ms": int(now_value_ms),
        "duration_ms": min(24 * 60 * 60 * 1000, max(0, int(age_minutes * 60000))),
        "severity": severity,
        "failure_code": failure_code,
        "action_count": 0,
        "action_ok_count": 0,
        "action_error_count": 0,
        "stage": stage,
        "stage_result": stage_result,
        "content_variant": "image",
        "recovery_state": "none",
    }


def evaluate_storebot_briefing_freshness() -> tuple[dict[str, Any], list[dict[str, Any]]]:
    """Read the current unsent/changed work-schedule broadcast contract.

    Fixed 07:00/21:00 schedule markers were intentionally retired.  The only
    liveness contract here is the broadcast state plus its referenced request
    and outbound image acknowledgement.
    """

    name = "storebot_briefing_freshness"
    source_issues: list[dict[str, Any]] = []
    now = now_ms()
    ca_kill_switch = storebot_ca_flag("STOREBOT_CA_KILL_SWITCH")
    ca_projection_enabled = storebot_ca_flag("STOREBOT_CA_PROJECTION_ENABLED") and not ca_kill_switch
    ca_live_send_enabled = (
        ca_projection_enabled
        and storebot_ca_flag("STOREBOT_CA_LIVE_SEND_ENABLED")
        and not ca_kill_switch
    )
    ca_schedule_recovery_enabled = (
        ca_projection_enabled
        and storebot_ca_flag("STOREBOT_CA_SCHEDULE_RECOVERY_ENABLED")
        and not ca_kill_switch
    )
    ca_recovery_transitions = [
        "schedule_timeout",
        "schedule_recovery_started",
        "schedule_recovery_result",
    ]
    if not ca_projection_enabled:
        source_issues.append(
            issue(
                "warn",
                "storebot_broadcast_ca_projection_disabled",
                "StoreBot 근무표 이상 CA방 projection 비활성",
                name,
                {"kill_switch": ca_kill_switch},
            )
        )
    elif not ca_live_send_enabled:
        source_issues.append(
            issue(
                "warn",
                "storebot_broadcast_ca_live_send_disabled",
                "StoreBot 근무표 이상 CA방 live delivery 비활성",
                name,
                {"projection_enabled": True},
            )
        )
    if not ca_schedule_recovery_enabled:
        source_issues.append(
            issue(
                "warn",
                "storebot_broadcast_ca_recovery_disabled",
                "StoreBot 근무표 timeout 즉시복구 비활성",
                name,
                {"projection_enabled": ca_projection_enabled, "kill_switch": ca_kill_switch},
            )
        )
    try:
        state = fb_get(STOREBOT_WORK_SCHEDULE_BROADCAST_STATE_PATH)
    except Exception as exc:
        error = compact(exc)
        source_issues.append(
            issue(
                "error",
                "storebot_broadcast_state_read_error",
                "StoreBot 근무표 자동발송 state 읽기 실패",
                name,
                {"path": STOREBOT_WORK_SCHEDULE_BROADCAST_STATE_PATH, "error": error},
            )
        )
        return {
            "name": name,
            "contract": "work_schedule_broadcast_v2",
            "path": STOREBOT_WORK_SCHEDULE_BROADCAST_STATE_PATH,
            "ok": False,
            "status": "error",
            "broadcast_status": "read_error",
            "recovery_paused": not ca_schedule_recovery_enabled,
            "recovery_pause_reason": "ca_schedule_recovery_disabled" if not ca_schedule_recovery_enabled else "",
            "recovery_pause_reason_code": "ca_schedule_recovery_disabled" if not ca_schedule_recovery_enabled else "none",
            "ca_projection_enabled": ca_projection_enabled,
            "ca_live_send_enabled": ca_live_send_enabled,
            "ca_schedule_recovery_enabled": ca_schedule_recovery_enabled,
            "ca_projection_status": "blocked_state_read_error",
            "ca_projection_input": None,
            "ca_recovery_status": "blocked_state_read_error",
            "ca_recovery_transitions": ca_recovery_transitions,
            "records": [],
        }, source_issues

    if not isinstance(state, dict) or not state:
        source_issues.append(
            issue(
                "error",
                "storebot_broadcast_state_missing",
                "StoreBot 근무표 자동발송 state 없음",
                name,
                {"path": STOREBOT_WORK_SCHEDULE_BROADCAST_STATE_PATH},
            )
        )
        missing_record = {
            "current_schedule_hash": "",
            "inflight_request_id": "",
            "inflight_outbound_key": "",
            "next_due_age_min": None,
        }
        ca_projection_input = storebot_broadcast_ca_projection_input(
            source_issues=source_issues,
            record=missing_record,
            now_value_ms=now,
        )
        ca_projection_status = "ready" if ca_projection_enabled and ca_live_send_enabled else (
            "ready_no_live_delivery" if ca_projection_enabled else "blocked_projection_disabled"
        )
        ca_recovery_status = "ready" if ca_schedule_recovery_enabled else "paused_recovery_disabled"
        return {
            "name": name,
            "contract": "work_schedule_broadcast_v2",
            "path": STOREBOT_WORK_SCHEDULE_BROADCAST_STATE_PATH,
            "ok": False,
            "status": "error",
            "broadcast_status": "state_missing",
            "recovery_paused": not ca_schedule_recovery_enabled,
            "recovery_pause_reason": "ca_schedule_recovery_disabled" if not ca_schedule_recovery_enabled else "",
            "recovery_pause_reason_code": "ca_schedule_recovery_disabled" if not ca_schedule_recovery_enabled else "none",
            "ca_projection_enabled": ca_projection_enabled,
            "ca_live_send_enabled": ca_live_send_enabled,
            "ca_schedule_recovery_enabled": ca_schedule_recovery_enabled,
            "ca_projection_status": ca_projection_status,
            "ca_projection_input": ca_projection_input,
            "ca_recovery_status": ca_recovery_status,
            "ca_recovery_transitions": ca_recovery_transitions,
            "records": [missing_record],
        }, source_issues

    state_status = str(state.get("status") or "").strip().lower()
    current_hash = str(state.get("current_schedule_hash") or state.get("last_schedule_hash") or "").strip()
    last_sent_hash = str(state.get("last_sent_schedule_hash") or "").strip()
    hash_pending = bool(current_hash and current_hash != last_sent_hash)
    interval_ms = storebot_broadcast_interval_ms(state)
    last_sent_at_ms = normalize_ts_ms(state.get("last_sent_at_ms") or 0)
    last_sent_age_min = round((now - last_sent_at_ms) / 60000, 1) if last_sent_at_ms > 0 else None
    next_due_at_ms = normalize_ts_ms(state.get("next_due_at_ms") or 0)
    if next_due_at_ms <= 0 and last_sent_at_ms > 0:
        next_due_at_ms = last_sent_at_ms + interval_ms
    next_due_age_min = round((now - next_due_at_ms) / 60000, 1) if next_due_at_ms > 0 else None
    due_after_grace = bool(
        next_due_at_ms > 0
        and now >= next_due_at_ms + STOREBOT_BRIEFING_MISSING_GRACE_MIN * 60000
    )
    due_after_stale = bool(
        next_due_at_ms > 0
        and now >= next_due_at_ms + STOREBOT_BRIEFING_STALE_MIN * 60000
    )
    state_ts_ms = storebot_broadcast_latest_ts_ms(state)
    state_age_min = round((now - state_ts_ms) / 60000, 1) if state_ts_ms > 0 else None
    request_id = str(state.get("inflight_request_id") or "").strip()
    outbound_key = str(state.get("inflight_outbound_key") or "").strip()
    recovery_pause_reasons: list[str] = []
    if state.get("publish_gate") is False:
        recovery_pause_reasons.append("publish_gate_false")
    if state.get("dry_run") is True:
        recovery_pause_reasons.append("dry_run")
    if state_status == "blocked_publish_gate":
        recovery_pause_reasons.append("blocked_publish_gate")
    if not ca_schedule_recovery_enabled:
        recovery_pause_reasons.append("ca_schedule_recovery_disabled")

    record: dict[str, Any] = {
        "state_status": state_status,
        "current_schedule_hash": current_hash,
        "last_sent_schedule_hash": last_sent_hash,
        "hash_pending": hash_pending,
        "last_sent_at_ms": last_sent_at_ms,
        "last_sent_at_kst": kst_text(last_sent_at_ms) if last_sent_at_ms > 0 else "",
        "last_sent_age_min": last_sent_age_min,
        "next_due_at_ms": next_due_at_ms,
        "next_due_at_kst": kst_text(next_due_at_ms) if next_due_at_ms > 0 else "",
        "next_due_age_min": next_due_age_min,
        "interval_ms": interval_ms,
        "state_age_min": state_age_min,
        "publish_gate": state.get("publish_gate"),
        "dry_run": state.get("dry_run"),
        "inflight_request_id": request_id,
        "inflight_outbound_key": outbound_key,
        "last_error": compact(state.get("last_error") or "", 250),
        "ca_projection_enabled": ca_projection_enabled,
        "ca_live_send_enabled": ca_live_send_enabled,
        "ca_schedule_recovery_enabled": ca_schedule_recovery_enabled,
        "ca_kill_switch": ca_kill_switch,
    }


    if not current_hash:
        source_issues.append(
            issue(
                "warn",
                "storebot_broadcast_hash_missing",
                "StoreBot 근무표 자동발송 current hash 없음",
                name,
                {"state_status": state_status},
            )
        )

    request: Any = None
    request_status = ""
    request_age_min: float | None = None
    request_terminal = False
    if request_id:
        try:
            request = fb_get(f"{STOREBOT_CODEX_REQUESTS_PATH}/{firebase_safe_key(request_id)}")
        except Exception as exc:
            source_issues.append(
                issue(
                    "warn",
                    "storebot_broadcast_request_read_error",
                    "StoreBot 근무표 자동발송 inflight request 읽기 실패",
                    name,
                    {"request_id": request_id, "error": compact(exc)},
                )
            )
        if isinstance(request, dict):
            request_status = item_status(request).lower()
            request_ts_ms = storebot_broadcast_latest_ts_ms(request)
            request_age_min = round((now - request_ts_ms) / 60000, 1) if request_ts_ms > 0 else None
            request_terminal = request_status in STOREBOT_BROADCAST_TERMINAL_REQUEST_STATUSES
            outbound_key = str(request.get("outbound_key") or outbound_key).strip()
            record.update(
                {
                    "request_present": True,
                    "request_status": request_status,
                    "request_age_min": request_age_min,
                    "request_terminal": request_terminal,
                    "inflight_outbound_key": outbound_key,
                }
            )
            if request_status in PAUSED_EXTERNAL_REQUEST_STATUSES:
                recovery_pause_reasons.append("paused_external_session")
                source_issues.append(
                    issue(
                        "warn",
                        "storebot_broadcast_recovery_paused",
                        "StoreBot 근무표 자동발송 request 외부 세션 대기로 복구 중지",
                        name,
                        {"request_id": request_id, "request_status": request_status},
                    )
                )
            elif request_terminal and request_status != "done":
                source_issues.append(
                    issue(
                        "error",
                        "storebot_broadcast_request_terminal_failure",
                        "StoreBot 근무표 자동발송 request 실패 상태",
                        name,
                        {"request_id": request_id, "request_status": request_status},
                    )
                )
            elif request_status in STOREBOT_BROADCAST_ACTIVE_REQUEST_STATUSES:
                if request_age_min is not None and request_age_min >= STOREBOT_BRIEFING_STALE_MIN:
                    source_issues.append(
                        issue(
                            "error",
                            "storebot_broadcast_request_stale",
                            "StoreBot 근무표 자동발송 request 처리 지연",
                            name,
                            {
                                "request_id": request_id,
                                "request_status": request_status,
                                "request_age_min": request_age_min,
                            },
                        )
                    )
            elif not request_terminal and request_age_min is not None and request_age_min >= STOREBOT_BRIEFING_STALE_MIN:
                source_issues.append(
                    issue(
                        "warn",
                        "storebot_broadcast_request_unknown_stale",
                        "StoreBot 근무표 자동발송 request 알 수 없는 상태로 지연",
                        name,
                        {
                            "request_id": request_id,
                            "request_status": request_status,
                            "request_age_min": request_age_min,
                        },
                    )
                )
        else:
            record["request_present"] = False
            stale_reference = state_age_min is None or state_age_min >= STOREBOT_BRIEFING_STALE_MIN
            source_issues.append(
                issue(
                    "error" if stale_reference else "warn",
                    "storebot_broadcast_request_missing",
                    "StoreBot 근무표 자동발송 inflight request 없음",
                    name,
                    {"request_id": request_id, "state_age_min": state_age_min},
                )
            )

    outbound: Any = None
    delivery_acked = False
    if outbound_key:
        try:
            outbound = fb_get(f"{STOREBOT_PENDING_QUEUE_PATH}/{firebase_safe_key(outbound_key)}")
        except Exception as exc:
            source_issues.append(
                issue(
                    "warn",
                    "storebot_broadcast_outbound_read_error",
                    "StoreBot 근무표 자동발송 outbound 읽기 실패",
                    name,
                    {"outbound_key": outbound_key, "error": compact(exc)},
                )
            )
        if isinstance(outbound, dict):
            outbound_ts_ms = storebot_broadcast_latest_ts_ms(outbound)
            outbound_age_min = round((now - outbound_ts_ms) / 60000, 1) if outbound_ts_ms > 0 else None
            outbound_sent = outbound.get("sent") is True
            image_sent = storebot_broadcast_image_delivery_succeeded(outbound)
            outbound_status = item_status(outbound).lower()
            delivery_acked = outbound_sent and image_sent
            record.update(
                {
                    "outbound_present": True,
                    "outbound_status": outbound_status,
                    "outbound_age_min": outbound_age_min,
                    "outbound_sent": outbound_sent,
                    "outbound_image_sent": image_sent,
                    "delivery_acked": delivery_acked,
                }
            )
            if outbound_sent and not image_sent:
                source_issues.append(
                    issue(
                        "error",
                        "storebot_broadcast_image_ack_missing",
                        "StoreBot 근무표 outbound가 sent지만 이미지 전송 성공 ack 없음",
                        name,
                        {"outbound_key": outbound_key, "outbound_status": outbound_status},
                    )
                )
            elif outbound_status in {"error", "failed", "failed_timeout", "rejected", "expired"}:
                source_issues.append(
                    issue(
                        "error",
                        "storebot_broadcast_outbound_terminal_failure",
                        "StoreBot 근무표 outbound 실패 상태",
                        name,
                        {"outbound_key": outbound_key, "outbound_status": outbound_status},
                    )
                )
            elif not outbound_sent and outbound_age_min is not None and outbound_age_min >= STOREBOT_BRIEFING_STALE_MIN:
                source_issues.append(
                    issue(
                        "error",
                        "storebot_broadcast_outbound_stale",
                        "StoreBot 근무표 outbound 이미지 전송 지연",
                        name,
                        {"outbound_key": outbound_key, "outbound_age_min": outbound_age_min},
                    )
                )
        else:
            record["outbound_present"] = False
            stale_reference = request_age_min is None or request_age_min >= STOREBOT_BRIEFING_STALE_MIN
            source_issues.append(
                issue(
                    "error" if stale_reference else "warn",
                    "storebot_broadcast_outbound_missing",
                    "StoreBot 근무표 자동발송 outbound 없음",
                    name,
                    {"outbound_key": outbound_key, "request_age_min": request_age_min},
                )
            )
    elif request_terminal and request_status == "done":
        source_issues.append(
            issue(
                "error",
                "storebot_broadcast_done_without_outbound",
                "StoreBot 근무표 request 완료지만 outbound 연결 없음",
                name,
                {"request_id": request_id},
            )
        )

    if delivery_acked:
        broadcast_status = "delivery_acked_pending_state_reconcile"
        if state_age_min is not None and state_age_min >= STOREBOT_BRIEFING_STALE_MIN:
            source_issues.append(
                issue(
                    "warn",
                    "storebot_broadcast_state_reconcile_stale",
                    "StoreBot 근무표 이미지 전송 성공 후 state 반영 지연",
                    name,
                    {"outbound_key": outbound_key, "state_age_min": state_age_min},
                )
            )
    elif request_id or outbound_key:
        broadcast_status = request_status or state_status or "inflight"
    elif state_status in {"image_capture_or_generation_pending", "request_failed", "publish_skipped"}:
        broadcast_status = "recovery_retry_scheduled" if next_due_at_ms > now else "recovery_retry_overdue"
        if due_after_grace:
            source_issues.append(
                issue(
                    "error" if due_after_stale else "warn",
                    "storebot_broadcast_recovery_overdue",
                    "StoreBot 근무표 자동발송 복구 재시도 지연",
                    name,
                    {"state_status": state_status, "next_due_age_min": next_due_age_min},
                )
            )
    elif due_after_grace:
        if hash_pending or not last_sent_hash:
            broadcast_status = "schedule_hash_unsent"
            source_issues.append(
                issue(
                    "error" if due_after_stale else "warn",
                    "storebot_broadcast_hash_unsent",
                    "StoreBot 최신 근무표 hash 미발송",
                    name,
                    {
                        "current_schedule_hash": current_hash,
                        "last_sent_schedule_hash": last_sent_hash,
                        "next_due_age_min": next_due_age_min,
                    },
                )
            )
        else:
            broadcast_status = "periodic_overdue"
            source_issues.append(
                issue(
                    "error" if due_after_stale else "warn",
                    "storebot_broadcast_periodic_overdue",
                    "StoreBot 근무표 주기 발송 지연",
                    name,
                    {"last_sent_age_min": last_sent_age_min, "next_due_age_min": next_due_age_min},
                )
            )
    elif hash_pending:
        broadcast_status = "changed_waiting_due" if next_due_at_ms > now else "changed_due_grace"
        if next_due_at_ms <= 0:
            source_issues.append(
                issue(
                    "warn",
                    "storebot_broadcast_changed_without_due",
                    "StoreBot 근무표 hash 변경됐지만 next_due 없음",
                    name,
                    {"current_schedule_hash": current_hash, "last_sent_schedule_hash": last_sent_hash},
                )
            )
    else:
        broadcast_status = "sent_current" if last_sent_hash else state_status or "initialized"

    if recovery_pause_reasons:
        pause_reason = ",".join(dict.fromkeys(recovery_pause_reasons))
        pause_reason_code = "+".join(dict.fromkeys(recovery_pause_reasons))
        pause_severity = "error" if due_after_grace or hash_pending or state_status == "blocked_publish_gate" else "warn"
        if any(
            reason in {"publish_gate_false", "dry_run", "blocked_publish_gate"}
            for reason in recovery_pause_reasons
        ):
            source_issues.append(
                issue(
                    pause_severity,
                    "storebot_broadcast_recovery_paused",
                    "StoreBot 근무표 자동발송/복구가 pause 상태",
                    name,
                    {
                        "reason": pause_reason,
                        "state_status": state_status,
                        "hash_pending": hash_pending,
                        "next_due_age_min": next_due_age_min,
                    },
                )
            )
        record["recovery_paused"] = True
        record["recovery_pause_reason"] = pause_reason
        record["recovery_pause_reason_code"] = pause_reason_code
    else:
        pause_reason = ""
        pause_reason_code = "none"
        record["recovery_paused"] = False
        record["recovery_pause_reason"] = ""
        record["recovery_pause_reason_code"] = pause_reason_code

    ca_projection_input = storebot_broadcast_ca_projection_input(
        source_issues=source_issues,
        record=record,
        now_value_ms=now,
    )
    if ca_projection_input is None:
        ca_projection_status = "not_required"
        ca_recovery_status = "not_required"
    elif not ca_projection_enabled:
        ca_projection_status = "blocked_projection_disabled"
        ca_recovery_status = "paused_projection_disabled"
    elif not ca_live_send_enabled:
        ca_projection_status = "ready_no_live_delivery"
        ca_recovery_status = "ready" if ca_schedule_recovery_enabled else "paused_recovery_disabled"
    else:
        ca_projection_status = "ready"
        ca_recovery_status = "ready" if ca_schedule_recovery_enabled else "paused_recovery_disabled"
    record.update(
        {
            "ca_projection_input_ready": ca_projection_input is not None,
            "ca_projection_status": ca_projection_status,
            "ca_recovery_status": ca_recovery_status,
            "ca_recovery_transitions": ca_recovery_transitions,
        }
    )

    status = max_severity(source_issues)
    return {
        "name": name,
        "contract": "work_schedule_broadcast_v2",
        "path": STOREBOT_WORK_SCHEDULE_BROADCAST_STATE_PATH,
        "ok": not [item for item in source_issues if SEVERITY_SCORE.get(str(item.get("severity")), 0) >= 1],
        "status": status,
        "broadcast_status": broadcast_status,
        "recovery_paused": bool(recovery_pause_reasons),
        "recovery_pause_reason": pause_reason,
        "recovery_pause_reason_code": pause_reason_code,
        "current_schedule_hash": current_hash,
        "last_sent_schedule_hash": last_sent_hash,
        "hash_pending": hash_pending,
        "last_sent_age_min": last_sent_age_min,
        "next_due_at_ms": next_due_at_ms,
        "next_due_age_min": next_due_age_min,
        "ca_projection_enabled": ca_projection_enabled,
        "ca_live_send_enabled": ca_live_send_enabled,
        "ca_schedule_recovery_enabled": ca_schedule_recovery_enabled,
        "ca_projection_status": ca_projection_status,
        "ca_projection_input": ca_projection_input,
        "ca_recovery_status": ca_recovery_status,
        "ca_recovery_transitions": ca_recovery_transitions,
        "missing_grace_min": STOREBOT_BRIEFING_MISSING_GRACE_MIN,
        "stale_min": STOREBOT_BRIEFING_STALE_MIN,
        "records": [record],
    }, source_issues


def _posdelay_issue_codes_from_values(data: dict[str, Any]) -> set[str]:
    codes: set[str] = set()
    status = status_text(data).lower()
    if status == "no_accessibility":
        codes.add("no_accessibility")
    if status in POSDELAY_RUNTIME_ISSUE_CODES:
        codes.add(status)
    if data.get("kds_accessibility") is False:
        codes.add("kds_accessibility_off")
    if data.get("delay_accessibility") is False:
        codes.add("delay_accessibility_off")
    issues = data.get("issues")
    if isinstance(issues, dict):
        issue_values = list(issues.keys())
        for value in issues.values():
            if isinstance(value, dict):
                issue_values.append(str(value.get("code") or value.get("issue") or value.get("status") or ""))
            else:
                issue_values.append(str(value))
    elif isinstance(issues, list):
        issue_values = [str(value.get("code") if isinstance(value, dict) else value) for value in issues]
    else:
        issue_values = []
    for raw in issue_values:
        code = str(raw or "").strip()
        if code in POSDELAY_RUNTIME_ISSUE_CODES:
            codes.add(code)
    for field in ("kds_sync_stale", "sync_stale"):
        if data.get(field) is True:
            codes.add("kds_sync_stale")
    for field in ("last_sync_age", "last_sync_age_sec", "kds_sync_age_sec"):
        value = data.get(field)
        try:
            if isinstance(value, (int, float, str)) and float(value) > 30 * 60:
                codes.add("kds_sync_stale")
        except (TypeError, ValueError):
            pass
    return codes


def evaluate_posdelay_runtime_health() -> tuple[dict[str, Any], list[dict[str, Any]]]:
    name = "posdelay_runtime_health"
    source_issues: list[dict[str, Any]] = []
    app_latest: Any = None
    app_latest_kds: Any = None
    heartbeat: Any = None
    read_errors: dict[str, str] = {}
    try:
        app_latest = fb_get("/posdelay/monitoring/app_latest")
    except Exception as exc:
        read_errors["app_latest"] = compact(exc)
    try:
        app_latest_kds = fb_get("/posdelay/monitoring/app_latest/kds")
    except Exception as exc:
        read_errors["app_latest_kds"] = compact(exc)
    try:
        heartbeat = fb_get("/subphone/heartbeat/posdelay")
    except Exception as exc:
        read_errors["subphone_heartbeat"] = compact(exc)

    if read_errors:
        source_issues.append(issue("warn", "runtime_read_error", "PosDelay runtime 상태 일부 읽기 실패", name, read_errors))

    runtime_codes: set[str] = set()
    for item in (app_latest, app_latest_kds, heartbeat):
        if isinstance(item, dict):
            runtime_codes.update(_posdelay_issue_codes_from_values(item))

    heartbeat_ts = extract_ts_ms(heartbeat) if isinstance(heartbeat, dict) else 0
    heartbeat_age = age_min(heartbeat_ts)
    heartbeat_fresh = heartbeat_ts > 0 and now_ms() - heartbeat_ts <= 10 * 60000
    if runtime_codes:
        source_issues.append(
            issue(
                "error",
                "posdelay_runtime_recoverable",
                "PosDelay 앱 runtime self-heal 필요",
                name,
                {
                    "runtime_issue_codes": sorted(runtime_codes),
                    "heartbeat_age_min": heartbeat_age,
                    "heartbeat_status": status_text(heartbeat) if isinstance(heartbeat, dict) else "",
                    "command_path": POSDELAY_CMD_PATH,
                    "safe_command": "recover_runtime",
                },
            )
        )

    return {
        "name": name,
        "ok": not source_issues,
        "status": "runtime_recoverable" if runtime_codes else "ok",
        "runtime_issue_codes": sorted(runtime_codes),
        "heartbeat_age_min": heartbeat_age,
        "heartbeat_fresh": heartbeat_fresh,
        "heartbeat_status": status_text(heartbeat) if isinstance(heartbeat, dict) else "",
    }, source_issues


def compare_number(value: Any) -> float | None:
    if isinstance(value, bool) or value is None:
        return None
    if isinstance(value, (int, float)):
        return float(value)
    if isinstance(value, str):
        try:
            return float(value.strip())
        except ValueError:
            return None
    return None


def evaluate_consistency_check(source: dict[str, Any]) -> tuple[dict[str, Any], list[dict[str, Any]]]:
    name = source["name"]
    left_path = source["left_path"]
    right_path = source["right_path"]
    left_field = str(source.get("left_field") or "")
    right_field = str(source.get("right_field") or "")
    left_ts_field = str(source.get("left_ts_field") or "")
    right_ts_field = str(source.get("right_ts_field") or "")
    severity = str(source.get("severity") or "warn")
    max_delta = float(source.get("max_delta") or 0)
    grace_ms = int(source.get("grace_sec") or 0) * 1000
    source_issues: list[dict[str, Any]] = []
    try:
        left = fb_get(left_path)
        right = fb_get(right_path)
    except Exception as exc:
        source_issues.append(
            issue(severity, "consistency_read_error", f"{name} 비교 경로 읽기 실패", name, {"error": compact(exc)})
        )
        return {"name": name, "ok": False, "status": "read_error"}, source_issues

    left_present = isinstance(left, dict)
    right_present = isinstance(right, dict)
    if not left_present and source.get("left_missing_ok_status"):
        summary = {
            "name": name,
            "left_path": left_path,
            "right_path": right_path,
            "left_field": left_field,
            "right_field": right_field,
            "left_present": False,
            "right_present": right_present,
            "ok": True,
            "status": str(source.get("left_missing_ok_status") or "left_missing_ok"),
        }
        if right_present:
            right_ts = extract_field_ts_ms(right, right_ts_field)
            summary.update(
                {
                    "right_value": get_field(right, right_field),
                    "right_age_min": age_min(right_ts),
                }
            )
        return summary, source_issues
    if left_present and not right_present and source.get("right_missing_grace_status"):
        left_value = get_field(left, left_field)
        left_ts = extract_field_ts_ms(left, left_ts_field)
        left_age = age_min(left_ts)
        if grace_ms > 0 and left_ts > 0 and now_ms() - left_ts <= grace_ms:
            return {
                "name": name,
                "left_path": left_path,
                "right_path": right_path,
                "left_field": left_field,
                "right_field": right_field,
                "left_value": left_value,
                "left_age_min": left_age,
                "left_present": True,
                "right_present": False,
                "ok": True,
                "status": str(source.get("right_missing_grace_status") or "right_missing_grace"),
            }, source_issues
    if not left_present or not right_present:
        source_issues.append(
            issue(
                severity,
                "consistency_missing",
                f"{name} 비교 데이터 없음",
                name,
                {"left_path": left_path, "right_path": right_path, "left_present": left_present, "right_present": right_present},
            )
        )
        return {"name": name, "ok": False, "status": "missing"}, source_issues

    left_value = get_field(left, left_field)
    right_value = get_field(right, right_field)
    left_ts = extract_field_ts_ms(left, left_ts_field)
    right_ts = extract_field_ts_ms(right, right_ts_field)
    left_age = age_min(left_ts)
    right_age = age_min(right_ts)

    if left_value is None or right_value is None:
        source_issues.append(
            issue(
                severity,
                "consistency_field_missing",
                f"{name} 비교 필드 없음",
                name,
                {
                    "left_field": left_field,
                    "right_field": right_field,
                    "left_value": left_value,
                    "right_value": right_value,
                },
            )
        )
    else:
        left_num = compare_number(left_value)
        right_num = compare_number(right_value)
        latest_ts = max(left_ts, right_ts)
        waiting_for_next_heartbeat = latest_ts > 0 and abs(left_ts - right_ts) > 0 and now_ms() - latest_ts <= grace_ms
        if waiting_for_next_heartbeat:
            return {
                "name": name,
                "left_path": left_path,
                "right_path": right_path,
                "left_field": left_field,
                "right_field": right_field,
                "left_value": left_value,
                "right_value": right_value,
                "left_age_min": left_age,
                "right_age_min": right_age,
                "ok": True,
                "status": "waiting_for_next_heartbeat",
            }, source_issues
        if left_num is not None and right_num is not None:
            delta = abs(left_num - right_num)
            mismatch = delta > max_delta
        else:
            delta = None
            mismatch = left_value != right_value
        if mismatch:
            source_issues.append(
                issue(
                    severity,
                    "consistency_mismatch",
                    f"{name} 값 불일치",
                    name,
                    {
                        "left_path": left_path,
                        "left_field": left_field,
                        "left_value": left_value,
                        "left_age_min": left_age,
                        "right_path": right_path,
                        "right_field": right_field,
                        "right_value": right_value,
                        "right_age_min": right_age,
                        "delta": delta,
                        "max_delta": max_delta,
                    },
                )
            )

    return {
        "name": name,
        "left_path": left_path,
        "right_path": right_path,
        "left_field": left_field,
        "right_field": right_field,
        "left_value": left_value,
        "right_value": right_value,
        "left_age_min": left_age,
        "right_age_min": right_age,
        "ok": not source_issues,
        "status": max_severity(source_issues),
    }, source_issues


ORDERHELPER_FB_PATH = "/order/desk_q7m9r3a8"


def count_positive_values(data: Any) -> int:
    if not isinstance(data, dict):
        return 0
    count = 0
    for value in data.values():
        number = compare_number(value)
        if number is not None and number > 0:
            count += 1
    return count


def count_sfa_actual_history(data: Any) -> int:
    if not isinstance(data, dict):
        return 0
    count = 0
    for key, value in data.items():
        if key == "latest" or not isinstance(value, dict):
            continue
        if count_positive_values(value.get("actualOrders")) > 0:
            count += 1
    return count


def orderhelper_unit_key(value: Any) -> str:
    text = str(value or "").strip().lower()
    if text in {"box", "박스", "박"}:
        return "box"
    if text in {"ea", "개"}:
        return "ea"
    if text in {"bon", "봉"}:
        return "bon"
    if text in {"묶", "묶음"}:
        return "bundle"
    return text


def orderhelper_expected_unit_is_mixed(unit_text: Any) -> bool:
    parts = [part.strip() for part in str(unit_text or "").split("/", 1)]
    if len(parts) != 2:
        return False
    return orderhelper_unit_key(parts[0]) != orderhelper_unit_key(parts[1])


def orderhelper_sfa_qty_rows(compare_data: Any) -> list[dict[str, Any]]:
    if not isinstance(compare_data, dict):
        return []
    comparison = compare_data.get("comparison") if isinstance(compare_data.get("comparison"), dict) else {}
    rows = comparison.get("matched")
    if not isinstance(rows, list):
        return []
    result = []
    for row in rows:
        if not isinstance(row, dict):
            continue
        qty = compare_number(row.get("sfa_qty"))
        if qty is not None and qty > 0 and row.get("expected_name"):
            result.append(row)
    return result


def evaluate_orderhelper_quality() -> tuple[dict[str, Any], list[dict[str, Any]]]:
    name = "orderhelper_actual_usage_inference"
    compare_path = f"{ORDERHELPER_FB_PATH}/sfaCompare/latest"
    current_path = f"{ORDERHELPER_FB_PATH}/current"
    history_path = f"{ORDERHELPER_FB_PATH}/history"
    sfa_history_path = f"{ORDERHELPER_FB_PATH}/sfaActualHistory"
    inference_path = f"{ORDERHELPER_FB_PATH}/unitInference/latest"
    source_issues: list[dict[str, Any]] = []
    try:
        compare_data = fb_get(compare_path)
        current_data = fb_get(current_path)
        history_data = fb_get(history_path, query={"orderBy": json.dumps("$key"), "limitToLast": 5})
        sfa_history_data = fb_get(sfa_history_path, query={"orderBy": json.dumps("$key"), "limitToLast": 16})
        inference_data = fb_get(inference_path)
    except Exception as exc:
        source_issues.append(issue("warn", "orderhelper_quality_read_error", "OrderHelper 품질 데이터 읽기 실패", name, {"error": compact(exc)}))
        return {"name": name, "path": compare_path, "ok": False, "status": "read_error"}, source_issues

    if not isinstance(compare_data, dict):
        return {"name": name, "path": compare_path, "ok": True, "status": "empty"}, source_issues

    compare_ts = normalize_ts_ms(compare_data.get("savedAt") or compare_data.get("saved_at"))
    compare_age = age_min(compare_ts)
    rows = orderhelper_sfa_qty_rows(compare_data)
    applied_count = count_positive_values(compare_data.get("appliedActualOrders"))
    current_actual_count = count_positive_values(current_data.get("actualOrders") if isinstance(current_data, dict) else None)
    recent_history_actual_count = 0
    history_dates: list[str] = []
    if isinstance(history_data, dict):
        for key, value in history_data.items():
            if not isinstance(value, dict):
                continue
            history_dates.append(str(value.get("dateKey") or key))
            recent_history_actual_count = max(recent_history_actual_count, count_positive_values(value.get("actualOrders")))

    mixed_rows = [row for row in rows if orderhelper_expected_unit_is_mixed(row.get("expected_unit"))]
    sfa_history_count = count_sfa_actual_history(sfa_history_data)
    inference_ts = normalize_ts_ms(inference_data.get("ts") if isinstance(inference_data, dict) else None)
    inference_age = age_min(inference_ts)
    inference_result_count = int(compare_number(inference_data.get("result_count")) or 0) if isinstance(inference_data, dict) else 0
    compare_recent = compare_ts <= 0 or now_ms() - compare_ts <= 48 * 60 * 60000
    if compare_data.get("ok") is False and compare_recent:
        source_issues.append(
            issue(
                "warn",
                "orderhelper_sfa_compare_failed",
                "OrderHelper SFA 분석 결과가 실패 상태",
                name,
                {"compare_age_min": compare_age, "file": get_field(compare_data, "file.name")},
            )
        )
    if rows and compare_recent and sfa_history_count == 0:
        source_issues.append(
            issue(
                "warn",
                "orderhelper_sfa_actual_history_missing",
                "OrderHelper SFA 분석은 됐지만 실발주 이력이 아직 누적되지 않음",
                name,
                {
                    "sfa_rows_with_qty": len(rows),
                    "compare_age_min": compare_age,
                    "safe_cli_scope": "감지, 보고, usage/unit inference 리포트 업로드, UI/문서/테스트/배포 보정 허용. 실발주 원본 자동변조 금지.",
                    "sample_items": [str(row.get("expected_name")) for row in rows[:5]],
                },
            )
        )
    if mixed_rows and compare_recent and (not isinstance(inference_data, dict) or inference_result_count <= 0):
        source_issues.append(
            issue(
                "warn",
                "orderhelper_unit_inference_missing",
                "OrderHelper 발주단위/재고단위 환산 CLI 추정 리포트가 없음",
                name,
                {
                    "mixed_unit_rows": len(mixed_rows),
                    "unit_inference_path": inference_path,
                    "sample_items": [
                        {
                            "name": row.get("expected_name"),
                            "expected_unit": row.get("expected_unit"),
                            "sfa_unit": row.get("sfa_unit"),
                            "sfa_qty": row.get("sfa_qty"),
                            "expected_stock_need": row.get("expected_stock_need"),
                        }
                        for row in mixed_rows[:5]
                    ],
                    "recommended_cli": "python3 scripts/orderhelper_usage_inference.py --upload",
                },
            )
        )
    if mixed_rows and compare_recent and inference_ts > 0 and now_ms() - inference_ts > 24 * 60 * 60000:
        source_issues.append(
            issue(
                "warn",
                "orderhelper_unit_inference_stale",
                "OrderHelper 단위/실사용 CLI 추정 리포트가 오래됨",
                name,
                {
                    "unit_inference_age_min": inference_age,
                    "unit_inference_path": inference_path,
                    "recommended_cli": "python3 scripts/orderhelper_usage_inference.py --upload",
                },
            )
        )

    return {
        "name": name,
        "path": compare_path,
        "ok": not source_issues,
        "status": max_severity(source_issues),
        "compare_age_min": compare_age,
        "sfa_rows_with_qty": len(rows),
        "mixed_unit_rows": len(mixed_rows),
        "applied_actual_orders_count": applied_count,
        "current_actual_orders_count": current_actual_count,
        "recent_history_actual_orders_count": recent_history_actual_count,
        "sfa_actual_history_count": sfa_history_count,
        "unit_inference_result_count": inference_result_count,
        "unit_inference_age_min": inference_age,
        "history_dates": history_dates[-5:],
    }, source_issues


def is_codex_model_refresh_runtime_error(error: Any) -> bool:
    text = compact(error, 1200).lower()
    return (
        "failed to refresh available models" in text
        or "timeout waiting for child process to exit" in text
        or "resident_response_health_empty_final" in text
    )


def request_error_ts_ms(input_health: dict[str, Any], request: dict[str, Any], key: str = "") -> int:
    for value in (
        input_health.get("last_request_error_at_ms"),
        request.get("finished_at_ms"),
        request.get("updated_at_ms"),
        request.get("created_at_ms"),
        request.get("ts_ms"),
        request.get("ts"),
    ):
        ts = normalize_ts_ms(value)
        if ts > 0:
            return ts
    return extract_ts_ms(request, key)


def evaluate_storebot_recent_request_error(
    source: dict[str, Any],
    request_path: str,
    *,
    exclude_request_id: str = "",
) -> tuple[dict[str, Any], list[dict[str, Any]]]:
    name = source["name"]
    recent_window = int(source.get("recent_error_window_min") or source.get("recent_window_min") or 30)
    limit = int(source.get("recent_error_request_limit") or 80)
    source_issues: list[dict[str, Any]] = []
    input_health: dict[str, Any] = {}
    try:
        raw_input = fb_get(str(source.get("input_health_path") or ""))
        input_health = raw_input if isinstance(raw_input, dict) else {}
    except Exception as exc:
        source_issues.append(issue("warn", "kakao_input_health_read_error", f"{name} 입력 health 읽기 실패", name, {"error": compact(exc)}))

    selected_id = str(input_health.get("last_request_error_id") or "").strip().replace("/", "_")
    selected_request: dict[str, Any] = {}
    selected_key = selected_id
    selected_status = str(input_health.get("last_request_error_status") or "").strip().lower()
    read_error = ""
    if selected_id:
        try:
            raw_request = fb_get(f"{request_path}/{firebase_safe_key(selected_id)}")
            selected_request = raw_request if isinstance(raw_request, dict) else {}
            selected_status = str(
                selected_request.get("status")
                or selected_request.get("local_recovery_status")
                or selected_request.get("ingress_status")
                or selected_status
            ).strip().lower()
        except Exception as exc:
            read_error = compact(exc)

    if selected_status not in {"error", "action_error"}:
        try:
            candidates = queue_items(request_path, limit)
        except Exception as exc:
            candidates = {}
            if not read_error:
                read_error = compact(exc)
        latest_ts = 0
        for key, value in candidates.items():
            if not isinstance(value, dict):
                continue
            status = str(value.get("status") or value.get("local_recovery_status") or value.get("ingress_status") or "").strip().lower()
            if status not in {"error", "action_error"}:
                continue
            ts = request_error_ts_ms({}, value, str(key))
            if ts >= latest_ts:
                selected_id = str(key)
                selected_key = str(key)
                selected_request = value
                selected_status = status
                latest_ts = ts

    error_text = compact(
        input_health.get("last_request_error")
        or selected_request.get("error")
        or selected_request.get("last_error"),
        500,
    )
    error_ts = request_error_ts_ms(input_health, selected_request, selected_key)
    error_age = age_min(error_ts)
    recent = bool(selected_id) and selected_status in {"error", "action_error"} and error_age is not None and error_age <= recent_window
    model_refresh_failure = is_codex_model_refresh_runtime_error(error_text)
    excluded = bool(exclude_request_id and selected_id == exclude_request_id)
    if recent and not excluded and not is_kakao_screen_ui_noise({}, selected_request):
        code = "kakao_model_refresh_failure" if model_refresh_failure else "kakao_recent_request_error"
        message = (
            f"{name} Codex model refresh runtime failure"
            if model_refresh_failure
            else f"{name} 최근 카톡 request 오류"
        )
        source_issues.append(
            issue(
                "error",
                code,
                message,
                name,
                {
                    "request_id": selected_id,
                    "status": selected_status,
                    "age_min": error_age,
                    "error": error_text,
                    "model_refresh_failure": model_refresh_failure,
                    "source": selected_request.get("source"),
                    "diagnostic_request_id": selected_request.get("diagnostic_request_id") or input_health.get("last_request_diagnostic_id"),
                    "diagnostic_enqueue_status": selected_request.get("diagnostic_enqueue_status") or input_health.get("last_request_diagnostic_enqueue_status"),
                },
            )
        )

    return {
        "present": bool(selected_id),
        "recent": recent,
        "excluded_current_request": excluded,
        "request_id": selected_id or None,
        "status": selected_status or None,
        "age_min": error_age,
        "error": error_text,
        "model_refresh_failure": model_refresh_failure,
        "diagnostic_enqueued": selected_request.get("diagnostic_enqueued") or input_health.get("diagnostic_enqueued"),
        "self_fix_enqueued": selected_request.get("self_fix_enqueued") or input_health.get("self_fix_enqueued"),
        "diagnostic_request_id": selected_request.get("diagnostic_request_id") or input_health.get("last_request_diagnostic_id"),
        "diagnostic_enqueue_status": selected_request.get("diagnostic_enqueue_status") or input_health.get("last_request_diagnostic_enqueue_status"),
        "read_error": read_error or None,
    }, source_issues


def evaluate_kakao_reply_flow(source: dict[str, Any]) -> tuple[dict[str, Any], list[dict[str, Any]]]:
    name = source["name"]
    claim_path = source["claim_path"]
    request_path = source["request_path"].rstrip("/")
    recent_window = int(source.get("recent_window_min") or 30)
    max_claim_to_request = int(source.get("max_claim_to_request_min") or 2)
    max_inflight = int(source.get("max_inflight_min") or 8)
    max_running = int(source.get("max_running_min") or 12)
    max_deferred_running = int(source.get("max_deferred_running_min") or max_running)
    max_done_elapsed_ms = int(source.get("max_done_elapsed_ms") or 120000)
    max_skip_elapsed_ms = int(source.get("max_skip_elapsed_ms") or 60000)
    slow_skip_severity = str(source.get("slow_skip_severity") or "info")
    if slow_skip_severity not in SEVERITY_SCORE:
        slow_skip_severity = "info"
    source_issues: list[dict[str, Any]] = []
    recent_error_summary, recent_error_issues = evaluate_storebot_recent_request_error(source, request_path)
    source_issues.extend(recent_error_issues)
    try:
        claim = fb_get(claim_path)
    except Exception as exc:
        source_issues.append(issue("warn", "kakao_claim_read_error", f"{name} 카톡 claim 읽기 실패", name, {"error": compact(exc)}))
        return {"name": name, "path": claim_path, "ok": False, "status": "read_error", "recent_error_request": recent_error_summary}, source_issues

    if not isinstance(claim, dict):
        input_summary, input_issues = evaluate_kakao_input_gap(source, {})
        source_issues.extend(input_issues)
        return {
            "name": name,
            "path": claim_path,
            "ok": not source_issues,
            "status": "no_claim",
            "age_min": None,
            "input_health": input_summary,
            "recent_error_request": recent_error_summary,
        }, source_issues

    claim_ts = extract_ts_ms(claim)
    claim_age = age_min(claim_ts)
    if claim_ts <= 0 or now_ms() - claim_ts > recent_window * 60000:
        input_summary, input_issues = evaluate_kakao_input_gap(source, claim)
        source_issues.extend(input_issues)
        return {
            "name": name,
            "path": claim_path,
            "ok": not source_issues,
            "status": "no_recent_input",
            "age_min": claim_age,
            "input_health": input_summary,
            "recent_error_request": recent_error_summary,
        }, source_issues

    request_id = str(claim.get("request_id") or "").strip().replace("/", "_")
    request: dict[str, Any] = {}
    if request_id:
        try:
            raw_request = fb_get(f"{request_path}/{request_id}")
            request = raw_request if isinstance(raw_request, dict) else {}
        except Exception as exc:
            source_issues.append(issue("warn", "kakao_request_read_error", f"{name} request 읽기 실패", name, {"request_id": request_id, "error": compact(exc)}))
    if not request:
        if claim_age is not None and claim_age > max_claim_to_request:
            source_issues.append(
                issue(
                    "error",
                    "kakao_claim_without_request",
                    f"{name} 카톡 입력은 잡혔지만 AI request가 없음",
                    name,
                    {"request_id": request_id, "claim_age_min": claim_age, "max_age_min": max_claim_to_request},
                )
            )
        return {
            "name": name,
            "path": claim_path,
            "ok": not source_issues,
            "status": "request_missing",
            "age_min": claim_age,
            "request_id": request_id or None,
            "transport": claim.get("transport"),
            "recent_error_request": recent_error_summary,
        }, source_issues

    status = str(request.get("status") or request.get("local_recovery_status") or request.get("ingress_status") or "").strip()
    req_ts = extract_ts_ms(request)
    req_age = age_min(req_ts)
    stale_age = req_age if req_age is not None else claim_age
    done_statuses = {"done", "reply_skipped", "expired"}
    inflight_statuses = {"local_direct_inflight", "local_recovery_pending", "pending"}
    running_statuses = {"running", "processing"}
    try:
        elapsed_ms = int(request.get("local_direct_elapsed_ms") or request.get("elapsed_ms") or 0)
    except (TypeError, ValueError):
        elapsed_ms = 0
    screen_ui_noise = is_kakao_screen_ui_noise(claim, request)
    local_direct_deferred = request.get("local_direct_deferred") is True
    output_category = str(request.get("output_category") or "")
    if status in {"error", "action_error"} and not screen_ui_noise:
        source_issues.append(
            issue(
                "error",
                "kakao_request_error",
                f"{name} 카톡 답변 request 오류",
                name,
                {"request_id": request_id, "status": status, "error": compact(request.get("error") or request.get("last_error"))},
            )
        )
    elif status in {"error", "action_error"} and screen_ui_noise:
        pass
    elif status in inflight_statuses and stale_age is not None and stale_age > max_inflight and not screen_ui_noise:
        source_issues.append(
            issue(
                "error",
                "kakao_reply_inflight_stale",
                f"{name} 카톡 답변 미완료",
                name,
                {"request_id": request_id, "status": status, "age_min": stale_age, "max_age_min": max_inflight},
            )
        )
    elif (
        status in running_statuses
        and local_direct_deferred
        and stale_age is not None
        and stale_age > max_deferred_running
        and not screen_ui_noise
    ):
        source_issues.append(
            issue(
                "error",
                "kakao_reply_deferred_stale",
                f"{name} 지연 답변 running 장시간 지속",
                name,
                {
                    "request_id": request_id,
                    "status": status,
                    "age_min": stale_age,
                    "max_age_min": max_deferred_running,
                    "elapsed_ms": elapsed_ms,
                },
            )
        )
    elif (
        status in running_statuses
        and local_direct_deferred
        and stale_age is not None
        and stale_age > max_running
        and not screen_ui_noise
    ):
        source_issues.append(
            issue(
                "warn",
                "kakao_reply_deferred_slow",
                f"{name} 지연 답변 처리 중",
                name,
                {"request_id": request_id, "status": status, "age_min": stale_age, "max_age_min": max_running},
            )
        )
    elif status in running_statuses and stale_age is not None and stale_age > max_running and not screen_ui_noise:
        source_issues.append(
            issue(
                "error",
                "kakao_reply_running_stale",
                f"{name} 카톡 답변 running 장시간 지속",
                name,
                {"request_id": request_id, "status": status, "age_min": stale_age, "max_age_min": max_running},
            )
        )
    elif (
        status in done_statuses
        and request.get("reply_skipped") is True
        and elapsed_ms > max_skip_elapsed_ms
        and not screen_ui_noise
    ):
        source_issues.append(
            issue(
                slow_skip_severity,
                "kakao_slow_skip_silent",
                f"{name} skip 처리 지연",
                name,
                {
                    "request_id": request_id,
                    "elapsed_ms": elapsed_ms,
                    "max_elapsed_ms": max_skip_elapsed_ms,
                    "message_preview": claim.get("message_preview"),
                },
            )
        )
    elif status in done_statuses and elapsed_ms > max_done_elapsed_ms and not screen_ui_noise:
        source_issues.append(
            issue(
                "warn",
                "kakao_reply_slow_done",
                f"{name} 카톡 답변 처리가 느림",
                name,
                {"request_id": request_id, "elapsed_ms": elapsed_ms, "max_elapsed_ms": max_done_elapsed_ms},
            )
        )
    elif status not in done_statuses | inflight_statuses | running_statuses:
        source_issues.append(issue("warn", "kakao_request_unknown_status", f"{name} 알 수 없는 카톡 request 상태", name, {"request_id": request_id, "status": status}))

    return {
        "name": name,
        "path": claim_path,
        "ok": not source_issues,
        "status": status or "missing",
        "age_min": stale_age,
        "request_id": request_id,
        "reply_skipped": request.get("reply_skipped"),
        "output_category": output_category,
        "local_direct_deferred": local_direct_deferred,
        "elapsed_ms": elapsed_ms,
        "message_preview": claim.get("message_preview"),
        "screen_ui_noise": screen_ui_noise,
        "recent_error_request": recent_error_summary,
    }, source_issues


def evaluate_kakao_input_gap(source: dict[str, Any], claim: dict[str, Any]) -> tuple[dict[str, Any], list[dict[str, Any]]]:
    name = source["name"]
    source_issues: list[dict[str, Any]] = []
    input_health: dict[str, Any] = {}
    bridge_latest: dict[str, Any] = {}
    transport_hb: dict[str, Any] = {}
    try:
        raw = fb_get(str(source.get("input_health_path") or ""))
        input_health = raw if isinstance(raw, dict) else {}
    except Exception as exc:
        source_issues.append(issue("warn", "kakao_input_health_read_error", f"{name} 입력 health 읽기 실패", name, {"error": compact(exc)}))
    try:
        raw = fb_get(str(source.get("bridge_latest_path") or ""))
        bridge_latest = raw if isinstance(raw, dict) else {}
    except Exception:
        bridge_latest = {}
    try:
        raw = fb_get(str(source.get("transport_heartbeat_path") or ""))
        transport_hb = raw if isinstance(raw, dict) else {}
    except Exception:
        transport_hb = {}

    input_health_present = bool(input_health)
    active_scan_from_bridge_log = False
    active_scan_ts = extract_field_ts_ms(input_health, "last_active_scan_ms")
    active_scan_count = int(input_health.get("active_scan_count") or 0) if isinstance(input_health.get("active_scan_count"), (int, float)) else 0
    bridge_message = str(bridge_latest.get("message") or "")
    if active_scan_ts <= 0 and "active kakao scan" in bridge_message:
        active_scan_ts = extract_ts_ms(bridge_latest)
        active_scan_from_bridge_log = True
    claim_ts = max(extract_ts_ms(claim), extract_field_ts_ms(input_health, "last_claim_created_ms"))
    notification_ts = extract_field_ts_ms(input_health, "last_notification_seen_ms")
    active_scan_age = age_min(active_scan_ts)
    claim_age = age_min(claim_ts)
    notification_age = age_min(notification_ts)
    max_active_scan_age = int(source.get("max_active_scan_age_min") or 5)
    warn_gap = int(source.get("max_claim_gap_with_scan_warn_min") or 0)
    error_gap = int(source.get("max_claim_gap_with_scan_error_min") or 0)
    active_scan_recent = active_scan_age is not None and active_scan_age <= max_active_scan_age
    transport_version = str(transport_hb.get("version_name") or transport_hb.get("version") or "")
    claim_version = str(claim.get("version_name") or input_health.get("version_name") or "")
    version_gap = bool(transport_version and claim_version and transport_version != claim_version)

    input_gap_observable = input_health_present and not active_scan_from_bridge_log
    if (
        input_gap_observable
        and active_scan_recent
        and warn_gap > 0
        and (claim_ts <= 0 or (claim_age is not None and claim_age > warn_gap))
    ):
        severity = "warn"
        code = "kakao_input_claim_gap_after_active_scan"
        if (error_gap > 0 and (claim_ts <= 0 or (claim_age is not None and claim_age > error_gap))) or version_gap:
            severity = "error"
            code = "kakao_input_unverified_after_active_scan"
        source_issues.append(
            issue(
                severity,
                code,
                f"{name} 카카오 active scan은 살아 있지만 입력 claim이 장시간 갱신되지 않음",
                name,
                {
                    "active_scan_age_min": active_scan_age,
                    "claim_age_min": claim_age,
                    "notification_age_min": notification_age,
                    "warn_gap_min": warn_gap,
                    "error_gap_min": error_gap,
                    "active_scan_count": active_scan_count or None,
                    "transport_version": transport_version or None,
                    "claim_version": claim_version or None,
                    "version_gap": version_gap,
                    "last_transport": input_health.get("last_transport"),
                    "last_room_name": input_health.get("last_room_name"),
                },
            )
        )

    return {
        "path": source.get("input_health_path"),
        "active_scan_age_min": active_scan_age,
        "claim_age_min": claim_age,
        "notification_age_min": notification_age,
        "active_scan_count": active_scan_count or None,
        "input_health_present": input_health_present,
        "active_scan_from_bridge_log": active_scan_from_bridge_log,
        "input_gap_observable": input_gap_observable,
        "transport_version": transport_version or None,
        "claim_version": claim_version or None,
        "version_gap": version_gap,
    }, source_issues


def evaluate_bundle_sync_check(source: dict[str, Any]) -> tuple[dict[str, Any], list[dict[str, Any]]]:
    name = source["name"]
    source_issues: list[dict[str, Any]] = []
    heartbeat: dict[str, Any] = {}
    command: dict[str, Any] = {}
    manifest: dict[str, Any] = {}
    try:
        raw = fb_get(str(source.get("heartbeat_path") or ""))
        heartbeat = raw if isinstance(raw, dict) else {}
    except Exception as exc:
        source_issues.append(issue("warn", "bundle_heartbeat_read_error", f"{name} worker heartbeat 읽기 실패", name, {"error": compact(exc)}))
    try:
        raw = fb_get(str(source.get("command_path") or ""))
        command = raw if isinstance(raw, dict) else {}
    except Exception:
        command = {}
    manifest_url = str(source.get("manifest_url") or "").strip()
    if manifest_url:
        try:
            raw = fetch_json_url(manifest_url)
            manifest = raw if isinstance(raw, dict) else {}
        except Exception as exc:
            source_issues.append(issue("warn", "bundle_manifest_read_error", f"{name} hosted bundle manifest 읽기 실패", name, {"error": compact(exc), "url": manifest_url}))

    current_version = str(heartbeat.get("bundle_version") or "")
    current_sha = str(heartbeat.get("bundle_sha256") or "")
    current_status = str(heartbeat.get("bundle_status") or "")
    heartbeat_age = age_min(extract_ts_ms(heartbeat))
    applied_ts_ms = normalize_ts_ms(heartbeat.get("bundle_applied_at_ms"))
    applied_age = age_min(applied_ts_ms)
    command_action = str(command.get("command") or command.get("action") or "").strip().lower()
    command_status = str(command.get("status") or "").strip().lower()
    command_target_version = str(command.get("target_version") or command.get("bundle_version") or "").strip()
    command_target_sha = str(command.get("target_sha256") or command.get("bundle_sha256") or "").strip()
    command_ts_ms = normalize_ts_ms(command.get("processed_at_ms") or command.get("started_at_ms") or command.get("created_at_ms"))
    command_age = age_min(command_ts_ms)
    manifest_version = str(manifest.get("version") or "")
    manifest_sha = str(manifest.get("bundle_sha256") or manifest.get("sha256") or "")
    sync_action = command_action in {"sync_worker_bundle", "download_worker_bundle", "sync_and_repair_worker", "repair_worker_from_hosted_bundle"}
    command_is_newer_than_applied_bundle = command_ts_ms is not None and (
        applied_ts_ms is None or command_ts_ms >= applied_ts_ms
    )
    command_done_mismatch = (
        sync_action
        and command_status == "done"
        and command_age is not None
        and command_age >= int(source.get("max_command_done_lag_min") or 5)
        and command_is_newer_than_applied_bundle
        and (
            (command_target_version and current_version and command_target_version != current_version)
            or (command_target_sha and current_sha and command_target_sha != current_sha)
        )
    )
    if command_done_mismatch:
        source_issues.append(
            issue(
                "error",
                "storebot_bundle_sync_mismatch",
                f"{name} command는 done이지만 live worker bundle이 target과 다름",
                name,
                {
                    "command_action": command_action,
                    "command_status": command_status,
                    "command_age_min": command_age,
                    "target_version": command_target_version or None,
                    "current_version": current_version or None,
                    "target_sha256": command_target_sha or None,
                    "current_sha256": current_sha or None,
                    "heartbeat_age_min": heartbeat_age,
                    "bundle_status": current_status or None,
                },
            )
        )

    manifest_lag = int(source.get("max_manifest_lag_min") or 0)
    manifest_mismatch = bool(
        manifest_lag > 0
        and manifest_version
        and current_version
        and manifest_version != current_version
        and (applied_age is None or applied_age >= manifest_lag)
    )
    if manifest_mismatch:
        source_issues.append(
            issue(
                "warn",
                "storebot_hosted_bundle_not_adopted",
                f"{name} hosted bundle보다 live worker bundle이 오래됨",
                name,
                {
                    "manifest_version": manifest_version,
                    "current_version": current_version,
                    "manifest_sha256": manifest_sha or None,
                    "current_sha256": current_sha or None,
                    "bundle_applied_age_min": applied_age,
                    "bundle_status": current_status or None,
                },
            )
        )

    return {
        "name": name,
        "ok": not source_issues,
        "status": max_severity(source_issues),
        "current_version": current_version or None,
        "manifest_version": manifest_version or None,
        "command_action": command_action or None,
        "command_status": command_status or None,
        "command_target_version": command_target_version or None,
        "heartbeat_age_min": heartbeat_age,
        "bundle_applied_age_min": applied_age,
    }, source_issues


def is_kakao_screen_ui_noise(claim: dict[str, Any], request: dict[str, Any]) -> bool:
    text = str(
        claim.get("message_preview")
        or request.get("message")
        or request.get("text")
        or request.get("message_preview")
        or ""
    ).strip()
    compact_text = re.sub(r"\s+", "", text)

    sender = str(claim.get("sender") or request.get("sender") or request.get("sender_name") or "").strip()
    transport = str(claim.get("transport") or request.get("transport") or "").lower()
    source = str(request.get("source") or claim.get("source") or "").lower()
    room_name = str(claim.get("room_name") or request.get("room_name") or request.get("roomTitle") or "").strip()
    room_compact = re.sub(r"\s+", "", room_name)
    pseudo_screen_sender = sender in {"카카오화면", "kakao_screen", "screen", "screen_scan"}
    screen_scan_source = (
        "screen_scan" in transport
        or "accessibility_screen" in transport
        or "screen_scan" in source
        or "kakao_screen" in source
    )
    if not pseudo_screen_sender and not (not sender and screen_scan_source):
        return False
    lower_text = compact_text.lower()
    return (
        re.fullmatch(r"\d{1,2}", compact_text) is not None
        or lower_text == "lee"
        or is_decorative_kakao_screen_label(text, compact_text)
        or is_kakao_screen_profile_label(text)
        or (room_compact and compact_text == room_compact)
        or compact_text in KAKAO_SCREEN_UI_TOKENS
    )


KAKAO_SCREEN_UI_TOKENS = {
    "BBQ하이닉스점",
    "BBQSK하이닉스점",
    "BBQ하이닉스점10",
    "공유하기",
    "친구",
    "채팅",
    "오픈채팅",
    "쇼핑",
    "더보기",
}


def is_decorative_kakao_screen_label(text: str, compact_text: str) -> bool:
    if not compact_text or len(compact_text) > 40 or re.search(r"\s", text):
        return False
    if re.search(r"[가-힣]", compact_text):
        return False
    if re.search(r"[A-Za-z]", compact_text) is None:
        return False
    return any(is_decorative_symbol(ch) for ch in compact_text)


def is_decorative_symbol(ch: str) -> bool:
    code = ord(ch)
    return (
        0x1F000 <= code <= 0x1FAFF
        or ch in {"❤", "♥", "♡", "💕", "💖", "💗", "💓", "💞", "💘", "⭐", "★", "☆", "✨"}
    )


def is_kakao_screen_profile_label(text: str) -> bool:
    clean = " ".join(str(text or "").split())
    if not clean or len(clean) > 40:
        return False
    if re.match(r"^[ㄱ-ㅎㅏ-ㅣ]\s+\S+", clean) is None:
        return False
    parts = clean.split()
    if len(parts) < 2 or len(parts) > 4:
        return False
    return all(re.fullmatch(r"[가-힣A-Za-z0-9._+&-]{1,16}", part) is not None for part in parts[1:])


def max_severity(issues: list[dict[str, Any]]) -> str:
    if not issues:
        return "ok"
    return max((str(item.get("severity") or "warn") for item in issues), key=lambda value: SEVERITY_SCORE.get(value, 1))


def safe_diagnostic_mapping(value: Any) -> dict[str, Any]:
    projected = redact_diagnostic_payload(value)
    return projected if isinstance(projected, dict) else {}


def safe_diagnostic_string(key: str, value: Any, fallback: str) -> str:
    projected = safe_diagnostic_mapping({key: value})
    candidate = projected.get(key)
    return str(candidate) if isinstance(candidate, str) and candidate else fallback


def safe_issue_records(value: Any) -> list[dict[str, Any]]:
    raw_issues = value.get("issues") if isinstance(value, dict) else value
    if not isinstance(raw_issues, list):
        return []
    projected = safe_diagnostic_mapping({"issues": raw_issues}).get("issues")
    if not isinstance(projected, list):
        return []
    return [item for item in projected if isinstance(item, dict)]


def issue_key(project: str, issues: Any) -> str:
    safe_issues = safe_issue_records(issues)
    codes = [
        f"{item.get('source')}:{item.get('code')}"
        for item in safe_issues
        if SEVERITY_SCORE.get(str(item.get("severity")), 0) >= 2
    ]
    if not codes:
        codes = [f"{item.get('source')}:{item.get('code')}" for item in safe_issues]
    digest = hashlib.sha1("|".join(sorted(codes)).encode("utf-8")).hexdigest()[:12]
    return f"{sanitize_key(project)}_{digest}"


def sanitize_key(value: str) -> str:
    return "".join(ch if ch.isalnum() or ch in ("_", "-") else "_" for ch in value)[:80] or "unknown"


def self_fix_profile(config: dict[str, Any]) -> str:
    options = self_fix_options(config)
    profile = str(options.get("profile") or DEFAULT_SELF_FIX_PROFILE).strip().lower()
    return profile if profile in {"read_only", "patch", "yolo"} else DEFAULT_SELF_FIX_PROFILE


def self_fix_target_host(config: dict[str, Any]) -> str:
    value = str(self_fix_options(config).get("target_host") or "").strip().lower()
    return value if value in {"subphone", "pc", "any"} else ""


def self_fix_target_node(config: dict[str, Any]) -> str:
    return str(self_fix_options(config).get("target_node") or "").strip()


def self_fix_explicit_pc_cwd(config: dict[str, Any]) -> str:
    options = self_fix_options(config)
    for key in ("pc_cwd", "target_cwd", "cwd"):
        value = str(options.get(key) or "").strip()
        if value:
            return value
    return ""


def self_fix_request_cwd(config: dict[str, Any]) -> str:
    if self_fix_target_host(config) == "pc":
        return self_fix_explicit_pc_cwd(config)
    return str(config.get("cwd") or "/root/my-first-project").strip()


def self_fix_is_read_only(config: dict[str, Any]) -> bool:
    options = self_fix_options(config)
    mode = str(options.get("mode") or "").strip().lower()
    return self_fix_profile(config) == "read_only" or mode == "read_only_diagnosis"


def self_fix_repair_scope(config: dict[str, Any]) -> str:
    options = self_fix_options(config)
    if self_fix_is_read_only(config):
        return str(options.get("repair_scope") or "read_only_diagnosis_only_no_patch_no_write")
    return str(options.get("repair_scope") or "code_config_docs_build_deploy_within_project_safety_boundary")


def self_fix_safety_code(config: dict[str, Any]) -> str:
    domain = safe_diagnostic_string("domain", config.get("domain"), "unknown_domain")
    suffix = "read_only_diagnosis" if self_fix_is_read_only(config) else "project_safety_contract"
    return safe_diagnostic_string("safety_boundary", f"{domain}_{suffix}", "project_safety_contract")


def build_self_fix_task(project: str, config: dict[str, Any], report: dict[str, Any]) -> str:
    safe_project = safe_diagnostic_string("project", project, "unknown_project")
    safe_domain = safe_diagnostic_string("domain", config.get("domain"), "unknown_domain")
    safe_safety = self_fix_safety_code(config)
    target_host = safe_diagnostic_string("target_host", self_fix_target_host(config), "subphone")
    target_node = safe_diagnostic_string("target_node", self_fix_target_node(config), "(auto)")
    profile = safe_diagnostic_string("profile", self_fix_profile(config), DEFAULT_SELF_FIX_PROFILE)
    request_cwd = safe_diagnostic_string("cwd", self_fix_request_cwd(config), "(worker CODEX_OPS_CWD)")
    task_report = safe_diagnostic_mapping(report)
    if target_host == "pc" and not self_fix_explicit_pc_cwd(config) and isinstance(task_report, dict):
        task_report = dict(task_report)
        task_report["cwd"] = "(worker CODEX_OPS_CWD)"
    if self_fix_is_read_only(config):
        mode_notice = (
            "이 요청은 1단계 read_only 진단 라우팅입니다. patch, 로컬 파일 수정, git write, Firebase write, 배포를 시도하지 마세요.\n"
            "PC에서 읽을 수 있는 로그, watchdog, heartbeat, 다운로드/SFA 파일 상태와 재현 증거만 확인하고 다음 조치만 남기세요.\n"
        )
        step3 = "3. 현장 PC 로그/heartbeat/watchdog/SFA 관련 파일을 읽고 실제 장애인지와 막힌 외부 경계를 확인합니다.\n"
        step4 = "4. 직접 교정 대신 필요한 다음 patch 포인터, 현장 조치, 재시작 확인 지점만 짧게 남깁니다.\n"
        step5 = "5. 코드수정이나 배포가 필요해 보여도 이번 단계에서는 실행하지 말고 근거와 다음 담당 단계만 정리합니다.\n"
    else:
        mode_notice = "이 self_fix는 report-only 작업이 아닙니다. 안전 경계 안에서 원인과 수정점이 확인되면 직접 코드/설정/문서 보정과 필요한 빌드/배포까지 시도하세요.\n"
        step3 = "3. 자체 복구가 가능하면 코드/설정/문서/배포 루프를 최소 변경으로 교정합니다.\n"
        step4 = "4. 고위험 원본 데이터나 플랫폼 실행은 앱별 기존 안전 경계를 통과하지 않으면 직접 수행하지 않습니다.\n"
        step5 = "5. 직접 교정이 불가능하면 외부 상태/권한/장비/데이터 경계 중 무엇이 막는지와 다음 복구 명령만 짧게 남깁니다.\n"
    return (
        "공용 AI Ops 상주 모니터가 운영 이상을 감지했습니다.\n"
        "goal mode입니다. 사용자 승인 대기 없이 분석, 복구, 필요한 최소 수정, 검증, 기록까지 이어서 진행하세요.\n"
        f"{mode_notice}"
        "단, destructive reset/checkout/force push/비밀 노출은 금지입니다.\n"
        "관제 파이프라인 자체 오류라면 monitor, worker, start wrapper까지 안전 경계 안에서 최소 수정할 수 있습니다.\n"
        "첫 판단은 AI가 합니다. 앱/worker에 사용자 입력 선분류 하드코딩을 추가하지 마세요.\n"
        f"프로젝트: {safe_project}\n"
        f"domain: {safe_domain}\n"
        f"cwd: {request_cwd}\n"
        f"target_host: {target_host}\n"
        f"target_node: {target_node}\n"
        f"profile: {profile}\n"
        f"안전 경계: {safe_safety}\n"
        "해야 할 일:\n"
        "1. AGENTS.md, CODEX_BRIEF.md, CODEMAP.txt, rules/ai_ops_prompt_contract.txt, 대상 앱 APP_INTENT.md/CODEMAP.txt를 필요한 만큼 확인합니다.\n"
        "2. 아래 증상이 실제 장애인지 코드/Firebase/로그 기준으로 넓게 판단합니다.\n"
        f"{step3}"
        f"{step4}"
        f"{step5}"
        "6. 검증 결과와 남은 위험을 짧게 남깁니다.\n\n"
        "## 감지 리포트 JSON\n"
        f"{json.dumps(task_report, ensure_ascii=False, indent=2, sort_keys=True)}\n"
    )


def self_fix_options(config: dict[str, Any]) -> dict[str, Any]:
    raw = config.get("self_fix")
    return raw if isinstance(raw, dict) else {}


def main_pc_recovery_state(config: dict[str, Any]) -> dict[str, Any]:
    if config.get("domain") not in {"main_pc_sitebot", "orderhelper"}:
        return {"supported": False, "recovered": False}
    heartbeat_source = next(
        (
            source
            for source in (config.get("heartbeats") or [])
            if str(source.get("path") or "") == "/monitor/main_pc/status"
        ),
        None,
    )
    if not isinstance(heartbeat_source, dict):
        return {"supported": False, "recovered": False}
    try:
        main_pc_status = fb_get("/monitor/main_pc/status")
    except Exception as exc:
        return {"supported": True, "recovered": False, "read_error": compact(exc)}
    try:
        watchdog_last = fb_get("/monitor/main_pc/watchdog_last")
    except Exception as exc:
        return {"supported": True, "recovered": False, "read_error": compact(exc)}

    records = child_records(main_pc_status)
    if not records:
        return {"supported": True, "recovered": False, "status": "missing"}
    selected_key, selected = max(records, key=lambda pair: extract_ts_ms(pair[1], pair[0]))
    ts_ms = extract_ts_ms(selected, selected_key)
    max_age = int(heartbeat_source.get("max_age_min") or 10)
    fresh = ts_ms > 0 and now_ms() - ts_ms <= max_age * 60000
    failed_requirements: dict[str, Any] = {}
    for field, expected in (heartbeat_source.get("require") or {}).items():
        value = get_field(selected, field)
        if not requirement_ok(value, expected):
            failed_requirements[field] = {"actual": value, "expected": expected}
    watchdog_ts = extract_ts_ms(watchdog_last) if isinstance(watchdog_last, dict) else 0
    watchdog_age = age_min(watchdog_ts)
    watchdog_text = status_text(watchdog_last) if isinstance(watchdog_last, dict) else ""
    watchdog_failed = any(token in watchdog_text.lower() for token in ("error", "fail", "stale"))
    recovered = fresh and not failed_requirements and not watchdog_failed
    return {
        "supported": True,
        "recovered": recovered,
        "main_pc_ts": ts_ms,
        "main_pc_age_min": age_min(ts_ms),
        "watchdog_ts": watchdog_ts,
        "watchdog_age_min": watchdog_age,
        "watchdog_status": watchdog_text,
        "failed_requirements": failed_requirements,
    }


def clear_recovered_self_fix_state(
    project: str,
    config: dict[str, Any],
    report: dict[str, Any],
    dry_run: bool,
) -> dict[str, Any] | None:
    if SEVERITY_SCORE.get(str(report.get("severity") or "ok"), 0) > 0:
        return None
    recovery = main_pc_recovery_state(config)
    if not recovery.get("supported") or not recovery.get("recovered"):
        return None
    project_state_path = f"{SELF_FIX_STATE_PATH}/{sanitize_key(project)}"
    try:
        previous = fb_get(project_state_path)
    except Exception as exc:
        return {"status": "read_error", "path": project_state_path, "error": compact(exc)}
    if not isinstance(previous, dict) or not previous:
        return None
    if dry_run:
        return {
            "status": "dry_run",
            "path": project_state_path,
            "main_pc_age_min": recovery.get("main_pc_age_min"),
            "watchdog_age_min": recovery.get("watchdog_age_min"),
        }
    fb_put(project_state_path, None)
    return {
        "status": "cleared",
        "path": project_state_path,
        "main_pc_age_min": recovery.get("main_pc_age_min"),
        "watchdog_age_min": recovery.get("watchdog_age_min"),
    }


def issue_codes(report: Any, min_severity: str = "warn") -> list[str]:
    threshold = SEVERITY_SCORE.get(min_severity, 1)
    codes = []
    for item in safe_issue_records(report):
        severity = str(item.get("severity") or "warn")
        if SEVERITY_SCORE.get(severity, 1) < threshold:
            continue
        codes.append(f"{item.get('source')}:{item.get('code')}")
    return codes


def self_fix_evidence(project: str, config: dict[str, Any], report: dict[str, Any], checked_at_ms: int) -> dict[str, Any]:
    safe_report = safe_diagnostic_mapping(report)
    safe_issues = safe_issue_records(safe_report)
    safe_project = safe_diagnostic_string("project", project, "unknown_project")
    safe_domain = safe_diagnostic_string("domain", config.get("domain"), sanitize_key(safe_project))
    issues = []
    for item in safe_issues[:8]:
        issues.append(
            {
                "severity": str(item.get("severity") or ""),
                "code": str(item.get("code") or ""),
                "source": str(item.get("source") or ""),
            }
        )
    return {
        "project": safe_project,
        "domain": safe_domain,
        "monitor_path": AI_OPS_BASE_PATH,
        "report_path": f"{PROJECTS_PATH}/{sanitize_key(safe_project)}/latest",
        "checked_at_ms": int(safe_report.get("checked_at_ms") or checked_at_ms),
        "severity": safe_report.get("severity"),
        "issue_count": len(safe_issues),
        "issue_codes": issue_codes(safe_report),
        "error_issue_codes": issue_codes(safe_report, "error"),
        "issues": issues,
    }


def enqueue_self_fix(
    project: str,
    config: dict[str, Any],
    report: dict[str, Any],
    cooldown_min: int,
    dry_run: bool,
) -> dict[str, Any]:
    safe_report = safe_diagnostic_mapping(report)
    safe_issues = safe_issue_records(safe_report)
    safe_project = safe_diagnostic_string("project", project, "unknown_project")
    safe_domain = safe_diagnostic_string("domain", config.get("domain"), sanitize_key(safe_project))
    key = issue_key(safe_project, safe_issues)
    state_path = f"{SELF_FIX_STATE_PATH}/{sanitize_key(safe_project)}/{key}"
    previous = {}
    try:
        previous = fb_get(state_path) or {}
    except Exception:
        previous = {}
    last_enqueued = int(previous.get("last_enqueued_at_ms") or 0) if isinstance(previous, dict) else 0
    last_request_id = str(previous.get("last_request_id") or "") if isinstance(previous, dict) else ""
    previous_status = ""
    previous_finished = 0
    if last_request_id:
        try:
            previous_request = fb_get(f"{CODEX_OPS_REQUESTS_PATH}/{last_request_id}") or {}
            if isinstance(previous_request, dict):
                previous_status = str(previous_request.get("status") or "")
                previous_finished = int(previous_request.get("finished_at_ms") or 0)
        except Exception:
            previous_status = ""
    if previous_status in PAUSED_EXTERNAL_REQUEST_STATUSES:
        return {
            "status": previous_status,
            "issue_key": key,
            "last_enqueued_at_ms": last_enqueued,
            "last_request_id": last_request_id,
        }
    if last_enqueued and now_ms() - last_enqueued < cooldown_min * 60000:
        retry_after_error_ms = 5 * 60000
        if previous_status == "error" and now_ms() - (previous_finished or last_enqueued) > retry_after_error_ms:
            pass
        else:
            return {"status": "cooldown", "issue_key": key, "last_enqueued_at_ms": last_enqueued, "last_request_id": last_request_id}

    created_at = now_ms()
    req_id = f"ops_ai_{created_at}_{secrets.token_hex(4)}"
    options = self_fix_options(config)
    timeout_sec = int(options.get("timeout_sec") or DEFAULT_SELF_FIX_TIMEOUT_SEC)
    ttl_ms = int(options.get("ttl_ms") or DEFAULT_SELF_FIX_TTL_MS)
    profile = self_fix_profile(config)
    target_host = self_fix_target_host(config)
    target_node = self_fix_target_node(config)
    read_only = self_fix_is_read_only(config)
    request_cwd = self_fix_request_cwd(config)
    safe_task = build_self_fix_task(safe_project, config, safe_report)
    payload = {
        "status": "pending",
        "source": "ai_ops_common_monitor",
        "requester": "ai_ops_monitor",
        "is_owner": True,
        "project": safe_project,
        "domain": safe_domain,
        "profile": profile,
        "model": options.get("model") or DEFAULT_SELF_FIX_MODEL,
        "reasoning_effort": options.get("reasoning_effort") or DEFAULT_SELF_FIX_REASONING_EFFORT,
        "timeout_sec": timeout_sec,
        "created_at_ms": created_at,
        "ttl_ms": ttl_ms,
        "bypass_adb": True,
        "bypass_kakao": True,
        "reply_target": {"type": "firebase_result", "kakao_publish": False},
        "monitor_issue_key": key,
        "detected_severity": safe_report.get("severity"),
        "detected_issue_codes": issue_codes(safe_report),
        "detected_error_issue_codes": issue_codes(safe_report, "error"),
        "evidence": self_fix_evidence(safe_project, config, safe_report, created_at),
        "safety_boundary": self_fix_safety_code(config),
        "auto_coding_allowed": not read_only,
        "must_attempt_repair": not read_only,
        "repair_scope": self_fix_repair_scope(config),
    }
    if request_cwd:
        payload["cwd"] = request_cwd
    if target_host:
        payload["target_host"] = target_host
    if target_node:
        payload["target_node"] = target_node
    if read_only:
        payload["route_stage"] = "pc_read_only_diagnosis_v1"
    payload = safe_diagnostic_mapping(payload)
    # The task is generated only from static instructions, validated enum/path
    # fields, and the strict report projection above. Arbitrary task text is not
    # accepted by diagnostic_redaction itself.
    payload["task"] = safe_task
    if not dry_run:
        fb_put(f"{CODEX_OPS_REQUESTS_PATH}/{req_id}", payload)
        fb_put(
            state_path,
            {
                "issue_key": key,
                "last_enqueued_at_ms": created_at,
                "last_request_id": req_id,
                "project": safe_project,
                "severity": safe_report.get("severity"),
                "issue_count": len(safe_issues),
            },
        )
    return {"status": "enqueued" if not dry_run else "dry_run", "issue_key": key, "request_id": req_id}


def posdelay_runtime_issue_key(report: dict[str, Any]) -> str:
    codes: list[str] = []
    raw_issues = report.get("issues")
    for item in raw_issues if isinstance(raw_issues, list) else []:
        if not isinstance(item, dict):
            continue
        details = item.get("details") if isinstance(item.get("details"), dict) else {}
        for code in details.get("runtime_issue_codes") or []:
            if code in POSDELAY_RUNTIME_ISSUE_CODES:
                codes.append(code)
        code = str(item.get("code") or "")
        if code in POSDELAY_RUNTIME_ISSUE_CODES:
            codes.append(code)
    if not codes:
        return ""
    digest = hashlib.sha1("|".join(sorted(set(codes))).encode("utf-8")).hexdigest()[:12]
    return f"posdelay_runtime_{digest}"


def pre_self_heal_posdelay_runtime(report: dict[str, Any], dry_run: bool) -> dict[str, Any] | None:
    key = posdelay_runtime_issue_key(report)
    if not key:
        return None
    previous: dict[str, Any] = {}
    try:
        raw = fb_get(POSDELAY_RUNTIME_SELF_HEAL_PATH) or {}
        previous = raw if isinstance(raw, dict) else {}
    except Exception:
        previous = {}

    last_key = str(previous.get("issue_key") or "")
    last_command_at = int(previous.get("last_command_at_ms") or 0)
    if last_key == key and last_command_at:
        age_ms = now_ms() - last_command_at
        if age_ms < POSDELAY_RUNTIME_SELF_HEAL_COOLDOWN_MIN * 60000:
            return {
                "status": "cooldown",
                "issue_key": key,
                "last_command_at_ms": last_command_at,
                "cooldown_min": POSDELAY_RUNTIME_SELF_HEAL_COOLDOWN_MIN,
            }
        return {
            "status": "persisted_after_pre_self_heal",
            "issue_key": key,
            "last_command_at_ms": last_command_at,
            "cooldown_min": POSDELAY_RUNTIME_SELF_HEAL_COOLDOWN_MIN,
        }

    created_at = now_ms()
    command = {
        "action": "recover_runtime",
        "time": created_at,
        "source": "ai_ops_common_monitor",
        "issue_key": key,
    }
    if not dry_run:
        fb_put(POSDELAY_CMD_PATH, command)
        fb_put(
            POSDELAY_RUNTIME_SELF_HEAL_PATH,
            {
                "issue_key": key,
                "last_command_at_ms": created_at,
                "command": "recover_runtime",
                "command_path": POSDELAY_CMD_PATH,
                "source": "ai_ops_common_monitor",
            },
        )
    return {
        "status": "commanded" if not dry_run else "dry_run",
        "issue_key": key,
        "command": "recover_runtime",
        "command_path": POSDELAY_CMD_PATH,
    }


def evaluate_project(project: str, config: dict[str, Any]) -> dict[str, Any]:
    issues: list[dict[str, Any]] = []
    heartbeats = []
    queues = []
    single_requests = []
    status_checks = []
    kakao_reply_flows = []
    bundle_sync_checks = []
    events = []
    local_json_checks = []
    metric_checks = []
    consistency_checks = []
    data_quality_checks = []
    for source in config.get("heartbeats") or []:
        summary, found = evaluate_heartbeat(source)
        heartbeats.append(summary)
        issues.extend(found)
    for source in config.get("queues") or []:
        summary, found = evaluate_queue(source)
        queues.append(summary)
        issues.extend(found)
    for source in config.get("single_requests") or []:
        summary, found = evaluate_single_request(source)
        single_requests.append(summary)
        issues.extend(found)
    for source in config.get("status_checks") or []:
        summary, found = evaluate_status_check(source)
        status_checks.append(summary)
        issues.extend(found)
    for source in config.get("kakao_reply_flows") or []:
        summary, found = evaluate_kakao_reply_flow(source)
        kakao_reply_flows.append(summary)
        issues.extend(found)
    for source in config.get("bundle_sync_checks") or []:
        summary, found = evaluate_bundle_sync_check(source)
        bundle_sync_checks.append(summary)
        issues.extend(found)
    for source in config.get("events") or []:
        summary, found = evaluate_events(source)
        events.append(summary)
        issues.extend(found)
    for source in config.get("local_json_checks") or []:
        summary, found = evaluate_local_json_check(source)
        local_json_checks.append(summary)
        issues.extend(found)
    for source in config.get("metric_checks") or []:
        summary, found = evaluate_metric_check(source)
        metric_checks.append(summary)
        issues.extend(found)
    for source in config.get("consistency_checks") or []:
        summary, found = evaluate_consistency_check(source)
        consistency_checks.append(summary)
        issues.extend(found)
    if config.get("domain") == "storebot_kakao":
        summary, found = evaluate_storebot_briefing_freshness()
        data_quality_checks.append(summary)
        issues.extend(found)
    if config.get("domain") == "posdelay":
        summary, found = evaluate_posdelay_pc_recovery_context()
        data_quality_checks.append(summary)
        issues.extend(found)
        summary, found = evaluate_posdelay_runtime_health()
        data_quality_checks.append(summary)
        issues.extend(found)
    if config.get("domain") == "orderhelper":
        summary, found = evaluate_orderhelper_quality()
        data_quality_checks.append(summary)
        issues.extend(found)
    severity = max_severity(issues)
    return {
        "project": project,
        "domain": config.get("domain"),
        "cwd": config.get("cwd"),
        "ok": severity in {"ok", "info"},
        "severity": severity,
        "summary": "ok" if not issues else "; ".join(compact(item.get("message"), 80) for item in issues[:4]),
        "issues": issues,
        "heartbeats": heartbeats,
        "queues": queues,
        "single_requests": single_requests,
        "status_checks": status_checks,
        "kakao_reply_flows": kakao_reply_flows,
        "bundle_sync_checks": bundle_sync_checks,
        "events": events,
        "local_json_checks": local_json_checks,
        "metric_checks": metric_checks,
        "consistency_checks": consistency_checks,
        "data_quality_checks": data_quality_checks,
    }


def write_monitor_heartbeat(args: argparse.Namespace, status: str, project_count: int, issue_count: int) -> None:
    safe_node = safe_diagnostic_string("node", args.node, "unknown_node")
    payload = {
        "node": safe_node,
        "status": status,
        "ts": now_ms(),
        "checked_at_kst": kst_text(),
        "pid": os.getpid(),
        "project_count": project_count,
        "issue_count": issue_count,
        "self_fix_enabled": args.self_fix,
        "interval_sec": args.interval_sec,
        "monitor_started_at_ms": args.monitor_started_at_ms,
        "code_revision": args.code_revision,
        "script_mtime_ms": args.script_mtime_ms,
    }
    fb_put(f"{HEARTBEAT_PATH}/{sanitize_key(safe_node)}", safe_diagnostic_mapping(payload))


def selected_projects(names: list[str]) -> dict[str, dict[str, Any]]:
    if not names:
        return PROJECT_CONFIGS
    selected = {}
    for name in names:
        if name not in PROJECT_CONFIGS:
            raise SystemExit(f"unknown project: {name}. choices={', '.join(PROJECT_CONFIGS)}")
        selected[name] = PROJECT_CONFIGS[name]
    return selected


def run_posdelay_ca_external_projection(node: str) -> dict[str, Any]:
    """Run PosDelay source polling only on an external serverphone/factory worker."""

    worker_node = str(node or "").strip()
    if worker_node not in POSDELAY_CA_EXTERNAL_NODES:
        return {"status": "blocked_non_external_node", "node": worker_node}
    try:
        import telegram_openclaw_codex_gate as telegram_gate

        return telegram_gate.project_posdelay_ca_once()
    except Exception as exc:
        return {"status": "error", "error": compact(exc, 240), "node": worker_node}


def storebot_ca_broadcast_check_from_report(report: dict[str, Any]) -> dict[str, Any] | None:
    """Return the exact current-broadcast monitor check, never a sibling diagnostic."""

    checks = report.get("data_quality_checks")
    if not isinstance(checks, list):
        return None
    for check in checks:
        if not isinstance(check, dict):
            continue
        if (
            check.get("name") != "work_schedule_broadcast_state"
            or check.get("contract") != "work_schedule_broadcast_v2"
            or check.get("path") != STOREBOT_WORK_SCHEDULE_BROADCAST_STATE_PATH
        ):
            continue
        return check
    return None


def storebot_ca_projection_input_from_report(report: dict[str, Any]) -> dict[str, Any] | None:
    """Extract only the typed current-broadcast projection packet.

    The monitor report can contain raw diagnostic context.  None of that
    context crosses into the CA producer; only the exact model-0 packet built
    by ``evaluate_storebot_briefing_freshness`` is forwarded.
    """

    check = storebot_ca_broadcast_check_from_report(report)
    packet = check.get("ca_projection_input") if isinstance(check, dict) else None
    return dict(packet) if isinstance(packet, dict) else None


def storebot_ca_schedule_recovery_allowed_from_report(report: dict[str, Any]) -> bool:
    check = storebot_ca_broadcast_check_from_report(report)
    if not isinstance(check, dict):
        return False
    return bool(
        check.get("ca_schedule_recovery_enabled") is True
        and check.get("recovery_paused") is False
        and check.get("ca_recovery_status") in {"ready", "not_required"}
    )


def run_storebot_ca_external_projection(
    node: str,
    projection_input: dict[str, Any] | None,
    *,
    schedule_recovery_allowed: bool,
    dry_run: bool,
) -> dict[str, Any]:
    """Run the typed CA producer only on the physical external-worker lanes."""

    worker_node = str(node or "").strip()
    if dry_run:
        return {"status": "blocked_dry_run", "node": worker_node}
    if worker_node not in STOREBOT_CA_EXTERNAL_NODES:
        return {"status": "blocked_non_external_node", "node": worker_node}
    try:
        import telegram_openclaw_codex_gate as telegram_gate

        return telegram_gate.project_storebot_ca_once(
            ca_projection_input=projection_input,
            ca_schedule_recovery_allowed=bool(schedule_recovery_allowed),
        )
    except Exception as exc:
        return {"status": "error", "error": compact(exc, 240), "node": worker_node}


def run_project_ca_after_monitor_cycle(
    args: argparse.Namespace,
    project_names: list[str],
    *,
    upload_completed: bool,
) -> dict[str, Any]:
    """Project the complete monitor snapshot only from an eligible external cycle."""

    worker_node = str(args.node or "").strip()
    base_status = {"node": worker_node, "no_send": True}
    if os.environ.get("PROJECT_CA_PROJECTION_ENABLED", "0") != "1":
        return {**base_status, "status": "disabled"}
    if os.environ.get("PROJECT_CA_KILL_SWITCH", "0") == "1":
        return {**base_status, "status": "disabled_kill_switch"}
    if bool(args.dry_run):
        return {**base_status, "status": "blocked_dry_run"}
    if bool(args.no_upload):
        return {**base_status, "status": "blocked_no_upload"}
    if len(project_names) != len(PROJECT_CONFIGS) or set(project_names) != set(PROJECT_CONFIGS):
        return {**base_status, "status": "blocked_subset"}
    if worker_node in PROJECT_CA_PERSONAL_NODES:
        return {**base_status, "status": "blocked_personal_node"}
    if worker_node not in PROJECT_CA_EXTERNAL_NODES:
        return {**base_status, "status": "blocked_non_external_node"}
    if not upload_completed:
        return {**base_status, "status": "blocked_upload_incomplete"}
    try:
        import telegram_openclaw_codex_gate as telegram_gate

        projection_status = telegram_gate.project_generic_ca_once()
        if not isinstance(projection_status, dict):
            projection_status = {"status": "invalid_result", "no_send": True}
        return safe_diagnostic_mapping(projection_status)
    except Exception as exc:
        candidate_reason = str(getattr(exc, "reason_code", "") or "")
        reason_code = (
            candidate_reason
            if candidate_reason in PROJECT_CA_SAFE_FAILURE_REASONS
            else "project_ca_projection_error"
        )
        return safe_diagnostic_mapping(
            {
                **base_status,
                "status": "error",
                "reason_code": reason_code,
                "exception_type": type(exc).__name__,
            }
        )


def run_once(args: argparse.Namespace) -> dict[str, Any]:
    configs = selected_projects(args.project)
    reports: dict[str, Any] = {}
    self_fix_results: dict[str, Any] = {}
    for project, config in configs.items():
        report = evaluate_project(project, config)
        pre_self_heal = None
        recovery_clear = clear_recovered_self_fix_state(project, config, report, args.dry_run)
        if recovery_clear:
            report["recovery_clear"] = recovery_clear
        if config.get("domain") == "storebot_kakao":
            report["ca_projection"] = run_storebot_ca_external_projection(
                args.node,
                storebot_ca_projection_input_from_report(report),
                schedule_recovery_allowed=storebot_ca_schedule_recovery_allowed_from_report(report),
                dry_run=bool(args.dry_run),
            )
        if config.get("domain") == "posdelay":
            report["ca_projection"] = run_posdelay_ca_external_projection(args.node)
            pre_self_heal = pre_self_heal_posdelay_runtime(report, args.dry_run)
            if pre_self_heal:
                report["pre_self_heal"] = pre_self_heal
        threshold_score = SEVERITY_SCORE.get(args.self_fix_threshold, 2)
        if args.self_fix and SEVERITY_SCORE.get(report["severity"], 0) >= threshold_score:
            if pre_self_heal and pre_self_heal.get("status") in {"commanded", "cooldown", "dry_run"}:
                report["self_fix"] = {
                    "status": "deferred_pre_self_heal",
                    "issue_key": pre_self_heal.get("issue_key"),
                    "pre_self_heal_status": pre_self_heal.get("status"),
                }
            else:
                report["self_fix"] = enqueue_self_fix(project, config, report, args.cooldown_min, args.dry_run)
            self_fix_results[project] = report["self_fix"]
        reports[project] = report

    issue_count = sum(len(safe_issue_records(report)) for report in reports.values())
    result = {
        "checked_at_ms": now_ms(),
        "checked_at_kst": kst_text(),
        "node": args.node,
        "ok": all(report.get("ok") for report in reports.values()),
        "severity": max((report.get("severity", "ok") for report in reports.values()), key=lambda value: SEVERITY_SCORE.get(value, 0)),
        "project_count": len(reports),
        "issue_count": issue_count,
        "self_fix_enabled": args.self_fix,
        "self_fix_results": self_fix_results,
        "projects": reports,
    }
    safe_result = safe_diagnostic_mapping(result)
    upload_completed = False
    if not args.no_upload and not args.dry_run:
        fb_put(OUT_PATH, safe_result)
        for project, report in safe_result["projects"].items():
            fb_put(f"{PROJECTS_PATH}/{sanitize_key(project)}/latest", report)
        write_monitor_heartbeat(args, "idle", len(reports), issue_count)
        upload_completed = True
    elif not args.no_upload:
        try:
            write_monitor_heartbeat(args, "dry_run", len(reports), issue_count)
        except Exception:
            pass
    project_ca_status = safe_diagnostic_mapping(
        run_project_ca_after_monitor_cycle(
            args,
            list(configs),
            upload_completed=upload_completed,
        )
    )
    safe_result["project_ca_projection"] = project_ca_status
    if upload_completed:
        fb_put(f"{OUT_PATH}/project_ca_projection", project_ca_status)
    return safe_result


def print_result(result: dict[str, Any]) -> None:
    print(f"ai_ops_monitor {result['severity'].upper()} projects={result['project_count']} issues={result['issue_count']}")
    for project, report in result["projects"].items():
        issue_labels = [
            f"{item.get('source')}:{item.get('code')}"
            for item in safe_issue_records(report)[:4]
        ]
        structured_summary = ",".join(issue_labels) if issue_labels else "ok"
        print(f"{project}: {report['severity']} - {structured_summary}")
        self_fix = report.get("self_fix")
        if self_fix:
            print(f"  self_fix={self_fix.get('status')} key={self_fix.get('issue_key')} request={self_fix.get('request_id') or ''}".rstrip())
    sys.stdout.flush()


def parse_args(argv: list[str]) -> argparse.Namespace:
    parser = argparse.ArgumentParser(description="공용 AI Ops 상주 모니터")
    parser.add_argument("--project", action="append", default=[], help="CoreOps, SolNote, StoreBot, DeliveryHelper, PosDelay, BankTotal, MainPC, OrderHelper 중 선택. 반복 지정 가능")
    parser.add_argument("--once", action="store_true")
    parser.add_argument("--watch", action="store_true")
    parser.add_argument("--interval-sec", type=int, default=int(os.environ.get("AI_OPS_MONITOR_INTERVAL_SEC", "300")))
    parser.add_argument("--cooldown-min", type=int, default=int(os.environ.get("AI_OPS_SELF_FIX_COOLDOWN_MIN", "360")))
    parser.add_argument("--self-fix-threshold", choices=["warn", "error", "critical"], default=os.environ.get("AI_OPS_SELF_FIX_THRESHOLD", "error"))
    parser.add_argument("--self-fix", action=argparse.BooleanOptionalAction, default=os.environ.get("AI_OPS_SELF_FIX", "0") == "1")
    parser.add_argument("--no-upload", action="store_true")
    parser.add_argument("--dry-run", action="store_true")
    parser.add_argument("--strict", action="store_true", help="issue가 있으면 non-zero 종료")
    parser.add_argument("--node", default=os.environ.get("AI_OPS_MONITOR_NODE", "subphone_ai_ops_monitor"))
    args = parser.parse_args(argv)
    args.monitor_started_at_ms = now_ms()
    args.code_revision = current_git_revision()
    args.script_mtime_ms = file_mtime_ms(__file__)
    if not args.watch and not args.once:
        args.once = True
    return args


def main(argv: list[str]) -> int:
    args = parse_args(argv)
    while True:
        try:
            result = run_once(args)
            print_result(result)
        except Exception as exc:
            result = safe_diagnostic_mapping({
                "checked_at_ms": now_ms(),
                "checked_at_kst": kst_text(),
                "node": args.node,
                "ok": False,
                "severity": "error",
                "project_count": 0,
                "issue_count": 1,
                "exception_type": type(exc).__name__,
                "reason_code": "monitor_exception",
            })
            print(json.dumps(result, ensure_ascii=False, indent=2), file=sys.stderr)
            if not args.no_upload and not args.dry_run:
                try:
                    fb_put(OUT_PATH, result)
                    write_monitor_heartbeat(args, "error", 0, 1)
                except Exception:
                    pass
            if not args.watch:
                return 2
        if not args.watch:
            return 0 if (not args.strict or result.get("ok")) else 2
        time.sleep(max(60, args.interval_sec))


if __name__ == "__main__":
    raise SystemExit(main(sys.argv[1:]))
