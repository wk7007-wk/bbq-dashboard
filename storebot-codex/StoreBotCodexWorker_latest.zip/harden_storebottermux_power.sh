#!/usr/bin/env bash
set -euo pipefail

ADB="${ADB:-adb}"
SERIAL="${ANDROID_SERIAL:-}"
PACKAGE="${STOREBOT_TERMUX_PACKAGE:-com.sbotux}"
GLOBAL_HARDEN="${STOREBOT_TERMUX_GLOBAL_HARDEN:-1}"

usage() {
  cat <<'EOF'
Usage: harden_storebottermux_power.sh [--serial SERIAL] [--package PACKAGE] [--no-global]

Applies server-phone survival settings for StoreBotTermux:
- deviceidle whitelist and standby bucket active
- background/foreground/wakelock appops allow
- WRITE_SECURE_SETTINGS grant and WRITE_SETTINGS appop allow
- accessibility and notification listener merge
- stay awake while charging, battery saver off, rotation lock, long screen timeout
- starts foreground service and StoreBot worker repair/start broadcasts
EOF
}

while [ "$#" -gt 0 ]; do
  case "$1" in
    -s|--serial)
      SERIAL="${2:-}"
      shift 2
      ;;
    --package)
      PACKAGE="${2:-}"
      shift 2
      ;;
    --no-global)
      GLOBAL_HARDEN=0
      shift
      ;;
    -h|--help)
      usage
      exit 0
      ;;
    *)
      echo "Unknown argument: $1" >&2
      usage >&2
      exit 2
      ;;
  esac
done

if [ -z "$PACKAGE" ]; then
  echo "Package is empty" >&2
  exit 2
fi

ADB_CMD=("$ADB")
if [ -n "$SERIAL" ]; then
  ADB_CMD+=("-s" "$SERIAL")
fi

log() {
  printf '[storebot-harden] %s\n' "$*"
}

run_adb() {
  log "adb $*"
  "${ADB_CMD[@]}" "$@" || log "ignored failure: adb $*"
}

shell() {
  run_adb shell "$@"
}

remote_shell_quote() {
  local value="$1"
  value="${value//\'/\'\\\'\'}"
  printf "'%s'" "$value"
}

get_setting() {
  local namespace="$1"
  local key="$2"
  "${ADB_CMD[@]}" shell settings get "$namespace" "$key" 2>/dev/null | tr -d '\r' || true
}

put_setting() {
  local namespace="$1"
  local key="$2"
  local value="$3"
  run_adb shell "settings put $(remote_shell_quote "$namespace") $(remote_shell_quote "$key") $(remote_shell_quote "$value")"
}

merge_colon_setting() {
  local namespace="$1"
  local key="$2"
  local add_value="$3"
  local drop_prefix="${4:-}"
  local current next part found

  current="$(get_setting "$namespace" "$key")"
  if [ "$current" = "null" ]; then
    current=""
  fi
  next=""
  found=0
  IFS=':' read -r -a parts <<< "$current"
  for part in "${parts[@]}"; do
    [ -n "$part" ] || continue
    if [ -n "$drop_prefix" ] && [[ "$part" == "$drop_prefix"* ]]; then
      continue
    fi
    if [ "$part" = "$add_value" ]; then
      found=1
    fi
    if [ -z "$next" ]; then
      next="$part"
    else
      next="$next:$part"
    fi
  done
  if [ "$found" = "0" ]; then
    if [ -z "$next" ]; then
      next="$add_value"
    else
      next="$next:$add_value"
    fi
  fi
  put_setting "$namespace" "$key" "$next"
}

log "waiting for adb device package=$PACKAGE serial=${SERIAL:-default}"
run_adb wait-for-device

log "granting privileged settings where shell is allowed"
shell pm grant "$PACKAGE" android.permission.WRITE_SECURE_SETTINGS
shell pm grant "$PACKAGE" android.permission.POST_NOTIFICATIONS
shell appops set "$PACKAGE" WRITE_SETTINGS allow
shell appops set "$PACKAGE" SYSTEM_ALERT_WINDOW allow
shell appops set "$PACKAGE" REQUEST_INSTALL_PACKAGES allow
shell appops set "$PACKAGE" WAKE_LOCK allow
shell appops set "$PACKAGE" RUN_IN_BACKGROUND allow
shell appops set "$PACKAGE" RUN_ANY_IN_BACKGROUND allow
shell appops set "$PACKAGE" START_FOREGROUND allow
shell appops set "$PACKAGE" SCHEDULE_EXACT_ALARM allow
shell appops set "$PACKAGE" POST_NOTIFICATION allow

log "removing app from idle and standby throttles"
shell cmd package set-stopped --user 0 "$PACKAGE" false
shell cmd deviceidle whitelist +"$PACKAGE"
shell cmd deviceidle tempwhitelist -d 86400000 "$PACKAGE"
shell am set-standby-bucket "$PACKAGE" active
shell cmd usagestats set-standby-bucket "$PACKAGE" active
shell cmd usagestats set-app-standby-bucket "$PACKAGE" active

log "applying power/display settings"
put_setting global low_power 0
put_setting global stay_on_while_plugged_in 7
put_setting system screen_off_timeout 1800000
put_setting system accelerometer_rotation 0
put_setting system user_rotation 0
if [ "$GLOBAL_HARDEN" = "1" ]; then
  put_setting global app_standby_enabled 0
  put_setting global adaptive_battery_management_enabled 0
fi

log "merging accessibility and notification listener settings"
merge_colon_setting \
  secure \
  enabled_accessibility_services \
  "$PACKAGE/com.sbotux.app.StoreBotTermuxAccessibilityService" \
  "com.storebot.app/"
put_setting secure accessibility_enabled 1
merge_colon_setting \
  secure \
  enabled_notification_listeners \
  "$PACKAGE/com.sbotux.app.StoreBotTermuxNotificationService"

log "starting StoreBotTermux foreground service and worker"
shell am start -n "$PACKAGE/.app.TermuxActivity"
shell am start-foreground-service -n "$PACKAGE/.app.TermuxService" -a "$PACKAGE.service_wake_lock"
shell am broadcast -n "$PACKAGE/.app.StoreBotTermuxOpsReceiver" -a com.sbotux.STOREBOT_REPAIR_ACCESSIBILITY
shell am broadcast -n "$PACKAGE/.app.StoreBotTermuxOpsReceiver" -a com.sbotux.STOREBOT_START_WORKER

log "status snapshot"
shell dumpsys deviceidle whitelist | grep -F "$PACKAGE"
shell appops get "$PACKAGE" RUN_IN_BACKGROUND RUN_ANY_IN_BACKGROUND START_FOREGROUND WAKE_LOCK SCHEDULE_EXACT_ALARM
shell settings get global stay_on_while_plugged_in
shell settings get system screen_off_timeout
shell dumpsys activity services "$PACKAGE" | grep -E "TermuxService|foreground|fg" | head -40

log "done"
