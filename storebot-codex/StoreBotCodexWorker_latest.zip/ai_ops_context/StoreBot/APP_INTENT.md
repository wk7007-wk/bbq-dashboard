<!-- source: /root/StoreBot/APP_INTENT.md -->
# StoreBot APP_INTENT.md

## 만든 이유
- 카카오 운영방에서 근무, 내점, 물류, 운영 응답을 자동 처리해 사용자의 반복 확인을 줄인다.

## 사용자 결과
- 필요한 메시지는 빠지지 않고, 불필요한 답장은 줄어야 한다.
- 근무, 내점, 물류는 실제 처리 결과와 기록으로 남아야 한다.

## 기본 로직 의도
- StoreBot은 키워드 명령봇이 아니라 카카오 운영방 자연어를 Codex 판단 세션으로 안전하게 운반하는 카카오 입출력/실행 브리지다.
- 최종 사용자 경험은 카카오 운영방이 프롬프트 입력창처럼 동작하는 것이다. 사용자는 카카오에 자연어로 묻고, StoreBotTermux가 방 단위 Codex 세션으로 문맥을 이어 넘기며, Codex가 답변/출력/action을 만들고 StoreBotTermux가 카톡으로 다시 발송한다.
- 대화 맥락의 기준은 Termux 터미널 프로세스가 아니라 `room_id` 단위 세션 상태다. worker self-sync나 재시작이 있어도 앱/Firebase의 최근 대화, 학습, runtime guidance를 다시 붙여 같은 방의 이어진 대화처럼 처리하는 방향이 최종 의도다.
- 새 Codex 세션으로 갈리는 것은 허용되지만, 사용자가 `그게 아니라`, `그거 말고`, `다른 것`처럼 직전 답변을 교정하는 문장은 반드시 직전 StoreBot 답변과 작업 결과를 함께 보고 해석해야 한다. 반복 가능한 선호/출력 기준은 `guidance.add_rule`로 저장해 다음 답변에도 반영한다.
- Codex 브리지 기본 처리 순서는 `수신 안정성/권한 확인 → 원문 없는 로컬 하드가드 → 앱 내장 worker 큐 저장 → Codex 답변/SKIP/action → StoreBot 카톡 출력 → Firebase 미러/누락보존`이다.
- 로컬 하드가드는 의미를 해석하지 않는다. 자기 메시지, 빈값, 완전 중복, 명백한 리액션, 권한/역할 불일치처럼 해석 없이 확정 가능한 것만 막는다.
- worker 판단력 의존은 절대 금지다. worker/App/monitor/codex_ops는 자연어 의미, 업무 여부, 답변/SKIP, action/domain/slot을 판단하지 않는다. worker는 prompt envelope 운반, 세션 유지, 명시 JSON 계약 검증/실행, DB 조회, 이미지 payload, 미러링만 맡는다.
- `fast_router`는 worker 내부 자연어 라우터가 아니라 Codex 세션 resume 경로 이름이다. Codex/스킬이 낸 구조화 출력 없이 regex, 키워드, 로컬 휴리스틱, fallback worker 판단으로 자연어 업무를 처리하면 실패다.
- Codex 브리지가 켜진 운영방에서 자연어 판단, 출력, 학습 기준은 Codex가 맡는다. 앱/터미널 통합은 Codex 실행 환경을 안정화하는 뜻이지 Gemini/Groq/로컬 action runner가 메인 판단자를 대체하는 뜻이 아니다.
- 자연어 의미 분류는 StoreBot 로컬 정규식보다 Codex 판단을 우선한다. 특히 근무/주소/주문/물류/결제/내점 가능성이 있는 문장은 짧거나 오타가 있어도 Codex까지 도달해야 한다.
- 운영방 1개 기준으로 StoreBotTermux가 카카오 알림 RemoteInput 답장 액션을 잡아 같은 서브폰의 로컬 Codex worker(`local_direct`, 기본 URL `127.0.0.1:8765`)로 넘긴다. 성공 답변은 StoreBotTermux가 카톡으로 출력한다. Firebase `/packhelper/storebot_codex/requests`는 정상 핫패스가 아니라 로컬 다이렉트 결과 미러, 실패 fallback, 누락 보존/감사 경로다.
- Codex 브리지가 켜진 운영방의 기준은 Codex-main이다. `native_fallback_enabled=true`, `direct_health_skip_enabled=true`, `legacy_fallback_enabled=false`를 기준으로 두고, local-direct/worker stale/timeout/빈응답처럼 Codex 경로가 먹통일 때만 앱 내 Gemini/Groq/로컬 action runner를 서브 fallback으로 1회 사용한다. fallback이 성공하면 `native_fallback=true`로 기록하고, 실패하면 Codex 처리용 pending 큐에 보존한다.
- 장기 통합 방향은 StoreBot 앱에 Termux를 넣는 것이 아니라, StoreBotTermux 운영엔진에 StoreBot 카카오 수신/발송/큐/상태판 기능을 이식하는 것이다. Codex CLI 로그인 세션, proot/Python/shell/MCP/skill 확장성은 StoreBotTermux가 소유하고, 기존 StoreBot Android는 서버폰에서 삭제했다.
- 1차 완료 기준은 StoreBotTermux 단일 APK가 알림 접근, 접근성, foreground service, boot 복구, 카카오 수신/발송, Codex local-direct/session/action loop를 한 앱 프로세스 경계 안에서 관리하는 것이다. 이후 DeliveryHelper는 주소/지도 UI 껍데기, PosDelay는 대시보드/실행 모듈로 붙이고 판단/분석/학습은 같은 CLI 엔진과 업무 세션 관리가 맡는다.
- 2026-06-12 KST 현재 1차 이식은 StoreBotTermux `0.118.3-storebot.3 / 1005`에 Kakao notification listener/accessibility와 RemoteInput -> local-direct -> RemoteInput reply 브리지까지 들어간 상태다. 서버폰 카카오 권한은 StoreBotTermux가 소유하고, 기존 StoreBot Android `com.storebot.app`는 삭제했다.
- Codex 브리지는 모든 메시지에 답변하기 위한 장치가 아니다. StoreBot은 메시지를 판단 큐에 올리고, Codex가 도움 줄 정보가 없다고 보면 `SKIP`한다.
- StoreBot이 주문 캡처에서 자체 생성한 내점/결제 알림은 로컬 경로가 SOT다. `[내점]`, `[내점취소]`, `[결제 알림]`, 추가/수정/변경감지 알림 echo는 Codex/AI로 다시 보내지 않는다.
- Codex worker 기본 모델은 빠른 운영 응답용 `gpt-5.3-codex-spark/low`다. 사용자가 다른 답변, 상위 모델, 정밀/재분석을 요구하면 해당 요청만 `gpt-5.5/low`로 승격한다.
- StoreBotTermux 1차 카카오 경로는 Codex 최종 답변만 보낸다. `생각중...` 같은 중간 문구는 업무 반영 결과가 아니라 로딩 표시이며, 중복 체감이 커서 기본값은 OFF다.
- StoreBot이 접근성 폴백으로 보낸 문구는 카카오 UI에서 발신자명이 애매하게 잡혀도 다시 사용자 입력으로 처리하지 않아야 한다.
- `백수`/`StoreBot`처럼 봇 자기 발신자로 확인되는 말풍선은 접근성/알림 어느 경로로 들어와도 Codex bridge 큐에 넣지 않는다.
- 근무표 수정/조회, 제한된 Firebase 조회, 최근 전표/주문 요약, 누락조회, 검색/브리핑, 동적 가이드는 Codex가 `STOREBOT_ACTIONS` JSON으로 요청하고 worker가 허용된 외부 동작만 실행한다. action 이름은 기능 경계가 아니라 도구 라벨이다. 실행 결과가 `ok:true`로 돌아온 뒤에만 Codex가 반영 답변을 만든다.
- StoreBotTermux는 카톡 출력문을 하드코딩하지 않는다. 고정 근무 알림도 발화 시점에 최신 근무표/출근기록/날씨/이슈 payload만 Codex 큐에 넣고, 최종 카톡 문구는 Codex가 생성한다.
- 카카오 알림에 답장 액션이 없어도 운영방 메시지 판단 자체를 버리면 안 된다. Codex 큐 위임은 시도하고, 실제 발송은 reply action 또는 접근성 전송 경로가 가능할 때 처리한다.
- 카톡 출력은 ReplyAction이 우선이고, ReplyAction이 없으면 접근성 전송을 쓴다. 접근성 전송은 입력창 직접입력 실패 시 클립보드 붙여넣기를 fallback으로 쓰되, 실제 전송 버튼 클릭이 확인되지 않으면 성공으로 보지 않는다.
- 근무표/스케줄 조회·브리핑 이미지는 Codex 텍스트 답변 캡처가 아니다. 발송 직전에 Android가 `/workschedule_v2/**`와 날씨/스포츠/뉴스/재훈 콘티 payload를 다시 수집해 구조화 카드로 렌더링하고 카톡에 붙여넣기 전송을 먼저 시도한다. 단순 출근도장/반영 확인 같은 짧은 근무 답변은 텍스트로 둔다.
- 사용자가 `이미지`라고 말하지 않아도 `근무`, `근무표`, `출근`, 근무 리스트/브리핑/출력 요청은 기본 근무조회 후보로 본다. 이미지 브리핑은 필터가 없거나 `오늘부터`처럼 시작만 있으면 KST 오늘부터 7일치를 기본으로 보여주고, `오늘/내일/토요일/2026-06-13`처럼 특정 날짜만 있으면 해당 1일로 좁힌다.
- 카카오방이 화면에 열린 상태에서는 알림이 없거나 알림 액션이 부족할 수 있다. 접근성 이벤트가 여러 형태로 오더라도 운영방 마지막 메시지 확인을 시도해 업무 후보를 놓치지 않는다.
- Codex 브리지가 켜져 있는데 카톡 프로세스/ReplyAction이 불안정하면 서브폰 heartbeat가 ReplyAction 재획득과 운영방 접근성 스캔을 주기적으로 트리거해 입력 누락을 줄인다. 단, heartbeat 자동 복구 스캔은 중복 로그와 자기답변 루프를 만들 수 있으므로 같은 원인 반복 시 30분 쿨다운을 두고, self-like 말풍선 업무 후보 재주입은 하지 않는다.
- 접근성 노드로 현재 방 제목/최근 말풍선을 못 잡으면 OCR은 보조 판단 수단으로 쓴다. OCR은 AI 판단 기능이 아니라 열린 방 여부와 최근 메시지 누락을 줄이는 수신 안정성 fallback이다.
- 카카오 접근성에서 오픈채팅 닉네임 노드나 방 제목 노드가 빠져도 입력 후보를 버리면 안 된다. 발신자 누락 말풍선은 좌우 위치로 내 메시지 여부를 보정하고, 고정 오픈채팅 URL 직행 직후 입력창이 보이면 짧은 시간 운영방으로 신뢰해 스캔을 진행한다.
- 카카오 메시지 resource-id가 바뀌어 기본 메시지 노드가 안 잡혀도 화면 텍스트 말풍선 fallback으로 최근 메시지를 읽어야 한다. ADB 없이도 원인을 볼 수 있게 수동/복구 스캔은 방 불일치, 메시지 0개, 필터 후 0개, 큐 투입 여부를 원격 로그로 남긴다.
- 카카오가 운영방 최근 말풍선을 전부 내 메시지처럼 표시하는 경우에도 업무 후보를 무조건 버리면 안 된다. 다만 전체 self-like 말풍선을 허용하면 봇 echo 루프가 생기므로, `scan_now` 같은 수동 진단에서만 근무/출근/누락/알림/배달/결제/내점 같은 운영 명령 후보를 제한적으로 살린다. heartbeat 자동 복구 스캔과 전송 직전 스캔은 self-like 재주입을 하지 않는다.
- 카카오 접근성은 같은 말풍선을 `lee`, `카카오`처럼 다른 발신자로 다시 읽을 수 있다. 이 경우 `sender|text` 중복 방지만으로는 중복 요청이 생기므로, 접근성 입력은 동일 텍스트를 1시간 별도로 중복 차단한다.
- `before_accessibility_send`, `before_image_briefing_send` 같은 전송 직전 접근성 스캔은 읽기 전용 진단이다. 이 스캔에서 보이는 과거 말풍선은 dedup 캐시에만 넣고 Codex 큐에 새로 투입하지 않는다.
- 근무표 이미지 브리핑은 같은 payload/답변이 짧은 시간에 두 번 들어오면 재발송하지 않는다. 고정 알림과 수동 브리핑이 겹쳐도 같은 이미지를 반복 발송하면 실패다.
- 운영방 열기/스캔이 한 번 실패했다고 메시지를 버리면 안 된다. `codex_bridge.room_name`, `target_rooms`, 접근성 캐시 방 이름을 후보로 순차 재시도하고, `BBQ하이닉스점`/`BBQ하이닉스점 10`처럼 suffix 차이가 있어도 같은 운영방 후보로 본다.
- 근무/스케줄 문장은 별도 근무모드로 진입하지 않고 항상 AI 라우팅으로 보낸다. `근무모드`라는 말도 안내문으로 먹지 않는다.
- AI는 자유답변보다 `LOCAL_ACTION:domain|payload` 또는 같은 의미의 구조화 결과를 우선 낸다. domain/intent/slots 판단은 AI가 하고, 저장/수정/조회 여부는 로컬 validator가 결정한다.
- 로컬은 기본 기능 슬롯만 제공한다. AI는 자연어를 `domain + intent + filter/slots`로 맞춰 호출하고, 로컬은 그 조건을 검증/실행한다.
- AI는 로컬 기능의 사용자다. 로컬 기능이 JSON 문법 오류나 validator 오류를 내면 그 오류와 깨진 payload를 AI에 다시 보여줘 재작성 기회를 주고, 사용자에게 바로 양식 오류를 던지지 않는다.
- Codex 브리지는 하드코딩 문구와 고정된 기능별 응답 흐름을 스킬 action 양식으로 대체한다. 예약 시간, 중복 방지, 최신 데이터 수집, 발송 대상, 권한, 실패 재시도와 허용되지 않은 DB 쓰기 차단은 로컬 고정 규칙이 계속 책임진다.
- StoreBot의 장기 의도는 자가발전이다. 사용자가 출력 양식, 포함 정보, 우선순위, 실패/성공 패턴을 교정하면 그때만 맞추고 끝내지 않고 runtime guidance와 스킬/MD에 누적해 다음 브리핑과 다음 세션에도 반영한다.
- 근무표 이미지 브리핑은 단순 텍스트 캡처가 아니다. 근무/재훈 콘티/날씨/월드컵/뉴스/공휴일/운영이슈를 구역별로 나누고, 중요 포인트는 색상·강조로 보여준다. 근무자는 출근시간 기준 정렬, 재훈 콘티는 재훈이 StoreBot 근무자가 아니어도 날짜 이슈로 표시, 월드컵은 당일 경기 전체 표시, 한국 경기는 강조, 뉴스는 제공된 경우 누락하지 않는다. `한국시간`/`KST`는 시간대 표기일 뿐 한국 경기 강조 근거가 아니다.
- 근무 수정에서 `금요일부터` 같은 시작 경계는 그 날짜 이후 기준이다. 사용자가 이전 날짜 삭제를 명시하지 않았으면 앞선 날짜별 임시 근무/예외를 지우거나 없는 근무로 판단하지 않는다.
- 기본 원칙은 양식 위주 기능 사용이다. 로컬 기능을 하나씩 설명하지 않고, AI가 공통 양식 슬롯을 채워 조회/수정/기록 기능을 사용한다.
- 근무의 기본 단위는 `고정 스케줄`과 `임시 스케줄`이다. 둘 다 추가/수정/삭제/조회가 가능해야 하며, AI는 이를 `fixed_update`, `schedule/off/clear/query` 슬롯으로 넘긴다.
- 고정 스케줄에서 `월/화만`처럼 근무요일을 지정한 경우 그 `days`가 기준이다. 이전 `off`나 `dayTimes` 찌꺼기가 남아도 추가 근무일처럼 해석되면 안 된다.
- 최초 자연어 업무 문구를 로컬 직접파서가 분류하지 않는다. 로컬 분류는 이미 운영 로그에서 실패가 확인됐으므로, 로컬은 AI 결과 검증/실행/중복방지에만 쓴다.
- 로컬 실행은 보수적이어야 한다. 직원, 날짜, 시간, 방, 발신자, phone role, KST 기준이 맞지 않거나 애매하면 저장하지 않고 확인질문 또는 무응답으로 끝낸다.
- 답변은 "무엇이 반영됐는지/무엇을 더 확인해야 하는지"만 짧게 말한다. AI가 장황하게 설명하는 것은 실패에 가깝다.

## 운영 설정 우선 원칙
- 자연어 이해 품질 문제는 APK 빌드보다 원격 프롬프트/규칙 갱신을 먼저 사용한다.
- 앱은 이미 구현된 실행 엔진이다. 새 문장 패턴을 코드에 계속 추가하지 않는다.
- Firebase `/packhelper/rules_hub/StoreBot/prompts/*`와 동적 규칙을 우선 갱신하고, 앱은 이를 받아 AI 판단과 validator 실행을 연결한다.
- 안정적으로 돌아가는 프롬프트/응답 경로는 한 번에 교체하지 않는다. 개선 후보는 먼저 shadow 계측으로 현재 AI 판단, LOCAL_ACTION domain/action, prompt profile/길이/hash, 실행 성공 여부를 기록해 비교한 뒤 canary 여부를 판단한다.
- 프롬프트 리미트가 걸리면 기능을 끄지 말고 프롬프트를 축소한다. 줄이는 순서는 `대화이력 → RAG/검색 참고문 → 동적 캐릭터/직원 세부규칙 → 도메인 부가 설명`이다.
- 축소 후에도 반드시 남길 최소 요소는 `현재 원문`, `현재 KST`, `LOCAL_ACTION:domain|payload`, `schedule/address 최소 스키마`, `출근 전 시간변경은 schedule.start` 규칙이다.
- APK 수정은 브릿지가 없을 때만 한다. 예: AI 호출 자체가 안 됨, `LOCAL_ACTION` 파싱/실행이 없음, validator가 action/slot을 모름, Firebase 반영 함수가 없음.
- `반영 불가` 로그는 원문 저장에서 끝내지 않고 `parse_repair_queue`로 승격한다. Gemini가 직접 고칠 수 있는 것은 프롬프트와 스키마 별칭뿐이고, APK/실행 로직 필요 건은 분석 요청으로만 남긴다.
- `LOCAL_ACTION` 실행 실패는 사용자의 입력 실패로 단정하지 않는다. raw payload, 오류 메시지, 로컬 계약, 사용자 원문을 함께 재시도/학습 데이터로 남겨 AI가 사태를 파악할 수 있게 한다.
- `연옥 이번주 일요일 오전 출근 등록`, `연옥 일요일 07:00~19:00` 같은 자연어를 사용자에게 양식으로 다시 요구하면 실패다. 프롬프트가 직원/요일/시간/상태 슬롯으로 바꿔야 한다.
- 리미트 최적화보다 성공률이 먼저다. 실제로 되는 상태를 만든 뒤 사용량을 보고 이력/RAG/동적 섹션을 줄인다.
- 자동 업데이트가 설치 화면을 못 열 때도 앱 안의 수동 업데이트 설치 버튼으로 이미 받은 APK 또는 원격 APK 설치 흐름을 다시 열 수 있어야 한다.

## 절대 기준
- 스킵/중복 방지는 누락 방지와 함께 판단한다.
- 서브폰은 운영 실행 단말이고, 개인폰은 MAIN/collector/모니터 단말이다. StoreBotTermux 운영엔진은 두 폰 모두 설치 가능해야 하며, phone role로 live ops 권한과 리소스 강도를 나눈다. 서브폰에서는 PosDelay 주문/지연/방어 실행 우선권을 유지하고, StoreBot 수신 안정화가 PosDelay foreground와 접근성 자동화를 빼앗지 않는다.
- 현재 개인폰 1대는 `device_key=d2dbdc4075acad22` 기준으로 `MAIN` 자동 고정한다. 이 기기는 live ops가 아니라 collector/모니터 역할로 둔다.
- 역할과 실행모드는 화면 토글로 수동 지정하지 않는다. 현재 개인폰 ID는 MAIN/collector, Firebase SOT에 등록된 서브폰 ID는 KITCHEN/server로 자동 판정한다.
- 기본 베이스 채팅은 자연어다. 빈값 같은 수신 하드가드 외에는 로컬이 의미를 판단하거나 SKIP하지 않는다.
- worker/App/monitor의 자연어 판단 의존은 절대 불가다. `SKIP`, `kakao_reply`, `STOREBOT_ACTIONS`, `STOREBOT_OUTPUT`, domain/intent/slots는 Codex/스킬 출력이나 명시 시스템 이벤트 계약에서만 나온다.
- Codex 브리지는 개인 1:1방/다중 방 라우팅이 아니라 운영방 1개 기준이다. 로컬 다이렉트가 실패하면 앱이 Codex 실행 경로 복구를 시도하고, 복구 전 요청은 Codex 처리용 pending 큐로 보존한다. 단, Codex 경로가 stale/timeout/빈응답으로 확인된 운영 메시지는 앱 내 Gemini/Groq/로컬 action runner가 서브 fallback으로 1회 처리할 수 있다.
- Codex 브리지의 최종 답변 여부는 Codex 세션의 `SKIP` 판단이 기준이다. 로컬이 답장 액션 부재만으로 업무 후보 메시지를 버리면 안 된다.
- 알림 리스너와 접근성 리스너는 경쟁 관계가 아니라 상호 보완이다. 알림이 없거나 reply action이 없는 경우에도 접근성 경로로 열린 카카오방 메시지를 포착해야 한다.
- 접근성 경로는 열린 방의 과거 말풍선을 반복해서 볼 수 있으므로, 같은 `sender|text`는 충분히 긴 시간 재처리하지 않아야 한다. 30분마다 같은 근무 반영 답변이 반복되면 실패다.
- 수신 안정화는 StoreBot 앱의 1차 책임이다. 열린/닫힌 카톡방 모두에서 누락을 줄이고, 앱킬, worker stale, 미발송 pending queue, 접근성/알림 권한 문제를 heartbeat/watchdog/누락조회로 드러낸다.
- 운영판의 버전 기준은 StoreBotTermux 앱 버전이다. 기존 StoreBot Android `version_name/version_code`는 더 이상 서버폰 운영 SOT가 아니며, Termux Codex worker bundle은 별도 제품 버전처럼 노출하지 않는다. 앱 화면과 `/subphone/heartbeat/storebot`에는 앱/worker 큐, local-direct 수신, self-sync, codex_ops stale, bridge_safe 같은 백엔드 상태만 노출한다. 내부 비교용 bundle 버전은 health 판단에만 쓴다.
- ADB가 안 되는 상황에서도 `/subphone/cmd/storebot`의 `codex_local_smoke` 진단 명령으로 앱 내부 로컬 다이렉트 연결을 no_publish 검증할 수 있어야 한다. Codex 응답은 수분까지 지연될 수 있으므로 local_direct timeout은 실측 기준으로 충분히 길게 둔다.
- ADB 없이 카카오 입력경로를 확인할 때는 `/subphone/cmd/storebot`의 `scan_now`로 운영방 접근성 스캔을 강제하고, `/packhelper/storebot_bridge_log`와 `/packhelper/storebot_codex/requests`를 같이 확인한다.
- ADB 없이 즉시 근무 브리핑을 검증할 때는 `/subphone/cmd/storebot`의 `briefing_now` 계열 명령을 쓴다. `image_briefing_now` 또는 `native_image=true`는 Codex worker stale 상황에서도 Android가 지정일/요일을 해석하고 발송 직전 live 근무 payload를 수집해 PNG를 직접 렌더링/전송한다. target이 비어 있으면 오늘부터 7일치가 기본이다. 일반 고정 알림의 최종 문구는 Codex가 만들되, 명시 CMD는 이미 지나간 고정 알림 dedup에 막히지 않아야 한다.
- 로컬 코드는 자연어 의미 분류의 주체가 아니다. 로컬이 먼저 할 일은 자기 메시지/빈값/완전 중복/명백한 리액션 같은 하드가드뿐이며, 업무 가능성이 있는 문장은 상위 AI가 먼저 받아 domain/intent 판단을 한다.
- AI는 자연어를 직접 실행하는 주체가 아니라 로컬 기능 domain과 JSON 슬롯으로 번역하는 통로다. 로컬 validator가 최종 실행 여부를 결정한다.
- 로컬 validator는 단순 차단기가 아니라 AI에게 줄 피드백 생산자다. 거절 사유는 사람이 다시 말하게 하기 전에 AI 재작성 루프에 먼저 사용한다.
- AI 리미트 조절은 AI를 우회하기 위한 장치가 아니다. 리미트 상황에서도 업무 후보 메시지는 최소 프롬프트로 AI 판단을 거치고, 이력/RAG/동적 섹션을 줄여 안정성을 맞춘다.
- 기능은 계속 늘어나므로 기능별 문장/번호를 프롬프트에 하나씩 매칭하지 않는다. AI는 입력 담당으로 자연어를 `domain + intent + slots`로 정규화하고, 로컬은 실행/저장/조회/최종 답변 출력 담당으로 둔다.
- 프롬프트에는 전체 기능 목록 대신 공통 출력 규격과 최소 도메인만 둔다. 새 기능은 로컬 registry와 validator를 늘리고, AI에는 필요한 슬롯 이름만 짧게 알려준다.
- 연속으로 오는 짧은 메시지는 낱개 로컬 스킵보다 최근 문맥을 묶어 보고 답변, 무응답, 로컬 기능 위임을 판단한다.
- 자기 메시지 루프 차단이 내점 알림이나 운영 이벤트 누락으로 번지면 안 된다.
- 내점/결제 알림의 생성, CAS, dedup, 발송 큐는 DineinMonitor 로컬 경로가 책임진다. Codex는 사람이 질문하거나 최근 주문을 조회할 때만 order 도구로 참고한다.
- 근무표/출근/내점은 발신자, 방, 날짜, KST, mode, phone role을 함께 본다.

## 프롬프트 정리 기준
- 프롬프트는 `역할/출력규격/도메인 스키마` 3층으로 나눈다. 역할과 출력규격은 항상 짧게, 도메인 스키마는 필요한 경우만 붙인다.
- 출력규격은 하나로 고정한다: `LOCAL_ACTION:domain|payload`. AI는 답변문을 길게 만들지 않고 domain과 payload만 만든다.
- `LOCAL_ACTION` payload는 한 줄이 원칙이지만, AI가 JSON을 여러 줄로 내도 앱이 완성된 JSON까지 수집해 실행해야 한다.
- `LOCAL_ACTION` payload는 로컬이 `JSONObject(payload)`로 읽을 수 있는 JSON 객체여야 한다. 깨진 JSON은 오류와 함께 AI에 되먹여 한 번 이상 고쳐보게 한다.
- AI는 로컬 Kotlin 구조를 직접 읽지 못한다. 프롬프트에는 구현 설명이 아니라 공개 호출 계약(domain/type 매핑/slot 이름)만 짧게 제공한다.
- domain은 큰 업무 묶음만 둔다. 예: `schedule`(근무표 예정, 실제 출퇴근 기록, 출퇴근 조회/삭제), `address`(주소/건물), 이후 `alert`, `payment`, `knowledge`처럼 확장한다.
- payload는 기능 번호가 아니라 JSON 슬롯이다. 근무 공통 양식은 `이름`, `날짜`, `고정`, `임시`, `시간`, `임의시간`, `filter` 중심으로 유지한다.
- `고정` 슬롯은 `days/dayTimes`뿐 아니라 `월/화/수/목/금/토/일` 한글 요일 키도 같은 고정스케줄 패치로 취급한다.
- APK 없이 자동 적용 가능한 스키마 보정은 `/packhelper/rules_hub/StoreBot/schema_normalizer/schedule`의 type/key/nested-key 별칭으로 제한한다.
- 조회 payload는 엑셀 필터처럼 본다. `filter` 안의 기간, 직원, 상태, 필드 조건을 로컬 validator가 실행 가능한 조회로 바꾼다.
- `query`는 기능을 쪼개지 않는다. 오늘/내일/이번주/다음주/직원별/기간별 조회는 모두 같은 조회 기능에 날짜·직원 필터를 붙인 것으로 처리한다.
- 직원명이 없는 근무조회/전체조회는 날짜 필터보다 알림 브리핑 기준을 우선한다. 즉 고정스케줄, 이번주/다음주, 날씨, 이슈를 한 번에 보여준다.
- 런타임 프롬프트는 예시 목록을 늘리지 않는다. 핵심 실패 문장은 회귀 테스트와 원격 규칙 검증용으로만 관리한다.
- 오타/축약/상대날짜는 AI가 슬롯으로 정규화하고, 로컬 validator가 직원/날짜/시간/권한을 재검증한다.
- 프롬프트는 "양식 안내문"이 아니라 "자연어 → JSON 슬롯 변환 계약"이다. 실패 시 사용자에게 형식을 요구하기보다 가능한 안전 action 또는 tentative 후보를 만든다.
- `출근`은 문맥으로 나눈다. `내일/다음주/요일 + 이름 + 출근`은 근무표 예정, `이름 + 6시 반 + 출근/퇴근`이나 `출근확정`은 실제 출퇴근 기록 후보로 본다.
- 근무 판단의 1차 기준은 KST 현재시각 대비 대상 시간이 미래인지 과거인지다. 미래 시간의 출근/퇴근 언급은 근무 예정/스케줄이고, 과거 또는 현재에 이미 발생한 출근/퇴근 언급은 실제 출퇴근 기록이다.
- 오늘 날짜처럼 애매한 경우도 시간까지 비교한다. 예: 현재보다 뒤의 `20:40 퇴근`은 예정/확인 후보, 현재보다 지난 `20:40 퇴근했어`는 실제 기록 후보로 본다.
- 오늘이어도 해당 직원의 예정 출근 전이면 `출근시간 변경/수정/바꿔`는 과거 기록 보정이 아니라 `/workschedule_v2/overrides/{오늘}/{직원}`의 `state=shift` 수정이다. `actual_start`는 `출근확정`, `도착`, `출근했어`처럼 실제 발생 확인이 있을 때만 쓴다.
- `출근할게요`, `퇴근한다고`, `20:40 퇴해도 돼요`처럼 약속/허락/예정 표현은 실제 출퇴근 기록이 아니다. 더 늦게 오거나 바뀔 수 있으므로 중간 단계 예정/확인 후보로 두고, 실제 기록은 `출근했어`, `도착`, `퇴근완료`, `출근확정/퇴근확정`처럼 발생이 확인된 표현에만 남긴다.
- 애매하면 AI가 임의 저장하지 않고 확인질문을 만든다. 로컬도 validator 실패 시 반영하지 않는다.

## AI 리미트 운용 의도
- AI 리미트 관리는 정확도와 안정성을 동시에 지키기 위한 장치다. 비용/한도 때문에 업무 후보를 로컬 skip으로 우회하지 않는다.
- 리미트가 부담될 때 줄이는 순서는 `대화이력 → RAG/검색 참고문 → 동적 캐릭터 섹션 → 도메인 부가 설명`이다. 마지막까지 남겨야 할 것은 `현재 원문`, `현재 KST`, `LOCAL_ACTION 출력규격`, `최소 도메인 스키마`다.
- 축소 프롬프트에서도 `출근 전 시간변경=schedule.start`, `실제 발생 확인=attendance`, `주소=address 도구` 기준은 빠지면 안 된다.
- 업무 후보 메시지는 최소 프롬프트라도 AI가 받아야 한다. 로컬이 "업무 아님"을 먼저 단정하는 방식은 금지한다.
- 상위 AI가 막히면 가벼운 AI 또는 폴백 AI로 domain/intent만 판단한다. 그래도 실패하면 저장/수정 같은 위험 작업은 하지 않고 확인질문 또는 무응답으로 둔다.
- 프롬프트는 길게 설명해서 맞히는 방식이 아니라, 짧은 계약과 로컬 validator 조합으로 맞힌다. 기능이 늘어나도 후보 문장 목록을 프롬프트에 계속 추가하지 않는다.
- 토큰/요청 제한 때문에 이력을 버리더라도 최신 원문은 보존한다. 근무/주소처럼 최근 문맥이 중요한 경우에는 필요한 최소 최근 문맥만 따로 붙인다.

## AI 자동 라우팅 의도
- 운영방 Codex 브리지 ON 기준 우선순위는 Codex-main이다. Gemini/Groq는 메인이 아니라 Codex local-direct/worker가 stale/timeout/빈응답으로 확인될 때만 쓰는 서브 fallback이다.
- 서브 fallback 안에서는 기존 안전 순서인 Gemini → Groq → 로컬 validator/action runner를 쓴다. 이 경로는 사용자가 응답을 아예 못 받는 상황을 줄이는 장애 대응이며, Codex 스킬/자가학습 기준을 대체하지 않는다.
- 로컬은 Codex나 fallback AI보다 먼저 자연어 의미, 업무 여부, 답변/SKIP 여부를 판단하지 않는다.
- 로컬 fallback은 AI 우회가 아니라 장애 대응이다. 쓰기 작업은 validator가 확정할 수 있을 때만 하고, 애매하면 저장하지 않는다.
- fallback이 답변 또는 `LOCAL_ACTION`을 만들면 검증 후 1회 처리하고 `native_fallback=true`로 남긴다. fallback도 실패하면 사용자에게 성공처럼 말하지 않고 Codex pending 큐와 누락조회 경로에 남긴다.
- 토큰/리미트 압박 시 Codex를 끄거나 하위 provider를 메인으로 올리지 않는다. 먼저 프롬프트를 줄이고, 그래도 먹통이면 서브 fallback으로 장애 대응한다.
- 사용자에게는 토큰/리밋/Gemini/Groq/AI 격하·격상을 말하지 않는다. 정상 처리되면 결과만 말하고, 저장 위험이 있는데 판단이 약하면 "기록은 안 건드렸고, 내가 이해한 건 ... 맞아?"처럼 확인만 한다.
- 잡담 예: `피곤하다 한잔하러 가야겠다`, `심심하다`는 업무 이벤트가 아니므로 운영방에서는 무응답이 기본이다. 1:1에서 답하더라도 업무 기록과 무관한 짧은 잡담으로 끝낸다.

## 도메인별 판단 의도
- `schedule`: 근무표 예정, 실제 출퇴근 기록, 출퇴근 조회/삭제를 같은 큰 도메인으로 본다. 예정과 실제 기록은 `intent/type`으로 나누고 날짜/시간/발신자 문맥으로 검증한다.
- `schedule` 조회는 근무자만 보여주는 축약 기능이 아니다. 날짜별 날씨, 스포츠/공휴일/뉴스 이슈까지 같은 조회 결과에 포함해 운영 판단에 필요한 맥락을 같이 준다.
- 근무알림 외부 이슈는 하드코딩 종목표가 아니라 검색/요약 도구와 동적 가이드로 판단한다. 사용자 교정이 있으면 다음부터 반영한다. 예: 월드컵은 한국 경기 우선, 야구는 전체 나열보다 중요한 경기만.
- 근무알림 샘플 문구는 시작점일 뿐 고정 템플릿이 아니다. 반복된 사용자 교정/누락/과잉 출력은 Codex 동적 가이드로 누적해 다음 출력 기준을 개선한다.
- `schedule` 시간축: 대상 시각이 미래면 예정 스케줄, 과거/현재면 실제 출퇴근 기록이다. 날짜 표현이 없으면 KST 오늘과 현재시각, 발신자 자기보고 표현, 직전 문맥을 함께 본다.
- `schedule` 출근시간 변경: 오늘 근무라도 아직 출근 전이면 미래 스케줄 변경이다. 예: 현재 14:00, `리 출근시간 5시로 변경` → 오늘 리 `schedule.start=17:00`; `리 출근확정 17:00` → `attendance.actual_start=17:00`.
- `schedule` 중간 예정: 직원이 "간다/온다/퇴한다/해도 되냐"고 말한 것은 실제 기록보다 약한 상태다. 로컬은 이를 actual_start/actual_end 로 바로 쓰지 않고 schedule/tentative/확인질문으로 처리한다.
- `address`: 건물명, 동호수, 짧은 주소 후보를 다룬다. StoreBot 코드에 주소를 박지 않고 DeliveryHelper 주소책/건물 메모리/confidence를 소비한다.
- `address`: 카카오 알림의 `사진을 보냈습니다.`는 이미지 원문이 아니므로 주소로 해석하지 않는다. 사진/스크린샷에서 나온 OCR 텍스트나 주문 원문에 `주소:`/`배달주소:` 라벨이 들어온 경우에만 메뉴 줄보다 주소 줄을 우선해 즉시 추출한다.
- `address`: 바쁜 시간 입력은 `아파트`, `빌라` 같은 접미사 없이 들어올 수 있다. `삼익 104-1109`처럼 짧은 건물+동호수는 DeliveryHelper 로컬 포인트 DB 원천(`map_knowledge`, `building_corrections`)에서 주소번지 포인트를 먼저 잡는다. 건물명을 치면 주소를, 주소를 치면 건물명을 보강하고, 동일라인 경험은 포인트 필수조건이 아니라 신뢰도 상승 근거로만 쓴다.
- `dinein/order/payment`: 내점, 주문, 결제, 영수증, 미결제 확인은 운영 이벤트다. 확정 데이터가 있으면 로컬 조회/기록을 우선하고, 애매하면 AI가 슬롯을 정리한다.
- `logistics`: 물류/배송/입고/발주/재고 알림을 운영 이벤트로 본다. 알림 원문은 가장 정보가 많은 본문을 선택하고, 파싱 결과를 로컬 저장/알림으로 연결한다.
- `order_excel_analyzer`: SFA 품목명은 OrderHelper MASTER target에 의미상 정확히 매칭해야 한다. `BBQ충진식패티(100g)(마일드)`와 `BBQ페퍼로니씬피자`는 `두마리치킨,파더스`로 묶지 않는다.
- `knowledge/search`: 명시 검색이나 외부 정보는 로컬 검색/RAG를 쓰되, 업무 맥락이 있으면 일반 검색보다 업무 도메인 판단을 우선한다.

## UI/동선 기준
- 카카오 답변은 짧고 실제 처리 결과 중심이어야 한다.
- 운영방 잡담과 명확한 근무/주소/검색 명령을 구분한다.
- "금호"처럼 짧은 건물/주소/근무 용어도 모르면 무응답으로 끝내지 말고, 주소DB/근무맥락/AI 판정 중 최소 1단계를 거쳐 답변 또는 확인질문으로 이어간다.
- 근무 관련 짧은 입력, 오타 입력, 직원 후속문은 단순 잡담으로 SKIP하지 않는다. 예: `근뭄드`, `사아야 고정 17시30분~22시`, `저2040퇴해도돼여?`.
- 기능 확장은 긴 후보 문장 목록이 아니라 `LOCAL_ACTION:domain|payload` 스키마로 한다. 예: `schedule|{"actions":[...]}`, `address|금호 주소`.
- 근무표 예정과 실제 출퇴근 기록은 같은 schedule 도메인 안의 다른 intent로 본다. 예: "내일 리 출근"은 근무표 예정이고, 오늘 "리 6시 반 출근/출근시간 변경"도 현재가 18:30 전이면 예정 변경이다. 실제 기록은 "리 6시 반 출근확정/도착/출근했어"처럼 발생 확인이 있어야 한다.
- 근무 반영 답장은 개별 처리 카운트보다 해당 날짜 전체 근무표를 `반영 yyyy-MM-dd(요일) 근무`로 보여준다. 시간이 없고 고정시간도 없으면 `일단출근`으로 표시한다.

## 데이터/경계 기준
- StoreBot은 서브폰 KITCHEN/server live ops 기준으로 동작한다.
- `mode=1on1` 같은 legacy 설정값은 실행모드로 쓰지 않는다. 명시 `server/collector`만 인정하고, 그 외에는 KITCHEN=server, MAIN=collector로 정규화한다.
- 물류 알림톡은 `EXTRA_TEXT`만 믿지 않고 `BIG_TEXT`/text lines 중 배송본문이 가장 잘 보이는 값을 사용한다. `동원산업-LOEX`, `동원로엑스`, `LOEX`를 동원 물류 발신자로 본다.
- 카카오방 상주형 보조 감시는 기본 수신 수단이 아니라 notification listener 장애나 누락 의심 때 쓰는 fallback이며, PosDelay health/safe window를 먼저 확인한다.
- 주소 지식은 DeliveryHelper의 누적 DB와 confidence를 소비하고 코드에 박지 않는다.
- `/packhelper/storebot_pending_queue` 생산자는 신규 전송 대기 항목에 `sent=false`를 반드시 넣는다. StoreBotTermux는 성공 발송 후에만 `sent=true`로 바꾼다.
- 원격 프롬프트 변경 시 로컬 fallback asset과 rules_hub 버전을 같이 확인한다.
- AI 도구 선택 개선은 `/packhelper/ai_monitor/apps/StoreBot/tool_usage_shadow/latest`와 `/packhelper/ai_learning/storebot/tool_usage_shadow/*`를 먼저 보고 판단한다. 이 shadow 데이터는 실제 답변/저장 결과를 바꾸면 안 되며, 안정성 확인 전에는 프롬프트 교체 근거로만 사용한다.
- C&I prompt는 StoreBot monitor, StoreBotTermux worker, `STOREBOT_OUTPUT.self_fix`, 사용자/수동 enqueue, 또는 상주 판단 루프가 만든다. 이는 LLM 실행을 깨우는 envelope이며 C&I 판단 권한 제한이 아니다.
- C&I 자동 복구는 카톡 답변 hot path와 분리된 `codex_ops` 큐에서 처리하고, 사용자에게 보이는 출력은 `kakao_reply`만 둔다.
- SFA 발주 엑셀은 파일이 내려받아지는 PC에서 분석한다. 폰/카톡방으로 파일을 옮기는 것을 전제로 하지 않고, 메인PC `main_auto.pyw`가 새 파일을 감지해 PC 분석기를 1회 실행하고 Firebase에 결과를 저장한다. 구조와 주문일자를 먼저 감지하고, 화/목/토 발주주기 시작일을 우선 매칭한다. 금액 열은 닭류 발주단위 추정의 보조 근거로만 쓰며, 목표일이 없을 때만 최신 주문일자를 쓴다. 비교 결과는 `/order/desk_q7m9r3a8/sfaCompare/latest`, 실발주 이력은 `/order/desk_q7m9r3a8/sfaActualHistory/{date}`에 남긴다. confidence 낮으면 `current.actualOrders` 원본 확정 반영은 하지 않는다.

## 수정 전 질문
- 답변 품질만 바꾸는가, 실제 운영 이벤트 처리까지 안전하게 보장하는가.
- 스킵, dedup, role guard가 필요한 알림을 막지 않는가.
- 날짜/요일/KST 검증이 원문과 일치하는가.

## 완료 기준
- 검증: 관련 단위테스트, Firebase 데이터 확인, 필요 시 자동업데이트/명령 소비 확인
- 전달: Android 변경 시 debug APK 및 자동업데이트 채널 반영
- 남은 위험: 서브폰 ADB 미연결, 앱 heartbeat와 Termux worker 실제 실행 버전 불일치, codex_ops 프로젝트 작업 통로 stale, 앱 내장 worker 전환 전까지 Termux 스크립트 kill 가능성
