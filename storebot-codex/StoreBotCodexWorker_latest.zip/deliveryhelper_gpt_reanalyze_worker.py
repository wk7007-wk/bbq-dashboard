#!/usr/bin/env python3
"""DeliveryHelper GPT first-review worker.

Polls Firebase requests created by the DeliveryHelper reanalyze button, runs a
stateless Codex pass with the deliveryhelper-reanalyze skill, and writes a
strict JSON result for the Android app to apply only to the matching device/order.
"""

from __future__ import annotations

import argparse
import hashlib
import json
import os
import re
import shutil
import socket
import subprocess
import sys
import time
import urllib.error
import urllib.parse
import urllib.request
from pathlib import Path
from typing import Any


BASE_DIR = Path(__file__).resolve().parents[1]
DEFAULT_FIREBASE = "https://poskds-4ba60-default-rtdb.asia-southeast1.firebasedatabase.app"
REQUESTS_PATH = "/packhelper/deliveryhelper/gpt_reanalyze/requests"
RESULTS_PATH = "/packhelper/deliveryhelper/gpt_reanalyze/results"
HEARTBEAT_PATH = "/packhelper/deliveryhelper/gpt_reanalyze/heartbeat"
GEOCODE_CACHE_PATH = "/packhelper/map_knowledge_geocode_cache"
NAVER_CLIENT_ID_PATH = "/banktotal/settings/naver_client_id"
NAVER_CLIENT_SECRET_PATH = "/banktotal/settings/naver_client_secret"
NAVER_GEOCODE_URL = "https://maps.apigw.ntruss.com/map-geocode/v2/geocode"
SKILL_NAME = "deliveryhelper-reanalyze"
CODEX_BIN_ENV = "DELIVERYHELPER_GPT_CODEX_BIN"
TMP_DIR_ENV = "DELIVERYHELPER_GPT_TMP_DIR"

FLAGS = ("utensil", "bell", "knock", "door", "direct", "call", "text", "chickenMu")
REQUEST_FIELDS = FLAGS + ("password", "specialNotes")
ADDRESS_FIELDS = ("building", "dong", "ho", "line")
FIELD_NAMES = tuple(f"address.{field}" for field in ADDRESS_FIELDS) + tuple(f"request.{field}" for field in REQUEST_FIELDS)
APPLY_POLICIES = {"auto", "candidate", "confirm", "reject"}
FIREBASE_INVALID_KEY_RE = re.compile(r"[.#$/\[\]]")


class WorkerError(RuntimeError):
    pass


def now_ms() -> int:
    return int(time.time() * 1000)


def log(message: str) -> None:
    print(f"[dh-gpt] {time.strftime('%Y-%m-%d %H:%M:%S')} {message}", flush=True)


def compact_error(text: str, limit: int = 500) -> str:
    return re.sub(r"\s+", " ", str(text or "")).strip()[:limit]


def compact(text: str) -> str:
    return re.sub(r"\s+", "", str(text or ""))


def assert_firebase_safe_object_keys(value: Any, path: str = "$") -> None:
    if isinstance(value, dict):
        for key, entry in value.items():
            text = str(key)
            if not text or FIREBASE_INVALID_KEY_RE.search(text):
                raise WorkerError(f"invalid Firebase object key at {path}: {text!r}")
            assert_firebase_safe_object_keys(entry, f"{path}.{text}")
    elif isinstance(value, list):
        for idx, entry in enumerate(value):
            assert_firebase_safe_object_keys(entry, f"{path}[{idx}]")


def unique_existing_paths(paths: list[str]) -> list[str]:
    out: list[str] = []
    seen: set[str] = set()
    for raw in paths:
        text = str(raw or "").strip()
        if not text:
            continue
        path = os.path.expandvars(os.path.expanduser(text))
        if path in seen:
            continue
        seen.add(path)
        out.append(path)
    return out


def codex_bin_candidates(configured: str | None = None) -> list[str]:
    candidates: list[str] = []
    configured_bin = str(configured or os.environ.get(CODEX_BIN_ENV) or "").strip()
    if configured_bin:
        if os.path.sep in configured_bin:
            candidates.append(configured_bin)
        else:
            found = shutil.which(configured_bin)
            candidates.append(found or configured_bin)

    path_bin = shutil.which("codex")
    if path_bin:
        candidates.append(path_bin)

    home = str(Path.home())
    prefix = os.environ.get("PREFIX", "")
    candidates.extend(
        [
            "/usr/local/bin/codex",
            "/root/.local/bin/codex",
            f"{home}/.local/bin/codex",
            f"{prefix}/bin/codex" if prefix else "",
            "/data/data/com.sbotux/files/usr/bin/codex",
            "/data/data/com.termux/files/usr/bin/codex",
        ]
    )
    return unique_existing_paths(candidates)


def is_executable_file(path: str) -> bool:
    expanded = os.path.expandvars(os.path.expanduser(path))
    return os.path.isfile(expanded) and os.access(expanded, os.X_OK)


def resolve_codex_bin(configured: str | None = None) -> str:
    candidates = codex_bin_candidates(configured)
    for candidate in candidates:
        if is_executable_file(candidate):
            return os.path.expandvars(os.path.expanduser(candidate))
    raise WorkerError(
        "codex executable not found; "
        f"{CODEX_BIN_ENV}={str(configured or os.environ.get(CODEX_BIN_ENV) or '').strip() or '<unset>'}; "
        f"PATH={os.environ.get('PATH', '')}; "
        f"candidates={', '.join(candidates) if candidates else '<none>'}"
    )


def temp_dir_candidates() -> list[Path]:
    env_tmp = str(os.environ.get(TMP_DIR_ENV) or "").strip()
    prefix = os.environ.get("PREFIX", "")
    candidates = [
        env_tmp,
        os.environ.get("TMPDIR", ""),
        f"{prefix}/tmp" if prefix else "",
        "/data/data/com.sbotux/files/usr/tmp",
        "/data/data/com.termux/files/usr/tmp",
        "/sdcard/Download/deliveryhelper_gpt_worker/tmp",
        "/tmp",
        "/var/tmp",
    ]
    repo_tmp = BASE_DIR / ".tmp"
    if repo_tmp.is_dir():
        candidates.append(str(repo_tmp))
    return [Path(path) for path in unique_existing_paths(candidates)]


def safe_unlink(path: Path, *, context: str = "temp cleanup") -> None:
    try:
        path.unlink()
    except FileNotFoundError:
        return
    except OSError as exc:
        log(f"{context} skipped path={path}: {compact_error(str(exc), 160)}")


def is_writable_dir(path: Path) -> bool:
    try:
        if not path.exists() and not path.parent.exists():
            return False
        path.mkdir(parents=True, exist_ok=True)
        if not path.is_dir():
            return False
        probe = path / f".dh_gpt_probe_{os.getpid()}_{time.time_ns()}"
        fd = os.open(str(probe), os.O_WRONLY | os.O_CREAT | os.O_EXCL, 0o600)
        try:
            os.write(fd, b"ok")
        finally:
            os.close(fd)
        if probe.read_bytes() != b"ok":
            return False
        safe_unlink(probe, context="temp probe cleanup")
        return True
    except OSError:
        return False


def select_tmp_dir() -> Path:
    candidates = temp_dir_candidates()
    for candidate in candidates:
        if is_writable_dir(candidate):
            return candidate
    raise WorkerError(
        "no writable temp directory for codex output; "
        f"{TMP_DIR_ENV}={os.environ.get(TMP_DIR_ENV, '<unset>')}; "
        f"candidates={', '.join(str(path) for path in candidates) if candidates else '<none>'}"
    )


def create_temp_output_path() -> Path:
    errors: list[str] = []
    for directory in temp_dir_candidates():
        if not is_writable_dir(directory):
            errors.append(f"{directory}: not writable")
            continue
        path = directory / f"dh_gpt_reanalyze_{os.getpid()}_{time.time_ns()}.txt"
        try:
            fd = os.open(str(path), os.O_WRONLY | os.O_CREAT | os.O_EXCL, 0o600)
            os.close(fd)
            return path
        except OSError as exc:
            errors.append(f"{directory}: {compact_error(str(exc), 120)}")
    raise WorkerError(f"cannot create codex output temp file; {'; '.join(errors[:5])}")


def safe_key(text: str) -> str:
    digest = hashlib.sha1(text.encode("utf-8")).hexdigest()[:14]
    label = re.sub(r"[^0-9A-Za-z가-힣]+", "_", text).strip("_")[:42]
    return f"{label}_{digest}" if label else digest


def firebase_base() -> str:
    return os.environ.get("FIREBASE_BASE_URL", DEFAULT_FIREBASE).rstrip("/")


def fb_url(path: str) -> str:
    safe = "/".join(urllib.parse.quote(part, safe="") for part in path.split("/") if part)
    return f"{firebase_base()}/{safe}.json"


def fb_get(path: str, timeout: int = 20) -> Any:
    try:
        with urllib.request.urlopen(fb_url(path), timeout=timeout) as resp:
            body = resp.read().decode("utf-8")
    except urllib.error.HTTPError as exc:
        raise WorkerError(f"firebase GET {path} HTTP {exc.code}") from exc
    if not body or body == "null":
        return None
    return json.loads(body)


def fb_write(path: str, payload: Any, method: str = "PUT", timeout: int = 20) -> Any:
    assert_firebase_safe_object_keys(payload)
    data = json.dumps(payload, ensure_ascii=False, separators=(",", ":")).encode("utf-8")
    req = urllib.request.Request(
        fb_url(path),
        data=data,
        method=method,
        headers={"Content-Type": "application/json; charset=utf-8"},
    )
    try:
        with urllib.request.urlopen(req, timeout=timeout) as resp:
            body = resp.read().decode("utf-8")
    except urllib.error.HTTPError as exc:
        detail = exc.read().decode("utf-8", errors="replace")[:300]
        raise WorkerError(f"firebase {method} {path} HTTP {exc.code} {detail}") from exc
    return json.loads(body) if body and body != "null" else None


def fb_put(path: str, payload: Any) -> Any:
    return fb_write(path, payload, "PUT")


def fb_patch(path: str, payload: dict[str, Any]) -> Any:
    return fb_write(path, payload, "PATCH")


def sanitize_key(value: str | None, fallback: str = "request") -> str:
    text = str(value or "").strip() or fallback
    text = re.sub(r"[.#$/\[\]?\s]+", "_", text)
    text = re.sub(r"[^0-9A-Za-z가-힣_-]+", "_", text)
    return text[:180] or fallback


def skill_paths() -> list[Path]:
    return [
        BASE_DIR / ".agents" / "skills" / SKILL_NAME / "SKILL.md",
        Path.home() / ".agents" / "skills" / SKILL_NAME / "SKILL.md",
    ]


def read_skill() -> str:
    for path in skill_paths():
        if path.exists():
            return path.read_text(encoding="utf-8").strip()
    raise WorkerError(f"missing skill: {SKILL_NAME}")


def normalize_ts_ms(value: Any) -> int:
    try:
        numeric = int(float(value))
    except (TypeError, ValueError):
        return now_ms()
    if 0 < numeric < 10_000_000_000:
        return numeric * 1000
    return numeric


def clean_geocode_query(text: str) -> str:
    cleaned = str(text or "").replace("_", " ")
    cleaned = re.sub(r"\[[^\]]+\]", " ", cleaned)
    cleaned = re.sub(r"\([^)]*수저[^)]*\)", " ", cleaned)
    cleaned = re.sub(r"(?:#|\*|샵|샾|별)\s*\d{2,8}\s*(?:#|\*|샵|샾|별)?", " ", cleaned)
    cleaned = re.sub(r"\b\d{3,5}\s*호\b.*$", " ", cleaned)
    cleaned = re.sub(r"\b\d{1,2}\s*층\b.*$", " ", cleaned)
    cleaned = re.sub(r"(\d+)번\s+길", r"\1번길", cleaned)
    cleaned = re.sub(r"\s+", " ", cleaned).strip()
    return cleaned


def usable_geocode_query(text: str) -> bool:
    value = clean_geocode_query(text)
    if len(compact(value)) < 8:
        return False
    if not re.search(r"\d", value):
        return False
    return bool(re.search(r"(시|군|읍|면|동|리|로|길|아파트|빌|빌라|오피스텔)", value))


def extract_building_name(text: str) -> str:
    cleaned = clean_geocode_query(text)
    patterns = [
        r"([가-힣A-Za-z0-9]+(?:아파트|오피스텔|빌라|빌딩|빌|맨션|타운|하우스|캐슬|파크|스위트|에버빌|푸르지오|자이|래미안|힐스테이트)[가-힣A-Za-z0-9]*)",
        r"([가-힣A-Za-z0-9]+(?:원룸|주택)[가-힣A-Za-z0-9]*)",
    ]
    for pattern in patterns:
        match = re.search(pattern, cleaned)
        if match:
            return match.group(1)
    return ""


KNOWN_SPACING_WORDS = (
    "배달주소",
    "도로명주소",
    "지번주소",
    "고객요청",
    "가게요청",
    "요청사항",
    "현관비번",
    "현관비밀번호",
    "공동현관",
    "비밀번호",
    "카드결제",
    "현금결제",
    "문앞",
    "문자주세요",
    "전화주세요",
    "벨누르지마",
    "벨누르지말아주세요",
    "초인종누르지마",
    "노크하지마",
    "수저빼주세요",
    "치킨무빼주세요",
)
IMPORTANT_LAYOUT_RE = re.compile(
    r"(배달주소|주소|도로명|지번|고객요청|가게요청|요청사항|현관|비번|비밀번호|공동현관|"
    r"벨|초인종|노크|문앞|문자|전화|카드|현금|결제|취소|추가|신규)"
)
BUILDING_NAME_RE = re.compile(
    r"([가-힣A-Za-z0-9]+(?:아파트|오피스텔|빌라|빌딩|빌|맨션|타운|하우스|캐슬|파크|"
    r"스위트|에버빌|푸르지오|자이|래미안|힐스테이트|원룸|주택)[가-힣A-Za-z0-9]*)"
)
REQUEST_LABEL_RE = re.compile(r"(고객요청|가게요청|요청사항|건물명|아파트명|단지명|목적지)\s*[:：]?\s*")


def repair_spacing_text(text: str) -> str:
    repaired = re.sub(r"\s+", " ", str(text or "").replace("\u00a0", " ")).strip()
    if not repaired:
        return ""
    for word in KNOWN_SPACING_WORDS:
        pattern = r"\s*".join(re.escape(ch) for ch in word)
        repaired = re.sub(pattern, word, repaired, flags=re.IGNORECASE)
    repaired = re.sub(r"(\d+)\s*번\s*길", r"\1번길", repaired)
    repaired = re.sub(r"(\d+)\s+(동|호|층|라인|번지)\b", r"\1\2", repaired)
    repaired = re.sub(r"\b([A-Za-z])\s+라인\b", r"\1라인", repaired)
    repaired = re.sub(r"([#*])\s+(\d)", r"\1\2", repaired)
    repaired = re.sub(r"(\d)\s+([#*])", r"\1\2", repaired)
    repaired = re.sub(r"\s+", " ", repaired).strip()
    return repaired


def raw_text_lines(raw_text: str) -> list[str]:
    return [line.strip() for line in str(raw_text or "").splitlines() if line.strip()]


def important_line_windows(lines: list[str]) -> list[dict[str, Any]]:
    windows: list[dict[str, Any]] = []
    for idx in range(len(lines)):
        raw_window = " ".join(lines[idx : idx + 3])
        repaired = repair_spacing_text(raw_window)
        if IMPORTANT_LAYOUT_RE.search(repaired):
            windows.append(
                {
                    "start_line": idx + 1,
                    "end_line": min(len(lines), idx + 3),
                    "text": clean_text(repaired, 350),
                }
            )
        if len(windows) >= 8:
            break
    return windows


def build_text_layout_hints(item: dict[str, Any]) -> dict[str, Any]:
    lines = raw_text_lines(str(item.get("raw_text") or ""))
    if not lines:
        return {}
    joined = " ".join(lines)
    repaired = repair_spacing_text(joined)
    compact_hangul = re.sub(r"(?<=[가-힣])\s+(?=[가-힣])", "", joined)
    hints = {
        "line_count": len(lines),
        "joined_text": clean_text(joined, 2500),
        "spacing_repaired_text": clean_text(repaired, 2500),
        "hangul_compact_text": clean_text(compact_hangul, 2500),
    }
    windows = important_line_windows(lines)
    if windows:
        hints["important_line_windows"] = windows
    return hints


def enrich_with_text_layout_hints(item: dict[str, Any]) -> dict[str, Any]:
    hints = build_text_layout_hints(item)
    if not hints:
        return item
    enriched = dict(item)
    enriched["text_layout_hints"] = hints
    return enriched


def extract_building_candidates(text: str, source: str) -> list[dict[str, Any]]:
    cleaned = repair_spacing_text(text)
    if not cleaned:
        return []
    candidates: list[dict[str, Any]] = []

    def add_candidate(raw_building: str, evidence_text: str) -> None:
        building = clean_text(raw_building, 120)
        building = REQUEST_LABEL_RE.sub("", building).strip(" -_/.,")
        building = re.sub(r"\s+\d{1,4}동.*$", "", building).strip()
        building = re.sub(r"\s+\d{1,5}호.*$", "", building).strip()
        building = re.sub(r"\s+(문앞|문 앞|현관|비번|벨|노크|전화|문자).*$", "", building).strip()
        if not building or len(compact(building)) < 2:
            return
        if re.search(r"(시|군|읍|면|로|길|번길|번지)", building) and not BUILDING_NAME_RE.search(building):
            return
        if any(compact(building) == compact(existing["building"]) for existing in candidates):
            return
        candidates.append(
            {
                "building": building,
                "source": source,
                "evidence": clean_text(evidence_text, 180),
            }
        )

    for match in BUILDING_NAME_RE.finditer(cleaned):
        start = max(0, match.start() - 30)
        end = min(len(cleaned), match.end() + 45)
        add_candidate(match.group(1), cleaned[start:end])

    request_like = source in {"customer_request", "store_request"} or REQUEST_LABEL_RE.search(cleaned)
    if request_like:
        patterns: list[str] = []
        if source in {"customer_request", "store_request"}:
            patterns.append(r"^\s*([가-힣A-Za-z0-9][가-힣A-Za-z0-9 ]{1,35}?)\s+\d{1,4}동\b")
        patterns.extend(
            [
                r"(?:고객요청|가게요청|요청사항|건물명|아파트명|단지명|목적지)\s*[:：]?\s*([가-힣A-Za-z0-9][가-힣A-Za-z0-9 ]{1,35}?)\s+\d{1,4}동\b",
                r"(?:고객요청|가게요청|요청사항|건물명|아파트명|단지명|목적지)\s*[:：]?\s*([가-힣A-Za-z0-9][가-힣A-Za-z0-9 ]{1,35}?)(?=\s+(?:문앞|문 앞|현관|비번|벨|노크|전화|문자)|$)",
            ]
        )
        for pattern in patterns:
            for match in re.finditer(pattern, cleaned):
                add_candidate(match.group(1), cleaned[max(0, match.start() - 20) : min(len(cleaned), match.end() + 45)])
    return candidates


def customer_building_candidates(item: dict[str, Any]) -> list[dict[str, Any]]:
    sources: list[tuple[str, str]] = []
    hints = item.get("text_layout_hints") if isinstance(item.get("text_layout_hints"), dict) else {}
    if isinstance(hints, dict):
        sources.extend(
            [
                ("text_layout_hints.spacing_repaired_text", str(hints.get("spacing_repaired_text") or "")),
                ("text_layout_hints.joined_text", str(hints.get("joined_text") or "")),
            ]
        )
    sources.extend(
        [
            ("raw_text", str(item.get("raw_text") or "")),
            ("customer_request", str(item.get("customer_request") or "")),
            ("store_request", str(item.get("store_request") or "")),
        ]
    )

    out: list[dict[str, Any]] = []
    seen: set[str] = set()
    for source, text in sources:
        for candidate in extract_building_candidates(text, source):
            key = compact(candidate["building"])
            if not key or key in seen:
                continue
            seen.add(key)
            out.append(candidate)
            if len(out) >= 5:
                return out
    return out


def enrich_with_customer_building_candidates(item: dict[str, Any]) -> dict[str, Any]:
    candidates = customer_building_candidates(item)
    if not candidates:
        return item
    enriched = dict(item)
    enriched["customer_building_candidates"] = candidates
    enriched["address_conflict_risk"] = {
        "enabled": True,
        "reason": "customer_entered_building_name",
        "rule": "prefer customer-entered building over road/jibun/geocode when they conflict",
    }
    return enriched


def precheck_building(item: dict[str, Any]) -> str:
    candidates = item.get("customer_building_candidates")
    if isinstance(candidates, list):
        for candidate in candidates:
            if isinstance(candidate, dict):
                building = clean_text(candidate.get("building"), 120)
                if building:
                    return building
    result = item.get("precheck_result") if isinstance(item.get("precheck_result"), dict) else item.get("first_result")
    if isinstance(result, dict):
        address = result.get("address")
        if isinstance(address, dict):
            building = clean_text(address.get("building"), 120)
            if building:
                return building
    for key in ("raw_address", "short_address", "known_road_address"):
        building = extract_building_name(str(item.get(key) or ""))
        if building:
            return building
    return ""


def raw_text_address_candidates(raw_text: str) -> list[str]:
    out: list[str] = []
    lines = raw_text_lines(raw_text)
    for idx, line in enumerate(lines):
        repaired_line = repair_spacing_text(line)
        if not re.search(r"(배달주소|주소|도로명|지번)", repaired_line):
            continue
        candidate = re.sub(r"^.*?(?:배달주소|주소|도로명|지번)\s*[:：]?\s*", "", repaired_line).strip()
        if not candidate and idx + 1 < len(lines):
            candidate = repair_spacing_text(" ".join(lines[idx + 1 : idx + 3]))
        if candidate and candidate not in out:
            out.append(candidate)
    return out


def geocode_queries_for_item(item: dict[str, Any]) -> list[str]:
    seeds: list[str] = []
    for key in ("known_road_address", "raw_address", "short_address"):
        value = clean_geocode_query(str(item.get(key) or ""))
        if value and value not in seeds:
            seeds.append(value)
    for value in raw_text_address_candidates(str(item.get("raw_text") or "")):
        cleaned = clean_geocode_query(value)
        if cleaned and cleaned not in seeds:
            seeds.append(cleaned)

    queries: list[str] = []

    def add(value: str) -> None:
        cleaned = clean_geocode_query(value)
        if usable_geocode_query(cleaned) and cleaned not in queries:
            queries.append(cleaned)

    for seed in seeds:
        add(seed)
        if seed and not re.search(r"(시|군|도)\s", seed):
            add(f"경기 이천시 {seed}")
            add(f"경기 여주시 {seed}")
    return queries


def load_naver_keys() -> tuple[str, str]:
    client_id = str(fb_get(NAVER_CLIENT_ID_PATH) or "").strip()
    client_secret = str(fb_get(NAVER_CLIENT_SECRET_PATH) or "").strip()
    return client_id, client_secret


def cached_geocode(query: str) -> dict[str, Any] | None:
    cached = fb_get(f"{GEOCODE_CACHE_PATH}/{safe_key(query)}", timeout=8)
    if isinstance(cached, dict) and cached.get("status") in {"ok", "not_found", "invalid_coord", "error"}:
        return cached
    return None


def cache_geocode(query: str, payload: dict[str, Any]) -> None:
    fb_put(f"{GEOCODE_CACHE_PATH}/{safe_key(query)}", payload)


def naver_geocode(query: str, naver_keys: tuple[str, str]) -> dict[str, Any]:
    client_id, client_secret = naver_keys
    if not client_id or not client_secret:
        return {"status": "no_key", "query": query}
    url = f"{NAVER_GEOCODE_URL}?query={urllib.parse.quote(query)}"
    req = urllib.request.Request(
        url,
        headers={
            "X-NCP-APIGW-API-KEY-ID": client_id,
            "X-NCP-APIGW-API-KEY": client_secret,
        },
    )
    try:
        with urllib.request.urlopen(req, timeout=8) as resp:
            body = json.loads(resp.read().decode("utf-8") or "{}")
    except Exception as exc:
        return {"status": "error", "query": query, "error": compact_error(str(exc), 160), "ts": now_ms()}

    addresses = body.get("addresses") or []
    if not addresses:
        return {"status": "not_found", "query": query, "ts": now_ms()}

    first = addresses[0]
    building = ""
    for element in first.get("addressElements") or []:
        types = element.get("types") or []
        if "BUILDING_NAME" in types:
            building = str(element.get("longName") or element.get("shortName") or "")
            break

    return {
        "status": "ok",
        "query": query,
        "road_address": str(first.get("roadAddress") or ""),
        "jibun_address": str(first.get("jibunAddress") or ""),
        "building": building,
        "lat": first.get("y"),
        "lng": first.get("x"),
        "source": "naver_geocode",
        "ts": now_ms(),
    }


def enrich_with_naver_candidates(item: dict[str, Any], args: argparse.Namespace) -> dict[str, Any]:
    if not args.naver_building_lookup or precheck_building(item):
        return item

    queries = geocode_queries_for_item(item)[: max(0, args.max_naver_queries)]
    if not queries:
        return item

    enriched = dict(item)
    candidates: list[dict[str, Any]] = []
    keys: tuple[str, str] | None = None
    lookup_status = "not_found"
    for query in queries:
        try:
            cached = cached_geocode(query)
            result = cached or {}
            if not cached:
                if keys is None:
                    keys = load_naver_keys()
                result = naver_geocode(query, keys)
                if result.get("status") != "no_key":
                    cache_geocode(query, result)
        except Exception as exc:
            result = {"status": "error", "query": query, "error": compact_error(str(exc), 160)}
        if result.get("status") == "ok":
            candidate = {
                "query": result.get("query") or query,
                "building": result.get("building") or "",
                "road_address": result.get("road_address") or "",
                "jibun_address": result.get("jibun_address") or "",
                "source": result.get("source") or "naver_geocode_cache",
            }
            candidates.append(candidate)
            if candidate["building"]:
                lookup_status = "building_found"
                break
            lookup_status = "address_found"
        elif lookup_status == "not_found" and result.get("status") in {"no_key", "error"}:
            lookup_status = str(result.get("status") or "error")

    if candidates:
        enriched["naver_map_candidates"] = candidates
    enriched["naver_map_lookup"] = {
        "enabled": True,
        "reason": "building_missing",
        "status": lookup_status,
        "query_count": len(queries),
    }
    return enriched


def load_pending(args: argparse.Namespace) -> list[tuple[str, dict[str, Any]]]:
    raw = fb_get(REQUESTS_PATH) or {}
    if not isinstance(raw, dict):
        return []
    stale_before = now_ms() - args.running_stale_ms
    pending: list[tuple[str, dict[str, Any]]] = []
    for key, item in raw.items():
        if not isinstance(item, dict):
            continue
        status = str(item.get("status") or "pending").lower()
        running_stale = status == "running" and normalize_ts_ms(item.get("started_at_ms")) < stale_before
        if status != "pending" and not running_stale:
            continue
        if args.device_key and str(item.get("device_key") or "") != args.device_key:
            continue
        if not (item.get("raw_text") or item.get("raw_address") or item.get("customer_request") or item.get("store_request")):
            continue
        pending.append((str(key), item))
    pending.sort(key=lambda pair: (normalize_ts_ms(pair[1].get("created_at_ms")), pair[0]))
    return pending[: args.limit]


def public_request(item: dict[str, Any]) -> dict[str, Any]:
    keys = [
        "request_id",
        "device_key",
        "device_role",
        "order_timestamp",
        "order_number",
        "pack_order_id",
        "channel",
        "raw_address",
        "short_address",
        "raw_text",
        "text_layout_hints",
        "customer_building_candidates",
        "address_conflict_risk",
        "known_road_address",
        "customer_request",
        "store_request",
        "payment_method",
        "reason",
        "trigger",
        "trigger_reason",
        "previous_failed",
        "previous_result",
        "naver_map_lookup",
        "naver_map_candidates",
        "precheck_model",
        "precheck_success",
        "precheck_result",
        "first_model",
        "first_success",
        "first_result",
    ]
    public = {key: item.get(key) for key in keys if key in item}
    if "precheck_model" not in public and "first_model" in public:
        public["precheck_model"] = public["first_model"]
    if "precheck_success" not in public and "first_success" in public:
        public["precheck_success"] = public["first_success"]
    if "precheck_result" not in public and "first_result" in public:
        public["precheck_result"] = public["first_result"]
    return public


def build_prompt(req_id: str, item: dict[str, Any], skill: str) -> str:
    schema_example = {
        "schema_version": 2,
        "address": {field: "" for field in ADDRESS_FIELDS},
        "request": {field: "" for field in REQUEST_FIELDS},
        "confidence": 0.0,
        "field_confidence": nested_field_map_defaults(0.0),
        "evidence_refs": nested_field_map_defaults(""),
        "conflicts": [],
        "apply_policy": nested_field_map_defaults("candidate"),
        "requires_user_confirm": False,
        "raw_supported_fields": [],
        "notes": "",
    }
    return (
        "DeliveryHelper GPT 1차 재검토를 수행하세요. LocalAI/Gemini/Groq 0차 선작업 결과는 참고만 하세요.\n"
        f"가능하면 ${SKILL_NAME} 스킬을 사용하세요. 스킬이 보이지 않으면 아래 SKILL.md의 Source Priority, Find And Analyze, Output 규칙을 그대로 따르세요.\n"
        "반드시 JSON 객체 하나만 출력하세요. 설명, 마크다운, 코드블록은 금지입니다.\n\n"
        "## SKILL.md\n"
        f"{skill}\n\n"
        "## Firebase request\n"
        f"{json.dumps(public_request(item), ensure_ascii=False, indent=2)[:12000]}\n\n"
        "## Required output reminder\n"
        f"{json.dumps(schema_example, ensure_ascii=False, separators=(',', ':'))}\n"
        "\n"
        "출력은 후보/감사 결과입니다. 주소, 건물명, 동, 호, 공동현관 비밀번호를 확정값처럼 쓰지 마세요. "
        "raw evidence 없는 주소/건물/동/호/password는 auto apply 금지이며 apply_policy는 candidate 또는 confirm이어야 합니다. "
        "필드별 evidence_refs에는 raw_text/customer_request/store_request/known_road_address/naver_map_candidates 같은 근거 위치를 짧게 적으세요. "
        "conflicts에는 raw, 기존 확정값, Naver 후보, 0차 결과가 충돌한 지점을 남기세요. "
        "raw_supported_fields에는 raw evidence로 직접 지지되는 필드만 dotted name으로 넣으세요.\n"
        "confirmed road/known_road_address는 보존하세요. customer-entered building/raw 건물명을 Naver 후보보다 우선하세요. "
        "Naver 후보는 raw/road 일치 근거가 없으면 과신하지 말고 candidate로만 두세요. "
        "ho는 전체 자릿수를 보존하고, line은 raw에 명시된 경우에만 채우세요. "
        "request flags와 password는 raw 근거가 있으면 auto 가능하지만, password 기호(#, *)와 숫자는 그대로 보존하세요.\n"
    )


def codex_command(output_path: str, args: argparse.Namespace) -> list[str]:
    configured_bin = getattr(args, "codex_bin", "")
    if not configured_bin or not is_executable_file(str(configured_bin)):
        args.codex_bin = resolve_codex_bin(str(configured_bin))
    cmd = [
        args.codex_bin,
        "exec",
        "--ignore-user-config",
        "--json",
        "-o",
        output_path,
        "--disable",
        "shell_tool",
        "-c",
        'web_search="disabled"',
        "-c",
        "tools.web_search=false",
        "-c",
        'sandbox_mode="read-only"',
        "-c",
        'approval_policy="never"',
        "--skip-git-repo-check",
        "--ignore-rules",
        "--sandbox",
        "read-only",
        "-C",
        args.cwd,
    ]
    if args.model:
        cmd.extend(["-m", args.model])
    if args.reasoning_effort:
        cmd.extend(["-c", f'model_reasoning_effort="{args.reasoning_effort}"'])
    cmd.append("-")
    return cmd


def run_codex(prompt: str, args: argparse.Namespace) -> str:
    output_path = create_temp_output_path()
    try:
        proc = subprocess.run(
            codex_command(str(output_path), args),
            input=prompt,
            text=True,
            capture_output=True,
            timeout=args.timeout_sec,
            cwd=str(BASE_DIR),
        )
        final = ""
        try:
            final = output_path.read_text(encoding="utf-8", errors="replace").strip()
        except OSError as exc:
            if proc.returncode == 0:
                raise WorkerError(f"codex output read failed: {compact_error(str(exc), 180)}") from exc
        if proc.returncode != 0:
            raise WorkerError(compact_error(proc.stderr or proc.stdout or "codex exec failed"))
        if not final:
            raise WorkerError("empty codex output")
        return final
    except subprocess.TimeoutExpired as exc:
        raise WorkerError(f"codex timeout after {args.timeout_sec}s") from exc
    except OSError as exc:
        raise WorkerError(f"codex exec start failed: {compact_error(str(exc), 220)}") from exc
    finally:
        safe_unlink(output_path)


def extract_json_object(text: str) -> dict[str, Any]:
    cleaned = text.strip()
    if cleaned.startswith("```"):
        cleaned = re.sub(r"^```(?:json)?", "", cleaned, flags=re.IGNORECASE).strip()
        cleaned = re.sub(r"```$", "", cleaned).strip()
    try:
        parsed = json.loads(cleaned)
    except json.JSONDecodeError:
        start = cleaned.find("{")
        end = cleaned.rfind("}")
        if start < 0 or end <= start:
            raise WorkerError("codex output has no JSON object")
        parsed = json.loads(cleaned[start : end + 1])
    if not isinstance(parsed, dict):
        raise WorkerError("codex output is not a JSON object")
    return parsed


def clean_text(value: Any, limit: int = 300) -> str:
    return re.sub(r"\s+", " ", str(value or "")).strip()[:limit]


def clean_flag(value: Any) -> str:
    text = str(value or "").strip().upper()
    if text in {"O", "Y", "YES", "TRUE", "1"}:
        return "O"
    if text in {"X", "N", "NO", "FALSE", "0"}:
        return "X"
    return ""


def normalize_schema_version(value: Any) -> int:
    try:
        version = int(float(value))
    except (TypeError, ValueError):
        version = 2
    return 2 if version >= 2 else 2


def normalize_field_name(section: str, field: str) -> str:
    raw = str(field or "").strip()
    if "." in raw:
        candidate = raw
    else:
        candidate = f"{section}.{raw}" if section else raw
    return candidate if candidate in FIELD_NAMES else ""


def normalize_field_map(value: Any, cleaner) -> dict[str, Any]:
    if not isinstance(value, dict):
        return {}
    out: dict[str, Any] = {}
    for key, entry in value.items():
        section = str(key or "").strip()
        if isinstance(entry, dict) and section in {"address", "request"}:
            for subkey, subentry in entry.items():
                field = normalize_field_name(section, str(subkey))
                if field:
                    out[field] = cleaner(subentry)
            continue
        field = normalize_field_name("", str(key))
        if field:
            out[field] = cleaner(entry)
    return out


def clean_confidence(value: Any) -> float:
    try:
        confidence = float(value)
    except (TypeError, ValueError):
        return 0.0
    return max(0.0, min(1.0, confidence))


def clean_apply_policy(value: Any) -> str:
    policy = str(value or "").strip().lower()
    return policy if policy in APPLY_POLICIES else "candidate"


def normalize_raw_supported_fields(value: Any) -> list[str]:
    fields: list[str] = []

    def add(field: str, section: str = "") -> None:
        normalized = normalize_field_name(section, field)
        if normalized and normalized not in fields:
            fields.append(normalized)

    if isinstance(value, list):
        for item in value:
            add(str(item or ""))
    elif isinstance(value, dict):
        for key, item in value.items():
            section = str(key or "").strip()
            if isinstance(item, dict) and section in {"address", "request"}:
                for subkey, subitem in item.items():
                    if subitem:
                        add(str(subkey), section)
                continue
            if isinstance(item, bool):
                if item:
                    add(str(key))
            elif isinstance(item, (str, int, float)) and str(item).strip().lower() not in {"", "false", "0", "no", "x"}:
                add(str(key))
            elif isinstance(item, list):
                for subitem in item:
                    add(str(subitem or ""))
    return fields


def normalize_conflicts(value: Any) -> list[str]:
    conflicts: list[str] = []

    def add(text: Any) -> None:
        cleaned = clean_text(text, 220)
        if cleaned and cleaned not in conflicts:
            conflicts.append(cleaned)

    if isinstance(value, list):
        for item in value:
            if isinstance(item, dict):
                add(json.dumps(item, ensure_ascii=False, separators=(",", ":")))
            else:
                add(item)
    elif isinstance(value, dict):
        for key, item in value.items():
            if isinstance(item, (list, tuple)):
                for subitem in item:
                    add(f"{key}: {subitem}")
            elif item:
                add(f"{key}: {item}")
    elif value:
        add(value)
    return conflicts


def normalize_requires_user_confirm(value: Any) -> bool | list[str]:
    if isinstance(value, bool):
        return value
    fields: list[str] = []
    def add(field_name: str, section: str = "") -> None:
        field = normalize_field_name(section, field_name)
        if field and field not in fields:
            fields.append(field)

    if isinstance(value, list):
        for item in value:
            field = normalize_field_name("", str(item or ""))
            if field and field not in fields:
                fields.append(field)
    elif isinstance(value, dict):
        for key, item in value.items():
            section = str(key or "").strip()
            if isinstance(item, dict) and section in {"address", "request"}:
                for subkey, subitem in item.items():
                    if subitem:
                        add(str(subkey), section)
                continue
            if item:
                add(str(key))
    elif str(value or "").strip().lower() in {"true", "yes", "1", "confirm"}:
        return True
    return fields if fields else False


def default_apply_policy(raw_supported_fields: list[str]) -> dict[str, str]:
    return {field: ("candidate" if field in raw_supported_fields else "reject") for field in FIELD_NAMES}


def fill_field_defaults(value: dict[str, Any], default: Any) -> dict[str, Any]:
    out = {field: default for field in FIELD_NAMES}
    out.update(value)
    return out


def nested_field_map_defaults(default: Any) -> dict[str, dict[str, Any]]:
    return {
        "address": {field: default for field in ADDRESS_FIELDS},
        "request": {field: default for field in REQUEST_FIELDS},
    }


def nest_field_map(value: dict[str, Any]) -> dict[str, dict[str, Any]]:
    out: dict[str, dict[str, Any]] = {"address": {}, "request": {}}
    for dotted_field, entry in value.items():
        field = normalize_field_name("", str(dotted_field))
        if not field:
            continue
        section, subfield = field.split(".", 1)
        out[section][subfield] = entry
    return out


def normalize_result(parsed: dict[str, Any]) -> dict[str, Any]:
    addr_in = parsed.get("address") if isinstance(parsed.get("address"), dict) else {}
    req_in = parsed.get("request") if isinstance(parsed.get("request"), dict) else {}
    address = {key: clean_text(addr_in.get(key), 120) for key in ADDRESS_FIELDS}
    request = {key: clean_flag(req_in.get(key)) for key in FLAGS}
    request["password"] = clean_text(req_in.get("password"), 160)
    request["specialNotes"] = clean_text(req_in.get("specialNotes"), 300)
    raw_supported_fields = normalize_raw_supported_fields(parsed.get("raw_supported_fields"))
    apply_policy = normalize_field_map(parsed.get("apply_policy"), clean_apply_policy)
    if not apply_policy:
        apply_policy = default_apply_policy(raw_supported_fields)
    result = {
        "schema_version": normalize_schema_version(parsed.get("schema_version")),
        "address": address,
        "request": request,
        "confidence": clean_confidence(parsed.get("confidence", 0.0)),
        "field_confidence": nest_field_map(
            fill_field_defaults(normalize_field_map(parsed.get("field_confidence"), clean_confidence), 0.0)
        ),
        "evidence_refs": nest_field_map(
            fill_field_defaults(
                normalize_field_map(parsed.get("evidence_refs"), lambda item: clean_text(item, 220)),
                "",
            )
        ),
        "conflicts": normalize_conflicts(parsed.get("conflicts")),
        "apply_policy": nest_field_map(fill_field_defaults(apply_policy, "reject")),
        "requires_user_confirm": normalize_requires_user_confirm(parsed.get("requires_user_confirm")),
        "raw_supported_fields": raw_supported_fields,
        "notes": clean_text(parsed.get("notes"), 300),
    }
    assert_firebase_safe_object_keys(result)
    return result


def mark_running(req_id: str, args: argparse.Namespace) -> None:
    fb_patch(
        f"{REQUESTS_PATH}/{sanitize_key(req_id)}",
        {
            "status": "running",
            "worker": args.node,
            "model": args.model,
            "reasoning_effort": args.reasoning_effort,
            "started_at_ms": now_ms(),
        },
    )


def mark_done(req_id: str, item: dict[str, Any], result: dict[str, Any], args: argparse.Namespace, elapsed_ms: int) -> None:
    key = sanitize_key(req_id)
    payload = {
        "schema_version": result["schema_version"],
        "status": "done",
        "request_id": req_id,
        "device_key": str(item.get("device_key") or ""),
        "device_role": str(item.get("device_role") or ""),
        "order_timestamp": normalize_ts_ms(item.get("order_timestamp")),
        "order_number": str(item.get("order_number") or ""),
        "pack_order_id": str(item.get("pack_order_id") or ""),
        "address": result["address"],
        "request": result["request"],
        "confidence": result["confidence"],
        "field_confidence": result["field_confidence"],
        "evidence_refs": result["evidence_refs"],
        "conflicts": result["conflicts"],
        "apply_policy": result["apply_policy"],
        "requires_user_confirm": result["requires_user_confirm"],
        "raw_supported_fields": result["raw_supported_fields"],
        "notes": result["notes"],
        "audit": {
            "reason": str(item.get("reason") or item.get("trigger_reason") or ""),
            "trigger": str(item.get("trigger") or ""),
        },
        "model": args.model,
        "reasoning_effort": args.reasoning_effort,
        "source": "deliveryhelper_gpt_reanalyze_worker",
        "worker": args.node,
        "elapsed_ms": elapsed_ms,
        "finished_at_ms": now_ms(),
    }
    fb_put(f"{RESULTS_PATH}/{key}", payload)
    fb_patch(
        f"{REQUESTS_PATH}/{key}",
        {
            "status": "done",
            "result_path": f"{RESULTS_PATH}/{key}",
            "finished_at_ms": payload["finished_at_ms"],
            "elapsed_ms": elapsed_ms,
            "worker": args.node,
            "model": args.model,
        },
    )


def mark_error(req_id: str, error: str, args: argparse.Namespace) -> None:
    fb_patch(
        f"{REQUESTS_PATH}/{sanitize_key(req_id)}",
        {
            "status": "error",
            "error": compact_error(error),
            "failed_at_ms": now_ms(),
            "worker": args.node,
            "model": args.model,
        },
    )


def write_heartbeat(
    args: argparse.Namespace,
    queue_size: int,
    status: str,
    error: str = "",
    *,
    current_request: str = "",
) -> None:
    payload = {
        "alive": True,
        "ts": now_ms(),
        "node": args.node,
        "status": status,
        "queue_size": queue_size,
        "device_key_filter": args.device_key,
        "model": args.model,
        "reasoning_effort": args.reasoning_effort,
        "last_error": compact_error(error, 250) if error else "",
    }
    if current_request:
        payload["current_request"] = current_request
    fb_put(f"{HEARTBEAT_PATH}/{sanitize_key(args.node)}", payload)


def process_one(req_id: str, item: dict[str, Any], skill: str, args: argparse.Namespace) -> None:
    start = now_ms()
    mark_running(req_id, args)
    try:
        write_heartbeat(args, 1, "processing", current_request=req_id)
    except Exception as exc:
        log(f"processing heartbeat failed request={req_id}: {compact_error(str(exc), 180)}")
    enriched_item = enrich_with_text_layout_hints(item)
    enriched_item = enrich_with_customer_building_candidates(enriched_item)
    enriched_item = enrich_with_naver_candidates(enriched_item, args)
    if "naver_map_lookup" in enriched_item:
        try:
            fb_patch(
                f"{REQUESTS_PATH}/{sanitize_key(req_id)}",
                {
                    "naver_map_lookup": enriched_item.get("naver_map_lookup"),
                    "naver_map_candidates": enriched_item.get("naver_map_candidates", []),
                },
            )
        except Exception as exc:
            log(f"naver lookup audit patch failed request={req_id}: {compact_error(str(exc), 180)}")
    prompt = build_prompt(req_id, enriched_item, skill)
    final = run_codex(prompt, args)
    parsed = normalize_result(extract_json_object(final))
    mark_done(req_id, item, parsed, args, now_ms() - start)
    log(f"done request={req_id} model={args.model} elapsed={now_ms() - start}ms")


def run_loop(args: argparse.Namespace) -> int:
    skill = read_skill()
    last_heartbeat = 0
    loop_errors = 0
    while True:
        try:
            pending = load_pending(args)
            loop_errors = 0
            if now_ms() - last_heartbeat > args.heartbeat_interval_sec * 1000:
                write_heartbeat(args, len(pending), "watching")
                last_heartbeat = now_ms()
            if not pending:
                if not args.watch:
                    return 0
                time.sleep(args.poll_interval_sec)
                continue
            for req_id, item in pending:
                try:
                    process_one(req_id, item, skill, args)
                except Exception as exc:
                    error = compact_error(str(exc))
                    log(f"error request={req_id}: {error}")
                    try:
                        mark_error(req_id, error, args)
                    except Exception:
                        pass
                    write_heartbeat(args, len(pending), "error", error)
            if not args.watch:
                return 0
        except KeyboardInterrupt:
            return 130
        except Exception as exc:
            error = compact_error(str(exc))
            loop_errors += 1
            log(f"loop error: {error}")
            try:
                write_heartbeat(args, 0, "error", error)
            except Exception:
                pass
            if not args.watch:
                return 1
            if loop_errors >= args.max_loop_errors:
                log(f"too many loop errors ({loop_errors}); exiting for wrapper restart")
                return 1
            time.sleep(args.poll_interval_sec)


def parse_args(argv: list[str]) -> argparse.Namespace:
    parser = argparse.ArgumentParser(description="DeliveryHelper GPT first-review worker")
    parser.add_argument("--watch", action="store_true", help="poll continuously")
    parser.add_argument("--limit", type=int, default=int(os.environ.get("DELIVERYHELPER_GPT_LIMIT", "1")))
    parser.add_argument("--poll-interval-sec", type=int, default=int(os.environ.get("DELIVERYHELPER_GPT_POLL_INTERVAL_SEC", "10")))
    parser.add_argument("--heartbeat-interval-sec", type=int, default=int(os.environ.get("DELIVERYHELPER_GPT_HEARTBEAT_INTERVAL_SEC", "60")))
    parser.add_argument("--running-stale-ms", type=int, default=int(os.environ.get("DELIVERYHELPER_GPT_RUNNING_STALE_MS", "600000")))
    parser.add_argument("--timeout-sec", type=int, default=int(os.environ.get("DELIVERYHELPER_GPT_TIMEOUT_SEC", "180")))
    parser.add_argument("--max-loop-errors", type=int, default=int(os.environ.get("DELIVERYHELPER_GPT_MAX_LOOP_ERRORS", "12")))
    parser.add_argument("--model", default=os.environ.get("DELIVERYHELPER_GPT_MODEL", "gpt-5.5"))
    parser.add_argument("--reasoning-effort", default=os.environ.get("DELIVERYHELPER_GPT_REASONING_EFFORT", "low"))
    parser.add_argument("--codex-bin", default=os.environ.get(CODEX_BIN_ENV, ""))
    parser.add_argument("--device-key", default=os.environ.get("DELIVERYHELPER_GPT_DEVICE_KEY", ""))
    parser.add_argument(
        "--no-naver-building-lookup",
        dest="naver_building_lookup",
        action="store_false",
        help="do not add Naver geocode candidates when building name is missing",
    )
    parser.set_defaults(naver_building_lookup=os.environ.get("DELIVERYHELPER_GPT_NAVER_BUILDING_LOOKUP", "1") != "0")
    parser.add_argument("--max-naver-queries", type=int, default=int(os.environ.get("DELIVERYHELPER_GPT_MAX_NAVER_QUERIES", "3")))
    parser.add_argument("--node", default=os.environ.get("DELIVERYHELPER_GPT_NODE", f"{socket.gethostname()}_dh_gpt"))
    parser.add_argument("--cwd", default=os.environ.get("DELIVERYHELPER_GPT_CWD", str(BASE_DIR)))
    return parser.parse_args(argv)


def main(argv: list[str]) -> int:
    args = parse_args(argv)
    if args.reasoning_effort not in {"minimal", "low", "medium", "high"}:
        raise SystemExit("--reasoning-effort must be one of minimal, low, medium, high")
    return run_loop(args)


if __name__ == "__main__":
    raise SystemExit(main(sys.argv[1:]))
