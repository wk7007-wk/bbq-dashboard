#!/usr/bin/env python3
"""StoreBot lifecycle receipt contracts and repository-driven CA outbox.

This module performs no network or Firebase I/O. Production use requires an
explicit durable repository implementation. The bundled in-memory repository
is a test fake and is rejected unless ``allow_test_repository=True``.
"""

from __future__ import annotations

import hashlib
import hmac
import json
import re
import threading
from collections.abc import Mapping, Sequence
from copy import deepcopy
from dataclasses import dataclass
from typing import Any, Protocol


SCHEMA = "storebot.telegram_ops_receipt.v1"
OUTBOX_SCHEMA = "storebot.telegram_gate_delivery.v1"
JUDGE_SCHEMA = "storebot.telegram_log_judge.v1"
FAILURE_SCHEMA = "storebot.telegram_failure_signal.v1"
TRANSITIONS = frozenset(
    {
        "request", "claim", "worker_started", "result", "error", "timeout",
        "recovery_proposed", "recovery_started", "recovery_result", "delivery",
    }
)
RESOURCES = frozenset(
    {"personal_gateway", "personal_wonmux_codex", "pc_codex_resource_01", "subphone_termux_ops", "com.sbotux"}
)
TRANSITION_RESOURCES = {
    "request": frozenset({"com.sbotux"}),
    "claim": frozenset({"subphone_termux_ops", "pc_codex_resource_01"}),
    "worker_started": frozenset({"subphone_termux_ops", "pc_codex_resource_01"}),
    "result": frozenset({"com.sbotux"}),
    "error": frozenset({"com.sbotux"}),
    "timeout": frozenset({"com.sbotux"}),
    "recovery_proposed": frozenset({"subphone_termux_ops", "pc_codex_resource_01", "personal_gateway"}),
    "recovery_started": frozenset({"subphone_termux_ops", "pc_codex_resource_01"}),
    "recovery_result": frozenset({"subphone_termux_ops", "pc_codex_resource_01"}),
    "delivery": frozenset({"com.sbotux"}),
}
TRANSITION_STATUSES = {
    "request": frozenset({"pending"}),
    "claim": frozenset({"running"}),
    "worker_started": frozenset({"running"}),
    "result": frozenset({"completed"}),
    "error": frozenset({"failed"}),
    "timeout": frozenset({"failed"}),
    "recovery_proposed": frozenset({"proposed"}),
    "recovery_started": frozenset({"running"}),
    "recovery_result": frozenset({"completed", "failed"}),
    "delivery": frozenset({"delivered"}),
}
KNOWN_RETRYABLE = frozenset({"resident_timeout", "resident_session_missing", "worker_stale", "local_direct_timeout"})
KNOWN_FAIL_CLOSED = frozenset({"policy_block", "approval_required", "live_action", "destructive_action"})
FAILURE_ORIGINS = frozenset(
    {"storebot_worker", "external_worker", "storebot_recovery", "storebot_ops_receipt_delivery", "telegram_delivery"}
)
NON_RECOVERY_ORIGINS = frozenset({"storebot_recovery", "storebot_ops_receipt_delivery", "telegram_delivery"})
RISK_LEVELS = frozenset({"low", "medium", "high", "critical", "live", "destructive"})
OPAQUE_RE = re.compile(r"\A[a-z][a-z0-9_]*_[0-9a-f]{24,64}\Z")
FAILURE_CODE_RE = re.compile(r"\A[a-z][a-z0-9_]{2,63}\Z")
DEFAULT_MAX_SOURCE_AGE_MS = 5 * 60_000
DEFAULT_FUTURE_SKEW_MS = 30_000
RECEIPT_KEYS = frozenset(
    {
        "schema", "receipt_id", "task_id", "transition", "attempt", "sequence", "status",
        "duration_ms", "resource", "evidence_pointer", "occurred_at_ms", "severity",
        "dedupe_key", "origin", "judge_eligible", "lease_epoch", "fencing_token",
        "no_send", "sent",
    }
)
FAILURE_KEYS = frozenset(
    {
        "schema", "failure_id", "task_id", "failure_code", "risk", "origin", "root_cause_id",
        "cause_chain", "hop", "recovery_eligible", "occurred_at_ms", "signature",
    }
)
GATE_DELIVERY_REQUIRED_KEYS = frozenset(
    {
        "status", "request_id", "queue", "request_path", "result_path", "target", "target_node",
        "task_id", "participant_id", "resource_id", "capability", "lifecycle_state",
        "ingress_account_id", "reply_account_id", "conversation_id", "room_kind", "thread_id",
        "source_message_id", "created_at_ms", "attempt_count", "next_attempt_at_ms",
    }
)


class OpsLogError(ValueError):
    pass


@dataclass(frozen=True)
class TaskSnapshot:
    revision: Any
    task: Mapping[str, Any]


@dataclass(frozen=True)
class DeliverySnapshot:
    revision: Any
    row: Mapping[str, Any]


@dataclass(frozen=True)
class RecoverySnapshot:
    revision: Any
    state: Mapping[str, Any]


@dataclass(frozen=True)
class ReserveResult:
    created: bool
    authoritative: Mapping[str, Any]
    contention: bool = False


class OpsReceiptRepository(Protocol):
    """Durable CAS contract. A task aggregate and its receipts must commit atomically."""

    is_durable: bool
    storage_kind: str

    def read_task(self, task_id: str) -> TaskSnapshot: ...

    def reserve_receipt(
        self, task_id: str, expected_revision: Any, receipt: Mapping[str, Any]
    ) -> ReserveResult: ...

    def all_receipts(self) -> list[dict[str, Any]]: ...

    def reserve_recovery_intent(self, intent_key: str, record: Mapping[str, Any]) -> ReserveResult: ...

    def reserve_outbox_batch(self, batch_key: str, record: Mapping[str, Any]) -> ReserveResult: ...

    def read_recovery_state(self, projection_id: str) -> RecoverySnapshot: ...

    def cas_recovery_state(
        self, projection_id: str, expected_revision: Any, replacement: Mapping[str, Any]
    ) -> ReserveResult: ...


class GateDeliveryRepository(Protocol):
    """CAS view of ``telegram_openclaw_codex_gate.DELIVERIES_PATH``."""

    is_durable: bool
    storage_kind: str

    def reserve_delivery(self, request_id: str, row: Mapping[str, Any]) -> ReserveResult: ...

    def list_deliveries(self) -> list[dict[str, Any]]: ...

    def read_delivery(self, request_id: str) -> DeliverySnapshot: ...

    def cas_delivery(
        self, request_id: str, expected_revision: Any, replacement: Mapping[str, Any]
    ) -> ReserveResult: ...


class FakeDurableCasRepository:
    """Process-memory test fake with shared backing for restart/race tests only."""

    is_durable = False
    storage_kind = "fake_in_memory_test_only"

    def __init__(self, shared_state: dict[str, Any] | None = None) -> None:
        self._state = shared_state if shared_state is not None else {}
        self._state.setdefault("tasks", {})
        self._state.setdefault("task_revisions", {})
        self._state.setdefault("recovery_intents", {})
        self._state.setdefault("outbox_batches", {})
        self._state.setdefault("recovery_states", {})
        self._state.setdefault("recovery_state_revisions", {})
        self._state.setdefault("deliveries", {})
        self._state.setdefault("delivery_revisions", {})
        self._lock = self._state.setdefault("_lock", threading.Lock())

    def read_task(self, task_id: str) -> TaskSnapshot:
        with self._lock:
            return TaskSnapshot(
                self._state["task_revisions"].get(task_id, 0),
                deepcopy(self._state["tasks"].get(task_id) or {}),
            )

    def reserve_receipt(
        self, task_id: str, expected_revision: Any, receipt: Mapping[str, Any]
    ) -> ReserveResult:
        candidate = dict(receipt)
        with self._lock:
            task = deepcopy(self._state["tasks"].get(task_id) or {})
            receipts = task.get("receipts") if isinstance(task.get("receipts"), dict) else {}
            existing = receipts.get(str(candidate.get("receipt_id") or ""))
            if isinstance(existing, dict):
                if existing != candidate:
                    raise OpsLogError("conflicting duplicate receipt")
                return ReserveResult(False, deepcopy(existing))
            for current in receipts.values():
                if isinstance(current, dict) and current.get("dedupe_key") == candidate.get("dedupe_key"):
                    if current != candidate:
                        raise OpsLogError("conflicting duplicate dedupe identity")
                    return ReserveResult(False, deepcopy(current))
            revision = self._state["task_revisions"].get(task_id, 0)
            if revision != expected_revision:
                return ReserveResult(False, {}, contention=True)
            sequence = int(task.get("sequence") or 0)
            if int(candidate.get("sequence") or 0) != sequence + 1:
                raise OpsLogError("repository sequence mismatch")
            receipts[str(candidate["receipt_id"])] = candidate
            self._state["tasks"][task_id] = {
                "task_id": task_id,
                "last_transition": candidate["transition"],
                "last_attempt": int(candidate["attempt"]),
                "last_occurred_at_ms": int(candidate["occurred_at_ms"]),
                "sequence": int(candidate["sequence"]),
                "receipts": receipts,
            }
            self._state["task_revisions"][task_id] = int(revision) + 1
            return ReserveResult(True, deepcopy(candidate))

    def all_receipts(self) -> list[dict[str, Any]]:
        with self._lock:
            values = [
                deepcopy(receipt)
                for task in self._state["tasks"].values()
                for receipt in (task.get("receipts") or {}).values()
                if isinstance(receipt, dict)
            ]
        return values

    def reserve_recovery_intent(self, intent_key: str, record: Mapping[str, Any]) -> ReserveResult:
        candidate = dict(record)
        with self._lock:
            existing = self._state["recovery_intents"].get(intent_key)
            if isinstance(existing, dict):
                existing_binding = {key: value for key, value in existing.items() if key != "occurred_at_ms"}
                candidate_binding = {key: value for key, value in candidate.items() if key != "occurred_at_ms"}
                if existing_binding != candidate_binding:
                    raise OpsLogError("conflicting recovery intent")
                return ReserveResult(False, deepcopy(existing))
            self._state["recovery_intents"][intent_key] = candidate
            return ReserveResult(True, deepcopy(candidate))

    def reserve_outbox_batch(self, batch_key: str, record: Mapping[str, Any]) -> ReserveResult:
        candidate = dict(record)
        with self._lock:
            existing = self._state["outbox_batches"].get(batch_key)
            if isinstance(existing, dict):
                binding_keys = {"kind", "room_registry_ref", "anchor_receipt_ref"}
                if {key: existing.get(key) for key in binding_keys} != {key: candidate.get(key) for key in binding_keys}:
                    raise OpsLogError("conflicting outbox batch binding")
                return ReserveResult(False, deepcopy(existing))
            self._state["outbox_batches"][batch_key] = candidate
            return ReserveResult(True, deepcopy(candidate))

    def read_recovery_state(self, projection_id: str) -> RecoverySnapshot:
        with self._lock:
            return RecoverySnapshot(
                self._state["recovery_state_revisions"].get(projection_id, 0),
                deepcopy(self._state["recovery_states"].get(projection_id) or {}),
            )

    def cas_recovery_state(
        self, projection_id: str, expected_revision: Any, replacement: Mapping[str, Any]
    ) -> ReserveResult:
        candidate = dict(replacement)
        with self._lock:
            revision = self._state["recovery_state_revisions"].get(projection_id, 0)
            if revision != expected_revision:
                return ReserveResult(
                    False,
                    deepcopy(self._state["recovery_states"].get(projection_id) or {}),
                    contention=True,
                )
            current = self._state["recovery_states"].get(projection_id)
            if isinstance(current, dict) and int(candidate.get("state_version") or 0) != int(current.get("state_version") or 0) + 1:
                raise OpsLogError("recovery state version mismatch")
            if current in (None, {}) and int(candidate.get("state_version") or 0) != 1:
                raise OpsLogError("initial recovery state version must be one")
            self._state["recovery_states"][projection_id] = candidate
            self._state["recovery_state_revisions"][projection_id] = int(revision) + 1
            return ReserveResult(True, deepcopy(candidate))

    def reserve_delivery(self, request_id: str, row: Mapping[str, Any]) -> ReserveResult:
        candidate = dict(row)
        with self._lock:
            existing = self._state["deliveries"].get(request_id)
            if isinstance(existing, dict):
                if existing != candidate:
                    raise OpsLogError("conflicting delivery reservation")
                return ReserveResult(False, deepcopy(existing))
            self._state["deliveries"][request_id] = candidate
            self._state["delivery_revisions"][request_id] = 1
            return ReserveResult(True, deepcopy(candidate))

    def list_deliveries(self) -> list[dict[str, Any]]:
        with self._lock:
            return [deepcopy(value) for value in self._state["deliveries"].values() if isinstance(value, dict)]

    def read_delivery(self, request_id: str) -> DeliverySnapshot:
        with self._lock:
            return DeliverySnapshot(
                self._state["delivery_revisions"].get(request_id, 0),
                deepcopy(self._state["deliveries"].get(request_id) or {}),
            )

    def cas_delivery(
        self, request_id: str, expected_revision: Any, replacement: Mapping[str, Any]
    ) -> ReserveResult:
        candidate = dict(replacement)
        with self._lock:
            revision = self._state["delivery_revisions"].get(request_id, 0)
            if revision != expected_revision:
                return ReserveResult(False, deepcopy(self._state["deliveries"].get(request_id) or {}), contention=True)
            if request_id not in self._state["deliveries"]:
                raise OpsLogError("unknown delivery row")
            self._state["deliveries"][request_id] = candidate
            self._state["delivery_revisions"][request_id] = int(revision) + 1
            return ReserveResult(True, deepcopy(candidate))


def _key(value: bytes | str) -> bytes:
    result = value.encode("utf-8") if isinstance(value, str) else bytes(value)
    if len(result) < 32:
        raise OpsLogError("identity_key must contain at least 32 bytes")
    return result


def _opaque(prefix: str, key: bytes, value: Any) -> str:
    encoded = json.dumps(value, ensure_ascii=False, sort_keys=True, separators=(",", ":")).encode("utf-8")
    return f"{prefix}_{hmac.new(key, encoded, hashlib.sha256).hexdigest()[:32]}"


def _opaque_ref(value: Any, prefix: str, field: str) -> str:
    result = str(value or "")
    if not result.startswith(f"{prefix}_") or not OPAQUE_RE.fullmatch(result):
        raise OpsLogError(f"{field} must be an opaque {prefix} ref")
    return result


def _allowed_predecessors(transition: str) -> frozenset[str]:
    return {
        "request": frozenset({""}),
        "claim": frozenset({"request"}),
        "worker_started": frozenset({"claim"}),
        "result": frozenset({"worker_started", "recovery_started", "recovery_result"}),
        "error": frozenset({"worker_started", "recovery_started"}),
        "timeout": frozenset({"worker_started"}),
        "recovery_proposed": frozenset({"error", "timeout", "recovery_proposed", "recovery_result"}),
        "recovery_started": frozenset({"recovery_proposed"}),
        "recovery_result": frozenset({"recovery_started"}),
        "delivery": frozenset({"result", "error", "recovery_result"}),
    }[transition]


def _validate_time(occurred_at_ms: int, now_ms: int, max_source_age_ms: int, future_skew_ms: int) -> int:
    occurred = int(occurred_at_ms)
    current = int(now_ms)
    if occurred <= 0 or current <= 0:
        raise OpsLogError("occurred_at_ms and now_ms must be positive")
    if occurred < current - max(0, int(max_source_age_ms)):
        raise OpsLogError("receipt source is stale")
    if occurred > current + max(0, int(future_skew_ms)):
        raise OpsLogError("receipt source is too far in the future")
    return occurred


class StoreBotOpsCoordinator:
    """Repository-backed receipt/outbox coordinator; contains no transport calls."""

    def __init__(
        self,
        *,
        identity_key: bytes | str,
        receipt_repository: OpsReceiptRepository,
        delivery_repository: GateDeliveryRepository,
        allow_test_repository: bool = False,
        max_recovery_attempts: int = 2,
        cooldown_ms: int = 10_000,
        max_source_age_ms: int = DEFAULT_MAX_SOURCE_AGE_MS,
        future_skew_ms: int = DEFAULT_FUTURE_SKEW_MS,
    ) -> None:
        self._key = _key(identity_key)
        self.receipt_repository = receipt_repository
        self.delivery_repository = delivery_repository
        if (
            not bool(getattr(receipt_repository, "is_durable", False))
            or not bool(getattr(delivery_repository, "is_durable", False))
        ) and not allow_test_repository:
            raise OpsLogError("non-durable repositories are test-only")
        self.max_recovery_attempts = max(1, int(max_recovery_attempts))
        self.cooldown_ms = max(0, int(cooldown_ms))
        self.max_source_age_ms = max(0, int(max_source_age_ms))
        self.future_skew_ms = max(0, int(future_skew_ms))
        self.kill_switch = False

    def task_id(self, private_task_ref: str) -> str:
        if not str(private_task_ref or "").strip():
            raise OpsLogError("private_task_ref is required")
        return _opaque("sttask", self._key, {"private_task_ref": private_task_ref})

    def task_state(self, private_task_ref: str) -> dict[str, Any]:
        return deepcopy(dict(self.receipt_repository.read_task(self.task_id(private_task_ref)).task))

    def read_recovery_state(self, projection_id: str) -> RecoverySnapshot:
        return self.receipt_repository.read_recovery_state(str(projection_id))

    def cas_recovery_state(
        self, projection_id: str, expected_revision: Any, replacement: Mapping[str, Any]
    ) -> ReserveResult:
        return self.receipt_repository.cas_recovery_state(
            str(projection_id), expected_revision, replacement
        )

    def append(
        self,
        *,
        private_task_ref: str,
        transition: str,
        status: str,
        resource: str,
        evidence_pointer: str,
        occurred_at_ms: int,
        now_ms: int,
        duration_ms: int = 0,
        severity: str = "info",
        attempt: int = 0,
        lease_epoch: int | None = None,
        fencing_token: str | None = None,
    ) -> dict[str, Any]:
        if transition not in TRANSITIONS:
            raise OpsLogError("transition is not allowlisted")
        if resource not in RESOURCES or resource not in TRANSITION_RESOURCES[transition]:
            raise OpsLogError("resource is not allowed for transition")
        if status not in TRANSITION_STATUSES[transition]:
            raise OpsLogError("status is not allowed for transition")
        if severity not in {"info", "warning", "error", "critical"}:
            raise OpsLogError("severity is not allowlisted")
        evidence = _opaque_ref(evidence_pointer, "stev", "evidence_pointer")
        occurred = _validate_time(occurred_at_ms, now_ms, self.max_source_age_ms, self.future_skew_ms)
        duration = int(duration_ms)
        if duration < 0:
            raise OpsLogError("duration_ms must be non-negative")
        task_id = self.task_id(private_task_ref)
        attempt_value = int(attempt)
        if attempt_value < 0:
            raise OpsLogError("attempt must be non-negative")
        if transition.startswith("recovery_") and not 1 <= attempt_value <= self.max_recovery_attempts:
            raise OpsLogError("recovery attempt is outside the bounded range")
        for _ in range(4):
            snapshot = self.receipt_repository.read_task(task_id)
            task = dict(snapshot.task)
            receipts = task.get("receipts") if isinstance(task.get("receipts"), Mapping) else {}
            previous_receipt = max(
                (dict(value) for value in receipts.values() if isinstance(value, Mapping)),
                key=lambda value: int(value.get("sequence") or 0),
                default={},
            )
            previous = str(task.get("last_transition") or "")
            previous_attempt = int(task.get("last_attempt") or 0)
            previous_lease_epoch = int(previous_receipt.get("lease_epoch") or 0)
            previous_fencing_token = str(previous_receipt.get("fencing_token") or "")
            existing_result_receipt = max(
                (
                    dict(value)
                    for value in receipts.values()
                    if isinstance(value, Mapping) and value.get("transition") == "result"
                ),
                key=lambda value: int(value.get("sequence") or 0),
                default={},
            )
            result_binding_source = (
                previous_receipt
                if previous in {"recovery_started", "recovery_result"}
                else existing_result_receipt
            )
            authoritative_attempt = 0
            authoritative_lease_epoch = 0
            authoritative_fencing_token = ""
            if transition.startswith("recovery_"):
                recovery_snapshot = self.receipt_repository.read_recovery_state(str(private_task_ref))
                recovery_state = recovery_snapshot.state if isinstance(recovery_snapshot.state, Mapping) else {}
                delegate = recovery_state.get("delegate") if isinstance(recovery_state.get("delegate"), Mapping) else {}
                if delegate:
                    authoritative_attempt = int(delegate.get("recovery_attempt") or 0)
                    authoritative_lease_epoch = int(delegate.get("lease_epoch") or 0)
                    authoritative_fencing_token = str(delegate.get("fencing_token") or "")
            if transition == "result" and result_binding_source:
                result_attempt = int(result_binding_source.get("attempt") or 0)
                if attempt_value not in {0, result_attempt}:
                    raise OpsLogError("result recovery attempt binding mismatch")
                attempt_value = result_attempt
            if transition.startswith("recovery_") and authoritative_attempt:
                if attempt_value != authoritative_attempt:
                    raise OpsLogError("recovery attempt conflicts with authoritative state")
                if lease_epoch is not None and int(lease_epoch) != authoritative_lease_epoch:
                    raise OpsLogError("recovery lease conflicts with authoritative state")
                if fencing_token is not None and str(fencing_token) != authoritative_fencing_token:
                    raise OpsLogError("recovery fence conflicts with authoritative state")
            effective_lease_epoch = (
                int(lease_epoch)
                if lease_epoch is not None
                else authoritative_lease_epoch
                if transition.startswith("recovery_") and authoritative_attempt
                else int(result_binding_source.get("lease_epoch") or 0)
                if transition == "result" and result_binding_source
                else 0
            )
            effective_fencing_token = (
                str(fencing_token)
                if fencing_token is not None
                else authoritative_fencing_token
                if transition.startswith("recovery_") and authoritative_attempt
                else str(result_binding_source.get("fencing_token") or "")
                if transition == "result" and result_binding_source
                else ""
            )
            if (effective_lease_epoch > 0) != bool(effective_fencing_token):
                raise OpsLogError("recovery lease and fence must be bound together")
            if effective_fencing_token and (
                not effective_fencing_token.startswith("stfence_")
                or not OPAQUE_RE.fullmatch(effective_fencing_token)
            ):
                raise OpsLogError("recovery fencing_token is invalid")
            if transition == "recovery_proposed" and attempt_value >= 2 and effective_lease_epoch <= 0:
                raise OpsLogError("delegated recovery proposal requires lease binding")
            if transition in {"recovery_started", "recovery_result"}:
                if attempt_value != previous_attempt:
                    raise OpsLogError("recovery attempt continuity mismatch")
                if (
                    effective_lease_epoch != previous_lease_epoch
                    or effective_fencing_token != previous_fencing_token
                ):
                    raise OpsLogError("recovery lease/fence continuity mismatch")
            if transition == "result" and result_binding_source and (
                effective_lease_epoch != int(result_binding_source.get("lease_epoch") or 0)
                or effective_fencing_token != str(result_binding_source.get("fencing_token") or "")
            ):
                raise OpsLogError("result recovery lease/fence continuity mismatch")
            identity = {"task_id": task_id, "transition": transition, "attempt": attempt_value}
            receipt_id = _opaque("stopreceipt", self._key, identity)
            dedupe_key = _opaque("stopdedupe", self._key, identity)
            existing = receipts.get(receipt_id) if isinstance(receipts, Mapping) else None
            sequence = int(task.get("sequence") or 0) + 1
            receipt = {
                "schema": SCHEMA,
                "receipt_id": receipt_id,
                "task_id": task_id,
                "transition": transition,
                "attempt": attempt_value,
                "sequence": sequence,
                "status": status,
                "duration_ms": duration,
                "resource": resource,
                "evidence_pointer": evidence,
                "occurred_at_ms": occurred,
                "severity": severity,
                "dedupe_key": dedupe_key,
                "origin": "storebot_worker",
                "judge_eligible": False,
                "lease_epoch": effective_lease_epoch,
                "fencing_token": effective_fencing_token,
                "no_send": True,
                "sent": False,
            }
            if isinstance(existing, Mapping):
                authoritative = dict(existing)
                candidate = {**receipt, "sequence": int(authoritative.get("sequence") or 0)}
                if authoritative != candidate:
                    raise OpsLogError("conflicting duplicate receipt")
                return deepcopy(authoritative)
            if previous not in _allowed_predecessors(transition):
                raise OpsLogError(f"invalid transition order: {previous or '<start>'}->{transition}")
            if transition == "recovery_proposed" and previous == "recovery_proposed" and attempt_value <= previous_attempt:
                raise OpsLogError("recovery proposal attempt must increase")
            if occurred < int(task.get("last_occurred_at_ms") or 0):
                raise OpsLogError("receipt time must be monotonic per task")
            if frozenset(receipt) != RECEIPT_KEYS:
                raise OpsLogError("receipt schema mismatch")
            reserved = self.receipt_repository.reserve_receipt(task_id, snapshot.revision, receipt)
            if reserved.contention:
                continue
            return deepcopy(dict(reserved.authoritative))
        raise OpsLogError("receipt CAS contention")

    def _build_gate_delivery_row(
        self, *, room_registry_ref: str, receipt_refs: Sequence[str], created_at_ms: int
    ) -> dict[str, Any]:
        room_ref = _opaque_ref(room_registry_ref, "stroomreg", "room_registry_ref")
        refs = [
            _opaque_ref(value, "stopreceipt", "receipt_ref")
            for value in receipt_refs
        ]
        identity = {"room_registry_ref": room_ref, "receipt_refs": refs}
        request_id = _opaque("stopoutbox", self._key, identity)
        payload_path = f"/packhelper/openclaw_telegram_gate/storebot_ops_payloads/{request_id}"
        row = {
            "schema": OUTBOX_SCHEMA,
            "status": "waiting",
            "request_id": request_id,
            "queue": "storebot_ops_receipt",
            "request_path": payload_path,
            "result_path": payload_path,
            "target": "phone",
            "target_node": "personal_wonmux_codex",
            "task_id": request_id,
            "participant_id": "personal",
            "resource_id": "personal_wonmux_codex",
            "capability": "storebot_ops_receipt_delivery",
            "lifecycle_state": "request",
            "ingress_account_id": "serverphone",
            "reply_account_id": "serverphone",
            "conversation_id": room_ref,
            "room_kind": "ca_expert",
            "thread_id": "",
            "source_message_id": refs[0],
            "created_at_ms": int(created_at_ms),
            "attempt_count": 0,
            "next_attempt_at_ms": 0,
            "delivery_kind": "storebot_ops_receipt",
            "room_registry_ref": room_ref,
            "receipt_refs": refs,
            "aggregate_count": len(refs),
            "message_ref": _opaque("stopmessage", self._key, identity),
            "recovery_eligible": False,
            "last_error": "",
            "last_attempt_at_ms": 0,
            "delivery_id": "",
            "delivered_at_ms": 0,
            "no_send": True,
            "sent": False,
        }
        if not GATE_DELIVERY_REQUIRED_KEYS.issubset(row):
            raise OpsLogError("gate delivery row schema mismatch")
        return row

    def pending_ca_outbox(
        self,
        *,
        room_registry_ref: str,
        now_ms: int,
        packet_limit: int = 4,
        aggregate_size: int = 8,
    ) -> list[dict[str, Any]]:
        current = int(now_ms)
        if current <= 0:
            raise OpsLogError("now_ms must be positive")
        room_ref = _opaque_ref(room_registry_ref, "stroomreg", "room_registry_ref")
        size = max(1, min(32, int(aggregate_size)))
        for _ in range(64):
            existing_rows = self.delivery_repository.list_deliveries()
            assigned = {
                str(ref)
                for row in existing_rows
                if row.get("delivery_kind") == "storebot_ops_receipt"
                for ref in (row.get("receipt_refs") or [])
            }
            receipts = sorted(
                (item for item in self.receipt_repository.all_receipts() if item.get("receipt_id") not in assigned),
                key=lambda item: (int(item.get("occurred_at_ms") or 0), str(item.get("receipt_id") or "")),
            )
            if not receipts:
                break
            group = receipts[:size]
            proposed_refs = [str(item["receipt_id"]) for item in group]
            anchor = proposed_refs[0]
            batch_key = _opaque(
                "stopbatch", self._key, {"room_registry_ref": room_ref, "anchor_receipt_ref": anchor}
            )
            batch = self.receipt_repository.reserve_outbox_batch(
                batch_key,
                {
                    "kind": "delivery_batch",
                    "room_registry_ref": room_ref,
                    "anchor_receipt_ref": anchor,
                    "receipt_refs": proposed_refs,
                    "created_at_ms": max(int(item["occurred_at_ms"]) for item in group),
                },
            )
            refs = [str(value) for value in batch.authoritative.get("receipt_refs") or []]
            if not refs:
                raise OpsLogError("authoritative outbox batch is empty")
            row = self._build_gate_delivery_row(
                room_registry_ref=room_ref,
                receipt_refs=refs,
                created_at_ms=int(batch.authoritative.get("created_at_ms") or current),
            )
            self.delivery_repository.reserve_delivery(str(row["request_id"]), row)
        eligible = [
            row
            for row in self.delivery_repository.list_deliveries()
            if row.get("delivery_kind") == "storebot_ops_receipt"
            and row.get("room_registry_ref") == room_registry_ref
            and row.get("status") in {"waiting", "retry"}
            and int(row.get("next_attempt_at_ms") or 0) <= current
            and row.get("no_send") is True
            and row.get("sent") is False
        ]
        eligible.sort(key=lambda row: (int(row.get("created_at_ms") or 0), str(row.get("request_id") or "")))
        return deepcopy(eligible[: max(1, int(packet_limit))])

    def mark_delivery(self, request_id: str, *, delivered: bool, now_ms: int) -> dict[str, Any]:
        current = int(now_ms)
        for _ in range(4):
            snapshot = self.delivery_repository.read_delivery(str(request_id))
            row = dict(snapshot.row)
            if not row or row.get("delivery_kind") != "storebot_ops_receipt":
                raise OpsLogError("unknown StoreBot receipt delivery")
            if delivered and row.get("no_send") is True:
                raise OpsLogError("no-send delivery cannot be marked sent")
            attempts = int(row.get("attempt_count") or 0) + 1
            if delivered:
                row.update(
                    {
                        "status": "delivered", "lifecycle_state": "telegram_delivered",
                        "attempt_count": attempts, "delivered_at_ms": current,
                        "last_attempt_at_ms": current, "next_attempt_at_ms": 0,
                        "last_error": "", "sent": True,
                    }
                )
            else:
                row.update(
                    {
                        "status": "retry", "lifecycle_state": "delivery_retry",
                        "attempt_count": attempts, "last_attempt_at_ms": current,
                        "next_attempt_at_ms": current + min(60_000, self.cooldown_ms * attempts),
                        "last_error": "typed_delivery_failure", "recovery_eligible": False,
                    }
                )
            updated = self.delivery_repository.cas_delivery(request_id, snapshot.revision, row)
            if updated.contention:
                continue
            return deepcopy(dict(updated.authoritative))
        raise OpsLogError("delivery CAS contention")

    def reconnect_replay(self, *, room_registry_ref: str, now_ms: int) -> list[dict[str, Any]]:
        return self.pending_ca_outbox(room_registry_ref=room_registry_ref, now_ms=now_ms)

    def build_failure_signal(
        self,
        *,
        private_task_ref: str,
        failure_code: str,
        risk: str,
        origin: str,
        private_root_cause_ref: str,
        private_cause_chain: Sequence[str],
        hop: int,
        recovery_eligible: bool,
        occurred_at_ms: int,
    ) -> dict[str, Any]:
        if not FAILURE_CODE_RE.fullmatch(str(failure_code or "")):
            raise OpsLogError("failure_code is invalid")
        if risk not in RISK_LEVELS or origin not in FAILURE_ORIGINS:
            raise OpsLogError("risk or origin is not allowlisted")
        if not str(private_root_cause_ref or "").strip():
            raise OpsLogError("private_root_cause_ref is required")
        if isinstance(private_cause_chain, (str, bytes)) or not isinstance(private_cause_chain, Sequence):
            raise OpsLogError("private_cause_chain must be a sequence")
        hop_value = int(hop)
        if hop_value < 0 or hop_value > 8:
            raise OpsLogError("hop is outside the bounded range")
        eligible = bool(recovery_eligible)
        if origin == "telegram_delivery" and eligible:
            raise OpsLogError("Telegram delivery failures cannot be recovery eligible")
        task_id = self.task_id(private_task_ref)
        root_cause_id = _opaque("stroot", self._key, {"private_root_cause_ref": private_root_cause_ref})
        cause_chain = [
            _opaque("stcause", self._key, {"index": index, "private_ref": value})
            for index, value in enumerate(private_cause_chain)
        ]
        if len(cause_chain) != hop_value:
            raise OpsLogError("cause_chain length must match hop")
        unsigned = {
            "schema": FAILURE_SCHEMA,
            "task_id": task_id,
            "failure_code": failure_code,
            "risk": risk,
            "origin": origin,
            "root_cause_id": root_cause_id,
            "cause_chain": cause_chain,
            "hop": hop_value,
            "recovery_eligible": eligible,
            "occurred_at_ms": int(occurred_at_ms),
        }
        failure_id = _opaque("stfailure", self._key, unsigned)
        signed = {**unsigned, "failure_id": failure_id}
        signal = {**signed, "signature": _opaque("stfailsig", self._key, signed)}
        if frozenset(signal) != FAILURE_KEYS:
            raise OpsLogError("failure signal schema mismatch")
        return signal

    def _validate_failure_signal(self, signal: Mapping[str, Any], now_ms: int) -> dict[str, Any]:
        if not isinstance(signal, Mapping) or frozenset(signal) != FAILURE_KEYS:
            raise OpsLogError("typed failure signal is required")
        value = dict(signal)
        if value.get("schema") != FAILURE_SCHEMA:
            raise OpsLogError("failure signal schema mismatch")
        for field, prefix in (("failure_id", "stfailure"), ("task_id", "sttask"), ("root_cause_id", "stroot")):
            _opaque_ref(value.get(field), prefix, field)
        chain = value.get("cause_chain")
        if not isinstance(chain, list):
            raise OpsLogError("cause_chain must be a list")
        for item in chain:
            _opaque_ref(item, "stcause", "cause_chain")
        if value.get("origin") not in FAILURE_ORIGINS or value.get("risk") not in RISK_LEVELS:
            raise OpsLogError("failure origin or risk is invalid")
        if not FAILURE_CODE_RE.fullmatch(str(value.get("failure_code") or "")):
            raise OpsLogError("failure_code is invalid")
        if not isinstance(value.get("recovery_eligible"), bool):
            raise OpsLogError("recovery_eligible must be boolean")
        if value.get("origin") == "telegram_delivery" and value.get("recovery_eligible") is not False:
            raise OpsLogError("Telegram delivery failures cannot be recovery eligible")
        hop = int(value.get("hop") or 0)
        if hop < 0 or hop > 8:
            raise OpsLogError("hop is outside the bounded range")
        if len(chain) != hop:
            raise OpsLogError("cause_chain length must match hop")
        _validate_time(value["occurred_at_ms"], now_ms, self.max_source_age_ms, self.future_skew_ms)
        signature = str(value.pop("signature"))
        if not hmac.compare_digest(signature, _opaque("stfailsig", self._key, value)):
            raise OpsLogError("failure signature mismatch")
        return dict(signal)

    def judge_failure(self, *, failure: Mapping[str, Any], now_ms: int) -> dict[str, Any]:
        signal = self._validate_failure_signal(failure, now_ms)
        task_id = str(signal["task_id"])
        if self.kill_switch:
            return self._judge_decision(task_id, "kill_switch", "none", "recovery_disabled")
        if signal["origin"] in NON_RECOVERY_ORIGINS:
            return self._judge_decision(task_id, "ignore_non_recovery_origin", "none", "origin_loop_guard")
        if int(signal["hop"]) > 1:
            return self._judge_decision(task_id, "hop_limit", "none", "cause_chain_hop_limit")
        if signal["recovery_eligible"] is not True:
            return self._judge_decision(task_id, "not_recovery_eligible", "none", "typed_failure_policy")
        failure_code = str(signal["failure_code"])
        risk = str(signal["risk"])
        if risk in {"high", "critical", "live", "destructive"} or failure_code in KNOWN_FAIL_CLOSED:
            return self._judge_decision(task_id, "high_risk_proposal_only", "personal_gateway", "approval_required")
        if failure_code not in KNOWN_RETRYABLE:
            return self._judge_decision(task_id, "codex_analysis_proposal", "pc_codex_resource_01", "unknown_or_ambiguous")
        wake_key = _opaque("stopcas", self._key, {"task_id": task_id, "kind": "wake", "attempt": 1})
        wake_record = {
            "task_id": task_id, "kind": "wake_primary", "attempt": 1,
            "target_resource": "subphone_termux_ops", "occurred_at_ms": int(signal["occurred_at_ms"]),
        }
        wake = self.receipt_repository.reserve_recovery_intent(wake_key, wake_record)
        if wake.created:
            decision = self._judge_decision(task_id, "wake_primary", "subphone_termux_ops", "first_retryable_error")
            decision["cas_intent_key"] = wake_key
            return decision
        wake_at_ms = int(wake.authoritative.get("occurred_at_ms") or 0)
        elapsed = int(now_ms) - wake_at_ms
        if elapsed < 20_000 or elapsed < self.cooldown_ms:
            return self._judge_decision(task_id, "wait", "subphone_termux_ops", "bounded_recovery_window")
        if self.max_recovery_attempts < 2:
            return self._judge_decision(task_id, "max_attempts_reached", "personal_gateway", "bounded_recovery_exhausted")
        delegate_key = _opaque("stopcas", self._key, {"task_id": task_id, "kind": "delegate", "attempt": 2})
        delegate_record = {
            "task_id": task_id, "kind": "delegate_analysis", "attempt": 2,
            "target_resource": "pc_codex_resource_01", "occurred_at_ms": int(now_ms),
        }
        delegate = self.receipt_repository.reserve_recovery_intent(delegate_key, delegate_record)
        if not delegate.created:
            return self._judge_decision(task_id, "delegate_already_reserved", "pc_codex_resource_01", "cas_winner_exists")
        decision = self._judge_decision(task_id, "delegate_analysis", "pc_codex_resource_01", "unresolved_after_wake")
        decision["cas_intent_key"] = delegate_key
        return decision

    def reserve_delegate_intent(
        self,
        *,
        private_task_ref: str,
        cas_intent_key: str,
        target_resource: str,
        attempt: int,
        now_ms: int,
    ) -> ReserveResult:
        _opaque_ref(cas_intent_key, "stcas", "cas_intent_key")
        if target_resource != "pc_codex_resource_01" or int(attempt) != 2:
            raise OpsLogError("delegate intent binding mismatch")
        record = {
            "task_id": self.task_id(private_task_ref), "kind": "delegate_analysis", "attempt": 2,
            "target_resource": target_resource, "occurred_at_ms": int(now_ms),
        }
        return self.receipt_repository.reserve_recovery_intent(cas_intent_key, record)

    @staticmethod
    def _judge_decision(task_id: str, action: str, target: str, reason: str) -> dict[str, Any]:
        return {
            "schema": JUDGE_SCHEMA,
            "task_id": task_id,
            "classification": "codex_required" if action == "codex_analysis_proposal" else "model_0",
            "action": action,
            "target_resource": target,
            "reason": reason,
            "proposal": action in {"wake_primary", "delegate_analysis", "codex_analysis_proposal", "high_risk_proposal_only"},
            "no_send": True,
            "sent": False,
        }

    def receipt(self, receipt_id: str) -> dict[str, Any]:
        for receipt in self.receipt_repository.all_receipts():
            if receipt.get("receipt_id") == receipt_id:
                return deepcopy(receipt)
        return {}


__all__ = [
    "DeliverySnapshot",
    "FAILURE_SCHEMA",
    "FakeDurableCasRepository",
    "GATE_DELIVERY_REQUIRED_KEYS",
    "GateDeliveryRepository",
    "OpsLogError",
    "OpsReceiptRepository",
    "RecoverySnapshot",
    "ReserveResult",
    "StoreBotOpsCoordinator",
    "TRANSITIONS",
    "TaskSnapshot",
]
