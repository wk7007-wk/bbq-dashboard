#!/usr/bin/env bash
set -euo pipefail

ROOT_DIR="${STOREBOT_CODEX_ROOT:-/root/my-first-project}"
cd "$ROOT_DIR"

if [ "$#" -eq 0 ]; then
  python3 scripts/storebot_manual_reply.py
else
  python3 scripts/storebot_manual_reply.py "$@"
fi
