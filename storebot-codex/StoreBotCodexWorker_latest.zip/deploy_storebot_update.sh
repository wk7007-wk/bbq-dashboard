#!/bin/sh
set -eu

ROOT_DIR="$(CDPATH= cd -- "$(dirname -- "$0")/.." && pwd)"
APP_DIR="/root/StoreBot"
HOST_DIR="$ROOT_DIR/AttendanceBoard/docs/storebot"
APK_SOURCE="$APP_DIR/app/build/outputs/apk/debug/app-debug.apk"
META_FILE="$APP_DIR/app/build/outputs/apk/debug/output-metadata.json"
HOSTED_APK_NAME="StoreBot_latest.bin"
APK_URL="https://poskds-attendance.web.app/storebot/$HOSTED_APK_NAME"

cleanup() {
  sh "$APP_DIR/gradlew" -p "$APP_DIR" --stop >/dev/null 2>&1 || true
}
trap cleanup EXIT

mkdir -p "$HOST_DIR"

sh "$APP_DIR/gradlew" -p "$APP_DIR" :app:assembleDebug

VERSION_CODE="$(python3 -c 'import json,sys; print(json.load(open(sys.argv[1]))["elements"][0]["versionCode"])' "$META_FILE")"
VERSION_NAME="$(python3 -c 'import json,sys; print(json.load(open(sys.argv[1]))["elements"][0]["versionName"])' "$META_FILE")"
SHA256="$(sha256sum "$APK_SOURCE" | awk '{print $1}')"
UPDATED_AT="$(TZ=Asia/Seoul date +%Y-%m-%dT%H:%M:%S%z)"
RELEASE_NOTES="${STOREBOT_RELEASE_NOTES:-StoreBot 자동 업데이트}"

cp "$APK_SOURCE" "$HOST_DIR/$HOSTED_APK_NAME"

python3 "$ROOT_DIR/scripts/write_update_manifest.py" \
  --host-dir "$HOST_DIR" \
  --channel-id "storebot" \
  --label "StoreBot" \
  --version-code "$VERSION_CODE" \
  --version-name "$VERSION_NAME" \
  --artifact-url "$APK_URL" \
  --artifact-sha256 "$SHA256" \
  --release-notes "$RELEASE_NOTES" \
  --updated-at "$UPDATED_AT"

cat > "$HOST_DIR/index.html" <<EOF
<!doctype html>
<html lang="ko">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>StoreBot 업데이트</title>
  <style>
    body { margin:0; min-height:100vh; display:grid; place-items:center; background:#111; color:#f5f5f5; font-family:sans-serif; }
    main { width:min(92vw, 460px); padding:32px; border:1px solid #333; border-radius:20px; background:#1b1b1b; }
    h1 { margin:0 0 8px; font-size:28px; }
    p { color:#bbb; line-height:1.55; }
    a { display:block; margin-top:24px; padding:18px; border-radius:14px; background:#2ecc71; color:#07140b; text-align:center; font-weight:700; text-decoration:none; }
    small { display:block; margin-top:18px; color:#777; word-break:break-all; }
  </style>
</head>
<body>
  <main>
    <h1>StoreBot 업데이트</h1>
    <p>버전 $VERSION_NAME ($VERSION_CODE)</p>
    <p>$RELEASE_NOTES</p>
    <a href="$HOSTED_APK_NAME" download="StoreBot_latest.apk">StoreBot APK 다운로드</a>
    <small>SHA-256: $SHA256</small>
  </main>
</body>
</html>
EOF

firebase deploy --only hosting:attendance --project poskds-4ba60

printf 'StoreBot auto-update deployed: %s (%s)\n%s\n' "$VERSION_NAME" "$VERSION_CODE" "$APK_URL"
