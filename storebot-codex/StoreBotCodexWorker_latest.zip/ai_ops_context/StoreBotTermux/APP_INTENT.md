<!-- source: /root/StoreBotTermux/APP_INTENT.md -->
# StoreBotTermux APP_INTENT

## 목적
- StoreBotTermux는 서버폰 카카오 운영의 단일 앱이다.
- surface 기준은 native-apk/live-execution layer다. 카카오 입출력은 native APK + accessibility execution layer로만 검증한다.
- 사용자 UI는 카카오톡 운영방이고, 이 앱은 persistent CLI/chat session, backplane, 카카오 입력/출력, runtime state를 같은 앱 생명주기로 묶는다.
- 기존 `com.storebot.app` StoreBot Android 앱은 서버폰 운영 대상이 아니다.

## 절대 기준
- 카톡 알림 수신, RemoteInput 답장, 접근성 fallback, worker health, 재기동은 StoreBotTermux가 소유한다.
- 다중 알림 레이더망 설계는 `docs/kakao_radar_mesh_design.md`가 상세 SOT다. Phase 1/default scope는 서버폰 전용 카카오방 1개이며 multi-room 일반 설계가 기본이 아니다. 서버폰 원본 카카오만 답장 주체이고, 서버폰 듀얼메신저/공장 PC 카카오는 receive-only radar로만 본다. API/Groq/OpenAI fast brain route는 기본 답변 후보가 아니며 키 입력 방향은 폐기한다. 메인 경로는 persistent CLI/chat session + StoreBotTermux backplane이고 `exec`는 예외 실행으로 제한한다.
- 현재 일반 terminal/AI bridge 기능 판정은 partial이다. `TermuxService`/`TerminalSession` 같은 일반 터미널 기능은 있으나, StoreBot/Kakao/backplane 입력이 상주 PTY/CLI stdin으로 계속 들어가는 구조는 기본 live 경로가 아니다.
- 현재 보유 기능은 Kakao input/output, local-direct HTTP, recovery queue, briefing mirror, `codex_exec`/`codex_resume` 기반 logical session 일부다. `codex_exec`는 one-shot fresh task brain이고 `codex_resume`도 attached persistent PTY/chat session은 아니다.
- 원칙: 도구가 있으니 쓰는 것이 아니라, 사용자 흐름을 보존하는 도구만 메인 경로가 된다. exec를 늘리는 것이 아니라, StoreBotTermux backplane 기반 persistent terminal/chat bridge를 만든다.
- live reply decision authority는 persistent main session에 있고, StoreBotTermux는 전용방 1개 기준 transport/send gate/safety veto/outbox owner다. Firebase는 mirror/audit/read-model이며 Android local journal/ledger/session lease가 canonical이다.
- Phase 1 model policy는 빠른 모델 기본값이다. confidence/문맥 부족, 복잡도, 반복 실패, 불확실, 위험 action, live ops/ADB/Firebase write 후보일 때만 상위 모델로 올리고, hot path 전체를 무겁게 하지 않는다.
- persistent main CLI/chat session이 warm 상태로 살아 있으면 per-turn process startup/boot delay는 거의 제거된다. 단 model inference, Kakao capture/send, local queue, safety gate, network, stdout drain, recovery와 cold start/kill/crash/model switch/rule hash reset 첫 turn 지연은 남는다.
- Phase 1 전용방에서도 turn order sync는 필수다. 카톡 수신 event마다 monotonic `turn_seq` 또는 `occurrence_seq`와 `correlation_id`를 부여하고, reply는 같은 seq/correlation/session lease/fencingToken이 맞을 때만 outbox로 보낸다. 여러 입력은 순차 처리 또는 in-flight 1개 원칙을 우선하며, 늦은 stdout은 다음 turn에 섞지 않고 stale/drain 처리한다.
- 카톡 전송은 final clean reply만 허용한다. prompt-only가 아니라 `STOREBOT_REPLY_V1` 같은 code contract로 강제하며, stdout/terminal log는 직접 전송 대상이 아니다. structured envelope 또는 sentinel-delimited clean block의 `reply_text`만 추출하고, 로그/디버그/내부 JSON/tool trace/code fence/빈 답변/다중 후보/stale correlation은 send gate에서 차단한다.
- 2026-07-09 KST Phase 1 구현 기준: Android `StoreBotTermuxRoomTurnLedger`가 `turn_seq`/`correlation_id`/`session_lease`/`fencing_token`을 request에 붙이고, worker `/storebot/request`는 `STOREBOT_REPLY_V1` envelope로 echo한다. Android send gate는 현재 ledger와 envelope `reply_text` 1개만 통과시키며 mismatch/log-mixed/blank/multi-candidate는 no-send/report로 닫는다.
- 근무표 이미지 브리핑은 최신 StoreBotTermux 안에서 처리한다. `근무/근무표/스케줄` 출력은 worker의 단일 `image_request.type=schedule_briefing` 계약을 거쳐야 하며, 앱은 payload를 새로 해석하지 않는 렌더러/운반자다.
- 근무표 정상 경로는 PNG 이미지 전송이다. 근무표 본문은 무조건 이미지이며, 이미지 실패 때 긴 텍스트 근무표로 대체하지 않는다. 실패 시에는 짧은 실패 알림과 원격 로그로 어디서 끊겼는지 남긴다.
- 자동 근무표 broadcast는 이미지 생성/첨부 성공 증거가 있어야만 `/packhelper/storebot_termux/work_schedule_broadcast_state`를 `sent`로 ack한다. 이미지 필수 경로에서 정책 skip/렌더 실패/공유 실패가 나면 `image_capture_or_generation_pending`과 짧은 retry로 남기고 `last_sent_schedule_hash`를 갱신하지 않는다.
- 근무표 이미지 발송은 하드 kill과 자동 하이브리드 정책을 함께 따른다. `/packhelper/storebot_termux/image_send_enabled=false`는 최우선 hard off이고, 새 정책은 `/packhelper/storebot_termux/image_send_mode`(`auto` 기본, `off`, `on`)와 `/packhelper/storebot_termux/thermal_state`(`normal`, `caution`, `hot-risk`, `unknown`)를 읽는다.
- `auto+hot-risk`는 PNG 렌더/공유 전에 skip한다. `auto+caution`은 같은 방/명령/range에 대해 이미지 dedupe/cooldown을 12분으로 늘려 반복 근무표 이미지를 억제한다. `normal`/`unknown`은 3분 stable dedupe로 허용한다. `on`은 thermal block을 우회할 수 있지만 flood dedupe는 반드시 유지한다.
- 근무표 이미지 dedupe는 payload 날짜/range가 있으면 카톡 원문 문구가 아니라 room + image type/event/mode/source + 날짜/range를 기준으로 한다. 같은 payload가 local-direct와 pending/broadcast transport를 모두 타도 한 장만 발송 계획되어야 하며, payload 날짜가 없을 때만 원문 문구를 fallback key로 쓴다.
- 정책 skip은 공유/렌더 전 진단 로그만 남기고 카카오 전송을 시도하지 않는다. 접근성, 알림 수신, worker poll은 유지하되 이미지/OCR/캡처 계열 고부하 작업만 상태에 따라 제한한다.
- live 재개 기준은 새 APK 또는 현재 live Android가 위 정책을 읽는다는 증거와 새 worker bundle 채택 증거다. 그 전 transitional 값은 `image_send_enabled=false`, `image_send_mode=auto`, `thermal_state=caution`으로 둔다.
- 근무표 PNG는 카톡 전송 후에도 읽혀야 한다. 파일 생성은 고해상도 3x 렌더 기준으로 하고, 한글 본문은 monospace가 아니라 산세리프/medium 계열을 쓴다. 게이지 행, 시간 눈금, 이름+시간 라벨은 카톡 축소 표시에서도 읽힐 만큼 크게 렌더링한다.
- 근무표 PNG 타임라인은 worker payload의 `graph_bounds`와 각 날짜 shift에서 계산한 동적 축을 쓴다. 프론트 이미지에는 `어두움`/`밝음`/`저녁` 같은 설명어를 노출하지 않고, 시작/중간/끝 시간 눈금과 색 흐름으로만 시간대를 전달한다.
- 근무표 PNG 시간 눈금 숫자는 그라데이션 위에서 작거나 흐릿하게 뭉개지면 실패다. 카톡 축소에서도 읽히도록 굵은 산세리프 숫자와 밝은 반투명 라벨 배경/테두리로 분리한다.
- 자동 근무표 broadcast와 사용자 근무표 요청은 하나의 `image_request.type=schedule_briefing`에서 하나의 통합 PNG를 렌더링하는 것이 기본이다. 날씨/월드컵/뉴스는 근무표 카드 내부 섹션으로 붙이며 별도 하루짜리 이미지로 분리하지 않는다.
- 뉴스는 출력 시점에 새로 조회한 기사 제목을 최대 2개까지 오늘 카드에만 싣는다. 모델 요약·예측·카테고리 접두어와 7일 과거기사 fallback을 쓰지 않고, 신선한 제목이 없으면 `실시간 뉴스 조회 불가`로 끝낸다.
- 근무표/근무 이미지 출력은 request당 canonical `image_request` 1개가 전부다. 사용자 화면 기본 범위는 7일이고 명시 범위는 4~7일로 제한한다. 모든 범위에서 기존 세로형 상세 카드·게이지·본문 크기를 유지하며, 휴대폰 한 화면에 맞춘다는 이유로 내용을 삭제하거나 글자를 과도하게 축소하는 compact layout은 쓰지 않는다.
- 근무표 그래프 축은 고정 0~24시가 아니라 각 날짜의 실제 근무 데이터에서 첫 출근자/첫 출근 시간부터 마지막 퇴근자/마지막 퇴근 시간까지다. 익일 퇴근은 다음날 absolute timeline으로 해석하고 payload `graph_bounds`/caption과 renderer axis가 같은 기준을 써야 한다.
- worker의 근무표 이미지 날짜 선택은 06:00 KST 운영일 기준을 따른다. 06:00 전에는 전날 운영일을 `오늘`로 보고, 자동 broadcast의 `start_offset_days=0`도 그 운영일에서 시작한다.
- 근무표 날짜 카드는 배경색만으로 구분하지 않는다. `근무`, `콘티`, `날씨`, `월드컵`, `뉴스` 같은 섹션 헤더와 구분선을 렌더링해 어디까지가 매장 근무인지 명확히 보여준다.
- 클립보드 붙여넣기와 카카오 사진 선택기는 품질 기준 경로로 보지 않는다. 근무표 품질 기준 경로는 사용자가 `내 파일 -> 공유 -> 카톡`으로 보냈을 때와 같은 `ACTION_SEND image/png` 공유 인텐트다. 파일 첨부 말풍선은 진단/비상 루트, 클립보드는 최후 fallback으로만 둔다.
- 근무표 카드의 세부 내용 규칙은 `/root/my-first-project/.agents/skills/storebot-kakao-reply/SKILL.md`만 SOT다. 앱은 payload를 충실히 렌더링하고 전송 결과만 기록한다.
- 접근성/worker가 흔들리면 앱 내부 ops receiver의 고정 action과 supervisor 주기 점검으로 복구한다. 임의 shell 실행용 receiver는 만들지 않는다.
- ADB가 끊긴 상태의 복구 자료 수집은 StoreBotTermux `AdbRecoveryAgent`가 Tasker 보조/대체 경로로 맡는다. Firebase `refresh_wireless_debug` 명령을 받으면 Tasker result 후보 경로를 먼저 확인하고, 개발자 옵션/무선 디버깅 화면의 접근성 텍스트와 스크린샷을 `/packhelper/subphone/adb_wireless/**`에 올려 CLI가 연결 전에 판단할 수 있게 한다. 일반 refresh는 QR/페어링 화면으로 먼저 들어가지 않으며, OFF가 확인될 때만 toggle 진단과 함께 스위치를 켠다. `capture_pairing_code` 계열 명령은 “페어링 코드로 기기 페어링” 화면을 열고 pairing endpoint/code를 `/packhelper/subphone/adb_wireless/pairing/latest`에 올린다.
- ADB recovery 성공 판정은 `/packhelper/subphone/adb_wireless/latest`의 fresh endpoint/status와 실제 `adb devices` 기준이다. `input_health`는 카카오 입력 이벤트 상태이고 `/packhelper/storebot_termux/heartbeat`는 singleton이라 scoped `/packhelper/storebot_termux/heartbeats/com_sbotux`와 함께 본다.
- 기본 실행 경로는 `TermuxService` foreground 세션이다. `bash -> proot -> start_storebot_codex_worker.sh -> python3 --watch`가 한 줄기로 보여야 한다.
- 일반 카톡 AI 답변의 기본 구조는 persistent CLI/chat session + StoreBotTermux backplane이다. 메인 CLI 채팅창이 이어지는 brain/session이고, StoreBotTermux는 backplane/input-output/runtime state, 서버폰 전용 카카오방 하나는 single-room input/output transport다.
- `exec`는 기본 hot path가 아니다. bootstrapping, isolated stateless command, build/test, timeout-protected probe, crash recovery, heavy bounded worker, self_fix에만 예외로 쓰고, 결과는 backplane/main session에 합류해야 한다.
- API direct는 쓰지 않는다. CLI/CNI 후보도 persistent StoreBotTermux backplane/session을 살리는 범위에서만 평가하고, API 키나 one-shot exec를 기본 hot path로 늘리지 않는다.
- 전용방 일반 답변은 빠른 모델로 먼저 처리하고, 품질/문맥/위험 기준을 못 넘을 때 상위 모델 검토나 비동기 보정으로 분리한다.
- 고정 문구/regex 하드코딩 답변은 AI 답변 후보가 아니다. 자기 메시지, 중복, 빈값, 카카오 UI 노이즈 같은 안전 guard는 로컬 처리할 수 있지만 업무 의미 판단을 대체하지 않는다.
- 속도 개선 목표는 `exec` 단발 호출을 늘리는 것이 아니라 이어지는 session, 입출력 multiplexing, context bridge, read-model, task packet, session memory를 안정화하는 것이다.
- 터미널이 이어붙이기/상주 세션/입출력 multiplexing을 못 하면 StoreBotTermux 기반 persistent terminal bridge를 개조한다. `exec`를 새 brain으로 늘려 문맥을 보정하지 않는다.
- 다음 구조 변경 전에는 no-send 벤치마크로 brain-role quality와 latency를 분리 측정한다. 감지, worker 처리, AI turn, 카카오 전송 단계는 분리 측정하고 실제 카카오 발송 없이 no-publish/no-send로 먼저 검증한다.
- worker 판단력 의존은 절대 불가다. `fast_router`는 worker 자연어 판단기가 아니라 Codex 세션 resume 경로 이름이며, worker/App/monitor는 자연어 의미, 업무 여부, 답변/SKIP, action/domain/slot을 판단하지 않는다.
- worker/App이 할 수 있는 선처리는 자기 메시지, 빈값, 완전 중복, 카카오 화면 UI 토큰 같은 해석 없는 하드가드와 입력 운반 노이즈 제거뿐이다. Codex/스킬의 구조화 출력 없이 regex, 키워드, 로컬 휴리스틱, fallback worker 판단으로 카톡 업무를 처리하면 실패다.
- `watch_storebot_codex_worker.sh`, Termux:Boot, shell-open fallback은 기본 경로가 아니다. 비상 옵션으로만 둔다.
- local-direct는 `127.0.0.1:8765`만 기준으로 한다. 외부 네트워크 바인딩을 기본값으로 쓰지 않는다.
- 앱에서 worker로 붙는 HTTP는 loopback만 허용한다. Android cleartext 차단 때문에 카카오 답장이 멈추면 `storebot_termux_network_security_config`와 local-direct health를 먼저 본다.
- OpenClaw 연동을 추가하더라도 앱의 역할은 바뀌지 않는다. 카톡 RemoteInput/접근성 전송, 실패 큐, 재시도 소유권은 StoreBotTermux가 계속 맡는다.
- 카카오 summary 알림은 제목/본문이 비어 있을 수 있다. listener 연결/빈 알림 시 active notification scan으로 상세 알림을 다시 읽되, 같은 알림 `postTime/key`는 6시간 중복 차단한다.
- 답장 액션이 없는 카카오 알림이나 빈 summary 알림은 접근성 화면 스캔/방 열기 fallback으로 운영방 메시지를 worker에 넣고 답장을 보낸다.
- 카톡 입력 운반은 하이브리드다. 알림, active notification scan, 접근성 화면 스캔이 같은 메시지를 잡으면 2분 claim 기준으로 먼저 잡은 1건만 처리하고 나머지는 운반 중복으로 스킵한다.
- notification callback이 조용히 놓친 경우를 줄이기 위해 listener가 살아 있는 동안 60초 간격으로 active notification scan을 다시 돈다. 이는 자연어 판단이 아니라 입력 회수용 저부하 운반 보정이다.
- foreground standby는 기본 off다. `/packhelper/storebot_termux/storebot_foreground_standby_enabled=true`일 때만 StoreBotTermux foreground service/명시적 `com.sbotux.STOREBOT_FOREGROUND_STANDBY` 1회 Activity 요청을 대기 기준으로 쓰고, Kakao는 background notification/RemoteInput 우선으로 둔다. 이 모드에서는 접근성 event scan 최소 30초, 열린 채팅방 foreground poll 30초, Kakao foreground idle 60초, Kakao background 120초, active notification scan 180초로 완화한다. 강제 foreground loop, 카카오 자동 발송, live state 수정은 하지 않는다.
- foreground standby APK 기준은 `0.118.3-storebot.63`/1068이다. 설치 후에도 flag가 off이면 기존 scan 주기와 발송 조건을 유지한다.
- Activity foreground는 Android background activity start 제한과 사용자 방해 가능성이 있어 필수 생존 기준이 아니다. worker 생존 기준은 계속 `TermuxService` foreground notification, wakelock, supervisor/local-direct heartbeat이며 Activity 전환은 no-send 검증 뒤 수동/명시 entrypoint로만 쓴다.
- 카카오톡을 앱 안에 embed하지 않는다. 구조 기준은 `카카오톡 앱 ↔ StoreBotTermux KakaoAdapter transport ↔ briefing_channel ↔ AI/resident session`이다. 1차 briefing_channel 본체는 Firebase가 아니라 같은 서버폰 worker가 소유한다. Android는 `127.0.0.1:8765/storebot/briefing-channel/event`로 운반 이벤트만 비동기 전달하고, 실제 카톡 텍스트/이미지 발송은 기존 RemoteInput/접근성/`ACTION_SEND image/png` 경로가 계속 소유한다.
- briefing_channel local schema는 기본 `/sdcard/Download/StoreBotTermux/briefing_channel/rooms/{briefing_channel_room_id}.json`와 `events/{event_id}.json`다. Phase 1은 dedicated room 1개 record가 live 기준이며 `rooms/` 경로는 호환성과 future multi-room 확장을 위해 유지한다. `room_id=storebot_group`은 worker 호환 필드로 유지하고, `briefing_channel_room_id=kakao_{room_name_sanitized}`를 별도로 둔다. rooms는 room_name, 최근 메시지, 발신자, 처리 상태, 마지막 AI 응답, 누락/지연/실패 상태, outbound intent, 브리핑용 `briefing_text`를 보존한다. Firebase `/packhelper/storebot_termux/briefing_channel`은 `STOREBOT_BRIEFING_CHANNEL_FIREBASE_MIRROR=true`일 때만 원격 진단 미러로 쓴다.
- 카카오 화면의 날짜 헤더 같은 수집 노이즈는 worker 호출 전에 차단한다. 이는 자연어 의도 선분류가 아니라 카카오 UI 노이즈 제거다.
- `sender=카카오화면` 접근성 스캔 결과는 카톡 원문이 아니라 화면 UI/프로필/발신자명 수집 잡음이므로 내용과 무관하게 worker 호출 전에 차단한다.
- 카카오의 `사진/이미지를 보냈습니다` 이벤트는 첨부 원본을 자동 다운로드하지 않는다. StoreBotTermux가 대상 방을 열어 방 제목과 입력창을 재검증한 뒤 현재 채팅영역만 임시 JPEG로 캡처하고, 최신 사용자 사진과 주변 대화를 Codex `localImage` 입력으로 함께 전달한다. 동영상/파일/음성은 계속 metadata-only다.
- 채팅 화면 캡처는 앱 전용 external-files의 `storebot_chat_vision` 아래 최대 12개/30분만 보존한다. worker는 고정 경로 allowlist, 8MB, 35분, 확장자, SHA-256을 검증하고 사진 turn은 텍스트 fast-router를 우회한다. 로컬 경로와 화면 대화문은 Firebase에 올리지 않고 원격 mirror에는 해시·크기·상태만 남긴다.
- 같은 방에서 15분 안에 이어지고 직원/주문/메뉴/근무 등 공통 대상을 가진 메시지는 한 에피소드로 판단한다. 직원끼리 결론난 반복 운영정보는 별도 가르침 없이 `/packhelper/ops_manual/candidates` 검토 후보로 남긴다. 서로 다른 채팅 증거가 2개 이상인 후보는 다음 질문의 읽기·설명용 `advisory_only` 맥락으로 자동 재사용하지만 주문·금융·영업 write 권한으로 쓰지 않으며, 추측이나 일회성 대화는 재사용하지 않는다.
- 확신 부족은 무응답 이유가 아니다. 읽기/조회/검색/맥락 복원은 가능한 범위에서 진행하고, 금융·주문 확정·영업 영향·파괴적 쓰기만 핵심 증거/승인을 요구한다.
- StoreBotTermux가 카톡에 텍스트/이미지/파일/RemoteInput 답변을 보낸 직후에는 자동 접근성 화면 이벤트 스캔을 짧게 쉬어 방금 갱신된 발신자명/닉네임/공유 UI 텍스트를 새 사용자 입력으로 오인하지 않는다. 알림 ReplyAction과 수동 진단 스캔은 이 자연어 전송 노이즈 방지와 별개다.
- 메시지를 잡으면 StoreBotTermux가 dedupe/claim보다 먼저 앱 내부 durable inbound journal에 `captured`를 남긴 뒤, 내부 dedupe/claim 후 즉시 `127.0.0.1` local-direct로 보낸다. local-direct health OK는 짧게 캐시해 살아있는 worker에 매 입력마다 health RTT를 강제하지 않는다. Firebase request 기록은 비동기 미러/감사용이며 hot path가 아니다. local-direct가 실패하면 같은 서버폰 앱 내부 `StoreBotTermuxLocalRequestQueue`가 요청을 보존하고 worker 재기동 후 local-direct + 접근성 전송으로 회수한다. Firebase에는 `local_recovery_pending` 보조 상태만 남기며 기본 답변 처리를 Firebase poll에 넘기지 않는다.
- 직원 별칭/오타 정정은 앱이 해석하지 않는다. Codex/스킬이 `employee.add_alias` 액션을 내면 worker가 기존 직원/별칭 충돌을 검증해 `/workschedule/employees/{emp}/aliases`에 저장한다.
- worker가 `system_progress`/`system_recovery`/`skip`/`report`/`log_only`/`self_heal`/`self_fix` 또는 deferred 응답을 반환해도 카톡에는 보내지 않는다. `STOREBOT_ACTIONS`/`STOREBOT_OUTPUT` 같은 내부 프로토콜 원문도 worker 파싱 실패 여부와 무관하게 카톡 전송 전에 차단한다. 앱은 해당 request를 무발송 완료로 정리해 진행/복구/내부상태 문구 남발을 막는다.
- `accessibility_foreground_scan`, heartbeat/keepalive/action_result/worker_action/self-test/internal transport, 명시 플래그 없는 non-chat event는 사용자 채팅 맥락이 아니므로 worker 호출 또는 pending queue 전송 없이 no-reply로 끝낸다. `requires_codex_output`/broadcast ack meta가 있는 예약 발송만 명시 예외다.
- 내점/결제/업무 알림과 예약 발송은 `/packhelper/storebot_pending_queue`를 StoreBotTermux가 직접 소비한다. 일반 카톡 hot path는 이 큐를 거치지 않고 local-direct HTTP 응답으로 바로 보낸다. 새 항목은 `sent=false`가 있어야 우선 조회에 걸리며, 전송 성공 후에만 `sent=true`를 찍고, 30분 지난 큐는 폐기 처리해 오래된 알림 폭주를 막는다. 예약 근무표 항목에 `image_request.type=schedule_briefing`이 있으면 텍스트가 아니라 PNG 공유 전송을 먼저 시도하고, broadcast ack는 pending queue row의 `image_sent/image_send_status/attachment_uri_status` 증거와 함께 남긴다.
- pending queue 알림은 화면이 꺼져 있어도 StoreBotTermux가 짧게 화면을 깨우고 카카오 운영방을 강제 오픈한 뒤 보낸다. 여러 큐가 동시에 쌓이면 UI 조작은 직렬화한다.
- StoreBotTermux는 kill 방지를 위해 foreground service `START_STICKY`, wakelock/wifi lock 유지, 2분 keepalive alarm, boot/package/quickboot/user-present/power-connected 재진입, 배터리 최적화 제외/절전모드 OFF/자동회전 OFF/화면꺼짐 30분/충전 중 화면유지를 보정한다. 서브폰 배터리가 15% 미만으로 떨어지면 카카오 운영방에 짧은 배터리 경고를 보낸다.
- OS 레벨 kill 방지는 ADB에서 `subphone/harden_storebottermux_power.sh`를 적용해 `deviceidle whitelist`, standby active, background/foreground/wakelock appops, 접근성/알림 리스너 secure setting을 보정한다.

## C&I / AI Ops 경계
- StoreBotTermux는 C&I 실행 엔진이다. CLI/LLM은 prompt envelope가 있어야 깨어나므로 monitor/worker/앱 receiver/사용자/수동 enqueue 또는 상주 판단 루프가 prompt를 넣는다. 이것은 C&I 판단 권한 제한이 아니다.
- 카카오 답변 hot path와 내부 self_fix 큐는 분리한다. 사용자에게 보이는 출력은 `kakao_reply`만이고, `report/log_only/self_heal/self_fix`는 내부 처리다.
- 자동 복구는 접근성/알림 권한 보정, worker bundle 반영, local-direct/foreground 세션 복구, 코드/문서/APK/업데이트센터 보정까지 허용한다.
- 임의 shell receiver 확대, 외부 네트워크 바인딩, 카카오 공식 API 우회, PosDelay 실행 경계 침범은 금지한다.

## MCP/검증 기준
- Firebase MCP read-only preflight만 허용한다. 읽기 대상은 `/packhelper/storebot_termux`, `/packhelper/storebot_codex/requests`, `/packhelper/storebot_codex/heartbeat`다.
- Android UI/프로젝트 후보는 Google Design MCP와 Android Studio MCP support로 본다.
- 실제 기기 검증은 factory PC device/ADB serial evidence를 우선한다. mobile-mcp가 있으면 보조, 개인폰 장기 MCP 서버는 세우지 않는다.
- 카카오 전송, ADB, Firebase write는 live boundary다. 별도 승인/안전 flow 없이 수행하지 않는다.
- 완료 전에는 device screenshot, accessibility snapshot, touch target, overflow check가 남아야 한다.

## 완료 기준
- 서버폰 package는 `com.sbotux`, 표시명은 StoreBotTermux다.
- StoreBotTermux notification listener와 accessibility service가 켜져 있다.
- `TermuxService isForeground=true`, local-direct health 200, watchdog sidecar 없음.
- 실제 카톡 채팅 1건이 `RemoteInput -> local-direct -> RemoteInput`으로 `reply sent` 로그와 Firebase `done/local_direct=true/reply_skipped=false`를 남긴다.
- 실제 카톡 채팅 1건을 잡으면 StoreBotTermux 내부 claim/dedupe가 먼저 잡히고, Firebase requests에는 비동기 미러로 `ingress_status=local_direct_inflight`가 보인다. 같은 메시지를 다른 입력 경로가 다시 잡으면 첫 claim 때문에 중복 처리되지 않아야 한다.
- briefing_channel 기록 실패는 카톡 답변 실패로 이어지지 않아야 한다. 입력 수신 후 local-direct 전 inbound event가 local worker에 비동기 전달되고, worker 응답 뒤에는 실제 발송이 아니라 outbound intent만 기록된다. 날짜 헤더, 방제목, 프로필명, `사진을 보냈습니다`, 공유 UI 텍스트 같은 transport noise는 briefing_channel에 넣지 않는다.
- listener periodic active scan 이벤트가 bridge log에 남아야 하며, 입력을 새로 발견했을 때는 같은 claim/dedupe 기준을 따라야 한다.
- foreground standby flag가 off/absent/null이면 기존 active scan/foreground scan 주기를 유지한다. flag가 on이면 input_health의 reason에 `foreground_standby_low_duty`가 남고, 알림 callback/RemoteInput 즉시 처리는 유지되어야 한다.
- `/packhelper/storebot_termux/input_health/latest`에는 active scan, 알림 확인, ingress claim 시간이 따로 올라가야 한다. live 앱이 `.48` 이상으로 전환되어 input_health가 실제로 관측될 때 active scan만 최신이고 claim이 장시간 갱신되지 않으면 AI Ops가 입력 먹통 후보로 본다. 현재 live `.47`처럼 input_health가 없는 상태에서는 bridge active scan 로그만으로 self_fix를 만들지 않는다.
- 앱 내부 inbound journal에는 `captured`, `candidate_filtered`, `dedupe_hit`, `native_queued`, `local_direct_inflight`, `local_recovery_pending`, `suppressed`, `skip`, `done`, `error` 상태가 남아야 하며, heartbeat/input_health에는 depth/latest state 요약만 저빈도로 반영한다.
- `.53` 채팅 인입 진단은 foreground/notification 공통으로 `ingress_source`, `ingress_trigger`, `ingress_claim_status`, `ingress_stale_reason`, `claim_key`, `dedupe_key`, `candidate_filtered`, `dedupe_hit`, `suppressed`, `bridge_event_only`를 기록한다. 실제 발송 조건은 바꾸지 않았고, dry-run input_health는 확인됐으며 실제 foreground inbound는 사용자 테스트 메시지 `진단키테스트_0625`로 확인한다.
- `.55` debug self-test action `com.sbotux.DEBUG_KAKAO_ATTACHMENT_STATUS`는 실제 Kakao send, OCR, image URI capture, local-direct worker 호출 없이 attachment status metadata event와 `/packhelper/storebot_termux/work_schedule_image_preview_queue/{event_id}` dry-run record만 남긴다. 필수 safety flag는 `no_send=true`, `no_live_write=true`, `write_status=blocked_until_confirmed`, `execute_live_write=false`다.
- 일반 AI 답변 heartbeat는 persistent CLI/chat session과 StoreBotTermux backplane이 살아 있는지를 기본 정상으로 본다. `exec`는 기본 정상 경로가 아니며, 예외 호출 시에도 결과가 backplane/main session에 합류하고 전용방 same-room continuity, turn order sync, duplicate detection, self/outbound echo 차단, late stdout drain/cancel, crash recovery, clean reply extraction, no-send 검증, send idempotency를 증명해야 한다. 다른 room/thread 격리는 future multi-room expansion gate다.
- 일반 AI 답변 완료 기준에는 `worker/App 자연어 선판단 없음`이 포함된다. `SKIP`, `kakao_reply`, `STOREBOT_ACTIONS`, `STOREBOT_OUTPUT`, domain/intent/slots는 Codex/스킬 출력 또는 명시 시스템 이벤트 계약에서만 나와야 한다.
- 앱 transport heartbeat는 singleton `/packhelper/storebot_termux/heartbeat`와 scoped `/packhelper/storebot_termux/heartbeats/com_sbotux` 둘 다 `package_name=com.sbotux`, 최신 `version_name/version_code`, `accessibility_enabled=true`, `notification_listener_enabled=true`, `legacy_storebot_accessibility_present=false`를 보여야 한다. singleton은 current `com.sbotux` writer와 version_code 단조 guard만 통과한다. 구 StoreBot heartbeat(`/packhelper/heartbeat/storebot`, `/subphone/heartbeat/storebot`, `/packhelper/storebot_app_heartbeat`)는 운영 판정에 쓰지 않는다.
- `근무표`/근무표 브리핑 요청에서 local-direct 응답에 `image_request.type=schedule_briefing`, `required=true`, `send_policy=image_first`, `fallback_policy=retry_pending`이 붙고, 접근성 서비스가 켜져 있으면 이미지 전송을 시도한다. 실패해도 긴 근무표 텍스트를 대신 보내지 않는다.
- 근무표 PNG 원본은 `/sdcard/Download/StoreBotTermux/`에도 남아야 하며, 기본 payload는 `/sdcard/Download/StoreBotTermux/storebot_schedule_payload.json` 하나만 쓴다.
- `/packhelper/storebot_termux/kakao_bridge_log/latest`와 `events/*`에 알림 수신, local-direct, 이미지/텍스트 전송 단계 로그가 남는다.
- 화면이 꺼진 상태에서 `/packhelper/storebot_pending_queue`에 새 `sv_*` 알림이 들어와도 `kakao screen wake requested`, `pending queue force-open result opened=true`, `pending queue sent`, Firebase `sent=true`가 남는다.
- 자동회전은 꺼져 있어야 한다. Tasker/MacroDroid 같은 자동화 앱이 다시 켜도 StoreBotTermux power guard가 `accelerometer_rotation=0`, `user_rotation=0`으로 되돌린다.
- `dumpsys deviceidle whitelist`에 `com.sbotux`가 포함되고, appops `RUN_IN_BACKGROUND/RUN_ANY_IN_BACKGROUND/START_FOREGROUND/WAKE_LOCK`이 허용 상태여야 한다. 서버폰 ADB가 연결되면 `subphone/harden_storebottermux_power.sh`로 한 번에 재적용한다.
- `STOREBOT_REPAIR_ACCESSIBILITY`는 삭제된 구 StoreBot 접근성 값을 제거하고 StoreBotTermux 접근성을 넣는다. `STOREBOT_REPAIR_WORKER`는 `/sdcard/Download/storebot_codex_worker` 최신 복사본을 proot 내부로 반영하고 worker를 재시작한다. Firebase `/subphone/cmd/storebot`의 `sync_worker_bundle` 계열 명령은 공개 `storebot-codex/bundle.json`을 native 앱이 직접 다운로드/sha 검증/압축해제한 뒤 같은 repair 경로로 재시작한다.
- supervisor는 local-direct health가 정상이어도 60초마다 구 `com.storebot.app` 접근성 값을 제거하고 StoreBotTermux 접근성을 유지해야 한다.
- force-stop 후 앱 재실행 시 기존 worker가 사라지고 새 foreground worker가 올라온다.
- 앱 개선 보고서는 별도 프로세스가 아니라 worker 내부 thread가 하루 1회 저부하 시간에 `/packhelper/app_improvement_reports/StoreBotTermux/latest`에 쓴다.
- StoreBotTermux 검증/설치는 서버폰 ADB 경로가 기준이다. 개인폰은 이 앱을 쓰지 않으므로 별도 요청이 없으면 개인폰 `/sdcard/Download` 복사나 `termux-open` 전달을 하지 않는다.
- 최신 공개 기준은 `0.118.3-storebot.52`, 서버폰 live worker bundle은 `0621.1237`이다. `.52`는 ADB refresh가 QR/페어링 화면으로 흐르지 않게 guard하고, OFF/toggle/Tasker 미확인 진단을 status/event에 남긴다. `.48`은 `com.sbotux` package/namespace와 bootstrap `$PREFIX=/data/data/com.sbotux/files/usr`로 서버폰 설치/첫 실행 검증까지 완료됐지만, live hot path는 기존 `com.termux` worker가 유지 중이다. `com.sbotux` 리스너는 중복 카톡 처리를 막기 위해 live 전환 전 비활성 상태로 둔다. 내부 `system_*`/`skip`/deferred 응답과 raw `STOREBOT_ACTIONS`/`STOREBOT_OUTPUT` 프로토콜은 카톡 무발송이며, 원래 `skip_reason`은 Firebase request에 보존한다. ADB 복구 명령은 연결 전 자료 수집이 목적이므로 앱이 먼저 endpoint/status/screenshot을 올리고 CLI가 그 뒤 `adb connect`를 시도한다. 2026-06-17 KST `.36`은 카카오 입력 hot path에서 Firebase pending fallback을 제거하고, 앱 내부 local recovery queue/command poller와 local-direct health를 기준으로 복구했다. 같은 날 속도테스트에서 resident path가 75초 sync deadline을 넘겼고, 2026-06-18 KST stateless fast-router도 88초 이상 지연되어 worker hot path는 fast-router prewarm/resume 기본값으로 전환했다. `.37`은 TermuxService `START_STICKY`, task/onDestroy restart alarm, power guard keepalive alarm, OS hardening script를 추가했고, `.41`은 `sender=카카오화면` 접근성 스캔 전체를 worker 입력에서 제거한다. `.42`는 무선 디버깅 OFF 화면에서 오른쪽 스위치를 우선 눌러 ADB endpoint 수집 복구를 안정화한다. `.43`은 ADB 없이 Firebase command poller가 hosted worker bundle을 직접 다운로드/sha 검증/repair할 수 있게 한다. `.44`는 ADB fresh endpoint가 refused일 때 pairing endpoint/code를 자동 수집하는 명령을 추가한다. `.45`는 화면 꺼짐 상태에서 ADB recovery가 검정 스크린샷/`endpoint_not_found`로 끝나지 않도록 설정 화면 진입 전에 화면을 깨운다. `.46`은 native worker bundle sync 후 proot bundle state까지 갱신해 heartbeat가 실제 적용 bundle version/sha를 즉시 반영한다. `.47`은 worker가 깨진 action JSON을 반환해도 내부 프로토콜이 카톡에 노출되지 않도록 Android 전송 직전 차단을 추가한다. `.48`은 input_health를 추가하고 worker bundle sync 명령이 `done`이어도 heartbeat가 목표 version/sha를 못 따라오면 error로 끝낸다. `0621.1237` 모니터는 stale sync command와 legacy `.47` missing input_health를 self_fix 오탐으로 보지 않는다.
- 현재 서버폰 설치본은 `0.118.3-storebot-kst0731.t0904`/1075다. worker bundle sync는 새 Hosting `wk7007-ops-static-2026.web.app/storebot-codex`만 allowlist하고, Firebase command의 `manifest_url`·target version·target SHA를 hosted manifest와 교차검증한다. 공장 PC USB `R39M30RWR2F`에서 update install 1회, PackageManager 1075, 새 crash 0, 이어진 bundle `0731.0838-automation-persistent` heartbeat 채택까지 확인했다.

## 확장 기준
- 1차는 StoreBotTermux 카카오 안정화다.
- OpenClaw/DeliveryHelper/PosDelay 확장 기준은 `/root/my-first-project/subphone/STOREBOT_CODEX_BRIDGE.md`를 SOT로 보고, 앱 문서에는 전송 소유권만 둔다.
- 물류 알림/파싱은 보류한다. 다음 확장은 DeliveryHelper 주소/건물/동호/비번 가공 worker와 알림 안정성이다.
- DeliveryHelper는 지도/UI 앱으로 두고, 무거운 주소 재가공은 StoreBotTermux/Codex 엔진 계열 worker가 Firebase 큐를 처리해 확정 후보만 돌려주는 구조를 우선한다.
- 이후 PosDelay는 대시보드/실행 모듈을 같은 앱 생명주기로 붙인다.
- 개인폰은 모니터/수동복구, 서버폰은 카카오 실운영/PosDelay/분석 worker 역할을 우선한다.
