#!/usr/bin/env python3
from __future__ import annotations

import argparse
import json
import re
import subprocess
import sys
import tempfile
import time
import urllib.parse
import urllib.request
from pathlib import Path
from typing import Any

from codex_ops_adb_check import compact_text, parse_devices, resolve_adb_path, select_device
from codex_ops_kakao_wake import run_kakao_wake


DEFAULT_STOREBOTTERMUX_PACKAGE = "com.sbotux"
DEFAULT_KAKAO_PACKAGE = "com.kakao.talk"
DEFAULT_FIREBASE_BASE = "https://poskds-4ba60-default-rtdb.asia-southeast1.firebasedatabase.app"
ALLOWED_WAKE_MODES = {"check", "wake_app", "foreground", "service_refresh"}
ADB_UNAVAILABLE_EXIT = 2
CHECK_FAILED_EXIT = 3

FIREBASE_PATHS = {
    "storebot_codex_heartbeat": "/packhelper/storebot_codex/heartbeat",
    "storebot_termux_heartbeat": "/packhelper/storebot_termux/heartbeat",
    "storebot_termux_scoped_heartbeat": "/packhelper/storebot_termux/heartbeats/com_sbotux",
    "input_health": "/packhelper/storebot_termux/input_health/latest",
    "claim_latest": "/packhelper/storebot_termux/kakao_ingress_claims/latest",
    "bridge_latest": "/packhelper/storebot_termux/kakao_bridge_log/latest",
    "requests": "/packhelper/storebot_codex/requests",
    "pending_queue": "/packhelper/storebot_pending_queue",
}

ACTIVE_REQUEST_STATUSES = {"pending", "running", "processing", "claimed", "local_direct_inflight", "local_recovery_pending"}
ERROR_PATTERNS = (
    "Exception",
    "ANR",
    "local_direct_failed",
    "local_direct_deferred_failed",
    "reply failed",
    "send failed",
    "KakaoBridge",
    "StoreBotTermux",
)


def now_ms() -> int:
    return int(time.time() * 1000)


def bool_field(value: Any) -> bool:
    if isinstance(value, bool):
        return value
    if isinstance(value, (int, float)):
        return value != 0
    return str(value or "").strip().lower() in {"1", "true", "yes", "y", "on"}


def storebottermux_request_requested(item: dict[str, Any]) -> bool:
    return bool_field(item.get("storebottermux_check")) or bool_field(item.get("storebottermux_wake"))


def normalize_wake_mode(item: dict[str, Any]) -> str:
    wake_requested = bool_field(item.get("storebottermux_wake"))
    raw_mode = str(item.get("storebottermux_wake_mode") or "").strip().lower()
    if raw_mode not in ALLOWED_WAKE_MODES:
        raw_mode = "foreground" if wake_requested else "check"
    if not wake_requested:
        return "check"
    return raw_mode


def normalize_spec(item: dict[str, Any]) -> dict[str, Any]:
    return {
        "enabled": storebottermux_request_requested(item),
        "mode": normalize_wake_mode(item),
        "adb_path": str(item.get("adb_path") or "").strip(),
        "serial": str(item.get("storebottermux_serial") or item.get("adb_serial") or item.get("serial") or "").strip(),
        "package": str(item.get("storebottermux_package") or DEFAULT_STOREBOTTERMUX_PACKAGE).strip()
        or DEFAULT_STOREBOTTERMUX_PACKAGE,
        "kakao_package": str(item.get("kakao_package") or DEFAULT_KAKAO_PACKAGE).strip() or DEFAULT_KAKAO_PACKAGE,
        "kakao_foreground": bool_field(item.get("kakao_foreground") or item.get("storebottermux_kakao_foreground")),
        "screenshot": bool_field(item.get("storebottermux_screenshot") or item.get("screenshot")),
        "logcat_tail": max(0, int(item.get("storebottermux_logcat_tail") or item.get("logcat_tail") or 0)),
        "timeout_sec": max(3, int(item.get("storebottermux_timeout_sec") or item.get("adb_timeout_sec") or 15)),
        "firebase_base": str(item.get("firebase_base") or DEFAULT_FIREBASE_BASE).strip() or DEFAULT_FIREBASE_BASE,
        "firebase_timeout_sec": max(1.0, float(item.get("firebase_timeout_sec") or 3.0)),
        "local_direct_port": max(1, int(item.get("storebottermux_local_direct_port") or 8765)),
        "forward_port": max(1, int(item.get("storebottermux_forward_port") or 18765)),
        "service_component": str(item.get("storebottermux_service_component") or "").strip(),
        "broadcast_action": str(item.get("storebottermux_broadcast_action") or "").strip(),
        "screenshot_on_fail": bool_field(item.get("storebottermux_screenshot_on_fail") or item.get("screenshot_on_fail")),
        "scheduled": bool_field(item.get("storebottermux_scheduled") or item.get("scheduled")),
        "state_file": str(item.get("storebottermux_state_file") or item.get("state_file") or "").strip(),
        "deep_every_sec": max(60, int(item.get("storebottermux_deep_every_sec") or item.get("deep_every_sec") or 180)),
        "logcat_every_sec": max(60, int(item.get("storebottermux_logcat_every_sec") or item.get("logcat_every_sec") or 300)),
        "log_jsonl": str(item.get("storebottermux_log_jsonl") or item.get("log_jsonl") or "").strip(),
    }


def load_state(path: str) -> dict[str, Any]:
    if not path:
        return {}
    try:
        return json.loads(Path(path).read_text(encoding="utf-8"))
    except Exception:
        return {}


def save_state(path: str, state: dict[str, Any]) -> None:
    if not path:
        return
    target = Path(path)
    target.parent.mkdir(parents=True, exist_ok=True)
    target.write_text(json.dumps(state, ensure_ascii=False, indent=2, sort_keys=True), encoding="utf-8")


def due(now: int, last: Any, every_sec: int) -> bool:
    last_ms = normalize_ts_ms(last)
    return last_ms <= 0 or now - last_ms >= every_sec * 1000


def throttle_state(spec: dict[str, Any]) -> dict[str, Any]:
    current = now_ms()
    state = load_state(str(spec.get("state_file") or ""))
    scheduled = bool(spec.get("scheduled"))
    deep_due = True
    logcat_due = int(spec.get("logcat_tail") or 0) > 0
    if scheduled:
        deep_due = due(current, state.get("last_deep_ms"), int(spec.get("deep_every_sec") or 180))
        logcat_due = bool(spec.get("logcat_tail")) and due(
            current,
            state.get("last_logcat_ms"),
            int(spec.get("logcat_every_sec") or 300),
        )
    return {
        "scheduled": scheduled,
        "state_file": str(spec.get("state_file") or ""),
        "deep_due": deep_due,
        "logcat_due": logcat_due,
        "deep_every_sec": int(spec.get("deep_every_sec") or 180),
        "logcat_every_sec": int(spec.get("logcat_every_sec") or 300),
        "loaded_state": {
            "last_light_ms": state.get("last_light_ms"),
            "last_deep_ms": state.get("last_deep_ms"),
            "last_logcat_ms": state.get("last_logcat_ms"),
        },
    }


def update_throttle_state(spec: dict[str, Any], throttle: dict[str, Any]) -> None:
    path = str(spec.get("state_file") or "")
    if not path:
        return
    state = load_state(path)
    current = now_ms()
    state["last_light_ms"] = current
    if throttle.get("deep_due"):
        state["last_deep_ms"] = current
    if throttle.get("logcat_due"):
        state["last_logcat_ms"] = current
    save_state(path, state)


def append_jsonl(path: str, result: dict[str, Any]) -> None:
    if not path:
        return
    target = Path(path)
    target.parent.mkdir(parents=True, exist_ok=True)
    with target.open("a", encoding="utf-8") as handle:
        handle.write(json.dumps(result, ensure_ascii=False, separators=(",", ":")) + "\n")


def finalize_result(
    result: dict[str, Any],
    spec: dict[str, Any],
    throttle: dict[str, Any],
    started: int,
) -> dict[str, Any]:
    result["duration_ms"] = now_ms() - started
    try:
        update_throttle_state(spec, throttle)
    except Exception as exc:  # noqa: BLE001 - logging helper must not hide the real result.
        result.setdefault("warnings", []).append(f"state_update_failed: {compact_text(exc, 200)}")
    try:
        append_jsonl(str(spec.get("log_jsonl") or ""), result)
    except Exception as exc:  # noqa: BLE001
        result.setdefault("warnings", []).append(f"log_jsonl_failed: {compact_text(exc, 200)}")
    return result


def _run(cmd: list[str], timeout_sec: int) -> subprocess.CompletedProcess[str]:
    return subprocess.run(
        cmd,
        text=True,
        stdout=subprocess.PIPE,
        stderr=subprocess.PIPE,
        timeout=timeout_sec,
        check=False,
    )


def _adb_base(adb_path: str, serial: str = "") -> list[str]:
    cmd = [adb_path]
    if serial:
        cmd.extend(["-s", serial])
    return cmd


def shell(base: list[str], args: list[str], timeout_sec: int) -> subprocess.CompletedProcess[str]:
    return _run(base + ["shell", *args], timeout_sec)


def command_result(proc: subprocess.CompletedProcess[str], limit: int = 1200) -> dict[str, Any]:
    text = f"{proc.stdout}\n{proc.stderr}".strip()
    return {
        "returncode": proc.returncode,
        "stdout_tail": compact_text(proc.stdout, limit),
        "stderr_tail": compact_text(proc.stderr, limit),
        "output_tail": compact_text(text, limit),
    }


def package_version(text: str) -> dict[str, str]:
    result: dict[str, str] = {}
    for key in ("versionName", "versionCode"):
        match = re.search(rf"\b{key}=([^\s]+)", text)
        if match:
            result[key] = match.group(1)
    return result


def check_package(base: list[str], package_name: str, timeout_sec: int) -> dict[str, Any]:
    pm_path = shell(base, ["pm", "path", package_name], timeout_sec)
    installed = pm_path.returncode == 0 and "package:" in pm_path.stdout
    dumpsys = shell(base, ["dumpsys", "package", package_name], timeout_sec) if installed else None
    version_text = f"{dumpsys.stdout}\n{dumpsys.stderr}" if dumpsys else ""
    return {
        "package_name": package_name,
        "installed": installed,
        "pm_path": command_result(pm_path),
        "version": package_version(version_text),
    }


def check_pid(base: list[str], package_name: str, timeout_sec: int) -> dict[str, Any]:
    proc = shell(base, ["pidof", package_name], timeout_sec)
    pids = [part for part in proc.stdout.strip().split() if part.isdigit()]
    return {"running": bool(pids), "pids": pids, **command_result(proc, 800)}


def extract_top_package(text: str) -> str:
    patterns = [
        r"mCurrentFocus=.*?\s([A-Za-z0-9_.]+)/[A-Za-z0-9_.$/]+",
        r"mFocusedApp=.*?\s([A-Za-z0-9_.]+)/[A-Za-z0-9_.$/]+",
        r"topResumedActivity=.*?\s([A-Za-z0-9_.]+)/[A-Za-z0-9_.$/]+",
        r"ResumedActivity:.*?\s([A-Za-z0-9_.]+)/[A-Za-z0-9_.$/]+",
    ]
    for pattern in patterns:
        match = re.search(pattern, text)
        if match:
            return match.group(1)
    return ""


def check_foreground(base: list[str], package_name: str, timeout_sec: int) -> dict[str, Any]:
    window_proc = shell(base, ["dumpsys", "window", "windows"], timeout_sec)
    activity_proc = shell(base, ["dumpsys", "activity", "activities"], timeout_sec)
    combined = f"{window_proc.stdout}\n{window_proc.stderr}\n{activity_proc.stdout}\n{activity_proc.stderr}"
    top_package = extract_top_package(combined)
    return {
        "top_package": top_package,
        "is_target": bool(top_package and top_package == package_name),
        "window": command_result(window_proc, 1200),
        "activity": command_result(activity_proc, 1200),
    }


def check_power(base: list[str], timeout_sec: int) -> dict[str, Any]:
    proc = shell(base, ["dumpsys", "power"], timeout_sec)
    text = f"{proc.stdout}\n{proc.stderr}"
    interactive: bool | None = None
    match = re.search(r"\bmInteractive=(true|false)", text)
    if match:
        interactive = match.group(1) == "true"
    elif "state=ON" in text:
        interactive = True
    elif "state=OFF" in text:
        interactive = False
    return {"interactive": interactive, **command_result(proc, 1200)}


def check_keyguard(base: list[str], timeout_sec: int) -> dict[str, Any]:
    proc = shell(base, ["dumpsys", "window", "policy"], timeout_sec)
    text = f"{proc.stdout}\n{proc.stderr}"
    locked: bool | None = None
    if any(token in text for token in ("isStatusBarKeyguard=true", "mShowingLockscreen=true", "showing=true")):
        locked = True
    elif any(token in text for token in ("isStatusBarKeyguard=false", "mShowingLockscreen=false", "showing=false")):
        locked = False
    return {"locked": locked, **command_result(proc, 1200)}


def check_settings(base: list[str], package_name: str, timeout_sec: int) -> dict[str, Any]:
    accessibility_enabled = shell(base, ["settings", "get", "secure", "accessibility_enabled"], timeout_sec)
    enabled_services = shell(base, ["settings", "get", "secure", "enabled_accessibility_services"], timeout_sec)
    notification_listeners = shell(base, ["settings", "get", "secure", "enabled_notification_listeners"], timeout_sec)
    services_text = enabled_services.stdout or ""
    listeners_text = notification_listeners.stdout or ""
    return {
        "accessibility_enabled_raw": compact_text(accessibility_enabled.stdout.strip(), 400),
        "accessibility_service_present": package_name in services_text,
        "enabled_accessibility_services_tail": compact_text(services_text, 1200),
        "notification_listener_present": package_name in listeners_text,
        "enabled_notification_listeners_tail": compact_text(listeners_text, 1200),
        "commands": {
            "accessibility_enabled": command_result(accessibility_enabled, 400),
            "enabled_accessibility_services": command_result(enabled_services, 1200),
            "enabled_notification_listeners": command_result(notification_listeners, 1200),
        },
    }


def encoded_url(base_url: str, path: str, query: dict[str, str] | None = None) -> str:
    safe_path = "/".join(urllib.parse.quote(part, safe="") for part in path.split("/") if part)
    url = f"{base_url.rstrip('/')}/{safe_path}.json"
    if query:
        url += "?" + urllib.parse.urlencode(query)
    return url


def firebase_get(base_url: str, path: str, timeout: float, query: dict[str, str] | None = None) -> Any:
    with urllib.request.urlopen(encoded_url(base_url, path, query), timeout=timeout) as response:
        raw = response.read().decode("utf-8")
    if not raw or raw == "null":
        return None
    return json.loads(raw)


def query_last(base_url: str, path: str, limit: int, timeout: float) -> dict[str, Any]:
    query = {"orderBy": json.dumps("$key"), "limitToLast": str(max(1, limit))}
    value = firebase_get(base_url, path, timeout, query)
    return value if isinstance(value, dict) else {}


def fetch_firebase_summary(base_url: str, timeout: float) -> dict[str, Any]:
    data: dict[str, Any] = {}
    errors: list[str] = []
    for name, path in FIREBASE_PATHS.items():
        try:
            if name in {"requests", "pending_queue"}:
                data[name] = query_last(base_url, path, 20, timeout)
            else:
                data[name] = firebase_get(base_url, path, timeout)
        except Exception as exc:  # noqa: BLE001 - diagnostics should continue with ADB fallback.
            errors.append(f"{name}: {exc.__class__.__name__}: {compact_text(exc, 160)}")
            data[name] = None
    return {"available": not errors, "errors": errors, "data": summarize_firebase_data(data)}


def normalize_ts_ms(value: Any) -> int:
    if not isinstance(value, (int, float)):
        return 0
    ts = int(value)
    if 0 < ts < 100_000_000_000:
        return ts * 1000
    return ts


def extract_ts_ms(value: Any) -> int:
    if not isinstance(value, dict):
        return 0
    for key in ("updated_at_ms", "ts_ms", "ts", "timestamp", "finished_at_ms", "created_at_ms", "started_at_ms"):
        ts = normalize_ts_ms(value.get(key))
        if ts > 0:
            return ts
    heartbeat = value.get("heartbeat")
    if isinstance(heartbeat, dict):
        return extract_ts_ms(heartbeat)
    return 0


def age_sec(value: Any) -> int:
    ts = normalize_ts_ms(value)
    if ts <= 0:
        return -1
    return max(0, int((now_ms() - ts) / 1000))


def rows_from_dict(value: Any) -> list[dict[str, Any]]:
    rows: list[dict[str, Any]] = []
    if not isinstance(value, dict):
        return rows
    for key, row in sorted(value.items()):
        if isinstance(row, dict):
            item = dict(row)
            item["_key"] = key
            rows.append(item)
    return rows


def request_status(row: dict[str, Any]) -> str:
    return str(row.get("status") or row.get("local_recovery_status") or row.get("ingress_status") or "").strip().lower()


def summarize_requests(raw: Any) -> dict[str, Any]:
    rows = rows_from_dict(raw)
    statuses: dict[str, int] = {}
    active: list[dict[str, Any]] = []
    errors: list[dict[str, Any]] = []
    for row in rows:
        status = request_status(row) or "unknown"
        statuses[status] = statuses.get(status, 0) + 1
        ts = extract_ts_ms(row)
        entry = {"id": row.get("_key") or row.get("request_id"), "status": status, "age_sec": age_sec(ts)}
        if status in ACTIVE_REQUEST_STATUSES:
            active.append(entry)
        if status in {"error", "action_error"}:
            errors.append(entry)
    active.sort(key=lambda item: item.get("age_sec", -1), reverse=True)
    errors.sort(key=lambda item: item.get("age_sec", -1), reverse=True)
    return {"count": len(rows), "statuses": statuses, "active": active[:5], "errors": errors[:5]}


def summarize_pending_queue(raw: Any) -> dict[str, Any]:
    rows = rows_from_dict(raw)
    unsent = [row for row in rows if row.get("sent") is not True and row.get("skipped") is not True]
    oldest_ts = min((extract_ts_ms(row) for row in unsent if extract_ts_ms(row) > 0), default=0)
    return {"count": len(rows), "unsent_count": len(unsent), "oldest_unsent_age_sec": age_sec(oldest_ts)}


def summarize_firebase_data(data: dict[str, Any]) -> dict[str, Any]:
    input_health = data.get("input_health") if isinstance(data.get("input_health"), dict) else {}
    bridge_latest = data.get("bridge_latest") if isinstance(data.get("bridge_latest"), dict) else {}
    scoped_hb = data.get("storebot_termux_scoped_heartbeat") if isinstance(data.get("storebot_termux_scoped_heartbeat"), dict) else {}
    legacy_hb = data.get("storebot_termux_heartbeat") if isinstance(data.get("storebot_termux_heartbeat"), dict) else {}
    transport_hb = scoped_hb or legacy_hb
    codex_hb = data.get("storebot_codex_heartbeat") if isinstance(data.get("storebot_codex_heartbeat"), dict) else {}
    return {
        "transport_heartbeat_age_sec": age_sec(extract_ts_ms(transport_hb)),
        "transport_version": transport_hb.get("version_name") or transport_hb.get("app_version_name") or "",
        "accessibility_enabled": transport_hb.get("accessibility_enabled"),
        "notification_listener_enabled": transport_hb.get("notification_listener_enabled"),
        "codex_heartbeat_age_sec": age_sec(extract_ts_ms(codex_hb)),
        "local_direct_listening": codex_hb.get("local_direct_listening"),
        "input_health_status": input_health.get("status") or input_health.get("request_status") or input_health.get("event"),
        "input_last_request_id": input_health.get("last_request_id"),
        "input_last_error": compact_text(input_health.get("last_request_error") or input_health.get("last_error"), 300),
        "claim_latest_age_sec": age_sec(extract_ts_ms(data.get("claim_latest"))),
        "bridge_latest_age_sec": age_sec(extract_ts_ms(bridge_latest)),
        "bridge_latest_status": bridge_latest.get("status") or bridge_latest.get("event"),
        "requests": summarize_requests(data.get("requests")),
        "pending_queue": summarize_pending_queue(data.get("pending_queue")),
    }


def http_get(url: str, timeout_sec: int) -> dict[str, Any]:
    started = now_ms()
    try:
        with urllib.request.urlopen(url, timeout=timeout_sec) as response:
            raw = response.read().decode("utf-8", errors="replace")
            payload: Any = None
            try:
                payload = json.loads(raw)
            except Exception:
                payload = None
            return {
                "status": "done",
                "http_status": response.status,
                "duration_ms": now_ms() - started,
                "json": payload,
                "body_tail": compact_text(raw, 1200),
            }
    except Exception as exc:
        return {"status": "failed", "duration_ms": now_ms() - started, "reason": compact_text(exc, 500)}


def check_local_direct(adb_path: str, serial: str, local_port: int, device_port: int, timeout_sec: int) -> dict[str, Any]:
    base = _adb_base(adb_path, serial)
    setup = _run(base + ["forward", f"tcp:{local_port}", f"tcp:{device_port}"], timeout_sec)
    result: dict[str, Any] = {"forward": command_result(setup, 1200), "local_port": local_port, "device_port": device_port}
    if setup.returncode != 0:
        result["health"] = {"status": "failed", "reason": "adb forward failed"}
        return result
    try:
        result["health"] = http_get(f"http://127.0.0.1:{local_port}/storebot/health", timeout_sec)
    finally:
        _run(base + ["forward", "--remove", f"tcp:{local_port}"], timeout_sec)
    return result


def take_screenshot(base: list[str], req_id: str, timeout_sec: int) -> dict[str, Any]:
    out_dir = Path(tempfile.gettempdir()) / "codex_ops_storebottermux_screenshots"
    out_dir.mkdir(parents=True, exist_ok=True)
    safe_req = re.sub(r"[^0-9A-Za-z_.-]+", "_", req_id or "storebottermux")[:80]
    screenshot_path = out_dir / f"{safe_req}_{now_ms()}.png"
    try:
        proc = subprocess.run(
            base + ["exec-out", "screencap", "-p"],
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE,
            timeout=timeout_sec,
            check=False,
        )
    except Exception as exc:
        return {"status": "failed", "reason": compact_text(exc, 500)}
    if proc.returncode == 0 and proc.stdout:
        screenshot_path.write_bytes(proc.stdout)
        return {"status": "done", "path": str(screenshot_path), "bytes": len(proc.stdout)}
    return {
        "status": "failed",
        "returncode": proc.returncode,
        "stderr_tail": compact_text(proc.stderr.decode("utf-8", errors="replace"), 1200),
    }


def analyze_logcat(text: str) -> dict[str, Any]:
    matched = []
    for line in text.splitlines():
        if any(pattern in line for pattern in ERROR_PATTERNS):
            matched.append(compact_text(line, 500))
    return {"matched_count": len(matched), "matched_tail": matched[-20:]}


def run_storebottermux_watchdog(item: dict[str, Any], req_id: str = "") -> dict[str, Any]:
    spec = normalize_spec(item)
    started = now_ms()
    throttle = throttle_state(spec)
    if not spec.get("enabled"):
        return finalize_result(
            {"status": "storebottermux_skipped", "enabled": False, "throttle": throttle},
            spec,
            throttle,
            started,
        )

    resolver = resolve_adb_path({"adb_path": spec.get("adb_path")})
    adb_path = str(resolver.get("adb_path") or "")
    result: dict[str, Any] = {
        "status": "adb_unavailable",
        "enabled": True,
        "mode": spec["mode"],
        "package": spec["package"],
        "adb_path": adb_path,
        "adb_path_source": resolver.get("adb_path_source") or "",
        "adb_candidates": resolver.get("adb_candidates") or [],
        "serial": "",
        "checks": {},
        "firebase": {},
        "health": {},
        "throttle": throttle,
        "safety": {
            "kakao_message_send": False,
            "kakao_chat_touch": False,
            "text_input": False,
            "unlock": False,
            "install": False,
            "kakao_foreground_default": False,
        },
        "duration_ms": 0,
    }
    if not adb_path:
        result["reason"] = "adb command not found"
        result["health"] = {"status": "fail", "severity": "error", "issues": ["adb_unavailable"]}
        return finalize_result(result, spec, throttle, started)

    timeout_sec = int(spec["timeout_sec"])
    try:
        devices_proc = _run([adb_path, "devices", "-l"], timeout_sec)
    except Exception as exc:
        result["reason"] = compact_text(exc, 500)
        result["health"] = {"status": "fail", "severity": "error", "issues": ["adb_devices_failed"]}
        return finalize_result(result, spec, throttle, started)

    devices = parse_devices(devices_proc.stdout)
    serial, select_error = select_device(devices, str(spec.get("serial") or ""))
    result["devices"] = devices
    result["serial"] = serial
    result["checks"]["devices"] = command_result(devices_proc, 1200)
    if throttle.get("deep_due"):
        result["firebase"] = fetch_firebase_summary(str(spec["firebase_base"]), float(spec["firebase_timeout_sec"]))
    else:
        result["firebase"] = {"skipped": True, "reason": "scheduled deep throttle"}
    if select_error:
        result["reason"] = select_error
        result["health"] = {"status": "fail", "severity": "error", "issues": ["adb_device_unavailable"]}
        return finalize_result(result, spec, throttle, started)

    base = _adb_base(adb_path, serial)
    package_name = str(spec["package"])
    result["checks"]["package"] = check_package(base, package_name, timeout_sec)
    result["checks"]["pid"] = check_pid(base, package_name, timeout_sec)
    result["checks"]["foreground_before"] = check_foreground(base, package_name, timeout_sec)
    result["checks"]["power_before"] = check_power(base, timeout_sec)
    result["checks"]["keyguard_before"] = check_keyguard(base, timeout_sec)
    if throttle.get("deep_due"):
        result["checks"]["settings"] = check_settings(base, package_name, timeout_sec)
        result["checks"]["local_direct"] = check_local_direct(
            adb_path,
            serial,
            int(spec["forward_port"]),
            int(spec["local_direct_port"]),
            timeout_sec,
        )
    else:
        result["checks"]["settings"] = {"status": "skipped", "reason": "scheduled deep throttle"}
        result["checks"]["local_direct"] = {"status": "skipped", "reason": "scheduled deep throttle"}
    result["foreground_before_package"] = result["checks"]["foreground_before"].get("top_package") or ""
    result["screen_interactive_before"] = result["checks"]["power_before"].get("interactive")
    result["keyguard_locked_before"] = result["checks"]["keyguard_before"].get("locked")

    if not result["checks"]["package"].get("installed"):
        result["status"] = "storebottermux_check_failed"
        result["reason"] = f"{package_name} is not installed"
        result["health"] = summarize_health(result)
        return finalize_result(result, spec, throttle, started)

    mode = str(spec["mode"])
    if mode in {"wake_app", "foreground", "service_refresh"}:
        proc = shell(base, ["input", "keyevent", "KEYCODE_WAKEUP"], timeout_sec)
        result["checks"]["wake_screen"] = {"status": "done" if proc.returncode == 0 else "failed", **command_result(proc)}
        time.sleep(0.5)

    if mode in {"wake_app", "foreground"}:
        proc = shell(base, ["monkey", "-p", package_name, "-c", "android.intent.category.LAUNCHER", "1"], timeout_sec)
        result["checks"]["bring_storebottermux_foreground"] = {
            "status": "done" if proc.returncode == 0 else "failed",
            **command_result(proc),
        }
        time.sleep(1.0)

    if mode == "service_refresh":
        service_component = str(spec.get("service_component") or "")
        broadcast_action = str(spec.get("broadcast_action") or "")
        if service_component:
            proc = shell(base, ["am", "start-foreground-service", "-n", service_component], timeout_sec)
            result["checks"]["service_refresh"] = {
                "status": "done" if proc.returncode == 0 else "failed",
                **command_result(proc),
            }
        else:
            result["checks"]["service_refresh"] = {"status": "skipped", "reason": "storebottermux_service_component missing"}
        if broadcast_action:
            proc = shell(base, ["am", "broadcast", "-a", broadcast_action, "-p", package_name], timeout_sec)
            result["checks"]["broadcast_refresh"] = {
                "status": "done" if proc.returncode == 0 else "failed",
                **command_result(proc),
            }

    if bool(spec.get("kakao_foreground")) and bool_field(item.get("storebottermux_wake")):
        result["checks"]["kakao_foreground_aux"] = run_kakao_wake(
            {
                "kakao_check": True,
                "kakao_wake": True,
                "kakao_wake_mode": "foreground",
                "kakao_package": spec["kakao_package"],
                "adb_path": adb_path,
                "adb_serial": serial,
                "kakao_timeout_sec": timeout_sec,
            },
            req_id,
        )

    result["checks"]["foreground_after"] = check_foreground(base, package_name, timeout_sec)
    result["checks"]["power_after"] = check_power(base, timeout_sec)
    result["checks"]["keyguard_after"] = check_keyguard(base, timeout_sec)
    result["foreground_after_package"] = result["checks"]["foreground_after"].get("top_package") or ""
    result["screen_interactive_after"] = result["checks"]["power_after"].get("interactive")
    result["keyguard_locked_after"] = result["checks"]["keyguard_after"].get("locked")

    logcat_tail = int(spec.get("logcat_tail") or 0)
    if logcat_tail and throttle.get("logcat_due"):
        proc = _run(base + ["logcat", "-d", "-t", str(logcat_tail)], max(timeout_sec, 30))
        log_text = f"{proc.stdout}\n{proc.stderr}"
        result["checks"]["logcat"] = {
            "status": "done" if proc.returncode == 0 else "failed",
            **command_result(proc, 5000),
            "analysis": analyze_logcat(log_text),
        }
    elif logcat_tail:
        result["checks"]["logcat"] = {"status": "skipped", "reason": "scheduled logcat throttle"}

    result["health"] = summarize_health(result)
    if spec.get("screenshot") or (spec.get("screenshot_on_fail") and result["health"].get("status") != "ok"):
        result["checks"]["screenshot"] = take_screenshot(base, req_id, timeout_sec)
    wake_failed = any(
        isinstance(result["checks"].get(name), dict) and result["checks"][name].get("status") == "failed"
        for name in (
            "wake_screen",
            "bring_storebottermux_foreground",
            "service_refresh",
            "broadcast_refresh",
        )
    )
    kakao_aux = result["checks"].get("kakao_foreground_aux")
    if isinstance(kakao_aux, dict) and kakao_aux.get("status") != "kakao_wake_done":
        wake_failed = True
    if mode == "check":
        result["status"] = "storebottermux_checked"
    else:
        result["status"] = "storebottermux_wake_failed" if wake_failed else "storebottermux_wake_done"
    return finalize_result(result, spec, throttle, started)


def summarize_health(result: dict[str, Any]) -> dict[str, Any]:
    issues: list[str] = []
    checks = result.get("checks") if isinstance(result.get("checks"), dict) else {}
    package = checks.get("package") if isinstance(checks.get("package"), dict) else {}
    pid = checks.get("pid") if isinstance(checks.get("pid"), dict) else {}
    settings = checks.get("settings") if isinstance(checks.get("settings"), dict) else {}
    local_direct = checks.get("local_direct") if isinstance(checks.get("local_direct"), dict) else {}
    local_health = local_direct.get("health") if isinstance(local_direct.get("health"), dict) else {}
    firebase_data = ((result.get("firebase") or {}).get("data") if isinstance(result.get("firebase"), dict) else {}) or {}

    if not package.get("installed"):
        issues.append("package_missing")
    if not pid.get("running"):
        issues.append("process_not_running")
    if settings.get("accessibility_service_present") is False:
        issues.append("accessibility_service_not_enabled")
    if settings.get("notification_listener_present") is False:
        issues.append("notification_listener_not_enabled")
    if "local_direct" in checks and local_direct.get("status") != "skipped" and local_health.get("status") != "done":
        issues.append("local_direct_health_unavailable")
    if firebase_data.get("local_direct_listening") is False:
        issues.append("firebase_local_direct_not_listening")
    pending_queue = firebase_data.get("pending_queue") if isinstance(firebase_data.get("pending_queue"), dict) else {}
    if int(pending_queue.get("unsent_count") or 0) > 0:
        issues.append("pending_queue_unsent")
    requests = firebase_data.get("requests") if isinstance(firebase_data.get("requests"), dict) else {}
    if requests.get("active"):
        issues.append("active_reply_requests_present")
    logcat = checks.get("logcat") if isinstance(checks.get("logcat"), dict) else {}
    analysis = logcat.get("analysis") if isinstance(logcat.get("analysis"), dict) else {}
    if int(analysis.get("matched_count") or 0) > 0:
        issues.append("logcat_error_patterns_present")

    severity = "ok"
    if any(issue in issues for issue in ("package_missing", "local_direct_health_unavailable")):
        severity = "error"
    elif issues:
        severity = "warn"
    status = "fail" if severity == "error" else severity
    return {"status": status, "severity": severity, "issues": issues}


def exit_code_for_result(result: dict[str, Any]) -> int:
    status = str(result.get("status") or "")
    if status in {"storebottermux_checked", "storebottermux_wake_done", "storebottermux_skipped"}:
        return 0
    if status == "adb_unavailable":
        return ADB_UNAVAILABLE_EXIT
    return CHECK_FAILED_EXIT


def parse_args(argv: list[str]) -> argparse.Namespace:
    parser = argparse.ArgumentParser(description="StoreBotTermux reply pipeline USB ADB watchdog for codex_ops")
    parser.add_argument("--json", action="store_true", help="JSON 결과 출력. 현재 출력은 항상 JSON입니다.")
    parser.add_argument("--adb-path", default="")
    parser.add_argument("--serial", default="")
    parser.add_argument("--package", default=DEFAULT_STOREBOTTERMUX_PACKAGE)
    parser.add_argument("--mode", choices=sorted(ALLOWED_WAKE_MODES), default="check")
    parser.add_argument("--wake", action="store_true")
    parser.add_argument("--screenshot", action="store_true")
    parser.add_argument("--screenshot-on-fail", action="store_true")
    parser.add_argument("--logcat-tail", type=int, default=0)
    parser.add_argument("--timeout-sec", type=int, default=15)
    parser.add_argument("--firebase-base", default=DEFAULT_FIREBASE_BASE)
    parser.add_argument("--local-direct-port", type=int, default=8765)
    parser.add_argument("--forward-port", type=int, default=18765)
    parser.add_argument("--service-component", default="")
    parser.add_argument("--broadcast-action", default="")
    parser.add_argument("--kakao-foreground", action="store_true", help="명시 wake 때만 KakaoTalk foreground 보조 실행")
    parser.add_argument("--kakao-package", default=DEFAULT_KAKAO_PACKAGE)
    parser.add_argument("--scheduled", action="store_true", help="state-file 기준 deep/logcat throttle 적용")
    parser.add_argument("--state-file", default="")
    parser.add_argument("--deep-every-sec", type=int, default=180)
    parser.add_argument("--logcat-every-sec", type=int, default=300)
    parser.add_argument("--log-jsonl", default="")
    parser.add_argument("--request-id", default="")
    return parser.parse_args(argv)


def main(argv: list[str]) -> int:
    args = parse_args(argv)
    wake_requested = args.wake or args.mode != "check"
    item = {
        "storebottermux_check": True,
        "storebottermux_wake": wake_requested,
        "storebottermux_wake_mode": args.mode if wake_requested else "check",
        "storebottermux_package": args.package,
        "storebottermux_screenshot": args.screenshot,
        "storebottermux_screenshot_on_fail": args.screenshot_on_fail,
        "storebottermux_logcat_tail": args.logcat_tail,
        "storebottermux_timeout_sec": args.timeout_sec,
        "storebottermux_local_direct_port": args.local_direct_port,
        "storebottermux_forward_port": args.forward_port,
        "storebottermux_service_component": args.service_component,
        "storebottermux_broadcast_action": args.broadcast_action,
        "storebottermux_kakao_foreground": args.kakao_foreground,
        "storebottermux_scheduled": args.scheduled,
        "storebottermux_state_file": args.state_file,
        "storebottermux_deep_every_sec": args.deep_every_sec,
        "storebottermux_logcat_every_sec": args.logcat_every_sec,
        "storebottermux_log_jsonl": args.log_jsonl,
        "kakao_package": args.kakao_package,
        "firebase_base": args.firebase_base,
        "adb_path": args.adb_path,
        "adb_serial": args.serial,
    }
    result = run_storebottermux_watchdog(item, args.request_id)
    print(json.dumps(result, ensure_ascii=False, indent=2))
    return exit_code_for_result(result)


if __name__ == "__main__":
    raise SystemExit(main(sys.argv[1:]))
