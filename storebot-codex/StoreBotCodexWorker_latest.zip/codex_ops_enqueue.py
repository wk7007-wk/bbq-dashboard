#!/usr/bin/env python3
from __future__ import annotations

import argparse
import json
import os
import secrets
import sys
import time
from pathlib import Path
from typing import Any

from storebot_codex_worker import build_no_live_context_bundle_v1, fb_get, fb_put, now_ms


CODEX_OPS_BASE_PATH = os.environ.get("CODEX_OPS_BASE_PATH", "/packhelper/codex_ops_v2").rstrip("/")
REQUESTS_PATH = f"{CODEX_OPS_BASE_PATH}/requests"
DEFAULT_CWD = "/root/my-first-project"
ALLOWED_TARGET_HOSTS = {"subphone", "pc", "any"}
ALLOWED_ENGINES = {"auto", "sdk", "exec"}
NO_SEND_ACTIONS = {"self_fix", "report", "log_only"}
RESUME_PROMPT_ACTION = "codex_resume_prompt_file"
ADB_CHECK_ACTION = "adb_check"
DIRECT_PROBE_ACTION = "direct_probe"
DEFAULT_PC_NODE = "pc_codex_resource_01"


def read_task(args: argparse.Namespace) -> str:
    if args.task.strip():
        return args.task.strip()
    if args.task_file.strip():
        return Path(args.task_file).read_text(encoding="utf-8").strip()
    if args.stdin or not sys.stdin.isatty():
        return sys.stdin.read().strip()
    return ""


def normalize_target_host(value: Any, default: str = "subphone") -> str:
    text = str(value or default).strip().lower()
    return text if text in ALLOWED_TARGET_HOSTS else default


def normalize_engine(value: Any, default: str = "auto") -> str:
    text = str(value or default).strip().lower()
    return text if text in ALLOWED_ENGINES else default


def normalize_domain(value: Any, project: Any) -> str:
    text = str(value or "").strip()
    if text:
        return text
    fallback = str(project or "my-first-project").strip()
    return fallback or "my-first-project"


def parse_json_object(value: str, label: str) -> dict[str, Any]:
    text = value.strip()
    if not text:
        return {}
    try:
        decoded = json.loads(text)
    except json.JSONDecodeError as exc:
        raise SystemExit(f"{label} must be valid JSON: {exc}") from exc
    if not isinstance(decoded, dict):
        raise SystemExit(f"{label} must be a JSON object")
    return decoded


def load_context_bundle_seed(args: argparse.Namespace) -> dict[str, Any]:
    seed: dict[str, Any] = {}
    context_file = getattr(args, "context_bundle_file", "").strip()
    if context_file:
        seed.update(parse_json_object(Path(context_file).read_text(encoding="utf-8"), "--context-bundle-file"))
    seed.update(parse_json_object(getattr(args, "context_bundle_json", ""), "--context-bundle-json"))
    return seed


def apply_no_send_dry_run_contract(key: str, payload: dict[str, Any], args: argparse.Namespace) -> None:
    action = str(getattr(args, "action", "") or "").strip() or "report"
    if action not in NO_SEND_ACTIONS:
        raise SystemExit(f"--action must be one of: {', '.join(sorted(NO_SEND_ACTIONS))}")
    payload["action"] = action
    payload["dry_run"] = True
    payload["no_send"] = True
    payload["no_publish"] = True
    payload["no_live"] = True
    payload["no_write"] = True
    payload["bypass_adb"] = True
    payload["bypass_kakao"] = True
    payload["safety_action_mode"] = "dry_run_only"
    payload["reply_target"] = {"type": "firebase_result", "kakao_publish": False}

    seed = {
        "request_id": key,
        "thread_key": payload.get("session") or payload.get("session_id") or "",
        "app_state": {
            "project": payload.get("project") or "",
            "domain": payload.get("domain") or "",
            "target_host": payload.get("target_host") or "",
        },
    }
    seed.update(load_context_bundle_seed(args))
    payload["context_bundle_v1"] = build_no_live_context_bundle_v1(key, seed)


def build_no_send_dry_run_payload(args: argparse.Namespace, task: str) -> tuple[str, dict[str, Any]]:
    key, payload = build_payload(args, task)
    apply_no_send_dry_run_contract(key, payload, args)
    return key, payload


def add_adb_check_payload(payload: dict[str, Any], args: argparse.Namespace) -> None:
    if not getattr(args, "adb_check", False):
        return
    payload["adb_check"] = {
        "enabled": True,
        "adb_path": getattr(args, "adb_path", "").strip(),
        "serial": args.adb_serial.strip(),
        "apk_path": args.apk_path.strip(),
        "package_name": args.package_name.strip(),
        "activity": args.activity.strip(),
        "screenshot": args.adb_screenshot,
        "logcat_tail": max(0, int(args.adb_logcat_tail)),
        "install": args.adb_install,
        "launch": args.adb_launch,
    }


def kakao_requested(args: argparse.Namespace) -> bool:
    return bool(getattr(args, "kakao_check", False) or getattr(args, "kakao_wake", False))


def storebottermux_requested(args: argparse.Namespace) -> bool:
    return bool(getattr(args, "storebottermux_check", False) or getattr(args, "storebottermux_wake", False))


def posdelay_requested(args: argparse.Namespace) -> bool:
    return bool(getattr(args, "posdelay_check", False) or getattr(args, "posdelay_wake", False))


def adb_only_requested(args: argparse.Namespace) -> bool:
    return bool(getattr(args, "adb_only", False))


def direct_probe_requested(args: argparse.Namespace) -> bool:
    return bool(getattr(args, "direct_probe", False))


def add_kakao_payload(payload: dict[str, Any], args: argparse.Namespace) -> None:
    if not kakao_requested(args):
        return
    wake_mode = str(getattr(args, "kakao_wake_mode", "check") or "check").strip()
    wake_requested = bool(getattr(args, "kakao_wake", False) or wake_mode in {"wake_screen", "foreground"})
    payload["action"] = "kakao_wake_check"
    payload["kakao_check"] = True
    payload["kakao_wake"] = wake_requested
    payload["kakao_wake_mode"] = wake_mode if wake_requested else "check"
    payload["kakao_package"] = getattr(args, "kakao_package", "com.kakao.talk").strip() or "com.kakao.talk"
    payload["kakao_screenshot"] = bool(getattr(args, "kakao_screenshot", False))
    payload["adb_path"] = getattr(args, "adb_path", "").strip()
    payload["adb_serial"] = getattr(args, "adb_serial", "").strip()


def add_storebottermux_payload(payload: dict[str, Any], args: argparse.Namespace) -> None:
    if not storebottermux_requested(args):
        return
    wake_mode = str(getattr(args, "storebottermux_wake_mode", "check") or "check").strip()
    wake_requested = bool(getattr(args, "storebottermux_wake", False))
    payload["action"] = "storebottermux_watchdog"
    payload["storebottermux_check"] = True
    payload["storebottermux_wake"] = wake_requested
    payload["storebottermux_wake_mode"] = wake_mode if wake_requested else "check"
    payload["storebottermux_package"] = (
        getattr(args, "storebottermux_package", "com.sbotux").strip() or "com.sbotux"
    )
    payload["storebottermux_screenshot"] = bool(getattr(args, "storebottermux_screenshot", False))
    payload["storebottermux_logcat_tail"] = max(0, int(getattr(args, "storebottermux_logcat_tail", 0) or 0))
    payload["storebottermux_kakao_foreground"] = bool(getattr(args, "storebottermux_kakao_foreground", False))
    payload["adb_path"] = getattr(args, "adb_path", "").strip()
    payload["adb_serial"] = getattr(args, "adb_serial", "").strip()


def add_posdelay_payload(payload: dict[str, Any], args: argparse.Namespace) -> None:
    if not posdelay_requested(args):
        return
    wake_requested = bool(getattr(args, "posdelay_wake", False))
    payload["action"] = "posdelay_watchdog"
    payload["posdelay_check"] = True
    payload["posdelay_wake"] = wake_requested
    payload["posdelay_wake_mode"] = "foreground" if wake_requested else "check"
    payload["posdelay_package"] = getattr(args, "posdelay_package", "com.posdelay.app").strip() or "com.posdelay.app"
    payload["posdelay_screenshot"] = bool(getattr(args, "posdelay_screenshot", False))
    payload["posdelay_screenshot_on_fail"] = bool(getattr(args, "posdelay_screenshot_on_fail", False))
    payload["posdelay_logcat_tail"] = max(0, int(getattr(args, "posdelay_logcat_tail", 0) or 0))
    payload["posdelay_battery"] = bool(getattr(args, "posdelay_battery", False))
    payload["adb_path"] = getattr(args, "adb_path", "").strip()
    payload["adb_serial"] = getattr(args, "adb_serial", "").strip()


def read_resume_prompt(args: argparse.Namespace) -> tuple[str, str]:
    if args.prompt_file.strip():
        path = Path(args.prompt_file).expanduser()
        return path.read_text(encoding="utf-8"), args.prompt_file_name.strip() or path.name
    if args.prompt_text:
        return args.prompt_text, args.prompt_file_name.strip() or "prompt_text.md"
    task = read_task(args)
    if task:
        return task, args.prompt_file_name.strip() or "prompt.md"
    return "", args.prompt_file_name.strip() or "prompt.md"


def build_payload(args: argparse.Namespace, task: str) -> tuple[str, dict[str, Any]]:
    created_at = now_ms()
    key = f"ops_{created_at}_{secrets.token_hex(4)}"
    profile = "read_only" if direct_probe_requested(args) and args.profile == "patch" else args.profile
    payload: dict[str, Any] = {
        "status": "pending",
        "source": args.source,
        "requester": args.requester,
        "is_owner": args.is_owner,
        "task": task,
        "cwd": args.cwd,
        "project": args.project,
        "domain": normalize_domain(getattr(args, "domain", ""), args.project),
        "profile": profile,
        "engine": normalize_engine(getattr(args, "engine", "auto")),
        "model": args.model,
        "reasoning_effort": args.reasoning_effort,
        "timeout_sec": args.timeout_sec,
        "created_at_ms": created_at,
        "ttl_ms": args.ttl_ms,
        "target_host": normalize_target_host(
            args.target_host,
            "pc"
            if (adb_only_requested(args) or kakao_requested(args) or storebottermux_requested(args) or posdelay_requested(args))
            else "subphone",
        ),
        "bypass_adb": True,
        "bypass_kakao": True,
        "reply_target": {"type": "firebase_result", "kakao_publish": False},
    }
    if direct_probe_requested(args):
        payload["action"] = DIRECT_PROBE_ACTION
        payload["mode"] = DIRECT_PROBE_ACTION
        payload["command"] = DIRECT_PROBE_ACTION
        payload["direct_probe"] = True
        payload["no_send"] = True
        payload["no_publish"] = True
        payload["no_live"] = True
        payload["no_write"] = True
    if adb_only_requested(args):
        if not getattr(args, "adb_check", False):
            raise SystemExit("--adb-only requires --adb-check")
        payload["action"] = ADB_CHECK_ACTION
        payload["mode"] = ADB_CHECK_ACTION
        payload["adb_only"] = True
    if getattr(args, "request_dry_run", False):
        payload["dry_run"] = True
    action = str(getattr(args, "action", "") or "").strip()
    if action:
        if action not in NO_SEND_ACTIONS:
            raise SystemExit(f"--action must be one of: {', '.join(sorted(NO_SEND_ACTIONS))}")
        payload["action"] = action
    session = str(getattr(args, "session", "") or "").strip()
    if session:
        payload["session"] = session
    if args.branch.strip():
        payload["branch"] = args.branch.strip()
    if args.target_node.strip():
        payload["target_node"] = args.target_node.strip()
    if args.node_hint.strip():
        payload["node_hint"] = args.node_hint.strip()
    add_adb_check_payload(payload, args)
    add_kakao_payload(payload, args)
    add_storebottermux_payload(payload, args)
    add_posdelay_payload(payload, args)
    return key, payload


def build_resume_payload(args: argparse.Namespace, prompt_text: str, prompt_file_name: str) -> tuple[str, dict[str, Any]]:
    created_at = now_ms()
    key = f"ops_{created_at}_{secrets.token_hex(4)}"
    target_node = args.target_node.strip() or DEFAULT_PC_NODE
    payload: dict[str, Any] = {
        "status": "pending",
        "source": args.source,
        "requester": args.requester,
        "is_owner": args.is_owner,
        "task": f"Resume Codex session {args.resume_session_id.strip()} from a queued prompt file.",
        "action": RESUME_PROMPT_ACTION,
        "mode": RESUME_PROMPT_ACTION,
        "session_id": args.resume_session_id.strip(),
        "prompt_file_content": prompt_text,
        "prompt_file_name": prompt_file_name,
        "cwd": args.cwd,
        "project_dir": args.cwd,
        "project": args.project,
        "domain": normalize_domain(getattr(args, "domain", ""), args.project),
        "profile": args.profile,
        "engine": normalize_engine(getattr(args, "engine", "auto")),
        "model": args.model,
        "reasoning_effort": args.reasoning_effort,
        "timeout_sec": args.timeout_sec,
        "created_at_ms": created_at,
        "ttl_ms": args.ttl_ms,
        "target_host": normalize_target_host(args.target_host, "pc"),
        "target_node": target_node,
        "node_hint": args.node_hint.strip() or target_node,
        "dry_run": args.request_dry_run,
        "bypass_adb": True,
        "bypass_kakao": True,
        "reply_target": {"type": "firebase_result", "kakao_publish": False},
    }
    if args.branch.strip():
        payload["branch"] = args.branch.strip()
    add_adb_check_payload(payload, args)
    add_kakao_payload(payload, args)
    add_storebottermux_payload(payload, args)
    add_posdelay_payload(payload, args)
    return key, payload


def compact_status(item: dict[str, Any]) -> dict[str, Any]:
    result = item.get("result") if isinstance(item.get("result"), dict) else {}
    return {
        "status": item.get("status"),
        "project": item.get("project"),
        "cwd": item.get("cwd"),
        "profile": item.get("profile"),
        "engine_requested": item.get("engine_requested") or item.get("engine"),
        "engine_used": item.get("engine_used"),
        "worker": item.get("worker"),
        "model": item.get("model"),
        "reasoning_effort": item.get("reasoning_effort"),
        "duration_ms": item.get("duration_ms"),
        "returncode": item.get("returncode"),
        "summary": result.get("summary"),
        "output_len": result.get("output_len"),
        "adb_status": (item.get("adb_result") or {}).get("status") if isinstance(item.get("adb_result"), dict) else "",
        "kakao_status": (item.get("kakao_result") or {}).get("status") if isinstance(item.get("kakao_result"), dict) else "",
        "storebottermux_status": (item.get("storebottermux_result") or {}).get("status")
        if isinstance(item.get("storebottermux_result"), dict)
        else "",
        "posdelay_status": (item.get("posdelay_result") or {}).get("status")
        if isinstance(item.get("posdelay_result"), dict)
        else "",
        "error": item.get("error"),
    }


def wait_for_result(key: str, timeout_sec: int, poll_sec: float) -> dict[str, Any] | None:
    deadline = time.monotonic() + timeout_sec
    last_status = ""
    while time.monotonic() < deadline:
        raw = fb_get(f"{REQUESTS_PATH}/{key}") or {}
        if isinstance(raw, dict):
            status = str(raw.get("status") or "")
            if status and status != last_status:
                print(f"status={status}", flush=True)
                last_status = status
            if status in {"done", "error", "failed_timeout", "stale_killed", "rejected", "expired"}:
                return raw
        time.sleep(poll_sec)
    return None


def parse_args(argv: list[str]) -> argparse.Namespace:
    parser = argparse.ArgumentParser(description="Codex ops 작업 큐로 직접 주입")
    parser.add_argument("task_pos", nargs="*", help="작업 지시")
    parser.add_argument("--task", default="", help="작업 지시")
    parser.add_argument("--task-file", default="", help="작업 지시 파일")
    parser.add_argument("--stdin", action="store_true", help="stdin에서 작업 지시를 읽음")
    parser.add_argument("--cwd", "--project-dir", dest="cwd", default=DEFAULT_CWD, help="worker에서 Codex가 실행할 작업 디렉터리")
    parser.add_argument("--project", default="my-first-project")
    parser.add_argument("--domain", default="", help="codex_ops v2 domain 필드. 미지정 시 project 값을 사용")
    parser.add_argument("--session", default="", help="OpenClaw/front 또는 외부 세션 식별자 메타데이터")
    parser.add_argument("--profile", choices=["read_only", "patch", "yolo"], default="patch")
    parser.add_argument("--engine", choices=["auto", "sdk", "exec"], default="auto")
    parser.add_argument("--model", default="gpt-5.5")
    parser.add_argument("--reasoning-effort", default="xhigh")
    parser.add_argument("--timeout-sec", type=int, default=1200)
    parser.add_argument("--ttl-ms", type=int, default=6 * 60 * 60 * 1000)
    parser.add_argument("--requester", default="personal_codex")
    parser.add_argument("--source", default="personal_codex_ops")
    parser.add_argument("--branch", default="")
    parser.add_argument("--target-host", choices=["subphone", "pc", "any"], default="", help="기본: 일반 task는 subphone, resume prompt file은 pc")
    parser.add_argument("--target-node", default="", help="특정 worker node 이름으로 고정 라우팅")
    parser.add_argument("--node-hint", default="", help="기록용 node 힌트. claim 필터에는 사용하지 않음")
    parser.add_argument("--is-owner", action=argparse.BooleanOptionalAction, default=True)
    parser.add_argument("--action", choices=sorted(NO_SEND_ACTIONS), default="", help="no-send dry-run contract action")
    parser.add_argument(
        "--no-send-dry-run-contract",
        action="store_true",
        help="OpenClaw/front용 no-send/no-publish/no-live/no-write payload만 stdout으로 출력하고 Firebase write는 하지 않음",
    )
    parser.add_argument("--context-bundle-json", default="", help="context_bundle_v1 seed 또는 완성 JSON object")
    parser.add_argument("--context-bundle-file", default="", help="context_bundle_v1 seed JSON 파일")
    parser.add_argument("--resume-session-id", default="", help="특정 Codex 세션에 prompt 파일을 읽으라고 resume 요청")
    parser.add_argument("--prompt-file", default="", help="resume 요청에 넣을 긴 prompt 파일")
    parser.add_argument("--prompt-text", default="", help="resume 요청에 넣을 긴 prompt 본문")
    parser.add_argument("--prompt-file-name", default="", help="worker spool에 기록할 원본 파일명 힌트")
    parser.add_argument(
        "--request-dry-run",
        "--worker-dry-run",
        action="store_true",
        help="요청 payload dry_run=true. worker가 prompt 파일 저장/명령 구성까지만 수행",
    )
    parser.add_argument("--direct-probe", action="store_true", help="Codex CLI 없이 worker Python 프로세스가 repo/runtime 상태만 직접 수집")
    parser.add_argument("--adb-check", action="store_true", help="완료 후 USB ADB 검증 payload를 추가")
    parser.add_argument("--adb-only", action="store_true", help="Codex subprocess 없이 worker가 USB ADB helper만 직접 수행")
    parser.add_argument("--adb-path", default="", help="ADB 실행파일 경로. 미지정 시 resolver가 공장 PC 기본 경로와 PATH를 찾음")
    parser.add_argument("--adb-serial", default="")
    parser.add_argument("--apk-path", default="")
    parser.add_argument("--package-name", default="")
    parser.add_argument("--activity", default="")
    parser.add_argument("--adb-screenshot", action="store_true")
    parser.add_argument("--adb-logcat-tail", type=int, default=0)
    parser.add_argument("--adb-install", action="store_true", help="명시 opt-in일 때만 adb install -r 수행")
    parser.add_argument("--adb-launch", action="store_true", help="명시 opt-in일 때만 activity 실행")
    parser.add_argument("--kakao-check", action="store_true", help="공장 PC USB ADB로 카카오톡 상태만 확인")
    parser.add_argument("--kakao-wake", action="store_true", help="명시 opt-in일 때만 카카오톡 wake mode 수행")
    parser.add_argument("--kakao-wake-mode", choices=["check", "wake_screen", "foreground"], default="check")
    parser.add_argument("--kakao-package", default="com.kakao.talk")
    parser.add_argument("--kakao-screenshot", action="store_true")
    parser.add_argument("--storebottermux-check", action="store_true", help="공장 PC USB ADB로 StoreBotTermux 답변 pipeline 상태 확인")
    parser.add_argument("--storebottermux-wake", action="store_true", help="명시 opt-in일 때만 StoreBotTermux wake/foreground 수행")
    parser.add_argument(
        "--storebottermux-wake-mode",
        choices=["check", "wake_app", "foreground", "service_refresh"],
        default="check",
    )
    parser.add_argument("--storebottermux-package", default="com.sbotux")
    parser.add_argument("--storebottermux-screenshot", action="store_true")
    parser.add_argument("--storebottermux-logcat-tail", type=int, default=0)
    parser.add_argument("--storebottermux-kakao-foreground", action="store_true", help="StoreBotTermux wake 때만 KakaoTalk foreground 보조 허용")
    parser.add_argument("--posdelay-check", action="store_true", help="공장 PC USB ADB로 PosDelay 상태만 확인")
    parser.add_argument("--posdelay-wake", action="store_true", help="명시 opt-in일 때만 PosDelay foreground 전환")
    parser.add_argument("--posdelay-package", default="com.posdelay.app")
    parser.add_argument("--posdelay-screenshot", action="store_true")
    parser.add_argument("--posdelay-screenshot-on-fail", action="store_true")
    parser.add_argument("--posdelay-logcat-tail", type=int, default=0)
    parser.add_argument("--posdelay-battery", action="store_true")
    parser.add_argument("--wait", action="store_true")
    parser.add_argument("--wait-timeout-sec", type=int, default=1500)
    parser.add_argument("--poll-sec", type=float, default=10.0)
    parser.add_argument("--dry-run", action="store_true")
    return parser.parse_args(argv)


def main(argv: list[str]) -> int:
    args = parse_args(argv)
    if args.task_pos and not args.task:
        args.task = " ".join(args.task_pos)
    if args.resume_session_id.strip():
        prompt_text, prompt_file_name = read_resume_prompt(args)
        if not prompt_text.strip():
            raise SystemExit("resume 요청에는 --prompt-file, --prompt-text, stdin, 또는 작업 지시가 필요합니다.")
        key, payload = build_resume_payload(args, prompt_text, prompt_file_name)
    else:
        task = read_task(args)
        if not task and direct_probe_requested(args):
            task = (
                "Run codex_ops direct_probe only. "
                "Do not start Codex CLI, ADB, Kakao, app wake, install, or live actions."
            )
        elif not task and adb_only_requested(args):
            task = (
                "Run direct USB ADB check/install helper only. "
                "Do not use wireless ADB, connect to IP:port, uninstall, clear data, launch apps, tap, type, or send Kakao messages."
            )
        elif not task and storebottermux_requested(args):
            task = (
                "Run StoreBotTermux reply pipeline USB ADB watchdog only. "
                "Do not send Kakao messages, tap chat rooms, type text, install APKs, or unlock the phone."
            )
        elif not task and posdelay_requested(args):
            task = (
                "Run PosDelay light USB ADB watchdog only. "
                "Do not click or type in Baemin/Coupang, install APKs, unlock the phone, or foreground the app unless posdelay_wake is explicitly true."
            )
        elif not task and kakao_requested(args):
            task = "Run auxiliary safe KakaoTalk USB ADB check/wake helper only. Do not send, tap, type, install, or unlock."
        if not task:
            raise SystemExit("작업 지시가 필요합니다.")
        if args.no_send_dry_run_contract:
            key, payload = build_no_send_dry_run_payload(args, task)
        else:
            key, payload = build_payload(args, task)
    if args.dry_run or args.no_send_dry_run_contract:
        print(json.dumps({"key": key, "path": f"{REQUESTS_PATH}/{key}", "payload": payload}, ensure_ascii=False, indent=2))
        return 0
    fb_put(f"{REQUESTS_PATH}/{key}", payload)
    print(f"enqueued {key} profile={args.profile} cwd={args.cwd}")
    if not args.wait:
        return 0
    result = wait_for_result(key, args.wait_timeout_sec, args.poll_sec)
    if result is None:
        print(f"timeout waiting ops request={key}", file=sys.stderr)
        return 2
    print(json.dumps({"key": key, **compact_status(result)}, ensure_ascii=False, indent=2))
    return 0 if result.get("status") == "done" else 1


if __name__ == "__main__":
    raise SystemExit(main(sys.argv[1:]))
