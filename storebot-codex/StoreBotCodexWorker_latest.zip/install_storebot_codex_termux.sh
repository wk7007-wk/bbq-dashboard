#!/data/data/com.sbotux/files/usr/bin/bash
set -euo pipefail

export PATH="/data/data/com.sbotux/files/usr/bin:/data/data/com.sbotux/files/usr/bin/applets:/system/bin:/system/xbin:$PATH"

ROOT_COPY="/sdcard/Download/storebot_codex_worker"
DISTRO="debian"

echo "[1/6] Termux packages"
pkg update -y
pkg install -y proot-distro curl git python nodejs-lts

echo "[2/6] Termux storage"
if [ ! -d "$HOME/storage/shared" ]; then
  termux-setup-storage || true
fi

echo "[3/6] Debian proot"
if ! proot-distro list | grep -q "^  $DISTRO "; then
  proot-distro install "$DISTRO"
fi

echo "[4/6] Check StoreBot Codex worker files"
if [ ! -d "$ROOT_COPY" ]; then
  echo "Missing $ROOT_COPY"
  exit 1
fi
chmod +x "$ROOT_COPY"/run_storebot_codex_worker.sh "$ROOT_COPY"/check_storebot_codex_worker.sh 2>/dev/null || true
chmod +x "$ROOT_COPY"/launch_storebot_codex_background.sh "$ROOT_COPY"/setup_storebot_codex_autostart.sh 2>/dev/null || true
chmod +x "$ROOT_COPY"/watch_storebot_codex_worker.sh 2>/dev/null || true
chmod +x "$ROOT_COPY"/storebot_manual_reply.sh 2>/dev/null || true
chmod +x "$ROOT_COPY"/start_automation_goal_dispatcher.sh 2>/dev/null || true

echo "[5/6] Debian packages + Codex CLI"
proot-distro login "$DISTRO" -- bash -lc '
set -euo pipefail
SRC="/sdcard/Download/storebot_codex_worker"
if [ ! -d "$SRC" ]; then
  SRC="/storage/emulated/0/Download/storebot_codex_worker"
fi
if [ ! -d "$SRC" ]; then
  echo "worker source not found in /sdcard/Download"
  exit 1
fi
apt-get update
apt-get install -y ca-certificates curl git python3 python3-pip nodejs npm
if ! python3 -c "import mcp" >/dev/null 2>&1; then
  python3 -m pip install --break-system-packages "mcp>=1.0" || python3 -m pip install --user "mcp>=1.0"
fi
export PATH="$HOME/.local/bin:$HOME/.codex/bin:/usr/local/bin:$PATH"
if ! command -v codex >/dev/null 2>&1; then
  curl -fsSL https://chatgpt.com/codex/install.sh | sh || npm install -g @openai/codex
fi
DEPLOYMENT_LOCK_FILE="/root/my-first-project/.storebot_codex_deploy.lock"
BUNDLE_STATE_FILE="/root/my-first-project/.storebot_codex_bundle_state.json"
exec 8>"$DEPLOYMENT_LOCK_FILE"
flock -x 8
MANIFEST_FILE=""
if [ -f "$SRC/native_bundle_sync.json" ]; then
  MANIFEST_FILE="$SRC/native_bundle_sync.json"
elif [ -f "$SRC/bundle_manifest.json" ]; then
  MANIFEST_FILE="$SRC/bundle_manifest.json"
elif [ -f "$SRC/bundle.json" ]; then
  MANIFEST_FILE="$SRC/bundle.json"
fi
if [ -z "$MANIFEST_FILE" ]; then
  echo "bundle manifest missing"
  exit 1
fi
python3 - "$MANIFEST_FILE" "$BUNDLE_STATE_FILE" applying <<PY
import json
import os
import sys
import tempfile
import time
from pathlib import Path

src = Path(sys.argv[1])
dst = Path(sys.argv[2])
manifest = json.loads(src.read_text(encoding="utf-8"))
for name in ("bundle_manifest.json", "bundle.json"):
    alt = src.parent / name
    if alt.exists() and alt != src:
        candidate = json.loads(alt.read_text(encoding="utf-8"))
        for key in ("bundle_sha256", "sha256", "source_revision", "code_revision", "version", "manifest_url", "files"):
            if not manifest.get(key) and candidate.get(key):
                manifest[key] = candidate[key]
bundle_hash = str(manifest.get("bundle_sha256") or manifest.get("sha256") or "").lower()
revision = str(manifest.get("source_revision") or manifest.get("code_revision") or "").strip()
if len(bundle_hash) != 64 or any(ch not in "0123456789abcdef" for ch in bundle_hash):
    raise SystemExit("invalid bundle hash")
if not revision:
    raise SystemExit("missing bundle revision")
state = {
    "schema_version": 2,
    "status": "applying",
    "target_bundle_sha256": bundle_hash,
    "target_source_revision": revision,
    "target_code_revision": revision,
    "bundle_version": str(manifest.get("version") or ""),
    "manifest_url": str(manifest.get("manifest_url") or ""),
    "apply_started_at_ms": int(time.time() * 1000),
    "automation_runtime_files": {},
}
dst.parent.mkdir(parents=True, exist_ok=True)
fd, tmp_name = tempfile.mkstemp(prefix=dst.name + ".", dir=str(dst.parent))
try:
    with os.fdopen(fd, "w", encoding="utf-8") as handle:
        json.dump(state, handle, ensure_ascii=False, indent=2, sort_keys=True)
        handle.write("\n")
        handle.flush()
        os.fsync(handle.fileno())
    os.replace(tmp_name, dst)
finally:
    if os.path.exists(tmp_name):
        os.unlink(tmp_name)
PY
python3 "$SRC/codex_hook_policy_probe.py" \
  --json --require-compatible \
  --source-hook "$SRC/codex_hooks/minimal_managed_lifecycle.py" \
  --worker-source "$SRC/codex_ops_worker.py" \
  --project-root /root/my-first-project
mkdir -p /root/my-first-project/scripts/codex_hooks /root/my-first-project/subphone /root/storebot-codex-workspace /root/StoreBot/bot/logs
cp "$SRC/codex_hook_policy_probe.py" /root/my-first-project/scripts/codex_hook_policy_probe.py
cp "$SRC/codex_hooks/minimal_managed_lifecycle.py" /root/my-first-project/scripts/codex_hooks/minimal_managed_lifecycle.py
cp "$SRC/STOREBOT_CODEX_WORKER.md" /root/my-first-project/STOREBOT_CODEX_WORKER.md
cp "$SRC/storebot_codex_worker.py" /root/my-first-project/scripts/storebot_codex_worker.py
cp "$SRC/storebot_codex_replay_chat.py" /root/my-first-project/scripts/storebot_codex_replay_chat.py 2>/dev/null || true
cp "$SRC/storebot_direct_inject.py" /root/my-first-project/scripts/storebot_direct_inject.py 2>/dev/null || true
cp "$SRC/storebot_kakao_live_diag.py" /root/my-first-project/scripts/storebot_kakao_live_diag.py 2>/dev/null || true
cp "$SRC/storebot_manual_reply.py" /root/my-first-project/scripts/storebot_manual_reply.py 2>/dev/null || true
cp "$SRC/codex_ops_enqueue.py" /root/my-first-project/scripts/codex_ops_enqueue.py 2>/dev/null || true
cp "$SRC/codex_ops_worker.py" /root/my-first-project/scripts/codex_ops_worker.py 2>/dev/null || true
cp "$SRC/codex_ops_adb_check.py" /root/my-first-project/scripts/codex_ops_adb_check.py 2>/dev/null || true
cp "$SRC/codex_ops_kakao_wake.py" /root/my-first-project/scripts/codex_ops_kakao_wake.py 2>/dev/null || true
cp "$SRC/codex_ops_posdelay_watchdog.py" /root/my-first-project/scripts/codex_ops_posdelay_watchdog.py 2>/dev/null || true
cp "$SRC/codex_ops_storebottermux_watchdog.py" /root/my-first-project/scripts/codex_ops_storebottermux_watchdog.py 2>/dev/null || true
cp "$SRC/codex_sdk_runner.py" /root/my-first-project/scripts/codex_sdk_runner.py 2>/dev/null || true
cp "$SRC/ai_ops_common_monitor.py" /root/my-first-project/scripts/ai_ops_common_monitor.py 2>/dev/null || true
cp "$SRC/automation_goal_dispatcher.py" /root/my-first-project/scripts/automation_goal_dispatcher.py
cp "$SRC/automation_goal_seed.py" /root/my-first-project/scripts/automation_goal_seed.py
cp "$SRC/automation_goal_program_compiler.py" /root/my-first-project/scripts/automation_goal_program_compiler.py
cp "$SRC/automation_goal_program_firebase_publish.py" /root/my-first-project/scripts/automation_goal_program_firebase_publish.py
cp "$SRC/automation_goal_dispatch_firebase.py" /root/my-first-project/scripts/automation_goal_dispatch_firebase.py
cp "$SRC/automation_learning_firebase_publish.py" /root/my-first-project/scripts/automation_learning_firebase_publish.py
chmod +x /root/my-first-project/scripts/automation_goal_seed.py /root/my-first-project/scripts/automation_goal_program_compiler.py /root/my-first-project/scripts/automation_goal_program_firebase_publish.py
cp "$SRC/diagnostic_redaction.py" /root/my-first-project/scripts/diagnostic_redaction.py 2>/dev/null || true
cp "$SRC/secure_ca_env.sh" /root/my-first-project/scripts/secure_ca_env.sh 2>/dev/null || true
cp "$SRC/pc_codex_cli_enqueue.py" /root/my-first-project/scripts/pc_codex_cli_enqueue.py 2>/dev/null || true
cp "$SRC/telegram_openclaw_codex_gate.py" /root/my-first-project/scripts/telegram_openclaw_codex_gate.py 2>/dev/null || true
cp "$SRC/project_telegram_ca_lifecycle.py" /root/my-first-project/scripts/project_telegram_ca_lifecycle.py 2>/dev/null || true
cp "$SRC/storebot_ca_log.py" /root/my-first-project/scripts/storebot_ca_log.py 2>/dev/null || true
cp "$SRC/manage_storebot_ca_activation.py" /root/my-first-project/scripts/manage_storebot_ca_activation.py 2>/dev/null || true
cp "$SRC/posdelay_ca_log.py" /root/my-first-project/scripts/posdelay_ca_log.py 2>/dev/null || true
cp "$SRC/operation_knowledge_adapter.py" /root/my-first-project/scripts/operation_knowledge_adapter.py 2>/dev/null || true
cp "$SRC/storebot_telegram_projection.py" /root/my-first-project/scripts/storebot_telegram_projection.py 2>/dev/null || true
cp "$SRC/storebot_telegram_backplane.py" /root/my-first-project/scripts/storebot_telegram_backplane.py 2>/dev/null || true
cp "$SRC/storebot_telegram_chat_contract.py" /root/my-first-project/scripts/storebot_telegram_chat_contract.py 2>/dev/null || true
cp "$SRC/storebot_telegram_ops_log.py" /root/my-first-project/scripts/storebot_telegram_ops_log.py 2>/dev/null || true
cp "$SRC/storebot_telegram_worker_adapter.py" /root/my-first-project/scripts/storebot_telegram_worker_adapter.py 2>/dev/null || true
mkdir -p /root/my-first-project/config
cp "$SRC/config/telegram_openclaw_room_registry.json" /root/my-first-project/config/telegram_openclaw_room_registry.json 2>/dev/null || true
cp "$SRC/config/telegram_project_ca_registry.json" /root/my-first-project/config/telegram_project_ca_registry.json 2>/dev/null || true
cp "$SRC/config/automation_goal_dispatch_policy.json" /root/my-first-project/config/automation_goal_dispatch_policy.json
cp "$SRC/config/automation_goal_programs.json" /root/my-first-project/config/automation_goal_programs.json
cp "$SRC/config/automation_goal_runtime.json" /root/my-first-project/config/automation_goal_runtime.json
cp "$SRC/deliveryhelper_gpt_reanalyze_worker.py" /root/my-first-project/scripts/deliveryhelper_gpt_reanalyze_worker.py 2>/dev/null || true
cp "$SRC/deploy_banktotal_update.sh" /root/my-first-project/scripts/deploy_banktotal_update.sh 2>/dev/null || true
cp "$SRC/deploy_deliveryhelper_update.sh" /root/my-first-project/scripts/deploy_deliveryhelper_update.sh 2>/dev/null || true
cp "$SRC/deploy_posdelay_update.sh" /root/my-first-project/scripts/deploy_posdelay_update.sh 2>/dev/null || true
cp "$SRC/start_storebot_codex_worker.sh" /root/my-first-project/subphone/start_storebot_codex_worker.sh
cp "$SRC/STOREBOT_CODEX_BRIDGE.md" /root/my-first-project/subphone/STOREBOT_CODEX_BRIDGE.md
cp "$SRC/launch_storebot_codex_background.sh" /root/my-first-project/subphone/launch_storebot_codex_background.sh 2>/dev/null || true
cp "$SRC/restart_storebot_codex_worker.sh" /root/my-first-project/subphone/restart_storebot_codex_worker.sh 2>/dev/null || true
# The fixed Codex updater is intentionally delivered only by the hash-verified
# bundle/admin packet. This broad legacy copy path must never stage or run it.
cp "$SRC/restart_ca_live_runtime.sh" /root/my-first-project/subphone/restart_ca_live_runtime.sh 2>/dev/null || true
cp "$SRC/watch_storebot_codex_worker.sh" /root/my-first-project/subphone/watch_storebot_codex_worker.sh 2>/dev/null || true
cp "$SRC/watch_storebot_kakao_stack.sh" /root/my-first-project/subphone/watch_storebot_kakao_stack.sh 2>/dev/null || true
cp "$SRC/setup_storebot_codex_autostart.sh" /root/my-first-project/subphone/setup_storebot_codex_autostart.sh 2>/dev/null || true
cp "$SRC/start_codex_ops_worker.sh" /root/my-first-project/subphone/start_codex_ops_worker.sh 2>/dev/null || true
cp "$SRC/start_ai_ops_monitor.sh" /root/my-first-project/subphone/start_ai_ops_monitor.sh 2>/dev/null || true
cp "$SRC/start_automation_goal_dispatcher.sh" /root/my-first-project/subphone/start_automation_goal_dispatcher.sh
cp "$SRC/start_deliveryhelper_gpt_reanalyze_worker.sh" /root/my-first-project/subphone/start_deliveryhelper_gpt_reanalyze_worker.sh 2>/dev/null || true
cp "$SRC/watch_deliveryhelper_gpt_reanalyze_worker.sh" /root/my-first-project/subphone/watch_deliveryhelper_gpt_reanalyze_worker.sh 2>/dev/null || true
cp "$SRC/setup_deliveryhelper_gpt_autostart.sh" /root/my-first-project/subphone/setup_deliveryhelper_gpt_autostart.sh 2>/dev/null || true
cp "$SRC/storebot_manual_reply.sh" /root/my-first-project/subphone/storebot_manual_reply.sh 2>/dev/null || true
if [ -f "$SRC/skills/storebot-kakao-reply/SKILL.md" ]; then
  mkdir -p /root/my-first-project/.agents/skills/storebot-kakao-reply /root/.agents/skills/storebot-kakao-reply
  cp "$SRC/skills/storebot-kakao-reply/SKILL.md" /root/my-first-project/.agents/skills/storebot-kakao-reply/SKILL.md
  cp "$SRC/skills/storebot-kakao-reply/SKILL.md" /root/.agents/skills/storebot-kakao-reply/SKILL.md
fi
if [ -f "$SRC/skills/deliveryhelper-reanalyze/SKILL.md" ]; then
  mkdir -p /root/my-first-project/.agents/skills/deliveryhelper-reanalyze /root/.agents/skills/deliveryhelper-reanalyze
  cp "$SRC/skills/deliveryhelper-reanalyze/SKILL.md" /root/my-first-project/.agents/skills/deliveryhelper-reanalyze/SKILL.md
  cp "$SRC/skills/deliveryhelper-reanalyze/SKILL.md" /root/.agents/skills/deliveryhelper-reanalyze/SKILL.md
fi
if [ -d "$SRC/ai_ops_context" ]; then
  rm -rf /root/my-first-project/ai_ops_context
  mkdir -p /root/my-first-project/ai_ops_context
  cp -R "$SRC/ai_ops_context/." /root/my-first-project/ai_ops_context/
fi
chmod +x /root/my-first-project/scripts/codex_hook_policy_probe.py /root/my-first-project/scripts/codex_hooks/minimal_managed_lifecycle.py /root/my-first-project/scripts/storebot_codex_worker.py /root/my-first-project/scripts/storebot_codex_replay_chat.py /root/my-first-project/scripts/project_telegram_ca_lifecycle.py /root/my-first-project/scripts/storebot_ca_log.py /root/my-first-project/scripts/manage_storebot_ca_activation.py /root/my-first-project/scripts/storebot_direct_inject.py /root/my-first-project/scripts/storebot_kakao_live_diag.py /root/my-first-project/scripts/storebot_manual_reply.py /root/my-first-project/scripts/codex_ops_enqueue.py /root/my-first-project/scripts/codex_ops_worker.py /root/my-first-project/scripts/codex_ops_adb_check.py /root/my-first-project/scripts/codex_ops_kakao_wake.py /root/my-first-project/scripts/codex_ops_posdelay_watchdog.py /root/my-first-project/scripts/codex_ops_storebottermux_watchdog.py /root/my-first-project/scripts/codex_sdk_runner.py /root/my-first-project/scripts/ai_ops_common_monitor.py /root/my-first-project/scripts/automation_goal_dispatcher.py /root/my-first-project/scripts/automation_goal_dispatch_firebase.py /root/my-first-project/scripts/automation_learning_firebase_publish.py /root/my-first-project/scripts/deliveryhelper_gpt_reanalyze_worker.py /root/my-first-project/scripts/deploy_banktotal_update.sh /root/my-first-project/scripts/deploy_deliveryhelper_update.sh /root/my-first-project/scripts/deploy_posdelay_update.sh /root/my-first-project/subphone/start_storebot_codex_worker.sh /root/my-first-project/subphone/restart_ca_live_runtime.sh /root/my-first-project/subphone/watch_storebot_codex_worker.sh /root/my-first-project/subphone/start_codex_ops_worker.sh /root/my-first-project/subphone/start_ai_ops_monitor.sh /root/my-first-project/subphone/start_automation_goal_dispatcher.sh /root/my-first-project/subphone/start_deliveryhelper_gpt_reanalyze_worker.sh /root/my-first-project/subphone/watch_deliveryhelper_gpt_reanalyze_worker.sh /root/my-first-project/subphone/setup_deliveryhelper_gpt_autostart.sh /root/my-first-project/subphone/storebot_manual_reply.sh 2>/dev/null || true
python3 - "$MANIFEST_FILE" "$BUNDLE_STATE_FILE" native_sync <<PY
import hashlib
import json
import os
import sys
import tempfile
import time
from pathlib import Path

src = Path(sys.argv[1])
dst = Path(sys.argv[2])
root = Path("/root/my-first-project")
manifest = json.loads(src.read_text(encoding="utf-8"))
for name in ("bundle_manifest.json", "bundle.json"):
    alt = src.parent / name
    if alt.exists() and alt != src:
        candidate = json.loads(alt.read_text(encoding="utf-8"))
        for key in ("bundle_sha256", "sha256", "source_revision", "code_revision", "version", "manifest_url", "files"):
            if not manifest.get(key) and candidate.get(key):
                manifest[key] = candidate[key]
bundle_hash = str(manifest.get("bundle_sha256") or manifest.get("sha256") or "").lower()
revision = str(manifest.get("source_revision") or manifest.get("code_revision") or "").strip()
entries = manifest.get("files") or []
if isinstance(entries, dict):
    expected = {str(k): str(v).lower() for k, v in entries.items()}
else:
    expected = {str(item.get("path") or item.get("name") or ""): str(item.get("sha256") or "").lower() for item in entries if isinstance(item, dict)}
targets = {
    "automation_goal_dispatcher.py": "scripts/automation_goal_dispatcher.py",
    "automation_goal_dispatch_firebase.py": "scripts/automation_goal_dispatch_firebase.py",
    "config/automation_goal_dispatch_policy.json": "config/automation_goal_dispatch_policy.json",
    "config/automation_goal_runtime.json": "config/automation_goal_runtime.json",
    "start_automation_goal_dispatcher.sh": "subphone/start_automation_goal_dispatcher.sh",
}
runtime = {}
error = ""
if len(bundle_hash) != 64 or any(ch not in "0123456789abcdef" for ch in bundle_hash):
    error = "invalid bundle hash"
elif not revision:
    error = "missing bundle revision"
for source_name, relative in targets.items():
    if error:
        break
    wanted = expected.get(source_name, "")
    target = root / relative
    actual = hashlib.sha256(target.read_bytes()).hexdigest() if target.is_file() else ""
    if len(wanted) != 64 or actual != wanted:
        error = "automation runtime hash mismatch: " + relative
        break
    runtime[relative] = actual
state = {
    "schema_version": 2,
    "status": "native_sync" if not error else "failed",
    "target_bundle_sha256": bundle_hash,
    "target_source_revision": revision,
    "target_code_revision": revision,
    "bundle_version": str(manifest.get("version") or ""),
    "manifest_url": str(manifest.get("manifest_url") or ""),
    "automation_runtime_files": dict(sorted(runtime.items())) if not error else {},
}
if error:
    state["error"] = error
else:
    state.update({"bundle_sha256": bundle_hash, "source_revision": revision, "code_revision": revision, "applied_at_ms": int(time.time() * 1000)})
fd, tmp_name = tempfile.mkstemp(prefix=dst.name + ".", dir=str(dst.parent))
try:
    with os.fdopen(fd, "w", encoding="utf-8") as handle:
        json.dump(state, handle, ensure_ascii=False, indent=2, sort_keys=True)
        handle.write("\n")
        handle.flush()
        os.fsync(handle.fileno())
    os.replace(tmp_name, dst)
finally:
    if os.path.exists(tmp_name):
        os.unlink(tmp_name)
if error:
    raise SystemExit(error)
PY
codex --version || true
python3 /root/my-first-project/scripts/storebot_codex_worker.py --once --dry-run
'

echo "[6/6] Boot helper"
bash "$ROOT_COPY/setup_storebot_codex_autostart.sh"

echo
echo "Install finished."
echo "Next: run this once and sign in if needed:"
echo "  proot-distro login debian -- codex"
echo
echo "After Codex login, start worker:"
echo "  bash /sdcard/Download/storebot_codex_worker/run_storebot_codex_worker.sh"
echo
echo "Check worker:"
echo "  bash /sdcard/Download/storebot_codex_worker/check_storebot_codex_worker.sh"
