#!/usr/bin/env python3
from __future__ import annotations

import argparse
import json
import secrets
import sys
from pathlib import Path
from typing import Any

from storebot_codex_worker import REQUESTS_PATH, fb_get, fb_put, now_ms


DEFAULT_ROOM_ID = "storebot_group"
DEFAULT_ROOM_NAME = "BBQ하이닉스점 10"


def read_text_arg(value: str, path: str, stdin: bool) -> str:
    if value.strip():
        return value.strip()
    if path.strip():
        return Path(path).read_text(encoding="utf-8").strip()
    if stdin or not sys.stdin.isatty():
        return sys.stdin.read().strip()
    return ""


def normalize_entries(raw: Any, args: argparse.Namespace) -> list[dict[str, Any]]:
    if isinstance(raw, dict):
        raw_entries = raw.get("messages") or raw.get("items") or raw.get("logs") or [raw]
    else:
        raw_entries = raw
    if not isinstance(raw_entries, list):
        raise SystemExit("JSON 로그는 object 또는 list여야 합니다.")

    entries: list[dict[str, Any]] = []
    for item in raw_entries:
        if not isinstance(item, dict):
            continue
        message = str(item.get("message") or item.get("text") or item.get("content") or "").strip()
        if not message:
            continue
        entries.append(
            {
                "sender": str(item.get("sender") or item.get("from") or args.sender).strip() or args.sender,
                "message": message,
                "room_id": str(item.get("room_id") or item.get("room") or args.room_id).strip() or args.room_id,
                "room_name": str(item.get("room_name") or item.get("roomTitle") or args.room_name).strip() or args.room_name,
                "ts": int(item.get("ts") or item.get("created_at_ms") or args.ts_ms or now_ms()),
            }
        )
    return entries


def build_entries(args: argparse.Namespace) -> list[dict[str, Any]]:
    if args.json_file:
        raw = json.loads(Path(args.json_file).read_text(encoding="utf-8"))
        return normalize_entries(raw, args)

    message = read_text_arg(args.message, args.message_file, args.stdin)
    if not message:
        raise SystemExit("--message, --message-file, --json-file 또는 stdin 중 하나가 필요합니다.")
    return [
        {
            "sender": args.sender,
            "message": message,
            "room_id": args.room_id,
            "room_name": args.room_name,
            "ts": args.ts_ms or now_ms(),
        }
    ]


def is_duplicate(entry: dict[str, Any]) -> bool:
    raw = fb_get(REQUESTS_PATH) or {}
    if not isinstance(raw, dict):
        return False
    message = entry["message"].strip()
    sender = entry["sender"].strip()
    room_id = entry["room_id"].strip()
    for item in raw.values():
        if not isinstance(item, dict):
            continue
        if str(item.get("message") or item.get("text") or "").strip() != message:
            continue
        if str(item.get("sender") or item.get("from") or "").strip() != sender:
            continue
        if str(item.get("room_id") or item.get("room") or "").strip() != room_id:
            continue
        status = str(item.get("status") or "").lower()
        if status in {"pending", "running", "done"}:
            return True
    return False


def enqueue(entry: dict[str, Any], args: argparse.Namespace) -> str:
    key = f"replay_{now_ms()}_{secrets.token_hex(4)}"
    ts_ms = int(entry["ts"])
    payload = {
        "status": "pending",
        "source": args.source,
        "event_kind": "chat_replay",
        "room_id": entry["room_id"],
        "room_name": entry["room_name"],
        "sender": entry["sender"],
        "message": entry["message"],
        "is_owner": args.is_owner,
        "is_1on1": False,
        "ts": ts_ms,
        "created_at_ms": now_ms(),
        "replayed_at_ms": now_ms(),
        "payload": {
            "replay": True,
            "reason": args.reason,
            "original_ts_ms": ts_ms,
        },
    }
    if args.no_publish:
        payload["no_publish"] = True
    if args.dry_run:
        print(json.dumps({"key": key, "payload": payload}, ensure_ascii=False, indent=2))
        return key
    fb_put(f"{REQUESTS_PATH}/{key}", payload)
    return key


def parse_args(argv: list[str]) -> argparse.Namespace:
    parser = argparse.ArgumentParser(description="놓친 StoreBot 카톡 로그를 Codex 답변 큐에 재주입")
    parser.add_argument("--message", default="", help="소급 처리할 카톡 메시지")
    parser.add_argument("--message-file", default="", help="소급 처리할 메시지 텍스트 파일")
    parser.add_argument("--json-file", default="", help="sender/message/ts 항목을 담은 JSON 로그 파일")
    parser.add_argument("--stdin", action="store_true", help="stdin에서 메시지를 읽음")
    parser.add_argument("--sender", default="BBQ SK하이닉스점")
    parser.add_argument("--room-id", default=DEFAULT_ROOM_ID)
    parser.add_argument("--room-name", default=DEFAULT_ROOM_NAME)
    parser.add_argument("--ts-ms", type=int, default=0)
    parser.add_argument("--source", default="manual_replay")
    parser.add_argument("--reason", default="missed_chat")
    parser.add_argument("--is-owner", action="store_true")
    parser.add_argument("--no-publish", action="store_true", help="카톡 발송 없이 소급 처리 결과만 기록")
    parser.add_argument("--force", action="store_true", help="동일 메시지가 있어도 다시 넣음")
    parser.add_argument("--dry-run", action="store_true")
    return parser.parse_args(argv)


def main(argv: list[str]) -> int:
    args = parse_args(argv)
    entries = build_entries(args)
    enqueued = 0
    skipped = 0
    for entry in entries:
        if not args.force and is_duplicate(entry):
            skipped += 1
            print(f"skip duplicate sender={entry['sender']} ts={entry['ts']}")
            continue
        key = enqueue(entry, args)
        enqueued += 1
        print(f"enqueued {key} sender={entry['sender']} ts={entry['ts']}")
    print(f"done enqueued={enqueued} skipped={skipped}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main(sys.argv[1:]))
