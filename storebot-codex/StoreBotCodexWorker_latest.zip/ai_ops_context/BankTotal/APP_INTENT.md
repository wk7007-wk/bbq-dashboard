<!-- source: /root/BankTotal/APP_INTENT.md -->
# BankTotal APP_INTENT.md

## 만든 이유
- 은행 문자/알림과 정산 항목을 연결해 돈 흐름, 반복 출금, 잔액을 틀리지 않게 본다.
- 표면은 native APK이며, WebView 화면은 APK 안의 한 화면으로 본다.

## 사용자 결과
- 지난 출금, 반복 출금, 분할, 보정, 잔액이 누락 없이 이어져야 한다.
- 돈 관련 화면은 정리보다 정확성과 추적 가능성이 우선이다.

## 절대 기준
- 금액 정확성, 수동 보정, 과거 미처리 항목 보존이 우선이다.
- 화면 정리를 이유로 돈 흐름이나 보정 근거를 숨기지 않는다.
- 로컬 API는 `127.0.0.1` 기준을 유지한다.
- 화면/ADB 없이도 정산 계산 근거를 구조화된 진단 JSON으로 재현할 수 있어야 한다.
- 진단/AI Ops는 read-only 분석, 오류설명, 코드 self-fix 후보 생성까지만 허용한다.
- read-only preflight는 `APP_INTENT.md`, `CODEMAP.txt`, `CLAUDE.md`와 Firebase/DB read-only source 확인으로 먼저 끝낸다.
- 금융 원본(계좌/금액/회차/반복 원본) 확정 변경은 기존 repository/local API/사용자 확인 경계를 통과해야 한다.
- 정산 날짜 스와이프는 목표 날짜 지정이다. 지정한 날짜는 다음날이 되어도 같이 밀리지 않는다.
- 이월은 오늘 못 낸 출금이 내일에도 남아야 하는 예외일 뿐, 모든 지정 날짜를 하루씩 이동시키는 규칙이 아니다.
- 고정비 미출금 회차를 날짜 이동한 경우에는 다음 고정비와 섞지 않고 해당 회차의 이동 상태를 보존한다.
- 월 고정비 원본은 자동삭제/숨김/회차 정리 때문에 사라지면 안 된다.
- 정산/DB 단순화 원칙은 `BANKTOTAL_DB_PRINCIPLES_20260707.md`를 우선한다. 정산탭 구현설계 자체가 앱 원칙이며, 사용자 행동 하나가 DB에서 바꾸는 범위가 명확해야 한다.
- 정산탭은 예정값과 실제값이 공존하는 화면이다. 반복 규칙, 발생건, 실제값, 연결, 감사기록은 덮어쓰기/병합하지 않는다.
- Google Calendar 정산 v2 설계는 `SETTLEMENT_CALENDAR_V2.md`를 따른다. 기존 Room v7과 기존 정산 화면은 절환 검증 전까지 보존하고, v2는 별도 DB/패키지로 운영한다.
- Calendar는 전용 `BankTotal 정산` 캘린더에 로컬 기준본을 단방향 투영한다. Calendar에서 직접 바꾼 날짜·금액·삭제는 금융 canonical에 반영하지 않는다.
- Calendar 이벤트는 방향과 반복 여부를 함께 색상화한다. 고정입금/1회입금은 진한/연한 초록, 고정출금/1회출금은 빨강/주황이며 기존 일정 갱신은 `colorId`만 patch한다.
- Calendar v2는 `banktotal_personal` 개인 Google 계정에만 연결한다. 최초 전용 Calendar ID를 바인딩으로 삼고, 다른 계정에서 접근할 수 없으면 새 캘린더나 대체 바인딩을 만들지 않고 `account_mismatch`로 차단한다. 사용자가 새 기준본 적용을 확인한 경우에만 접근 검증된 앱 전용 Calendar를 삭제·재생성할 수 있다.
- 하이닉스 근무표 Google 계정/OAuth/Calendar/token 저장소는 BankTotal과 공유하지 않는다.
- 회차 기준일 `original_date`는 불변이고 날짜 이동은 `effective_date`만 바꾼다. 반복 수정은 이번 회차/이번 이후/전체 범위를 명시한다.
- 평일·주말 고정입금은 사용자에게 한 종류(`fixed-deposit`)지만 금액·요일이 다르면 서로 다른 반복 부모로 유지한다.
- 최초 기준본은 기존 Room의 현재 visible 항목을 Codex 판정 규칙으로 분석한다. 정확히 같은 항목은 합치고, 원본이 없는 고아 state와 과거 완료·숨김 항목은 새 기준본에 개별 복제하지 않으며 집계 audit만 남긴다.
- 금액·날짜·반복 규칙이 다른 동명이 항목은 중복으로 추측하지 않는다. 실제 거래 링크가 있으면 재생성을 중단한다. 이미 게시된 기준본은 `확정 내역 바로 적용` 한 번으로 앱 전용 Calendar와 v2 projection을 정리한 뒤 새 기준본을 즉시 게시하되, 원격 삭제 실패 시 로컬 기준본을 비우지 않는다.
- 숨김은 해당 회차 금액을 계산에서 잠시 빼고 남은 금액을 보기 위한 상태다.
- 삭제는 납부했지만 거래 매칭이 안 된 회차를 정산에서 제거하는 동작이며, 반복 원본 삭제가 아니다.
- 물류 OCR은 발주일에서 계산한 대상 날짜별 1회 예상치다. 반복 물류 항목이나 SFA/BLOCK 금액에 섞지 않는다.
- 물류 OCR 식별은 `ocr_logistics_` ID 또는 `source=ocr` 중 하나만 남아도 유지되어야 한다.
- 물류 OCR은 최근 과거분만 오늘 줄로 올리고, 오래된 과거 예상은 화면에서 제외한다.
- 물류 OCR도 사용자가 제외/숨김 처리한 상태는 존중한다.
- 같은 대상 날짜의 물류 OCR은 한 항목으로 합치고, 다른 날짜 물류와 합산하지 않는다.
- SFA 주문현황 OCR은 조회기간/헤더/총계 텍스트를 주문 row로 오인하지 않아야 한다.
- SFA 불납금액은 확정금액이다. 같은 대상 날짜에 확정금액이 있으면 물류 OCR 예상치보다 우선해 대체한다.
- 예외: 토요일 실제 SFA 확정금액은 일요일 만기 물류 OCR의 확정금액으로 본다. 화면 표시는 실제 물류 기점인 토요일을 우선한다.
- 자동 이름 매칭은 공백/기호 제거 후 exact 또는 충분히 긴 단일 prefix일 때만 허용하고, 복수 후보면 자동 건너뛴다.
- Codex CLI/codex_ops를 기본 AI ops 경계로 두고, OpenClaw가 충분히 빠르고 안정적이면 BankTotal 전용 agent/session 후보로만 붙인다. 역할은 조회, 요약, 불일치 후보 설명, 사용자가 확인할 수정안 작성까지다.
- OpenClaw는 금융/정산 원본을 직접 확정 수정하지 않는다. 금액, 회차 상태, 반복 원본, SFA/물류 대체는 기존 Room repository/local API/전용 rule 객체 경계를 거쳐야 한다.
- goal mode는 승인 대기 없는 상주 모니터링/오류판정/자가교정 운영 모드다. BankTotal 오류 분석/보고/self_fix는 알림 누락, OCR 불일치, 정산 데이터 불일치, 반복 사용자 보정까지 넓게 보고 멈추지 않고 진행하되, 금융 원본 데이터 확정 변경은 기존 repository/local API/사용자 확인 경계를 통과해야 한다.
- BankTotal은 사용자 동작형 앱이다. 공용 AI Ops에 포함하되 앱 monitor stale만으로 장애/self_fix를 만들지 않고, 앱 실행/정산 조작/엑셀 동기화/OCR/SFA/알림 수신 같은 사용자 동작 또는 백그라운드 이벤트 실패와 crash를 기준으로 올린다.

## UI/동선 기준
- 정산/가계부/계좌 화면은 누락 위험이 큰 항목을 먼저 드러낸다.
- 반복 출금과 분할 상태는 사용자가 다음 행동을 바로 판단할 수 있어야 한다.
- 날짜 이동 상태는 사용자가 지정한 날짜와 이월 예외를 구분해서 보여야 한다.
- 물류는 대상 날짜가 먼저 보여야 하며, 이월 표시와 OCR 재배분 근거가 섞이지 않아야 한다.
- 이월·날짜이동·물류 OCR 항목은 항목명 뒤 날짜 꼬리표로 원 기준일이나 물류 기점일을 보여야 한다.
- 월 고정비는 Room에 없고 Firebase 백업에만 남은 경우 앱 시작/복귀 시 자동 복구되어야 한다.
- UI 완료 기준은 대표 기기 screenshot, accessibility label, touch target, overflow 확인이 있어야 한다.
- APK 변경은 build 후 전달까지 보고, 업데이트 채널이 있으면 함께 확인한다.
- Calendar 기준본 절환 전에는 개인계정 OAuth, 다른 계정 차단, 기준본 분석 결과, 실제 기기 반복 수정 3범위, 로컬 변경의 Calendar 반영을 검증한다.

## 데이터/경계 기준
- SMS/알림/접근성/SFA BLOCK 입력 경로를 구분한다.
- Room migration과 과거 데이터 보존을 우선 확인한다.
- Room v7에는 `raw_events`와 `audit_events`가 있다. 주요 입력 원문은 변환/저장 전에 `raw_events`에 먼저 기록하고, 저장/중복/차단/실패 결과는 `audit_events`에 남긴다.
- `FinancialInputRecorder` 현재 연결 경로: 은행 알림, SMS 수신/기록, SFA BLOCK 접근성, SFA 주문현황 물류 OCR, `/sdcard/Download/banktotal_input.json`, Firebase `/banktotal/settle_input`, Local API `POST/PATCH /settle` 및 `POST /account`.
- recorder 실패는 입력 저장 자체를 막지 않는다. 실패는 앱 로그와 가능한 감사기록에 남긴다.
- Local API raw payload는 계좌번호 키를 마스킹한 뒤 저장한다.
- 아직 미연결: 정산탭 사용자 직접 조작(숨김/날짜이동/분할/보정), Gemini 고지서 후보 저장, Firebase manual 백업 복구, 반복/발생건/link migration.
- 원문 입력은 중복처럼 보여도 버리지 않는다. 중복 판정은 `duplicate_of`/`event_status`와 감사기록으로 표시한다.
- 정산 화면의 기준은 Room이며, Firebase `/banktotal/settle/manual`은 monthly 누락분 복구용 백업으로만 사용한다.
- 정산 조회/진단(`generateSettleView`, `buildDebugSnapshot`)은 Room write를 하지 않는다. 만료 분할/레거시 물류/상대 날짜 고정은 명시 `runSettleMaintenance()`에서만 처리한다.
- 웹/CLI/Firebase 직접 경로는 read-only 진단/백업 보조가 기본이며, 정산·거래 원본 write/delete는 기본 차단한다.
- 사용자가 금액·회차를 구체적으로 확인한 복구는 Local API `/settle/confirmed-repair`에서 확인 문자열, 사유, expected 현재값을 모두 검증하고 한 트랜잭션으로만 적용한다. 일반 금액 수정 허용으로 확장하지 않는다.
- OpenClaw 입력은 `domain=banktotal` envelope로 분리하고, 필요한 최소 거래/정산 후보만 보낸다. StoreBot/DeliveryHelper/PosDelay 세션과 돈 흐름 맥락을 섞지 않는다.
- 공용 서버폰 `codex_ops` 베이스를 쓰더라도 BankTotal 금융 맥락은 전용 envelope/session/result 경로로 분리한다.
- C&I prompt는 BankTotal monitor, crash/OCR/SFA 이벤트, 사용자/수동 enqueue, 또는 상주 판단 루프가 만든다. 이는 LLM 실행을 깨우는 envelope이며 C&I 판단 권한 제한이 아니다.
- C&I 자동 복구는 코드/설정/문서/APK/업데이트센터 보정까지 허용하되, 금액·회차·반복 원본 확정 변경은 기존 repository/local API/사용자 확인 경계를 통과해야 한다.
- 백업 동기화는 한 번에 하나만 실행하고 각 후보를 Room transaction에서 다시 확인한 뒤 insert-ignore한다. 로컬 값은 revision과 무관하게 우선하며, Firebase 429/5xx만 제한 재시도하고 실패해도 현재 Room 화면을 유지한다.
- 기존 Room v7의 반복항목 삭제/숨김/제외는 `settle_item_states` 회차 상태로 남아도, 새 기준본 생성 시 원본이 없는 state를 다시 살리지 않는다. 현재 유효한 기준본만 Calendar에 게시한다.
- 금융성 데이터는 로그와 문서에 과도하게 노출하지 않는다.
- 진단 스냅샷은 schema version을 가진 `raw-ish source + computed view + occurrence trace + invariants/findings` 구조를 유지한다.
- 공유 저장소 export와 Local API debug snapshot은 같은 read-only 계약을 써야 하며, 계좌번호는 마스킹한다.

## 수정 전 질문
- 이 변경이 실제 정산 누락을 막는가.
- 화면 정리 때문에 돈 흐름을 숨기지 않는가.
- 반복/분할/지난 미처리 회차가 모두 유지되는가.

## 완료 기준
- 검증: repository 로직, migration 영향, Android 빌드
- 전달: Android 변경 시 debug APK 복사와 `termux-open`
- 남은 위험: 은행 알림 문구 변경, 과거 데이터 케이스 부족
