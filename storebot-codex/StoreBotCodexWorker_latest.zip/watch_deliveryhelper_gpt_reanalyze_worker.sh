#!/data/data/com.sbotux/files/usr/bin/bash
set -u

ROOT_DIR="${DELIVERYHELPER_GPT_ROOT:-/root/my-first-project}"
LOG_DIR="${DELIVERYHELPER_GPT_LOG_DIR:-/sdcard/Download/deliveryhelper_gpt_worker}"
INTERVAL_SEC="${DELIVERYHELPER_GPT_WATCH_INTERVAL_SEC:-60}"
LOCK_BASE_DIR="${DELIVERYHELPER_GPT_LOCK_BASE_DIR:-${TMPDIR:-${PREFIX:-/data/data/com.sbotux/files/usr}/tmp}}"
LOCK_DIR="${DELIVERYHELPER_GPT_LOCK_DIR:-$LOCK_BASE_DIR/deliveryhelper_gpt_reanalyze.lock}"

PATH="${PATH:-}"
prepend_path_dir() {
  dir="$1"
  [ -n "$dir" ] || return 0
  [ -d "$dir" ] || return 0
  case ":$PATH:" in
    *":$dir:"*) ;;
    *) PATH="$dir${PATH:+:$PATH}" ;;
  esac
}

prepend_path_dir "/usr/local/bin"
prepend_path_dir "/root/.local/bin"
prepend_path_dir "${HOME:-/root}/.local/bin"
if [ -n "${PREFIX:-}" ]; then
  prepend_path_dir "$PREFIX/bin"
fi
prepend_path_dir "/data/data/com.sbotux/files/usr/bin"
prepend_path_dir "/data/data/com.termux/files/usr/bin"
export PATH

mkdir -p "$LOG_DIR" "$LOCK_BASE_DIR" 2>/dev/null || true

pid_cmdline() {
  pid="$1"
  cmdline="$(ps -p "$pid" -o args= 2>/dev/null || true)"
  if [ -z "$cmdline" ] && [ -r "/proc/$pid/cmdline" ]; then
    cmdline="$(tr '\0' ' ' < "/proc/$pid/cmdline" 2>/dev/null || true)"
  fi
  printf '%s' "$cmdline"
}

pid_matches_deliveryhelper_gpt() {
  pid="$1"
  [ -n "$pid" ] || return 1
  kill -0 "$pid" 2>/dev/null || return 1
  case "$(pid_cmdline "$pid")" in
    *deliveryhelper_gpt_reanalyze_worker.py*|*start_deliveryhelper_gpt_reanalyze_worker.sh*)
      return 0
      ;;
  esac
  return 1
}

is_worker_active() {
  pgrep -f "deliveryhelper_gpt_reanalyze_worker.py --watch" >/dev/null 2>&1 && return 0
  return 1
}

cleanup_stale_lock() {
  [ -d "$LOCK_DIR" ] || return 0
  lock_pid="$(cat "$LOCK_DIR/pid" 2>/dev/null || true)"
  if ! pid_matches_deliveryhelper_gpt "$lock_pid"; then
    echo "$(date '+%Y-%m-%d %H:%M:%S') removing stale DeliveryHelper GPT lock pid=${lock_pid:-none}" >> "$LOG_DIR/watchdog.log"
    rm -rf "$LOCK_DIR" 2>/dev/null || true
  fi
}

cleanup_duplicate_workers() {
  keep_pid=""
  pgrep -f "deliveryhelper_gpt_reanalyze_worker.py --watch" 2>/dev/null | while read -r pid; do
    [ -n "$pid" ] || continue
    [ "$pid" = "$$" ] && continue
    if [ -z "$keep_pid" ]; then
      keep_pid="$pid"
      continue
    fi
    echo "$(date '+%Y-%m-%d %H:%M:%S') stopping duplicate DeliveryHelper GPT worker pid=$pid keep=$keep_pid" >> "$LOG_DIR/watchdog.log"
    kill "$pid" 2>/dev/null || true
  done
}

cleanup_stale_starter() {
  pgrep -f "start_deliveryhelper_gpt_reanalyze_worker.sh" 2>/dev/null | while read -r pid; do
    [ -n "$pid" ] || continue
    [ "$pid" = "$$" ] && continue
    case "$(pid_cmdline "$pid")" in
      *start_deliveryhelper_gpt_reanalyze_worker.sh*) ;;
      *) continue ;;
    esac
    echo "$(date '+%Y-%m-%d %H:%M:%S') stopping stale DeliveryHelper GPT starter pid=$pid" >> "$LOG_DIR/watchdog.log"
    kill "$pid" 2>/dev/null || true
    sleep 1
    if kill -0 "$pid" 2>/dev/null; then
      case "$(pid_cmdline "$pid")" in
        *start_deliveryhelper_gpt_reanalyze_worker.sh*)
          echo "$(date '+%Y-%m-%d %H:%M:%S') killing stale DeliveryHelper GPT starter pid=$pid" >> "$LOG_DIR/watchdog.log"
          kill -KILL "$pid" 2>/dev/null || true
          ;;
      esac
    fi
  done
  rm -rf "$LOCK_DIR" 2>/dev/null || true
}

start_worker() {
  if [ ! -f "$ROOT_DIR/subphone/start_deliveryhelper_gpt_reanalyze_worker.sh" ]; then
    echo "$(date '+%Y-%m-%d %H:%M:%S') start script missing: $ROOT_DIR/subphone/start_deliveryhelper_gpt_reanalyze_worker.sh" >> "$LOG_DIR/watchdog.log"
    return 1
  fi
  echo "$(date '+%Y-%m-%d %H:%M:%S') starting DeliveryHelper GPT worker" >> "$LOG_DIR/watchdog.log"
  setsid bash "$ROOT_DIR/subphone/start_deliveryhelper_gpt_reanalyze_worker.sh" >/dev/null 2>&1 &
}

while true; do
  cleanup_stale_lock
  cleanup_duplicate_workers
  if ! is_worker_active; then
    cleanup_stale_starter
    start_worker || true
  fi
  sleep "$INTERVAL_SEC"
done
