#!/usr/bin/env python3
"""Two-phase, no-workspace-write verifier for a real fresh Codex hook turn."""

from __future__ import annotations

import argparse
import datetime as dt
import json
import os
from pathlib import Path
import secrets
import subprocess
import sys
from typing import Any


POLICY_VERSION = "minimal-managed-hooks-v2.1"
REQUIRED_PROBES = {
    "ordinary_pwd",
    "codex_version",
    "codex_exec_help",
    "managed_requirements_read",
}
DEFAULT_HOOK_STATE = Path("/root/.codex/managed-hook-state")
DEFAULT_ADMIN_STATE = Path("/root/.local/state/wonmux-codex-admin/fresh-hook-verifier")


class VerificationError(RuntimeError):
    pass


def atomic_json(path: Path, payload: dict[str, Any]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True, mode=0o700)
    temporary = path.with_name(path.name + f".tmp-{os.getpid()}")
    temporary.write_text(json.dumps(payload, ensure_ascii=False, indent=2, sort_keys=True) + "\n", encoding="utf-8")
    temporary.chmod(0o600)
    os.replace(temporary, path)


def file_offsets(directory: Path) -> dict[str, int]:
    if not directory.is_dir():
        return {}
    return {str(path): path.stat().st_size for path in sorted(directory.glob("*.jsonl")) if path.is_file()}


def policy_probe(repo_root: Path) -> dict[str, Any]:
    probe = repo_root / "scripts" / "codex_hook_policy_probe.py"
    completed = subprocess.run(
        [
            sys.executable,
            str(probe),
            "--json",
            "--require-compatible",
            "--project-root",
            str(repo_root),
        ],
        text=True,
        stdout=subprocess.PIPE,
        stderr=subprocess.PIPE,
        timeout=20,
        check=False,
    )
    if completed.returncode != 0 or len(completed.stdout) > 131072 or len(completed.stderr) > 131072:
        raise VerificationError("hook_policy_not_compatible")
    try:
        result = json.loads(completed.stdout.strip().splitlines()[-1])
    except (IndexError, json.JSONDecodeError) as exc:
        raise VerificationError("hook_policy_invalid_json") from exc
    managed = result.get("managed") if isinstance(result.get("managed"), dict) else {}
    if result.get("compatible") is not True or managed.get("status") != "exact":
        raise VerificationError("managed_hook_not_exact")
    return result


def prepare(repo_root: Path, hook_state: Path, admin_state: Path) -> dict[str, Any]:
    policy = policy_probe(repo_root)
    managed = policy["managed"]
    expected = managed["expected"]
    nonce = secrets.token_hex(16)
    pending = {
        "schema_version": 1,
        "status": "awaiting_fresh_turn",
        "nonce": nonce,
        "prepared_at": dt.datetime.now(dt.timezone.utc).isoformat(timespec="seconds"),
        "policy_version": expected["policy_version"],
        "policy_source_sha256": expected["sha256"],
        "policy_installed_sha256": managed["installed_sha256"],
        "receipt_offsets": file_offsets(hook_state / "receipts"),
        "lifecycle_path": str(hook_state / "lifecycle.jsonl"),
        "lifecycle_offset": (hook_state / "lifecycle.jsonl").stat().st_size
        if (hook_state / "lifecycle.jsonl").is_file()
        else 0,
        "required_probes": sorted(REQUIRED_PROBES),
        "workspace_write_performed": False,
        "binary_help_only_sufficient": False,
    }
    atomic_json(admin_state / "pending.json", pending)
    managed_path = "/" + "etc/codex/requirements.toml"
    return {
        **pending,
        "next": "start_a_new_codex_turn_and_execute_exact_commands",
        "exact_commands": [
            "pwd",
            "/root/.local/bin/codex --version",
            "/root/.local/bin/codex exec --help",
            f"sed -n '1,5p' {managed_path} 2>/dev/null",
        ],
        "then": f"python3 {Path(__file__).resolve()} verify",
    }


def read_appended_jsonl(path: Path, offset: int) -> list[dict[str, Any]]:
    if not path.is_file():
        if offset:
            raise VerificationError(f"evidence_file_missing:{path.name}")
        return []
    size = path.stat().st_size
    if size < offset:
        raise VerificationError(f"evidence_file_truncated:{path.name}")
    with path.open("rb") as handle:
        handle.seek(offset)
        raw = handle.read(1024 * 1024 + 1)
    if len(raw) > 1024 * 1024:
        raise VerificationError(f"evidence_append_too_large:{path.name}")
    records: list[dict[str, Any]] = []
    for line in raw.decode("utf-8", errors="strict").splitlines():
        if not line.strip():
            continue
        item = json.loads(line)
        if isinstance(item, dict):
            records.append(item)
    return records


def verify_receipts(pending: dict[str, Any], hook_state: Path, current_policy: dict[str, Any]) -> dict[str, Any]:
    managed = current_policy.get("managed") if isinstance(current_policy.get("managed"), dict) else {}
    expected = managed.get("expected") if isinstance(managed.get("expected"), dict) else {}
    if current_policy.get("compatible") is not True or managed.get("status") != "exact":
        raise VerificationError("managed_hook_not_exact")
    if expected.get("sha256") != pending.get("policy_source_sha256"):
        raise VerificationError("policy_changed_after_prepare")
    if managed.get("installed_sha256") != pending.get("policy_installed_sha256"):
        raise VerificationError("installed_hook_changed_after_prepare")

    receipt_offsets = pending.get("receipt_offsets") if isinstance(pending.get("receipt_offsets"), dict) else {}
    receipt_paths = {str(path): path for path in (hook_state / "receipts").glob("*.jsonl") if path.is_file()}
    receipt_paths.update({path: Path(path) for path in receipt_offsets})
    receipts: list[dict[str, Any]] = []
    for path_text, path in sorted(receipt_paths.items()):
        receipts.extend(read_appended_jsonl(path, int(receipt_offsets.get(path_text, 0))))

    lifecycle_path = Path(str(pending.get("lifecycle_path") or (hook_state / "lifecycle.jsonl")))
    lifecycle = read_appended_jsonl(lifecycle_path, int(pending.get("lifecycle_offset") or 0))
    fresh_sessions = {
        str(item.get("sessionId"))
        for item in lifecycle
        if item.get("event") == "session_start"
        and item.get("policyVersion") == POLICY_VERSION
        and str(item.get("sessionId") or "") not in {"", "unknown"}
    }
    by_session: dict[str, set[str]] = {}
    receipt_count = 0
    for item in receipts:
        session_id = str(item.get("sessionId") or "")
        probe = str(item.get("harmlessFreshTurnProbe") or "")
        if (
            session_id in fresh_sessions
            and probe in REQUIRED_PROBES
            and item.get("succeeded") is True
            and item.get("policyVersion") == POLICY_VERSION
        ):
            by_session.setdefault(session_id, set()).add(probe)
            receipt_count += 1
    candidates = sorted(session for session, probes in by_session.items() if probes == REQUIRED_PROBES)
    if len(candidates) != 1:
        raise VerificationError("fresh_turn_receipts_incomplete_or_ambiguous")
    return {
        "status": "PASS",
        "schema_version": 1,
        "nonce": pending.get("nonce"),
        "fresh_session_id": candidates[0],
        "policy_version": POLICY_VERSION,
        "policy_source_sha256": expected.get("sha256"),
        "policy_installed_sha256": managed.get("installed_sha256"),
        "required_probes": sorted(REQUIRED_PROBES),
        "successful_probe_receipt_count": receipt_count,
        "workspace_write_performed": False,
        "binary_help_only_sufficient": False,
        "verified_at": dt.datetime.now(dt.timezone.utc).isoformat(timespec="seconds"),
    }


def verify(repo_root: Path, hook_state: Path, admin_state: Path) -> dict[str, Any]:
    pending_path = admin_state / "pending.json"
    if not pending_path.is_file():
        raise VerificationError("prepare_state_missing")
    pending = json.loads(pending_path.read_text(encoding="utf-8"))
    result = verify_receipts(pending, hook_state, policy_probe(repo_root))
    atomic_json(admin_state / "evidence" / f"{pending['nonce']}.json", result)
    return result


def parse_args(argv: list[str]) -> argparse.Namespace:
    repo_root = Path(__file__).resolve().parents[1]
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("action", choices=("prepare", "verify"))
    parser.add_argument("--repo-root", default=str(repo_root))
    parser.add_argument("--hook-state", default=str(DEFAULT_HOOK_STATE))
    parser.add_argument("--admin-state", default=str(DEFAULT_ADMIN_STATE))
    return parser.parse_args(argv)


def main(argv: list[str]) -> int:
    args = parse_args(argv)
    try:
        if args.action == "prepare":
            result = prepare(Path(args.repo_root), Path(args.hook_state), Path(args.admin_state))
        else:
            result = verify(Path(args.repo_root), Path(args.hook_state), Path(args.admin_state))
    except (OSError, ValueError, json.JSONDecodeError, subprocess.TimeoutExpired, VerificationError) as exc:
        print(json.dumps({"status": "FAIL", "error": str(exc)}, ensure_ascii=False, sort_keys=True))
        return 3
    print(json.dumps(result, ensure_ascii=False, sort_keys=True))
    return 0


if __name__ == "__main__":
    raise SystemExit(main(sys.argv[1:]))
