#!/usr/bin/env python3
"""Crash-safe Firebase adapter for the pure automation goal reducer.

The transport is dependency-injected.  The adapter is shadow/read-only unless
``apply=True`` (CLI: ``--apply``); importing this module performs no I/O.
"""

from __future__ import annotations

import argparse
import copy
from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path
import re
import sys
import time
from typing import Any, Protocol

ROOT = Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))
from scripts import automation_goal_dispatcher as reducer
from scripts import automation_goal_program_compiler as program_compiler


AUTOMATION_ROOT = "/packhelper/automation_dispatch_v1"
CODEX_OPS_ROOT = "/packhelper/codex_ops_v2"
LEARNING_ROOT = f"{AUTOMATION_ROOT}/learning"
LEARNING_SNAPSHOTS_ROOT = f"{LEARNING_ROOT}/snapshots"
LEARNING_INBOX_ROOT = f"{LEARNING_ROOT}/inbox"
LEARNING_RECEIPTS_ROOT = f"{LEARNING_ROOT}/receipts"
LEARNING_CONFLICT_RECEIPTS_ROOT = f"{LEARNING_ROOT}/conflict_receipts"
LEARNING_SEQUENCE_ROOT = f"{LEARNING_ROOT}/sequence"
LEARNING_CURSOR_ROOT = f"{LEARNING_ROOT}/cursor"
PROGRAM_ROOT = f"{AUTOMATION_ROOT}/program"
PROGRAM_REQUESTS_ROOT = f"{PROGRAM_ROOT}/requests"
PROGRAM_SEQUENCE_ROOT = f"{PROGRAM_ROOT}/sequence"
PROGRAM_RECEIPTS_ROOT = f"{PROGRAM_ROOT}/receipts"
PROGRAM_CONFLICT_RECEIPTS_ROOT = f"{PROGRAM_ROOT}/conflict_receipts"
PROGRAM_CURSOR_ROOT = f"{PROGRAM_ROOT}/cursor"
LEASE_TTL_MS = 120_000
TERMINAL_STATUSES = {"done", "error", "failed_timeout", "stale_killed", "rejected", "expired"}
USABLE_WORKER_BUNDLE_STATUSES = {
    "applied", "current", "native_sync", "ready", "verified", "verified_current",
}
HEX64 = re.compile(r"[0-9a-f]{64}")
SECRET_TEXT = re.compile(r"(?i)(token|secret|password|authorization)\s*[:=]\s*[^\s,;]+")


class FirebaseTransport(Protocol):
    def get(self, path: str) -> Any: ...
    def query(self, path: str, params: dict[str, Any]) -> Any: ...
    def get_with_etag(self, path: str) -> tuple[Any, str]: ...
    def compare_and_put(self, path: str, value: Any, etag: str) -> bool: ...
    def put(self, path: str, value: Any) -> None: ...


class AdapterValidationError(ValueError):
    def __init__(self, message: str, *, code: str = "invalid_learning_item") -> None:
        super().__init__(message)
        self.code = code


class ProjectionConflict(AdapterValidationError):
    pass


def _iso(milliseconds: int) -> str:
    return datetime.fromtimestamp(milliseconds / 1000, tz=timezone.utc).isoformat().replace("+00:00", "Z")


def _mapping(value: Any, label: str) -> dict[str, Any]:
    if not isinstance(value, dict):
        raise AdapterValidationError(f"{label} must be an object")
    return value


def _safe_id(value: str, label: str) -> str:
    if not isinstance(value, str) or not value or re.fullmatch(r"[A-Za-z0-9._:-]+", value) is None:
        raise AdapterValidationError(f"{label} is invalid")
    return value


def _payload_hash(value: Any) -> str:
    return reducer.canonical_hash(value)


LEARNING_INBOX_FIELDS = {
    "schema_version", "inbox_id", "goal_id", "goal_epoch", "snapshot_path",
    "snapshot_id", "snapshot_hash", "policy_hash", "action", "target_lane",
    "task_id", "task_fingerprint", "prompt_hash", "risk_assessment_hash",
    "producer", "created_at_ms", "expires_at_ms", "sequence_id", "item_hash",
}
LEARNING_SEQUENCE_FIELDS = {"schema_version", "sequence_id", "inbox_id", "item_hash", "created_at_ms"}
LEARNING_SNAPSHOT_FIELDS = {"schema_version", "producer", "created_at_ms", "body", "body_hash"}
PROGRAM_REQUEST_FIELDS = {
    "schema_version", "request_id", "goal_id", "goal_epoch", "program_id",
    "program_hash", "config_hash", "compiler_sha256", "expected_state_hash",
    "worker_revision", "source_revision", "target_node", "resource_id", "model_id", "reasoning_effort",
    "producer", "created_at_ms", "expires_at_ms", "sequence_id", "item_hash",
}
PROGRAM_SEQUENCE_FIELDS = {"schema_version", "sequence_id", "request_id", "item_hash", "created_at_ms"}
LEARNING_FORBIDDEN_EXECUTION_FIELDS = {
    "prompt", "task", "task_id", "cwd", "model", "model_id", "reasoning_effort",
    "risk", "risk_flags", "risk_assessment", "token_budget", "context_tokens",
}


def learning_item_hash(item: dict[str, Any]) -> str:
    return _payload_hash({key: value for key, value in item.items() if key != "item_hash"})


def learning_sequence_scope(goal_id: str, goal_epoch: int) -> str:
    safe_goal = reducer.firebase_storage_key("goal", _safe_id(goal_id, "goal_id"))
    if not isinstance(goal_epoch, int) or isinstance(goal_epoch, bool) or goal_epoch < 1:
        raise AdapterValidationError("goal_epoch is invalid", code="epoch_mismatch")
    return f"{LEARNING_SEQUENCE_ROOT}/{safe_goal}/{goal_epoch}"


def _hydrate_rtdb_compiled_body(value: Any) -> dict[str, Any]:
    """Restore only fixed compile fields that RTDB drops when empty or null."""

    body = copy.deepcopy(_mapping(value, "compiled learning body"))
    if "excluded_candidates" not in body or body["excluded_candidates"] is None:
        body["excluded_candidates"] = []
    snapshot = body.get("snapshot")
    if not isinstance(snapshot, dict):
        return body
    rules = snapshot.get("rules")
    if not isinstance(rules, list):
        return body
    for rule in rules:
        if not isinstance(rule, dict):
            continue
        full_learning_rule = "action_summary" in rule and "evidence_summary" in rule
        if full_learning_rule and "bounded_evidence_packet" not in rule:
            rule["bounded_evidence_packet"] = None
        if full_learning_rule and "recommended_model_lane" not in rule:
            rule["recommended_model_lane"] = None
        if full_learning_rule and ("review_reason" not in rule or rule["review_reason"] is None):
            rule["review_reason"] = []
        rollback = rule.get("rollback")
        if isinstance(rollback, dict) and "previous_snapshot_id" not in rollback:
            rollback["previous_snapshot_id"] = None
        expiry = rule.get("expiry")
        if isinstance(expiry, dict) and "expires_at" not in expiry:
            expiry["expires_at"] = None
    return body


def scoped_sequence_path(root: str, goal_id: str, goal_epoch: int) -> str:
    safe_goal = reducer.firebase_storage_key("goal", _safe_id(goal_id, "goal_id"))
    if not isinstance(goal_epoch, int) or isinstance(goal_epoch, bool) or goal_epoch < 1:
        raise AdapterValidationError("goal_epoch is invalid", code="epoch_mismatch")
    return f"{root}/{safe_goal}/{goal_epoch}"


def validate_compiled_snapshot_document(
    document: Any, inbox: dict[str, Any], policy: dict[str, Any]
) -> dict[str, Any]:
    if not isinstance(document, dict) or set(document) != LEARNING_SNAPSHOT_FIELDS:
        raise AdapterValidationError("learning snapshot document schema is invalid", code="snapshot_schema")
    if document.get("schema_version") != 1 or document.get("producer") != inbox.get("producer"):
        raise AdapterValidationError("learning snapshot producer/schema mismatch", code="snapshot_binding")
    raw_body = document.get("body")
    if isinstance(raw_body, dict) and document.get("body_hash") == _payload_hash(raw_body):
        body = copy.deepcopy(raw_body)
    else:
        body = _hydrate_rtdb_compiled_body(raw_body)
        if document.get("body_hash") != _payload_hash(body):
            raise AdapterValidationError("learning compile body hash mismatch", code="snapshot_body_hash")
    if len(reducer.canonical_json(document).encode("utf-8")) > policy["learning"]["max_snapshot_bytes"]:
        raise AdapterValidationError("learning snapshot exceeds size cap", code="snapshot_oversized")
    expected_body_keys = {
        "status", "mode", "policy_version", "policy_hash", "model_lane",
        "ai_invocations", "snapshot", "excluded_candidates",
    }
    if set(body) != expected_body_keys or body.get("status") != "ok" or body.get("mode") != "compile":
        raise AdapterValidationError("nested compile result schema is invalid", code="compile_schema")
    if body.get("model_lane") != "model-0" or body.get("ai_invocations") != 0:
        raise AdapterValidationError("nested compile model lane is invalid", code="compile_schema")
    if body.get("policy_hash") != inbox.get("policy_hash"):
        raise AdapterValidationError("nested compile policy hash mismatch", code="snapshot_binding")
    snapshot = body.get("snapshot")
    if not isinstance(snapshot, dict):
        raise AdapterValidationError("nested compile snapshot is missing", code="compile_schema")
    if snapshot.get("immutable") is not True or snapshot.get("policy_hash") != inbox.get("policy_hash"):
        raise AdapterValidationError("nested compile snapshot binding mismatch", code="snapshot_binding")
    snapshot_id = snapshot.get("snapshot_id")
    snapshot_hash = snapshot.get("snapshot_hash")
    if snapshot_id != inbox.get("snapshot_id") or snapshot_hash != inbox.get("snapshot_hash"):
        raise AdapterValidationError("nested compile snapshot identity mismatch", code="snapshot_binding")
    if not isinstance(snapshot_hash, str) or HEX64.fullmatch(snapshot_hash) is None:
        raise AdapterValidationError("nested compile snapshot hash is invalid", code="snapshot_binding")
    snapshot_body = {key: value for key, value in snapshot.items() if key not in {"snapshot_id", "snapshot_hash"}}
    if _payload_hash(snapshot_body) != snapshot_hash:
        raise AdapterValidationError("nested compile snapshot hash mismatch", code="snapshot_hash")
    if snapshot_id != f"automation-rule-snapshot-{snapshot_hash[:16]}":
        raise AdapterValidationError("nested compile snapshot id mismatch", code="snapshot_binding")
    rules = snapshot.get("rules")
    allowed_rows = policy["learning"]["promotion_allowlist"].get(inbox.get("task_id"))
    if not isinstance(rules, list) or not rules or not isinstance(allowed_rows, list):
        raise AdapterValidationError("compiled rules are not allowlisted for target", code="promotion_not_allowed")
    allowed = {(row["family"], row["classification"]) for row in allowed_rows}
    for rule in rules:
        stack = [rule]
        while stack:
            value = stack.pop()
            if isinstance(value, dict):
                if set(value) & LEARNING_FORBIDDEN_EXECUTION_FIELDS:
                    raise AdapterValidationError(
                        "compiled rule contains execution fields", code="promotion_not_allowed"
                    )
                stack.extend(value.values())
            elif isinstance(value, list):
                stack.extend(value)
        if (
            not isinstance(rule, dict)
            or (rule.get("family"), rule.get("classification")) not in allowed
            or rule.get("grade") != "A"
            or rule.get("promotion_status") != "compile_ready"
            or rule.get("requires_ai_review") is not False
        ):
            raise AdapterValidationError("compiled rule is not promotion-allowlisted", code="promotion_not_allowed")
    return body


def _hydrate_rtdb_state(value: Any) -> dict[str, Any]:
    """Restore only canonical empty containers that RTDB drops during roundtrip."""

    state = copy.deepcopy(_mapping(value, "goal state"))
    if "now" not in state or state["now"] is None:
        state["now"] = None
    for field in ("next", "watch", "backlog", "blocked"):
        if field not in state or state[field] is None:
            state[field] = []
    for field in (
        "completed", "children", "consumed_receipts", "consumed_learning_snapshots",
        "held_resources", "held_locks",
    ):
        if field not in state or state[field] is None:
            state[field] = {}

    def hydrate_task(row: Any) -> None:
        if not isinstance(row, dict) or not isinstance(row.get("task_id"), str):
            return
        for field in ("dependencies", "locks", "risk_flags"):
            if field not in row or row[field] is None:
                row[field] = []
        assessment = row.get("risk_assessment")
        if isinstance(assessment, dict) and (
            "risk_flags" not in assessment or assessment["risk_flags"] is None
        ):
            assessment["risk_flags"] = []
        envelope = row.get("worker_envelope")
        if isinstance(envelope, dict) and ("locks" not in envelope or envelope["locks"] is None):
            envelope["locks"] = []

    hydrate_task(state.get("now"))
    for lane in ("next", "watch", "backlog", "blocked"):
        rows = state.get(lane)
        if isinstance(rows, list):
            for row in rows:
                hydrate_task(row)
    children = state.get("children")
    if isinstance(children, dict):
        for row in children.values():
            hydrate_task(row)
    return state


class FirebaseGoalDispatchAdapter:
    def __init__(
        self,
        *,
        transport: FirebaseTransport,
        policy: dict[str, Any],
        owner_id: str,
        instance_id: str,
        apply: bool = False,
        now_ms: Any | None = None,
        worker_revision: str,
        required_worker_bundle_sha256: str | None = None,
        capability_allowlist: set[str] | None = None,
        kill_switch: bool = False,
    ) -> None:
        reducer.validate_policy(policy)
        self.transport = transport
        self.policy = copy.deepcopy(policy)
        self.owner_id = _safe_id(owner_id, "owner_id")
        self.instance_id = _safe_id(instance_id, "instance_id")
        if self.instance_id == self.owner_id:
            raise AdapterValidationError("instance_id must be distinct from owner_id")
        self.apply = apply is True
        self._now_ms = now_ms or (lambda: int(time.time() * 1000))
        self.worker_revision = _safe_id(worker_revision, "worker_revision")
        if required_worker_bundle_sha256 is not None:
            if not isinstance(required_worker_bundle_sha256, str) or HEX64.fullmatch(required_worker_bundle_sha256) is None:
                raise AdapterValidationError("required_worker_bundle_sha256 is invalid")
        self.required_worker_bundle_sha256 = required_worker_bundle_sha256
        self.capability_allowlist = frozenset(
            capability_allowlist or self.policy["resource"]["allowed_capabilities"]
        )
        if not self.capability_allowlist or not all(isinstance(value, str) and value for value in self.capability_allowlist):
            raise AdapterValidationError("capability_allowlist is invalid")
        self.kill_switch = kill_switch is True

    def _path(self, collection: str, *parts: str) -> str:
        safe_parts = [_safe_id(part, collection) for part in parts]
        return "/".join((AUTOMATION_ROOT, collection, *safe_parts))

    def _lease_candidate(self, goal_id: str, current: Any, now: int) -> dict[str, Any] | None:
        row = current if isinstance(current, dict) else {}
        owner = row.get("owner")
        instance_id = row.get("instance_id")
        expires = row.get("expires_at_ms")
        live = isinstance(expires, int) and not isinstance(expires, bool) and expires > now
        same_holder = owner == self.owner_id and instance_id == self.instance_id
        if live and not same_holder:
            return None
        renewing = live and same_holder
        epoch = row.get("epoch") if renewing and isinstance(row.get("epoch"), int) else int(row.get("epoch") or 0) + 1
        binding = {
            "goal_id": goal_id,
            "owner": self.owner_id,
            "instance_id": self.instance_id,
            "epoch": epoch,
        }
        return {
            "owner": self.owner_id,
            "instance_id": self.instance_id,
            "epoch": epoch,
            "lease_id": f"lease-{reducer.canonical_hash(binding)[:24]}",
            "acquired_at_ms": int(row.get("acquired_at_ms") or now) if renewing else now,
            "renewed_at_ms": now,
            "expires_at_ms": now + LEASE_TTL_MS,
        }

    def _acquire_lease(self, goal_id: str, now: int, *, shadow: bool) -> dict[str, Any] | None:
        path = self._path("leases", goal_id)
        current, etag = self.transport.get_with_etag(path)
        candidate = self._lease_candidate(goal_id, current, now)
        if candidate is None:
            return None
        if shadow:
            return candidate
        if not self.transport.compare_and_put(path, candidate, etag):
            return None
        return candidate

    def _candidate_tasks(self, goal_state: dict[str, Any]) -> list[dict[str, Any]]:
        if isinstance(goal_state.get("now"), dict):
            return [goal_state["now"]]
        return [row for row in goal_state.get("next", []) if isinstance(row, dict)]

    def _heartbeat_snapshot(
        self, goal_state: dict[str, Any], lease: dict[str, Any], now: int
    ) -> tuple[dict[str, Any], dict[str, Any] | None]:
        maximum_age_ms = self.policy["resource"]["max_snapshot_age_seconds"] * 1000
        for candidate in self._candidate_tasks(goal_state):
            node = candidate.get("target_node")
            if not isinstance(node, str) or not node:
                continue
            heartbeat = self.transport.get(f"{CODEX_OPS_ROOT}/heartbeat/{node}")
            if not isinstance(heartbeat, dict):
                continue
            updated = heartbeat.get("ts")
            model = heartbeat.get("model")
            raw_models = heartbeat.get("supported_models")
            supported_models = (
                list(raw_models)
                if isinstance(raw_models, list)
                and raw_models
                and all(isinstance(value, str) and value for value in raw_models)
                else [model] if raw_models is None and isinstance(model, str) and model else []
            )
            raw_efforts = heartbeat.get("supported_reasoning_efforts")
            supported_efforts = (
                list(raw_efforts)
                if isinstance(raw_efforts, list)
                and raw_efforts
                and all(isinstance(value, str) and value for value in raw_efforts)
                else [heartbeat.get("reasoning_effort")]
                if raw_efforts is None and isinstance(heartbeat.get("reasoning_effort"), str)
                else []
            )
            revision_matches = self.worker_revision in {
                heartbeat.get("code_revision"), heartbeat.get("source_revision")
            }
            bundle_matches = self.required_worker_bundle_sha256 is None or (
                heartbeat.get("bundle_sha256") == self.required_worker_bundle_sha256
                and heartbeat.get("bundle_status") in USABLE_WORKER_BUNDLE_STATUSES
            )
            valid = (
                heartbeat.get("status") == "idle"
                and heartbeat.get("pending") == 0
                and heartbeat.get("codex_available") is True
                and revision_matches
                and bundle_matches
                and heartbeat.get("node") == node
                and heartbeat.get("host") in {candidate.get("target_host"), "any"}
                and isinstance(updated, int) and 0 <= now - updated <= maximum_age_ms
                and model in supported_models
                and candidate.get("model_id") in supported_models
                and candidate.get("reasoning_effort") in supported_efforts
                and candidate.get("capability") in self.capability_allowlist
            )
            if not valid:
                continue
            snapshot = {
                "status": "ready",
                "checked_at": _iso(updated),
                "resource_id": candidate["resource_id"],
                "capability": candidate["capability"],
                "supported_models": [candidate["model_id"]],
                "capacity": 1,
                "lease_id": lease["lease_id"],
                "lease_epoch": lease["epoch"],
                "lease_expires_at": _iso(lease["expires_at_ms"]),
            }
            return snapshot, copy.deepcopy(heartbeat)
        return {}, None

    def _dispatch_event(self, goal_state: dict[str, Any], lease: dict[str, Any], now: int) -> tuple[dict[str, Any], dict[str, Any] | None]:
        snapshot, heartbeat = self._heartbeat_snapshot(goal_state, lease, now)
        return {
            "type": "dispatch",
            "parent_goal": goal_state["active_goal"]["goal_id"],
            "goal_epoch": goal_state["active_goal"]["goal_epoch"],
            "now": _iso(now),
            "resource_snapshot": snapshot,
        }, heartbeat

    def _attach_envelope(self, state: dict[str, Any], envelope: dict[str, Any] | None) -> None:
        if envelope is None or not isinstance(state.get("now"), dict):
            return
        child_id = state["now"].get("child_id")
        state["now"]["worker_envelope"] = copy.deepcopy(envelope)
        if isinstance(child_id, str) and isinstance(state.get("children", {}).get(child_id), dict):
            state["children"][child_id]["worker_envelope"] = copy.deepcopy(envelope)

    def _envelope_from_state(self, state: dict[str, Any]) -> dict[str, Any] | None:
        current = state.get("now")
        if not isinstance(current, dict):
            return None
        envelope = current.get("worker_envelope")
        return copy.deepcopy(envelope) if isinstance(envelope, dict) else None

    def _heartbeat_still_valid(self, child: dict[str, Any], lease: dict[str, Any], now: int) -> bool:
        snapshot, _heartbeat = self._heartbeat_snapshot({"now": child, "next": []}, lease, now)
        return bool(snapshot) and snapshot.get("lease_id") == child.get("lease_id") and snapshot.get("lease_epoch") == child.get("lease_epoch")

    def _request_path(self, request_id: str) -> str:
        return f"{CODEX_OPS_ROOT}/requests/{_safe_id(request_id, 'request_id')}"

    def _same_worker_request(self, existing: Any, envelope: dict[str, Any]) -> bool:
        if not isinstance(existing, dict):
            return False
        for key, value in envelope.items():
            if key == "status":
                continue
            actual = existing.get(key)
            if value == [] and actual is None:
                actual = []
            if actual != value:
                return False
        return existing.get("status") in {"pending", "running", *TERMINAL_STATUSES}

    def _ensure_request(self, state: dict[str, Any], lease: dict[str, Any], now: int) -> dict[str, Any]:
        child = state.get("now")
        envelope = self._envelope_from_state(state)
        if not isinstance(child, dict) or envelope is None:
            return {"status": "idle"}
        request_id = envelope["request_id"]
        path = self._request_path(request_id)
        existing, etag = self.transport.get_with_etag(path)
        if existing is not None:
            if self._same_worker_request(existing, envelope):
                return {"status": "request_noop", "request_id": request_id}
            return {"status": "child_payload_conflict", "request_id": request_id}
        if not self._heartbeat_still_valid(child, lease, now):
            return {"status": "resource_unavailable", "request_id": request_id}
        try:
            created = self.transport.compare_and_put(path, envelope, etag)
        except Exception as exc:  # state is already canonical; retry next once
            return {"status": "request_write_failed", "request_id": request_id, "error": type(exc).__name__}
        if created:
            return {"status": "request_created", "request_id": request_id}
        winner = self.transport.get(path)
        if self._same_worker_request(winner, envelope):
            return {"status": "request_noop", "request_id": request_id}
        return {"status": "child_payload_conflict", "request_id": request_id}

    def _ensure_projection(self, path: str, payload: dict[str, Any]) -> None:
        existing, etag = self.transport.get_with_etag(path)
        if existing is not None:
            if _payload_hash(existing) != _payload_hash(payload):
                raise ProjectionConflict(f"projection conflict: {path}")
            return
        try:
            created = self.transport.compare_and_put(path, payload, etag)
        except Exception as exc:
            raise ProjectionConflict(f"projection CAS failed: {path}") from exc
        if created:
            return
        winner = self.transport.get(path)
        if _payload_hash(winner) != _payload_hash(payload):
            raise ProjectionConflict(f"projection conflict: {path}")

    def _write_adapter_heartbeat(self, goal_id: str, lease: dict[str, Any], now: int) -> None:
        payload = {
            "owner": self.owner_id, "instance_id": self.instance_id,
            "goal_id": goal_id, "lease_id": lease["lease_id"],
            "lease_epoch": lease["epoch"], "updated_at_ms": now,
        }
        self.transport.put(self._path("heartbeat", self.owner_id), payload)

    def _audit(self, goal_id: str, kind: str, state_value: dict[str, Any], decision: dict[str, Any], now: int) -> None:
        payload = {
            "goal_id": goal_id, "kind": kind, "state_hash": _payload_hash(state_value),
            "decision_hash": _payload_hash(decision), "at_ms": now,
        }
        audit_id = reducer.canonical_hash(payload)
        self._ensure_projection(self._path("audit", goal_id, audit_id), payload)

    def _repair_receipt_index(self, goal_id: str, state_value: dict[str, Any]) -> None:
        for receipt_id, receipt_fingerprint in sorted(state_value.get("consumed_receipts", {}).items()):
            payload = {
                "goal_id": goal_id,
                "receipt_id": receipt_id,
                "receipt_fingerprint": receipt_fingerprint,
            }
            self._ensure_projection(self._path("receipt_index", goal_id, receipt_id), payload)

    def _learning_receipt(
        self, inbox: dict[str, Any], status: str, reason: str, decision: dict[str, Any] | None = None
    ) -> dict[str, Any]:
        return {
            "schema_version": 1,
            "inbox_id": inbox["inbox_id"],
            "item_hash": inbox["item_hash"],
            "goal_id": inbox.get("goal_id", ""),
            "goal_epoch": inbox.get("goal_epoch", 0),
            "task_id": inbox.get("task_id", ""),
            "snapshot_id": inbox.get("snapshot_id", ""),
            "status": status,
            "reason": reason,
            "decision_hash": _payload_hash(decision or {}),
        }

    def _reject_learning_item(
        self,
        inbox_id: str,
        item_hash: str,
        current: dict[str, Any],
        reason: str,
    ) -> dict[str, Any]:
        goal = current["active_goal"]
        synthetic = {
            "inbox_id": inbox_id,
            "item_hash": item_hash if isinstance(item_hash, str) else "",
            "goal_id": goal["goal_id"],
            "goal_epoch": goal["goal_epoch"],
            "task_id": "",
            "snapshot_id": "",
        }
        decision = {"status": "learning_rejected", "inbox_id": inbox_id, "reason": reason}
        receipt = self._learning_receipt(synthetic, "rejected", reason, decision)
        if self.apply:
            self._ensure_projection(f"{LEARNING_RECEIPTS_ROOT}/{inbox_id}", receipt)
        return decision

    def _validate_learning_inbox(
        self, raw: Any, sequence: dict[str, Any], current: dict[str, Any], now: int
    ) -> tuple[dict[str, Any], dict[str, Any]]:
        if not isinstance(raw, dict) or set(raw) != LEARNING_INBOX_FIELDS:
            raise AdapterValidationError("learning inbox schema is invalid", code="inbox_schema")
        inbox = copy.deepcopy(raw)
        if inbox.get("schema_version") != 1:
            raise AdapterValidationError("learning inbox schema version is invalid", code="inbox_schema")
        inbox_id = _safe_id(inbox.get("inbox_id"), "inbox_id")
        if inbox_id != sequence["inbox_id"] or inbox.get("sequence_id") != sequence["sequence_id"]:
            raise AdapterValidationError("learning sequence/inbox binding mismatch", code="sequence_binding")
        if sequence.get("created_at_ms") != inbox.get("created_at_ms"):
            raise AdapterValidationError("learning sequence timestamp mismatch", code="sequence_binding")
        if len(reducer.canonical_json(inbox).encode("utf-8")) > self.policy["learning"]["max_item_bytes"]:
            raise AdapterValidationError("learning inbox exceeds size cap", code="inbox_oversized")
        item_hash = inbox.get("item_hash")
        if not isinstance(item_hash, str) or HEX64.fullmatch(item_hash) is None or learning_item_hash(inbox) != item_hash:
            raise AdapterValidationError("learning inbox item hash mismatch", code="item_hash")
        if sequence.get("item_hash") != item_hash:
            raise AdapterValidationError("learning sequence item hash mismatch", code="sequence_binding")
        goal = current["active_goal"]
        epoch = inbox.get("goal_epoch")
        if (
            inbox.get("goal_id") != goal["goal_id"]
            or not isinstance(epoch, int) or isinstance(epoch, bool)
            or epoch < 1 or epoch > self.policy["learning"]["max_goal_epoch"]
            or epoch != goal["goal_epoch"]
        ):
            raise AdapterValidationError("learning goal epoch binding mismatch", code="epoch_mismatch")
        created = inbox.get("created_at_ms")
        expires = inbox.get("expires_at_ms")
        max_ttl = self.policy["learning"]["max_ttl_seconds"] * 1000
        if (
            not isinstance(created, int) or isinstance(created, bool)
            or not isinstance(expires, int) or isinstance(expires, bool)
            or created > now or expires <= now or expires <= created or expires - created > max_ttl
        ):
            raise AdapterValidationError("learning inbox TTL is invalid", code="expired")
        if inbox.get("producer") not in self.policy["learning"]["allowed_producers"]:
            raise AdapterValidationError("learning producer is not allowlisted", code="producer_not_allowed")
        if inbox.get("policy_hash") not in self.policy["learning"]["allowed_policy_hashes"]:
            raise AdapterValidationError("learning policy is not allowlisted", code="policy_not_allowed")
        if inbox.get("action") != "promote_existing_watch_once" or inbox.get("target_lane") != "watch":
            raise AdapterValidationError("learning action is invalid", code="action_not_allowed")
        for field in ("snapshot_hash", "policy_hash", "task_fingerprint", "prompt_hash", "risk_assessment_hash"):
            value = inbox.get(field)
            if not isinstance(value, str) or HEX64.fullmatch(value) is None:
                raise AdapterValidationError(f"learning {field} is invalid", code="inbox_schema")
        snapshot_id = _safe_id(inbox.get("snapshot_id"), "snapshot_id")
        expected_path = f"{LEARNING_SNAPSHOTS_ROOT}/{snapshot_id}"
        if inbox.get("snapshot_path") != expected_path:
            raise AdapterValidationError("learning snapshot path mismatch", code="snapshot_binding")
        document = self.transport.get(expected_path)
        validate_compiled_snapshot_document(document, inbox, self.policy)
        verification_body = {
            "schema_version": 1,
            "verified_by": "model-0",
            "snapshot_body_hash_verified": True,
            "snapshot_identity_verified": True,
            "inbox_item_hash_verified": True,
            "sequence_binding_verified": True,
            "policy_allowlist_verified": True,
            "snapshot_hash": inbox["snapshot_hash"],
            "item_hash": inbox["item_hash"],
            "policy_hash": inbox["policy_hash"],
        }
        model0_verification = {
            **verification_body,
            "verification_hash": reducer.canonical_hash(verification_body),
        }
        event = {
            "type": "automation_learning_promote_watch_once",
            **{key: inbox[key] for key in (
                "inbox_id", "snapshot_path", "snapshot_id", "snapshot_hash", "policy_hash",
                "action", "target_lane", "task_id", "task_fingerprint", "prompt_hash",
                "risk_assessment_hash", "producer", "created_at_ms", "expires_at_ms", "item_hash",
            )},
            "parent_goal": inbox["goal_id"],
            "goal_epoch": inbox["goal_epoch"],
            "model0_verification": model0_verification,
        }
        return inbox, event

    def _sequence_window(self, sequence_scope: str, cursor_path: str, cap: int) -> list[tuple[str, Any]]:
        cursor = self.transport.get(cursor_path)
        after = cursor.get("sequence_id") if isinstance(cursor, dict) else None
        params: dict[str, Any] = {"orderBy": '"$key"', "limitToFirst": cap + (1 if after else 0)}
        if isinstance(after, str) and after:
            params["startAt"] = json.dumps(after)
        raw = self.transport.query(sequence_scope, params)
        if raw is None:
            return []
        if not isinstance(raw, dict):
            raise AdapterValidationError("sequence projection is invalid", code="sequence_projection_invalid")
        return [(key, value) for key, value in sorted(raw.items()) if not isinstance(after, str) or key > after][:cap]

    def _advance_sequence_cursor(
        self, cursor_path: str, sequence_id: str, item_hash: str, receipt: dict[str, Any]
    ) -> bool:
        if not self.apply:
            return False
        candidate = {
            "schema_version": 1,
            "sequence_id": sequence_id,
            "item_hash": item_hash,
            "receipt_hash": _payload_hash(receipt),
        }
        current, etag = self.transport.get_with_etag(cursor_path)
        if isinstance(current, dict) and isinstance(current.get("sequence_id"), str):
            if current["sequence_id"] >= sequence_id:
                return True
        return bool(self.transport.compare_and_put(cursor_path, candidate, etag))

    def _record_sequence_conflict(
        self,
        *,
        root: str,
        goal_id: str,
        goal_epoch: int,
        sequence_id: str,
        observed_item_hash: str,
        existing_receipt_id: str,
        existing_receipt: Any,
        cursor_path: str,
    ) -> dict[str, Any]:
        projection = {
            "schema_version": 1,
            "goal_id": goal_id,
            "goal_epoch": goal_epoch,
            "sequence_id": sequence_id,
            "observed_item_hash": observed_item_hash,
            "existing_receipt_id": existing_receipt_id,
            "existing_receipt_hash": _payload_hash(existing_receipt),
            "reason": "item_hash_conflict",
        }
        if self.apply:
            scope = scoped_sequence_path(root, goal_id, goal_epoch)
            self._ensure_projection(f"{scope}/{sequence_id}", projection)
            self._advance_sequence_cursor(
                cursor_path, sequence_id, observed_item_hash, projection
            )
        return projection

    def _program_receipt(
        self, request: dict[str, Any], status: str, reason: str
    ) -> dict[str, Any]:
        return {
            "schema_version": 1,
            "request_id": request["request_id"],
            "item_hash": request["item_hash"],
            "goal_id": request.get("goal_id", ""),
            "goal_epoch": request.get("goal_epoch", 0),
            "program_id": request.get("program_id", ""),
            "status": status,
            "reason": reason,
        }

    def _validate_program_request(
        self, raw: Any, sequence: dict[str, Any], current: dict[str, Any], now: int
    ) -> tuple[dict[str, Any], dict[str, Any]]:
        seed_policy = self.policy["program_seed"]
        reducer._validate_state(current)
        if not isinstance(raw, dict) or set(raw) != PROGRAM_REQUEST_FIELDS:
            raise AdapterValidationError("program request schema is invalid", code="program_schema")
        request = copy.deepcopy(raw)
        if request.get("schema_version") != 1:
            raise AdapterValidationError("program request schema version is invalid", code="program_schema")
        request_id = _safe_id(request.get("request_id"), "request_id")
        if request_id != sequence.get("request_id") or request.get("sequence_id") != sequence.get("sequence_id"):
            raise AdapterValidationError("program sequence binding mismatch", code="sequence_binding")
        if sequence.get("created_at_ms") != request.get("created_at_ms"):
            raise AdapterValidationError("program sequence timestamp mismatch", code="sequence_binding")
        if len(reducer.canonical_json(request).encode("utf-8")) > seed_policy["max_item_bytes"]:
            raise AdapterValidationError("program request exceeds size cap", code="program_oversized")
        item_hash = request.get("item_hash")
        actual_item_hash = _payload_hash({key: value for key, value in request.items() if key != "item_hash"})
        if not isinstance(item_hash, str) or HEX64.fullmatch(item_hash) is None or item_hash != actual_item_hash:
            raise AdapterValidationError("program request item hash mismatch", code="item_hash")
        if sequence.get("item_hash") != item_hash:
            raise AdapterValidationError("program sequence item hash mismatch", code="sequence_binding")
        goal = current["active_goal"]
        epoch = request.get("goal_epoch")
        if (
            request.get("goal_id") != goal["goal_id"]
            or not isinstance(epoch, int) or isinstance(epoch, bool)
            or epoch != goal["goal_epoch"] or epoch < 1 or epoch > seed_policy["max_goal_epoch"]
        ):
            raise AdapterValidationError("program goal epoch mismatch", code="epoch_mismatch")
        created = request.get("created_at_ms")
        expires = request.get("expires_at_ms")
        if (
            not isinstance(created, int) or isinstance(created, bool)
            or not isinstance(expires, int) or isinstance(expires, bool)
            or created > now or expires <= now or expires <= created
            or expires - created > seed_policy["max_ttl_seconds"] * 1000
        ):
            raise AdapterValidationError("program request TTL is invalid", code="expired")
        if request.get("producer") not in seed_policy["allowed_producers"]:
            raise AdapterValidationError("program producer is not allowlisted", code="producer_not_allowed")
        if request.get("worker_revision") != self.worker_revision:
            raise AdapterValidationError("program worker revision mismatch", code="worker_revision_mismatch")
        worker_revision = request.get("worker_revision")
        source_revision = request.get("source_revision")
        if (
            not isinstance(worker_revision, str)
            or re.fullmatch(r"[0-9a-f]{12}|[0-9a-f]{40}", worker_revision) is None
            or not isinstance(source_revision, str)
            or re.fullmatch(r"[0-9a-f]{40}", source_revision) is None
            or not source_revision.startswith(worker_revision)
        ):
            raise AdapterValidationError("program source/worker revision binding mismatch", code="revision_binding_mismatch")
        binding = seed_policy["allowed_programs"].get(request.get("program_id"))
        if not isinstance(binding, dict) or any(request.get(field) != binding[field] for field in binding):
            raise AdapterValidationError("program policy attestation mismatch", code="program_attestation_mismatch")
        config_bytes = Path(program_compiler.DEFAULT_PROGRAMS).read_bytes()
        compiler_bytes = Path(program_compiler.__file__).read_bytes()
        if hashlib.sha256(compiler_bytes).hexdigest() != request["compiler_sha256"]:
            raise AdapterValidationError("local program compiler hash mismatch", code="local_attestation_mismatch")
        config = json.loads(config_bytes.decode("utf-8"))
        if reducer.canonical_hash(config) != request["config_hash"]:
            raise AdapterValidationError("local program config hash mismatch", code="local_attestation_mismatch")
        consumed_key = reducer.firebase_storage_key("program_request", request_id)
        previous = current["consumed_learning_snapshots"].get(consumed_key)
        if previous is not None:
            if previous != item_hash:
                raise AdapterValidationError("program request replay changed", code="receipt_conflict")
            return request, {"status": "program_seed_replay", "request_id": request_id}
        if request.get("expected_state_hash") != _payload_hash(current):
            raise AdapterValidationError("program expected state hash mismatch", code="state_drift")
        compile_request = {
            "schema_version": 1,
            "program_id": request["program_id"],
            "goal_id": request["goal_id"],
            "goal_epoch": request["goal_epoch"],
            "source_revision": request["source_revision"],
            "target_node": request["target_node"],
            "resource_id": request["resource_id"],
            "model_id": request["model_id"],
            "reasoning_effort": request["reasoning_effort"],
        }
        compiled = program_compiler.compile_watch_task(compile_request, config, self.policy)
        tasks = compiled.get("watch_tasks")
        if not isinstance(tasks, list) or len(tasks) != 1:
            raise AdapterValidationError("program compiler did not produce one watch task", code="compile_invalid")
        task = tasks[0]
        task_id = task.get("task_id")
        present = any(
            isinstance(row, dict) and row.get("task_id") == task_id
            for lane in ("next", "watch", "backlog") for row in current[lane]
        ) or (isinstance(current.get("now"), dict) and current["now"].get("task_id") == task_id)
        if present:
            raise AdapterValidationError("program target already exists", code="target_exists")
        blocked_matches = [
            row for row in current["blocked"]
            if isinstance(row, dict) and row.get("task_id") == task_id
        ]
        if len(blocked_matches) > 1:
            raise AdapterValidationError("program target has duplicate blocked rows", code="target_blocked_invalid")
        blocked_entry = blocked_matches[0] if blocked_matches else None
        completed_key = reducer.firebase_storage_key("task", task_id)
        completed_entry = reducer._mapping_entry(current["completed"], "task", task_id)
        rearming_completed = completed_entry is not None
        rearming_blocked = blocked_entry is not None
        if rearming_completed and rearming_blocked:
            # A terminal token overrun is intentionally projected into both
            # ``completed`` (immutable terminal history) and ``blocked``
            # (operator-visible stop reason).  Permit rearm only when both
            # projections bind the exact same rejected child; every other
            # completed+blocked combination remains fail-closed.
            if (
                not isinstance(completed_entry, dict)
                or completed_entry.get("status") != "rejected"
                or completed_entry.get("child_id") != blocked_entry.get("child_id")
            ):
                raise AdapterValidationError(
                    "program target has conflicting completed and blocked projections",
                    code="target_blocked_invalid",
                )
        if rearming_completed:
            if (
                not isinstance(completed_entry, dict)
                or completed_entry.get("task_id") != task_id
                or completed_entry.get("status") not in TERMINAL_STATUSES
                or not isinstance(completed_entry.get("child_id"), str)
            ):
                raise AdapterValidationError(
                    "program completed target is not safely rearmable", code="target_completed_invalid"
                )
            completed_child = current["children"].get(completed_entry["child_id"])
            if (
                not isinstance(completed_child, dict)
                or completed_child.get("status") not in TERMINAL_STATUSES
                or any(
                    reducer._entry_child_id(value) == completed_entry["child_id"]
                    for mapping in (current["held_resources"], current["held_locks"])
                    for value in mapping.values()
                )
            ):
                raise AdapterValidationError(
                    "program completed child is not safely rearmable", code="target_completed_invalid"
                )
        if rearming_blocked:
            blocked_child_id = blocked_entry.get("child_id")
            blocked_child = current["children"].get(blocked_child_id)
            if (
                blocked_entry.get("block_reason") != "actual_token_budget_exceeded"
                or blocked_entry.get("terminal_status") != "rejected"
                or not isinstance(blocked_entry.get("actual_token_usage"), int)
                or not isinstance(blocked_entry.get("reserved_token_budget"), int)
                or blocked_entry["actual_token_usage"] <= blocked_entry["reserved_token_budget"]
                or not isinstance(blocked_child, dict)
                or blocked_child.get("status") != "rejected"
                or any(
                    reducer._entry_child_id(value) == blocked_child_id
                    for mapping in (current["held_resources"], current["held_locks"])
                    for value in mapping.values()
                )
            ):
                raise AdapterValidationError(
                    "program budget-blocked target is not safely rearmable", code="target_blocked_invalid"
                )
        reducer._normalized_task(task, current, self.policy)
        updated = copy.deepcopy(current)
        if rearming_completed:
            if completed_key in updated["completed"]:
                del updated["completed"][completed_key]
            elif task_id in updated["completed"]:
                del updated["completed"][task_id]
        if rearming_blocked:
            updated["blocked"] = [
                row for row in updated["blocked"]
                if not (isinstance(row, dict) and row.get("task_id") == task_id)
            ]
        updated["watch"].append(copy.deepcopy(task))
        updated["consumed_learning_snapshots"][consumed_key] = item_hash
        return request, {
            "status": (
                "program_watch_rearmed_from_budget_block"
                if rearming_blocked
                else "program_watch_rearmed" if rearming_completed else "program_watch_seeded"
            ),
            "request_id": request_id,
            "state": updated,
        }

    def _poll_program_inbox(
        self, current: dict[str, Any], now: int
    ) -> tuple[dict[str, Any], list[dict[str, Any]], dict[str, Any] | None]:
        goal = current["active_goal"]
        policy = self.policy["program_seed"]
        sequence_scope = scoped_sequence_path(PROGRAM_SEQUENCE_ROOT, goal["goal_id"], goal["goal_epoch"])
        cursor_path = scoped_sequence_path(PROGRAM_CURSOR_ROOT, goal["goal_id"], goal["goal_epoch"])
        try:
            rows = self._sequence_window(sequence_scope, cursor_path, policy["max_inbox_scan"])
        except AdapterValidationError as exc:
            return current, [{"status": "program_poll_rejected", "reason": exc.code}], None
        decisions: list[dict[str, Any]] = []
        rejected = 0
        for sequence_id, raw_sequence in rows:
            rejection_id = reducer.firebase_storage_key("program_reject", str(sequence_id))
            try:
                if not isinstance(raw_sequence, dict) or set(raw_sequence) != PROGRAM_SEQUENCE_FIELDS:
                    raise AdapterValidationError("program sequence schema is invalid", code="sequence_schema")
                sequence = copy.deepcopy(raw_sequence)
                if sequence.get("schema_version") != 1 or sequence.get("sequence_id") != sequence_id:
                    raise AdapterValidationError("program sequence identity is invalid", code="sequence_schema")
                request_id = _safe_id(sequence.get("request_id"), "request_id")
                rejection_id = request_id
                item_hash = sequence.get("item_hash")
                if not isinstance(item_hash, str) or HEX64.fullmatch(item_hash) is None:
                    raise AdapterValidationError("program sequence hash is invalid", code="sequence_schema")
                receipt_path = f"{PROGRAM_RECEIPTS_ROOT}/{request_id}"
                existing_receipt = self.transport.get(receipt_path)
                if existing_receipt is not None:
                    if isinstance(existing_receipt, dict) and existing_receipt.get("item_hash") == item_hash:
                        self._advance_sequence_cursor(cursor_path, sequence_id, item_hash, existing_receipt)
                        continue
                    self._record_sequence_conflict(
                        root=PROGRAM_CONFLICT_RECEIPTS_ROOT,
                        goal_id=goal["goal_id"], goal_epoch=goal["goal_epoch"],
                        sequence_id=sequence_id, observed_item_hash=item_hash,
                        existing_receipt_id=request_id, existing_receipt=existing_receipt,
                        cursor_path=cursor_path,
                    )
                    decisions.append({"status": "program_item_conflict", "request_id": request_id})
                    continue
                raw_request = self.transport.get(f"{PROGRAM_REQUESTS_ROOT}/{request_id}")
                request, decision = self._validate_program_request(raw_request, sequence, current, now)
                if decision["status"] == "program_seed_replay":
                    receipt = self._program_receipt(request, "accepted", "append_existing_watch_once")
                    decisions.append(decision)
                    return current, decisions, {
                        "receipt": receipt, "cursor_path": cursor_path,
                        "sequence_id": sequence_id, "item_hash": item_hash,
                    }
                updated = decision.pop("state")
                receipt_reason = (
                    "rearm_budget_blocked_watch_once"
                    if decision.get("status") == "program_watch_rearmed_from_budget_block"
                    else "rearm_completed_watch_once"
                    if decision.get("status") == "program_watch_rearmed"
                    else "append_existing_watch_once"
                )
                receipt = self._program_receipt(request, "accepted", receipt_reason)
                decisions.append(decision)
                return updated, decisions, {
                    "receipt": receipt, "cursor_path": cursor_path,
                    "sequence_id": sequence_id, "item_hash": item_hash,
                }
            except (AdapterValidationError, program_compiler.ProgramCompileError, reducer.GoalDispatchValidationError, KeyError, ValueError, OSError) as exc:
                rejected += 1
                reason = getattr(exc, "code", "invalid_program_request")
                synthetic = {
                    "request_id": rejection_id,
                    "item_hash": raw_sequence.get("item_hash", "") if isinstance(raw_sequence, dict) else "",
                    "goal_id": goal["goal_id"], "goal_epoch": goal["goal_epoch"], "program_id": "",
                }
                receipt = self._program_receipt(synthetic, "rejected", reason)
                if self.apply:
                    self._ensure_projection(f"{PROGRAM_RECEIPTS_ROOT}/{rejection_id}", receipt)
                    self._advance_sequence_cursor(cursor_path, str(sequence_id), synthetic["item_hash"], receipt)
                decisions.append({"status": "program_rejected", "request_id": rejection_id, "reason": reason})
                if rejected >= policy["max_rejections_per_once"]:
                    break
        return current, decisions, None

    def _poll_learning_inbox(
        self, current: dict[str, Any], now: int
    ) -> tuple[dict[str, Any], list[dict[str, Any]], dict[str, Any] | None]:
        cap = self.policy["learning"]["max_inbox_scan"]
        goal = current["active_goal"]
        sequence_scope = learning_sequence_scope(goal["goal_id"], goal["goal_epoch"])
        cursor_path = scoped_sequence_path(LEARNING_CURSOR_ROOT, goal["goal_id"], goal["goal_epoch"])
        try:
            raw_sequences = self._sequence_window(sequence_scope, cursor_path, cap)
        except AdapterValidationError as exc:
            return current, [{"status": "learning_poll_rejected", "reason": exc.code}], None
        decisions: list[dict[str, Any]] = []
        rejected = 0
        for sequence_id, raw_sequence in raw_sequences:
            if len(decisions) >= cap:
                break
            rejection_id = reducer.firebase_storage_key("learning_reject", str(sequence_id))
            try:
                safe_sequence_id = _safe_id(sequence_id, "sequence_id")
                if not isinstance(raw_sequence, dict) or set(raw_sequence) != LEARNING_SEQUENCE_FIELDS:
                    raise AdapterValidationError("learning sequence schema is invalid", code="sequence_schema")
                sequence = copy.deepcopy(raw_sequence)
                if sequence.get("schema_version") != 1 or sequence.get("sequence_id") != safe_sequence_id:
                    raise AdapterValidationError("learning sequence binding is invalid", code="sequence_schema")
                inbox_id = _safe_id(sequence.get("inbox_id"), "inbox_id")
                rejection_id = inbox_id
                item_hash = sequence.get("item_hash")
                if not isinstance(item_hash, str) or HEX64.fullmatch(item_hash) is None:
                    raise AdapterValidationError("learning sequence item hash is invalid", code="sequence_schema")
                existing_receipt = self.transport.get(f"{LEARNING_RECEIPTS_ROOT}/{inbox_id}")
                if existing_receipt is not None:
                    if isinstance(existing_receipt, dict) and existing_receipt.get("item_hash") == item_hash:
                        self._advance_sequence_cursor(cursor_path, sequence_id, item_hash, existing_receipt)
                        continue
                    self._record_sequence_conflict(
                        root=LEARNING_CONFLICT_RECEIPTS_ROOT,
                        goal_id=goal["goal_id"], goal_epoch=goal["goal_epoch"],
                        sequence_id=sequence_id, observed_item_hash=item_hash,
                        existing_receipt_id=inbox_id, existing_receipt=existing_receipt,
                        cursor_path=cursor_path,
                    )
                    decisions.append({"status": "learning_item_conflict", "inbox_id": inbox_id})
                    continue
                raw_inbox = self.transport.get(f"{LEARNING_INBOX_ROOT}/{inbox_id}")
                inbox, event = self._validate_learning_inbox(raw_inbox, sequence, current, now)
                try:
                    updated, decision = reducer.reduce_dispatch(current, event, self.policy)
                except reducer.GoalDispatchValidationError as exc:
                    rejected += 1
                    decisions.append(self._reject_learning_item(inbox_id, item_hash, current, exc.code))
                    receipt = self.transport.get(f"{LEARNING_RECEIPTS_ROOT}/{inbox_id}") if self.apply else None
                    if isinstance(receipt, dict):
                        self._advance_sequence_cursor(cursor_path, sequence_id, item_hash, receipt)
                    if rejected >= self.policy["learning"]["max_rejections_per_once"]:
                        break
                    continue
                receipt = self._learning_receipt(
                    inbox,
                    "accepted",
                    "promote_existing_watch_once",
                    {"inbox_id": inbox_id, "item_hash": item_hash},
                )
                decisions.append(decision)
                return updated, decisions, {
                    "receipt": receipt,
                    "cursor_path": cursor_path,
                    "sequence_id": sequence_id,
                    "item_hash": item_hash,
                }
            except (AdapterValidationError, KeyError, TypeError, ValueError) as exc:
                rejected += 1
                code = exc.code if isinstance(exc, AdapterValidationError) else "invalid_learning_item"
                raw_hash = raw_sequence.get("item_hash", "") if isinstance(raw_sequence, dict) else ""
                decisions.append(self._reject_learning_item(rejection_id, str(raw_hash), current, code))
                receipt = self.transport.get(f"{LEARNING_RECEIPTS_ROOT}/{rejection_id}") if self.apply else None
                if isinstance(receipt, dict):
                    self._advance_sequence_cursor(cursor_path, str(sequence_id), str(raw_hash), receipt)
                if rejected >= self.policy["learning"]["max_rejections_per_once"]:
                    break
        return current, decisions, None

    def _learning_event(self, state_value: dict[str, Any], compiled: dict[str, Any]) -> dict[str, Any]:
        source_path = compiled.get("source_path")
        snapshot_hash = compiled.get("snapshot_hash")
        if not isinstance(source_path, str) or not source_path or not isinstance(snapshot_hash, str) or HEX64.fullmatch(snapshot_hash) is None:
            raise AdapterValidationError("compiled learning pointer/hash is invalid")
        evidence = {
            "source_path": source_path,
            "snapshot_hash": snapshot_hash,
            "candidate_count": int(compiled.get("candidate_count") or 0),
        }
        return {
            "type": "automation_learning_snapshot",
            "snapshot_id": _safe_id(compiled.get("snapshot_id"), "snapshot_id"),
            "evidence": evidence,
            "evidence_hash": reducer.canonical_hash(evidence),
            "target_task_ids": list(compiled.get("target_task_ids") or []),
        }

    def _terminal_event(
        self, state_value: dict[str, Any], worker_result: dict[str, Any], lease: dict[str, Any], now: int
    ) -> tuple[dict[str, Any], str]:
        child = _mapping(state_value.get("now"), "current child")
        status = worker_result.get("status")
        if status not in TERMINAL_STATUSES:
            raise AdapterValidationError("worker result is not terminal")
        request_id = child["request_id"]
        envelope = self._envelope_from_state(state_value)
        if envelope is None:
            raise AdapterValidationError("current child has no persisted worker envelope")
        original_request = self.transport.get(self._request_path(request_id))
        if original_request is None:
            raise AdapterValidationError("original worker request is missing")
        if not self._same_worker_request(original_request, envelope):
            raise AdapterValidationError("original worker request binding mismatch")
        if worker_result.get("worker") != envelope.get("target_node"):
            raise AdapterValidationError("terminal worker does not match target_node")
        nested = worker_result.get("result")
        if not isinstance(nested, dict):
            raise AdapterValidationError("worker result.result is missing")
        if nested.get("request_id") != request_id:
            raise AdapterValidationError("nested result request_id mismatch")
        if nested.get("terminal_status") != status:
            raise AdapterValidationError("nested terminal_status mismatch")
        result_hash = reducer.canonical_hash(worker_result)
        summary = SECRET_TEXT.sub(r"\1=[REDACTED]", str(nested.get("summary") or ""))[:512]
        evidence = {"worker_status": status, "summary": summary, "result_hash": result_hash}
        artifact_hash = nested.get("artifact_hash")
        if isinstance(artifact_hash, str) and HEX64.fullmatch(artifact_hash):
            evidence["artifact_hash"] = artifact_hash
        receipt_id = f"worker-{reducer.canonical_hash({'request_id': request_id, 'result_hash': result_hash})[:24]}"
        dispatch_event, _heartbeat = self._dispatch_event({**state_value, "now": None}, lease, now)
        event = {
            "type": "terminal_receipt",
            "receipt_id": receipt_id,
            "request_id": request_id,
            "child_id": child["child_id"],
            "parent_goal": child["parent_goal"],
            "goal_epoch": child["goal_epoch"],
            "terminal_status": status,
            "source_revision": child["source_revision"],
            "task_fingerprint": child["task_fingerprint"],
            "input_evidence_hash": child["input_evidence_hash"],
            "actual_token_usage": nested.get("actual_token_usage", child["token_budget"]),
            "evidence": evidence,
            "evidence_hash": reducer.canonical_hash(evidence),
            "now": _iso(now),
            "resource_snapshot": dispatch_event["resource_snapshot"],
        }
        return event, receipt_id

    def _worker_result(self, state_value: dict[str, Any]) -> dict[str, Any] | None:
        current = state_value.get("now")
        if not isinstance(current, dict) or not isinstance(current.get("request_id"), str):
            return None
        value = self.transport.get(f"{CODEX_OPS_ROOT}/results/{current['request_id']}")
        return copy.deepcopy(value) if isinstance(value, dict) else None

    def once(
        self,
        goal_id: str,
        *,
        seed_state: dict[str, Any] | None = None,
        learning_snapshot: dict[str, Any] | None = None,
    ) -> dict[str, Any]:
        goal_id = _safe_id(goal_id, "goal_id")
        now = int(self._now_ms())
        if self.kill_switch or self.policy["kill_switch"]:
            return {"status": "kill_switch"}
        goal_path = self._path("goals", goal_id)
        stored, goal_etag = self.transport.get_with_etag(goal_path)
        if stored is None:
            if seed_state is None:
                return {"status": "goal_missing"}
            current = copy.deepcopy(seed_state)
        else:
            current = _hydrate_rtdb_state(stored)
        active_goal = _mapping(current.get("active_goal"), "active_goal")
        if active_goal.get("goal_id") != goal_id:
            raise AdapterValidationError("goal path does not match canonical active_goal")
        lease = self._acquire_lease(goal_id, now, shadow=not self.apply)
        if lease is None:
            return {"status": "lease_lost"}

        original = copy.deepcopy(current)
        decisions: list[dict[str, Any]] = []
        program_pending: dict[str, Any] | None = None
        learning_pending: dict[str, Any] | None = None
        current, program_decisions, program_pending = self._poll_program_inbox(current, now)
        decisions.extend(program_decisions)
        if learning_snapshot is not None:
            current, learning_decision = reducer.reduce_dispatch(
                current, self._learning_event(current, learning_snapshot), self.policy
            )
            decisions.append(learning_decision)
        current, inbox_decisions, learning_pending = self._poll_learning_inbox(current, now)
        decisions.extend(inbox_decisions)

        terminal_receipt_id: str | None = None
        worker_result = self._worker_result(current)
        if worker_result is not None and worker_result.get("status") in TERMINAL_STATUSES:
            terminal_event, terminal_receipt_id = self._terminal_event(current, worker_result, lease, now)
            current, decision = reducer.reduce_dispatch(current, terminal_event, self.policy)
            decisions.append(decision)
            self._attach_envelope(current, decision.get("next_child"))
            action_kind = "terminal"
        elif current.get("now") is None:
            dispatch_event, _heartbeat = self._dispatch_event(current, lease, now)
            current, decision = reducer.reduce_dispatch(current, dispatch_event, self.policy)
            decisions.append(decision)
            self._attach_envelope(current, decision.get("next_child"))
            action_kind = "dispatch"
        else:
            decision = {"status": "active"}
            decisions.append(decision)
            action_kind = "recover"

        final_decision = decisions[-1]
        if not self.apply:
            result = {"status": "shadow", "decision": final_decision, "state_hash": _payload_hash(current)}
            envelope = self._envelope_from_state(current)
            if envelope is not None:
                result["next_child"] = envelope
            return result

        self._write_adapter_heartbeat(goal_id, lease, now)
        changed = current != original or stored is None
        if changed and not self.transport.compare_and_put(goal_path, current, goal_etag):
            return {"status": "goal_cas_conflict"}
        if learning_pending is not None:
            learning_receipt = learning_pending["receipt"]
            self._ensure_projection(
                f"{LEARNING_RECEIPTS_ROOT}/{learning_receipt['inbox_id']}",
                learning_receipt,
            )
            self._advance_sequence_cursor(
                learning_pending["cursor_path"],
                learning_pending["sequence_id"],
                learning_pending["item_hash"],
                learning_receipt,
            )
        if program_pending is not None:
            program_receipt = program_pending["receipt"]
            self._ensure_projection(
                f"{PROGRAM_RECEIPTS_ROOT}/{program_receipt['request_id']}",
                program_receipt,
            )
            self._advance_sequence_cursor(
                program_pending["cursor_path"],
                program_pending["sequence_id"],
                program_pending["item_hash"],
                program_receipt,
            )
        if changed:
            self._audit(goal_id, action_kind, current, final_decision, now)
        self._repair_receipt_index(goal_id, current)

        enqueue = self._ensure_request(current, lease, now)
        if terminal_receipt_id is not None:
            if enqueue["status"] == "request_created":
                return {**enqueue, "status": "terminal_consumed_next_created", "receipt_id": terminal_receipt_id}
            if current.get("now") is None:
                return {"status": "terminal_consumed", "receipt_id": terminal_receipt_id}
        if enqueue["status"] in {"request_created", "request_write_failed", "child_payload_conflict", "resource_unavailable"}:
            return enqueue
        if final_decision.get("status") == "blocked":
            return {"status": "blocked"}
        if final_decision.get("status") in {"resource_unavailable", "idle"}:
            return {"status": final_decision["status"]}
        return enqueue


class CodexOpsFirebaseTransport:
    """Thin runtime wrapper; tests inject a fake and never instantiate this."""

    def __init__(self) -> None:
        from scripts import codex_ops_worker as worker
        self.worker = worker

    def get(self, path: str) -> Any:
        return self.worker.fb_get(path)

    def query(self, path: str, params: dict[str, Any]) -> Any:
        return self.worker.fb_get_query(path, params)

    def get_with_etag(self, path: str) -> tuple[Any, str]:
        return self.worker.firebase_get_with_etag(path)

    def compare_and_put(self, path: str, value: Any, etag: str) -> bool:
        return bool(self.worker.firebase_conditional_put(path, value, etag))

    def put(self, path: str, value: Any) -> None:
        self.worker.fb_put(path, value)


def _load_json(path: str | None) -> dict[str, Any] | None:
    if not path:
        return None
    value = json.loads(Path(path).read_text(encoding="utf-8"))
    return _mapping(value, path)


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--goal-id", required=True)
    parser.add_argument("--owner-id", required=True)
    parser.add_argument("--instance-id", required=True)
    parser.add_argument("--worker-revision", required=True)
    parser.add_argument("--required-worker-bundle-sha256")
    parser.add_argument("--policy", default=str(reducer.DEFAULT_POLICY))
    parser.add_argument("--seed-file")
    parser.add_argument("--learning-file")
    parser.add_argument("--apply", action="store_true")
    parser.add_argument("--kill-switch", action="store_true")
    parser.add_argument("--mode", choices=("once", "watch"), default="once")
    parser.add_argument("--max-iterations", type=int, default=1)
    parser.add_argument("--interval-sec", type=float, default=5.0)
    args = parser.parse_args(argv)
    if args.max_iterations < 1 or args.max_iterations > 100:
        parser.error("--max-iterations must be 1..100")
    adapter = FirebaseGoalDispatchAdapter(
        transport=CodexOpsFirebaseTransport(), policy=reducer.load_policy(args.policy),
        owner_id=args.owner_id, instance_id=args.instance_id,
        apply=args.apply, worker_revision=args.worker_revision,
        required_worker_bundle_sha256=args.required_worker_bundle_sha256,
        kill_switch=args.kill_switch,
    )
    seed = _load_json(args.seed_file)
    learning = _load_json(args.learning_file)
    iterations = 1 if args.mode == "once" else args.max_iterations
    result: dict[str, Any] = {}
    for index in range(iterations):
        result = adapter.once(args.goal_id, seed_state=seed if index == 0 else None, learning_snapshot=learning if index == 0 else None)
        print(json.dumps(result, ensure_ascii=False, sort_keys=True))
        if index + 1 < iterations:
            time.sleep(max(0.1, min(args.interval_sec, 60.0)))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
