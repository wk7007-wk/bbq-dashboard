<!-- source: /root/PackHelper/APP_INTENT.md -->
# PackHelper APP_INTENT.md

## 만든 이유
- POS 프린터 주문을 안정적으로 수집하고, 조리/타이머 상태와 배달 주문 후보를 Firebase에 정리해 현장 앱들이 무겁게 추론하지 않게 한다.

## 사용자 결과
- 메인PC와 서브PC 중 어느 쪽이 먼저 주문을 받아도 주문이 누락되지 않아야 한다.
- ChickenTimer 화면은 계속 단순하게 켜지고, 포장 화면과 혼동되지 않아야 한다.
- DeliveryHelper는 PackHelper가 정리한 주소/주문 타입/중복 병합 결과를 가볍게 소비해야 한다.

## 절대 기준
- TCP 9100으로 들어온 전표는 기본적으로 주문 데이터다. 배민/쿠팡 외 채널을 주소 필터로 버리지 않는다.
- 같은 주문을 양쪽 PC가 받아도 늦게 온 쪽을 버리지 않는다. 기존 capture를 보존하고 빈 주소, 도로명, 주문 타입, 메뉴 정보만 보강한다.
- Firebase 데이터는 누적 보존하고 삭제보다 상태/메타 필드 갱신을 우선한다.
- 폰 앱에서 무거운 raw 재파싱, 건물명 역매칭, 후보 추론을 반복하지 않는다. 정규화는 PC/외부 worker와 Firebase DB가 맡는다.
- RTDB는 스크립트를 실행하지 않는다. 실행 로직은 PC/Termux worker 또는 Cloud Functions/Run 같은 외부 실행 환경에 둔다.

## UI/동선 기준
- 현재 운영 화면은 ChickenTimer다.
- 서브PC 타이머 기본 주소는 `https://wk7007-ops-static-2026.web.app/chicken-timer/?profile=subnote&sync=main`이며 509 구주소는 금지하고 `PACKHELPER_SCREEN_URL` 명시 override만 허용한다.
- 예전 포장 체크리스트 웹 대시보드는 기본 비활성이다.
- 레거시 포장 화면은 필요할 때만 `legacy_pack_dashboard=true`로 별도 활성화한다.

## MCP/검증 기준
- surface_type은 `hybrid-ops`다.
- Firebase read-only preflight는 `/packhelper/capture`, `/packhelper/delivery_orders`, `/packhelper/menu_rules`, `/packhelper/config`, `/packhelper/status`, `/packhelper/source`만 확인한다.
- 웹 UI나 브라우저 증거가 있는 변경은 Playwright/Axe와 공장 PC evidence를 같이 본다.
- CLI/스크립트는 dry-run 또는 read-only evidence만 본다.
- live 주문/포장 원본 변경, 프린트, 카톡 발송, 외부 사이트 조작, Firebase write, destructive change는 별도 safety flow나 명시 승인 없이는 금지한다.

## 데이터/경계 기준
- PackHelper는 전표 capture, 중복 병합, 주문 정규화, KDS/타이머 릴레이를 맡는다.
- 내점 전표는 capture 보존과 별개로 StoreBot 카톡 알림 큐에 즉시 올린다. 메인PC/서브PC가 동시에 잡아도 Firebase claim으로 같은 30초 버킷 중복 발송을 막는다.
- DeliveryHelper는 배달 현장 판단 앱이다. PackHelper 원문을 공유해도 DeliveryHelper 목적을 덮지 않는다.
- 정규화 owner는 `/packhelper/roles/order_normalizer` lease로 1개 노드만 잡는다.
- 결과 경로는 `/packhelper/delivery_orders/{canonical_key}`이고, 원본은 `/packhelper/capture/{order_id}`에 보존한다.
- 상세 역할 분리는 `NORMALIZER_ROLE.md`를 본다.

## C&I / AI Ops 경계
- C&I는 capture 누락, normalizer/lease/PC worker 정체, Firebase schema 불일치, code_version 반영 실패를 감지해 self_fix prompt를 `codex_ops`에 넣을 수 있다.
- 자동 복구는 스크립트/설정/문서 보정, worker 재시작 요청, `code_version` 갱신까지 허용한다.
- 원본 capture 삭제, 주문 확정값 임의 덮어쓰기, DeliveryHelper 배달 상태 확정은 금지한다.
- CLI/LLM은 prompt envelope가 있어야 깨어난다. monitor/worker/사용자/수동 enqueue 또는 상주 판단 루프가 prompt를 주입하며, 이것은 C&I 판단 권한 제한이 아니다.

## 수정 전 질문
- 이 변경이 주문 누락이나 중복 덮어쓰기 위험을 줄이는가.
- 메인PC, 서브PC, 서브폰 중 일부만 살아도 역할 인계가 가능한가.
- DeliveryHelper/StoreBot/PosDelay 소비 경로에 부작용이 없는가.

## 완료 기준
- 검증: Python 문법 검사, read-only Firebase preflight, 정규화/중복 병합 샘플, 필요 시 Playwright/Axe, Firebase heartbeat/lease/status 확인.
- 전달: Python 변경 시 git push와 Firebase `code_version` PUT.
- 남은 위험: 실제 프린터 ESC/POS 변형, PC 자동 pull 지연, 메인PC는 pull 후 restart 명령이 별도로 필요할 수 있음.
