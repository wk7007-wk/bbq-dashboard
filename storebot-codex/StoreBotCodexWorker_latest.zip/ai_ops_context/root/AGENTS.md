<!-- source: /root/my-first-project/AGENTS.md -->
# AGENTS.md — AI 에이전트 장기 운영 전략

> Claude Code(메인), Gemini CLI(설계리뷰/코딩/보안), GPT Codex(코드개선/디자인) 공존 환경
> 서로의 작업을 존중하고, 충돌 없이 협업할 것

---

## 목적
- 이 문서는 단기 메모가 아니라 장기 운영 기준서다.
- 목표는 `속도`보다 `충돌 없는 협업`, `재현 가능한 배포`, `누가 봐도 이어서 작업 가능한 상태`를 유지하는 것이다.
- 모든 에이전트는 자기 강점만 쓰고, 남의 작업을 덮지 않는다.

## 문서 역할 분리
- `AGENTS.md`: 공용 장기 전략, 역할 분담, 충돌 방지, 배포 표준의 단일 기준
- `AI_HANDOFF.md`: 보조 현재 작업판. Codex가 Claude MD를 읽은 뒤 현재 상태 확인/갱신에 사용
- `CLAUDE.md`: Claude Code 전용 실행 규칙, Firebase 메모리/대기열/자동 호출 규칙
- `rules/workflow.txt`: 절차형 작업 흐름과 배포 순서
- `rules/infra.txt`: 인프라/보안/운영 환경 기준
- `rules/intent_records.txt`: 앱 의도 중심 MD 기록 기준, `APP_INTENT.md` 운용 규칙
- `rules/ai_knowledge_organization.txt`: 개인 노트와 운영메뉴얼에 공통 적용하는 AI 의미 분석·제안·승인·Codex/ChatGPT 역할 계약
- `rules/android_first_terminal_bridge.txt`: Android-first 상주 terminal bridge 장기 구조와 안전 기준
- `rules/mcp_restructure.txt`: MCP hub read-model, 로컬 pointer 문서, factory PC 단일 worker 큐, pending 완료 기록 기준
- `rules/mcp_restructure.txt`: MCP는 원천 DB가 아니고 외부 호출/증빙 수집층. canonical은 내부 DB(`/workschedule_v2` 등) 기준.
- `rules/dispatcher_efficiency.txt`: 모든 Codex가 공유하는 최소 hook과 dispatcher/broker의 메모리 admission·필요 리소스 전체 배치·병렬 wave·토큰/속도 효율 기준
- `APP_STABILITY.md`: 앱 안정성 등급, 보호체계, 현재 상태 추적
- `CODEMAP.txt`: 루트 문서/진입점 빠른 찾기
- `config/factory_pc_sync_manifest.json`: 공장 PC/서버폰 외부 worker가 전 프로젝트를 이어받을 때 보는 repo·문서·검증·안전경계 manifest
- 문서가 충돌하면 공용 전략은 `AGENTS.md`를 우선 기준으로 본다.
- Claude를 당분간 안 쓰면 기본 운영 셋은 `AGENTS.md` → `AI_HANDOFF.md` → `CODEMAP.txt` → 필요 시 `rules/*` 순서로 본다.
- 추가 Claude 문맥이 필요하면 `memory/MEMORY.md`, `memory/CURRENT.md` 만 먼저 보고, 나머지 `.claude/*` 는 작업별 on-demand 참고로만 취급한다.
- 세션은 언제든 리셋될 수 있으므로 운영 표준, 프로그램 prompt, baseline 판정 기준 변경은 `AI_HANDOFF.md`나 Wonmux `current_plan.md`에만 두지 않고 `AGENTS.md` 또는 `rules/workflow.txt`에 즉시 반영한다.
- `AI_HANDOFF.md`, `CODEX_BRIEF.md`, Wonmux `current_plan.md`는 현재 상태와 다음 큐를 짧게 가리키는 포인터로만 쓴다.
- prompt/프로그램 guidance는 compact pointer-style로 유지하고, 같은 기준을 여러 문서에 긴 서사로 복제하지 않는다.

## 환경
- **OS**: Android Termux + proot-distro (aarch64/ARM64)
- **시간**: KST (Asia/Seoul)
- **언어**: 한국어
- **빌드**: Gradle 7.5.1 + AGP 7.4.2 + Kotlin 1.8.22 + Java 17

## 프로젝트 목록
| 프로젝트 | 경로 | 타입 | private |
|----------|------|------|---------|
| PosDelay | /root/PosDelay/ | Android | ✅ |
| PosKDS | /root/PosKDS/ | Android | ✅ |
| BankTotal | /root/BankTotal/ | Android | |
| DeliveryHelper | /root/DeliveryHelper/ | Android | ✅ |
| NotallyX | /root/NotallyX/ | Android | ✅ |
| PackHelper | /root/PackHelper/ | Python/Win | |
| SiteBot | /root/SiteBot/ | Python+Edge | |
| StoreBotTermux | /root/StoreBotTermux/ | Android/Termux/Kakao 통합 | |
| WorkSchedule | /root/WorkSchedule/ | WebView | |
| OrderHelper | /root/OrderHelper/ | Web+SiteBot | |

- `StoreBot`은 삭제된 구 앱/레거시 명칭이다. 새 카톡 응답/큐/라우팅/폰측 실행 작업 대상명은 `StoreBotTermux` 통합본이다.

## DB 원천/read-model 계약
- 근무 계획 DB canonical은 `/workschedule_v2`다. 근무표 화면/하이닉스 화면/출력물은 `employees`/`fixed_schedules`/`overrides`/`status` resolver 계약을 통해 소비하고, legacy `/workschedule`나 `/packhelper/storebot_summary/schedule` cache를 원천처럼 재도입하지 않는다.
- 출근/퇴근/실근태 기록 canonical은 `/workschedule_v2/attendance/{date}/{empId}`다. 보조 메타는 `/workschedule_v2/attendance_meta`에 두고 계획 근무(`fixed_schedules`, `overrides`, `status`)와 섞지 않는다.
- 카카오 raw chat/event/claim/worker action은 화면·기능별로 분산 소비하지 않는다. canonical log/read-model contract와 registry를 먼저 정한 뒤 소비자를 붙이고, 요약/cache/MCP 결과는 원본 DB로 보지 않는다.

## 역할 분담
| 담당 | 역할 | 범위 |
|------|------|------|
| **Claude Code** | 메인 개발, 빌드, 배포, Firebase | 전체 |
| **Gemini CLI** | 기획/설계 리뷰, 미검출 리스크 탐지, 사용자 관점 정의, 코딩 및 검증 | 코드 수정 + 검증 + 리포트 |
| **GPT Codex** | 코드 개선, 디자인/UX 개선 | 코드 수정 + APK 전달 |

## 장기 역할 원칙
- `Claude Code`는 프로젝트의 메인 작업선이다.
- `Gemini CLI`는 단순 보안 위주를 넘어 기획 단계에서의 Codex/Claude 미검출 리스크 탐지, 사용자 관점 포인트 정의 등 설계 리뷰와 실제 코딩/검증 영역까지 주도적으로 담당한다.
- `GPT Codex`는 UI/UX 개선, 구조 정리, 코드 품질 개선, APK 전달까지 맡는다.
- 같은 문제를 여러 에이전트가 동시에 구현하지 않는다.
- 구현 담당이 아닌 에이전트는 원칙적으로 `리포트` 또는 `제안`으로 끝낸다.
- 개인폰 메인 ChatGPT와 협업 기록의 ChatGPT 표시명은 정확히 `GPT-5.6 Sol`, `GPT-5.6 Terra`, `GPT-5.6 Luna`만 사용한다. `Sol/Terra/Luna`는 ChatGPT 등급·표시명이며 Codex CLI model id가 아니다. ChatGPT는 OpenClaw의 상주 agent나 단말기 수를 늘리는 참가자로 만들지 않고, 실제 ChatGPT UI/Plugin channel이 있을 때 같은 최소 evidence packet을 전달해 질문·반론·수용판정 receipt를 협업방에 기록한다. `ultra`는 자동 서브에이전트 과호출 위험 때문에 모든 lane에서 사용하지 않는다.
- ChatGPT consumer 구독 surface와 Codex surface를 분리한다. `codex`, `codex exec`, Codex app-server/SDK는 ChatGPT 계정으로 로그인했어도 Codex 사용량이며 실제 ChatGPT 발화나 ChatGPT 구독 직접 호출로 기록하지 않는다. Responses API는 ChatGPT 구독과 별도 과금 surface다.
- 2026-07-24 공식 문서와 개인폰 CLI 확인 기준, consumer ChatGPT 대화를 임의 로컬 프로그램이 headless로 시작하고 응답을 받는 공식 CLI/API는 확인되지 않았다. 실제 ChatGPT 참여는 ChatGPT web/mobile/desktop UI에서 시작한 Chat/Work/Quick chat 또는 ChatGPT 대화가 선택한 공식 Plugin/MCP 호출만 인정한다. 호출 surface, thread/event id, model label이 없는 결과는 ChatGPT receipt가 아니다.
- ChatGPT Plugin/MCP의 호출 방향은 `ChatGPT conversation -> authenticated HTTPS MCP tool -> 최소 결과`다. 앱/Firebase/CLI가 MCP를 호출하는 것만으로 ChatGPT 응답이 생성되지는 않는다. 개인폰 로컬 DB는 공장 PC나 Firebase에 복제하지 않고 개인폰의 read-only/scoped adapter에서 선택·redaction한 최소 packet만 ChatGPT에 반환하며, 이 전송도 외부 반출 receipt를 남긴다.
- coding review와 일반 외부 AI 호출에 같은 surface 구분을 적용한다. unattended/background completion은 명시 승인된 별도 과금 API, Codex quota, 또는 local/provider connector 중 실제 사용 가능한 것을 선택하고, consumer ChatGPT UI를 브라우저 DOM/cookie 자동화로 우회하지 않는다. 실제 ChatGPT channel이 없으면 `chatgpt_participation=unavailable|degraded`로 남기며 Codex를 ChatGPT로 위장하지 않는다.
- ChatGPT의 `unlimited` 표시는 자동화 권한이나 절대 무제한을 뜻하지 않는다. 공식 account/model allowance와 abuse guardrail을 확인하며, 자동·프로그램 방식의 대량 추출이나 제3자 서비스용 계정 공유를 호출 설계로 채택하지 않는다.
- 메인 세션의 `경량 dispatcher`는 직접 실행 범위와 context 관리 원칙이다. 단순 상태·정형 작업은 `GPT-5.6 Luna`, 일반 구현 보조는 `GPT-5.6 Terra`, 설계 반론·코드 리뷰·최종 수용판정은 `GPT-5.6 Sol`을 우선한다. ChatGPT 검토 기본은 `Sol/medium`이고 live 금융·계정·destructive·영업 영향 또는 증거 충돌만 `Sol/high`로 올린다. `max`는 high에서도 해소되지 않는 고위험 이견에 한해 1회만 쓴다.
- 활성 메인 세션의 모델은 비용·속도 최적화를 이유로 낮추지 않는다. 모델 최적화는 작업별 일회용 worker에만 적용하고, main은 사용자 문맥·설계 판단·결과 취합·최종 gate를 계속 맡는다.
- 같은 위험도 라우팅 원칙은 외부 Codex/oneoff worker 선택에도 적용하되 이름은 섞지 않는다. Codex CLI는 runner가 실제 지원한다고 확인된 model id만 `Codex CLI: <actual model id>/<reasoning_effort>`로 기록하며, `GPT-5.6 Sol/Terra/Luna`나 미확인 id를 `--model` 값으로 추측하지 않는다. 같은 task를 여러 모델에 중복 호출하지 않고, 전환 model·reason을 receipt에 남긴다. 고위험 task는 `GPT-5.6 Sol`급 실제 ChatGPT 최종 검토 없이 완료 처리하지 않는다.
- fixed Python/Bash script는 AI 모델을 호출하지 않는 model-0 lane으로 처리한다. 동일 task를 여러 AI에 중복 호출하지 않는다.
- 단체 Codex room의 목적은 하나의 구현을 여러 worker에게 쪼개 맡기는 것이 아니라, 같은 문제를 Codex·ChatGPT·전문 역할이 서로의 의견을 읽고 질문·반론·수정하는 multi-perspective collaboration으로 다루는 것이다.
- 협업방 참가자 수는 품질·토큰·속도 조절 수단이 아니다. 단말기별 Codex 1개면 충분하며, 품질은 `Sol/medium` 검토와 반론 receipt로 확보하고 속도·토큰은 작은 evidence packet, 중복 호출 금지, 광범위 재읽기 금지로 최적화한다.
- main dispatcher는 facilitator·recorder·conflict guard이며 독단적 최종 결정자가 아니다. ChatGPT는 사용자 의도와 전체 흐름 관점의 정식 참가자로 최대한 활용한다.
- 비단순 작업에서 ChatGPT는 문제 정의·사용자 의도·end-to-end 시나리오·누락/모순 질문·증거 종합·최종 수용판정을 주도한다. Codex와 전문 역할은 코드·테스트·물리 증거를 책임지며, ChatGPT가 executor나 물리 증거 owner인 것처럼 보고하지 않는다.
- 구현 전에는 실제 ChatGPT의 질문 또는 반론과 그에 대한 수정 응답을 최소 1회 남기고, 구현 후에는 diff/evidence에 대한 ChatGPT 수용판정을 다시 받는다. 완료 증거는 실제 ChatGPT 발화 event id와 요약이며, Codex가 만든 `ChatGPT 관점` 문구나 합성 역할극은 참가 증거가 아니다.
- fixed script/model-0, 단순 help/status/health/test, 긴급 kill-switch는 ChatGPT 호출 없이 진행할 수 있다. 그 밖의 작업에서 응답이 bounded timeout 안에 없으면 안전한 read-only·국소 코드만 `chatgpt_participation=degraded`로 진행하고 합의 완료로 표시하지 않는다. live 운영·금융·계정·destructive·고위험 변경은 실제 ChatGPT receipt 없이는 `blocked/escalation_needed`다.
- ChatGPT 사용량을 무제한으로 가정하지 않는다. 장기 작업 전 공식 account rate-limit/usage 또는 Usage Dashboard를 확인하고, 한도 근접 시 작은 evidence packet·task 분할·Sol/Terra/Luna 적응형 라우팅·가능한 credit/reset 순으로 대응한다. 정상 라우팅은 model·reason을 기록하고, 고위험 최종 판정을 capacity 때문에 낮춰야 하는 경우에는 사용자에게 알리고 완료를 보류한다.
- 참가자 합의 후 단일 executor가 구현하고 diff와 evidence를 room에 돌려 공동 리뷰한다. 중요한 이견이 남으면 main이 숨기거나 단독 결정하지 않고 사용자 또는 명시된 domain owner에게 올린다.
- `fast 1 + stable 1`, main의 독립 판단, 저위험 합의 시 stable interrupt는 각 참가자가 자기 답을 만들 때 쓰는 내부 호출 최적화일 뿐 group decision을 대체하지 않는다. 두 모델에는 같은 작은 evidence packet만 전달하며, live 운영·금융·계정·destructive 작업에서는 stable을 조기종료하지 않는다.
- 단체 Codex room은 관점 협업과 함께 물리 locality bridge 역할을 한다. personal main은 사용자에게 중계를 요구하지 않고 factory PC와 serverphone에 직접 fresh 상태·증거를 요청해 작업을 잇는다. `factory_pc`는 Windows local repo·build·browser·USB ADB·install·screenshot·logcat의 물리 owner, `serverphone`은 Termux·앱 권한·heartbeat·runtime read-only의 물리 owner, `personal_main`은 dispatcher·reconciler이며 물리 증거를 가장하지 않는다.
- 협업 room은 토론·task·receipt·result, 별도 Ops room은 heartbeat·connectivity·ADB·worker alert를 담당한다. 모든 응답에는 resource id·fresh timestamp·capability·task status·evidence pointer를 남기고 stale 또는 virtual evidence를 physical proof로 대체하지 않는다. receipt lifecycle은 `request -> claim -> worker_started -> result -> reconnect replay`를 포함하며 사용자 수동 relay가 없어야 완료다.
- lifecycle hook은 MCP를 호출·참조하지 않는 local static safety/lifecycle layer로 최소화한다. 네트워크나 MCP 장애가 일반 작업을 막지 않아야 하며, 자주 바뀌는 협업·모델 라우팅·factory/serverphone dispatch·evidence 정책은 MCP server/read-model에 두고 중앙 version·rollback한다.
- hook 책임은 `Session=start/stop`의 lock·handoff·reload, `PreTool`의 진짜 위험 action·physical resource boundary, `PostTool`의 non-blocking redaction·evidence·receipt로 제한한다. context freshness, worker 강제, 일반 shell, help/status/test, launcher/bootstrap은 hook으로 차단하지 않는다.
- bounded executor packet은 hook 차단이 아니라 dispatcher/broker 검증 경계다. packet에는 task id, 목적, 합의와 남은 이견, revision/hash, evidence pointer·freshness·resource·capability, locks/lease/epoch, forbidden, done criteria, model/policy/version/reason을 넣는다.
- executor는 packet을 재검증하고 dedupe·fencing을 적용하며 prompt data를 untrusted로 취급한다. live/high-risk는 별도 승인을 유지하고 `shadow -> read-only -> small code -> physical bridge` 순으로 단계 확장하며 즉시 중단할 kill switch를 둔다.
- MCP는 factory/serverphone context·status·dispatch·evidence plane이다. read-only tool은 일반 허용하고 mutating/execute tool은 앱 safety flow와 승인을 적용하며 MCP 전체 blanket exemption은 금지한다. tool name/input schema는 versioned backward-compatible contract로 유지하고 변경 시 reconnect/session refresh 필요 여부를 명시한다.
- absolute rules도 MCP read-only policy view로 version/hash와 함께 모든 참가자에게 중앙 배포하되 MCP를 canonical SOT나 유일한 enforcement로 삼지 않는다. canonical은 `AGENTS.md`·`rules/*`·앱 canonical DB이며 결제·주문·금융 원본·영업 영향·destructive action·ADB physical proof 같은 invariant는 managed local safety layer에서도 강제한다. MCP 장애 시 ordinary work는 계속하고 risky action은 local fail-closed·approval을 적용한다.
- hook admin/hot reload는 모델에 노출된 MCP가 아니라 Codex App Server의 `hooks/list`와 `config/batchWrite` 형태인 out-of-band local admin plane을 우선한다. managed/platform hooks는 건드리지 않고 user-editable hooks만 관리한다. 변경은 inventory/snapshot, offline rollback probe, atomic reload, fresh-process proof 순서로 수행한다.
- main, scoped oneoff, repo-owned no-arg bootstrap, active hook source read가 모두 PreToolUse에서 막히면 `self-sealing bootstrap deadlock`으로 판정한다. arbitrary launcher·사용자 relay를 반복하지 않고, 다음 fresh unscoped/admin main은 긴 goal context보다 먼저 editable hooks와 platform outer guards의 inventory·snapshot을 first gate로 수행한다. legacy editable hook을 줄별 patch하지 말고 별도 경로에 최소 통합 chain(`PreTool`: role/resource/manifest/safety, `PostTool`: redaction/evidence/receipt, `Session`: lock/handoff/reload)을 구축한다. offline tests와 rollback probe PASS 후 config를 atomic cutover하고 fresh session probe PASS 뒤에만 legacy editable hooks를 제거한다. 보호 공백을 만드는 선삭제, platform guard 삭제 시도, global disable은 금지하며 실패하면 snapshot으로 rollback한다. 기존 dirty/local patch는 보존한다.
- Matrix/협업 room은 토론·합의·task receipt/result surface이고 HTTP/WSS는 DeliveryHelper·StoreBotTermux 같은 앱 연결 adapter다. canonical DB/read-model만 원천이며 room·API·cache를 원천 DB로 사용하지 않는다.
- adapter는 `task_id/request/claim/worker_started/result/reconnect replay`, auth/capability, idempotency, lease/epoch/expiry/evidence의 공통 broker lifecycle을 공유한다. routine low-risk는 API direct route, ambiguous/high-risk는 협업 room으로 escalate한다. DeliveryHelper는 주소·요청·비밀번호를 최소 전달하고 로그를 마스킹하며, StoreBotTermux live Kakao action은 targeted role·single executor·safety gate를 거치고 heartbeat·ADB·alert는 Ops room으로 보낸다. adapter 확장은 core physical E2E 완료 후 진행한다.
- 긴 작업은 한 번에 몰지 말고 짧은 요청과 체크포인트로 쪼갠다.
- 장기 작업은 `짧은 분석/상태 -> 구현 -> 검증/보고` 순으로 끊고 중간 진행 보고를 남긴다.
- 일회용 worker는 작은 단위 완료/검증/커밋/보고 후 닫고, 다음 단위는 새 요청으로 시작한다.
- 외부 호출/일회용 worker 지시는 긴 묶음이 아니라 작은 작업 단위로 나누고, 각 worker에 timeout 기준, 중간보고 기준, 담당 파일/권한, 완료 증거를 명시한다.
- worker가 오래 걸리면 큰 작업을 계속 기다리지 말고 `버전 수정`, `빌드`, `센터 배포`, `설치 검증`처럼 다음 단위로 분리한다.

## 작업 분기 기준
- 기능 개발, 빌드, 배포, Firebase 연동: `Claude Code`
- 설계/기획 리뷰, 사용자 시나리오 고도화, 보안, 취약점 패치 및 코딩: `Gemini CLI`
- 디자인 개편, UX 개선, 코드 정리, 테스트 자동화 보강, APK 전달: `GPT Codex`
- PriceHunt에서 `Gemini CLI`는 검색 결과 생성과 HTML 출력 확인만 담당한다.
- 경계가 애매하면 `Claude Code`가 메인, 나머지는 보조로 붙는다.

## 실전 협업 방식
- 고정 분업보다 `작업별 주 구현자 전환`을 우선한다.
- 각 작업마다 `주 구현자`는 1명만 정한다.
- 나머지 모델은 같은 파일을 동시에 직접 수정하지 말고 `리뷰/대안 제시` 역할로 붙는다.
- `구조, 상태관리, Firebase, 다중 프로젝트 영향`은 `Claude Code`가 주 구현자 맡기 좋다.
- `UI, UX, Android 화면, 테스트 자동화, 빌드, APK 전달`은 `GPT Codex`가 주 구현자 맡기 좋다.
- `보안, 인증, 포트, 키, URL 검증`은 `Gemini CLI`가 리뷰 담당 맡기 좋다.
- 같은 유형 버그를 2번 연속 내면 작업 주도권을 반대 모델로 넘긴다.
- 30분 이상 막히면 반대 모델 관점으로 재검토한다.
- 구현 담당은 코드를 만든다.
- 반대 모델은 `버그 위험`, `더 단순한 방법`, `영향 범위 누락` 중심으로 본다.
- 빌드는 공통 판정 수단일 뿐이고, `주 구현자`와 `최종 수정권`은 별개다.
- 메인 디스패처는 경량 유지가 기본이고, 깊은 읽기/광범위 분석/수정/검증은 외부 실행 리소스에 위임한다.
- 병렬은 공장 PC에 세션을 여러 개 늘린다는 뜻이 아니라, 순서 의존이 없는 독립 lane 두 개를 동시에 진행한다는 뜻이다. 개인폰 세션 Codex는 결과를 취합/정리/final gate만 맡는다. 공장 PC 추가 worker는 `heartbeat parallel hint`나 dirty gate 통과 시에만 예외적으로 사용한다.
- 한 작업 결과가 다음 작업의 전제면 병렬이 아니라 순차 진행이다.
- 물리 공장 PC와 서버폰 물리 Codex/C&I는 개인폰 리소스가 아니므로 충돌 없는 별도 lane이면 동시에 쓸 수 있다. 공장 PC lane은 repo/code/build/browser 검증 중심, 서버폰 lane은 Android/Kakao/live-state(heartbeat/스크린샷 포함) 중심으로 고정한다. 예: factory PC는 repo/code/브라우저, serverphone은 live permission/runtime/read-only 검증.
- 같은 DB write, 같은 파일/repo write, 같은 hot path 실행, 같은 ADB 장치, 같은 APK 설치/검증, 같은 위험 action이 순서 의존이면 병렬 금지다.
- 서버폰 `subphone_termux_ops`가 `bundle_copy` 런타임이면 repo 수정/커밋/push 주체가 아니다. 이 lane은 StoreBotTermux live/app 상태, 알림/접근성/input 권한, bundle direct_probe/read-only 진단, Firebase heartbeat/shape 검증까지만 맡고, ADB·파일·스크린샷·로그 evidence와 폰측 적용 확인은 `factory_pc` 물리 리소스 증거가 있을 때만 완료로 본다.
- 공장 PC와 서버폰이 둘 다 막히면 컨텍스트 신선도가 좋은 가상 oneoff-worker를 쓴다.
- 가상 worker 처리는 물리 PC/서버폰 처리 증거가 아니다. 보고에서는 `가상 worker 처리`와 `물리 PC/서버폰 처리`를 분리한다.
- 물리 실행자나 가상 oneoff-worker를 활용하더라도 카카오 hot path, 주문·결제·금융 원본 변경, 배민/쿠팡 실행, 영업 영향 live action, destructive write는 앱별 safety flow를 반드시 따른다.

## 크로스 체크 표준
- 사용자가 `검토해`, `다시 봐`, `크로스 체크`라고 하면 기본은 **구현자가 만든 diff 중심 리뷰**다.
- 리뷰 담당은 전체 재구현/전체 재분석보다 `git diff`와 해당 작업의 핸드오프/체크리스트를 먼저 본다.
- 검토 순서: `git status` → 관련 핸드오프/요구사항 → `git diff` → 위험 파일만 추가 열람 → 필요한 검증.
- 보고는 `버그/회귀 위험`, `누락된 요구사항`, `검증 부족`을 우선하고, 단순 취향·대규모 재설계는 뒤로 미룬다.
- 큰 재작성은 `Claude 구현 → Codex diff 리뷰` 또는 `Codex 구현 → Claude diff 리뷰`처럼 구현자와 리뷰어를 분리할 수 있다.
- 작은 수정은 한 모델이 끝까지 처리한다. 버튼/CSS/단일 버그는 크로스 체크를 기본값으로 쓰지 않는다.
- 리뷰 중 수정이 필요해도 먼저 리포트하고, 사용자가 맡긴 경우에만 국소 패치한다.
- 외부 coder/worker 결과가 있어도 개인 main/final gate는 테스트 통과만으로 완료 처리하지 않는다.
- 사이트/화면 사용자 검증은 실제 브라우저 기준이 기본이다. DOM marker/정적 grep/unit test는 보조 증거이며, 사용자가 `직접 들어가서 검증`, `설계안 대비 매칭 검증`을 말한 경우 live 화면 검증 없이 완료 보고하지 않는다.
- 브라우저 검증은 `보이는가, 누를 수 있는가, 저장/출력 경로가 맞는가, 불필요한 로그/개발자 용어가 숨겨졌는가`를 확인하고, 인증 화면은 인증 전/후를 분리해 인증 후 미검증이면 완료가 아니라 제한으로 보고한다.
- 사용자-facing 사이트, StoreBot, 카카오 출력 검증은 repo 파일 확인만으로 완료 판정하지 않는다. 반드시 `live deployed artifact(URL/hosting target/file hash) -> canonical DB/source path -> fresh generated output/render/payload` 3자 대조를 남긴다.
- dynamic output은 과거 request snapshot으로 현재 상태를 판정하지 않는다. source 변경 이후 fresh `no-publish` 또는 dry-run output을 새로 생성해 현재 source와 비교한다.
- DB 관련 도메인 canonical path는 근무 `/workschedule_v2`, 운영메뉴얼 `/packhelper/ops_manual` 아래 `entries/candidates/read_model`, 뉴스/날씨는 stale `/packhelper/storebot_summary/news|weather|schedule`가 아니라 realtime/fresh generation 증거다.
- live site 검증은 실제 URL이 어느 repo/public dir/file에서 배포됐는지 hash/hosting target으로 확인한다. WorkSchedule docs 같은 비-live repo 파일만 보고 live 완료로 판정하지 않는다.
- 사용자-facing 검증 보고에는 `PASS/FAIL/PARTIAL`, source path, live artifact path/hash, fresh output request id/payload, 미검증 항목을 포함한다.
- 외부 worker 결과는 신뢰하되 final gate가 독립 검증한다.

## 작업 시작 전 공통 절차
- 먼저 `git status` 확인
- `CODEMAP.txt`가 있으면 먼저 읽기
- `APP_INTENT.md`가 있으면 앱을 만든 이유와 완료 기준 먼저 확인
- 현재 작업 파일이 이미 수정 중이면 겹치지 않게 범위 재조정
- Firebase 경로, API 응답 형식, 공용 스크립트 변경은 소비자 프로젝트까지 영향 확인

## 앱 버전/업데이트센터 절대 기준
- Android APK를 빌드·배포·설치하는 작업에서는 `versionName`을 배포 시점의 KST 날짜+시간 기준으로 올린다. 예: `MMDD.HHMM`.
- `versionCode`는 기존 설치본과 update-center가 업데이트로 인식하도록 반드시 증가시킨다.
- APK를 사용자에게 설치 또는 배포했다고 보고하려면 update-center 대상 앱의 `version.json`과 최신 APK 파일까지 같은 버전명·버전코드·sha256으로 갱신하고 live URL에서 검증한다.
- Android 수정 뒤 사용자가 `진행`, `설치`, `전달`, `줘`라고 하면 별도 build-only 요청이 없는 한 앱별 배포 스크립트로 update-center를 먼저 공개·live 검증한 뒤 다운로드/설치 화면을 연다. 로컬 APK나 Download 복사만으로 전달 완료 처리하지 않는다.
- 서버폰, 개인폰, update-center는 각각 별도 설치/배포 상태로 보고한다. 한쪽 설치나 hosted 파일 갱신을 다른 쪽 완료 증거로 대체하지 않는다.
- 앱별 update channel과 공개 순서는 `rules/workflow.txt`를 SOT로 본다. 하나의 Firebase/Hosting 경로를 모든 앱에 가정하지 않는다.
- AppUpdateCenter/ChickenTimer의 현재 채널은 `bbq-dashboard` GitHub Pages `/updates` metadata/catalog + GitHub Release `app-updates` APK다.

## Codex 세션 시작 규칙
- Codex는 새 세션/작업 시작 시 Claude 정리 산출물을 먼저 읽고, 사용자가 같은 설명을 반복하지 않게 한다.
- 읽기 순서:
  1. `/root/my-first-project/CLAUDE.md`
  2. `/root/.claude/projects/-root-my-first-project/memory/MEMORY.md`
  3. `/root/.claude/projects/-root-my-first-project/memory/CURRENT.md` (세션 시작 SOT — 빌드 표 + ⚡ 전환 + ⚠️ 오판단 + P0/P1/P2)
  4. `/root/my-first-project/CODEX_BRIEF.md` (긴 기록을 못 읽을 때도 놓치면 안 되는 최신 핵심)
  5. 작업 주제별 `memory/{앱}.md` 또는 `memory/feedback_*.md` 1~2개만 선택
  6. 사용자가 `/연결`, `/서브폰`, `/배포`, `/점검`, `/정리` 같은 Claude 명령을 말하면 해당 `.claude/commands/{명령}.md`
  7. 대상 프로젝트 `CODEMAP.txt`와 `CLAUDE.md`
- 모든 memory를 통째로 읽지 않는다. `현재 상태`, `최근 전환`, `오판단 주의`, 관련 토픽만 읽는다.
- Claude 정리 산출물과 코드가 충돌하면 실제 코드와 `git status`를 우선한다.
- `CODEX_BRIEF.md`는 빠른 최신 요약, `AI_HANDOFF.md`는 보조 현재 상태판이다. 규칙 소스는 Claude MD와 이 `AGENTS.md`다.

## Codex 단독 운영
- Claude를 쓰지 않는 기간에는 Codex가 `AGENTS.md`를 공용 규칙 SOT로 본다.
- 현재 핵심 요약은 `CODEX_BRIEF.md`, 상세 상태는 `AI_HANDOFF.md`, 구조와 진입점은 `CODEMAP.txt`를 우선한다.
- `CLAUDE.md`와 `.claude/*` 산출물은 필요한 경우에만 열고, 현재 코드와 충돌하면 코드 기준으로 판단한다.
- Claude memory fallback이 필요하면 `MEMORY.md` → `CURRENT.md` → 관련 `memory/{앱}.md` 또는 `feedback_*.md` 1~2개만 읽는다.
- 공용 절차가 더 필요하면 `rules/workflow.txt`, `rules/infra.txt`만 추가로 읽는다.

## Codex/Wonmux dispatcher 기준
- Codex 계정과 사용자 작업선은 하나를 기준으로 유지한다. `personal_main`, 메인 PC, `factory_pc`, `serverphone`은 서로 다른 Codex 계정이 아니라 물리 실행 리소스이며, Telegram 역할 봇 수와도 분리한다.
- 어느 화면·단말에서든 같은 작업을 이어받을 수 있도록 모든 외부 작업은 `task/request id + repo + branch/commit + resource id + evidence/receipt + next pointer`를 남긴다. 세션·단말 전환이 canonical 문서·DB·Git 기준선을 갈라놓아서는 안 된다.
- 메인 Codex/Wonmux 세션은 반드시 경량 dispatcher로만 운용한다. 모든 `nontrivial` 요청은 model-0 preflight의 `ready` receipt와 외부 실행 task를 1개 이상 가져야 하며, 없으면 실행·완료 판정을 금지한다. `personal_main`은 coordination/reconcile/final gate만 맡는다.
- Codex 정석 lane은 `clean git -> 작은 범위 task -> 적절한 실행 환경 -> targeted verification -> diff/review -> 작은 커밋 -> worker/session close` 순서다.
- 병렬은 순서 의존 없는 독립 lane 동시 진행 + 개인폰 세션 Codex의 결과 취합/정리/final gate다. 한 작업이 끝나야 다음 작업이 가능하면 순차 진행으로 기록한다.
- 물리 공장 PC와 서버폰 물리 Codex/C&I는 개인폰 리소스가 아니므로 충돌 없는 별도 lane이면 동시에 쓸 수 있다. 같은 DB write, 파일/repo write, hot path 실행, ADB 장치, APK 설치/검증, 위험 action이 순서 의존이면 병렬 금지다.
- `WorkSchedule` 사이트 코드 검증은 공장 PC repo/browser lane에서 수행한다. `StoreBotTermux`/카카오/폰 측 Android 상태 점검은 서버폰 lane에서 수행한다.
- Playwright MCP는 공장 PC 설치 기준으로 본다. 개인 main에 MCP가 직접 노출되지 않아도 `factory_pc browser lane` 또는 공장 PC worker 경유 호출 가능성을 먼저 확인하고, `MCP 없음`만으로 브라우저 검증 불가라고 단정하지 않는다.
- MCP 기반 라우팅은 read-model/registry/guard뿐 아니라 리소스 제약 때문에 공장 PC 실행 lane을 호출/위임하는 기준으로도 쓴다.
- 공장 PC와 서버폰이 둘 다 막히면 개인폰 main 직접 수행 대신 컨텍스트 신선도가 좋은 가상 oneoff-worker를 쓴다.
- 가상 worker는 물리 리소스가 아니다. 완료 보고에서 `가상 worker 처리`와 `물리 PC/서버폰 처리`를 분리하고, 가상 결과를 물리 실행 완료 증거로 쓰지 않는다.
- 외부 리소스/worker로 진행한 작업의 진행 보고, 완료 보고, 인수인계에는 `사용 리소스: factory_pc:pc_codex_resource_01`, `사용 리소스: serverphone:subphone_termux_ops`, `사용 리소스: virtual:oneoff-worker:<id>`, `사용 리소스: personal_main` 중 하나처럼 짧고 일관되게 표기한다.
- `personal_main`은 병렬 작업 수행자가 아니라 dispatcher/result reconciler/final gate다.
- 물리 리소스 대신 virtual worker를 쓰면 `virtual 사유: PC dirty-reject`, `serverphone bundle-runtime only`, `ADB unavailable`, `safety boundary`처럼 한 줄 사유를 함께 남긴다.
- 직전 세션 설계 복구는 `복구 대상 설계안: ...`과 `사용 리소스: ...`를 분리해 쓴다. 세션 복구 절차 문서를 실제 설계안으로 오인하지 않는다.
- 자동 PC CLI 제어 경로는 공장 PC에서 `scripts/start_pc_codex_cli_runner.ps1`를 상주시킨 뒤 개인폰/메인 Codex가 `scripts/pc_codex_cli_enqueue.py`로 `/packhelper/pc_codex_cli/requests`에 `health/status/sync/codex_exec/codex_resume/stop/shutdown` 요청을 넣는 것이다. App Remote는 사용자가 PC UI/터미널을 직접 조작할 때 쓰고, `codex_ops` 큐는 fallback, long job, background, audit trail 용도로 둔다.
- `pc_codex_cli` runner는 heartbeat, request timeout, same-node stale running 회수, output cap, wrapper restart loop를 먹통 방어 기준으로 본다.
- 장기 terminal bridge 구조는 Android-first다. 공통 protocol/state는 StoreBotTermux/Termux native execution 모델을 기준으로 하고, 공장 PC는 Windows ConPTY 계열 adapter를 붙이는 보조 실행자로 본다. 세부 기준은 `rules/android_first_terminal_bridge.txt`를 본다.
- PC repo/외부 checkout이 dirty/stale이면 같은 파일 작업 전 dirty 보존, branch 분리, 커밋/스태시, sync/revision gate 판단을 별도 작은 단위로 먼저 끝낸다.
- 설계와 완료 기준이 확정되면 먼저 현재 작업판에 짧게 기록하고, 무거운 일은 짧은 lane/task 패킷으로 나눠 맡긴다.
- 추가 프롬프트/요청은 즉시 최우선이 아니다. active goal, 안전성, 사용자 업무 영향, 파일 충돌, 외부 worker 상태로 `now/in_progress`, `next`, `backlog`, `지속관리(watch/recurring)`, `blocked` 중 하나로 분류한다.
- active goal과 직접 관련된 요청은 현재 체크리스트에 편입하고, 무관하면 순서조정 또는 backlog로 둔다. 충돌/위험하면 사용자에게 이유를 짧게 알린다.
- 지속관리(watch/recurring)는 작업 종료마다 상태와 추적 포인터를 갱신하고, 닫히지 않은 항목은 완료 보고에서 숨기지 않는다.
- 개인폰 Wonmux/Codex는 개인폰 Termux/Codex CLI 조작면이자 dispatcher다. PC에 wonmux 수신 데몬이 떠 있어야 하는 구조로 보지 않고, 개인폰에서 병렬 작업이나 worker fan-out을 하지 않는다.
- 개인폰 Codex 검증은 worker evidence, `git status`, diff 범위, 짧은 문서 포인터 확인까지만 맡긴다. 빌드, 대규모 테스트, audit, live 확인, 긴 로그 분석은 외부 실행 리소스가 맡는다.
- 무거운 읽기, 분석, 수정, 빌드, 검증, 긴 로그 읽기, 대량 파일 검색, 긴 대기는 개인폰에서 금지하고 외부 실행 리소스에 위임한다.
- 개인폰 세션 메모리가 불안정하면 물리 공장 PC가 전 프로젝트 repo 동기화, 실제 수정, 빌드, 검증, 업데이트센터 배포, 가능한 ADB/설치 확인의 주 실행자다. 시작 기준과 프로젝트 목록은 `config/factory_pc_sync_manifest.json`을 본다.
- 사용자가 설계 확정 뒤 개인폰 메모리 사용 금지를 선언한 작업은 개인폰 과거 세션·로컬 메모리·긴 로그를 판단 근거로 쓰지 않는다. 개인폰은 요청 전달과 final gate만 맡고, 공장 PC worker가 durable docs와 repo를 새로 읽어 판단·수정·검증한다.
- 공장 CLI가 새 기준/hook을 못 보면 먼저 `/root/my-first-project`에서 `bash scripts/bootstrap_factory_cli_context.sh --install-root-pointer --verify-managed-hooks`를 실행해 최신 pull, cwd, `/root/AGENTS.md` 포인터를 맞추고 host managed hook을 read-only 검증한다. bootstrap은 user config나 hook을 설치하지 않는다.
- Wonmux 세션 리셋이 같은 날 2회 이상 반복되면 개인폰 local main에서 계속 새 세션을 만들지 말고 `.wonmux/chat.jsonl`/handoff만 남긴 뒤 짧은 외부 worker 패킷으로 넘긴다.
- 열린 Codex/Wonmux sub/work 세션 정리는 `scripts/manage_codex_wonmux_sessions.py` dry-run 요약을 먼저 보고, 유지할 main 1개를 식별한 뒤 명시 옵션이 있을 때만 worker-like 후보를 종료한다.
- 개인폰 메인 ChatGPT와 외부 ChatGPT 검토는 위 장기 역할 원칙의 `GPT-5.6 Sol/Terra/Luna` 적응형 라우팅을 따른다. 설계 반론·코드 리뷰·최종 수용판정은 기본 `GPT-5.6 Sol/medium`, 정형 확인·요약은 `GPT-5.6 Luna`, 일반 구현 보조는 `GPT-5.6 Terra`를 우선한다. 고위험 또는 증거 충돌만 `Sol/high`, 해소되지 않은 고위험 이견만 `Sol/max` 1회로 올린다. 외부 Codex/oneoff worker는 같은 위험도 기준으로 고르되 실제 지원되는 Codex CLI model id로 별도 기록한다.
- 실제 ChatGPT 검토는 공장 PC 브라우저에 종속하지 않는다. factory ChatGPT UI/Plugin channel이 실패하거나 unavailable이면 개인폰에 이미 열린 실제 ChatGPT UI/Plugin channel을 확인해 같은 최소 evidence packet으로 재시도한다. 개인폰의 실제 event/receipt가 있으면 정상 참여로 인정하고, channel이 없으면 `chatgpt_participation=unavailable|degraded`로 남긴다. 공장 PC는 repo·코드·빌드·브라우저·USB 증거 역할을 계속 맡는다.
- 설계안-코드 일치 여부 대조는 메인 Codex가 최종 게이트를 맡고, 읽기 전용 대조는 빠른 모델, 실제 구현은 충돌 없는 단일 worker, 사이트 로직/문서/테스트 같은 bounded 작업은 중간 모델을 우선 쓴다.
- 개인폰 main 세션은 직접 worker fan-out을 하지 않는다. 분할 작업은 짧은 외부 worker 패킷으로 나누고, 동시 물리 실행은 순서 의존 없는 독립 lane일 때만 허용한다.
- 공장 PC CLI 자동 조작은 `pc_codex_cli` runner가 담당한다. App Remote는 GUI/터미널을 사람이 직접 보는 조작면이고, 직접 PC 셸 접근이 있을 때는 runner 없이 PC 안에서 CLI를 쓸 수 있다.
- Wonmux에서 긴 설계안이나 긴 프롬프트를 공장 PC에 넘길 때는 factory PC direct session registry(`/packhelper/pc_codex_cli/direct_sessions/{node}`)를 먼저 보고 `factory_pc_direct_inject.py`로 `discover -> choose -> codex_resume` 한다. direct session이 없으면 `blocked/no_direct_session`으로 보고하고, 사용자가 명시 fallback을 준 경우에만 `pc_codex_cli_enqueue.py --command codex_exec|codex_resume --allow-codex-exec` 또는 `codex_ops` Firebase queue/prompt file/session lock을 fallback, long job, background, audit trail 용도로 쓴다.
- 같은 Codex 세션이 이미 작업 중이면 Wonmux 주입 요청은 즉시 실행하지 않고 `queued`로 남긴다. 결과는 세션 ID, 프롬프트 파일 경로, stdout/stderr/status, 완료/실패 사유만 짧게 기록한다.
- PC app-server WebSocket listener는 현재 없으며, `factory_sse_listener`도 일반 Codex 작업 lane으로 보지 않는다.
- 외부 worker 위임은 파일/역할/검증 lane을 분리하고, 같은 파일/repo write/Firebase live 경로/ADB 장치/위험 action 동시 처리는 lock 없이는 금지한다. 각 worker는 증거와 남은 위험을 짧게 반환한다.
- 개인 main은 단순 relay가 아니라 설계/검증 책임자다. 사용자 발화를 그대로 복붙하지 말고 목적, 배경, 현재 상태, 원천 DB, 파일 범위, 금지사항, 완료기준, 검증 증거, 보고 형식으로 번역한 작업지시를 넘긴다.
- 모호한 사용자 표현은 main이 구체 항목으로 풀어쓰고, 불확실한 것은 `확인할 것`으로 명시한다. 구현만이 아니라 설계안 대비 코드 매칭 검증을 맡길 때도 체크리스트를 함께 준다.
- 외부 worker 결과는 final gate가 사용자 관점으로 재검증한다.
- 물리 공장 PC worker는 수동 진단 대상만이 아니다. 안전하고 기능적으로 유용하면 live-state 확인, 스크린샷/로그 수집, ADB·설치 점검, 폰측 적용 확인, heartbeat/worker 확인, 제한된 백그라운드 검증을 맡긴다. 서버폰 lane은 ADB 없이 가능한 live-state/read-only 확인으로 제한한다.
- Android APK 실제 설치/검증의 기본 루트는 factory PC USB ADB다. ADB 실행과 ADB 기반 증거 수집(`adb devices`, install, 파일 hash, screenshot, logcat)은 `factory_pc` 물리 리소스 전용이다.
- `personal_main`, `virtual:oneoff-worker:*`, `serverphone:subphone_termux_ops` bundle-runtime lane은 ADB/install/file hash/screenshot/logcat을 직접 수행하거나 완료 증거로 보고하지 않는다.
- 공장 PC 증거가 없으면 ADB/파일 생성/실제 발송 증거는 `미검증` 또는 `blocked`로 보고하고, Firebase heartbeat/queue/app read-only 응답은 이를 대체하지 못한다.
- 공장 PC는 매 ADB 설치/검증 전 `C:\Users\wk700\platform-tools\adb.exe devices -l`로 현재 연결 장치를 증명하고 실제 serial에만 `install -r`과 `dumpsys package`를 수행한다. 장치가 1대면 그 serial, 여러 대면 사용자가 지정한 serial만 사용한다.
- 전역 `ANDROID_SERIAL` 고정은 금지한다. 필요 시 현재 PowerShell 세션에서만 `$env:ADB_DEVICE_SERIAL="원하는_시리얼"`처럼 임시 지정한다.
- 공장 PC ADB 경로는 `C:\Users\wk700\platform-tools\adb.exe`다. 현재 서버폰 후보 serial/model은 `R39M30RWR2F`/`SM-G975N`이며, 현재 `devices -l` 확인 결과가 그 후보일 때만 쓴다.
- 개인폰 serial은 저장값/추정으로 설치하지 않는다. 공장 PC USB `devices -l`에서 식별되거나 사용자가 명시 serial을 준 경우만 설치 대상으로 삼는다.
- 현재 호스트가 공장 PC임을 증명하지 못하면 ADB 직접 실행 금지이며, `scripts/pc_codex_cli_enqueue.py`로 factory PC 요청을 등록한다. 큐 요청에는 `repo`, `apk`, `package`, expected `versionName`/`versionCode`/`sha256`, `allowed_commands`, `forbidden_actions`, `verify` fields를 넣는다.
- 서버폰 ADB 설치/검증 재시도는 USB ADB를 1순위로 본다. `adb devices`에 USB `device`가 있으면 그 serial로 `adb install -r`/`dumpsys package`를 먼저 수행하고, 서버폰이 공장 PC에 USB로 물려 있으면 설치도 공장 PC USB ADB에서 한다.
- 서버폰이 공장 PC에 직접 USB 연결된 작업은 연결/설치 판정도 실제 USB가 물린 공장 PC Codex/작업자만 수행한다. 위치가 불확실한 세션은 ADB·설치·연결 명령을 실행하지 말고 공장 PC 요청/큐만 남긴다.
- `IP:port` endpoint는 무선 ADB라서 USB가 없거나 명시적으로 무선 복구가 필요한 경우의 2순위다. 무선 ADB가 `offline`이거나 timeout이면 stale endpoint로 보고 짧게 1회만 시도 후 중단하며 반복 connect 루프를 돌리지 않는다.
- 무선 ADB fresh endpoint 수집은 Tasker publish 결과를 무선 복구 안의 1순위 SOT로 본다. `prefer_tasker=true` 또는 `tasker_hint=refresh_wireless_debug_port` 뒤에는 먼저 Tasker result/latest Firebase 경로의 `created_at_ms`/`updated_at_ms`/`source`/`endpoint`를 확인하되, Tasker/Firebase endpoint는 USB 우선순위를 넘지 않는다.
- StoreBotTermux `AdbRecoveryAgent`의 `screen_text`, screenshot, OCR, `endpoint_not_found`는 Tasker publish 실패/보조 진단이지 Tasker 결과가 아니다. 최신 command 이후 Tasker result/latest가 갱신되지 않으면 `Tasker 미실행 또는 publish 경로 불일치`로 판정하고, 앱 OCR fallback보다 Tasker가 실제 쓰는 result path를 먼저 찾는다.
- 서버폰 ADB 복구 판정은 매번 새로 확인한다. StoreBotTermux ADB recovery는 `/packhelper/subphone/adb_wireless/latest` fresh endpoint와 실제 `adb devices`를 우선 신뢰하고, Tasker result/input_health는 보조 신호로 본다. `/packhelper/storebot_termux/heartbeat`가 낡으면 `dumpsys package` 버전과 `adb_wireless/latest`를 같이 확인해 stale writer/경로 혼선을 분리한다.
- 기존 Firebase endpoint/port는 틀릴 가능성이 큰 참고값이다. 연결 시도는 새 Tasker endpoint와 live heartbeat IP 조합을 짧은 timeout으로 병렬 검증하고, stale endpoint 연결 루프를 돌리지 않는다.
- 새 full session은 dispatcher 문맥 자체가 불안정할 때의 fallback이다. 일반적인 문맥 보호와 긴 읽기 외부 위임은 먼저 일회용 worker로 처리한다.
- hosted/public 업데이트 상태만으로 폰측 적용을 단정하지 않는다. 폰측 적용이 중요한 작업은 heartbeat, 설치 상태, worker/bundle 상태까지 확인한다.
- APK install 완료 보고는 `install result`, `dumpsys package`의 `versionName`/`versionCode`, `serial`/`model`, `lastUpdateTime` 없이는 하지 않는다. worker 단위는 `큐 등록`, `장치 확인`, `설치`, `패키지 검증`으로 작게 나누고 timeout/중간보고 기준을 둔다.
- 설치/검증 실패 보고는 APK 빌드·서명·패키지 문제와 ADB 연결·serial 선택 문제를 분리한다.
- 안전 경계는 그대로 유지한다. 카카오 hot path/답장 전송, 주문·결제·금융 원본 변경, 배민/쿠팡 실행, 영업 영향 live action, destructive write, 위험한 원격 조작은 앱별 safety flow와 명시 경계를 통과해야 한다.
- 일회용 worker routing, multi-project lane board, 모델/리소스 선택, 개인폰 fan-out 금지, 물리 worker 병행 lock/lane, 가상 worker fallback, safety boundary, 새 세션 fallback 기준은 이 문단과 `rules/workflow.txt`가 durable SOT다. 현재 큐와 임시 상태만 `AI_HANDOFF.md`/Wonmux `current_plan.md`에 둔다.

## Goal-mode 운영 기준
- 사용자가 `goal-mode`, `끝까지`, `항상 진행`, `목표 달성까지` 같은 목표형 진행을 선언하면 Codex는 먼저 명시 목표와 완료 기준을 잡고, 그 기준이 실제 충족될 때까지 이어간다.
- 여러 승인된 요구는 `A 또는 B` 중 하나를 골라 닫는 선택지가 아니다. 충돌 없는 항목은 모두 `now -> next` 실행 큐에 유지하고, 순서 의존 항목은 안전 게이트를 통과하는 순서로 끝까지 이어간다.
- 한 lane의 timeout/blocked는 전체 목표의 종료 조건이 아니다. 실패 원인을 기록한 뒤 다른 승인 lane과 read-only/준비 작업은 계속하고, 같은 위험 동작을 반복하지 않는 다음 안전 경로를 자동으로 시도한다.
- `blocked`는 해당 물리·권한·외부 조건에만 국소 적용한다. destructive, live-business, physical-device mutation은 계속 fail-closed로 두되, 안전하게 진행 가능한 나머지 범위를 숨기거나 멈추지 않는다.
- 98% 완료 상태에서 멈추지 않는다. 피할 수 있는 잔여 작업은 끝내고, 못 끝내는 경우에만 실제 blocker와 필요한 사용자/외부 조건을 적는다.
- 목표 진행 중 사용자가 다른 요청을 끼워 넣으면, 안전한 짧은 상태 확인/질문 답변은 즉시 처리하고 원래 목표로 복귀한다.
- 끼어든 요청이 길거나 위험하거나 active goal과 충돌하면 backlog로 남긴 뒤 active goal을 계속한다. 사용자가 명시적으로 `변경`, `중단`, `일시정지`를 말할 때만 목표를 바꾼다.
- 새 요청은 즉시 선점하지 말고 active goal과의 연관성, 긴급도, 안전성, 사용자 업무 영향, 파일 충돌, 외부 worker 상태로 분류한다. 분류 결과는 `now/in_progress`, `next`, `backlog`, `지속관리(watch/recurring)`, `blocked` 중 하나로 남기고, 지속관리 항목은 플랜이나 `AI_HANDOFF.md` 같은 추적 포인터에 계속 보이게 둔다.
- 사용자가 명시적으로 우선순위를 바꾸거나 긴급 live 문제가 생기면 순서를 조정한다. 새 요청이 현재 작업과 무관하면 backlog 또는 별도 항목으로 분리하고, 충돌하면 active goal 우선으로 정리한다.
- 보고는 완료 지향으로 쓴다: `완료/미완료`, 증거, blocker만 남긴다. 피할 수 있는 일을 `남은 일`로 포장하지 않는다.
- live ops에서도 안전 경계는 유지한다. hot path, 결제/주문/금융, destructive action은 앱별 safety flow를 통과하되, 통과 가능한 범위 안에서는 완료까지 계속 진행한다.
- 개인폰 Wonmux는 goal-mode에서도 경량 dispatcher다. 개인폰 병렬 작업, 무거운 읽기, 빌드, live 확인, 긴 검증은 금지하고 외부 실행 리소스에 짧은 lane/task 패킷으로 넘긴다.

## 사용자 결과 우선 절대 기준
- 코드는 사용자 workflow를 위해 존재한다. 모든 계획·설계·구현·운영 전에 `대상 사용자`, `job-to-be-done`, `현재 불편`, `사용자에게 보일 목표 결과`, `주요 흐름`, `edge/failure/recovery`, `접근성·조작성`, `설치·배포·실제 채택`을 먼저 정의한다.
- 설계는 내부 구조의 우아함이나 process PASS보다 사용자가 가장 단순하고 안정적으로 목적을 달성하는 방향을 우선한다. 불필요한 기능 설명, 개발자 용어, 기술 장치, 추가 단계로 사용자 부담을 늘리지 않는다.
- 사용자가 명시한 업무 규칙, 표현, 용어, 예외는 그대로 보존한다. 리뷰는 내부 취향보다 사용자에게 보이는 회귀, 끊긴 주요 workflow, 누락된 failure/recovery, 접근성·조작성 문제를 먼저 찾는다.
- 완료는 실제 사용자 경로가 처음부터 끝까지 사용 가능하고 UI·실기기·live artifact 증거가 있을 때만 인정한다. build, unit test, process, heartbeat, hosted 파일은 보조 증거이며, 아직 사용할 수 없으면 `PARTIAL/BLOCKED`로 보고한다.
- downstream의 설치, 첫 실행, 재부팅 후 실행, 라이선스·약관, 로그인·VPN, 방화벽·권한, 설치기 후속 화면, 배포·채택까지 예측해 총 작업량·시간·중단·영업 영향과 사용자 조치를 산정한다.
- 사용자 조치가 있으면 시작 보고에 `예상 총 승인 횟수와 현재 확인 가능한 최대치`, `예상 물리 방문 횟수`, `완료/남은 승인`, `한 방문에서 묶을 수 있는 승인`, `외부 상태에 따라 추가될 분기`를 먼저 적는다. 예견 가능한 승인을 하나씩 뒤늦게 알리지 않는다.
- downstream gate를 감사하기 전에는 `한 번만`, `마지막`, `더 이상 없음`이라고 말하지 않는다. 새 승인이 발견되면 계획 누락을 인정하고 총 승인·방문·시간을 다시 계산해 다음 방문 항목을 합친다.
- 진행·완료 보고는 `사용자가 얻는 결과와 사용자가 무엇을, 몇 번, 언제 해야 하는지`를 맨 앞에 쓰고 기술 증거를 뒤에 둔다.
- 안전한 remote/no-touch 경로를 우선하되 UAC, 보안 경고, 인증, 약관, 로그인, VPN, 권한을 우회하거나 사용자를 대신해 승인하지 않는다.

## 기록 원칙
- 프로젝트별 상세 설계안은 `PROJECT_DESIGN.md`를 표준 SOT로 둔다.
- 한 번에 전부 완성하지 않고, 코딩 작업마다 사용자 프롬프트, 확정 설계, 실제 구현 내용, 검증 증거로 점진 갱신한다.
- 문서만 읽어도 현재 구현과 거의 같은 수준으로 재구현 가능해야 한다.
- 목적/사용자 흐름/UI/입출력/원천 DB·캐시·외부 API 경로/프론트·백엔드·CLI·봇·worker 경로/권한/배포/검증 기준을 포함한다.
- 기능/UI/DB·입출력/worker·hook·template/live ops/배포 흐름 변경은 같은 작업 안에서 `PROJECT_DESIGN.md`를 갱신하거나 완료 보고에 미갱신 사유를 남긴다.
- 없는 프로젝트는 다음 코딩 작업 때 template 기반 skeleton을 만들고 확인된 부분부터 채운다.
- 외부 worker 지시에는 `PROJECT_DESIGN.md` 갱신 여부, 사용자 프롬프트 반영, 설계 확정 내용, 구현 경로, 검증 증거 항목을 포함한다.
- final gate에서 `check_project_design_update_gate.py` 또는 동등 확인을 쓴다. hook 연결 가능 환경이면 pre-commit 또는 Codex lifecycle hook에 연결한다.
- 사용자가 바로 이해해야 하는 내용은 짧게 한국어로 남긴다.
- Termux 화면과 작업 중 보고에는 `자연어 요약`만 남긴다. 코드 조각, 긴 명령, 로그 원문, diff는 사용자가 명시적으로 요청할 때만 보여준다.
- 도구 호출, Firebase 원문, 로그 키 목록, JSON 덤프, 터미널 실행 과정은 사용자에게 그대로 설명하지 않는다. 사용자가 필요한 것은 `진행중/완료/문제/다음 조치` 한국어 요약이다.
- 에이전트는 진행 보고를 `무엇을 했는지 / 왜 필요한지 / 다음에 무엇을 하는지` 중심의 짧은 문장으로 남긴다.
- 외부 리소스/worker가 관여한 보고와 인수인계에는 `사용 리소스: ...`와 필요한 경우 `virtual 사유: ...`를 결과 위주로 넣고, 내부 큐/로그 원문은 반복하지 않는다.
- 진행 보고에서 외부 worker 호출, 공장 PC/서버폰 사용, 개인 main 직접 처리, MCP 호출처럼 리소스가 바뀌거나 새 호출을 시작하면 먼저 `[리소스: ... / MCP: 사용-이름 또는 미사용-사유 / 모델: 모델명-적정성 / 사유: ...] 작업 요약`을 짧게 표시하고, 매 호출마다 같은 형식으로 갱신한다.
- 개인 main 진행 보고도 기본값은 위 형식을 그대로 쓴다. MCP를 쓰지 않았으면 `MCP: 미사용-사유`를 반드시 적고, 모델을 바꿨거나 외부 worker를 고르면 그 이유를 `모델:`과 `사유:`에 함께 적는다.
- 모델 표기는 `ChatGPT: <표시명>/<추론단계>`와 `Codex CLI: <실제 model id>/<reasoning_effort>`를 분리한다. 개인 메인·Matrix ChatGPT 사용과 factory/oneoff Codex CLI 실행을 서로의 사용 증거로 대체하지 않으며, AI 미호출 고정 스크립트는 `model-0`로 적는다.
- 필요 시 진행 보고에 `요청분류`와 `지속관리 상태`를 포함하고, 지속관리 항목은 작업 종료마다 갱신한다.
- 세션 진행 화면은 자유서술보다 체크리스트를 기본으로 쓴다.
- 각 항목은 `[구간] 상태 - 한줄요약` 또는 이에 준하는 형태로 원인 분석/설계/작업/검증/다음조치를 드러낸다.
- 사용자용 진행 보고에는 `ran`, raw command/log, tool-style status를 쓰지 않고, `구간 / 원인 / 작업 / 결과 / 다음` 중심의 한국어 한줄요약 체크리스트만 남긴다.
- 사용자용 출력 게이트: 모든 진행/완료 문장을 보내기 전 `사용자가 알아야 할 결과/위험/다음 조치인가`로 먼저 분류한다. 내부 실행 구조, 도구 상태, 차단 사유, 명령/로그 설명이면 자동으로 숨기거나 결과 중심 문장으로 바꾼다.
- 매 세션 현재 구간 하나는 `in_progress`로 표시하고, 긴 로그/명령 원문 대신 자연어 요약만 적는다.
- 사용자가 직접 해야 하는 일이 있으면 모호한 설명으로 끝내지 말고 `사용자 동작:`으로 실제 입력할 명령, 누를 버튼, 열 화면을 짧고 순서대로 적는다.
- 개인폰 Termux 음성채팅은 입력 확인용 낭독을 하지 않는다. `bv`/STT 입력은 조용히 텍스트화하고, TTS는 `brief`/`br`로 최종 브리핑·주의사항·다음 조치 같은 짧은 출력만 읽는다. 코드, 긴 로그, diff 원문은 사용자가 명시하지 않으면 음성 출력하지 않는다.
- 사용자가 방향, 설계, UX, 구조를 물을 때는 단순히 “알겠다”로 수용하지 않는다. 먼저 `왜 그렇게 판단하는지`, `내가 보는 더 나은 방향`, `현재 제안의 단점`을 짧게 말한 뒤 실행한다.
- 사용자가 `왜`, `의견`, `너 생각`, `맞는 방향`을 묻는 경우에는 구현보다 판단 근거를 우선 답한다. 현장 속도 때문에 실행이 급해 보여도, 설계 단계에서는 Codex 의견을 생략하지 않는다.
- 현재 작업 상태는 필요 시 `AI_HANDOFF.md`에 짧게 남긴다.
- 사용자가 `항상`, `앞으로`, `다음 세션도`, `기록`, `스킬`, `MD`처럼 장기 운영 기준을 말하면 이번 세션 답변으로 끝내지 말고 `AGENTS.md`, `CODEX_BRIEF.md`, `AI_HANDOFF.md`, 메모리 note 중 적절한 durable 위치에 짧게 남긴다.
- 코드 구조 변경은 `CODEMAP.txt`에 반영한다.
- 앱을 만든 이유, 사용자 결과, 절대 기준은 앱별 `APP_INTENT.md`에 짧게 남긴다.
- 배포 규칙, 협업 규칙, 공용 운영 기준은 이 `AGENTS.md`에 반영한다.
- 장기적으로 남길 가치가 없는 임시 메모는 규칙 문서에 넣지 않는다.
- 공용 md는 한 화면 안에 읽히게 유지하고, 긴 설명은 `rules/*`나 프로젝트 문서로 보낸다.
- 정리/인수인계/CODEMAP 동기화는 Codex `sync-codemap-md` 스킬을 우선 사용한다.

## 인수인계 기준
- 다음 사람이 바로 이어받을 수 있어야 한다.
- 최소 기록 항목:
- 무엇을 바꿨는지
- 왜 바꿨는지
- 어디까지 검증했는지
- 아직 남은 위험이 무엇인지
- APK를 전달했는지

## APK 빌드 & 전달 (Android 프로젝트)
```bash
# 빌드
./gradlew assembleDebug && ./gradlew --stop

# 사용자에게 전달 (필수!)
APP_NAME="프로젝트명"
VER=$(TZ=Asia/Seoul date +"%m%d_%H%M")
cp app/build/outputs/apk/debug/app-debug.apk /sdcard/Download/${APP_NAME}_${VER}.apk
termux-open /sdcard/Download/${APP_NAME}_${VER}.apk
```

- `./gradlew --stop` 필수 (데몬이 1.5GB 먹고 안 죽음)
- `termux-open`까지 해야 설치 화면이 뜸. 빌드만 하고 끝내지 말 것
- 서브폰에 설치한 작업도 개인폰 `/sdcard/Download`에 복사하고 `termux-open`으로 설치 화면을 같이 연다.
- 업데이트센터/자동업데이트 채널이 있는 앱은 직접 APK 전달과 별개로 `version.json` + `*_latest.bin` 공개 채널 배포까지 항상 완료한다.
- `build/` 디렉토리는 커밋 금지
- APK 전달은 `빌드 성공`만으로 끝난 것이 아니다. 사용자가 설치 화면을 실제로 봐야 완료다.

## 이미지/시안 파일 전달
- 사용자에게 직접 보여줄 PNG/JPG/WebP/HTML 등 전달 파일은 기본적으로 `/sdcard/Download/`에 둔다.
- `/root/.codex/generated_images/...` 같은 내부 생성 경로에만 두고 끝내지 않는다.
- 전달 직후 `termux-open`으로 실제 열어 사용자가 바로 볼 수 있게 한다.

## Android 배포 표준
- 기본 배포는 `debug APK` 기준으로 한다.
- 사용자가 별도 요청할 때만 `release APK`를 만든다.
- APK 이름은 `프로젝트명_MMdd_HHmm.apk`
- 버전 표기는 KST 기준 `MMdd.HHmm`
- `versionCode`는 epoch minutes 사용
- 빌드 후 APK 위치를 모르면 `find . -name "*.apk" -path "*/build/*"`로 찾는다.
- 빌드 후 Gradle 데몬은 반드시 종료한다.

## 보안 체크리스트 (Gemini 참고)
- API 키 하드코딩 금지 — Firebase 또는 환경변수에서 로드
- `.env`, credentials, SA키 커밋 금지
- SiteBot(PC) 포트: `127.0.0.1`만 (`0.0.0.0` 금지)
- SiteBot API: `X-API-Token` 인증 필수
- URL 검증: `http/https`만 허용 (`javascript:`, `data:` 차단)
- Firebase `/secrets` 경로 차단 확인
- KDS는 영업 중 업데이트 금지

## 코드 수정 시 주의
- `CODEMAP.txt` 있는 프로젝트는 반드시 읽고 영향 범위 확인
- Firebase 경로/필드명 변경 시 → 모든 소비자 프로젝트 확인
- 크로스 프로젝트 파이프라인 한쪽 변경 시 → 양쪽 확인
- 버전: KST 기준 `MMdd.HHmm` 형식
- UI 개편 시 한손 사용성, 실제 운영 동선, 지도/리스트 가시성 같은 사용자 맥락을 우선한다.
- 앱 목적, UI/동선 기준, 데이터 경계, 완료 기준이 바뀌면 해당 `APP_INTENT.md`도 같이 갱신한다.
- 의도 포인터 누락은 `python3 /root/my-first-project/scripts/sync_app_intent_pointers.py --check`로 확인한다.
- 테스트 스크립트가 깨져 있으면 앱 문제와 스크립트 문제를 분리해서 판단한다.

## 충돌 방지
- 같은 파일 동시 수정 금지 — 작업 전 `git status` 확인
- 다른 에이전트가 수정 중인 브랜치 강제 push 금지
- 확신 없으면 수정하지 말고 리포트만 남길 것
- 더러운 워크트리에서는 내가 만든 변경만 명확히 구분한다.
- 이미 있던 미커밋 변경은 최신 작업물로 취급한다. 마지막 커밋 기준 diff를 보고 예전 코드로 오판하거나 “무관/낡은 변경”처럼 표현하지 않는다.
- 현재 dirty 워크트리로 빌드한 APK는 현재 미커밋 변경 전체를 포함한다. 보고할 때 `이번 턴 수정`, `기존 미커밋 포함`, `빌드 포함 범위`를 분리한다.
- 사용자 변경으로 보이는 내용은 되돌리지 않는다.

## 검증 원칙
- push 전 최소 1회 검증은 필수다.
- Android는 가능하면 `빌드`, `기본 실행`, `필수 동작`, `APK 전달`까지 확인한다.
- 테스트 실패 시 `앱 문제`, `기기 환경 문제`, `스크립트 문제`를 구분해서 기록한다.
- 검증을 못 했으면 못 한 이유를 남긴다.
- ADB 실행과 ADB 기반 증거 수집은 기존 safety 기준대로 공장 PC 전용이다. 개인 main, virtual worker, serverphone bundle-runtime evidence로 대체하지 않는다.

## 커밋 규칙
- 메시지: 한국어
- `build/` 커밋 금지
- `.env`, credentials 커밋 금지
- push 전 검증 필수 (테스트/시뮬레이션)
- 커밋은 의미 단위로 나눈다.
- 다른 에이전트의 변경과 내 변경이 섞였으면 메시지나 기록으로 경계를 분명히 한다.
- Codex가 구현·문서·빌드·APK 전달을 맡은 작업은 커밋까지 완료 기준이다. 사용자가 명시적으로 보류하지 않으면 미커밋 상태로 끝내지 않는다.
- MCP 재구조화 관련 가드 수정/검증은 registry와 설치 MCP 후보의 분리 규칙을 함께 점검한다. `project_context_guard`에서 unknown MCP는 `available`로 처리하지 않으며, `installed_mcp`/`missing_required_mcp` 출력을 함께 확인한다.
- 커밋 전 `git status --short`로 수정/신규 파일을 확인하고, untracked 파일 누락 여부를 본다.
- 커밋 후 다시 `git status --short`와 `git log -1 --oneline`을 확인해 누락 커밋이 없는지 보고한다.
- 빌드 산출물, 비밀정보, 임시파일을 제외한다는 이유로 파일을 빠뜨릴 때는 빠뜨린 이유를 보고한다.

## 운영 우선순위
- 1순위: 사용자 업무에 직접 영향 주는 버그
- 2순위: 배포/로그/자동화처럼 운영 효율을 높이는 기반 정리
- 3순위: 디자인, 가독성, 품질 개선
- 4순위: 장기 구조 정리

## 공용 AI Ops 원칙
- C&I는 모든 프로젝트에 개입 가능한 공용 CLI/AI Ops 실행층이다. 오류/복구/비효율 패턴 개선은 안전 경계 안에서 자체 판단, 자체 복구, 문서 갱신, 빌드, 업데이트센터 업로드까지 이어질 수 있다.
- goal mode는 승인 대기 없이 상주 모니터링, 오류판정, 복구, self_fix를 계속 진행하는 운영 모드다.
- CLI/LLM 실행은 prompt envelope가 있어야 깨어난다. 이것은 지시 범위 제한이 아니라 런타임 트리거 한계이며, monitor/worker/앱/사용자/수동 enqueue 또는 상주 판단 루프가 증상과 목적을 prompt로 만들어 `/packhelper/codex_ops/requests`에 넣는다.
- 오류판정은 좁은 예외처리만 보지 않는다. 무응답, 큐 정체, heartbeat stale, 전송 실패, 데이터 불일치, 반복 사용자 수정, 속도 급락, 앱킬/권한/절전 문제까지 증상으로 본다.
- self_fix는 코드/설정/문서/배포 루프 교정까지 포함한다. 단, 금융 원본 변경, 배민/쿠팡 실행, 실시간 주문 확정처럼 위험한 동작은 앱별 기존 안전 경계를 반드시 통과한다.
- 공용 실행자는 `codex_ops`를 쓰되 domain envelope, session, result 경로는 앱별로 분리한다.
- StoreBotTermux 통합본/카카오톡 쪽 CLI는 카톡 답변 수행자만이 아니라 PosDelay처럼 내부 복구/개선 작업 실행자 역할도 맡는다. 답변 큐와 내부 ops 큐는 분리하고, 사용자에게 보이는 것은 `kakao_reply`만이며 `report`, `log_only`, `self_heal`, `self_fix`는 내부 처리로 남긴다.
- 카카오 운영방 hot path는 막지 않는다. 무거운 분석/코딩/배포 self_fix는 monitor/worker가 증상과 요청을 `codex_ops`에 넣어 백그라운드로 처리하고, 지연이 사용자에게 보일 때만 먼저 지연/복구 문구를 보낸다.
- 상주 앱과 사용자 동작형 앱을 구분한다. BankTotal처럼 사용자가 열 때 heartbeat가 찍히는 앱은 비활성 자체를 장애로 보지 않고, 사용자 동작 실패/크래시/명시 오류만 self_fix 후보로 올린다.
- 상세 prompt 주입 계약은 `rules/ai_ops_prompt_contract.txt`를 본다.

## 금지 사항
- 근거 없이 Firebase 구조 변경
- build 산출물 커밋
- 비밀정보 커밋
- 영업 중 KDS 업데이트
- 사용자가 모르는 강제 리셋, 강제 덮어쓰기, 강제 push
