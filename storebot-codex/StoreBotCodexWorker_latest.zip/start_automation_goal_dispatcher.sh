#!/usr/bin/env bash
set -euo pipefail

PROJECT_ROOT="${AUTOMATION_PROJECT_ROOT:-/root/my-first-project}"
ADAPTER="$PROJECT_ROOT/scripts/automation_goal_dispatch_firebase.py"
POLICY="${AUTOMATION_GOAL_POLICY:-$PROJECT_ROOT/config/automation_goal_dispatch_policy.json}"
RUNTIME_CONFIG="${AUTOMATION_GOAL_RUNTIME_CONFIG:-$PROJECT_ROOT/config/automation_goal_runtime.json}"
BUNDLE_STATE_FILE="${AUTOMATION_GOAL_BUNDLE_STATE_FILE:-$PROJECT_ROOT/.storebot_codex_bundle_state.json}"
DEPLOYMENT_LOCK_FILE="${AUTOMATION_GOAL_DEPLOYMENT_LOCK_FILE:-$PROJECT_ROOT/.storebot_codex_deploy.lock}"
RUNTIME_DIR="${AUTOMATION_GOAL_RUNTIME_DIR:-/root/tmp/automation_goal_dispatcher}"
LOG_FILE="${AUTOMATION_GOAL_LOG_FILE:-$RUNTIME_DIR/dispatcher.log}"
LOCK_FILE="${AUTOMATION_GOAL_LOCK_FILE:-$RUNTIME_DIR/dispatcher.lock}"
MAX_LOG_BYTES="${AUTOMATION_GOAL_MAX_LOG_BYTES:-262144}"
ADAPTER_TIMEOUT_SEC="${AUTOMATION_GOAL_ADAPTER_TIMEOUT_SEC:-180}"

mkdir -p "$RUNTIME_DIR"
chmod 700 "$RUNTIME_DIR" 2>/dev/null || true

rotate_log() {
  local size=0
  if [ -f "$LOG_FILE" ]; then
    size="$(wc -c < "$LOG_FILE" 2>/dev/null || printf '0')"
  fi
  if [ "$size" -ge "$MAX_LOG_BYTES" ]; then
    mv -f "$LOG_FILE" "$LOG_FILE.1"
  fi
}

log_status() {
  rotate_log
  printf '%s status=%s\n' "$(date -u +%Y-%m-%dT%H:%M:%SZ)" "$1" >> "$LOG_FILE"
  chmod 600 "$LOG_FILE" 2>/dev/null || true
}

if [ ! -r "$RUNTIME_CONFIG" ]; then
  log_status "runtime_config_missing"
  exit 66
fi
set +e
runtime_values="$(python3 - "$RUNTIME_CONFIG" <<'PY'
import json
import sys

with open(sys.argv[1], encoding="utf-8") as handle:
    value = json.load(handle)
expected = {
    "schema_version", "config_version", "goal_id", "owner_id", "apply_enabled",
    "kill_switch", "watch_interval_seconds", "backoff_initial_seconds",
    "backoff_max_seconds", "safety_contract",
}
if not isinstance(value, dict) or set(value) != expected:
    raise SystemExit(2)
if value.get("schema_version") != 1 or value.get("config_version") != "automation-goal-runtime-v1":
    raise SystemExit(2)
safety = value.get("safety_contract")
if not isinstance(safety, dict) or set(safety) != {
    "seeded_task_profiles", "reducer_fail_closed_risk_flags", "live_actions_allowed",
    "destructive_actions_allowed", "physical_actions_allowed",
}:
    raise SystemExit(2)
if safety.get("seeded_task_profiles") != ["read_only"]:
    raise SystemExit(2)
if safety.get("reducer_fail_closed_risk_flags") != [
    "live", "live_business", "destructive", "physical", "physical_device"
]:
    raise SystemExit(2)
if any(safety.get(key) is not False for key in (
    "live_actions_allowed", "destructive_actions_allowed", "physical_actions_allowed"
)):
    raise SystemExit(2)
if not isinstance(value.get("apply_enabled"), bool) or not isinstance(value.get("kill_switch"), bool):
    raise SystemExit(2)
for key in ("goal_id", "owner_id"):
    if not isinstance(value.get(key), str) or not value[key]:
        raise SystemExit(2)
for key in ("watch_interval_seconds", "backoff_initial_seconds", "backoff_max_seconds"):
    if not isinstance(value.get(key), int) or isinstance(value[key], bool) or value[key] < 1:
        raise SystemExit(2)
print(value["goal_id"])
print(value["owner_id"])
print("1" if value["apply_enabled"] else "0")
print("1" if value["kill_switch"] else "0")
print(value["watch_interval_seconds"])
print(value["backoff_initial_seconds"])
print(value["backoff_max_seconds"])
PY
)"
runtime_code=$?
set -e
if [ "$runtime_code" -ne 0 ]; then
  log_status "runtime_config_invalid"
  exit 65
fi
mapfile -t runtime_rows <<< "$runtime_values"
if [ "${#runtime_rows[@]}" -ne 7 ]; then
  log_status "runtime_config_invalid"
  exit 65
fi

GOAL_ID="${1:-${AUTOMATION_GOAL_ID:-${runtime_rows[0]}}}"
OWNER_ID="${2:-${AUTOMATION_GOAL_OWNER_ID:-${runtime_rows[1]}}}"
CONFIG_APPLY="${runtime_rows[2]}"
CONFIG_KILL_SWITCH="${runtime_rows[3]}"
WATCH_INTERVAL_SEC="${AUTOMATION_GOAL_WATCH_INTERVAL_SEC:-${runtime_rows[4]}}"
BACKOFF_INITIAL_SEC="${AUTOMATION_GOAL_BACKOFF_INITIAL_SEC:-${runtime_rows[5]}}"
BACKOFF_MAX_SEC="${AUTOMATION_GOAL_BACKOFF_MAX_SEC:-${runtime_rows[6]}}"

case "${AUTOMATION_GOAL_KILL_SWITCH:-$CONFIG_KILL_SWITCH}" in
  1|true|TRUE|yes|YES)
    log_status "kill_switch"
    exit 0
    ;;
  0|false|FALSE|no|NO) ;;
  *) log_status "runtime_config_invalid"; exit 65 ;;
esac

if [ ! -r "$ADAPTER" ] || [ ! -r "$POLICY" ]; then
  log_status "runtime_missing"
  exit 66
fi

if [[ ! "$ADAPTER_TIMEOUT_SEC" =~ ^[0-9]+$ ]] || [ "$ADAPTER_TIMEOUT_SEC" -lt 1 ] || [ "$ADAPTER_TIMEOUT_SEC" -gt 180 ]; then
  log_status "runtime_config_invalid"
  exit 65
fi

if [ "${AUTOMATION_GOAL_SINGLETON_LOCK_INHERITED:-0}" = "1" ]; then
  if ! flock -n 9 2>/dev/null; then
    log_status "inherited_lock_invalid"
    exit 73
  fi
else
  exec 9>"$LOCK_FILE"
  if ! flock -n 9; then
    log_status "already_running"
    exit 0
  fi
fi

APPLY_VALUE="${AUTOMATION_GOAL_DISPATCH_APPLY:-$CONFIG_APPLY}"
case "$APPLY_VALUE" in
  1|true|TRUE|yes|YES) APPLY_ENABLED=1 ;;
  0|false|FALSE|no|NO) APPLY_ENABLED=0 ;;
  *) log_status "runtime_config_invalid"; exit 65 ;;
esac

# A lease instance identifies this exact wrapper process. It is generated once
# and reused by bounded adapter turns and a bundle-triggered self-exec.
if [ -n "${AUTOMATION_GOAL_PROCESS_INSTANCE_ID:-}" ]; then
  INSTANCE_ID="$AUTOMATION_GOAL_PROCESS_INSTANCE_ID"
else
  INSTANCE_ID="$(python3 - "$OWNER_ID" "$$" <<'PY'
import hashlib
import sys
import time

owner = sys.argv[1]
pid = sys.argv[2]
nonce = time.time_ns()
digest = hashlib.sha256(f"{owner}:{pid}:{nonce}".encode("utf-8")).hexdigest()[:20]
print(f"{owner}.pid{pid}.{digest}")
PY
)"
fi
if [[ ! "$INSTANCE_ID" =~ ^[A-Za-z0-9._:-]+$ ]] || [ "$INSTANCE_ID" = "$OWNER_ID" ]; then
  log_status "instance_id_invalid"
  exit 65
fi

backoff="$BACKOFF_INITIAL_SEC"
increase_backoff() {
  if [ "$backoff" -lt "$BACKOFF_MAX_SEC" ]; then
    backoff=$((backoff * 2))
    if [ "$backoff" -gt "$BACKOFF_MAX_SEC" ]; then
      backoff="$BACKOFF_MAX_SEC"
    fi
  fi
}

refresh_bundle_attestation() {
  local attestation_values attestation_code
  set +e
  attestation_values="$(python3 - "$BUNDLE_STATE_FILE" "$PROJECT_ROOT" <<'PY'
import hashlib
import json
from pathlib import Path
import re
import sys

try:
    with open(sys.argv[1], encoding="utf-8") as handle:
        value = json.load(handle)
except (OSError, ValueError):
    raise SystemExit(2)
if not isinstance(value, dict):
    raise SystemExit(2)
if value.get("schema_version") != 2:
    raise SystemExit(3)
status = value.get("status")
if status not in {"applied", "native_sync", "verified_current"}:
    raise SystemExit(3)
if "sha256" in value:
    raise SystemExit(4)
bundle_sha256 = value.get("bundle_sha256")
if not isinstance(bundle_sha256, str) or re.fullmatch(r"[0-9a-f]{64}", bundle_sha256) is None:
    raise SystemExit(4)
source_revision = value.get("source_revision")
code_revision = value.get("code_revision")
if source_revision != code_revision or not isinstance(source_revision, str):
    raise SystemExit(5)
if re.fullmatch(r"[A-Za-z0-9._:-]+", source_revision) is None:
    raise SystemExit(5)
expected_paths = {
    "scripts/automation_goal_dispatcher.py",
    "scripts/automation_goal_dispatch_firebase.py",
    "config/automation_goal_dispatch_policy.json",
    "config/automation_goal_runtime.json",
    "subphone/start_automation_goal_dispatcher.sh",
}
runtime_files = value.get("automation_runtime_files")
if not isinstance(runtime_files, dict) or set(runtime_files) != expected_paths:
    raise SystemExit(6)
root = Path(sys.argv[2])
for relative_path in sorted(expected_paths):
    expected_hash = runtime_files.get(relative_path)
    if not isinstance(expected_hash, str) or re.fullmatch(r"[0-9a-f]{64}", expected_hash) is None:
        raise SystemExit(6)
    try:
        actual_hash = hashlib.sha256((root / relative_path).read_bytes()).hexdigest()
    except OSError:
        raise SystemExit(6)
    if actual_hash != expected_hash:
        raise SystemExit(6)
print(source_revision)
print(bundle_sha256)
PY
)"
  attestation_code=$?
  set -e
  if [ "$attestation_code" -ne 0 ]; then
    return 1
  fi
  mapfile -t attestation_rows <<< "$attestation_values"
  if [ "${#attestation_rows[@]}" -ne 2 ]; then
    return 1
  fi
  WORKER_REVISION="${attestation_rows[0]}"
  REQUIRED_WORKER_BUNDLE_SHA256="${attestation_rows[1]}"
  adapter_args=(
    "$ADAPTER"
    --goal-id "$GOAL_ID"
    --owner-id "$OWNER_ID"
    --instance-id "$INSTANCE_ID"
    --worker-revision "$WORKER_REVISION"
    --required-worker-bundle-sha256 "$REQUIRED_WORKER_BUNDLE_SHA256"
    --policy "$POLICY"
  )
  if [ "$APPLY_ENABLED" -eq 1 ]; then
    adapter_args+=(--apply)
  fi
  return 0
}

run_adapter() {
  output_file="$(mktemp "$RUNTIME_DIR/adapter.XXXXXX")"
  chmod 600 "$output_file" 2>/dev/null || true
  set +e
  timeout --signal=TERM --kill-after=5 "$ADAPTER_TIMEOUT_SEC" \
    python3 "${adapter_args[@]}" "$@" > "$output_file" 2>/dev/null
  adapter_code=$?
  set -e

  adapter_status="$(python3 - "$output_file" <<'PY' 2>/dev/null || true
import json
import sys

status = ""
with open(sys.argv[1], encoding="utf-8", errors="replace") as handle:
    for line in handle:
        try:
            value = json.loads(line)
        except (TypeError, ValueError):
            continue
        candidate = value.get("status") if isinstance(value, dict) else None
        if isinstance(candidate, str):
            status = candidate
print(status)
PY
)"
  rm -f "$output_file"
}

exec 8>"$DEPLOYMENT_LOCK_FILE"
OBSERVED_BUNDLE_SHA256=""

while :; do
  if ! flock -s -n 8; then
    log_status "deployment_lock_retry"
    sleep "$backoff"
    increase_backoff
    continue
  fi
  if ! refresh_bundle_attestation; then
    flock -u 8
    log_status "bundle_attestation_retry"
    sleep "$backoff"
    increase_backoff
    continue
  fi
  if [ -n "$OBSERVED_BUNDLE_SHA256" ] && [ "$OBSERVED_BUNDLE_SHA256" != "$REQUIRED_WORKER_BUNDLE_SHA256" ]; then
    flock -u 8
    log_status "bundle_changed_reload"
    exec env \
      AUTOMATION_GOAL_PROCESS_INSTANCE_ID="$INSTANCE_ID" \
      AUTOMATION_GOAL_SINGLETON_LOCK_INHERITED=1 \
      "$PROJECT_ROOT/subphone/start_automation_goal_dispatcher.sh" "$@"
  fi
  OBSERVED_BUNDLE_SHA256="$REQUIRED_WORKER_BUNDLE_SHA256"
  # Validate one state snapshot and run exactly one adapter turn while holding
  # the shared deployment lock. Never keep the deployer blocked during sleep.
  run_adapter --mode once --max-iterations 1
  flock -u 8
  if [ "$adapter_status" = "goal_missing" ]; then
    log_status "goal_missing_retry"
    sleep "$backoff"
    increase_backoff
  elif [ "$adapter_code" -ne 0 ]; then
    log_status "adapter_probe_exit_${adapter_code}"
    sleep "$backoff"
    increase_backoff
  else
    log_status "dispatch_once_complete"
    backoff="$BACKOFF_INITIAL_SEC"
    sleep "$WATCH_INTERVAL_SEC"
  fi
done
