<!-- source: /root/SiteBot/APP_INTENT.md -->
# SiteBot APP_INTENT.md

## 만든 이유
- PC 브라우저 자동화를 한곳에서 관리해 PosDelay, OrderHelper, StoreBotTermux의 PC 의존 상태 확인과 실행 보조를 안정적으로 처리한다.

## 사용자 결과
- 사이트 조작은 중복 실행되거나 잘못된 탭에 가면 안 된다.
- 브라우저 상태, DOM, screenshot 증거는 공장 PC Edge 기준으로 확인한다.
- SFA 주문현황 파일 감지와 분석 요청은 PC에서 처리하고, 폰 앱은 상태와 결과만 본다.

## 절대 기준
- SiteBot API는 로컬/내부 제어 경로다. `127.0.0.1`만 허용하고 `X-API-Token` 없이는 실행 경로를 열지 않는다.
- URL은 `http/https`만 허용하고 `javascript:` / `data:` 는 차단한다.
- 배민/쿠팡/요기요/땡겨요 실제 조작은 명령 큐, token, 브리지 연결, 플랫폼별 안전 경계를 통과해야 한다.
- 외부 사이트 live action, 주문/발주, destructive write는 별도 safety flow와 명시 승인 없이는 금지한다.
- SFA 파일 스캔/분석 실행자는 PC/SiteBot이다. OrderHelper가 품목/단위/실발주 원본을 자동 확정하지 않는다.

## UI/동선 기준
- 수동 확인이 필요하면 viewer나 로그로 원인을 볼 수 있어야 한다.
- 자동화 실패는 조용히 묻히지 않고 `/monitor/main_pc/*` 상태와 alert에 남아야 한다.
- UI/웹 검증은 Playwright, BrowserStack, Browserbase, 또는 공장 PC Edge evidence로 잡는다.

## 데이터/경계 기준
- 주요 경로는 `/sitebot/cmd_queue`, `/sitebot/cmd_result`, `/sitebot/heartbeat/main_pc`, `/monitor/main_pc/*`다.
- read-only 조회가 필요하면 Firebase read-only 경로와 공장 PC 브라우저 증거를 먼저 본다.
- PackHelper, StoreBot server, GateEngine, Excel, SFA 분석은 `main_auto.pyw`가 PC 프로세스로 관리한다.
- `main_auto.pyw`는 시작 시 `MainPC_Watchdog` 작업스케줄러를 best-effort로 등록/갱신해 프로세스 사망 또는 heartbeat stale 뒤 OS 레벨 재기동을 시도한다.
- watchdog은 `/monitor/main_pc/watchdog_last`에 마지막 판정과 재시작 시도 상태를 남겨 PC 절전/스케줄러/프로세스 문제를 구분한다.
- code_version 포인터가 현재 HEAD의 조상인 stale 값이면 이미 만족한 배포로 보고 pull/restart 루프를 만들지 않는다.
- 자동 git 갱신은 로컬 변경이 없을 때 `ff-only`로만 적용하고, dirty repo는 보존한 채 중단한다.
- PosDelay PC 매크로 복구는 `/monitor/main_pc/cmd=restart_posdelay_pc`로 repo 갱신과 `mate_monitor.pyw` 재시작까지만 수행한다.
- `/monitor/main_pc/cmd` 소비는 전용 원격명령 루프가 맡아 heartbeat가 PosDelay/git 복구 작업에 묶이지 않게 한다.
- API token, 포트, 브라우저 확장 host permission을 바꾸면 소비자 프로젝트까지 확인한다.

## C&I / AI Ops 경계
- C&I는 PC heartbeat stale, bridge disconnect, command timeout, SFA request 정체, 자동 pull/restart 실패를 self_fix 후보로 올린다.
- 자동 복구는 PC 스크립트/설정/문서/code_version 보정과 안전한 재시작 명령 후보 생성까지 허용한다.
- 실제 사장님 페이지 조작은 기존 SiteBot 명령 큐와 token, 플랫폼별 안전 경계를 통과해야 한다.
- CLI/LLM은 prompt envelope가 있어야 깨어난다. monitor/worker/사용자/수동 enqueue 또는 상주 판단 루프가 prompt를 주입하며, 이것은 C&I 판단 권한 제한이 아니다.

## 수정 전 질문
- 이 변경이 PC 자동화 정체를 줄이는가.
- 외부 노출, 인증, 사이트 직접 조작 위험이 늘지 않는가.
- OrderHelper/PosDelay/StoreBot 소비 경로와 의미가 유지되는가.

## 완료 기준
- 검증: 로컬 API, WebSocket bridge, Firebase queue/result, main_pc heartbeat, browser/DOM/screenshot evidence.
- 전달: PC 코드 변경 시 git push, code_version 반영, 필요 시 PC pull/restart 확인.
- 남은 위험: 브라우저/사이트 DOM 변경, PC 절전, 확장 연결 끊김, 외부 사이트 live boundary 오판.
