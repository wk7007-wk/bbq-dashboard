#!/data/data/com.sbotux/files/usr/bin/bash
set -euo pipefail

export PATH="/data/data/com.sbotux/files/usr/bin:/data/data/com.sbotux/files/usr/bin/applets:/system/bin:/system/xbin:$PATH"

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
SECURE_CA_ENV_LOADER="${SECURE_CA_ENV_LOADER:-$SCRIPT_DIR/secure_ca_env.sh}"
if [ ! -r "$SECURE_CA_ENV_LOADER" ]; then
  SECURE_CA_ENV_LOADER="$SCRIPT_DIR/../scripts/secure_ca_env.sh"
fi
STOREBOT_CA_ENV_FILE="${STOREBOT_CA_ENV_FILE:-$HOME/.config/wonmux/ca-live.env}"
if [ ! -r "$SECURE_CA_ENV_LOADER" ]; then
  echo "secure CA env loader not found: $SECURE_CA_ENV_LOADER" >&2
  exit 66
fi
# shellcheck source=scripts/secure_ca_env.sh
source "$SECURE_CA_ENV_LOADER"
wonmux_load_secure_ca_env "$STOREBOT_CA_ENV_FILE" "${STOREBOT_CA_ENV_REQUIRED:-0}"

proot-distro login debian -- bash -lc '
set -euo pipefail
export PATH="$HOME/.local/bin:$HOME/.codex/bin:/usr/local/bin:/usr/bin:/bin:$PATH"
SRC="/sdcard/Download/storebot_codex_worker"
if [ ! -d "$SRC" ]; then
  SRC="/storage/emulated/0/Download/storebot_codex_worker"
fi
mkdir -p /root/my-first-project/scripts /root/my-first-project/subphone /root/StoreBot/bot/logs /root/storebot-codex-workspace
if [ -d "$SRC" ]; then
  cp "$SRC/STOREBOT_CODEX_WORKER.md" /root/my-first-project/STOREBOT_CODEX_WORKER.md
  cp "$SRC/storebot_codex_worker.py" /root/my-first-project/scripts/storebot_codex_worker.py
  cp "$SRC/storebot_codex_replay_chat.py" /root/my-first-project/scripts/storebot_codex_replay_chat.py 2>/dev/null || true
  cp "$SRC/secure_ca_env.sh" /root/my-first-project/scripts/secure_ca_env.sh 2>/dev/null || true
  cp "$SRC/storebot_ca_log.py" /root/my-first-project/scripts/storebot_ca_log.py 2>/dev/null || true
  cp "$SRC/manage_storebot_ca_activation.py" /root/my-first-project/scripts/manage_storebot_ca_activation.py 2>/dev/null || true
  cp "$SRC/start_storebot_codex_worker.sh" /root/my-first-project/subphone/start_storebot_codex_worker.sh
  cp "$SRC/STOREBOT_CODEX_BRIDGE.md" /root/my-first-project/subphone/STOREBOT_CODEX_BRIDGE.md
  cp "$SRC/launch_storebot_codex_background.sh" /root/my-first-project/subphone/launch_storebot_codex_background.sh 2>/dev/null || true
  cp "$SRC/watch_storebot_codex_worker.sh" /root/my-first-project/subphone/watch_storebot_codex_worker.sh 2>/dev/null || true
  cp "$SRC/setup_storebot_codex_autostart.sh" /root/my-first-project/subphone/setup_storebot_codex_autostart.sh 2>/dev/null || true
  if [ -f "$SRC/skills/storebot-kakao-reply/SKILL.md" ]; then
    mkdir -p /root/my-first-project/.agents/skills/storebot-kakao-reply /root/.agents/skills/storebot-kakao-reply
    cp "$SRC/skills/storebot-kakao-reply/SKILL.md" /root/my-first-project/.agents/skills/storebot-kakao-reply/SKILL.md
    cp "$SRC/skills/storebot-kakao-reply/SKILL.md" /root/.agents/skills/storebot-kakao-reply/SKILL.md
  fi
  chmod +x /root/my-first-project/scripts/storebot_codex_worker.py /root/my-first-project/scripts/storebot_codex_replay_chat.py /root/my-first-project/scripts/storebot_ca_log.py /root/my-first-project/scripts/manage_storebot_ca_activation.py /root/my-first-project/subphone/start_storebot_codex_worker.sh /root/my-first-project/subphone/watch_storebot_codex_worker.sh 2>/dev/null || true
fi
cd /root/my-first-project
bash subphone/start_storebot_codex_worker.sh
'
