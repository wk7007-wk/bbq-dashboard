#!/system/bin/sh
if [ -z "${AI_OPS_BASH_REEXEC:-}" ]; then
  for candidate in "${STOREBOT_TERMUX_DATA_DIR:-}" /data/data/com.sbotux /data/data/com.termux; do
    [ -n "$candidate" ] || continue
    if [ -x "$candidate/files/usr/bin/bash" ]; then
      export STOREBOT_TERMUX_DATA_DIR="$candidate"
      export AI_OPS_BASH_REEXEC=1
      exec "$candidate/files/usr/bin/bash" "$0" "$@"
    fi
  done
fi
set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
resolve_termux_data_dir() {
  if [ -n "${STOREBOT_TERMUX_DATA_DIR:-}" ] && [ -x "$STOREBOT_TERMUX_DATA_DIR/files/usr/bin/bash" ]; then
    printf '%s\n' "$STOREBOT_TERMUX_DATA_DIR"
    return 0
  fi
  for candidate in /data/data/com.sbotux /data/data/com.termux; do
    if [ -x "$candidate/files/usr/bin/bash" ]; then
      printf '%s\n' "$candidate"
      return 0
    fi
  done
  printf '%s\n' "/data/data/com.sbotux"
}

APP_DATA_DIR="$(resolve_termux_data_dir)"
APP_PREFIX="$APP_DATA_DIR/files/usr"
export PREFIX="${PREFIX:-$APP_PREFIX}"
export PATH="$APP_PREFIX/bin:$APP_PREFIX/bin/applets:/system/bin:/system/xbin:$PATH"

SECURE_CA_ENV_LOADER="${SECURE_CA_ENV_LOADER:-$SCRIPT_DIR/secure_ca_env.sh}"
if [ ! -r "$SECURE_CA_ENV_LOADER" ]; then
  SECURE_CA_ENV_LOADER="$SCRIPT_DIR/../scripts/secure_ca_env.sh"
fi
AI_OPS_CA_ENV_FILE="${AI_OPS_CA_ENV_FILE:-$APP_DATA_DIR/files/home/.config/wonmux/ca-live.env}"
if [ ! -r "$SECURE_CA_ENV_LOADER" ]; then
  echo "secure CA env loader not found: $SECURE_CA_ENV_LOADER" >&2
  exit 66
fi
# shellcheck source=scripts/secure_ca_env.sh
source "$SECURE_CA_ENV_LOADER"
wonmux_load_secure_ca_env "$AI_OPS_CA_ENV_FILE" "${AI_OPS_CA_ENV_REQUIRED:-0}"

ROOT="${AI_OPS_ROOT:-/root/my-first-project}"
if [ "$APP_DATA_DIR" = "/data/data/com.sbotux" ]; then
  DEFAULT_MONITOR_LOG_DIR="/sdcard/Download/ai_ops_monitor_sbotux"
  DEFAULT_MONITOR_NODE="subphone_sbotux_ai_ops_monitor"
  DEFAULT_MONITOR_BASE_PATH="/packhelper/ai_ops_monitor_sbotux_v2"
  DEFAULT_MONITOR_INTERVAL_SEC="60"
else
  DEFAULT_MONITOR_LOG_DIR="/sdcard/Download/ai_ops_monitor"
  DEFAULT_MONITOR_NODE="subphone_ai_ops_monitor"
  DEFAULT_MONITOR_BASE_PATH="/packhelper/ai_ops_monitor_v2"
  DEFAULT_MONITOR_INTERVAL_SEC="300"
fi
LOG_DIR="${AI_OPS_MONITOR_LOG_DIR:-$DEFAULT_MONITOR_LOG_DIR}"
mkdir -p "$LOG_DIR"
LOCK_BASE_DIR="${AI_OPS_MONITOR_LOCK_BASE_DIR:-$LOG_DIR}"
LOCK_DIR="${AI_OPS_MONITOR_LOCK_DIR:-$LOCK_BASE_DIR/ai_ops_monitor.lock}"
export AI_OPS_MONITOR_LOG_DIR="$LOG_DIR"
export AI_OPS_MONITOR_LOCK_BASE_DIR="$LOCK_BASE_DIR"
export AI_OPS_MONITOR_LOCK_DIR="$LOCK_DIR"
export AI_OPS_MONITOR_NODE="${AI_OPS_MONITOR_NODE:-$DEFAULT_MONITOR_NODE}"
export AI_OPS_BASE_PATH="${AI_OPS_BASE_PATH:-$DEFAULT_MONITOR_BASE_PATH}"
export AI_OPS_MONITOR_INTERVAL_SEC="${AI_OPS_MONITOR_INTERVAL_SEC:-$DEFAULT_MONITOR_INTERVAL_SEC}"
# The repackaged server-phone runtime owns the generic project shadow lane.
# Keep it projection-only by default and pass proot-visible identity/registry
# paths explicitly; the projector itself remains disabled outside this launcher.
if [ "$APP_DATA_DIR" = "/data/data/com.sbotux" ]; then
  export PROJECT_CA_PROJECTION_ENABLED="${PROJECT_CA_PROJECTION_ENABLED:-1}"
  export PROJECT_CA_LIVE_SEND_ENABLED="${PROJECT_CA_LIVE_SEND_ENABLED:-0}"
  export PROJECT_CA_KILL_SWITCH="${PROJECT_CA_KILL_SWITCH:-0}"
  export PROJECT_CA_IDENTITY_KEY_FILE="${PROJECT_CA_IDENTITY_KEY_FILE:-/root/.config/wonmux/project-ca.identity}"
  export PROJECT_CA_IDENTITY_DERIVE_FROM_STOREBOT="${PROJECT_CA_IDENTITY_DERIVE_FROM_STOREBOT:-1}"
  export PROJECT_CA_REGISTRY_PATH="${PROJECT_CA_REGISTRY_PATH:-/root/my-first-project/config/telegram_project_ca_registry.json}"
fi
PROOT_ROOTFS_DIR="${AI_OPS_PROOT_ROOTFS_DIR:-$PREFIX/var/lib/proot-distro/installed-rootfs}"
DISTRO="${AI_OPS_DISTRO:-${STOREBOT_CODEX_DISTRO:-}}"
mkdir -p "$LOCK_BASE_DIR" 2>/dev/null || true

CA_RUNTIME_ENV_KEYS=(
  POSDELAY_CA_PROJECTION_ENABLED
  POSDELAY_CA_LIVE_SEND_ENABLED
  POSDELAY_CA_FACTORY_SELF_FIX_ENABLED
  POSDELAY_CA_KILL_SWITCH
  POSDELAY_CA_IDENTITY_KEY_FILE
  POSDELAY_CA_MODULE_PATH
  POSDELAY_CA_MODULE_SHA256
  STOREBOT_CA_PROJECTION_ENABLED
  STOREBOT_CA_LIVE_SEND_ENABLED
  STOREBOT_CA_FACTORY_SELF_FIX_ENABLED
  STOREBOT_CA_SCHEDULE_RECOVERY_ENABLED
  STOREBOT_CA_KILL_SWITCH
  STOREBOT_CA_IDENTITY_KEY_FILE
  STOREBOT_CA_MODULE_PATH
  STOREBOT_CA_MODULE_SHA256
  STOREBOT_TELEGRAM_BACKPLANE_DRY_RUN
  STOREBOT_TELEGRAM_BACKPLANE_KILL_SWITCH
  STOREBOT_TELEGRAM_BACKPLANE_IDENTITY_KEY_FILE
  PROJECT_CA_PROJECTION_ENABLED
  PROJECT_CA_LIVE_SEND_ENABLED
  PROJECT_CA_KILL_SWITCH
  PROJECT_CA_IDENTITY_KEY_FILE
  PROJECT_CA_IDENTITY_DERIVE_FROM_STOREBOT
  PROJECT_CA_REGISTRY_PATH
)
CA_RUNTIME_ENV_ARGS=()
for ca_key in "${CA_RUNTIME_ENV_KEYS[@]}"; do
  if [[ -v "$ca_key" ]]; then
    CA_RUNTIME_ENV_ARGS+=("$ca_key=${!ca_key}")
  fi
done

resolve_distro() {
  if [ -n "$DISTRO" ] && [ -d "$PROOT_ROOTFS_DIR/$DISTRO" ]; then
    return 0
  fi
  if [ -d "$PROOT_ROOTFS_DIR/debian" ]; then
    DISTRO="debian"
    return 0
  fi
  if [ -d "$PROOT_ROOTFS_DIR/ubuntu" ]; then
    DISTRO="ubuntu"
    return 0
  fi
  first="$(find "$PROOT_ROOTFS_DIR" -mindepth 1 -maxdepth 1 -type d -print 2>/dev/null | head -n 1)"
  if [ -n "$first" ]; then
    DISTRO="$(basename "$first")"
    return 0
  fi
  return 1
}

if ! mkdir "$LOCK_DIR" 2>/dev/null; then
  if [ -f "$LOCK_DIR/pid" ]; then
    old_pid="$(cat "$LOCK_DIR/pid" 2>/dev/null || true)"
    if [ -n "$old_pid" ] && kill -0 "$old_pid" 2>/dev/null; then
      echo "ai_ops_monitor already running pid=$old_pid" >> "$LOG_DIR/monitor.log"
      exit 0
    fi
  fi
  rm -rf "$LOCK_DIR"
  mkdir "$LOCK_DIR"
fi

MONITOR_CHILD_PID=""

monitor_child_running() {
  local pid="${1:-}" state
  [ -n "$pid" ] && kill -0 "$pid" 2>/dev/null || return 1
  state="$(awk '{print $3}' "/proc/$pid/stat" 2>/dev/null || true)"
  [ "$state" != "Z" ]
}

stop_monitor_child() {
  local pid="$MONITOR_CHILD_PID" deadline
  monitor_child_running "$pid" || return 0
  kill -TERM "$pid" 2>/dev/null || true
  deadline=$((SECONDS + 10))
  while monitor_child_running "$pid" && [ "$SECONDS" -lt "$deadline" ]; do
    sleep 1
  done
  if monitor_child_running "$pid"; then
    kill -KILL "$pid" 2>/dev/null || true
  fi
  wait "$pid" 2>/dev/null || true
  MONITOR_CHILD_PID=""
}

cleanup() {
  rm -rf "$LOCK_DIR"
}

handle_monitor_signal() {
  local code="$1"
  stop_monitor_child
  exit "$code"
}

run_monitor_child() {
  local code
  "$@" &
  MONITOR_CHILD_PID="$!"
  set +e
  wait "$MONITOR_CHILD_PID"
  code=$?
  set -e
  MONITOR_CHILD_PID=""
  return "$code"
}

trap cleanup EXIT
trap 'handle_monitor_signal 143' TERM
trap 'handle_monitor_signal 130' INT
echo "$$" > "$LOCK_DIR/pid"

if command -v proot-distro >/dev/null 2>&1 && resolve_distro && proot-distro login "$DISTRO" -- true >/dev/null 2>&1; then
  run_monitor_child proot-distro login "$DISTRO" -- env \
    "${CA_RUNTIME_ENV_ARGS[@]}" \
    "AI_OPS_MONITOR_NODE=$AI_OPS_MONITOR_NODE" \
    "AI_OPS_BASE_PATH=$AI_OPS_BASE_PATH" \
    "AI_OPS_MONITOR_INTERVAL_SEC=$AI_OPS_MONITOR_INTERVAL_SEC" \
    bash -lc "
    cd '$ROOT'
    export AI_OPS_SELF_FIX=\"\${AI_OPS_SELF_FIX:-1}\"
    export AI_OPS_SELF_FIX_THRESHOLD=\"\${AI_OPS_SELF_FIX_THRESHOLD:-error}\"
    export AI_OPS_SELF_FIX_COOLDOWN_MIN=\"\${AI_OPS_SELF_FIX_COOLDOWN_MIN:-360}\"
    exec python3 scripts/ai_ops_common_monitor.py --watch --self-fix --node '$AI_OPS_MONITOR_NODE'
  " >> "$LOG_DIR/monitor.log" 2>&1
  exit $?
fi

if [ ! -d "$ROOT" ]; then
  echo "ai_ops_monitor root missing: $ROOT (distro=${DISTRO:-none})" >> "$LOG_DIR/monitor.log"
  exit 1
fi

cd "$ROOT"
export AI_OPS_MONITOR_NODE="${AI_OPS_MONITOR_NODE}"
export AI_OPS_BASE_PATH="${AI_OPS_BASE_PATH}"
export AI_OPS_MONITOR_INTERVAL_SEC="${AI_OPS_MONITOR_INTERVAL_SEC}"
export AI_OPS_SELF_FIX="${AI_OPS_SELF_FIX:-1}"
export AI_OPS_SELF_FIX_THRESHOLD="${AI_OPS_SELF_FIX_THRESHOLD:-error}"
export AI_OPS_SELF_FIX_COOLDOWN_MIN="${AI_OPS_SELF_FIX_COOLDOWN_MIN:-360}"
run_monitor_child python3 scripts/ai_ops_common_monitor.py --watch --self-fix --node "$AI_OPS_MONITOR_NODE" >> "$LOG_DIR/monitor.log" 2>&1
