#!/usr/bin/env bash
# Strict 0600 environment loader for CA telemetry activation.
# Values are assigned without eval/source so an env file cannot execute shell.

wonmux_load_secure_ca_env() {
  local env_file="${1:-}"
  local required="${2:-0}"
  local mode line key value

  if [[ -z "$env_file" ]]; then
    echo "secure CA env path is empty" >&2
    return 64
  fi
  if [[ ! -e "$env_file" ]]; then
    if [[ "$required" == "1" ]]; then
      echo "secure CA env file is missing: $env_file" >&2
      return 66
    fi
    return 0
  fi
  if [[ ! -f "$env_file" || -L "$env_file" ]]; then
    echo "secure CA env must be a regular non-symlink file: $env_file" >&2
    return 65
  fi
  mode="$(stat -c '%a' -- "$env_file" 2>/dev/null || true)"
  if [[ "$mode" != "600" ]]; then
    echo "secure CA env must have mode 0600: $env_file" >&2
    return 65
  fi
  if [[ "$(wc -c <"$env_file")" -gt 16384 ]]; then
    echo "secure CA env is too large: $env_file" >&2
    return 65
  fi

  while IFS= read -r line || [[ -n "$line" ]]; do
    line="${line%$'\r'}"
    [[ -z "$line" || "$line" == \#* ]] && continue
    if [[ "$line" != *=* ]]; then
      echo "secure CA env contains an invalid line" >&2
      return 65
    fi
    key="${line%%=*}"
    value="${line#*=}"
    case "$key" in
      POSDELAY_CA_PROJECTION_ENABLED|POSDELAY_CA_LIVE_SEND_ENABLED|POSDELAY_CA_FACTORY_SELF_FIX_ENABLED|POSDELAY_CA_KILL_SWITCH|STOREBOT_CA_PROJECTION_ENABLED|STOREBOT_CA_LIVE_SEND_ENABLED|STOREBOT_CA_FACTORY_SELF_FIX_ENABLED|STOREBOT_CA_SCHEDULE_RECOVERY_ENABLED|STOREBOT_CA_KILL_SWITCH|PROJECT_CA_PROJECTION_ENABLED|PROJECT_CA_LIVE_SEND_ENABLED|PROJECT_CA_KILL_SWITCH|PROJECT_CA_IDENTITY_DERIVE_FROM_STOREBOT)
        if [[ "$value" != "0" && "$value" != "1" ]]; then
          echo "secure CA env flag must be 0 or 1: $key" >&2
          return 65
        fi
        ;;
      POSDELAY_CA_IDENTITY_KEY_FILE|POSDELAY_CA_MODULE_PATH|STOREBOT_CA_IDENTITY_KEY_FILE|STOREBOT_CA_MODULE_PATH|PROJECT_CA_IDENTITY_KEY_FILE|PROJECT_CA_REGISTRY_PATH)
        if [[ "$value" != /* || "$value" == *$'\n'* || "$value" == *$'\r'* ]]; then
          echo "secure CA env path must be absolute: $key" >&2
          return 65
        fi
        ;;
      POSDELAY_CA_MODULE_SHA256|STOREBOT_CA_MODULE_SHA256)
        if [[ ! "$value" =~ ^[0-9a-f]{64}$ ]]; then
          echo "secure CA env hash is invalid: $key" >&2
          return 65
        fi
        ;;
      STOREBOT_TELEGRAM_BACKPLANE_DRY_RUN|STOREBOT_TELEGRAM_BACKPLANE_KILL_SWITCH)
        if [[ "$value" != "0" && "$value" != "1" ]]; then
          echo "secure CA env flag must be 0 or 1: $key" >&2
          return 65
        fi
        ;;
      STOREBOT_TELEGRAM_BACKPLANE_IDENTITY_KEY_FILE)
        if [[ "$value" != /* || "$value" == *$'\n'* || "$value" == *$'\r'* ]]; then
          echo "secure CA env path must be absolute: $key" >&2
          return 65
        fi
        ;;
      *)
        echo "secure CA env key is not allowlisted: $key" >&2
        return 65
        ;;
    esac
    export "$key=$value"
  done <"$env_file"
}
