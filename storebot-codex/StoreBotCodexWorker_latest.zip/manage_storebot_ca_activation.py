#!/usr/bin/env python3
"""Atomically manage StoreBot CA activation files without printing secrets."""

from __future__ import annotations

import argparse
import hashlib
import json
import os
import secrets
import stat
import tempfile
from pathlib import Path


FLAGS = (
    "STOREBOT_CA_PROJECTION_ENABLED",
    "STOREBOT_CA_LIVE_SEND_ENABLED",
    "STOREBOT_CA_FACTORY_SELF_FIX_ENABLED",
    "STOREBOT_CA_SCHEDULE_RECOVERY_ENABLED",
    "STOREBOT_CA_KILL_SWITCH",
)
POSDELAY_FLAGS = (
    "POSDELAY_CA_PROJECTION_ENABLED",
    "POSDELAY_CA_LIVE_SEND_ENABLED",
    "POSDELAY_CA_FACTORY_SELF_FIX_ENABLED",
    "POSDELAY_CA_KILL_SWITCH",
)
STOREBOT_KEYS = frozenset(
    {
        *FLAGS,
        "STOREBOT_CA_IDENTITY_KEY_FILE",
        "STOREBOT_CA_MODULE_PATH",
        "STOREBOT_CA_MODULE_SHA256",
    }
)
POSDELAY_KEYS = frozenset(
    {
        *POSDELAY_FLAGS,
        "POSDELAY_CA_IDENTITY_KEY_FILE",
        "POSDELAY_CA_MODULE_PATH",
        "POSDELAY_CA_MODULE_SHA256",
    }
)
PROJECT_FLAGS = (
    "PROJECT_CA_PROJECTION_ENABLED",
    "PROJECT_CA_LIVE_SEND_ENABLED",
    "PROJECT_CA_KILL_SWITCH",
)
PROJECT_KEYS = frozenset(
    {
        *PROJECT_FLAGS,
        "PROJECT_CA_IDENTITY_KEY_FILE",
        "PROJECT_CA_REGISTRY_PATH",
    }
)
PROJECT_REGISTRY_SCHEMA = "project.telegram_ca_registry.v1"
PROJECT_REGISTRY_PROJECTS = frozenset(
    {
        "CoreOps",
        "SolNote",
        "StoreBot",
        "DeliveryHelper",
        "PosDelay",
        "BankTotal",
        "MainPC",
        "OrderHelper",
    }
)
PRESERVABLE_KEYS = frozenset(
    {
        *POSDELAY_KEYS,
        "STOREBOT_TELEGRAM_BACKPLANE_DRY_RUN",
        "STOREBOT_TELEGRAM_BACKPLANE_KILL_SWITCH",
        "STOREBOT_TELEGRAM_BACKPLANE_IDENTITY_KEY_FILE",
    }
)
ALL_CA_ENV_KEYS = frozenset({*STOREBOT_KEYS, *PRESERVABLE_KEYS, *PROJECT_KEYS})


class ActivationError(RuntimeError):
    pass


def cli_path(value: str) -> Path:
    """Expand user paths without resolving away a final symlink."""
    return Path(os.path.abspath(Path(value).expanduser()))


def preflight_identity(path: Path) -> None:
    if not (path.exists() or path.is_symlink()):
        return
    info = path.lstat()
    if not stat.S_ISREG(info.st_mode) or stat.S_IMODE(info.st_mode) != 0o600:
        raise ActivationError(f"private file must be a regular 0600 file: {path}")
    if not 32 <= path.stat().st_size <= 4096:
        raise ActivationError(f"identity key length is invalid: {path}")


def ensure_private_regular(path: Path, *, create_key: bool) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    if path.exists() or path.is_symlink():
        info = path.lstat()
        if not stat.S_ISREG(info.st_mode) or stat.S_IMODE(info.st_mode) != 0o600:
            raise ActivationError(f"private file must be a regular 0600 file: {path}")
        if create_key and not 32 <= path.stat().st_size <= 4096:
            raise ActivationError(f"identity key length is invalid: {path}")
        return
    if not create_key:
        return
    descriptor = os.open(path, os.O_WRONLY | os.O_CREAT | os.O_EXCL, 0o600)
    try:
        os.write(descriptor, secrets.token_bytes(48))
        os.fsync(descriptor)
    finally:
        os.close(descriptor)


def atomic_write_private(path: Path, content: str) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    descriptor, temporary = tempfile.mkstemp(prefix=f".{path.name}.", dir=path.parent)
    try:
        os.fchmod(descriptor, 0o600)
        with os.fdopen(descriptor, "w", encoding="utf-8") as handle:
            handle.write(content)
            handle.flush()
            os.fsync(handle.fileno())
        os.replace(temporary, path)
        os.chmod(path, 0o600)
    except Exception:
        try:
            os.unlink(temporary)
        except FileNotFoundError:
            pass
        raise


def env_content(
    *,
    active: bool,
    schedule_recovery: bool,
    identity: Path,
    module: Path,
    module_hash: str,
    existing: str = "",
    posdelay: dict[str, str] | None = None,
) -> str:
    values = {
        "STOREBOT_CA_PROJECTION_ENABLED": "1" if active else "0",
        "STOREBOT_CA_LIVE_SEND_ENABLED": "1" if active else "0",
        "STOREBOT_CA_FACTORY_SELF_FIX_ENABLED": "1" if active else "0",
        "STOREBOT_CA_SCHEDULE_RECOVERY_ENABLED": "1" if active and schedule_recovery else "0",
        "STOREBOT_CA_KILL_SWITCH": "0" if active else "1",
        "STOREBOT_CA_IDENTITY_KEY_FILE": str(identity),
        "STOREBOT_CA_MODULE_PATH": str(module),
        "STOREBOT_CA_MODULE_SHA256": module_hash,
    }
    preserved: list[str] = []
    for raw in existing.splitlines():
        line = raw.rstrip("\r")
        if not line or line.startswith("#"):
            preserved.append(line)
            continue
        if "=" not in line:
            raise ActivationError("existing CA env contains an invalid line")
        key = line.split("=", 1)[0]
        if key in STOREBOT_KEYS:
            continue
        if posdelay is not None and key in POSDELAY_KEYS:
            continue
        if key not in PRESERVABLE_KEYS:
            raise ActivationError(f"existing CA env key is not allowlisted: {key}")
        preserved.append(line)
    prefix = "\n".join(preserved).strip()
    storebot = "".join(f"{key}={value}\n" for key, value in values.items())
    posdelay_content = "" if posdelay is None else "".join(f"{key}={value}\n" for key, value in posdelay.items())
    return (prefix + "\n" if prefix else "") + storebot + posdelay_content


def validate_module(path: Path, *, label: str = "StoreBot") -> str:
    if not path.is_absolute() or not path.is_file() or path.is_symlink():
        raise ActivationError(f"{label} CA module must be an absolute regular non-symlink file")
    return hashlib.sha256(path.read_bytes()).hexdigest()


def posdelay_values(*, active: bool, identity: Path, module: Path, module_hash: str) -> dict[str, str]:
    return {
        "POSDELAY_CA_PROJECTION_ENABLED": "1" if active else "0",
        "POSDELAY_CA_LIVE_SEND_ENABLED": "1" if active else "0",
        "POSDELAY_CA_FACTORY_SELF_FIX_ENABLED": "1" if active else "0",
        "POSDELAY_CA_KILL_SWITCH": "0" if active else "1",
        "POSDELAY_CA_IDENTITY_KEY_FILE": str(identity),
        "POSDELAY_CA_MODULE_PATH": str(module),
        "POSDELAY_CA_MODULE_SHA256": module_hash,
    }


def project_registry_path(value: str) -> Path:
    expanded = Path(value).expanduser()
    if not expanded.is_absolute():
        raise ActivationError("project CA registry path must be absolute")
    return Path(os.path.abspath(expanded))


def validate_project_registry(path: Path) -> None:
    if not path.is_absolute() or not path.is_file() or path.is_symlink():
        raise ActivationError("project CA registry must be an absolute regular non-symlink JSON file")
    try:
        registry = json.loads(path.read_text(encoding="utf-8"))
    except (OSError, UnicodeError, json.JSONDecodeError) as exc:
        raise ActivationError("project CA registry must contain valid JSON") from exc
    if not isinstance(registry, dict):
        raise ActivationError("project CA registry schema is invalid")
    projects = registry.get("projects")
    if registry.get("schema") != PROJECT_REGISTRY_SCHEMA or not isinstance(projects, dict):
        raise ActivationError("project CA registry schema is invalid")
    if len(projects) != 8 or frozenset(projects) != PROJECT_REGISTRY_PROJECTS:
        raise ActivationError("project CA registry must contain the exact eight projects")


def preflight_project_identity(path: Path) -> bool:
    if not (path.exists() or path.is_symlink()):
        return False
    info = path.lstat()
    if (
        not stat.S_ISREG(info.st_mode)
        or stat.S_IMODE(info.st_mode) != 0o600
        or info.st_size != 48
    ):
        raise ActivationError(f"project identity must be a regular 48-byte 0600 file: {path}")
    return True


def ensure_project_identity(path: Path) -> bool:
    if preflight_project_identity(path):
        return False
    path.parent.mkdir(parents=True, exist_ok=True)
    descriptor = os.open(path, os.O_WRONLY | os.O_CREAT | os.O_EXCL, 0o600)
    try:
        with os.fdopen(descriptor, "wb") as handle:
            handle.write(secrets.token_bytes(48))
            handle.flush()
            os.fsync(handle.fileno())
    except Exception:
        path.unlink(missing_ok=True)
        raise
    return True


def read_private_env(path: Path) -> tuple[str, bool]:
    if not (path.exists() or path.is_symlink()):
        return "", False
    info = path.lstat()
    if not stat.S_ISREG(info.st_mode) or stat.S_IMODE(info.st_mode) != 0o600:
        raise ActivationError(f"private file must be a regular 0600 file: {path}")
    with path.open("r", encoding="utf-8", newline="") as handle:
        return handle.read(), True


def parse_project_env(existing: str) -> dict[str, str]:
    values: dict[str, str] = {}
    for raw in existing.splitlines():
        line = raw.rstrip("\r")
        if not line or line.startswith("#"):
            continue
        if "=" not in line:
            raise ActivationError("existing CA env contains an invalid line")
        key, value = line.split("=", 1)
        if key not in ALL_CA_ENV_KEYS:
            raise ActivationError(f"existing CA env key is not allowlisted: {key}")
        if key not in PROJECT_KEYS:
            continue
        if key in values:
            raise ActivationError(f"existing CA env contains a duplicate key: {key}")
        if key in PROJECT_FLAGS and value not in {"0", "1"}:
            raise ActivationError(f"existing project CA flag must be 0 or 1: {key}")
        if key in {"PROJECT_CA_IDENTITY_KEY_FILE", "PROJECT_CA_REGISTRY_PATH"} and not Path(value).is_absolute():
            raise ActivationError(f"existing project CA path must be absolute: {key}")
        values[key] = value
    return values


def project_env_content(*, active: bool, identity: Path, registry: Path, existing: str) -> str:
    parse_project_env(existing)
    preserved: list[str] = []
    for raw in existing.splitlines(keepends=True):
        line = raw.rstrip("\r\n")
        if line and not line.startswith("#") and "=" in line:
            key = line.split("=", 1)[0]
            if key in PROJECT_KEYS:
                continue
        preserved.append(raw)
    prefix = "".join(preserved)
    if prefix and not prefix.endswith(("\n", "\r")):
        prefix += "\n"
    values = {
        "PROJECT_CA_PROJECTION_ENABLED": "1" if active else "0",
        "PROJECT_CA_LIVE_SEND_ENABLED": "0",
        "PROJECT_CA_KILL_SWITCH": "0" if active else "1",
        "PROJECT_CA_IDENTITY_KEY_FILE": str(identity),
        "PROJECT_CA_REGISTRY_PATH": str(registry),
    }
    return prefix + "".join(f"{key}={value}\n" for key, value in values.items())


def selected_envs(args: argparse.Namespace) -> list[tuple[str, Path]]:
    values = {
        "personal": cli_path(args.personal_env),
        "serverphone": cli_path(args.serverphone_env),
    }
    return list(values.items()) if args.scope == "both" else [(args.scope, values[args.scope])]


def status_project_shadow(args: argparse.Namespace) -> dict[str, object]:
    identity = cli_path(args.identity_key)
    registry = project_registry_path(args.registry)
    validate_project_registry(registry)
    identity_ready = preflight_project_identity(identity)
    env_files: dict[str, object] = {}
    for label, path in selected_envs(args):
        existing, private = read_private_env(path)
        values = parse_project_env(existing)
        env_files[label] = {
            "private": private,
            "identity_ready": identity_ready,
            "projection": values.get("PROJECT_CA_PROJECTION_ENABLED") == "1",
            "live_send": values.get("PROJECT_CA_LIVE_SEND_ENABLED") == "1",
            "kill_switch": values.get("PROJECT_CA_KILL_SWITCH") != "0",
        }
    return {
        "ok": True,
        "command": "status-project-shadow",
        "env_files": env_files,
    }


def mutate_project_shadow(args: argparse.Namespace, *, active: bool) -> dict[str, object]:
    identity = cli_path(args.identity_key)
    registry = project_registry_path(args.registry)
    validate_project_registry(registry)
    identity_existed = preflight_project_identity(identity)
    selected = selected_envs(args)
    prepared: list[tuple[Path, str, str, bool]] = []
    for _label, path in selected:
        existing, existed = read_private_env(path)
        prepared.append(
            (
                path,
                project_env_content(
                    active=active,
                    identity=identity,
                    registry=registry,
                    existing=existing,
                ),
                existing,
                existed,
            )
        )

    identity_created = ensure_project_identity(identity) if active else False
    changed: list[tuple[Path, str, bool]] = []
    try:
        for path, content, existing, existed in prepared:
            atomic_write_private(path, content)
            changed.append((path, existing, existed))
    except Exception as exc:
        rollback_error: Exception | None = None
        for path, existing, existed in reversed(changed):
            try:
                if existed:
                    atomic_write_private(path, existing)
                else:
                    path.unlink(missing_ok=True)
            except Exception as restore_exc:
                rollback_error = restore_exc
        if identity_created and not identity_existed:
            try:
                identity.unlink(missing_ok=True)
            except OSError as restore_exc:
                rollback_error = restore_exc
        if rollback_error is not None:
            raise ActivationError("project shadow activation failed and rollback was incomplete") from rollback_error
        raise ActivationError("project shadow activation failed and was rolled back") from exc

    return {
        "ok": True,
        "command": "activate-project-shadow" if active else "deactivate-project-shadow",
        "identity_ready": preflight_project_identity(identity),
        "env_files": [str(path) for path, _content, _existing, _existed in prepared],
        "projection": active,
        "live_send": False,
        "kill_switch": not active,
        "secret_printed": False,
        "service_restart_performed": False,
    }


def status(args: argparse.Namespace) -> dict[str, object]:
    module = cli_path(args.module)
    identity = cli_path(args.identity_key)
    posdelay_module = cli_path(args.posdelay_module)
    posdelay_identity = cli_path(args.posdelay_identity_key)
    result: dict[str, object] = {
        "ok": True,
        "command": "status",
        "module_path": str(module),
        "module_sha256": hashlib.sha256(module.read_bytes()).hexdigest() if module.is_file() else "",
        "identity_path": str(identity),
        "identity_ready": identity.is_file() and not identity.is_symlink() and stat.S_IMODE(identity.stat().st_mode) == 0o600 and identity.stat().st_size >= 32,
        "posdelay": {
            "included": bool(args.with_posdelay),
            "module_path": str(posdelay_module),
            "module_sha256": hashlib.sha256(posdelay_module.read_bytes()).hexdigest()
            if args.with_posdelay and posdelay_module.is_file() and not posdelay_module.is_symlink()
            else "",
            "identity_path": str(posdelay_identity),
            "identity_ready": posdelay_identity.is_file()
            and not posdelay_identity.is_symlink()
            and stat.S_IMODE(posdelay_identity.stat().st_mode) == 0o600
            and posdelay_identity.stat().st_size >= 32,
        },
        "env_files": {},
    }
    for label, path in selected_envs(args):
        values: dict[str, str] = {}
        if path.is_file() and not path.is_symlink() and stat.S_IMODE(path.stat().st_mode) == 0o600:
            for line in path.read_text(encoding="utf-8").splitlines():
                if "=" in line:
                    key, value = line.split("=", 1)
                    if key in FLAGS or (args.with_posdelay and key in POSDELAY_FLAGS):
                        values[key] = value
        result["env_files"][label] = {
            "path": str(path),
            "private": path.is_file() and not path.is_symlink() and stat.S_IMODE(path.stat().st_mode) == 0o600,
            "projection": values.get("STOREBOT_CA_PROJECTION_ENABLED") == "1",
            "live_send": values.get("STOREBOT_CA_LIVE_SEND_ENABLED") == "1",
            "factory_self_fix": values.get("STOREBOT_CA_FACTORY_SELF_FIX_ENABLED") == "1",
            "schedule_recovery": values.get("STOREBOT_CA_SCHEDULE_RECOVERY_ENABLED") == "1",
            "kill_switch": values.get("STOREBOT_CA_KILL_SWITCH") != "0",
            "posdelay": {
                "projection": values.get("POSDELAY_CA_PROJECTION_ENABLED") == "1",
                "live_send": values.get("POSDELAY_CA_LIVE_SEND_ENABLED") == "1",
                "factory_self_fix": values.get("POSDELAY_CA_FACTORY_SELF_FIX_ENABLED") == "1",
                "kill_switch": values.get("POSDELAY_CA_KILL_SWITCH") != "0",
            }
            if args.with_posdelay
            else {"included": False},
        }
    return result


def mutate(args: argparse.Namespace, *, active: bool) -> dict[str, object]:
    module = cli_path(args.module)
    identity = cli_path(args.identity_key)
    digest = validate_module(module)
    posdelay_module = cli_path(args.posdelay_module)
    posdelay_identity = cli_path(args.posdelay_identity_key)
    posdelay_digest = (
        validate_module(posdelay_module, label="PosDelay") if args.with_posdelay else ""
    )
    selected = selected_envs(args)
    prepared: list[tuple[Path, str]] = []
    posdelay = (
        posdelay_values(
            active=active,
            identity=posdelay_identity,
            module=posdelay_module,
            module_hash=posdelay_digest,
        )
        if args.with_posdelay
        else None
    )
    preflight_identity(identity)
    if args.with_posdelay:
        preflight_identity(posdelay_identity)
    for _label, path in selected:
        ensure_private_regular(path, create_key=False)
        existing = path.read_text(encoding="utf-8") if path.is_file() else ""
        content = env_content(
            active=active,
            schedule_recovery=bool(args.schedule_recovery),
            identity=identity,
            module=module,
            module_hash=digest,
            existing=existing,
            posdelay=posdelay,
        )
        prepared.append((path, content))
    ensure_private_regular(identity, create_key=True)
    if args.with_posdelay:
        ensure_private_regular(posdelay_identity, create_key=True)
    changed: list[str] = []
    for path, content in prepared:
        atomic_write_private(path, content)
        changed.append(str(path))
    return {
        "ok": True,
        "command": "activate" if active else "deactivate",
        "identity_path": str(identity),
        "identity_preserved_or_created": True,
        "module_path": str(module),
        "module_sha256": digest,
        "env_files": changed,
        "projection": active,
        "live_send": active,
        "factory_self_fix": active,
        "schedule_recovery": active and bool(args.schedule_recovery),
        "kill_switch": not active,
        "posdelay": {
            "included": bool(args.with_posdelay),
            "identity_path": str(posdelay_identity) if args.with_posdelay else "",
            "identity_preserved_or_created": bool(args.with_posdelay),
            "module_path": str(posdelay_module) if args.with_posdelay else "",
            "module_sha256": posdelay_digest,
            "projection": active and bool(args.with_posdelay),
            "live_send": active and bool(args.with_posdelay),
            "factory_self_fix": active and bool(args.with_posdelay),
            "kill_switch": not active if args.with_posdelay else True,
        },
        "secret_printed": False,
        "service_restart_performed": False,
    }


def parser() -> argparse.ArgumentParser:
    root = argparse.ArgumentParser(description="StoreBot CA activation file manager")
    commands = root.add_subparsers(dest="command", required=True)
    for name in ("status", "activate", "deactivate"):
        item = commands.add_parser(name)
        item.add_argument("--scope", choices=("personal", "serverphone", "both"), default="both")
        item.add_argument("--personal-env", default="~/.openclaw/ca-live.env")
        item.add_argument("--serverphone-env", default="~/.config/wonmux/ca-live.env")
        item.add_argument("--identity-key", default="~/.config/wonmux/storebot-ca.identity")
        item.add_argument("--module", default=str(Path(__file__).with_name("storebot_ca_log.py")))
        item.add_argument(
            "--with-posdelay",
            action="store_true",
            help="also manage PosDelay CA activation in the same private env file",
        )
        item.add_argument("--posdelay-identity-key", default="~/.config/wonmux/posdelay-ca.key")
        item.add_argument("--posdelay-module", default=str(Path(__file__).with_name("posdelay_ca_log.py")))
        item.add_argument(
            "--schedule-recovery",
            action="store_true",
            help="explicitly enable one-shot existing StoreBot schedule queue recovery",
        )
    for name in ("status-project-shadow", "activate-project-shadow", "deactivate-project-shadow"):
        item = commands.add_parser(name)
        item.add_argument("--scope", choices=("personal", "serverphone", "both"), default="both")
        item.add_argument("--personal-env", default="~/.openclaw/ca-live.env")
        item.add_argument("--serverphone-env", default="~/.config/wonmux/ca-live.env")
        item.add_argument(
            "--identity-key",
            "--project-identity-key",
            dest="identity_key",
            default="~/.config/wonmux/project-ca.identity",
        )
        item.add_argument(
            "--registry",
            "--project-registry",
            "--registry-path",
            "--project-registry-path",
            dest="registry",
            default="/root/my-first-project/config/telegram_project_ca_registry.json",
        )
    return root


def main(argv: list[str] | None = None) -> int:
    args = parser().parse_args(argv)
    try:
        if args.command == "status-project-shadow":
            result = status_project_shadow(args)
        elif args.command in {"activate-project-shadow", "deactivate-project-shadow"}:
            result = mutate_project_shadow(args, active=args.command == "activate-project-shadow")
        else:
            result = status(args) if args.command == "status" else mutate(args, active=args.command == "activate")
    except (ActivationError, OSError, ValueError) as exc:
        print(json.dumps({"ok": False, "error": str(exc)}, ensure_ascii=False))
        return 2
    print(json.dumps(result, ensure_ascii=False, sort_keys=True, separators=(",", ":")))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
