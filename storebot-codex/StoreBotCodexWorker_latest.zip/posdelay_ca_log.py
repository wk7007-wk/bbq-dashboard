"""Default-off PosDelay CA receipt projection.

The module is model-0 and has no direct network, Telegram, recovery or
business-action client. Its injected repository contract is intentionally
compatible with TelegramGateFirebaseCasRepository read/CAS callables, while
every record retains a PosDelay-specific schema and resource identity.
"""

from __future__ import annotations

import hashlib
import hmac
import json
import re
import secrets
import threading
import time
from collections import deque
from collections.abc import Callable, Mapping, Sequence
from copy import deepcopy
from dataclasses import dataclass
from typing import Any, Protocol


RECEIPT_SCHEMA = "posdelay.ca_receipt.v1"
DELIVERY_SCHEMA = "posdelay.ca_delivery.v1"
OPS_EVENT_SCHEMA = "posdelay.ops_event.v1"
REJECTION_SCHEMA = "posdelay.ca_rejection.v1"
DOMAIN = "posdelay"
RESOURCE = "posdelay_app"
SELF_ORIGIN = "posdelay_ca_receipt"
OPS_EVENTS_PATH = "/posdelay/ops_events"
CA_TASKS_PATH = "/posdelay/ca_projection/tasks"
CA_RECEIPTS_PATH = "/posdelay/ca_projection/receipts"
CA_BATCHES_PATH = "/posdelay/ca_projection/outbox_batches"
CA_QUARANTINE_PATH = "/posdelay/ca_projection/quarantine"
CA_GUARD_PATH = "/posdelay/ca_projection/guards/global"
CA_OUTBOX_GUARD_PATH = "/posdelay/ca_projection/guards/outbox"
CA_OUTBOX_CLAIMS_PATH = "/posdelay/ca_projection/outbox_claims"
GATE_DELIVERIES_PATH = "/packhelper/openclaw_telegram_gate/deliveries"
EVENT_KINDS = frozenset({"action", "error", "heartbeat", "recovery"})
TRANSITIONS = frozenset(
    {
        "action_requested", "action_started", "action_result", "error_detected",
        "heartbeat", "recovery_proposed", "recovery_started", "recovery_result",
    }
)
TRANSITION_KIND = {
    "action_requested": "action",
    "action_started": "action",
    "action_result": "action",
    "error_detected": "error",
    "heartbeat": "heartbeat",
    "recovery_proposed": "recovery",
    "recovery_started": "recovery",
    "recovery_result": "recovery",
}
PREDECESSORS = {
    "action_requested": frozenset({""}),
    "action_started": frozenset({"", "action_requested"}),
    "action_result": frozenset({"", "action_started"}),
    "error_detected": frozenset({"", "action_started", "action_result"}),
    "heartbeat": frozenset({"", "heartbeat"}),
    "recovery_proposed": frozenset({"", "error_detected", "action_result", "recovery_result"}),
    "recovery_started": frozenset({"recovery_proposed"}),
    "recovery_result": frozenset({"recovery_started"}),
}
TASKS = frozenset(
    {
        "ad_baemin", "ad_coupang", "delay_baemin", "delay_coupang",
        "defense_fee_baemin", "defense_stop_baemin", "discount_baemin", "app_health",
    }
)
TASK_EXPECTED_SOURCE = {
    "ad_baemin": "kds_weighted",
    "ad_coupang": "kds_weighted",
    "delay_baemin": "kds_weighted",
    "delay_coupang": "kds_weighted",
    "defense_fee_baemin": "kds",
    "defense_stop_baemin": "kds_weighted",
    "discount_baemin": "kds",
}
TASK_EXPECTED_TARGET = {
    "ad_baemin": "baemin",
    "ad_coupang": "coupang",
    "delay_baemin": "baemin",
    "delay_coupang": "coupang",
    "defense_fee_baemin": "baemin",
    "defense_stop_baemin": "baemin",
    "discount_baemin": "baemin",
}
SOURCES = frozenset({"none", "kds", "kds_raw", "kds_weighted", "printer"})
TARGETS = frozenset({"none", "baemin", "coupang", "posdelay_app"})
RESULTS = frozenset({"pending", "running", "success", "failed", "skipped", "matched", "mismatch", "stale"})
SEVERITIES = frozenset({"info", "warning", "error", "critical"})
ORIGINS = frozenset({"posdelay_engine", "posdelay_health", "posdelay_recovery", SELF_ORIGIN})
EXECUTION_PATHS = frozenset({"unified_task_queue", "health_publisher", "factory_self_fix"})
OPAQUE_EVIDENCE = re.compile(r"\Apdevidence_[0-9a-f]{32,64}\Z")
OPAQUE_EVENT = re.compile(r"\Apdevent_[0-9a-f]{32,64}\Z")
OPAQUE_EXECUTION = re.compile(r"\Apdexec_[0-9a-f]{32,64}\Z")
SAFE_ID = re.compile(r"\A[A-Za-z0-9_-]{3,160}\Z")
OPS_EVENT_KEYS = frozenset(
    {
        "schema", "domain", "event_id", "execution_id", "event_kind", "transition", "task",
        "execution_path", "expected_source", "decision_source", "target", "result", "severity",
        "trigger_source", "kds_adjusted_count", "kds_raw_count", "kds_weighted_count",
        "printer_count", "observed_count", "duration_ms", "source_updated_at_ms",
        "source_revision", "settings_revision", "occurred_at_ms", "evidence_pointer", "origin",
        "telegram_send_approved",
    }
)
RECEIPT_KEYS = frozenset(
    {
        "schema", "domain", "resource", "receipt_id", "task_id", "event_kind", "transition",
        "attempt", "execution_path", "expected_source", "data_source", "target", "result",
        "severity", "kds_adjusted_count", "kds_raw_count", "kds_weighted_count",
        "printer_count", "observed_count", "duration_ms", "source_updated_at_ms",
        "source_revision", "settings_revision",
        "occurred_at_ms", "evidence_pointer", "dedupe_key", "coalesce_key", "projection_fence", "origin",
        "no_send", "sent",
    }
)
RECEIPT_STORAGE_KEYS = frozenset({"receipt_status", "state_version", "updated_at_ms"})


class PosDelayCaLogError(ValueError):
    pass


class ContractRejected(PosDelayCaLogError):
    pass


class RepositoryTransient(PosDelayCaLogError):
    pass


class CasContention(RepositoryTransient):
    pass


def _event_sort_key(row: Mapping[str, Any]) -> tuple[int, str]:
    try:
        occurred_at = int(row.get("occurred_at_ms") or 0)
    except (TypeError, ValueError, OverflowError):
        occurred_at = 0
    return occurred_at, str(row.get("event_id") or "")


@dataclass(frozen=True)
class Snapshot:
    revision: Any
    task: Mapping[str, Any]


@dataclass(frozen=True)
class ReserveResult:
    created: bool
    authoritative: Mapping[str, Any]
    contention: bool = False


@dataclass(frozen=True)
class GuardSnapshot:
    revision: Any
    state: Mapping[str, Any]


@dataclass(frozen=True)
class Page:
    items: Sequence[Mapping[str, Any]]
    next_cursor: Mapping[str, Any] | None
    exhausted: bool


class Repository(Protocol):
    """Duck-compatible subset of TelegramGateFirebaseCasRepository."""

    is_durable: bool
    storage_kind: str

    def read_ops_events(self, limit: int) -> list[dict[str, Any]]: ...
    def read_task(self, task_id: str) -> Snapshot: ...
    def cas_task(self, task_id: str, expected_revision: Any, replacement: Mapping[str, Any]) -> ReserveResult: ...
    def read_receipt(self, receipt_id: str) -> GuardSnapshot: ...
    def cas_receipt(self, receipt_id: str, expected_revision: Any, replacement: Mapping[str, Any]) -> ReserveResult: ...
    def read_receipt_page(self, limit: int, cursor: Mapping[str, Any] | None) -> Page: ...
    def reserve_outbox_batch(self, batch_key: str, record: Mapping[str, Any]) -> ReserveResult: ...
    def reserve_delivery(self, request_id: str, row: Mapping[str, Any]) -> ReserveResult: ...
    def read_due_delivery_page(self, limit: int, now_ms: int, cursor: Mapping[str, Any] | None) -> Page: ...
    def read_delivery(self, request_id: str) -> Any: ...
    def cas_delivery(self, request_id: str, expected_revision: Any, replacement: Mapping[str, Any]) -> ReserveResult: ...
    def reserve_quarantine(self, quarantine_id: str, row: Mapping[str, Any]) -> ReserveResult: ...
    def read_projection_guard(self) -> GuardSnapshot: ...
    def cas_projection_guard(self, expected_revision: Any, replacement: Mapping[str, Any]) -> ReserveResult: ...
    def read_outbox_guard(self) -> GuardSnapshot: ...
    def cas_outbox_guard(self, expected_revision: Any, replacement: Mapping[str, Any]) -> ReserveResult: ...
    def read_outbox_claim(self, receipt_id: str) -> GuardSnapshot: ...
    def cas_outbox_claim(self, receipt_id: str, expected_revision: Any, replacement: Mapping[str, Any]) -> ReserveResult: ...
    def read_pending_claim_page(self, limit: int, cursor: Mapping[str, Any] | None) -> Page: ...


class FakeCasRepository:
    """Shared-memory test fake; never selected by production code."""

    is_durable = False
    storage_kind = "fake_in_memory_test_only"

    def __init__(self, shared: dict[str, Any] | None = None) -> None:
        self.state = shared if shared is not None else {}
        for key in (
            "ops_events", "tasks", "task_revisions", "receipts", "receipt_revisions",
            "batches", "deliveries", "delivery_revisions",
            "quarantine", "guard", "outbox_guard", "outbox_claims", "outbox_claim_revisions",
        ):
            self.state.setdefault(key, {})
        self.lock = self.state.setdefault("_lock", threading.Lock())

    def read_ops_events(self, limit: int) -> list[dict[str, Any]]:
        with self.lock:
            values = [deepcopy(value) for value in self.state["ops_events"].values() if isinstance(value, dict)]
        return sorted(
            values,
            key=_event_sort_key,
        )[-max(1, int(limit)):]

    def read_task(self, task_id: str) -> Snapshot:
        with self.lock:
            return Snapshot(
                self.state["task_revisions"].get(task_id, 0),
                deepcopy(self.state["tasks"].get(task_id) or {}),
            )

    def cas_task(self, task_id: str, expected_revision: Any, replacement: Mapping[str, Any]) -> ReserveResult:
        with self.lock:
            revision = self.state["task_revisions"].get(task_id, 0)
            if revision != expected_revision:
                return ReserveResult(
                    False,
                    deepcopy(self.state["tasks"].get(task_id) or {}),
                    contention=True,
                )
            candidate = dict(replacement)
            self.state["tasks"][task_id] = candidate
            self.state["task_revisions"][task_id] = int(revision) + 1
            return ReserveResult(True, deepcopy(candidate))

    def read_receipt(self, receipt_id: str) -> GuardSnapshot:
        with self.lock:
            return GuardSnapshot(
                self.state["receipt_revisions"].get(receipt_id, 0),
                deepcopy(self.state["receipts"].get(receipt_id) or {}),
            )

    def cas_receipt(
        self,
        receipt_id: str,
        expected_revision: Any,
        replacement: Mapping[str, Any],
    ) -> ReserveResult:
        with self.lock:
            revision = self.state["receipt_revisions"].get(receipt_id, 0)
            current = deepcopy(self.state["receipts"].get(receipt_id) or {})
            if revision != expected_revision:
                return ReserveResult(False, current, contention=True)
            candidate = dict(replacement)
            if int(candidate.get("state_version") or 0) != int(current.get("state_version") or 0) + 1:
                raise PosDelayCaLogError("receipt state version mismatch")
            self.state["receipts"][receipt_id] = candidate
            self.state["receipt_revisions"][receipt_id] = int(revision) + 1
            return ReserveResult(True, deepcopy(candidate))

    def read_receipt_page(self, limit: int, cursor: Mapping[str, Any] | None) -> Page:
        with self.lock:
            rows = [
                (str(receipt_id), deepcopy(receipt))
                for receipt_id, receipt in self.state["receipts"].items()
                if isinstance(receipt, Mapping) and receipt.get("receipt_status") == "committed"
            ]
        after = str((cursor or {}).get("key") or "")
        remaining = sorted(row for row in rows if row[0] > after)
        selected = remaining[:max(1, int(limit))]
        next_cursor = {"key": selected[-1][0]} if selected else None
        return Page(
            [_public_receipt(row[1]) for row in selected],
            next_cursor,
            len(remaining) <= len(selected),
        )

    def reserve_outbox_batch(self, batch_key: str, record: Mapping[str, Any]) -> ReserveResult:
        with self.lock:
            existing = self.state["batches"].get(batch_key)
            if isinstance(existing, dict):
                return ReserveResult(False, deepcopy(existing))
            self.state["batches"][batch_key] = dict(record)
            return ReserveResult(True, deepcopy(dict(record)))

    def reserve_delivery(self, request_id: str, row: Mapping[str, Any]) -> ReserveResult:
        with self.lock:
            existing = self.state["deliveries"].get(request_id)
            if isinstance(existing, dict):
                return ReserveResult(False, deepcopy(existing))
            self.state["deliveries"][request_id] = dict(row)
            self.state["delivery_revisions"][request_id] = 1
            return ReserveResult(True, deepcopy(dict(row)))

    def read_due_delivery_page(
        self,
        limit: int,
        now_ms: int,
        cursor: Mapping[str, Any] | None,
    ) -> Page:
        with self.lock:
            rows = [
                (
                    int(row.get("next_attempt_at_ms") or 0),
                    str(request_id),
                    deepcopy(row),
                )
                for request_id, row in self.state["deliveries"].items()
                if isinstance(row, Mapping)
                and row.get("status") == "retry"
                and int(row.get("next_attempt_at_ms") or 0) <= int(now_ms)
            ]
        after = (int((cursor or {}).get("value") or -1), str((cursor or {}).get("key") or ""))
        remaining = sorted(row for row in rows if (row[0], row[1]) > after)
        selected = remaining[:max(1, int(limit))]
        next_cursor = (
            {"value": selected[-1][0], "key": selected[-1][1]}
            if selected
            else None
        )
        return Page([row[2] for row in selected], next_cursor, len(remaining) <= len(selected))

    def read_delivery(self, request_id: str) -> Any:
        with self.lock:
            return type(
                "DeliverySnapshot",
                (),
                {
                    "revision": self.state["delivery_revisions"].get(request_id, 0),
                    "row": deepcopy(self.state["deliveries"].get(request_id) or {}),
                },
            )()

    def cas_delivery(self, request_id: str, expected_revision: Any, replacement: Mapping[str, Any]) -> ReserveResult:
        with self.lock:
            revision = self.state["delivery_revisions"].get(request_id, 0)
            if revision != expected_revision:
                return ReserveResult(False, deepcopy(self.state["deliveries"].get(request_id) or {}), contention=True)
            self.state["deliveries"][request_id] = dict(replacement)
            self.state["delivery_revisions"][request_id] = int(revision) + 1
            return ReserveResult(True, deepcopy(dict(replacement)))

    def reserve_quarantine(self, quarantine_id: str, row: Mapping[str, Any]) -> ReserveResult:
        with self.lock:
            existing = self.state["quarantine"].get(quarantine_id)
            if isinstance(existing, dict):
                return ReserveResult(False, deepcopy(existing))
            self.state["quarantine"][quarantine_id] = dict(row)
            return ReserveResult(True, deepcopy(dict(row)))

    def read_projection_guard(self) -> GuardSnapshot:
        with self.lock:
            return GuardSnapshot(
                self.state.get("guard_revision", 0),
                deepcopy(self.state.get("guard") or {}),
            )

    def cas_projection_guard(self, expected_revision: Any, replacement: Mapping[str, Any]) -> ReserveResult:
        with self.lock:
            revision = self.state.get("guard_revision", 0)
            current = deepcopy(self.state.get("guard") or {})
            if revision != expected_revision:
                return ReserveResult(False, current, contention=True)
            candidate = dict(replacement)
            if int(candidate.get("state_version") or 0) != int(current.get("state_version") or 0) + 1:
                raise PosDelayCaLogError("projection guard state version mismatch")
            current_fence = int(current.get("fencing_token") or 0)
            candidate_fence = int(candidate.get("fencing_token") or 0)
            if candidate_fence < current_fence or candidate_fence > current_fence + 1:
                raise PosDelayCaLogError("projection guard fencing mismatch")
            self.state["guard"] = candidate
            self.state["guard_revision"] = int(revision) + 1
            return ReserveResult(True, deepcopy(candidate))

    def read_outbox_guard(self) -> GuardSnapshot:
        with self.lock:
            return GuardSnapshot(
                self.state.get("outbox_guard_revision", 0),
                deepcopy(self.state.get("outbox_guard") or {}),
            )

    def cas_outbox_guard(self, expected_revision: Any, replacement: Mapping[str, Any]) -> ReserveResult:
        with self.lock:
            revision = self.state.get("outbox_guard_revision", 0)
            current = deepcopy(self.state.get("outbox_guard") or {})
            if revision != expected_revision:
                return ReserveResult(False, current, contention=True)
            candidate = dict(replacement)
            if int(candidate.get("state_version") or 0) != int(current.get("state_version") or 0) + 1:
                raise PosDelayCaLogError("outbox guard state version mismatch")
            current_fence = int(current.get("fencing_token") or 0)
            candidate_fence = int(candidate.get("fencing_token") or 0)
            if candidate_fence < current_fence or candidate_fence > current_fence + 1:
                raise PosDelayCaLogError("outbox guard fencing mismatch")
            self.state["outbox_guard"] = candidate
            self.state["outbox_guard_revision"] = int(revision) + 1
            return ReserveResult(True, deepcopy(candidate))

    def read_outbox_claim(self, receipt_id: str) -> GuardSnapshot:
        with self.lock:
            return GuardSnapshot(
                self.state["outbox_claim_revisions"].get(receipt_id, 0),
                deepcopy(self.state["outbox_claims"].get(receipt_id) or {}),
            )

    def cas_outbox_claim(
        self,
        receipt_id: str,
        expected_revision: Any,
        replacement: Mapping[str, Any],
    ) -> ReserveResult:
        with self.lock:
            revision = self.state["outbox_claim_revisions"].get(receipt_id, 0)
            current = deepcopy(self.state["outbox_claims"].get(receipt_id) or {})
            if revision != expected_revision:
                return ReserveResult(False, current, contention=True)
            candidate = dict(replacement)
            if int(candidate.get("state_version") or 0) != int(current.get("state_version") or 0) + 1:
                raise PosDelayCaLogError("outbox claim state version mismatch")
            if int(candidate.get("fencing_token") or 0) < int(current.get("fencing_token") or 0):
                raise PosDelayCaLogError("outbox claim fencing mismatch")
            self.state["outbox_claims"][receipt_id] = candidate
            self.state["outbox_claim_revisions"][receipt_id] = int(revision) + 1
            return ReserveResult(True, deepcopy(candidate))

    def read_pending_claim_page(self, limit: int, cursor: Mapping[str, Any] | None) -> Page:
        with self.lock:
            rows = [
                (
                    int(row.get("updated_at_ms") or 0),
                    str(receipt_id),
                    deepcopy(row),
                )
                for receipt_id, row in self.state["outbox_claims"].items()
                if isinstance(row, Mapping) and row.get("status") != "committed"
            ]
        after = (int((cursor or {}).get("value") or -1), str((cursor or {}).get("key") or ""))
        remaining = sorted(row for row in rows if (row[0], row[1]) > after)
        selected = remaining[:max(1, int(limit))]
        next_cursor = (
            {"value": selected[-1][0], "key": selected[-1][1]}
            if selected
            else None
        )
        return Page([row[2] for row in selected], next_cursor, len(remaining) <= len(selected))


class PosDelayFirebaseCasRepository:
    """Durable Firebase CAS adapter with mandatory server-side bounded event query."""

    is_durable = True
    storage_kind = "posdelay_firebase_cas"

    def __init__(
        self,
        *,
        read_with_etag,
        conditional_put,
        read,
        query_latest_ops_events,
        query_receipts_page,
        query_due_deliveries_page,
        query_pending_outbox_claims_page,
    ) -> None:
        self._read_with_etag = read_with_etag
        self._conditional_put = conditional_put
        self._read = read
        if not callable(query_latest_ops_events):
            raise PosDelayCaLogError("server-side bounded ops-event query callable is required")
        if not callable(query_receipts_page):
            raise PosDelayCaLogError("cursor-bounded committed-receipt page callable is required")
        if not callable(query_due_deliveries_page):
            raise PosDelayCaLogError("cursor-bounded due-delivery page callable is required")
        if not callable(query_pending_outbox_claims_page):
            raise PosDelayCaLogError("cursor-bounded pending-claim page callable is required")
        self._query_latest_ops_events = query_latest_ops_events
        self._query_receipts_page = query_receipts_page
        self._query_due_deliveries_page = query_due_deliveries_page
        self._query_pending_outbox_claims_page = query_pending_outbox_claims_page

    @staticmethod
    def _path(root: str, value: str, field: str) -> str:
        if not SAFE_ID.fullmatch(value):
            raise PosDelayCaLogError(f"{field} is not a safe opaque id")
        return f"{root}/{value}"

    def read_ops_events(self, limit: int) -> list[dict[str, Any]]:
        bounded_limit = max(1, min(1_000, int(limit)))
        raw = self._query_latest_ops_events(
            OPS_EVENTS_PATH,
            order_by_child="occurred_at_ms",
            limit_to_last=bounded_limit,
        ) or {}
        if not isinstance(raw, dict):
            raise PosDelayCaLogError("invalid PosDelay ops event collection")
        values = [dict(value) for value in raw.values() if isinstance(value, dict)]
        if len(values) > bounded_limit:
            raise PosDelayCaLogError("bounded ops-event query returned too many rows")
        return values

    @staticmethod
    def _parse_page(raw: Any, limit: int, label: str) -> Page:
        if not isinstance(raw, Mapping):
            raise PosDelayCaLogError(f"invalid {label} page")
        raw_items = raw.get("items") or []
        if isinstance(raw_items, Mapping):
            items = [dict(value) for value in raw_items.values() if isinstance(value, Mapping)]
        elif isinstance(raw_items, Sequence) and not isinstance(raw_items, (str, bytes, bytearray)):
            items = [dict(value) for value in raw_items if isinstance(value, Mapping)]
        else:
            raise PosDelayCaLogError(f"invalid {label} page items")
        if len(items) > limit:
            raise PosDelayCaLogError(f"bounded {label} page returned too many rows")
        cursor = raw.get("next_cursor")
        if cursor is not None and not isinstance(cursor, Mapping):
            raise PosDelayCaLogError(f"invalid {label} page cursor")
        return Page(items, dict(cursor) if isinstance(cursor, Mapping) else None, bool(raw.get("exhausted")))

    def read_task(self, task_id: str) -> Snapshot:
        value, etag = self._read_with_etag(self._path(CA_TASKS_PATH, task_id, "task id"))
        if value in (None, {}):
            value = {}
        if not isinstance(value, dict):
            raise PosDelayCaLogError("invalid durable PosDelay task aggregate")
        return Snapshot(etag, dict(value))

    def cas_task(self, task_id: str, expected_revision: Any, replacement: Mapping[str, Any]) -> ReserveResult:
        path = self._path(CA_TASKS_PATH, task_id, "task id")
        current, etag = self._read_with_etag(path)
        if current not in (None, {}) and not isinstance(current, dict):
            raise PosDelayCaLogError("invalid durable PosDelay task aggregate")
        if etag != expected_revision:
            return ReserveResult(False, dict(current or {}), contention=True)
        candidate = dict(replacement)
        if not self._conditional_put(path, candidate, etag):
            return ReserveResult(False, dict(current or {}), contention=True)
        return ReserveResult(True, candidate)

    def read_receipt(self, receipt_id: str) -> GuardSnapshot:
        value, etag = self._read_with_etag(self._path(CA_RECEIPTS_PATH, receipt_id, "receipt id"))
        if value in (None, {}):
            value = {}
        if not isinstance(value, dict):
            raise PosDelayCaLogError("invalid durable PosDelay receipt")
        return GuardSnapshot(etag, dict(value))

    def cas_receipt(
        self,
        receipt_id: str,
        expected_revision: Any,
        replacement: Mapping[str, Any],
    ) -> ReserveResult:
        path = self._path(CA_RECEIPTS_PATH, receipt_id, "receipt id")
        current, etag = self._read_with_etag(path)
        current_state = dict(current) if isinstance(current, dict) else {}
        if current not in (None, {}) and not isinstance(current, dict):
            raise PosDelayCaLogError("invalid durable PosDelay receipt")
        if etag != expected_revision:
            return ReserveResult(False, current_state, contention=True)
        candidate = dict(replacement)
        if int(candidate.get("state_version") or 0) != int(current_state.get("state_version") or 0) + 1:
            raise PosDelayCaLogError("receipt state version mismatch")
        if not self._conditional_put(path, candidate, etag):
            return ReserveResult(False, current_state, contention=True)
        return ReserveResult(True, candidate)

    def read_receipt_page(self, limit: int, cursor: Mapping[str, Any] | None) -> Page:
        bounded_limit = max(1, min(1_000, int(limit)))
        raw = self._query_receipts_page(
            CA_RECEIPTS_PATH,
            limit=bounded_limit,
            cursor=dict(cursor) if isinstance(cursor, Mapping) else None,
        )
        page = self._parse_page(raw, bounded_limit, "committed-receipt")
        if any(receipt.get("receipt_status") != "committed" for receipt in page.items):
            raise PosDelayCaLogError("receipt page must contain only committed rows")
        return Page(
            [_public_receipt(receipt) for receipt in page.items],
            page.next_cursor,
            page.exhausted,
        )

    def reserve_outbox_batch(self, batch_key: str, record: Mapping[str, Any]) -> ReserveResult:
        return self._reserve_new(self._path(CA_BATCHES_PATH, batch_key, "batch key"), record)

    def reserve_quarantine(self, quarantine_id: str, row: Mapping[str, Any]) -> ReserveResult:
        path = self._path(CA_QUARANTINE_PATH, quarantine_id, "quarantine id")
        candidate = dict(row)
        for _ in range(4):
            current, etag = self._read_with_etag(path)
            if isinstance(current, dict):
                stable_keys = {
                    "schema", "domain", "resource", "quarantine_id", "rejection_code", "no_send", "sent"
                }
                if {key: current.get(key) for key in stable_keys} != {
                    key: candidate.get(key) for key in stable_keys
                }:
                    raise PosDelayCaLogError("conflicting durable quarantine")
                return ReserveResult(False, dict(current))
            if current not in (None, {}):
                raise PosDelayCaLogError("invalid durable quarantine")
            if self._conditional_put(path, candidate, etag):
                return ReserveResult(True, candidate)
        raise PosDelayCaLogError("durable quarantine contention")

    def read_projection_guard(self) -> GuardSnapshot:
        value, etag = self._read_with_etag(CA_GUARD_PATH)
        if value in (None, {}):
            value = {}
        if not isinstance(value, dict):
            raise PosDelayCaLogError("invalid durable projection guard")
        return GuardSnapshot(etag, dict(value))

    def cas_projection_guard(self, expected_revision: Any, replacement: Mapping[str, Any]) -> ReserveResult:
        current, etag = self._read_with_etag(CA_GUARD_PATH)
        current_state = dict(current) if isinstance(current, dict) else {}
        if current not in (None, {}) and not isinstance(current, dict):
            raise PosDelayCaLogError("invalid durable projection guard")
        if etag != expected_revision:
            return ReserveResult(False, current_state, contention=True)
        candidate = dict(replacement)
        if int(candidate.get("state_version") or 0) != int(current_state.get("state_version") or 0) + 1:
            raise PosDelayCaLogError("projection guard state version mismatch")
        current_fence = int(current_state.get("fencing_token") or 0)
        candidate_fence = int(candidate.get("fencing_token") or 0)
        if candidate_fence < current_fence or candidate_fence > current_fence + 1:
            raise PosDelayCaLogError("projection guard fencing mismatch")
        if not self._conditional_put(CA_GUARD_PATH, candidate, etag):
            return ReserveResult(False, current_state, contention=True)
        return ReserveResult(True, candidate)

    def read_outbox_guard(self) -> GuardSnapshot:
        value, etag = self._read_with_etag(CA_OUTBOX_GUARD_PATH)
        if value in (None, {}):
            value = {}
        if not isinstance(value, dict):
            raise PosDelayCaLogError("invalid durable outbox guard")
        return GuardSnapshot(etag, dict(value))

    def cas_outbox_guard(self, expected_revision: Any, replacement: Mapping[str, Any]) -> ReserveResult:
        current, etag = self._read_with_etag(CA_OUTBOX_GUARD_PATH)
        current_state = dict(current) if isinstance(current, dict) else {}
        if current not in (None, {}) and not isinstance(current, dict):
            raise PosDelayCaLogError("invalid durable outbox guard")
        if etag != expected_revision:
            return ReserveResult(False, current_state, contention=True)
        candidate = dict(replacement)
        if int(candidate.get("state_version") or 0) != int(current_state.get("state_version") or 0) + 1:
            raise PosDelayCaLogError("outbox guard state version mismatch")
        current_fence = int(current_state.get("fencing_token") or 0)
        candidate_fence = int(candidate.get("fencing_token") or 0)
        if candidate_fence < current_fence or candidate_fence > current_fence + 1:
            raise PosDelayCaLogError("outbox guard fencing mismatch")
        if not self._conditional_put(CA_OUTBOX_GUARD_PATH, candidate, etag):
            return ReserveResult(False, current_state, contention=True)
        return ReserveResult(True, candidate)

    def read_outbox_claim(self, receipt_id: str) -> GuardSnapshot:
        path = self._path(CA_OUTBOX_CLAIMS_PATH, receipt_id, "receipt id")
        value, etag = self._read_with_etag(path)
        if value in (None, {}):
            value = {}
        if not isinstance(value, dict):
            raise PosDelayCaLogError("invalid durable outbox claim")
        return GuardSnapshot(etag, dict(value))

    def cas_outbox_claim(
        self,
        receipt_id: str,
        expected_revision: Any,
        replacement: Mapping[str, Any],
    ) -> ReserveResult:
        path = self._path(CA_OUTBOX_CLAIMS_PATH, receipt_id, "receipt id")
        current, etag = self._read_with_etag(path)
        current_state = dict(current) if isinstance(current, dict) else {}
        if current not in (None, {}) and not isinstance(current, dict):
            raise PosDelayCaLogError("invalid durable outbox claim")
        if etag != expected_revision:
            return ReserveResult(False, current_state, contention=True)
        candidate = dict(replacement)
        if int(candidate.get("state_version") or 0) != int(current_state.get("state_version") or 0) + 1:
            raise PosDelayCaLogError("outbox claim state version mismatch")
        if int(candidate.get("fencing_token") or 0) < int(current_state.get("fencing_token") or 0):
            raise PosDelayCaLogError("outbox claim fencing mismatch")
        if not self._conditional_put(path, candidate, etag):
            return ReserveResult(False, current_state, contention=True)
        return ReserveResult(True, candidate)

    def read_pending_claim_page(self, limit: int, cursor: Mapping[str, Any] | None) -> Page:
        bounded_limit = max(1, min(1_000, int(limit)))
        raw = self._query_pending_outbox_claims_page(
            CA_OUTBOX_CLAIMS_PATH,
            limit=bounded_limit,
            cursor=dict(cursor) if isinstance(cursor, Mapping) else None,
        )
        return self._parse_page(raw, bounded_limit, "pending-claim")

    def reserve_delivery(self, request_id: str, row: Mapping[str, Any]) -> ReserveResult:
        return self._reserve_new(self._path(GATE_DELIVERIES_PATH, request_id, "request id"), row)

    def read_due_delivery_page(
        self,
        limit: int,
        now_ms: int,
        cursor: Mapping[str, Any] | None,
    ) -> Page:
        bounded_limit = max(1, min(1_000, int(limit)))
        raw = self._query_due_deliveries_page(
            GATE_DELIVERIES_PATH,
            now_ms=int(now_ms),
            limit=bounded_limit,
            cursor=dict(cursor) if isinstance(cursor, Mapping) else None,
        )
        return self._parse_page(raw, bounded_limit, "due-delivery")

    def read_delivery(self, request_id: str) -> Any:
        value, etag = self._read_with_etag(self._path(GATE_DELIVERIES_PATH, request_id, "request id"))
        if value in (None, {}):
            value = {}
        if not isinstance(value, dict):
            raise PosDelayCaLogError("invalid gate delivery row")
        return type("DeliverySnapshot", (), {"revision": etag, "row": dict(value)})()

    def cas_delivery(self, request_id: str, expected_revision: Any, replacement: Mapping[str, Any]) -> ReserveResult:
        path = self._path(GATE_DELIVERIES_PATH, request_id, "request id")
        current, etag = self._read_with_etag(path)
        if not isinstance(current, dict):
            raise PosDelayCaLogError("unknown gate delivery row")
        if etag != expected_revision:
            return ReserveResult(False, dict(current), contention=True)
        candidate = dict(replacement)
        if not self._conditional_put(path, candidate, etag):
            return ReserveResult(False, dict(current), contention=True)
        return ReserveResult(True, candidate)

    def _reserve_new(self, path: str, record: Mapping[str, Any]) -> ReserveResult:
        candidate = dict(record)
        for _ in range(4):
            current, etag = self._read_with_etag(path)
            if isinstance(current, dict):
                if current != candidate:
                    raise PosDelayCaLogError("conflicting durable reservation")
                return ReserveResult(False, dict(current))
            if current not in (None, {}):
                raise PosDelayCaLogError("invalid durable reservation")
            if self._conditional_put(path, candidate, etag):
                return ReserveResult(True, candidate)
        raise PosDelayCaLogError("durable reservation contention")


def _key(value: bytes | str) -> bytes:
    result = value.encode() if isinstance(value, str) else bytes(value)
    if len(result) < 32:
        raise PosDelayCaLogError("identity key must contain at least 32 bytes")
    return result


def _opaque(prefix: str, key: bytes, value: Any) -> str:
    payload = json.dumps(value, ensure_ascii=False, sort_keys=True, separators=(",", ":")).encode()
    return f"{prefix}_{hmac.new(key, payload, hashlib.sha256).hexdigest()[:32]}"


def _public_receipt(record: Mapping[str, Any]) -> dict[str, Any]:
    """Remove flat-SOT lifecycle metadata from the public receipt contract."""
    return {
        key: deepcopy(value)
        for key, value in record.items()
        if key in RECEIPT_KEYS or key == "sequence"
    }


class PosDelayCaLog:
    def __init__(
        self,
        *,
        identity_key: bytes | str,
        repository: Repository,
        live_send_approved: bool = False,
        max_per_minute: int = 20,
        coalesce_window_ms: int = 30_000,
        max_events_per_poll: int = 200,
        projection_lease_ms: int = 15_000,
        clock_ms: Callable[[], int] | None = None,
    ) -> None:
        if live_send_approved:
            raise PosDelayCaLogError("live CA send requires a separate approved transport stage")
        self.key = _key(identity_key)
        self.repository = repository
        self.max_per_minute = max(1, min(256, int(max_per_minute)))
        self.coalesce_window_ms = max(1, int(coalesce_window_ms))
        self.max_events_per_poll = max(1, min(1_000, int(max_events_per_poll)))
        self.projection_lease_ms = max(1_000, min(60_000, int(projection_lease_ms)))
        self.clock_ms = clock_ms or (lambda: time.time_ns() // 1_000_000)
        self._seen_event_ids: set[str] = set()
        self._seen_event_order: deque[str] = deque()

    def _live_now_ms(self, supplied_ms: int) -> int:
        return max(int(supplied_ms), int(self.clock_ms()))

    def observe_canonical_events(self, *, now_ms: int) -> list[dict[str, Any]]:
        """Read a bounded newest window and project unseen canonical events."""
        events = sorted(
            self.repository.read_ops_events(self.max_events_per_poll),
            key=_event_sort_key,
        )
        projected: list[dict[str, Any]] = []
        for event in events:
            event_id = str(event.get("event_id") or "")
            seen_key = event_id if OPAQUE_EVENT.fullmatch(event_id) else _opaque("pdpoison", self.key, event)
            if seen_key in self._seen_event_ids:
                continue
            try:
                receipt = self.observe_ops_event(event, now_ms=now_ms)
            except ContractRejected as exc:
                receipt = self._quarantine_or_retry(event, now_ms=now_ms, error=exc)
            except RepositoryTransient:
                receipt = self._repository_retry()
            except PosDelayCaLogError:
                receipt = self._repository_retry()
            except (TypeError, ValueError, OverflowError) as exc:
                receipt = self._quarantine_or_retry(event, now_ms=now_ms, error=exc)
            projected.append(receipt)
            if (
                receipt.get("receipt_id")
                or receipt.get("quarantine_id")
                or receipt.get("reason") == "late_start_reconciled"
            ):
                self._mark_event_seen(seen_key)
        return projected

    @staticmethod
    def _repository_retry() -> dict[str, Any]:
        return {
            "accepted": False,
            "reason": "repository_retry",
            "retryable": True,
            "no_send": True,
            "sent": False,
        }

    def _quarantine_or_retry(
        self,
        event: Mapping[str, Any],
        *,
        now_ms: int,
        error: Exception,
    ) -> dict[str, Any]:
        try:
            return self._quarantine_rejection(event, now_ms=now_ms, error=error)
        except (RepositoryTransient, PosDelayCaLogError):
            return self._repository_retry()

    def _mark_event_seen(self, event_id: str) -> None:
        if event_id in self._seen_event_ids:
            return
        while len(self._seen_event_order) >= self.max_events_per_poll:
            self._seen_event_ids.discard(self._seen_event_order.popleft())
        self._seen_event_order.append(event_id)
        self._seen_event_ids.add(event_id)

    def _quarantine_rejection(
        self,
        event: Mapping[str, Any],
        *,
        now_ms: int,
        error: Exception,
    ) -> dict[str, Any]:
        message = str(error)
        rejection_code = next(
            (
                code
                for marker, code in (
                    ("schema", "schema_mismatch"),
                    ("canonical", "identity_mismatch"),
                    ("approve", "send_flag_invalid"),
                    ("opaque", "opaque_id_invalid"),
                    ("transition", "transition_invalid"),
                    ("trigger", "trigger_invalid"),
                    ("decision source", "source_mapping_invalid"),
                    ("target", "target_mapping_invalid"),
                    ("timestamp", "timestamp_invalid"),
                    ("invalid literal", "type_invalid"),
                )
                if marker in message
            ),
            "contract_rejected",
        )
        quarantine_id = _opaque("pdreject", self.key, event)
        row = {
            "schema": REJECTION_SCHEMA,
            "domain": DOMAIN,
            "resource": RESOURCE,
            "quarantine_id": quarantine_id,
            "rejection_code": rejection_code,
            "occurred_at_ms": int(now_ms),
            "no_send": True,
            "sent": False,
        }
        reserved = self.repository.reserve_quarantine(quarantine_id, row)
        return deepcopy(dict(reserved.authoritative))

    def observe_ops_event(self, event: Mapping[str, Any], *, now_ms: int) -> dict[str, Any]:
        """Validate the exact Android publisher schema before creating a no-send receipt."""
        row = dict(event)
        if frozenset(row) != OPS_EVENT_KEYS:
            raise ContractRejected("canonical ops event schema mismatch")
        if row.get("schema") != OPS_EVENT_SCHEMA or row.get("domain") != DOMAIN:
            raise ContractRejected("canonical PosDelay ops event required")
        if row.get("telegram_send_approved") is not False:
            raise ContractRejected("Android publisher cannot approve Telegram delivery")
        event_id = str(row.get("event_id") or "")
        execution_id = str(row.get("execution_id") or "")
        if not OPAQUE_EVENT.fullmatch(event_id) or not OPAQUE_EXECUTION.fullmatch(execution_id):
            raise ContractRejected("opaque event and execution ids required")
        transition = str(row["transition"])
        if transition not in {"action_started", "action_result"}:
            raise ContractRejected("Android event transition is not allowlisted")
        if str(row.get("trigger_source")) not in {
            "count_change", "schedule", "manual", "firebase_cmd", "failover"
        }:
            raise ContractRejected("trigger source is not allowlisted")
        canonical_source = TASK_EXPECTED_SOURCE.get(str(row.get("task")))
        canonical_target = TASK_EXPECTED_TARGET.get(str(row.get("task")))
        if (
            canonical_source is None
            or row.get("expected_source") != canonical_source
            or row.get("decision_source") != canonical_source
        ):
            raise ContractRejected("task decision source does not match canonical mapping")
        if canonical_target is None or row.get("target") != canonical_target:
            raise ContractRejected("task target does not match canonical mapping")
        if transition == "action_started":
            task_id = _opaque("pdtask", self.key, {"private_occurrence_ref": execution_id})
            task_snapshot = self.repository.read_task(task_id)
            if task_snapshot.task.get("last_transition") == "action_result":
                return {
                    "accepted": False,
                    "reason": "late_start_reconciled",
                    "task_id": task_id,
                    "no_send": True,
                    "sent": False,
                }
        return self.append(
            private_occurrence_ref=execution_id,
            event_kind=str(row["event_kind"]),
            transition=transition,
            task=str(row["task"]),
            execution_path=str(row["execution_path"]),
            expected_source=str(row["expected_source"]),
            data_source=str(row["decision_source"]),
            target=str(row["target"]),
            result=str(row["result"]),
            severity=str(row["severity"]),
            kds_adjusted_count=int(row["kds_adjusted_count"]),
            kds_raw_count=int(row["kds_raw_count"]),
            kds_weighted_count=int(row["kds_weighted_count"]),
            printer_count=int(row["printer_count"]),
            observed_count=int(row["observed_count"]),
            duration_ms=int(row["duration_ms"]),
            source_updated_at_ms=int(row["source_updated_at_ms"]),
            source_revision=int(row["source_revision"]),
            settings_revision=int(row["settings_revision"]),
            occurred_at_ms=int(row["occurred_at_ms"]),
            now_ms=int(now_ms),
            evidence_pointer=str(row["evidence_pointer"]),
            origin=str(row["origin"]),
        )

    def append(
        self,
        *,
        private_occurrence_ref: str,
        event_kind: str,
        transition: str,
        task: str,
        execution_path: str,
        expected_source: str,
        data_source: str,
        target: str,
        result: str,
        severity: str,
        kds_adjusted_count: int,
        kds_raw_count: int,
        kds_weighted_count: int,
        printer_count: int,
        observed_count: int,
        duration_ms: int,
        source_updated_at_ms: int,
        source_revision: int,
        settings_revision: int,
        occurred_at_ms: int,
        now_ms: int,
        evidence_pointer: str,
        origin: str,
        attempt: int = 0,
    ) -> dict[str, Any]:
        if origin == SELF_ORIGIN:
            return {"accepted": False, "reason": "self_log_ignored", "no_send": True, "sent": False}
        values = {
            "event_kind": event_kind,
            "transition": transition,
            "task": task,
            "execution_path": execution_path,
            "expected_source": expected_source,
            "data_source": data_source,
            "target": target,
            "result": result,
            "severity": severity,
            "origin": origin,
        }
        allowed = {
            "event_kind": EVENT_KINDS,
            "transition": TRANSITIONS,
            "task": TASKS,
            "execution_path": EXECUTION_PATHS,
            "expected_source": SOURCES,
            "data_source": SOURCES,
            "target": TARGETS,
            "result": RESULTS,
            "severity": SEVERITIES,
            "origin": ORIGINS,
        }
        for field, value in values.items():
            if value not in allowed[field]:
                raise ContractRejected(f"{field} is not allowlisted")
        if TRANSITION_KIND[transition] != event_kind:
            raise ContractRejected("event kind/transition mismatch")
        if not private_occurrence_ref or not OPAQUE_EVIDENCE.fullmatch(evidence_pointer):
            raise ContractRejected("private occurrence and opaque evidence are required")
        numeric = (
            kds_adjusted_count, kds_raw_count, kds_weighted_count, printer_count,
            observed_count, duration_ms, source_updated_at_ms, source_revision,
            settings_revision, occurred_at_ms, now_ms,
        )
        if any(int(value) < 0 for value in numeric[:-2]) or int(occurred_at_ms) <= 0 or int(now_ms) <= 0:
            raise ContractRejected("counts, duration, revision or time are invalid")
        if int(occurred_at_ms) < int(now_ms) - 5 * 60_000 or int(occurred_at_ms) > int(now_ms) + 30_000:
            raise ContractRejected("receipt timestamp is stale or future")
        attempt_value = int(attempt)
        if transition.startswith("recovery_") and not 1 <= attempt_value <= 3:
            raise ContractRejected("recovery attempt is outside bounded range")
        task_id = _opaque("pdtask", self.key, {"private_occurrence_ref": private_occurrence_ref})
        coalesce_identity = {
            "task": task,
            "event_kind": event_kind,
            "transition": transition,
            "execution_path": execution_path,
            "expected_source": expected_source,
            "data_source": data_source,
            "target": target,
            "result": result,
            "severity": severity,
            "kds_adjusted_count": int(kds_adjusted_count),
            "kds_raw_count": int(kds_raw_count),
            "kds_weighted_count": int(kds_weighted_count),
            "printer_count": int(printer_count),
            "observed_count": int(observed_count),
            "source_revision": int(source_revision),
            "settings_revision": int(settings_revision),
        }
        if event_kind == "action":
            coalesce_identity["execution_task_id"] = task_id
        coalesce_key = _opaque("pdcoal", self.key, coalesce_identity)
        identity = {"task_id": task_id, "transition": transition, "attempt": attempt_value}
        receipt_id = _opaque("pdreceipt", self.key, identity)
        dedupe_key = _opaque("pddedupe", self.key, identity)
        initial_receipt = self.repository.read_receipt(receipt_id).state
        if initial_receipt:
            if initial_receipt.get("coalesce_key") != coalesce_key:
                raise ContractRejected("conflicting duplicate receipt")
        else:
            initial = self.repository.read_task(task_id)
            initial_previous = str(initial.task.get("last_transition") or "")
            initial_pending = initial.task.get("pending_receipt")
            if not isinstance(initial_pending, Mapping) and initial_previous not in PREDECESSORS[transition]:
                raise ContractRejected(
                    f"invalid lifecycle transition: {initial_previous or '<start>'}->{transition}"
                )
            if int(occurred_at_ms) < int(initial.task.get("last_occurred_at_ms") or 0):
                raise ContractRejected("receipt time must be monotonic")
        owner_id = "pdowner_" + secrets.token_hex(16)
        slot = self._acquire_projection_lease(
            coalesce_key=coalesce_key,
            task_id=task_id,
            receipt_id=receipt_id,
            owner_id=owner_id,
            now_ms=int(now_ms),
        )
        if slot.get("authoritative_receipt"):
            return deepcopy(dict(slot["authoritative_receipt"]))
        if slot.get("accepted") is False:
            return slot
        projection_fence = int(slot["projection_fence"])
        durable_receipt_started = False
        try:
            for _ in range(8):
                snapshot = self.repository.read_task(task_id)
                task_state = dict(snapshot.task)
                receipt_snapshot = self.repository.read_receipt(receipt_id)
                existing_state = dict(receipt_snapshot.state)
                existing = _public_receipt(existing_state)
                if transition == "action_started" and task_state.get("last_transition") == "action_result":
                    if existing_state.get("receipt_status") == "pending":
                        invalidated = {
                            **existing_state,
                            "receipt_status": "invalidated",
                            "state_version": int(existing_state.get("state_version") or 0) + 1,
                            "updated_at_ms": self._live_now_ms(now_ms),
                        }
                        self.repository.cas_receipt(receipt_id, receipt_snapshot.revision, invalidated)
                    return {
                        "accepted": False,
                        "reason": "late_start_reconciled",
                        "task_id": task_id,
                        "no_send": True,
                        "sent": False,
                    }
                pending = (
                    dict(task_state.get("pending_receipt"))
                    if isinstance(task_state.get("pending_receipt"), Mapping)
                    else None
                )
                if pending is not None and pending.get("receipt_id") != receipt_id:
                    if int(pending.get("expires_at_ms") or 0) > self._live_now_ms(now_ms):
                        raise RepositoryTransient("task lifecycle reservation pending")
                    if self._reconcile_stale_task_pending(task_id, snapshot, pending, now_ms=int(now_ms)):
                        continue
                    continue
                sequence = int(
                    (pending or {}).get("sequence")
                    or existing.get("sequence")
                    or (int(task_state.get("sequence") or 0) + 1)
                )
                receipt = {
                    "schema": RECEIPT_SCHEMA,
                    "domain": DOMAIN,
                    "resource": RESOURCE,
                    "receipt_id": receipt_id,
                    "task_id": task_id,
                    "event_kind": event_kind,
                    "transition": transition,
                    "attempt": attempt_value,
                    "execution_path": execution_path,
                    "expected_source": expected_source,
                    "sequence": sequence,
                    "data_source": data_source,
                    "target": target,
                    "result": result,
                    "severity": severity,
                    "kds_adjusted_count": int(kds_adjusted_count),
                    "kds_raw_count": int(kds_raw_count),
                    "kds_weighted_count": int(kds_weighted_count),
                    "printer_count": int(printer_count),
                    "observed_count": int(observed_count),
                    "duration_ms": int(duration_ms),
                    "source_updated_at_ms": int(source_updated_at_ms),
                    "source_revision": int(source_revision),
                    "settings_revision": int(settings_revision),
                    "occurred_at_ms": int(occurred_at_ms),
                    "evidence_pointer": evidence_pointer,
                    "dedupe_key": dedupe_key,
                    "coalesce_key": coalesce_key,
                    "projection_fence": projection_fence,
                    "origin": origin,
                    "no_send": True,
                    "sent": False,
                }
                if frozenset(receipt) != RECEIPT_KEYS | {"sequence"}:
                    raise ContractRejected("receipt schema mismatch")
                if existing_state:
                    candidate = {
                        **receipt,
                        "sequence": int(existing.get("sequence") or 0),
                        "projection_fence": int(existing.get("projection_fence") or 0),
                    }
                    if candidate != existing:
                        raise ContractRejected("conflicting duplicate receipt")
                    status = str(existing_state.get("receipt_status") or "")
                    if status == "invalidated":
                        if transition == "action_started":
                            return {
                                "accepted": False,
                                "reason": "late_start_reconciled",
                                "task_id": task_id,
                                "no_send": True,
                                "sent": False,
                            }
                        raise ContractRejected("receipt was invalidated")
                    if status not in {"pending", "committed"}:
                        raise ContractRejected("invalid receipt lifecycle state")
                    durable_receipt_started = True
                    stale_fence = int(existing.get("projection_fence") or 0)
                    if status == "committed":
                        self._commit_projection_lease(
                            coalesce_key=coalesce_key,
                            task_id=task_id,
                            receipt_id=receipt_id,
                            owner_id=owner_id,
                            projection_fence=projection_fence,
                            authoritative_fence=stale_fence,
                            committed_at_ms=int(now_ms),
                        )
                        return existing
                else:
                    previous = str(task_state.get("last_transition") or "")
                    if previous not in PREDECESSORS[transition]:
                        raise ContractRejected(f"invalid lifecycle transition: {previous or '<start>'}->{transition}")
                    if int(occurred_at_ms) < int(task_state.get("last_occurred_at_ms") or 0):
                        raise ContractRejected("receipt time must be monotonic")
                    if pending is None:
                        self._validate_projection_lease(
                            coalesce_key=coalesce_key,
                            owner_id=owner_id,
                            projection_fence=projection_fence,
                            now_ms=int(now_ms),
                        )
                        pending = {
                            "receipt_id": receipt_id,
                            "sequence": sequence,
                            "transition": transition,
                            "occurred_at_ms": int(occurred_at_ms),
                            "owner_id": owner_id,
                            "projection_fence": projection_fence,
                            "expires_at_ms": self._live_now_ms(now_ms) + self.projection_lease_ms,
                        }
                        task_pending = {
                            "task_id": task_id,
                            "sequence": int(task_state.get("sequence") or 0),
                            "last_transition": previous,
                            "last_occurred_at_ms": int(task_state.get("last_occurred_at_ms") or 0),
                            "last_receipt_id": str(task_state.get("last_receipt_id") or ""),
                            "pending_receipt": pending,
                        }
                        installed = self.repository.cas_task(task_id, snapshot.revision, task_pending)
                        if installed.contention:
                            continue
                        snapshot = Snapshot(None, task_pending)
                    self._validate_projection_lease(
                        coalesce_key=coalesce_key,
                        owner_id=owner_id,
                        projection_fence=projection_fence,
                        now_ms=int(now_ms),
                    )
                    storage = {
                        **receipt,
                        "receipt_status": "pending",
                        "state_version": 1,
                        "updated_at_ms": self._live_now_ms(now_ms),
                    }
                    reserved = self.repository.cas_receipt(receipt_id, receipt_snapshot.revision, storage)
                    if reserved.contention:
                        continue
                    existing_state = dict(reserved.authoritative)
                    existing = _public_receipt(existing_state)
                    stale_fence = int(existing.get("projection_fence") or 0)
                    durable_receipt_started = True

                self._validate_projection_lease(
                    coalesce_key=coalesce_key,
                    owner_id=owner_id,
                    projection_fence=projection_fence,
                    now_ms=int(now_ms),
                )
                task_after = self.repository.read_task(task_id)
                current_task = dict(task_after.task)
                current_pending = (
                    dict(current_task.get("pending_receipt"))
                    if isinstance(current_task.get("pending_receipt"), Mapping)
                    else None
                )
                if current_task.get("last_receipt_id") != receipt_id:
                    if not isinstance(current_pending, Mapping) or current_pending.get("receipt_id") != receipt_id:
                        if transition == "action_started" and current_task.get("last_transition") == "action_result":
                            continue
                        raise RepositoryTransient("task lifecycle pointer lost during receipt reconcile")
                    task_committed = {
                        "task_id": task_id,
                        "sequence": int(existing.get("sequence") or 0),
                        "last_transition": transition,
                        "last_occurred_at_ms": int(occurred_at_ms),
                        "last_receipt_id": receipt_id,
                    }
                    finalized = self.repository.cas_task(task_id, task_after.revision, task_committed)
                    if finalized.contention:
                        continue
                final_snapshot = self.repository.read_receipt(receipt_id)
                final_state = dict(final_snapshot.state)
                if final_state.get("receipt_status") == "pending":
                    committed_state = {
                        **final_state,
                        "receipt_status": "committed",
                        "state_version": int(final_state.get("state_version") or 0) + 1,
                        "updated_at_ms": self._live_now_ms(now_ms),
                    }
                    committed = self.repository.cas_receipt(
                        receipt_id,
                        final_snapshot.revision,
                        committed_state,
                    )
                    if committed.contention:
                        continue
                    final_state = dict(committed.authoritative)
                if final_state.get("receipt_status") != "committed":
                    raise RepositoryTransient("receipt commit did not converge")
                authoritative = _public_receipt(final_state)
                authoritative_fence = int(authoritative.get("projection_fence") or 0)
                self._commit_projection_lease(
                    coalesce_key=coalesce_key,
                    task_id=task_id,
                    receipt_id=receipt_id,
                    owner_id=owner_id,
                    projection_fence=projection_fence,
                    authoritative_fence=authoritative_fence,
                    committed_at_ms=int(now_ms),
                )
                return authoritative
            raise CasContention("receipt CAS contention")
        finally:
            if not durable_receipt_started:
                self._release_task_pending(
                    task_id=task_id,
                    receipt_id=receipt_id,
                    owner_id=owner_id,
                    projection_fence=projection_fence,
                )
                self._release_projection_lease(
                    coalesce_key=coalesce_key,
                    owner_id=owner_id,
                    projection_fence=projection_fence,
                    now_ms=int(now_ms),
                )

    def _read_receipt(self, task_id: str, receipt_id: str) -> dict[str, Any] | None:
        del task_id  # receipt_id is the independent flat-SOT key
        state = self.repository.read_receipt(receipt_id).state
        if state.get("receipt_status") != "committed":
            return None
        return _public_receipt(state)

    def _release_task_pending(
        self,
        *,
        task_id: str,
        receipt_id: str,
        owner_id: str,
        projection_fence: int,
    ) -> None:
        for _ in range(4):
            snapshot = self.repository.read_task(task_id)
            state = dict(snapshot.task)
            pending = state.get("pending_receipt")
            if not isinstance(pending, Mapping) or (
                pending.get("receipt_id") != receipt_id
                or pending.get("owner_id") != owner_id
                or int(pending.get("projection_fence") or 0) != projection_fence
            ):
                return
            replacement = {key: value for key, value in state.items() if key != "pending_receipt"}
            updated = self.repository.cas_task(task_id, snapshot.revision, replacement)
            if not updated.contention:
                return

    def _reconcile_stale_task_pending(
        self,
        task_id: str,
        snapshot: Snapshot,
        pending: Mapping[str, Any],
        *,
        now_ms: int,
    ) -> bool:
        pending_receipt_id = str(pending.get("receipt_id") or "")
        if not pending_receipt_id:
            raise ContractRejected("invalid task pending pointer")
        receipt_snapshot = self.repository.read_receipt(pending_receipt_id)
        receipt_state = dict(receipt_snapshot.state)
        if receipt_state.get("receipt_status") == "pending":
            public = _public_receipt(receipt_state)
            committed_task = {
                "task_id": task_id,
                "sequence": int(public.get("sequence") or 0),
                "last_transition": str(public.get("transition") or ""),
                "last_occurred_at_ms": int(public.get("occurred_at_ms") or 0),
                "last_receipt_id": pending_receipt_id,
            }
            updated_task = self.repository.cas_task(task_id, snapshot.revision, committed_task)
            if updated_task.contention:
                return False
            committed_receipt = {
                **receipt_state,
                "receipt_status": "committed",
                "state_version": int(receipt_state.get("state_version") or 0) + 1,
                "updated_at_ms": self._live_now_ms(now_ms),
            }
            self.repository.cas_receipt(
                pending_receipt_id,
                receipt_snapshot.revision,
                committed_receipt,
            )
            return True
        replacement = {key: value for key, value in snapshot.task.items() if key != "pending_receipt"}
        self.repository.cas_task(task_id, snapshot.revision, replacement)
        return True

    def _acquire_projection_lease(
        self,
        *,
        coalesce_key: str,
        task_id: str,
        receipt_id: str,
        owner_id: str,
        now_ms: int,
    ) -> dict[str, Any]:
        for _ in range(8):
            live_now_ms = self._live_now_ms(now_ms)
            snapshot = self.repository.read_projection_guard()
            state = dict(snapshot.state)
            raw_coalesce = state.get("coalesce") if isinstance(state.get("coalesce"), Mapping) else {}
            coalesce = {
                str(key): dict(value)
                for key, value in raw_coalesce.items()
                if isinstance(value, Mapping)
            }
            reaped, recovered_at_ms = self._reap_expired_projection_leases(
                coalesce=coalesce,
                now_ms=live_now_ms,
            )
            if reaped:
                replacement = self._guard_replacement(
                    state,
                    coalesce,
                    live_now_ms,
                    add_committed_at_values=recovered_at_ms,
                )
                updated = self.repository.cas_projection_guard(snapshot.revision, replacement)
                if updated.contention:
                    continue
                continue
            existing = coalesce.get(coalesce_key)
            if existing is not None:
                existing_task_id = str(existing.get("task_id") or "")
                existing_receipt_id = str(existing.get("receipt_id") or "")
                existing_fence = int(existing.get("projection_fence") or 0)
                authoritative = self._read_receipt(existing_task_id, existing_receipt_id)
                if authoritative is not None and int(authoritative.get("projection_fence") or 0) == existing_fence:
                    if existing.get("status") != "committed":
                        authoritative_at = int(authoritative.get("occurred_at_ms") or live_now_ms)
                        coalesce[coalesce_key] = {
                            **existing,
                            "status": "committed",
                            "committed_at_ms": authoritative_at,
                        }
                        replacement = self._guard_replacement(
                            state, coalesce, live_now_ms, add_committed_at_ms=authoritative_at
                        )
                        updated = self.repository.cas_projection_guard(snapshot.revision, replacement)
                        if updated.contention:
                            continue
                        if existing_receipt_id != receipt_id and (
                            live_now_ms - authoritative_at >= self.coalesce_window_ms
                        ):
                            continue
                    committed_at = int(
                        existing.get("committed_at_ms")
                        or authoritative.get("occurred_at_ms")
                        or 0
                    )
                    if existing_receipt_id == receipt_id or live_now_ms - committed_at < self.coalesce_window_ms:
                        return {"authoritative_receipt": authoritative}
                lease_fresh = (
                    existing.get("status") == "pending"
                    and int(existing.get("expires_at_ms") or 0) > live_now_ms
                )
                if lease_fresh:
                    raise RepositoryTransient("projection lease pending")
            recent = [
                int(value)
                for value in (state.get("recent_at_ms") or [])
                if int(value) >= live_now_ms - 60_000
            ]
            orphan_receipt = self._read_receipt(task_id, receipt_id)
            if orphan_receipt is not None:
                orphan_fence = int(orphan_receipt.get("projection_fence") or 0)
                coalesce[coalesce_key] = {
                    "status": "committed",
                    "owner_id": "compensated",
                    "task_id": task_id,
                    "receipt_id": receipt_id,
                    "projection_fence": orphan_fence,
                    "reserved_at_ms": live_now_ms,
                    "expires_at_ms": live_now_ms,
                    "committed_at_ms": live_now_ms,
                }
                replacement = self._guard_replacement(
                    state,
                    coalesce,
                    live_now_ms,
                    add_committed_at_ms=live_now_ms,
                    minimum_fence=orphan_fence,
                )
                updated = self.repository.cas_projection_guard(snapshot.revision, replacement)
                if updated.contention:
                    continue
                return {"authoritative_receipt": orphan_receipt}
            pending_capacity = sum(
                1
                for value in coalesce.values()
                if value.get("status") == "pending"
                and int(value.get("expires_at_ms") or 0) > live_now_ms
            )
            if len(recent) + pending_capacity >= self.max_per_minute:
                return {"accepted": False, "reason": "rate_limited", "no_send": True, "sent": False}
            fence = int(state.get("fencing_token") or 0) + 1
            coalesce[coalesce_key] = {
                "status": "pending",
                "owner_id": owner_id,
                "task_id": task_id,
                "receipt_id": receipt_id,
                "projection_fence": fence,
                "reserved_at_ms": live_now_ms,
                "expires_at_ms": live_now_ms + self.projection_lease_ms,
            }
            if len(coalesce) > 256:
                newest = sorted(
                    coalesce.items(),
                    key=lambda item: int(item[1].get("reserved_at_ms") or 0),
                    reverse=True,
                )[:256]
                coalesce = dict(newest)
            replacement = self._guard_replacement(state, coalesce, live_now_ms, minimum_fence=fence)
            updated = self.repository.cas_projection_guard(snapshot.revision, replacement)
            if updated.contention:
                continue
            return {
                "accepted": True,
                "owner_id": owner_id,
                "projection_fence": fence,
                "no_send": True,
                "sent": False,
            }
        raise CasContention("projection guard CAS contention")

    def _reap_expired_projection_leases(
        self,
        *,
        coalesce: dict[str, dict[str, Any]],
        now_ms: int,
    ) -> tuple[bool, list[int]]:
        changed = False
        recovered_at_ms: list[int] = []
        for key, slot in list(coalesce.items()):
            if slot.get("status") != "pending" or int(slot.get("expires_at_ms") or 0) > now_ms:
                continue
            task_id = str(slot.get("task_id") or "")
            receipt_id = str(slot.get("receipt_id") or "")
            authoritative = self._read_receipt(task_id, receipt_id) if task_id and receipt_id else None
            projection_fence = int(slot.get("projection_fence") or 0)
            if (
                authoritative is not None
                and int(authoritative.get("projection_fence") or 0) == projection_fence
            ):
                committed_at_ms = int(authoritative.get("occurred_at_ms") or now_ms)
                coalesce[key] = {
                    **slot,
                    "status": "committed",
                    "committed_at_ms": committed_at_ms,
                }
                recovered_at_ms.append(committed_at_ms)
            else:
                coalesce.pop(key, None)
            changed = True
        return changed, recovered_at_ms

    def _validate_projection_lease(
        self,
        *,
        coalesce_key: str,
        owner_id: str,
        projection_fence: int,
        now_ms: int,
    ) -> None:
        live_now_ms = self._live_now_ms(now_ms)
        snapshot = self.repository.read_projection_guard()
        slots = snapshot.state.get("coalesce") if isinstance(snapshot.state.get("coalesce"), Mapping) else {}
        slot = slots.get(coalesce_key) if isinstance(slots, Mapping) else None
        if not isinstance(slot, Mapping) or (
            slot.get("status") != "pending"
            or slot.get("owner_id") != owner_id
            or int(slot.get("projection_fence") or 0) != projection_fence
            or int(slot.get("expires_at_ms") or 0) <= live_now_ms
        ):
            raise RepositoryTransient("projection lease lost before receipt write")

    def _commit_projection_lease(
        self,
        *,
        coalesce_key: str,
        task_id: str,
        receipt_id: str,
        owner_id: str,
        projection_fence: int,
        committed_at_ms: int,
        authoritative_fence: int | None = None,
    ) -> None:
        receipt_fence = projection_fence if authoritative_fence is None else int(authoritative_fence)
        for _ in range(8):
            live_now_ms = self._live_now_ms(committed_at_ms)
            snapshot = self.repository.read_projection_guard()
            state = dict(snapshot.state)
            raw_slots = state.get("coalesce") if isinstance(state.get("coalesce"), Mapping) else {}
            slots = {str(key): dict(value) for key, value in raw_slots.items() if isinstance(value, Mapping)}
            slot = slots.get(coalesce_key)
            if not isinstance(slot, Mapping):
                raise RepositoryTransient("projection lease missing after receipt write")
            if (
                slot.get("status") == "committed"
                and slot.get("receipt_id") == receipt_id
                and int(slot.get("projection_fence") or 0) == receipt_fence
            ):
                return
            if (
                slot.get("status") != "pending"
                or slot.get("owner_id") != owner_id
                or slot.get("task_id") != task_id
                or slot.get("receipt_id") != receipt_id
                or int(slot.get("projection_fence") or 0) != projection_fence
            ):
                raise RepositoryTransient("stale projection holder cannot commit")
            authoritative = self._read_receipt(task_id, receipt_id)
            if authoritative is None or int(authoritative.get("projection_fence") or 0) != receipt_fence:
                raise RepositoryTransient("authoritative receipt missing during commit")
            slots[coalesce_key] = {
                **slot,
                "status": "committed",
                "projection_fence": receipt_fence,
                "superseded_projection_fence": projection_fence if receipt_fence != projection_fence else 0,
                "committed_at_ms": live_now_ms,
            }
            replacement = self._guard_replacement(
                state, slots, live_now_ms, add_committed_at_ms=live_now_ms
            )
            updated = self.repository.cas_projection_guard(snapshot.revision, replacement)
            if updated.contention:
                continue
            return
        raise CasContention("projection lease commit CAS contention")

    def _release_projection_lease(
        self,
        *,
        coalesce_key: str,
        owner_id: str,
        projection_fence: int,
        now_ms: int,
    ) -> None:
        for _ in range(4):
            live_now_ms = self._live_now_ms(now_ms)
            snapshot = self.repository.read_projection_guard()
            state = dict(snapshot.state)
            raw_slots = state.get("coalesce") if isinstance(state.get("coalesce"), Mapping) else {}
            slots = {str(key): dict(value) for key, value in raw_slots.items() if isinstance(value, Mapping)}
            slot = slots.get(coalesce_key)
            if not isinstance(slot, Mapping):
                return
            if (
                slot.get("status") != "pending"
                or slot.get("owner_id") != owner_id
                or int(slot.get("projection_fence") or 0) != projection_fence
            ):
                return
            slots.pop(coalesce_key, None)
            replacement = self._guard_replacement(state, slots, live_now_ms)
            updated = self.repository.cas_projection_guard(snapshot.revision, replacement)
            if updated.contention:
                continue
            return
        raise CasContention("projection lease release CAS contention")

    @staticmethod
    def _guard_replacement(
        state: Mapping[str, Any],
        coalesce: Mapping[str, Any],
        now_ms: int,
        *,
        add_committed_at_ms: int | None = None,
        add_committed_at_values: Sequence[int] = (),
        minimum_fence: int = 0,
    ) -> dict[str, Any]:
        recent = [
            int(value)
            for value in (state.get("recent_at_ms") or [])
            if int(value) >= now_ms - 60_000
        ]
        if add_committed_at_ms is not None:
            recent.append(int(add_committed_at_ms))
        recent.extend(int(value) for value in add_committed_at_values)
        return {
            "schema": "posdelay.ca_projection_guard.v2",
            "state_version": int(state.get("state_version") or 0) + 1,
            "fencing_token": max(int(state.get("fencing_token") or 0), int(minimum_fence)),
            "coalesce": dict(coalesce),
            "recent_at_ms": recent[-256:],
            "updated_at_ms": now_ms,
        }

    def pending_ca_outbox(self, *, room_registry_ref: str, now_ms: int, aggregate_size: int = 8) -> list[dict[str, Any]]:
        if not re.fullmatch(r"pdroom_[0-9a-f]{32,64}", room_registry_ref):
            raise PosDelayCaLogError("opaque PosDelay room registry ref required")
        del aggregate_size  # receipt-scoped claims intentionally avoid partial multi-receipt ownership
        preliminary = self.repository.read_receipt_page(self.max_events_per_poll, None)
        del preliminary
        owner_id = "pdoutboxowner_" + secrets.token_hex(16)
        lease = self._acquire_outbox_lease(owner_id=owner_id, now_ms=int(now_ms))
        if lease is None:
            self.repository.read_due_delivery_page(self.max_events_per_poll, int(now_ms), None)
            return []
        outbox_fence = int(lease["fencing_token"])
        try:
            guard_state = self._validate_outbox_lease(
                owner_id=owner_id,
                fencing_token=outbox_fence,
                now_ms=int(now_ms),
            )
            claim_cursor = (
                dict(guard_state.get("claim_cursor"))
                if isinstance(guard_state.get("claim_cursor"), Mapping)
                else None
            )
            rows, next_claim_cursor = self._recover_outbox_claims(
                owner_id=owner_id,
                fencing_token=outbox_fence,
                now_ms=int(now_ms),
                cursor=claim_cursor,
            )
            guard_state = self._validate_outbox_lease(
                owner_id=owner_id,
                fencing_token=outbox_fence,
                now_ms=int(now_ms),
            )
            receipt_cursor = (
                dict(guard_state.get("receipt_cursor"))
                if isinstance(guard_state.get("receipt_cursor"), Mapping)
                else None
            )
            receipt_page = self.repository.read_receipt_page(self.max_events_per_poll, receipt_cursor)
            for receipt in sorted(receipt_page.items, key=lambda row: str(row.get("receipt_id") or "")):
                if receipt.get("no_send") is not True:
                    continue
                receipt_id = str(receipt.get("receipt_id") or "")
                claim = self._claim_outbox_receipt(
                    room_registry_ref=room_registry_ref,
                    receipt_id=receipt_id,
                    owner_id=owner_id,
                    fencing_token=outbox_fence,
                    now_ms=int(now_ms),
                )
                if claim is not None:
                    rows.append(self._materialize_outbox_claim(
                        claim,
                        owner_id=owner_id,
                        fencing_token=outbox_fence,
                        now_ms=int(now_ms),
                    ))
            self._advance_outbox_cursors(
                owner_id=owner_id,
                fencing_token=outbox_fence,
                receipt_cursor=receipt_page.next_cursor,
                claim_cursor=next_claim_cursor,
                now_ms=int(now_ms),
            )
            return rows
        finally:
            self._release_outbox_lease(
                owner_id=owner_id,
                fencing_token=outbox_fence,
                now_ms=int(now_ms),
            )

    def _acquire_outbox_lease(self, *, owner_id: str, now_ms: int) -> dict[str, Any] | None:
        for _ in range(8):
            live_now_ms = self._live_now_ms(now_ms)
            snapshot = self.repository.read_outbox_guard()
            state = dict(snapshot.state)
            if (
                state.get("status") == "pending"
                and int(state.get("expires_at_ms") or 0) > live_now_ms
                and state.get("owner_id") != owner_id
            ):
                continue
            fence = int(state.get("fencing_token") or 0) + 1
            replacement = {
                "schema": "posdelay.ca_outbox_guard.v1",
                "state_version": int(state.get("state_version") or 0) + 1,
                "fencing_token": fence,
                "status": "pending",
                "owner_id": owner_id,
                "reserved_at_ms": live_now_ms,
                "expires_at_ms": live_now_ms + self.projection_lease_ms,
                "receipt_cursor": deepcopy(state.get("receipt_cursor")),
                "claim_cursor": deepcopy(state.get("claim_cursor")),
                "updated_at_ms": live_now_ms,
            }
            updated = self.repository.cas_outbox_guard(snapshot.revision, replacement)
            if updated.contention:
                continue
            return deepcopy(dict(updated.authoritative))
        return None

    def _validate_outbox_lease(self, *, owner_id: str, fencing_token: int, now_ms: int) -> dict[str, Any]:
        live_now_ms = self._live_now_ms(now_ms)
        state = self.repository.read_outbox_guard().state
        if (
            state.get("status") != "pending"
            or state.get("owner_id") != owner_id
            or int(state.get("fencing_token") or 0) != fencing_token
            or int(state.get("expires_at_ms") or 0) <= live_now_ms
        ):
            raise RepositoryTransient("outbox lease lost before assignment")
        return dict(state)

    def _claim_outbox_receipt(
        self,
        *,
        room_registry_ref: str,
        receipt_id: str,
        owner_id: str,
        fencing_token: int,
        now_ms: int,
    ) -> dict[str, Any] | None:
        refs = [receipt_id]
        batch_key = _opaque("pdbatch", self.key, {"room": room_registry_ref, "refs": refs})
        request_id = _opaque("pddelivery", self.key, {"batch_key": batch_key})
        for _ in range(8):
            live_now_ms = self._live_now_ms(now_ms)
            self._validate_outbox_lease(
                owner_id=owner_id,
                fencing_token=fencing_token,
                now_ms=live_now_ms,
            )
            snapshot = self.repository.read_outbox_claim(receipt_id)
            state = dict(snapshot.state)
            existing_request_id = str(state.get("request_id") or "")
            if existing_request_id:
                delivery = self.repository.read_delivery(existing_request_id).row
                if isinstance(delivery, Mapping) and delivery.get("request_id") == existing_request_id:
                    if state.get("status") != "committed":
                        replacement = {
                            **state,
                            "state_version": int(state.get("state_version") or 0) + 1,
                            "status": "committed",
                            "owner_id": "compensated",
                            "updated_at_ms": live_now_ms,
                        }
                        updated = self.repository.cas_outbox_claim(receipt_id, snapshot.revision, replacement)
                        if updated.contention:
                            continue
                    return None
                if state.get("status") == "committed":
                    raise RepositoryTransient("committed outbox claim is missing delivery")
            claim = {
                "schema": "posdelay.ca_outbox_claim.v1",
                "state_version": int(state.get("state_version") or 0) + 1,
                "fencing_token": fencing_token,
                "status": "pending",
                "owner_id": owner_id,
                "receipt_id": receipt_id,
                "batch_key": batch_key,
                "request_id": request_id,
                "room_registry_ref": room_registry_ref,
                "receipt_refs": refs,
                "assigned_at_ms": live_now_ms,
                "updated_at_ms": live_now_ms,
                "expires_at_ms": live_now_ms + self.projection_lease_ms,
            }
            updated = self.repository.cas_outbox_claim(receipt_id, snapshot.revision, claim)
            if updated.contention:
                continue
            return deepcopy(dict(updated.authoritative))
        raise CasContention("outbox receipt claim CAS contention")

    def _recover_outbox_claims(
        self,
        *,
        owner_id: str,
        fencing_token: int,
        now_ms: int,
        cursor: Mapping[str, Any] | None,
    ) -> tuple[list[dict[str, Any]], Mapping[str, Any] | None]:
        recovered: list[dict[str, Any]] = []
        page = self.repository.read_pending_claim_page(self.max_events_per_poll, cursor)
        for existing in page.items:
            receipt_id = str(existing.get("receipt_id") or "")
            room_registry_ref = str(existing.get("room_registry_ref") or "")
            if not receipt_id or not room_registry_ref:
                continue
            claim = self._claim_outbox_receipt(
                room_registry_ref=room_registry_ref,
                receipt_id=receipt_id,
                owner_id=owner_id,
                fencing_token=fencing_token,
                now_ms=now_ms,
            )
            if claim is not None:
                recovered.append(self._materialize_outbox_claim(
                    claim,
                    owner_id=owner_id,
                    fencing_token=fencing_token,
                    now_ms=now_ms,
                ))
        return recovered, page.next_cursor

    def _materialize_outbox_claim(
        self,
        claim: Mapping[str, Any],
        *,
        owner_id: str,
        fencing_token: int,
        now_ms: int,
    ) -> dict[str, Any]:
        refs = [str(value) for value in (claim.get("receipt_refs") or [])]
        receipt_id = str(claim.get("receipt_id") or "")
        batch_key = str(claim.get("batch_key") or "")
        request_id = str(claim.get("request_id") or "")
        room_registry_ref = str(claim.get("room_registry_ref") or "")
        self._validate_outbox_claim(receipt_id, request_id, owner_id, fencing_token)
        batch = self.repository.reserve_outbox_batch(
            batch_key,
            {"kind": "posdelay_ops_event", "room_registry_ref": room_registry_ref, "receipt_refs": refs},
        )
        row = {
            "schema": DELIVERY_SCHEMA,
            "domain": DOMAIN,
            "resource": RESOURCE,
            "status": "waiting",
            "request_id": request_id,
            "task_id": request_id,
            "queue": "posdelay_ca_status",
            "request_path": f"/packhelper/openclaw_telegram_gate/posdelay_ca_payloads/{request_id}",
            "result_path": "",
            "target": "phone",
            "target_node": "personal_wonmux_codex",
            "participant_id": "personal",
            "resource_id": "personal_wonmux_codex",
            "capability": "posdelay_status_only",
            "lifecycle_state": "request",
            "ingress_account_id": "personal",
            "reply_account_id": "personal",
            "conversation_id": room_registry_ref,
            "room_kind": "ca_expert",
            "thread_id": "",
            "source_message_id": "",
            "created_at_ms": int(claim.get("assigned_at_ms") or now_ms),
            "attempt_count": 0,
            "next_attempt_at_ms": 0,
            "delivery_kind": "posdelay_ops_event",
            "receipt_refs": list(batch.authoritative.get("receipt_refs") or refs),
            "aggregate_count": len(refs),
            "assignment_claim_id": receipt_id,
            "no_send": True,
            "sent": False,
        }
        reserved = self.repository.reserve_delivery(request_id, row)
        self._commit_outbox_claim(
            receipt_id=receipt_id,
            request_id=request_id,
            owner_id=owner_id,
            fencing_token=fencing_token,
            now_ms=now_ms,
        )
        return deepcopy(dict(reserved.authoritative))

    def _validate_outbox_claim(
        self,
        receipt_id: str,
        request_id: str,
        owner_id: str,
        fencing_token: int,
    ) -> None:
        claim = self.repository.read_outbox_claim(receipt_id).state
        if (
            claim.get("status") != "pending"
            or claim.get("request_id") != request_id
            or claim.get("owner_id") != owner_id
            or int(claim.get("fencing_token") or 0) != fencing_token
        ):
            raise RepositoryTransient("outbox claim lost before materialization")

    def _commit_outbox_claim(
        self,
        *,
        receipt_id: str,
        request_id: str,
        owner_id: str,
        fencing_token: int,
        now_ms: int,
    ) -> None:
        for _ in range(8):
            live_now_ms = self._live_now_ms(now_ms)
            self._validate_outbox_lease(
                owner_id=owner_id,
                fencing_token=fencing_token,
                now_ms=live_now_ms,
            )
            snapshot = self.repository.read_outbox_claim(receipt_id)
            claim = dict(snapshot.state)
            if claim.get("status") == "committed" and claim.get("request_id") == request_id:
                return
            if (
                claim.get("status") != "pending"
                or claim.get("request_id") != request_id
                or claim.get("owner_id") != owner_id
                or int(claim.get("fencing_token") or 0) != fencing_token
            ):
                raise RepositoryTransient("stale outbox claim holder cannot commit")
            delivery = self.repository.read_delivery(request_id).row
            if not isinstance(delivery, Mapping) or delivery.get("assignment_claim_id") != receipt_id:
                raise RepositoryTransient("authoritative delivery missing during outbox commit")
            replacement = {
                **claim,
                "state_version": int(claim.get("state_version") or 0) + 1,
                "status": "committed",
                "updated_at_ms": live_now_ms,
            }
            updated = self.repository.cas_outbox_claim(receipt_id, snapshot.revision, replacement)
            if updated.contention:
                continue
            return
        raise CasContention("outbox claim commit CAS contention")

    def _advance_outbox_cursors(
        self,
        *,
        owner_id: str,
        fencing_token: int,
        receipt_cursor: Mapping[str, Any] | None,
        claim_cursor: Mapping[str, Any] | None,
        now_ms: int,
    ) -> None:
        for _ in range(8):
            live_now_ms = self._live_now_ms(now_ms)
            snapshot = self.repository.read_outbox_guard()
            state = dict(snapshot.state)
            if (
                state.get("status") != "pending"
                or state.get("owner_id") != owner_id
                or int(state.get("fencing_token") or 0) != fencing_token
                or int(state.get("expires_at_ms") or 0) <= live_now_ms
            ):
                raise RepositoryTransient("outbox lease lost before cursor commit")
            replacement = {
                **state,
                "state_version": int(state.get("state_version") or 0) + 1,
                "receipt_cursor": dict(receipt_cursor) if isinstance(receipt_cursor, Mapping) else None,
                "claim_cursor": dict(claim_cursor) if isinstance(claim_cursor, Mapping) else None,
                "updated_at_ms": live_now_ms,
            }
            updated = self.repository.cas_outbox_guard(snapshot.revision, replacement)
            if updated.contention:
                continue
            return
        raise CasContention("outbox cursor CAS contention")

    def _release_outbox_lease(self, *, owner_id: str, fencing_token: int, now_ms: int) -> None:
        for _ in range(4):
            live_now_ms = self._live_now_ms(now_ms)
            snapshot = self.repository.read_outbox_guard()
            state = dict(snapshot.state)
            if (
                state.get("status") != "pending"
                or state.get("owner_id") != owner_id
                or int(state.get("fencing_token") or 0) != fencing_token
            ):
                return
            replacement = {
                **state,
                "state_version": int(state.get("state_version") or 0) + 1,
                "status": "released",
                "expires_at_ms": live_now_ms,
                "updated_at_ms": live_now_ms,
            }
            updated = self.repository.cas_outbox_guard(snapshot.revision, replacement)
            if updated.contention:
                continue
            return
        raise CasContention("outbox lease release CAS contention")

    def mark_delivery(self, request_id: str, *, delivered: bool, now_ms: int) -> dict[str, Any]:
        if delivered:
            raise PosDelayCaLogError("default-off PosDelay CA rows cannot be marked delivered")
        for _ in range(4):
            snapshot = self.repository.read_delivery(request_id)
            row = dict(snapshot.row)
            if not row or row.get("domain") != DOMAIN or row.get("no_send") is not True:
                raise PosDelayCaLogError("unknown or sendable delivery row")
            attempts = int(row.get("attempt_count") or 0) + 1
            replacement = {
                **row,
                "status": "retry",
                "lifecycle_state": "delivery_retry",
                "attempt_count": attempts,
                "next_attempt_at_ms": int(now_ms) + min(300_000, 5_000 * (2 ** min(attempts - 1, 6))),
                "no_send": True,
                "sent": False,
            }
            updated = self.repository.cas_delivery(request_id, snapshot.revision, replacement)
            if updated.contention:
                continue
            return deepcopy(dict(updated.authoritative))
        raise PosDelayCaLogError("delivery retry CAS contention")

    def reconnect_replay(self, *, now_ms: int) -> list[dict[str, Any]]:
        rows: list[dict[str, Any]] = []
        cursor: Mapping[str, Any] | None = None
        for _ in range(10_000):
            page = self.repository.read_due_delivery_page(
                self.max_events_per_poll,
                int(now_ms),
                cursor,
            )
            rows.extend(
                deepcopy(dict(row))
                for row in page.items
                if row.get("domain") == DOMAIN
                and row.get("no_send") is True
                and row.get("status") == "retry"
                and int(row.get("next_attempt_at_ms") or 0) <= int(now_ms)
            )
            if page.exhausted:
                return rows
            if page.next_cursor is None or page.next_cursor == cursor:
                raise RepositoryTransient("due-delivery cursor did not advance")
            cursor = page.next_cursor
        raise RepositoryTransient("due-delivery pagination exceeded safety bound")


__all__ = [
    "CasContention", "ContractRejected", "DOMAIN", "DELIVERY_SCHEMA", "FakeCasRepository",
    "OPS_EVENT_KEYS", "OPS_EVENT_SCHEMA", "Page", "PosDelayCaLog", "PosDelayCaLogError",
    "PosDelayFirebaseCasRepository", "RECEIPT_KEYS", "RECEIPT_SCHEMA", "RepositoryTransient",
    "ReserveResult", "RESOURCE", "SELF_ORIGIN",
]
