#!/usr/bin/env bash
set -euo pipefail

ROOT_DIR="${STOREBOT_CODEX_ROOT:-/root/my-first-project}"
LOG_DIR="${STOREBOT_CODEX_LOG_DIR:-/root/StoreBot/bot/logs}"
POLL_SEC="${STOREBOT_CODEX_POLL_SEC:-5}"
LOCK_DIR="${STOREBOT_CODEX_LOCK_DIR:-/tmp/storebot_codex_worker.lock}"
MODEL="${STOREBOT_CODEX_MODEL:-gpt-5.6-terra}"
REASONING_EFFORT="${STOREBOT_CODEX_REASONING_EFFORT:-low}"
TIMEOUT_SEC="${STOREBOT_CODEX_TIMEOUT_SEC:-540}"
IMPROVEMENT_REPORT_ENABLED="${STOREBOT_IMPROVEMENT_REPORT_ENABLED:-1}"
export STOREBOT_FAST_BRAIN_ENABLED="${STOREBOT_FAST_BRAIN_ENABLED:-0}"

load_fast_brain_secret_env() {
  local paths raw_path path mode line key value loaded_keys ignored_count mode_warn key_list
  paths="${STOREBOT_FAST_BRAIN_ENV_PATHS:-/data/data/com.sbotux/files/home/.storebot_fast_brain.env:/data/data/com.sbotux/files/usr/var/lib/storebot/fast_brain.env:/root/.storebot_fast_brain.env}"
  export STOREBOT_FAST_BRAIN_SECRET_LOADED=0
  export STOREBOT_FAST_BRAIN_SECRET_SOURCE=""
  export STOREBOT_FAST_BRAIN_SECRET_KEYS=""
  export STOREBOT_FAST_BRAIN_SECRET_REASON="no_local_secret_file"
  export STOREBOT_FAST_BRAIN_SECRET_MODE_WARNING=""
  export STOREBOT_FAST_BRAIN_SECRET_IGNORED_COUNT=0

  IFS=':' read -r -a secret_paths <<< "$paths"
  for raw_path in "${secret_paths[@]}"; do
    path="${raw_path/#\~/$HOME}"
    if [ ! -f "$path" ]; then
      continue
    fi
    if [ ! -r "$path" ]; then
      export STOREBOT_FAST_BRAIN_SECRET_REASON="secret_file_not_readable"
      export STOREBOT_FAST_BRAIN_SECRET_SOURCE="$path"
      return 0
    fi

    mode="$(stat -c '%a' "$path" 2>/dev/null || stat -f '%Lp' "$path" 2>/dev/null || true)"
    mode_warn=""
    if [ -n "$mode" ]; then
      case "$mode" in
        *[1-7][0-7]|*[0-7][1-7])
          mode_warn="file_mode_too_broad"
          ;;
      esac
    fi

    key_list=""
    ignored_count=0
    while IFS= read -r line || [ -n "$line" ]; do
      line="${line#"${line%%[![:space:]]*}"}"
      line="${line%"${line##*[![:space:]]}"}"
      case "$line" in
        ""|\#*)
          continue
          ;;
      esac
      if [[ "$line" != *=* ]]; then
        ignored_count=$((ignored_count + 1))
        continue
      fi
      key="${line%%=*}"
      value="${line#*=}"
      key="${key#"${key%%[![:space:]]*}"}"
      key="${key%"${key##*[![:space:]]}"}"
      value="${value#"${value%%[![:space:]]*}"}"
      value="${value%"${value##*[![:space:]]}"}"
      if [[ "$value" == \"*\" && "$value" == *\" && ${#value} -ge 2 ]]; then
        value="${value:1:${#value}-2}"
      elif [[ "$value" == \'*\' && "$value" == *\' && ${#value} -ge 2 ]]; then
        value="${value:1:${#value}-2}"
      fi
      case "$key" in
        GROQ_API_KEY|OPENAI_API_KEY|STOREBOT_FAST_BRAIN_PROVIDER|STOREBOT_FAST_BRAIN_MODEL|STOREBOT_FAST_BRAIN_TIMEOUT_SEC|STOREBOT_FAST_BRAIN_MAX_TOKENS|STOREBOT_FAST_BRAIN_REASONING_EFFORT|STOREBOT_GROQ_MODEL|GROQ_MODEL|OPENAI_MODEL|STOREBOT_GROQ_REASONING_EFFORT)
          export "$key=$value"
          case ",$key_list," in
            *,"$key",*) ;;
            *) key_list="${key_list:+$key_list,}$key" ;;
          esac
          ;;
        *)
          ignored_count=$((ignored_count + 1))
          ;;
      esac
    done < "$path"

    if [ -n "$key_list" ]; then
      loaded_keys="$key_list"
      export STOREBOT_FAST_BRAIN_SECRET_LOADED=1
      export STOREBOT_FAST_BRAIN_SECRET_SOURCE="$path"
      export STOREBOT_FAST_BRAIN_SECRET_KEYS="$loaded_keys"
      export STOREBOT_FAST_BRAIN_SECRET_REASON=""
      export STOREBOT_FAST_BRAIN_SECRET_MODE_WARNING="$mode_warn"
      export STOREBOT_FAST_BRAIN_SECRET_IGNORED_COUNT="$ignored_count"
      return 0
    fi

    export STOREBOT_FAST_BRAIN_SECRET_LOADED=0
    export STOREBOT_FAST_BRAIN_SECRET_SOURCE="$path"
    export STOREBOT_FAST_BRAIN_SECRET_KEYS=""
    export STOREBOT_FAST_BRAIN_SECRET_REASON="no_allowed_keys_in_secret_file"
    export STOREBOT_FAST_BRAIN_SECRET_MODE_WARNING="$mode_warn"
    export STOREBOT_FAST_BRAIN_SECRET_IGNORED_COUNT="$ignored_count"
    return 0
  done
}

if [ "$STOREBOT_FAST_BRAIN_ENABLED" = "1" ] && [ "${STOREBOT_FAST_BRAIN_LOAD_SECRET:-0}" = "1" ]; then
  load_fast_brain_secret_env
else
  export STOREBOT_FAST_BRAIN_SECRET_LOADED=0
  export STOREBOT_FAST_BRAIN_SECRET_SOURCE=""
  export STOREBOT_FAST_BRAIN_SECRET_KEYS=""
  export STOREBOT_FAST_BRAIN_SECRET_REASON="disabled_by_default"
  export STOREBOT_FAST_BRAIN_SECRET_MODE_WARNING=""
  export STOREBOT_FAST_BRAIN_SECRET_IGNORED_COUNT=0
fi

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
SECURE_CA_ENV_LOADER="${SECURE_CA_ENV_LOADER:-$SCRIPT_DIR/secure_ca_env.sh}"
if [ ! -r "$SECURE_CA_ENV_LOADER" ]; then
  SECURE_CA_ENV_LOADER="$SCRIPT_DIR/../scripts/secure_ca_env.sh"
fi
STOREBOT_CA_ENV_FILE="${STOREBOT_CA_ENV_FILE:-$HOME/.config/wonmux/ca-live.env}"
if [ ! -r "$SECURE_CA_ENV_LOADER" ]; then
  echo "secure CA env loader not found: $SECURE_CA_ENV_LOADER" >&2
  exit 66
fi
# shellcheck source=scripts/secure_ca_env.sh
source "$SECURE_CA_ENV_LOADER"
wonmux_load_secure_ca_env "$STOREBOT_CA_ENV_FILE" "${STOREBOT_CA_ENV_REQUIRED:-0}"

export STOREBOT_CODEX_HOME="${STOREBOT_CODEX_HOME:-$HOME/.storebot_codex_home}"
export STOREBOT_CODEX_RESIDENT_CODEX_HOME="${STOREBOT_CODEX_RESIDENT_CODEX_HOME:-$STOREBOT_CODEX_HOME}"
export PATH="$HOME/.local/bin:$HOME/.codex/bin:/usr/local/bin:/usr/bin:/bin:$PATH"
if [ -d "$HOME/.nvm/versions/node" ]; then
  NVM_NODE_BIN="$(find "$HOME/.nvm/versions/node" -mindepth 2 -maxdepth 2 -type d -name bin 2>/dev/null | sort | tail -n 1 || true)"
  if [ -n "$NVM_NODE_BIN" ]; then
    export PATH="$NVM_NODE_BIN:$PATH"
  fi
fi
export STOREBOT_CODEX_LOCAL_DIRECT_HOST="${STOREBOT_CODEX_LOCAL_DIRECT_HOST:-127.0.0.1}"
export STOREBOT_CODEX_LOCAL_DIRECT_PORT="${STOREBOT_CODEX_LOCAL_DIRECT_PORT:-8765}"
export STOREBOT_CODEX_LOCAL_DIRECT_SYNC_TIMEOUT_SEC="${STOREBOT_CODEX_LOCAL_DIRECT_SYNC_TIMEOUT_SEC_OVERRIDE:-0}"
export STOREBOT_CODEX_LOCAL_DIRECT_DEFERRED_PUBLISH="${STOREBOT_CODEX_LOCAL_DIRECT_DEFERRED_PUBLISH_OVERRIDE:-0}"
export STOREBOT_CODEX_LOCAL_DIRECT_DEFERRED_REPLY="${STOREBOT_CODEX_LOCAL_DIRECT_DEFERRED_REPLY:-}"
export STOREBOT_CODEX_LOCAL_DIRECT_ERROR_REPLY="${STOREBOT_CODEX_LOCAL_DIRECT_ERROR_REPLY:-}"
export STOREBOT_CODEX_BRIDGE_MODE="${STOREBOT_CODEX_BRIDGE_MODE:-dedicated_persistent_phase1}"
export STOREBOT_CODEX_SELF_SYNC="${STOREBOT_CODEX_SELF_SYNC:-0}"
export STOREBOT_CODEX_RESIDENT_APP_SERVER="${STOREBOT_CODEX_RESIDENT_APP_SERVER_OVERRIDE:-1}"
export STOREBOT_CODEX_RESIDENT_FALLBACK_EXEC="${STOREBOT_CODEX_RESIDENT_FALLBACK_EXEC_OVERRIDE:-0}"
export STOREBOT_CODEX_RESIDENT_REVIVE_ON_FAILURE="${STOREBOT_CODEX_RESIDENT_REVIVE_ON_FAILURE_OVERRIDE:-1}"
export STOREBOT_CODEX_RESIDENT_SESSION_PREBOOT="${STOREBOT_CODEX_RESIDENT_SESSION_PREBOOT:-1}"
export STOREBOT_CODEX_RESIDENT_SESSION_WATCHDOG="${STOREBOT_CODEX_RESIDENT_SESSION_WATCHDOG:-1}"
export STOREBOT_CODEX_RESIDENT_SESSION_WATCHDOG_INTERVAL_SEC="${STOREBOT_CODEX_RESIDENT_SESSION_WATCHDOG_INTERVAL_SEC:-120}"
export STOREBOT_CODEX_RESIDENT_SESSION_KEEPALIVE_INTERVAL_SEC="${STOREBOT_CODEX_RESIDENT_SESSION_KEEPALIVE_INTERVAL_SEC:-600}"
export STOREBOT_CODEX_PREBOOT_ROOM_ID="${STOREBOT_CODEX_PREBOOT_ROOM_ID:-storebot_group}"
export STOREBOT_CODEX_PREBOOT_ROOM_NAME="${STOREBOT_CODEX_PREBOOT_ROOM_NAME:-BBQ하이닉스점}"
export STOREBOT_CODEX_MCP_TOOLS="${STOREBOT_CODEX_MCP_TOOLS:-0}"
export STOREBOT_CODEX_FAST_ROUTER="${STOREBOT_CODEX_FAST_ROUTER:-1}"
export STOREBOT_CODEX_FAST_ROUTER_STATELESS_EXEC="${STOREBOT_CODEX_FAST_ROUTER_STATELESS_EXEC_OVERRIDE:-0}"
export STOREBOT_CODEX_FAST_ROUTER_TIMEOUT_SEC="${STOREBOT_CODEX_FAST_ROUTER_TIMEOUT_SEC_OVERRIDE:-540}"
export STOREBOT_CODEX_FAST_ROUTER_REASONING_EFFORT="${STOREBOT_CODEX_FAST_ROUTER_REASONING_EFFORT:-low}"
export STOREBOT_CODEX_FAST_ROUTER_PREWARM="${STOREBOT_CODEX_FAST_ROUTER_PREWARM_OVERRIDE:-1}"
export STOREBOT_CODEX_FAST_ROUTER_REFRESH_AFTER_ACTION="${STOREBOT_CODEX_FAST_ROUTER_REFRESH_AFTER_ACTION_OVERRIDE:-0}"
export STOREBOT_CODEX_FAST_ROUTER_FALLBACK_FULL="${STOREBOT_CODEX_FAST_ROUTER_FALLBACK_FULL:-1}"
export STOREBOT_CODEX_FAST_ROUTER_FALLBACK_ON_ERROR="${STOREBOT_CODEX_FAST_ROUTER_FALLBACK_ON_ERROR:-0}"
export STOREBOT_FAST_BRAIN_ENABLED="${STOREBOT_FAST_BRAIN_ENABLED:-0}"
export STOREBOT_FAST_BRAIN_PROVIDER="${STOREBOT_FAST_BRAIN_PROVIDER:-auto}"
export STOREBOT_FAST_BRAIN_TIMEOUT_SEC="${STOREBOT_FAST_BRAIN_TIMEOUT_SEC:-12}"
export STOREBOT_FAST_BRAIN_MAX_TOKENS="${STOREBOT_FAST_BRAIN_MAX_TOKENS:-900}"
export STOREBOT_CODEX_RESIDENT_THREAD_START_TIMEOUT_SEC="${STOREBOT_CODEX_RESIDENT_THREAD_START_TIMEOUT_SEC:-60}"
export STOREBOT_IMPROVEMENT_REPORT_ENABLED="$IMPROVEMENT_REPORT_ENABLED"
export STOREBOT_IMPROVEMENT_REPORT_DAILY="${STOREBOT_IMPROVEMENT_REPORT_DAILY:-1}"
export STOREBOT_IMPROVEMENT_REPORT_TIME_KST="${STOREBOT_IMPROVEMENT_REPORT_TIME_KST:-04:30}"
export STOREBOT_IMPROVEMENT_REPORT_DEFER_SEC="${STOREBOT_IMPROVEMENT_REPORT_DEFER_SEC:-1800}"
export STOREBOT_IMPROVEMENT_REPORT_MAX_DEFER_SEC="${STOREBOT_IMPROVEMENT_REPORT_MAX_DEFER_SEC:-14400}"
export STOREBOT_IMPROVEMENT_REPORT_INTERVAL_SEC="${STOREBOT_IMPROVEMENT_REPORT_INTERVAL_SEC:-86400}"
export STOREBOT_IMPROVEMENT_REPORT_INITIAL_DELAY_SEC="${STOREBOT_IMPROVEMENT_REPORT_INITIAL_DELAY_SEC:-0}"

mkdir -p "$LOG_DIR"
cd "$ROOT_DIR"

if ! mkdir "$LOCK_DIR" 2>/dev/null; then
  if [ -f "$LOCK_DIR/pid" ]; then
    old_pid="$(cat "$LOCK_DIR/pid" 2>/dev/null || true)"
    if [ -n "$old_pid" ] && kill -0 "$old_pid" 2>/dev/null; then
      echo "StoreBot Codex worker already running pid=$old_pid" >> "$LOG_DIR/storebot_codex_worker.log"
      exit 0
    fi
  fi
  rm -rf "$LOCK_DIR"
  mkdir "$LOCK_DIR"
fi

cleanup() {
  rm -rf "$LOCK_DIR"
}
trap cleanup EXIT INT TERM
echo "$$" > "$LOCK_DIR/pid"

while true; do
  set +e
  python3 "$ROOT_DIR/scripts/storebot_codex_worker.py" \
    --watch \
    --poll-sec "$POLL_SEC" \
    --model "$MODEL" \
    --reasoning-effort "$REASONING_EFFORT" \
    --timeout-sec "$TIMEOUT_SEC" \
    >> "$LOG_DIR/storebot_codex_worker.log" 2>&1
  code=$?
  set -e

  if [ "$code" = "75" ]; then
    echo "StoreBot Codex worker self-sync restart requested" >> "$LOG_DIR/storebot_codex_worker.log"
    sleep 2
    continue
  fi
  exit "$code"
done
