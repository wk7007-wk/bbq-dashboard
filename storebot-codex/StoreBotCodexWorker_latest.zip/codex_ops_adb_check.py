#!/usr/bin/env python3
from __future__ import annotations

import argparse
import json
import os
import re
import shutil
import subprocess
import sys
import tempfile
import time
from pathlib import Path, PurePath
from typing import Any

FACTORY_PC_ADB_PATH = r"C:\Users\wk700\AppData\Local\codex_ops\tools\android-platform-tools\platform-tools\adb.exe"
LOCALAPPDATA_ADB_SUFFIX = r"codex_ops\tools\android-platform-tools\platform-tools\adb.exe"


def now_ms() -> int:
    return int(time.time() * 1000)


def bool_field(value: Any) -> bool:
    if isinstance(value, bool):
        return value
    if isinstance(value, (int, float)):
        return value != 0
    return str(value or "").strip().lower() in {"1", "true", "yes", "y", "on"}


def compact_text(value: Any, limit: int = 4000) -> str:
    text = str(value or "")
    return text if len(text) <= limit else text[-limit:]


def adb_check_requested(item: dict[str, Any]) -> bool:
    value = item.get("adb_check")
    if isinstance(value, dict):
        return bool_field(value.get("enabled", True))
    return bool_field(value)


def normalize_adb_spec(item: dict[str, Any]) -> dict[str, Any]:
    raw = item.get("adb_check") if isinstance(item.get("adb_check"), dict) else {}
    raw = raw if isinstance(raw, dict) else {}
    spec: dict[str, Any] = {
        "enabled": adb_check_requested(item),
        "adb_path": str(raw.get("adb_path") or item.get("adb_path") or item.get("adbPath") or "").strip(),
        "serial": str(raw.get("serial") or item.get("adb_serial") or item.get("serial") or "").strip(),
        "apk_path": str(raw.get("apk_path") or item.get("apk_path") or "").strip(),
        "package_name": str(raw.get("package_name") or item.get("package_name") or "").strip(),
        "activity": str(raw.get("activity") or item.get("activity") or "").strip(),
        "screenshot": bool_field(raw.get("screenshot", item.get("screenshot"))),
        "logcat_tail": int(raw.get("logcat_tail") or item.get("logcat_tail") or 0),
        "install": bool_field(raw.get("install", item.get("install") or item.get("adb_install"))),
        "launch": bool_field(raw.get("launch", item.get("launch") or item.get("adb_launch"))),
        "timeout_sec": int(raw.get("timeout_sec") or item.get("adb_timeout_sec") or 15),
    }
    return spec


def _candidate_exists(value: str) -> bool:
    if not value:
        return False
    if Path(value).exists():
        return True
    return shutil.which(value) is not None


def _resolve_candidate(value: str) -> str:
    if not value:
        return ""
    if Path(value).exists():
        return value
    return shutil.which(value) or ""


def _localappdata_adb_path() -> str:
    localappdata = os.environ.get("LOCALAPPDATA", "").strip()
    if not localappdata:
        return ""
    return str(PurePath(localappdata) / LOCALAPPDATA_ADB_SUFFIX)


def resolve_adb_path(spec: dict[str, Any] | None = None) -> dict[str, Any]:
    spec = spec or {}
    candidates: list[dict[str, str]] = []

    def add(source: str, value: Any) -> None:
        text = str(value or "").strip()
        if not text:
            return
        candidates.append({"source": source, "path": text, "exists": str(_candidate_exists(text)).lower()})

    add("payload", spec.get("adb_path"))
    add("env_CODEX_OPS_ADB_PATH", os.environ.get("CODEX_OPS_ADB_PATH"))
    add("factory_pc_known_path", FACTORY_PC_ADB_PATH)
    add("localappdata", _localappdata_adb_path())
    path_adb = shutil.which("adb") or ""
    add("PATH", path_adb or "adb")

    for candidate in candidates:
        resolved = _resolve_candidate(candidate["path"])
        if resolved:
            return {
                "adb_path": resolved,
                "adb_path_source": candidate["source"],
                "adb_candidates": candidates,
            }
    return {"adb_path": "", "adb_path_source": "", "adb_candidates": candidates}


def _adb_base(adb_path: str, serial: str = "") -> list[str]:
    cmd = [adb_path]
    if serial:
        cmd.extend(["-s", serial])
    return cmd


def _run(cmd: list[str], timeout_sec: int) -> subprocess.CompletedProcess[str]:
    return subprocess.run(
        cmd,
        text=True,
        stdout=subprocess.PIPE,
        stderr=subprocess.PIPE,
        timeout=timeout_sec,
        check=False,
    )


def parse_devices(output: str) -> list[dict[str, Any]]:
    devices: list[dict[str, Any]] = []
    for line in output.splitlines()[1:]:
        text = line.strip()
        if not text:
            continue
        parts = text.split()
        if len(parts) < 2:
            continue
        serial, state = parts[0], parts[1]
        details: dict[str, str] = {}
        for part in parts[2:]:
            if ":" in part:
                key, value = part.split(":", 1)
                details[key] = value
        devices.append({"serial": serial, "state": state, "details": details, "raw": text})
    return devices


def select_device(devices: list[dict[str, Any]], serial: str = "") -> tuple[str, str]:
    online = [item for item in devices if item.get("state") == "device"]
    if serial:
        for item in online:
            if item.get("serial") == serial:
                return serial, ""
        return "", f"requested adb serial not connected: {serial}"
    if not online:
        return "", "no adb device connected"
    if len(online) > 1:
        return "", "multiple adb devices connected; set adb_serial"
    return str(online[0].get("serial") or ""), ""


def package_version(text: str) -> dict[str, Any]:
    result: dict[str, Any] = {}
    for key in ("versionName", "versionCode"):
        match = re.search(rf"^\s*{key}=([^\s]+)", text, flags=re.MULTILINE)
        if match:
            result[key] = match.group(1).strip()
    for key in ("lastUpdateTime",):
        match = re.search(rf"^\s*{key}=([^\r\n]+)", text, flags=re.MULTILINE)
        if match:
            result[key] = match.group(1).strip()
    return result


def package_check(base: list[str], package_name: str, timeout_sec: int) -> dict[str, Any]:
    proc = _run(base + ["shell", "dumpsys", "package", package_name], timeout_sec)
    text = f"{proc.stdout}\n{proc.stderr}"
    installed = proc.returncode == 0 and package_name in text
    return {
        "package_name": package_name,
        "installed": installed,
        "returncode": proc.returncode,
        "version": package_version(text),
        "output_tail": compact_text(text, 1200),
    }


def run_adb_check(item: dict[str, Any], req_id: str = "") -> dict[str, Any]:
    spec = normalize_adb_spec(item)
    started = now_ms()
    if not spec.get("enabled"):
        return {"status": "adb_skipped", "enabled": False, "duration_ms": 0}
    timeout_sec = max(3, int(spec.get("timeout_sec") or 15))
    resolver = resolve_adb_path(spec)
    adb_path = str(resolver.get("adb_path") or "")
    if not adb_path:
        return {
            "status": "adb_unavailable",
            "enabled": True,
            "adb_path": "",
            "adb_path_source": "",
            "adb_candidates": resolver.get("adb_candidates") or [],
            "reason": "adb command not found",
            "duration_ms": now_ms() - started,
        }
    try:
        devices_proc = _run([adb_path, "devices", "-l"], timeout_sec)
    except Exception as exc:
        return {
            "status": "adb_unavailable",
            "enabled": True,
            "adb_path": adb_path,
            "adb_path_source": resolver.get("adb_path_source") or "",
            "adb_candidates": resolver.get("adb_candidates") or [],
            "reason": compact_text(exc, 500),
            "duration_ms": now_ms() - started,
        }
    devices = parse_devices(devices_proc.stdout)
    serial, select_error = select_device(devices, str(spec.get("serial") or ""))
    result: dict[str, Any] = {
        "status": "adb_done" if serial else "adb_unavailable",
        "enabled": True,
        "adb_path": adb_path,
        "adb_path_source": resolver.get("adb_path_source") or "",
        "adb_candidates": resolver.get("adb_candidates") or [],
        "serial": serial,
        "devices": devices,
        "read_only": not bool(spec.get("install") or spec.get("launch")),
        "checks": {},
        "duration_ms": now_ms() - started,
    }
    if select_error:
        result["reason"] = select_error
        result["duration_ms"] = now_ms() - started
        return result

    base = _adb_base(adb_path, serial)
    package_name = str(spec.get("package_name") or "")
    if package_name:
        result["checks"]["package"] = package_check(base, package_name, timeout_sec)

    apk_path = str(spec.get("apk_path") or "")
    if spec.get("install"):
        if not apk_path or not Path(apk_path).exists():
            result["checks"]["install"] = {"status": "adb_skipped", "reason": "apk_path missing"}
        else:
            proc = _run(base + ["install", "-r", apk_path], max(timeout_sec, 90))
            result["checks"]["install"] = {
                "status": "done" if proc.returncode == 0 else "failed",
                "returncode": proc.returncode,
                "output_tail": compact_text(f"{proc.stdout}\n{proc.stderr}", 1200),
            }
            if package_name and proc.returncode == 0:
                result["checks"]["package_after_install"] = package_check(base, package_name, timeout_sec)

    activity = str(spec.get("activity") or "")
    if spec.get("launch"):
        if not activity:
            result["checks"]["launch"] = {"status": "adb_skipped", "reason": "activity missing"}
        else:
            proc = _run(base + ["shell", "am", "start", "-n", activity], timeout_sec)
            result["checks"]["launch"] = {
                "status": "done" if proc.returncode == 0 else "failed",
                "returncode": proc.returncode,
                "output_tail": compact_text(f"{proc.stdout}\n{proc.stderr}", 1200),
            }

    if spec.get("screenshot"):
        out_dir = Path(tempfile.gettempdir()) / "codex_ops_adb_screenshots"
        out_dir.mkdir(parents=True, exist_ok=True)
        safe_req = re.sub(r"[^0-9A-Za-z_.-]+", "_", req_id or "request")[:80]
        screenshot_path = out_dir / f"{safe_req}_{now_ms()}.png"
        try:
            proc = subprocess.run(
                base + ["exec-out", "screencap", "-p"],
                stdout=subprocess.PIPE,
                stderr=subprocess.PIPE,
                timeout=timeout_sec,
                check=False,
            )
            if proc.returncode == 0 and proc.stdout:
                screenshot_path.write_bytes(proc.stdout)
                result["checks"]["screenshot"] = {
                    "status": "done",
                    "path": str(screenshot_path),
                    "bytes": len(proc.stdout),
                }
            else:
                result["checks"]["screenshot"] = {
                    "status": "failed",
                    "returncode": proc.returncode,
                    "stderr_tail": compact_text(proc.stderr.decode("utf-8", errors="replace"), 1200),
                }
        except Exception as exc:
            result["checks"]["screenshot"] = {"status": "failed", "reason": compact_text(exc, 500)}

    logcat_tail = max(0, int(spec.get("logcat_tail") or 0))
    if logcat_tail:
        proc = _run(base + ["logcat", "-d", "-t", str(logcat_tail)], max(timeout_sec, 30))
        result["checks"]["logcat"] = {
            "status": "done" if proc.returncode == 0 else "failed",
            "returncode": proc.returncode,
            "tail": compact_text(f"{proc.stdout}\n{proc.stderr}", 4000),
        }

    failed = [name for name, check in result["checks"].items() if isinstance(check, dict) and check.get("status") == "failed"]
    if failed:
        result["status"] = "adb_failed"
        result["failed_checks"] = failed
    result["duration_ms"] = now_ms() - started
    return result


def parse_args(argv: list[str]) -> argparse.Namespace:
    parser = argparse.ArgumentParser(description="Read-only biased ADB post-check for codex_ops")
    parser.add_argument("--json", required=True, help="request item JSON file")
    parser.add_argument("--request-id", default="")
    return parser.parse_args(argv)


def main(argv: list[str]) -> int:
    args = parse_args(argv)
    item = json.loads(Path(args.json).read_text(encoding="utf-8"))
    result = run_adb_check(item, args.request_id)
    print(json.dumps(result, ensure_ascii=False, indent=2))
    return 0 if result.get("status") in {"adb_done", "adb_skipped", "adb_unavailable"} else 1


if __name__ == "__main__":
    raise SystemExit(main(sys.argv[1:]))
