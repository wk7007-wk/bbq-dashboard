#!/system/bin/sh
if [ -z "${CODEX_OPS_BASH_REEXEC:-}" ]; then
  for candidate in "${STOREBOT_TERMUX_DATA_DIR:-}" /data/data/com.sbotux /data/data/com.termux; do
    [ -n "$candidate" ] || continue
    if [ -x "$candidate/files/usr/bin/bash" ]; then
      export CODEX_OPS_BASH_REEXEC=1
      exec "$candidate/files/usr/bin/bash" "$0" "$@"
    fi
  done
fi
set -euo pipefail

resolve_termux_data_dir() {
  if [ -n "${STOREBOT_TERMUX_DATA_DIR:-}" ] && [ -x "$STOREBOT_TERMUX_DATA_DIR/files/usr/bin/bash" ]; then
    printf '%s\n' "$STOREBOT_TERMUX_DATA_DIR"
    return 0
  fi
  for candidate in /data/data/com.sbotux /data/data/com.termux; do
    if [ -x "$candidate/files/usr/bin/bash" ]; then
      printf '%s\n' "$candidate"
      return 0
    fi
  done
  printf '%s\n' "/data/data/com.sbotux"
}

APP_DATA_DIR="$(resolve_termux_data_dir)"
APP_PREFIX="$APP_DATA_DIR/files/usr"
export PREFIX="${PREFIX:-$APP_PREFIX}"
export PATH="$APP_PREFIX/bin:$APP_PREFIX/bin/applets:/system/bin:/system/xbin:$PATH"

ROOT="${CODEX_OPS_ROOT:-/root/my-first-project}"
LOG_DIR="${CODEX_OPS_LOG_DIR:-/sdcard/Download/codex_ops_worker}"
LOCK_BASE_DIR="${CODEX_OPS_LOCK_BASE_DIR:-$LOG_DIR}"
mkdir -p "$LOG_DIR" "$LOCK_BASE_DIR" 2>/dev/null || true
LOCK_DIR="${CODEX_OPS_LOCK_DIR:-$LOCK_BASE_DIR/codex_ops_worker.lock}"
INSTALL_STAMP="$LOG_DIR/codex_install_attempted"
PROOT_ROOTFS_DIR="${CODEX_OPS_PROOT_ROOTFS_DIR:-$PREFIX/var/lib/proot-distro/installed-rootfs}"
DISTRO="${CODEX_OPS_DISTRO:-${STOREBOT_CODEX_DISTRO:-}}"

if ! mkdir "$LOCK_DIR" 2>/dev/null; then
  if [ -f "$LOCK_DIR/pid" ]; then
    old_pid="$(cat "$LOCK_DIR/pid" 2>/dev/null || true)"
    if [ -n "$old_pid" ] && kill -0 "$old_pid" 2>/dev/null; then
      echo "codex_ops_worker already running pid=$old_pid" >> "$LOG_DIR/worker.log"
      exit 0
    fi
  fi
  rm -rf "$LOCK_DIR"
  mkdir "$LOCK_DIR"
fi

cleanup() {
  rm -rf "$LOCK_DIR"
}
trap cleanup EXIT INT TERM
echo "$$" > "$LOCK_DIR/pid"

if [ -z "$DISTRO" ]; then
  if [ -d "$PROOT_ROOTFS_DIR/debian" ]; then
    DISTRO="debian"
  elif [ -d "$PROOT_ROOTFS_DIR/ubuntu" ]; then
    DISTRO="ubuntu"
  fi
fi

if command -v proot-distro >/dev/null 2>&1 && [ -n "$DISTRO" ] && [ -d "$PROOT_ROOTFS_DIR/$DISTRO" ] && proot-distro login "$DISTRO" -- true >/dev/null 2>&1; then
  proot-distro login "$DISTRO" -- bash -lc "
    cd '$ROOT'
    export PATH=\"/root/.nvm/versions/node/v22.22.1/bin:/root/.local/bin:/root/.codex/bin:/usr/local/bin:/usr/bin:/bin:\$PATH\"
    export CODEX_OPS_NODE=\"\${CODEX_OPS_NODE:-subphone_termux_ops}\"
    export CODEX_OPS_MODEL=\"\${CODEX_OPS_MODEL:-gpt-5.5}\"
    export CODEX_OPS_REASONING_EFFORT=\"\${CODEX_OPS_REASONING_EFFORT:-xhigh}\"
    export CODEX_OPS_POLL_SEC=\"\${CODEX_OPS_POLL_SEC:-15}\"
    if [ -z \"\${CODEX_CODE_REVISION:-}\" ] && [ -f '$ROOT/.storebot_codex_bundle_state.json' ]; then
      export CODEX_CODE_REVISION=\"\$(python3 -c 'import json; data=json.load(open(\"$ROOT/.storebot_codex_bundle_state.json\")); print(data.get(\"code_revision\") or data.get(\"source_revision\") or \"\")' 2>/dev/null || true)\"
    fi
    if ! command -v codex >/dev/null 2>&1; then
      if [ ! -f '$INSTALL_STAMP' ] || [ \$((\$(date +%s) - \$(cat '$INSTALL_STAMP' 2>/dev/null || echo 0))) -gt 21600 ]; then
        date +%s > '$INSTALL_STAMP'
        echo \"codex missing; attempting install\" >&2
        (curl -fsSL https://chatgpt.com/codex/install.sh | sh || npm install -g @openai/codex) || true
      else
        echo \"codex missing; recent install attempt exists\" >&2
      fi
    fi
    python3 scripts/codex_ops_worker.py --watch
  " >> "$LOG_DIR/worker.log" 2>&1
  exit $?
fi

cd "$ROOT"
export PATH="/root/.nvm/versions/node/v22.22.1/bin:/root/.local/bin:/root/.codex/bin:/usr/local/bin:/usr/bin:/bin:$PATH"
export CODEX_OPS_NODE="${CODEX_OPS_NODE:-subphone_termux_ops}"
export CODEX_OPS_MODEL="${CODEX_OPS_MODEL:-gpt-5.5}"
export CODEX_OPS_REASONING_EFFORT="${CODEX_OPS_REASONING_EFFORT:-xhigh}"
export CODEX_OPS_POLL_SEC="${CODEX_OPS_POLL_SEC:-15}"
if [ -z "${CODEX_CODE_REVISION:-}" ] && [ -f "$ROOT/.storebot_codex_bundle_state.json" ]; then
  export CODEX_CODE_REVISION="$(python3 -c 'import json,sys; data=json.load(open(sys.argv[1])); print(data.get("code_revision") or data.get("source_revision") or "")' "$ROOT/.storebot_codex_bundle_state.json" 2>/dev/null || true)"
fi
python3 scripts/codex_ops_worker.py --watch >> "$LOG_DIR/worker.log" 2>&1
