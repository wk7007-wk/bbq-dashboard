#!/usr/bin/env python3
from __future__ import annotations

import argparse
import asyncio
import importlib
import importlib.metadata as importlib_metadata
import importlib.util
import json
import os
import shutil
import subprocess
import sys
import time
import traceback
from pathlib import Path
from typing import Any


ALLOWED_ENGINES = {"auto", "sdk", "exec"}


def now_ms() -> int:
    return int(time.time() * 1000)


def normalize_engine(value: Any, default: str = "auto") -> str:
    text = str(value or default).strip().lower()
    return text if text in ALLOWED_ENGINES else default


def compact_text(value: Any, limit: int = 4000) -> str:
    text = str(value or "")
    return text if len(text) <= limit else text[-limit:]


def _module_spec(module_name: str) -> Any:
    try:
        return importlib.util.find_spec(module_name)
    except (ImportError, ValueError):
        return None


def _package_version(package_name: str) -> str:
    try:
        return importlib_metadata.version(package_name)
    except importlib_metadata.PackageNotFoundError:
        return ""


def _api_key_available() -> bool:
    return bool(str(os.environ.get("OPENAI_API_KEY") or "").strip())


def _probe_codex_subcommand(
    codex_bin: str,
    subcommand: str,
    timeout_sec: float,
) -> tuple[bool, str]:
    try:
        proc = subprocess.run(
            [codex_bin, subcommand, "--help"],
            text=True,
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE,
            timeout=timeout_sec,
            check=False,
        )
        combined = f"{proc.stdout}\n{proc.stderr}".strip()
        available = proc.returncode == 0 or subcommand in combined
        return available, "" if available else compact_text(combined, 500)
    except Exception as exc:
        return False, compact_text(exc, 500)


def _sdk_unavailable_reason(probe: dict[str, Any]) -> str:
    if not probe.get("agents_sdk_installed"):
        return "agents_sdk_package_unavailable"
    if not probe.get("openai_sdk_installed"):
        return "openai_sdk_package_unavailable"
    if not probe.get("codex_mcp_server_available"):
        reason = str(probe.get("codex_mcp_server_probe_error") or "").strip()
        return f"codex_mcp_server_unavailable: {reason}" if reason else "codex_mcp_server_unavailable"
    if not probe.get("api_key_available"):
        return "openai_api_key_unavailable"
    return "sdk_not_runnable"


def probe_codex_sdk(codex_bin: str = "codex", timeout_sec: float = 3.0) -> dict[str, Any]:
    """Return a non-fatal availability probe for official SDKs and Codex CLIs."""
    agents_spec = _module_spec("agents")
    openai_spec = _module_spec("openai")
    legacy_codex_spec = _module_spec("openai_codex")
    codex_path = shutil.which(codex_bin)
    codex_app_server_available = False
    app_server_probe_error = ""
    codex_mcp_server_available = False
    codex_mcp_server_probe_error = ""
    codex_mcp_server_command = ""
    if codex_path:
        codex_app_server_available, app_server_probe_error = _probe_codex_subcommand(
            codex_bin,
            "app-server",
            timeout_sec,
        )
        for command in ("mcp-server", "mcp"):
            available, error = _probe_codex_subcommand(codex_bin, command, timeout_sec)
            if available:
                codex_mcp_server_available = True
                codex_mcp_server_command = command
                codex_mcp_server_probe_error = ""
                break
            if error:
                codex_mcp_server_probe_error = error
    agents_sdk_installed = bool(agents_spec)
    openai_sdk_installed = bool(openai_spec)
    sdk_installed = agents_sdk_installed and openai_sdk_installed
    api_key_available = _api_key_available()
    sdk_runnable = sdk_installed and codex_mcp_server_available and api_key_available
    selected_engine = "sdk" if sdk_runnable else "exec"
    probe = {
        "available": sdk_runnable,
        "python_sdk_available": sdk_installed,
        "python_sdk_origin": getattr(agents_spec, "origin", "") if agents_spec else "",
        "agents_sdk_installed": agents_sdk_installed,
        "agents_sdk_origin": getattr(agents_spec, "origin", "") if agents_spec else "",
        "agents_sdk_version": _package_version("openai-agents") if agents_sdk_installed else "",
        "openai_sdk_installed": openai_sdk_installed,
        "openai_sdk_origin": getattr(openai_spec, "origin", "") if openai_spec else "",
        "openai_sdk_version": _package_version("openai") if openai_sdk_installed else "",
        "legacy_openai_codex_installed": bool(legacy_codex_spec),
        "legacy_openai_codex_origin": getattr(legacy_codex_spec, "origin", "") if legacy_codex_spec else "",
        "api_key_available": api_key_available,
        "sdk_runnable": sdk_runnable,
        "selected_engine": selected_engine,
        "selected_engine_reason": "sdk_runnable" if sdk_runnable else _sdk_unavailable_reason(
            {
                "agents_sdk_installed": agents_sdk_installed,
                "openai_sdk_installed": openai_sdk_installed,
                "codex_mcp_server_available": codex_mcp_server_available,
                "codex_mcp_server_probe_error": codex_mcp_server_probe_error,
                "api_key_available": api_key_available,
            }
        ),
        "codex_bin": codex_bin,
        "codex_path": codex_path or "",
        "codex_app_server_available": codex_app_server_available,
        "app_server_cli_available": codex_app_server_available,
        "app_server_probe_error": app_server_probe_error,
        "codex_mcp_server_available": codex_mcp_server_available,
        "codex_mcp_server_command": codex_mcp_server_command,
        "codex_mcp_server_probe_error": codex_mcp_server_probe_error,
        "checked_at_ms": now_ms(),
    }
    return probe


def choose_engine(engine: Any, probe: dict[str, Any] | None = None) -> tuple[str, str]:
    requested = normalize_engine(engine)
    if requested == "exec":
        return "exec", "engine_exec_requested"
    probe = probe or probe_codex_sdk()
    if probe.get("sdk_runnable") or (
        "sdk_runnable" not in probe
        and probe.get("available")
        and probe.get("api_key_available", True)
    ):
        return "sdk", "sdk_probe_ok"
    return "exec", _sdk_unavailable_reason(probe)


def _jsonable(value: Any) -> Any:
    if value is None or isinstance(value, (str, int, float, bool)):
        return value
    if isinstance(value, dict):
        return {str(k): _jsonable(v) for k, v in value.items()}
    if isinstance(value, (list, tuple)):
        return [_jsonable(v) for v in value]
    return str(value)


def _mcp_sandbox(profile: str) -> str:
    if profile == "read_only":
        return "read-only"
    return "danger-full-access"


def _agents_runner_input(payload: dict[str, Any], sandbox: str) -> str:
    tool_args: dict[str, Any] = {
        "prompt": str(payload.get("prompt") or ""),
        "approval-policy": "never",
        "cwd": str(payload.get("cwd") or ""),
        "sandbox": sandbox,
    }
    if payload.get("model"):
        tool_args["model"] = str(payload.get("model") or "")
    return (
        "Use the Codex CLI MCP server to run exactly one Codex task with these tool arguments. "
        "Call the codex MCP tool, wait for its response, and return the Codex result content without extra commentary.\n\n"
        f"{json.dumps(tool_args, ensure_ascii=False)}"
    )


async def _run_agents_sdk_payload(payload: dict[str, Any], probe: dict[str, Any]) -> Any:
    from agents import Agent, Runner
    from agents.mcp import MCPServerStdio

    codex_bin = str(payload.get("codex_bin") or probe.get("codex_bin") or "codex")
    mcp_command = str(probe.get("codex_mcp_server_command") or "mcp-server")
    timeout_sec = int(payload.get("timeout_sec") or 360000)
    sandbox = _mcp_sandbox(str(payload.get("profile") or "patch"))
    agent_kwargs: dict[str, Any] = {
        "name": "Codex Ops SDK Runner",
        "instructions": (
            "You are a thin orchestration layer. Always delegate repository work to the Codex MCP "
            "tool using the exact arguments provided by the user message."
        ),
    }
    if payload.get("model"):
        agent_kwargs["model"] = str(payload.get("model") or "")
    async with MCPServerStdio(
        name="Codex CLI",
        params={"command": codex_bin, "args": [mcp_command]},
        client_session_timeout_seconds=timeout_sec,
    ) as codex_mcp_server:
        agent = Agent(**agent_kwargs, mcp_servers=[codex_mcp_server])
        return await Runner.run(agent, _agents_runner_input(payload, sandbox), max_turns=6)


def _result_summary(result: Any) -> tuple[str, dict[str, Any]]:
    if isinstance(result, dict):
        text = result.get("final_response") or result.get("summary") or result.get("text") or json.dumps(result, ensure_ascii=False)
        return str(text), _jsonable(result)
    for name in ("final_output", "final_response", "summary", "text", "message"):
        value = getattr(result, name, None)
        if value:
            attrs = {
                "status": getattr(result, "status", ""),
                "thread_id": getattr(result, "thread_id", ""),
                "turn_id": getattr(result, "turn_id", ""),
            }
            events = getattr(result, "events", None)
            if events is not None:
                try:
                    attrs["event_count"] = len(events)
                except Exception:
                    attrs["event_count"] = 0
            return str(value), _jsonable(attrs)
    return str(result), {"status": getattr(result, "status", "")}


def run_sdk_payload(payload: dict[str, Any]) -> dict[str, Any]:
    started = now_ms()
    codex_bin = str(payload.get("codex_bin") or "codex")
    probe = probe_codex_sdk(codex_bin=codex_bin)
    if not probe.get("sdk_runnable"):
        reason = _sdk_unavailable_reason(probe)
        return {
            "status": "unavailable",
            "returncode": 2,
            "duration_ms": now_ms() - started,
            "stage": "probe",
            "started_turn": False,
            "summary": reason,
            "error": reason,
            "probe": probe,
        }
    prompt = str(payload.get("prompt") or "")
    if not prompt.strip():
        return {
            "status": "error",
            "returncode": 1,
            "duration_ms": now_ms() - started,
            "stage": "input",
            "started_turn": False,
            "summary": "prompt missing",
            "error": "prompt missing",
            "probe": probe,
        }
    stage = "import"
    started_turn = False
    try:
        importlib.import_module("agents")
        importlib.import_module("openai")
        stage = "run"
        started_turn = True
        result = asyncio.run(_run_agents_sdk_payload(payload, probe))
        summary, raw = _result_summary(result)
        status = str(raw.get("status") or "done") if isinstance(raw, dict) else "done"
        if not status or status == "None":
            status = "done"
        normalized_status = "needs_approval" if "approval" in status.lower() else "done"
        if status.lower() in {"failed", "error"}:
            normalized_status = "error"
        return {
            "status": normalized_status,
            "sdk_status": status,
            "returncode": 0 if normalized_status == "done" else 1,
            "duration_ms": now_ms() - started,
            "stage": "completed",
            "started_turn": started_turn,
            "summary": compact_text(summary, 4000),
            "output_len": len(summary),
            "raw": raw,
            "probe": probe,
            "thread_id": str(raw.get("thread_id") or payload.get("thread_id") or ""),
        }
    except Exception as exc:
        return {
            "status": "error",
            "returncode": 1,
            "duration_ms": now_ms() - started,
            "stage": stage,
            "started_turn": started_turn,
            "summary": compact_text(exc, 1200),
            "error": compact_text(exc, 1200),
            "traceback": compact_text(traceback.format_exc(), 4000),
            "probe": probe,
        }


def parse_args(argv: list[str]) -> argparse.Namespace:
    parser = argparse.ArgumentParser(description="Codex SDK probe/runner for codex_ops")
    sub = parser.add_subparsers(dest="command", required=True)
    probe = sub.add_parser("probe")
    probe.add_argument("--codex-bin", default=os.environ.get("CODEX_BIN", "codex"))
    probe.add_argument("--timeout-sec", type=float, default=3.0)
    run = sub.add_parser("run")
    run.add_argument("--request-json", required=True)
    return parser.parse_args(argv)


def main(argv: list[str]) -> int:
    args = parse_args(argv)
    if args.command == "probe":
        print(json.dumps(probe_codex_sdk(args.codex_bin, args.timeout_sec), ensure_ascii=False))
        return 0
    payload = json.loads(Path(args.request_json).read_text(encoding="utf-8"))
    result = run_sdk_payload(payload)
    print(json.dumps(result, ensure_ascii=False))
    return int(result.get("returncode") or 0)


if __name__ == "__main__":
    raise SystemExit(main(sys.argv[1:]))
