#!/usr/bin/env python3
"""Model-0 Telegram/OpenClaw bridge for personal Wonmux and factory Codex."""

from __future__ import annotations

import argparse
import hashlib
import importlib.util
import json
import os
import re
import stat
import sys
from pathlib import Path
from typing import Any, Callable, Mapping

import codex_ops_enqueue
import pc_codex_cli_enqueue
from codex_ops_worker import firebase_conditional_put, firebase_get_with_etag
from storebot_codex_worker import fb_get, fb_get_query, fb_patch, now_ms

try:
    from storebot_telegram_ops_log import DeliverySnapshot, OpsLogError, RecoverySnapshot, ReserveResult, TaskSnapshot
except ModuleNotFoundError:  # pragma: no cover - package import in repo tests.
    from scripts.storebot_telegram_ops_log import DeliverySnapshot, OpsLogError, RecoverySnapshot, ReserveResult, TaskSnapshot

try:
    import storebot_ca_log
except ModuleNotFoundError:  # pragma: no cover - package import in repo tests.
    from scripts import storebot_ca_log

try:
    import project_telegram_ca_lifecycle as project_ca
except ModuleNotFoundError:  # pragma: no cover - package import in repo tests.
    from scripts import project_telegram_ca_lifecycle as project_ca


GATE_BASE_PATH = "/packhelper/openclaw_telegram_gate"
DEDUPE_PATH = f"{GATE_BASE_PATH}/dedupe"
DELIVERIES_PATH = f"{GATE_BASE_PATH}/deliveries"
STOREBOT_OPS_TASKS_PATH = f"{GATE_BASE_PATH}/storebot_ops/tasks"
STOREBOT_OPS_RECOVERY_INTENTS_PATH = f"{GATE_BASE_PATH}/storebot_ops/recovery_intents"
STOREBOT_OPS_OUTBOX_BATCHES_PATH = f"{GATE_BASE_PATH}/storebot_ops/outbox_batches"
STOREBOT_OPS_RECOVERY_STATES_PATH = f"{GATE_BASE_PATH}/storebot_ops/recovery_states"
POSDELAY_PAYLOADS_PATH = f"{GATE_BASE_PATH}/posdelay_ca_payloads"
POSDELAY_DELIVERY_KIND = "posdelay_ops_event"
POSDELAY_PAYLOAD_SCHEMA = "posdelay.ca_telegram_payload.v1"
POSDELAY_LIVE_DELIVERY_SCHEMA = "posdelay.ca_live_delivery.v1"
STOREBOT_OPS_DELIVERY_KIND = "storebot_ops_receipt"
STOREBOT_CA_RECEIPTS_PATH = storebot_ca_log.RECEIPTS_PATH
STOREBOT_CA_PAYLOADS_PATH = storebot_ca_log.PAYLOADS_PATH
STOREBOT_STAGE_LEDGERS_PATH = "/packhelper/storebot_codex/stage_ledger/requests"
STOREBOT_REQUESTS_PATH = "/packhelper/storebot_codex/requests"
STOREBOT_PENDING_OUTBOUND_PATH = "/packhelper/storebot_pending_queue"
STOREBOT_SCHEDULE_RECOVERY_PATH = f"{GATE_BASE_PATH}/storebot_ca/schedule_recovery"
STOREBOT_SCHEDULE_EVENT_KIND = "work_schedule_broadcast"
STOREBOT_MONITOR_PACKET_MAX_AGE_MS = 5 * 60 * 1000
DEFAULT_POSDELAY_CA_MODULE_PATH = str(Path(__file__).with_name("posdelay_ca_log.py"))
POSDELAY_CA_MODULE_CONTRACT = {
    "DOMAIN": "posdelay",
    "OPS_EVENT_SCHEMA": "posdelay.ops_event.v1",
    "RECEIPT_SCHEMA": "posdelay.ca_receipt.v1",
    "DELIVERY_SCHEMA": "posdelay.ca_delivery.v1",
}
DEFAULT_ROOM_REGISTRY_PATH = str(Path(__file__).resolve().parents[1] / "config" / "telegram_openclaw_room_registry.json")
DEFAULT_PROJECT_CA_REGISTRY_PATH = str(Path(__file__).resolve().parents[1] / "config" / "telegram_project_ca_registry.json")
PERSONAL_NODE = "personal_wonmux_codex"
FACTORY_NODE = "pc_codex_resource_01"
SERVERPHONE_NODE = "subphone_termux_ops"
PARTICIPANTS = {
    "phone": {
        "participant_id": "personal",
        "resource_id": PERSONAL_NODE,
        "capability": "personal_main_dispatcher",
    },
    "factory": {
        "participant_id": "factory",
        "resource_id": FACTORY_NODE,
        "capability": "factory_pc_repo_code_build_browser",
    },
    "serverphone": {
        "participant_id": "serverphone",
        "resource_id": SERVERPHONE_NODE,
        "capability": "serverphone_read_only_runtime_diag",
    },
}
REPLY_ACCOUNTS = {"phone": "personal", "factory": "factory", "serverphone": "serverphone"}
DEFAULT_PERSONAL_MIN_AVAILABLE_MB = 2048
DEFAULT_FACTORY_HEARTBEAT_MAX_AGE_SEC = 180
TERMINAL_STATUSES = {
    "done",
    "error",
    "failed_timeout",
    "stale_killed",
    "rejected",
    "expired",
    "cancelled_resolved",
}
RESULT_BINDING_SCHEMA = "telegram_gate_result_binding.v1"
STRONG_RESULT_BINDING_MODE = "telegram_gate_bound_v1"
LEGACY_RESULT_BINDING_MODE = "legacy_scoped_path_v1"
TERMINAL_FUTURE_SKEW_MS = 30_000
SAFE_REQUEST_ID = re.compile(r"^[A-Za-z0-9_.:-]{6,180}$")
TELEGRAM_TOKEN_RE = re.compile(r"\b\d{6,12}:[A-Za-z0-9_-]{20,}\b")
API_SECRET_RE = re.compile(r"\b(?:sk-[A-Za-z0-9_-]{16,}|AIza[A-Za-z0-9_-]{20,})\b")
BEARER_RE = re.compile(r"(?i)\bBearer\s+[A-Za-z0-9._~+/-]{12,}")
SECRET_FIELD_RE = re.compile(
    r'(?i)(["\']?(?:token|password|secret|api[_-]?key)["\']?\s*[:=]\s*)["\']?[^\s,"\']{8,}'
)
SERVERPHONE_UNSAFE_RE = re.compile(
    r"(?ix)(?:"
    r"\badb\b|\bfastboot\b|\binstall\b|\bapk\b|\blogcat\b|\bscreencap\b|\bscreenshot\b|"
    r"\bgit\s+(?:commit|push|merge|rebase|reset|clean)\b|\brm\s+-|"
    r"repo\s*(?:write|수정)|file\s*(?:write|delete)|파일\s*(?:쓰기|수정|삭제)|"
    r"카카오\s*(?:전송|발송)|kakao\s*send|주문|결제|금융|배민|쿠팡|destructive"
    r")"
)


class GateError(RuntimeError):
    def __init__(self, message: str, *, reason_code: str = "") -> None:
        super().__init__(message)
        self.reason_code = reason_code


def env_enabled(name: str) -> bool:
    return str(os.environ.get(name) or "").strip().lower() in {"1", "true", "yes", "on"}


def posdelay_projection_enabled() -> bool:
    return env_enabled("POSDELAY_CA_PROJECTION_ENABLED") and not env_enabled("POSDELAY_CA_KILL_SWITCH")


def posdelay_live_send_enabled() -> bool:
    return (
        posdelay_projection_enabled()
        and env_enabled("POSDELAY_CA_LIVE_SEND_ENABLED")
        and not env_enabled("POSDELAY_CA_KILL_SWITCH")
    )


def storebot_projection_enabled() -> bool:
    return env_enabled("STOREBOT_CA_PROJECTION_ENABLED") and not env_enabled("STOREBOT_CA_KILL_SWITCH")


def storebot_live_send_enabled() -> bool:
    return (
        storebot_projection_enabled()
        and env_enabled("STOREBOT_CA_LIVE_SEND_ENABLED")
        and not env_enabled("STOREBOT_CA_KILL_SWITCH")
    )


def storebot_factory_self_fix_enabled() -> bool:
    return (
        storebot_projection_enabled()
        and env_enabled("STOREBOT_CA_FACTORY_SELF_FIX_ENABLED")
        and not env_enabled("STOREBOT_CA_KILL_SWITCH")
    )


def storebot_schedule_recovery_enabled() -> bool:
    return (
        storebot_projection_enabled()
        and env_enabled("STOREBOT_CA_SCHEDULE_RECOVERY_ENABLED")
        and not env_enabled("STOREBOT_CA_KILL_SWITCH")
    )


def project_ca_projection_enabled() -> bool:
    return env_enabled("PROJECT_CA_PROJECTION_ENABLED") and not env_enabled("PROJECT_CA_KILL_SWITCH")


def project_ca_live_send_enabled() -> bool:
    return (
        project_ca_projection_enabled()
        and env_enabled("PROJECT_CA_LIVE_SEND_ENABLED")
        and not env_enabled("PROJECT_CA_KILL_SWITCH")
    )


def read_posdelay_identity_key() -> bytes:
    path_text = str(os.environ.get("POSDELAY_CA_IDENTITY_KEY_FILE") or "").strip()
    if not path_text:
        raise GateError("PosDelay CA identity key file is not configured")
    path = Path(path_text)
    flags = os.O_RDONLY | getattr(os, "O_CLOEXEC", 0) | getattr(os, "O_NOFOLLOW", 0)
    descriptor = os.open(path, flags)
    try:
        metadata = os.fstat(descriptor)
        if not stat.S_ISREG(metadata.st_mode) or stat.S_IMODE(metadata.st_mode) != 0o600:
            raise GateError("PosDelay CA identity key file must be a regular 0600 file")
        value = os.read(descriptor, 4097)
    finally:
        os.close(descriptor)
    if len(value) < 32 or len(value) > 4096:
        raise GateError("PosDelay CA identity key length is invalid")
    return value


def read_project_ca_identity_key() -> bytes:
    path_text = str(os.environ.get("PROJECT_CA_IDENTITY_KEY_FILE") or "").strip()
    if not path_text:
        raise GateError(
            "project CA identity key file is not configured",
            reason_code="project_ca_identity_not_configured",
        )
    path = Path(path_text)
    flags = os.O_RDONLY | getattr(os, "O_CLOEXEC", 0) | getattr(os, "O_NOFOLLOW", 0)
    try:
        descriptor = os.open(path, flags)
    except FileNotFoundError:
        if not env_enabled("PROJECT_CA_IDENTITY_DERIVE_FROM_STOREBOT"):
            raise
        storebot_path_text = str(os.environ.get("STOREBOT_CA_IDENTITY_KEY_FILE") or "").strip()
        if not storebot_path_text:
            raise GateError(
                "StoreBot CA identity key file is not configured",
                reason_code="project_ca_storebot_seed_not_configured",
            )
        storebot_path = Path(storebot_path_text)
        try:
            storebot_descriptor = os.open(storebot_path, flags)
        except FileNotFoundError as exc:
            raise GateError(
                "StoreBot CA identity key file is unavailable",
                reason_code="project_ca_storebot_seed_unavailable",
            ) from exc
        try:
            storebot_metadata = os.fstat(storebot_descriptor)
            if not stat.S_ISREG(storebot_metadata.st_mode) or stat.S_IMODE(storebot_metadata.st_mode) != 0o600:
                raise GateError(
                    "StoreBot CA identity key file must be a regular 0600 file",
                    reason_code="project_ca_storebot_seed_not_private",
                )
            storebot_identity = os.read(storebot_descriptor, 4097)
        finally:
            os.close(storebot_descriptor)
        if len(storebot_identity) < 32 or len(storebot_identity) > 4096:
            raise GateError(
                "StoreBot CA identity key length is invalid",
                reason_code="project_ca_storebot_seed_length_invalid",
            )
        return hashlib.sha256(b"project-ca.identity.v1\0" + storebot_identity).digest()
    try:
        metadata = os.fstat(descriptor)
        if not stat.S_ISREG(metadata.st_mode) or stat.S_IMODE(metadata.st_mode) != 0o600:
            raise GateError(
                "project CA identity key file must be a regular 0600 file",
                reason_code="project_ca_identity_not_private",
            )
        value = os.read(descriptor, 4097)
    finally:
        os.close(descriptor)
    if len(value) < 32 or len(value) > 4096:
        raise GateError(
            "project CA identity key length is invalid",
            reason_code="project_ca_identity_length_invalid",
        )
    return value


def load_posdelay_ca_module():
    path = Path(os.environ.get("POSDELAY_CA_MODULE_PATH") or DEFAULT_POSDELAY_CA_MODULE_PATH)
    if not path.is_file():
        raise GateError("PosDelay CA module is unavailable")
    expected_hash = str(os.environ.get("POSDELAY_CA_MODULE_SHA256") or "").strip().lower()
    actual_hash = hashlib.sha256(path.read_bytes()).hexdigest()
    if expected_hash and (not re.fullmatch(r"[0-9a-f]{64}", expected_hash) or actual_hash != expected_hash):
        raise GateError("PosDelay CA module hash mismatch")
    spec = importlib.util.spec_from_file_location("wonmux_posdelay_ca_log", path)
    if spec is None or spec.loader is None:
        raise GateError("PosDelay CA module cannot be loaded")
    module = importlib.util.module_from_spec(spec)
    sys.modules[spec.name] = module
    spec.loader.exec_module(module)
    for field, expected in POSDELAY_CA_MODULE_CONTRACT.items():
        if getattr(module, field, None) != expected:
            raise GateError(f"PosDelay CA module contract mismatch: {field}")
    return module


def resolve_posdelay_ca_room() -> str:
    registry_path = Path(os.environ.get("OPENCLAW_CODEX_GATE_ROOM_REGISTRY") or DEFAULT_ROOM_REGISTRY_PATH)
    try:
        registry = json.loads(registry_path.read_text(encoding="utf-8"))
    except (OSError, json.JSONDecodeError) as exc:
        raise GateError("Telegram CA room registry is unavailable") from exc
    room_ids = registry.get("ca_room_ids") if isinstance(registry, dict) else None
    if not isinstance(room_ids, list) or len(room_ids) != 1:
        raise GateError("PosDelay CA transport requires exactly one registered CA room")
    room_id = str(room_ids[0] or "").strip()
    if not re.fullmatch(r"-[0-9]+", room_id):
        raise GateError("PosDelay CA room id is invalid")
    return room_id


def posdelay_delivery_id(receipt_id: str, room_id: str, account_id: str) -> str:
    digest = hashlib.sha256(f"posdelay\0{receipt_id}\0{room_id}\0{account_id}".encode()).hexdigest()[:32]
    return f"pdlive_{digest}"


def posdelay_factory_request_id(receipt_id: str) -> str:
    digest = hashlib.sha256(f"posdelay_factory\0{receipt_id}".encode()).hexdigest()[:32]
    return f"pdfix_{digest}"


def read_json_stdin() -> dict[str, Any]:
    try:
        value = json.load(sys.stdin)
    except json.JSONDecodeError as exc:
        raise GateError(f"invalid JSON input: {exc}") from exc
    if not isinstance(value, dict):
        raise GateError("JSON input must be an object")
    return value


def clean_text(value: Any, limit: int = 12000) -> str:
    text = str(value or "").replace("\x00", "").strip()
    if not text:
        raise GateError("empty task")
    return text[:limit]


def safe_id(value: Any, label: str, required: bool = True) -> str:
    text = str(value or "").strip()
    if not text and not required:
        return ""
    if not text or len(text) > 180 or not re.fullmatch(r"[A-Za-z0-9_.:@+-]+", text):
        raise GateError(f"invalid {label}")
    return text


def redact_text(value: Any, limit: int = 3400) -> str:
    text = str(value or "")
    text = TELEGRAM_TOKEN_RE.sub("[REDACTED_TELEGRAM_TOKEN]", text)
    text = API_SECRET_RE.sub("[REDACTED_API_KEY]", text)
    text = BEARER_RE.sub("Bearer [REDACTED]", text)
    text = SECRET_FIELD_RE.sub(r"\1[REDACTED]", text)
    if len(text) > limit:
        text = text[: limit - 16].rstrip() + "\n…(일부 생략)"
    return text.strip()


def ensure_serverphone_safe_task(task: str) -> None:
    if SERVERPHONE_UNSAFE_RE.search(task):
        raise GateError("serverphone participant is read-only runtime diagnostics only")


def participant_for_target(target: str) -> dict[str, str]:
    try:
        return dict(PARTICIPANTS[target])
    except KeyError as exc:
        raise GateError(f"unknown participant target: {target}") from exc


def dedupe_key(conversation_id: str, message_id: str) -> str:
    digest = hashlib.sha256(f"telegram\0{conversation_id}\0{message_id}".encode()).hexdigest()
    return digest[:32]


def available_memory_mb(meminfo_path: str | Path = "/proc/meminfo") -> int | None:
    try:
        values: dict[str, int] = {}
        for line in Path(meminfo_path).read_text(encoding="utf-8").splitlines():
            key, raw = line.split(":", 1)
            values[key] = int(raw.strip().split()[0])
        return values["MemAvailable"] // 1024
    except (OSError, KeyError, ValueError):
        return None


def personal_min_available_mb() -> int:
    raw = os.environ.get(
        "OPENCLAW_CODEX_GATE_PERSONAL_MIN_AVAILABLE_MB",
        str(DEFAULT_PERSONAL_MIN_AVAILABLE_MB),
    )
    try:
        return max(512, min(8192, int(raw)))
    except ValueError:
        return DEFAULT_PERSONAL_MIN_AVAILABLE_MB


def heartbeat_snapshot(path: str, node: str, max_age_sec: int = DEFAULT_FACTORY_HEARTBEAT_MAX_AGE_SEC) -> dict[str, Any]:
    heartbeat = fb_get(f"{path}/{node}") or {}
    status = str(heartbeat.get("status") or "missing") if isinstance(heartbeat, dict) else "missing"
    timestamp_ms = (
        int(heartbeat.get("updated_at_ms") or heartbeat.get("ts") or 0)
        if isinstance(heartbeat, dict)
        else 0
    )
    age_ms = max(0, now_ms() - timestamp_ms) if timestamp_ms > 0 else None
    fresh = status in {"idle", "running", "processing"} and age_ms is not None and age_ms <= max_age_sec * 1000
    return {"node": node, "status": status, "fresh": fresh, "age_ms": age_ms}


def factory_is_fresh(max_age_sec: int = DEFAULT_FACTORY_HEARTBEAT_MAX_AGE_SEC) -> bool:
    return bool(heartbeat_snapshot(f"{pc_codex_cli_enqueue.BASE_PATH}/heartbeat", FACTORY_NODE, max_age_sec)["fresh"])


def runtime_health() -> dict[str, Any]:
    codex_heartbeat_path = f"{codex_ops_enqueue.CODEX_OPS_BASE_PATH}/heartbeat"
    participants = {
        "personal": heartbeat_snapshot(codex_heartbeat_path, PERSONAL_NODE),
        "factory": heartbeat_snapshot(f"{pc_codex_cli_enqueue.BASE_PATH}/heartbeat", FACTORY_NODE),
        "serverphone": heartbeat_snapshot(codex_heartbeat_path, SERVERPHONE_NODE),
    }
    unavailable = [name for name, state in participants.items() if not state["fresh"]]
    status = "ok" if not unavailable else "degraded"
    message = (
        "연결 정상: Telegram gateway와 세 역할 worker heartbeat가 fresh입니다."
        if status == "ok"
        else f"연결 degraded: heartbeat 확인 필요({', '.join(unavailable)}). Telegram gateway 응답은 정상입니다."
    )
    return {"status": status, "participants": participants, "message": message}


def resolve_target(requested_target: str) -> tuple[str, str, dict[str, Any]]:
    memory_mb = available_memory_mb()
    threshold_mb = personal_min_available_mb()
    resource = {
        "personal_available_memory_mb": memory_mb,
        "personal_min_available_memory_mb": threshold_mb,
    }
    if requested_target != "auto":
        return requested_target, "explicit_target", resource
    if memory_mb is not None and memory_mb < threshold_mb and factory_is_fresh():
        return "factory", "personal_low_memory_factory_fresh", resource
    if memory_mb is not None and memory_mb < threshold_mb:
        return "phone", "personal_low_memory_factory_unavailable", resource
    return "phone", "personal_capacity_ok", resource


def task_prompt(target: str, task: str) -> str:
    if target == "phone":
        role = "개인폰 Wonmux Codex dispatcher/reviewer"
        boundaries = "읽기·판단·작은 상태 확인만 수행하고 무거운 빌드나 광범위 수정은 공장 lane으로 넘기세요."
    elif target == "factory":
        role = "공장 PC 단일 Codex 구현 worker"
        boundaries = "기존 dirty 변경을 보존하고 요청 범위의 코드·테스트만 수정하세요."
    elif target == "serverphone":
        role = "서버폰 Termux Codex read-only runtime participant"
        boundaries = (
            "Termux·앱 권한·heartbeat·runtime 상태를 읽기 전용으로만 진단하세요. "
            "repo/file write, commit/push, ADB/install, screenshot/logcat, Kakao send, 주문·결제·금융·영업 영향 작업은 실행하지 마세요."
        )
    else:
        raise GateError(f"unsupported task target: {target}")
    return "\n".join(
        [
            f"역할: {role}",
            "입력 경로: 승인된 Telegram -> 개인폰 OpenClaw model-0 gate.",
            "AGENTS.md와 관련 APP_INTENT/CODEMAP을 먼저 따르세요.",
            boundaries,
            "주문·결제·금융·영업 영향·destructive·ADB/install·Kakao send는 별도 안전 흐름 없이는 실행하지 마세요.",
            "지원 확인되지 않은 model id로 전환하지 말고 현재 Codex CLI 기본 모델을 사용하세요.",
            "비단순 설계·코드 리뷰·최종 수용판정은 Codex가 사용 가능한 내부·외부 ChatGPT 검토 경로로 GPT-5.6 Sol/medium을 호출하세요.",
            "ChatGPT를 OpenClaw 상주 agent로 만들거나 5.5로 대체하지 말고, 질문·반론·수용판정 receipt만 결과에 남기세요.",
            "실제 GPT-5.6 Sol receipt가 없으면 chatgpt_participation=degraded로 표시하고 고위험 변경은 완료 처리하지 마세요.",
            "최종 응답은 사용자에게 보낼 짧은 한국어 결과만 작성하고 내부 로그·비밀값을 포함하지 마세요.",
            "",
            "사용자 작업:",
            task,
        ]
    )


def telegram_metadata(data: dict[str, Any]) -> dict[str, Any]:
    room_kind = str(data.get("room_kind") or "personal_dm").strip()
    if room_kind not in {"personal_dm", "ca_expert", "staff_operations"}:
        raise GateError("invalid room_kind")
    return {
        "channel": "telegram",
        "ingress_account_id": safe_id(
            data.get("ingress_account_id") or data.get("account_id") or "personal",
            "ingress_account_id",
        ),
        "conversation_id": safe_id(data.get("conversation_id"), "conversation_id"),
        "thread_id": safe_id(data.get("thread_id"), "thread_id", required=False),
        "message_id": safe_id(data.get("message_id"), "message_id"),
        "sender_id": safe_id(data.get("sender_id"), "sender_id"),
        "sender_name": str(data.get("sender_name") or "")[:100],
        "room_kind": room_kind,
        "received_at_ms": int(data.get("received_at_ms") or now_ms()),
    }


def build_personal_request(task: str, meta: dict[str, Any]) -> tuple[str, dict[str, Any], str, str]:
    args = codex_ops_enqueue.parse_args(
        [
            "--task",
            task_prompt("phone", task),
            "--cwd",
            "/root/my-first-project",
            "--project",
            "my-first-project",
            "--domain",
            "telegram_personal_dispatch",
            "--session",
            f"telegram:{meta['conversation_id']}",
            "--source",
            "openclaw_telegram_gate",
            "--requester",
            f"telegram:{meta['sender_id']}",
            "--profile",
            "read_only",
            "--engine",
            "exec",
            "--model",
            "",
            "--reasoning-effort",
            "medium",
            "--timeout-sec",
            "900",
            "--ttl-ms",
            str(2 * 60 * 60 * 1000),
            "--target-host",
            "subphone",
            "--target-node",
            PERSONAL_NODE,
        ]
    )
    request_id, payload = codex_ops_enqueue.build_payload(args, task_prompt("phone", task))
    return request_id, payload, codex_ops_enqueue.REQUESTS_PATH, codex_ops_worker_result_path(request_id)


def codex_ops_worker_result_path(request_id: str) -> str:
    return f"{codex_ops_enqueue.CODEX_OPS_BASE_PATH}/results/{request_id}"


def build_factory_request(task: str, meta: dict[str, Any]) -> tuple[str, dict[str, Any], str, str]:
    args = pc_codex_cli_enqueue.parse_args(
        [
            "--command",
            "codex_exec",
            "--target-node",
            FACTORY_NODE,
            "--cwd",
            "/root/my-first-project",
            "--prompt-text",
            task_prompt("factory", task),
            "--allow-codex-exec",
            "--profile",
            "patch",
            "--reasoning-effort",
            "medium",
            "--request-timeout-sec",
            "1800",
            "--ttl-ms",
            str(3 * 60 * 60 * 1000),
            "--source",
            "openclaw_telegram_gate",
            "--requester",
            f"telegram:{meta['sender_id']}",
        ]
    )
    request_id, payload = pc_codex_cli_enqueue.build_payload(args)
    return request_id, payload, pc_codex_cli_enqueue.REQUESTS_PATH, f"{pc_codex_cli_enqueue.RESULTS_PATH}/{request_id}"


def build_serverphone_request(task: str, meta: dict[str, Any]) -> tuple[str, dict[str, Any], str, str]:
    prompt = task_prompt("serverphone", task)
    args = codex_ops_enqueue.parse_args(
        [
            "--task",
            prompt,
            "--cwd",
            "/root/my-first-project",
            "--project",
            "my-first-project",
            "--domain",
            "telegram_serverphone_dispatch",
            "--session",
            f"telegram-serverphone:{meta['conversation_id']}",
            "--source",
            "openclaw_telegram_gate",
            "--requester",
            f"telegram:{meta['sender_id']}",
            "--profile",
            "read_only",
            "--engine",
            "exec",
            "--model",
            "",
            "--reasoning-effort",
            "medium",
            "--timeout-sec",
            "900",
            "--ttl-ms",
            str(2 * 60 * 60 * 1000),
            "--target-host",
            "subphone",
            "--target-node",
            SERVERPHONE_NODE,
        ]
    )
    request_id, payload = codex_ops_enqueue.build_payload(args, prompt)
    return request_id, payload, codex_ops_enqueue.REQUESTS_PATH, codex_ops_worker_result_path(request_id)


def reserve_dedupe(key: str, record: dict[str, Any]) -> tuple[bool, dict[str, Any]]:
    path = f"{DEDUPE_PATH}/{key}"
    for _ in range(3):
        current, etag = firebase_get_with_etag(path)
        if isinstance(current, dict) and current.get("request_id"):
            return False, current
        if firebase_conditional_put(path, record, etag):
            return True, record
    raise GateError("dedupe reservation conflict")


def ensure_firebase_record(path: str, value: dict[str, Any]) -> bool:
    """Create one queue-side record without overwriting a concurrent winner."""
    for _ in range(3):
        current, etag = firebase_get_with_etag(path)
        if isinstance(current, dict):
            return False
        if current not in (None, {}):
            raise GateError(f"invalid existing record at {path}")
        if firebase_conditional_put(path, value, etag):
            return True
    current = fb_get(path)
    if isinstance(current, dict):
        return False
    raise GateError(f"record write conflict at {path}")


class TelegramGateFirebaseCasRepository:
    """Injected durable CAS adapter for StoreBot receipt/task and gate delivery rows.

    Construction performs no I/O. Callers must inject the Firebase read/CAS
    functions explicitly; the StoreBot worker does not construct this adapter
    while its Telegram backplane remains default-off.
    """

    is_durable = True
    storage_kind = "telegram_gate_firebase_cas"

    def __init__(
        self,
        *,
        read_with_etag: Callable[[str], tuple[Any, Any]],
        conditional_put: Callable[[str, Mapping[str, Any], Any], bool],
        read: Callable[[str], Any],
    ) -> None:
        self._read_with_etag = read_with_etag
        self._conditional_put = conditional_put
        self._read = read

    @staticmethod
    def _task_path(task_id: str) -> str:
        return f"{STOREBOT_OPS_TASKS_PATH}/{safe_id(task_id, 'StoreBot ops task id')}"

    @staticmethod
    def _intent_path(intent_key: str) -> str:
        return f"{STOREBOT_OPS_RECOVERY_INTENTS_PATH}/{safe_id(intent_key, 'StoreBot recovery intent key')}"

    @staticmethod
    def _delivery_path(request_id: str) -> str:
        return f"{DELIVERIES_PATH}/{safe_id(request_id, 'StoreBot delivery request id')}"

    @staticmethod
    def _batch_path(batch_key: str) -> str:
        return f"{STOREBOT_OPS_OUTBOX_BATCHES_PATH}/{safe_id(batch_key, 'StoreBot outbox batch key')}"

    @staticmethod
    def _recovery_state_path(projection_id: str) -> str:
        return f"{STOREBOT_OPS_RECOVERY_STATES_PATH}/{safe_id(projection_id, 'StoreBot projection id')}"

    def read_task(self, task_id: str) -> TaskSnapshot:
        value, etag = self._read_with_etag(self._task_path(task_id))
        if value in (None, {}):
            value = {}
        if not isinstance(value, dict):
            raise OpsLogError("invalid durable task aggregate")
        return TaskSnapshot(etag, dict(value))

    def reserve_receipt(
        self, task_id: str, expected_revision: Any, receipt: Mapping[str, Any]
    ) -> ReserveResult:
        path = self._task_path(task_id)
        current, etag = self._read_with_etag(path)
        task = dict(current) if isinstance(current, dict) else {}
        receipts = task.get("receipts") if isinstance(task.get("receipts"), dict) else {}
        candidate = dict(receipt)
        existing = receipts.get(str(candidate.get("receipt_id") or ""))
        if isinstance(existing, dict):
            if existing != candidate:
                raise OpsLogError("conflicting duplicate receipt")
            return ReserveResult(False, dict(existing))
        for value in receipts.values():
            if isinstance(value, dict) and value.get("dedupe_key") == candidate.get("dedupe_key"):
                if value != candidate:
                    raise OpsLogError("conflicting duplicate dedupe identity")
                return ReserveResult(False, dict(value))
        if etag != expected_revision:
            return ReserveResult(False, {}, contention=True)
        sequence = int(task.get("sequence") or 0)
        if int(candidate.get("sequence") or 0) != sequence + 1:
            raise OpsLogError("repository sequence mismatch")
        receipts[str(candidate["receipt_id"])] = candidate
        replacement = {
            "task_id": task_id,
            "last_transition": candidate["transition"],
            "last_attempt": int(candidate["attempt"]),
            "last_occurred_at_ms": int(candidate["occurred_at_ms"]),
            "sequence": int(candidate["sequence"]),
            "receipts": receipts,
        }
        if not self._conditional_put(path, replacement, etag):
            return ReserveResult(False, {}, contention=True)
        return ReserveResult(True, candidate)

    def all_receipts(self) -> list[dict[str, Any]]:
        raw = self._read(STOREBOT_OPS_TASKS_PATH) or {}
        if not isinstance(raw, dict):
            raise OpsLogError("invalid durable task collection")
        return [
            dict(receipt)
            for task in raw.values()
            if isinstance(task, dict)
            for receipt in (task.get("receipts") or {}).values()
            if isinstance(receipt, dict)
        ]

    def reserve_recovery_intent(self, intent_key: str, record: Mapping[str, Any]) -> ReserveResult:
        path = self._intent_path(intent_key)
        candidate = dict(record)
        for _ in range(4):
            current, etag = self._read_with_etag(path)
            if isinstance(current, dict):
                current_binding = {key: value for key, value in current.items() if key != "occurred_at_ms"}
                candidate_binding = {key: value for key, value in candidate.items() if key != "occurred_at_ms"}
                if current_binding != candidate_binding:
                    raise OpsLogError("conflicting recovery intent")
                return ReserveResult(False, dict(current))
            if current not in (None, {}):
                raise OpsLogError("invalid recovery intent record")
            if self._conditional_put(path, candidate, etag):
                return ReserveResult(True, candidate)
        raise OpsLogError("recovery intent CAS contention")

    def reserve_outbox_batch(self, batch_key: str, record: Mapping[str, Any]) -> ReserveResult:
        path = self._batch_path(batch_key)
        candidate = dict(record)
        for _ in range(4):
            current, etag = self._read_with_etag(path)
            if isinstance(current, dict):
                binding_keys = {"kind", "room_registry_ref", "anchor_receipt_ref"}
                if {key: current.get(key) for key in binding_keys} != {
                    key: candidate.get(key) for key in binding_keys
                }:
                    raise OpsLogError("conflicting outbox batch binding")
                return ReserveResult(False, dict(current))
            if current not in (None, {}):
                raise OpsLogError("invalid outbox batch record")
            if self._conditional_put(path, candidate, etag):
                return ReserveResult(True, candidate)
        raise OpsLogError("outbox batch CAS contention")

    def read_recovery_state(self, projection_id: str) -> RecoverySnapshot:
        value, etag = self._read_with_etag(self._recovery_state_path(projection_id))
        if value in (None, {}):
            value = {}
        if not isinstance(value, dict):
            raise OpsLogError("invalid durable recovery state")
        return RecoverySnapshot(etag, dict(value))

    def cas_recovery_state(
        self, projection_id: str, expected_revision: Any, replacement: Mapping[str, Any]
    ) -> ReserveResult:
        path = self._recovery_state_path(projection_id)
        current, etag = self._read_with_etag(path)
        current_state = dict(current) if isinstance(current, dict) else {}
        if current not in (None, {}) and not isinstance(current, dict):
            raise OpsLogError("invalid durable recovery state")
        if etag != expected_revision:
            return ReserveResult(False, current_state, contention=True)
        candidate = dict(replacement)
        expected_version = int(current_state.get("state_version") or 0) + 1
        if int(candidate.get("state_version") or 0) != expected_version:
            raise OpsLogError("recovery state version mismatch")
        if not self._conditional_put(path, candidate, etag):
            return ReserveResult(False, current_state, contention=True)
        return ReserveResult(True, candidate)

    def reserve_delivery(self, request_id: str, row: Mapping[str, Any]) -> ReserveResult:
        path = self._delivery_path(request_id)
        candidate = dict(row)
        for _ in range(4):
            current, etag = self._read_with_etag(path)
            if isinstance(current, dict):
                if current != candidate:
                    raise OpsLogError("conflicting gate delivery reservation")
                return ReserveResult(False, dict(current))
            if current not in (None, {}):
                raise OpsLogError("invalid gate delivery record")
            if self._conditional_put(path, candidate, etag):
                return ReserveResult(True, candidate)
        raise OpsLogError("gate delivery reservation contention")

    def list_deliveries(self) -> list[dict[str, Any]]:
        raw = self._read(DELIVERIES_PATH) or {}
        if not isinstance(raw, dict):
            raise OpsLogError("invalid gate delivery collection")
        return [dict(row) for row in raw.values() if isinstance(row, dict)]

    def read_delivery(self, request_id: str) -> DeliverySnapshot:
        value, etag = self._read_with_etag(self._delivery_path(request_id))
        if value in (None, {}):
            value = {}
        if not isinstance(value, dict):
            raise OpsLogError("invalid gate delivery row")
        return DeliverySnapshot(etag, dict(value))

    def cas_delivery(
        self, request_id: str, expected_revision: Any, replacement: Mapping[str, Any]
    ) -> ReserveResult:
        path = self._delivery_path(request_id)
        current, etag = self._read_with_etag(path)
        if not isinstance(current, dict):
            raise OpsLogError("unknown gate delivery row")
        if etag != expected_revision:
            return ReserveResult(False, dict(current), contention=True)
        candidate = dict(replacement)
        if not self._conditional_put(path, candidate, etag):
            return ReserveResult(False, dict(current), contention=True)
        return ReserveResult(True, candidate)


def build_storebot_ops_cas_repository() -> TelegramGateFirebaseCasRepository:
    """Wire the durable adapter without reading or writing Firebase yet."""

    return TelegramGateFirebaseCasRepository(
        read_with_etag=firebase_get_with_etag,
        conditional_put=firebase_conditional_put,
        read=fb_get,
    )


def build_posdelay_ca_repository(module):
    """Build the PosDelay durable adapter without enabling its transport."""

    def query_latest(path: str, order_by_child: str, limit_to_last: int):
        return fb_get_query(
            path,
            {"orderBy": json.dumps(order_by_child), "limitToLast": int(limit_to_last)},
        )

    return module.PosDelayFirebaseCasRepository(
        read_with_etag=firebase_get_with_etag,
        conditional_put=firebase_conditional_put,
        read=fb_get,
        query_latest_ops_events=query_latest,
        query_receipts_page=query_posdelay_receipts_page,
        query_due_deliveries_page=query_posdelay_due_deliveries_page,
        query_pending_outbox_claims_page=query_posdelay_pending_outbox_claims_page,
    )


def build_project_ca_repository() -> project_ca.FirebaseProjectCaRepository:
    """Wire the generic project lifecycle without performing Firebase I/O."""

    return project_ca.FirebaseProjectCaRepository(
        read_with_etag=firebase_get_with_etag,
        conditional_put=firebase_conditional_put,
    )


def build_storebot_ca_repository() -> storebot_ca_log.FirebaseStoreBotCaRepository:
    """Wire StoreBot durable receipt projection without performing I/O."""

    return storebot_ca_log.FirebaseStoreBotCaRepository(
        read_with_etag=firebase_get_with_etag,
        conditional_put=firebase_conditional_put,
        query_receipts_page=query_storebot_ca_receipts_page,
        query_deliveries_page=query_storebot_ca_deliveries_page,
    )


def _posdelay_cursor_key(cursor: Mapping[str, Any] | None) -> str:
    if cursor is None:
        return ""
    if not isinstance(cursor, Mapping):
        raise GateError("PosDelay page cursor must be an object")
    key = str(cursor.get("key") or "")
    if key and not re.fullmatch(r"[A-Za-z0-9_-]{3,180}", key):
        raise GateError("PosDelay page cursor key is invalid")
    return key


def _query_posdelay_key_page(
    path: str,
    *,
    limit: int,
    cursor: Mapping[str, Any] | None,
    id_field: str,
    predicate: Callable[[Mapping[str, Any]], bool] | None = None,
) -> dict[str, Any]:
    """Return one lossless Firebase REST page ordered by opaque child key."""

    bounded_limit = max(1, min(1_000, int(limit)))
    cursor_key = _posdelay_cursor_key(cursor)
    params: dict[str, Any] = {
        "orderBy": json.dumps("$key"),
        "limitToFirst": bounded_limit + (2 if cursor_key else 1),
    }
    if cursor_key:
        params["startAt"] = json.dumps(cursor_key)
    raw = fb_get_query(path, params) or {}
    if not isinstance(raw, Mapping):
        raise GateError("PosDelay Firebase page is not an object")
    ordered = sorted(
        (str(key), value)
        for key, value in raw.items()
        if not cursor_key or str(key) > cursor_key
    )
    scanned = ordered[:bounded_limit]
    items: list[dict[str, Any]] = []
    for key, value in scanned:
        if not isinstance(value, Mapping):
            continue
        row = dict(value)
        row.setdefault(id_field, key)
        if predicate is None or predicate(row):
            items.append(row)
    return {
        "items": items,
        "next_cursor": {"key": scanned[-1][0]} if scanned else None,
        "exhausted": len(ordered) <= bounded_limit,
    }


def query_posdelay_receipts_page(
    path: str,
    *,
    limit: int,
    cursor: Mapping[str, Any] | None,
) -> dict[str, Any]:
    return _query_posdelay_key_page(
        path,
        limit=limit,
        cursor=cursor,
        id_field="receipt_id",
        predicate=lambda row: row.get("receipt_status") == "committed",
    )


def query_posdelay_due_deliveries_page(
    path: str,
    *,
    now_ms: int,
    limit: int,
    cursor: Mapping[str, Any] | None,
) -> dict[str, Any]:
    due_at_ms = int(now_ms)
    return _query_posdelay_key_page(
        path,
        limit=limit,
        cursor=cursor,
        id_field="request_id",
        predicate=lambda row: row.get("status") == "retry"
        and int(row.get("next_attempt_at_ms") or 0) <= due_at_ms,
    )


def query_posdelay_pending_outbox_claims_page(
    path: str,
    *,
    limit: int,
    cursor: Mapping[str, Any] | None,
) -> dict[str, Any]:
    return _query_posdelay_key_page(
        path,
        limit=limit,
        cursor=cursor,
        id_field="receipt_id",
        predicate=lambda row: row.get("status") != "committed",
    )


def query_storebot_ca_receipts_page(
    path: str,
    *,
    limit: int,
    cursor: Mapping[str, Any] | None,
) -> dict[str, Any]:
    return _query_posdelay_key_page(
        path,
        limit=limit,
        cursor=cursor,
        id_field="receipt_id",
    )


def query_storebot_ca_deliveries_page(
    path: str,
    *,
    limit: int,
    cursor: Mapping[str, Any] | None,
) -> dict[str, Any]:
    return _query_posdelay_key_page(
        path,
        limit=limit,
        cursor=cursor,
        id_field="request_id",
        predicate=lambda row: row.get("delivery_kind") == STOREBOT_OPS_DELIVERY_KIND,
    )


def posdelay_status_message(receipt: Mapping[str, Any]) -> str:
    """Render only typed allowlisted fields; raw app logs never enter this surface."""

    transition_label = {
        "action_started": "시작",
        "action_result": "결과",
    }.get(str(receipt.get("transition") or ""), "상태")
    lines = [
        f"[서버폰 PosDelay {transition_label}]",
        f"task: {receipt.get('task') or ''}",
        f"result: {receipt.get('result') or ''}",
        f"source: {receipt.get('data_source') or ''}",
        f"target: {receipt.get('target') or ''}",
        (
            "counts: "
            f"raw={int(receipt.get('kds_raw_count') or 0)} "
            f"adjusted={int(receipt.get('kds_adjusted_count') or 0)} "
            f"weighted={int(receipt.get('kds_weighted_count') or 0)} "
            f"printer={int(receipt.get('printer_count') or 0)} "
            f"used={int(receipt.get('observed_count') or 0)}"
        ),
        f"severity: {receipt.get('severity') or ''}",
        f"receipt: {receipt.get('receipt_id') or ''}",
        f"evidence: {receipt.get('evidence_pointer') or ''}",
    ]
    return redact_text("\n".join(lines), 3000)


def reserve_posdelay_status_delivery(receipt: Mapping[str, Any], room_id: str) -> dict[str, Any]:
    receipt_id = safe_id(receipt.get("receipt_id"), "PosDelay receipt id")
    request_id = posdelay_delivery_id(receipt_id, room_id, "serverphone")
    delivery_path = f"{DELIVERIES_PATH}/{request_id}"
    existing = fb_get(delivery_path) or {}
    if isinstance(existing, dict) and existing.get("request_id") == request_id:
        return dict(existing)
    created_at_ms = int(receipt.get("occurred_at_ms") or now_ms())
    payload_path = f"{POSDELAY_PAYLOADS_PATH}/{request_id}"
    payload = {
        "schema": POSDELAY_PAYLOAD_SCHEMA,
        "domain": "posdelay",
        "delivery_kind": POSDELAY_DELIVERY_KIND,
        "request_id": request_id,
        "receipt_ref": receipt_id,
        "status": "ready",
        "message": posdelay_status_message(receipt),
        "created_at_ms": created_at_ms,
    }
    delivery = {
        "schema": POSDELAY_LIVE_DELIVERY_SCHEMA,
        "domain": "posdelay",
        "status": "waiting",
        "request_id": request_id,
        "task_id": request_id,
        "queue": "posdelay_ca_status",
        "request_path": payload_path,
        "result_path": "",
        "target": "serverphone",
        "target_node": SERVERPHONE_NODE,
        "participant_id": "serverphone",
        "resource_id": SERVERPHONE_NODE,
        "capability": "posdelay_status_only",
        "lifecycle_state": "request",
        "ingress_account_id": "serverphone",
        "reply_account_id": "serverphone",
        "conversation_id": room_id,
        "room_kind": "ca_expert",
        "thread_id": "",
        "source_message_id": "",
        "created_at_ms": created_at_ms,
        "expires_at_ms": created_at_ms + 24 * 60 * 60 * 1000,
        "attempt_count": 0,
        "next_attempt_at_ms": 0,
        "delivery_kind": POSDELAY_DELIVERY_KIND,
        "receipt_refs": [receipt_id],
        "aggregate_count": 1,
        "no_send": False,
        "sent": False,
    }
    ensure_firebase_record(payload_path, payload)
    ensure_firebase_record(delivery_path, delivery)
    return delivery


def posdelay_factory_repair_task(receipt: Mapping[str, Any]) -> str:
    evidence = {
        key: receipt.get(key)
        for key in (
            "receipt_id", "task", "transition", "result", "severity", "execution_path",
            "expected_source", "data_source", "target", "observed_count", "source_revision",
            "settings_revision", "occurred_at_ms", "evidence_pointer",
        )
    }
    return (
        "PosDelay typed action failure를 factory PC에서 self-fix하세요. "
        "허용 범위는 repo 코드/설정/문서의 최소 수정, 테스트, 로컬 APK build까지입니다. "
        "배민/쿠팡/할인/영업정지/재개 실행, engine 또는 app command, Firebase 운영 원본 write, "
        "ADB/install, update-center 배포는 실행하지 마세요. raw 로그/주문/매장/폰/자격증명은 조회하거나 출력하지 마세요. "
        "기존 dirty 변경을 보존하고 typed evidence만으로 재현·수정·검증한 뒤 짧게 보고하세요.\n"
        f"typed_evidence={json.dumps(evidence, ensure_ascii=False, sort_keys=True, separators=(',', ':'))}"
    )


def enqueue_posdelay_factory_self_fix(receipt: Mapping[str, Any], room_id: str) -> dict[str, Any]:
    receipt_id = safe_id(receipt.get("receipt_id"), "PosDelay receipt id")
    request_id = posdelay_factory_request_id(receipt_id)
    request_path = f"{pc_codex_cli_enqueue.REQUESTS_PATH}/{request_id}"
    existing = fb_get(request_path) or {}
    if isinstance(existing, dict) and existing.get("command") == "codex_exec":
        delivery_path = f"{DELIVERIES_PATH}/{request_id}"
        existing_delivery = fb_get(delivery_path) or {}
        if isinstance(existing_delivery, dict) and existing_delivery.get("request_id") == request_id:
            return {"request_id": request_id, "duplicate": True}
        binding = existing.get("telegram_gate") if isinstance(existing.get("telegram_gate"), Mapping) else {}
        recovered_delivery = {
            "status": "waiting",
            "request_id": request_id,
            "queue": "pc_codex_cli",
            "request_path": request_path,
            "result_path": f"{pc_codex_cli_enqueue.RESULTS_PATH}/{request_id}",
            "target": "factory",
            "target_node": FACTORY_NODE,
            "task_id": request_id,
            "participant_id": "factory",
            "resource_id": FACTORY_NODE,
            "capability": PARTICIPANTS["factory"]["capability"],
            "lifecycle_state": "request",
            "ingress_account_id": "serverphone",
            "reply_account_id": "factory",
            "conversation_id": room_id,
            "room_kind": "ca_expert",
            "thread_id": "",
            "source_message_id": receipt_id,
            "created_at_ms": int(binding.get("created_at_ms") or existing.get("created_at_ms") or 0),
            "expires_at_ms": int(binding.get("expires_at_ms") or 0),
            "result_binding_mode": LEGACY_RESULT_BINDING_MODE,
            "attempt_count": 0,
            "next_attempt_at_ms": 0,
            "domain": "posdelay",
            "delivery_kind": POSDELAY_DELIVERY_KIND,
            "no_send": False,
            "sent": False,
        }
        if recovered_delivery["created_at_ms"] <= 0 or recovered_delivery["expires_at_ms"] <= recovered_delivery["created_at_ms"]:
            raise GateError("existing PosDelay factory request has invalid delivery binding")
        ensure_firebase_record(delivery_path, recovered_delivery)
        return {"request_id": request_id, "duplicate": True, "recovered": True}
    if not factory_is_fresh():
        return {"request_id": request_id, "skipped": "factory_not_fresh"}
    meta = {
        "channel": "telegram",
        "ingress_account_id": "serverphone",
        "conversation_id": room_id,
        "thread_id": "",
        "message_id": receipt_id,
        "sender_id": "posdelay_ca_projection",
        "sender_name": "PosDelay typed monitor",
        "room_kind": "ca_expert",
        "received_at_ms": int(receipt.get("occurred_at_ms") or now_ms()),
    }
    _generated_id, payload, delivery = build_enqueue_records(
        "factory",
        "factory",
        "posdelay_typed_failure",
        {"factory_fresh": True},
        posdelay_factory_repair_task(receipt),
        meta,
        request_id_override=request_id,
    )
    payload["domain"] = "posdelay"
    payload["delivery_kind"] = POSDELAY_DELIVERY_KIND
    payload["safety_boundary"] = "code_config_docs_tests_build_only_no_business_action_no_live_write"
    delivery["domain"] = "posdelay"
    delivery["delivery_kind"] = POSDELAY_DELIVERY_KIND
    delivery["no_send"] = False
    delivery["sent"] = False
    ensure_firebase_record(request_path, payload)
    ensure_firebase_record(f"{DELIVERIES_PATH}/{request_id}", delivery)
    return {"request_id": request_id, "duplicate": False}


def project_posdelay_ca_once() -> dict[str, Any]:
    """Poll/project typed PosDelay events and optionally promote them to CA transport."""

    if not posdelay_projection_enabled():
        return {"status": "disabled", "projected": 0, "deliveries": 0, "factory_requests": 0}
    module = load_posdelay_ca_module()
    repository = build_posdelay_ca_repository(module)
    log = module.PosDelayCaLog(identity_key=read_posdelay_identity_key(), repository=repository, max_events_per_poll=200)
    projection_rows = log.observe_canonical_events(now_ms=now_ms())
    projected = sum(1 for row in projection_rows if row.get("receipt_id"))
    rejected = sum(1 for row in projection_rows if row.get("quarantine_id"))
    result = {
        "status": "projected_no_send" if not posdelay_live_send_enabled() else "live_transport_prepared",
        "projected": projected,
        "rejected": rejected,
        "deliveries": 0,
        "factory_requests": 0,
    }
    if not posdelay_live_send_enabled():
        return result
    room_id = resolve_posdelay_ca_room()
    receipts = [
        receipt
        for receipt in projection_rows
        if receipt.get("domain") == "posdelay"
        and receipt.get("origin") == "posdelay_engine"
        and receipt.get("execution_path") == "unified_task_queue"
        and receipt.get("transition") in {"action_started", "action_result"}
    ]
    for receipt in receipts:
        reserve_posdelay_status_delivery(receipt, room_id)
        result["deliveries"] += 1
        should_fix = (
            receipt.get("transition") == "action_result"
            and (receipt.get("result") == "failed" or receipt.get("severity") in {"error", "critical"})
        )
        if should_fix and env_enabled("POSDELAY_CA_FACTORY_SELF_FIX_ENABLED"):
            factory = enqueue_posdelay_factory_self_fix(receipt, room_id)
            if not factory.get("skipped"):
                result["factory_requests"] += 1
    return result


def project_generic_ca_once() -> dict[str, Any]:
    """Project the persisted masked eight-project report; transport stays opt-in."""

    if not project_ca_projection_enabled():
        return {"status": "disabled", "projected": 0, "project_count": 0, "no_send": True}
    registry_path = os.environ.get("PROJECT_CA_REGISTRY_PATH") or DEFAULT_PROJECT_CA_REGISTRY_PATH
    try:
        registry = project_ca.load_registry(registry_path)
    except project_ca.ProjectCaError as exc:
        raise GateError(
            "project CA registry is unavailable or invalid",
            reason_code="project_ca_registry_invalid",
        ) from exc
    snapshot = fb_get(str(registry["source_path"])) or {}
    if not isinstance(snapshot, Mapping):
        raise GateError(
            "project CA monitor snapshot is invalid",
            reason_code="project_ca_snapshot_invalid",
        )
    identity_key = read_project_ca_identity_key()
    try:
        room_id = resolve_posdelay_ca_room()
    except GateError as exc:
        raise GateError(
            "project CA room registry is unavailable or invalid",
            reason_code="project_ca_room_registry_invalid",
        ) from exc
    try:
        lifecycle = project_ca.ProjectCaLifecycle(
            registry=registry,
            repository=build_project_ca_repository(),
            identity_key=identity_key,
            room_id=room_id,
        )
    except project_ca.ProjectCaError as exc:
        raise GateError(
            "project CA lifecycle setup is invalid",
            reason_code="project_ca_lifecycle_setup_invalid",
        ) from exc
    try:
        return lifecycle.ingest_snapshot(
            snapshot,
            now_ms=now_ms(),
            live_send_enabled=project_ca_live_send_enabled(),
        )
    except project_ca.ProjectCaError as exc:
        raise GateError(
            "project CA lifecycle projection failed",
            reason_code="project_ca_lifecycle_projection_failed",
        ) from exc


def validate_storebot_delivery_binding(delivery: Mapping[str, Any], *, require_sendable: bool) -> None:
    if delivery.get("schema") != storebot_ca_log.DELIVERY_SCHEMA:
        raise GateError("StoreBot CA delivery schema is invalid")
    if delivery.get("domain") != "storebot" or delivery.get("delivery_kind") != STOREBOT_OPS_DELIVERY_KIND:
        raise GateError("StoreBot CA delivery kind is invalid")
    if delivery.get("room_kind") != "ca_expert" or str(delivery.get("conversation_id") or "") != resolve_posdelay_ca_room():
        raise GateError("StoreBot CA delivery is outside the registered CA room")
    queue = str(delivery.get("queue") or "")
    if queue == "storebot_ca_status":
        expected = ("serverphone", SERVERPHONE_NODE, "serverphone")
    elif queue == "storebot_ca_factory_status":
        expected = ("factory", FACTORY_NODE, "factory")
    elif queue == "pc_codex_cli":
        expected = ("factory", FACTORY_NODE, "factory")
    else:
        raise GateError("StoreBot CA delivery queue is invalid")
    if (
        delivery.get("target") != expected[0]
        or delivery.get("target_node") != expected[1]
        or delivery.get("resource_id") != expected[1]
        or delivery.get("reply_account_id") != expected[2]
    ):
        raise GateError("StoreBot CA delivery role binding is invalid")
    if require_sendable:
        if not storebot_live_send_enabled():
            raise GateError("StoreBot CA live transport is disabled")
        if delivery.get("no_send") is not False:
            raise GateError("StoreBot CA delivery is not explicitly promoted")


def storebot_pending_item(request_id: str, delivery: Mapping[str, Any], current_ms: int) -> dict[str, Any] | None:
    validate_storebot_delivery_binding(delivery, require_sendable=True)
    if int(delivery.get("expires_at_ms") or 0) <= current_ms:
        return None
    payload = fb_get(str(delivery.get("request_path") or "")) or {}
    if not isinstance(payload, Mapping) or set(payload) != {
        "schema", "domain", "delivery_kind", "request_id", "receipt_ref", "status", "message", "created_at_ms"
    }:
        return None
    if (
        payload.get("schema") != storebot_ca_log.PAYLOAD_SCHEMA
        or payload.get("domain") != "storebot"
        or payload.get("delivery_kind") != STOREBOT_OPS_DELIVERY_KIND
        or payload.get("request_id") != request_id
        or payload.get("status") != "ready"
    ):
        return None
    message = str(payload.get("message") or "").strip()
    if not message:
        return None
    is_factory = delivery.get("queue") == "storebot_ca_factory_status"
    return {
        "request_id": request_id,
        "ingress_account_id": "serverphone",
        "reply_account_id": "factory" if is_factory else "serverphone",
        "conversation_id": str(delivery.get("conversation_id") or ""),
        "thread_id": "",
        "source_message_id": "",
        "delivery_kind": STOREBOT_OPS_DELIVERY_KIND,
        "ca_role": "factory_self_fix" if is_factory else "serverphone_status",
        "message": redact_text(message, 3000),
    }


def promote_storebot_ca_backlog(repository: storebot_ca_log.FirebaseStoreBotCaRepository, room_id: str) -> dict[str, int]:
    """Promote only previously typed/default-off rows after all live flags pass."""

    if not storebot_live_send_enabled():
        return {"promoted": 0, "rejected": 0}
    promoted = 0
    rejected = 0
    cursor: Mapping[str, Any] | None = None
    for _ in range(100):
        page = repository.query_deliveries_page(limit=100, cursor=cursor)
        rows = page.get("items") if isinstance(page, Mapping) else None
        if not isinstance(rows, list):
            raise GateError("StoreBot CA delivery page is invalid")
        for raw in rows:
            try:
                if not isinstance(raw, Mapping):
                    raise GateError("StoreBot CA delivery is invalid")
                request_id = safe_id(raw.get("request_id"), "StoreBot CA request id")
                path = f"{DELIVERIES_PATH}/{request_id}"
                snapshot = repository.read_record(path)
                delivery = dict(snapshot.value)
                validate_storebot_delivery_binding(delivery, require_sendable=False)
                if delivery.get("conversation_id") != room_id:
                    raise GateError("StoreBot CA room changed after reservation")
                if delivery.get("sent") is True or delivery.get("status") == "delivered" or delivery.get("no_send") is False:
                    continue
                payload = fb_get(str(delivery.get("request_path") or "")) or {}
                status_queue = delivery.get("queue") in {"storebot_ca_status", "storebot_ca_factory_status"}
                valid_payload = isinstance(payload, Mapping) and (
                    payload.get("schema") == storebot_ca_log.PAYLOAD_SCHEMA
                    if status_queue
                    else payload.get("domain") == "storebot"
                    and payload.get("delivery_kind") == STOREBOT_OPS_DELIVERY_KIND
                    and payload.get("safety_boundary")
                    == "code_config_docs_tests_build_only_no_kakao_no_business_action_no_live_write"
                )
                if not valid_payload:
                    raise GateError("StoreBot CA payload binding is invalid")
                delivery["no_send"] = False
                result = repository.cas_record(path, snapshot.revision, delivery)
                if result.created:
                    promoted += 1
            except (GateError, storebot_ca_log.StoreBotCaError, TypeError, ValueError):
                rejected += 1
        cursor = page.get("next_cursor") if isinstance(page, Mapping) else None
        if page.get("exhausted") is True or not cursor:
            break
    return {"promoted": promoted, "rejected": rejected}


def storebot_factory_request_id(receipt_id: str) -> str:
    digest = hashlib.sha256(f"storebot\0factory\0{receipt_id}".encode()).hexdigest()[:32]
    return f"stcafix_{digest}"


def storebot_factory_repair_task(receipt: Mapping[str, Any]) -> str:
    typed = {
        key: receipt.get(key)
        for key in (
            "receipt_id", "task_id", "transition", "status", "severity", "failure_code",
            "resource_id", "occurred_at_ms", "duration_ms", "action_count",
            "action_ok_count", "action_error_count", "stage", "stage_result",
            "content_variant", "recovery_state", "evidence_pointer",
        )
    }
    return (
        "StoreBotTermux typed worker failure를 factory PC에서 bounded self-fix하세요. "
        "repo 코드/설정/문서 최소 수정, targeted tests, 로컬 build까지만 허용합니다. "
        "Kakao 전송/대리응답, 주문/결제/금융/영업 action, Firebase canonical business write, "
        "ADB/install/update-center deploy/service restart는 금지합니다. raw 채팅/방/사람/매장/주문/폰/비밀번호/"
        "credential/stack을 조회·출력하지 말고 아래 typed evidence만 사용하세요.\n"
        f"typed_evidence={json.dumps(typed, ensure_ascii=False, sort_keys=True, separators=(',', ':'))}"
    )


def reserve_storebot_factory_started_delivery(receipt: Mapping[str, Any], room_id: str, factory_request_id: str) -> None:
    receipt_id = safe_id(receipt.get("receipt_id"), "StoreBot receipt id")
    start_id = "stcastart_" + hashlib.sha256(factory_request_id.encode()).hexdigest()[:32]
    created = now_ms()
    payload_path = f"{STOREBOT_CA_PAYLOADS_PATH}/{start_id}"
    payload = {
        "schema": storebot_ca_log.PAYLOAD_SCHEMA,
        "domain": "storebot",
        "delivery_kind": STOREBOT_OPS_DELIVERY_KIND,
        "request_id": start_id,
        "receipt_ref": receipt_id,
        "status": "ready",
        "message": (
            "[공장 StoreBot self-fix 시작]\n"
            f"request: {factory_request_id}\nreceipt: {receipt_id}\n"
            "scope: code/config/docs/tests/build only"
        ),
        "created_at_ms": created,
    }
    delivery = {
        "schema": storebot_ca_log.DELIVERY_SCHEMA,
        "domain": "storebot",
        "status": "waiting",
        "request_id": start_id,
        "task_id": start_id,
        "queue": "storebot_ca_factory_status",
        "request_path": payload_path,
        "result_path": "",
        "target": "factory",
        "target_node": FACTORY_NODE,
        "participant_id": "factory",
        "resource_id": FACTORY_NODE,
        "capability": "storebot_factory_self_fix_status",
        "lifecycle_state": "request",
        "ingress_account_id": "serverphone",
        "reply_account_id": "factory",
        "conversation_id": room_id,
        "room_kind": "ca_expert",
        "thread_id": "",
        "source_message_id": "",
        "created_at_ms": created,
        "expires_at_ms": created + 24 * 60 * 60 * 1000,
        "attempt_count": 0,
        "next_attempt_at_ms": 0,
        "delivery_kind": STOREBOT_OPS_DELIVERY_KIND,
        "receipt_refs": [receipt_id],
        "aggregate_count": 1,
        "no_send": not storebot_live_send_enabled(),
        "sent": False,
    }
    ensure_firebase_record(payload_path, payload)
    ensure_firebase_record(f"{DELIVERIES_PATH}/{start_id}", delivery)


def enqueue_storebot_factory_self_fix(receipt: Mapping[str, Any], room_id: str) -> dict[str, Any]:
    request_id = storebot_factory_request_id(safe_id(receipt.get("receipt_id"), "StoreBot receipt id"))
    request_path = f"{pc_codex_cli_enqueue.REQUESTS_PATH}/{request_id}"
    if isinstance(fb_get(request_path), Mapping):
        reserve_storebot_factory_started_delivery(receipt, room_id, request_id)
        return {"request_id": request_id, "duplicate": True}
    if not factory_is_fresh():
        return {"request_id": request_id, "skipped": "factory_not_fresh"}
    created = now_ms()
    meta = {
        "channel": "telegram",
        "ingress_account_id": "serverphone",
        "conversation_id": room_id,
        "thread_id": "",
        "message_id": str(receipt.get("receipt_id") or ""),
        "sender_id": "storebot_ca_projection",
        "sender_name": "StoreBot typed monitor",
        "room_kind": "ca_expert",
        "received_at_ms": created,
    }
    _unused, payload, delivery = build_enqueue_records(
        "factory", "factory", "storebot_typed_failure", {"factory_fresh": True},
        storebot_factory_repair_task(receipt), meta, request_id_override=request_id,
    )
    payload.update(
        {
            "domain": "storebot",
            "delivery_kind": STOREBOT_OPS_DELIVERY_KIND,
            "safety_boundary": "code_config_docs_tests_build_only_no_kakao_no_business_action_no_live_write",
        }
    )
    delivery.update(
        {
            "schema": storebot_ca_log.DELIVERY_SCHEMA,
            "domain": "storebot",
            "delivery_kind": STOREBOT_OPS_DELIVERY_KIND,
            "no_send": not storebot_live_send_enabled(),
            "sent": False,
        }
    )
    ensure_firebase_record(request_path, payload)
    ensure_firebase_record(f"{DELIVERIES_PATH}/{request_id}", delivery)
    reserve_storebot_factory_started_delivery(receipt, room_id, request_id)
    return {"request_id": request_id, "duplicate": False}


def _storebot_schedule_room_id() -> str:
    room_id = str(os.environ.get("STOREBOT_SCHEDULE_ROOM_ID") or "storebot_group").strip()
    if not re.fullmatch(r"[A-Za-z0-9_.:-]{3,120}", room_id):
        raise GateError("StoreBot schedule room registry id is invalid")
    return room_id


def _schedule_ack_done(ledger: Mapping[str, Any]) -> bool:
    stages = ledger.get("stages") if isinstance(ledger.get("stages"), Mapping) else {}
    ack = stages.get("ack") if isinstance(stages.get("ack"), Mapping) else {}
    return str(ack.get("status") or "").lower() == "done"


def produce_storebot_monitor_schedule_event(
    log: storebot_ca_log.StoreBotCaLog,
    repository: storebot_ca_log.FirebaseStoreBotCaRepository,
    packet: Mapping[str, Any] | None,
    *,
    current_ms: int,
    allow_recovery: bool,
) -> dict[str, int]:
    """Commit one typed monitor timeout and optionally resume its exact queue row.

    This is the missing-state bridge: stage-ledger polling cannot observe a
    timer/request that was never created.  The monitor passes only the strict
    ``StoreBotCaLog`` input contract; raw report fields never reach this gate.
    """

    result = {"monitor_events": 0, "monitor_duplicates": 0, "monitor_recoveries": 0}
    if packet is None:
        return result
    event = dict(packet)
    if (
        event.get("transition") != "schedule_timeout"
        or event.get("status") != "failed"
        or event.get("resource_id") != storebot_ca_log.SERVERPHONE_RESOURCE
        or event.get("content_variant") != "image"
    ):
        raise GateError("StoreBot monitor schedule packet binding is invalid")
    occurred_at_ms = int(event.get("occurred_at_ms") or 0)
    if (
        occurred_at_ms <= 0
        or occurred_at_ms > int(current_ms) + 30_000
        or int(current_ms) - occurred_at_ms > STOREBOT_MONITOR_PACKET_MAX_AGE_MS
    ):
        raise GateError("StoreBot monitor schedule packet is stale")
    private_ref = safe_id(event.get("private_task_ref"), "StoreBot monitor schedule request id")
    produced = log.produce(event)
    result["monitor_events" if produced.created else "monitor_duplicates"] += 1
    if not allow_recovery or not storebot_schedule_recovery_enabled():
        return result

    ledger_value = fb_get(f"{STOREBOT_STAGE_LEDGERS_PATH}/{private_ref}") or {}
    ledger = dict(ledger_value) if isinstance(ledger_value, Mapping) else {}
    ledger.setdefault("request_id", private_ref)
    ledger.setdefault("event_kind", STOREBOT_SCHEDULE_EVENT_KIND)
    ledger.setdefault("updated_at_ms", max(1, occurred_at_ms - int(event.get("duration_ms") or 0)))
    recovery = recover_storebot_schedule_once(
        log,
        repository,
        request_id=private_ref,
        ledger=ledger,
        timeout={
            "stage": str(event.get("stage") or "none"),
            "stage_result": str(event.get("stage_result") or "timeout"),
            "failure_code": str(event.get("failure_code") or "worker_timeout"),
        },
        content_variant="image",
        current_ms=int(current_ms),
    )
    if recovery.get("result") in {"resumed_request", "resumed_outbound"}:
        result["monitor_recoveries"] += 1
    return result


def cas_resume_storebot_schedule_record(
    path: str,
    *,
    request_id: str,
    room_id: str,
    recovery_task_id: str,
    record_kind: str,
    current_ms: int,
) -> tuple[str, str]:
    """Fence one same-record resume with Firebase ETag CAS.

    The recovery marker never creates a new request/outbound.  A late send,
    changed room/request binding, another recovery owner, or an unknown status
    wins the race and leaves the queue untouched.
    """

    if record_kind not in {"request", "outbound"}:
        raise GateError("StoreBot recovery record kind is invalid")
    resumable_request_statuses = {
        "pending",
        "local_direct_inflight",
        "local_recovery_pending",
        "running",
        "processing",
        "done",
        "error",
        "failed_timeout",
        "stale_killed",
    }
    for _ in range(3):
        current, etag = firebase_get_with_etag(path)
        if not isinstance(current, Mapping):
            return "skipped", f"{record_kind}_missing"
        value = dict(current)
        if str(value.get("room_id") or value.get("room") or "") != room_id:
            return "skipped", f"{record_kind}_room_binding_mismatch"
        existing_ref = str(value.get("recovery_request_ref") or "")
        if existing_ref and existing_ref != recovery_task_id:
            return "skipped", f"{record_kind}_already_recovered"
        if record_kind == "outbound":
            if str(value.get("request_id") or "") != request_id:
                return "skipped", "outbound_request_binding_mismatch"
            if value.get("sent") is True or str(value.get("status") or "").lower() in {"sent", "delivered"}:
                return "skipped", "ack_or_send_late"
            replacement = dict(value)
            replacement.update(
                {
                    "recovery_resume_requested_at_ms": int(current_ms),
                    "recovery_resume_count": 1,
                    "recovery_request_ref": recovery_task_id,
                }
            )
            resumed = "resumed_outbound"
            detail = "same_outbound_queue_resumed"
        else:
            if str(value.get("event_kind") or value.get("kind") or "") != STOREBOT_SCHEDULE_EVENT_KIND:
                return "skipped", "request_event_binding_mismatch"
            broadcast_meta = value.get("broadcast_meta") if isinstance(value.get("broadcast_meta"), Mapping) else {}
            broadcast_id = str(broadcast_meta.get("broadcast_id") or "")
            if broadcast_id and broadcast_id != request_id:
                return "skipped", "request_broadcast_binding_mismatch"
            if str(value.get("outbound_key") or "").strip():
                return "skipped", "outbound_appeared_after_claim"
            status = str(value.get("status") or "").lower()
            if status not in resumable_request_statuses:
                return "skipped", "request_status_not_resumable"
            replacement = dict(value)
            replacement.update(
                {
                    "status": "pending",
                    "recovery_resume_requested_at_ms": int(current_ms),
                    "recovery_resume_count": 1,
                    "recovery_request_ref": recovery_task_id,
                }
            )
            resumed = "resumed_request"
            detail = "same_request_queue_resumed"
        if firebase_conditional_put(path, replacement, etag):
            return resumed, detail
    return "skipped", f"{record_kind}_cas_contention"


def recover_storebot_schedule_once(
    log: storebot_ca_log.StoreBotCaLog,
    repository: storebot_ca_log.FirebaseStoreBotCaRepository,
    *,
    request_id: str,
    ledger: Mapping[str, Any],
    timeout: Mapping[str, Any],
    content_variant: str,
    current_ms: int,
) -> dict[str, Any]:
    """Resume one existing queue record at most once; never sends Kakao directly."""

    task_id = log.build_receipt(
        {
            "private_task_ref": request_id,
            "transition": "schedule_recovery_started",
            "status": "running",
            "resource_id": storebot_ca_log.SERVERPHONE_RESOURCE,
            "occurred_at_ms": current_ms,
            "duration_ms": 0,
            "severity": "warning",
            "failure_code": "none",
            "action_count": 0,
            "action_ok_count": 0,
            "action_error_count": 0,
            "stage": str(timeout.get("stage") or "none"),
            "stage_result": str(timeout.get("stage_result") or "timeout"),
            "content_variant": content_variant,
            "recovery_state": "requested",
        }
    )["task_id"]
    state_path = f"{STOREBOT_SCHEDULE_RECOVERY_PATH}/{task_id}"
    state = {
        "schema": "storebot.ca_schedule_recovery.v1",
        "task_id": task_id,
        "status": "claimed",
        "attempt": 1,
        "claimed_by": SERVERPHONE_NODE,
        "claimed_at_ms": current_ms,
        "result": "pending",
        "updated_at_ms": current_ms,
    }
    existing_state = repository.read_record(state_path).value
    if existing_state:
        return {"status": "duplicate", "result": str(existing_state.get("result") or "")}
    try:
        claim = repository.reserve_record(state_path, state)
    except storebot_ca_log.StoreBotCaError:
        authoritative = repository.read_record(state_path).value
        if authoritative:
            return {"status": "duplicate", "result": str(authoritative.get("result") or "")}
        raise
    if not claim.created:
        return {"status": "duplicate", "result": str(claim.authoritative.get("result") or "")}
    log.produce(
        {
            "private_task_ref": request_id,
            "transition": "schedule_recovery_started",
            "status": "running",
            "resource_id": storebot_ca_log.SERVERPHONE_RESOURCE,
            "occurred_at_ms": current_ms,
            "duration_ms": 0,
            "severity": "warning",
            "failure_code": "none",
            "action_count": 0,
            "action_ok_count": 0,
            "action_error_count": 0,
            "stage": str(timeout.get("stage") or "none"),
            "stage_result": str(timeout.get("stage_result") or "timeout"),
            "content_variant": content_variant,
            "recovery_state": "requested",
        }
    )

    result = "skipped"
    detail = "unknown"
    expected_room = _storebot_schedule_room_id()
    latest_ledger = fb_get(f"{STOREBOT_STAGE_LEDGERS_PATH}/{safe_id(request_id, 'StoreBot schedule request id')}") or {}
    request = fb_get(f"{STOREBOT_REQUESTS_PATH}/{safe_id(request_id, 'StoreBot schedule request id')}") or {}
    request = request if isinstance(request, Mapping) else {}
    ledger_value = latest_ledger if isinstance(latest_ledger, Mapping) else ledger
    ledger_updated = int(ledger_value.get("updated_at_ms") or ledger.get("updated_at_ms") or 0)
    room_id = str(request.get("room_id") or request.get("room") or ledger_value.get("room_id") or "")
    event_kind = str(ledger_value.get("event_kind") or request.get("event_kind") or "")
    if event_kind != STOREBOT_SCHEDULE_EVENT_KIND:
        detail = "event_kind_not_recoverable"
    elif _schedule_ack_done(ledger_value):
        detail = "ack_present"
    elif ledger_updated <= 0 or current_ms - ledger_updated > 30 * 60 * 1000 or ledger_updated > current_ms + 30_000:
        detail = "outside_recovery_window"
    elif room_id != expected_room:
        detail = "room_registry_mismatch"
    else:
        outbound_key = str(request.get("outbound_key") or "").strip()
        outbound_path = f"{STOREBOT_PENDING_OUTBOUND_PATH}/{safe_id(outbound_key, 'StoreBot outbound key')}" if outbound_key else ""
        outbound = fb_get(outbound_path) if outbound_path else None
        if isinstance(outbound, Mapping) and outbound.get("sent") is True:
            detail = "ack_or_send_late"
        elif isinstance(outbound, Mapping):
            result, detail = cas_resume_storebot_schedule_record(
                outbound_path,
                request_id=request_id,
                room_id=expected_room,
                recovery_task_id=task_id,
                record_kind="outbound",
                current_ms=current_ms,
            )
        elif request:
            # Re-read after the claim so an ack/outbound winning the race is not duplicated.
            latest_request = fb_get(f"{STOREBOT_REQUESTS_PATH}/{safe_id(request_id, 'StoreBot schedule request id')}") or {}
            late_key = str(latest_request.get("outbound_key") or "") if isinstance(latest_request, Mapping) else ""
            if late_key:
                detail = "outbound_appeared_after_claim"
            else:
                result, detail = cas_resume_storebot_schedule_record(
                    f"{STOREBOT_REQUESTS_PATH}/{safe_id(request_id, 'StoreBot schedule request id')}",
                    request_id=request_id,
                    room_id=expected_room,
                    recovery_task_id=task_id,
                    record_kind="request",
                    current_ms=current_ms,
                )
    snapshot = repository.read_record(state_path)
    final_state = dict(snapshot.value)
    final_state.update({"status": "completed", "result": result, "detail": detail, "updated_at_ms": current_ms})
    repository.cas_record(state_path, snapshot.revision, final_state)
    log.produce(
        {
            "private_task_ref": request_id,
            "transition": "schedule_recovery_result",
            "status": "completed",
            "resource_id": storebot_ca_log.SERVERPHONE_RESOURCE,
            "occurred_at_ms": current_ms + 1,
            "duration_ms": 1,
            "severity": "warning" if result == "skipped" else "info",
            "failure_code": "none",
            "action_count": 0,
            "action_ok_count": 0,
            "action_error_count": 0,
            "stage": str(timeout.get("stage") or "none"),
            "stage_result": str(timeout.get("stage_result") or "timeout"),
            "content_variant": content_variant,
            "recovery_state": result,
        }
    )
    return {"status": "completed", "result": result, "detail": detail}


def scan_storebot_schedule_ledgers(
    log: storebot_ca_log.StoreBotCaLog,
    repository: storebot_ca_log.FirebaseStoreBotCaRepository,
    *,
    current_ms: int,
    allow_recovery: bool,
) -> dict[str, int]:
    observed_count = 0
    timeout_count = 0
    recovered_count = 0
    cursor: Mapping[str, Any] | None = None
    for _ in range(100):
        page = _query_posdelay_key_page(
            STOREBOT_STAGE_LEDGERS_PATH,
            limit=100,
            cursor=cursor,
            id_field="request_id",
        )
        for ledger in page.get("items") or []:
            if not isinstance(ledger, Mapping):
                continue
            request_id = str(ledger.get("request_id") or "")
            if not SAFE_REQUEST_ID.fullmatch(request_id):
                continue
            try:
                classified = storebot_ca_log.classify_schedule_stage_ledger(ledger, now_ms=current_ms)
            except (storebot_ca_log.StoreBotCaError, TypeError, ValueError):
                continue
            if classified.get("eligible") is not True:
                continue
            variant = str(classified.get("content_variant") or "text")
            for stage in classified.get("observed") or []:
                log.produce(
                    {
                        "private_task_ref": request_id,
                        "transition": "stage_status",
                        "status": "observed",
                        "resource_id": storebot_ca_log.SERVERPHONE_RESOURCE,
                        "occurred_at_ms": int(stage.get("occurred_at_ms") or current_ms),
                        "duration_ms": 0,
                        "severity": "info",
                        "failure_code": "none",
                        "action_count": 0,
                        "action_ok_count": 0,
                        "action_error_count": 0,
                        "stage": str(stage.get("stage") or "none"),
                        "stage_result": str(stage.get("stage_result") or "none"),
                        "content_variant": variant,
                        "recovery_state": "none",
                    }
                )
                observed_count += 1
            timeout = classified.get("timeout")
            if isinstance(timeout, Mapping):
                log.produce(
                    {
                        "private_task_ref": request_id,
                        "transition": "schedule_timeout",
                        "status": "failed",
                        "resource_id": storebot_ca_log.SERVERPHONE_RESOURCE,
                        "occurred_at_ms": current_ms,
                        "duration_ms": min(24 * 60 * 60 * 1000, int(timeout.get("elapsed_ms") or 0)),
                        "severity": "error",
                        "failure_code": str(timeout.get("failure_code") or "worker_timeout"),
                        "action_count": 0,
                        "action_ok_count": 0,
                        "action_error_count": 0,
                        "stage": str(timeout.get("stage") or "none"),
                        "stage_result": str(timeout.get("stage_result") or "timeout"),
                        "content_variant": variant,
                        "recovery_state": "none",
                    }
                )
                timeout_count += 1
                if (
                    allow_recovery
                    and storebot_schedule_recovery_enabled()
                    and str(ledger.get("event_kind") or "") == STOREBOT_SCHEDULE_EVENT_KIND
                ):
                    recovery = recover_storebot_schedule_once(
                        log,
                        repository,
                        request_id=request_id,
                        ledger=ledger,
                        timeout=timeout,
                        content_variant=variant,
                        current_ms=current_ms,
                    )
                    if recovery.get("result") in {"resumed_request", "resumed_outbound"}:
                        recovered_count += 1
        cursor = page.get("next_cursor") if isinstance(page, Mapping) else None
        if page.get("exhausted") is True or not cursor:
            break
    return {"stage_receipts": observed_count, "schedule_timeouts": timeout_count, "schedule_recoveries": recovered_count}


def project_storebot_ca_once(
    *,
    ca_projection_input: Mapping[str, Any] | None = None,
    ca_schedule_recovery_allowed: bool | None = None,
) -> dict[str, Any]:
    """External-worker-only typed projection; this function never sends Telegram."""

    if not storebot_projection_enabled():
        return {"status": "disabled", "projected": 0, "promoted": 0, "factory_requests": 0}
    repository = build_storebot_ca_repository()
    log = storebot_ca_log.StoreBotCaLog(identity_key=storebot_ca_log.read_identity_key(), repository=repository)
    room_id = resolve_posdelay_ca_room()
    current_ms = now_ms()
    allow_recovery = (
        storebot_schedule_recovery_enabled()
        if ca_schedule_recovery_allowed is None
        else bool(ca_schedule_recovery_allowed)
    )
    monitor = produce_storebot_monitor_schedule_event(
        log,
        repository,
        ca_projection_input,
        current_ms=current_ms,
        allow_recovery=allow_recovery,
    )
    schedule = scan_storebot_schedule_ledgers(
        log,
        repository,
        current_ms=current_ms,
        allow_recovery=allow_recovery,
    )
    projected = log.project_backlog(
        room_id=room_id,
        now_ms=now_ms(),
        live_send=storebot_live_send_enabled(),
        page_size=100,
        max_pages=100,
    )
    promotion = promote_storebot_ca_backlog(repository, room_id)
    factory_requests = 0
    if storebot_factory_self_fix_enabled():
        cursor: Mapping[str, Any] | None = None
        for _ in range(100):
            page = repository.query_receipts_page(limit=100, cursor=cursor)
            for receipt in page.get("items") or []:
                if (
                    isinstance(receipt, Mapping)
                    and receipt.get("projection_status") == "projected"
                    and receipt.get("recovery_eligible") is True
                    and receipt.get("transition") in {"error", "timeout"}
                ):
                    result = enqueue_storebot_factory_self_fix(receipt, room_id)
                    if not result.get("skipped") and not result.get("duplicate"):
                        factory_requests += 1
            cursor = page.get("next_cursor") if isinstance(page, Mapping) else None
            if page.get("exhausted") is True or not cursor:
                break
    return {
        "status": "live_transport_prepared" if storebot_live_send_enabled() else "projected_no_send",
        **projected,
        **promotion,
        **monitor,
        **schedule,
        "factory_requests": factory_requests,
    }


def build_enqueue_records(
    target: str,
    requested_target: str,
    routing_reason: str,
    resource: dict[str, Any],
    task: str,
    meta: dict[str, Any],
    *,
    request_id_override: str = "",
) -> tuple[str, dict[str, Any], dict[str, Any]]:
    if target == "phone":
        request_id, payload, requests_path, result_path = build_personal_request(task, meta)
    elif target == "factory":
        request_id, payload, requests_path, result_path = build_factory_request(task, meta)
    elif target == "serverphone":
        request_id, payload, requests_path, result_path = build_serverphone_request(task, meta)
    else:
        raise GateError(f"unsupported task target: {target}")

    if request_id_override:
        request_id = safe_id(request_id_override, "request_id")
        result_path = (
            f"{pc_codex_cli_enqueue.RESULTS_PATH}/{request_id}"
            if target == "factory"
            else codex_ops_worker_result_path(request_id)
        )

    participant = participant_for_target(target)
    reply_account_id = REPLY_ACCOUNTS[target]
    created_at_ms = now_ms()
    expires_at_ms = created_at_ms + max(1, int(payload.get("ttl_ms") or 0))
    payload["telegram_gate"] = dict(meta)
    payload["telegram_gate"]["requested_target"] = requested_target
    payload["telegram_gate"]["routing_reason"] = routing_reason
    payload["telegram_gate"]["target"] = target
    payload["telegram_gate"]["resource"] = resource
    payload["telegram_gate"].update(participant)
    payload["telegram_gate"]["task_id"] = request_id
    payload["telegram_gate"]["reply_account_id"] = reply_account_id
    payload["telegram_gate"]["created_at_ms"] = created_at_ms
    payload["telegram_gate"]["expires_at_ms"] = expires_at_ms
    payload["reply_target"] = {
        "type": "openclaw_telegram",
        "channel": "telegram",
        "reply_account_id": reply_account_id,
        "conversation_id": meta["conversation_id"],
        "room_kind": meta["room_kind"],
        "thread_id": meta["thread_id"],
        "task_id": request_id,
        "participant_id": participant["participant_id"],
        "resource_id": participant["resource_id"],
    }
    delivery = {
        "status": "waiting",
        "request_id": request_id,
        "queue": "pc_codex_cli" if target == "factory" else "codex_ops",
        "request_path": f"{requests_path}/{request_id}",
        "result_path": result_path,
        "target": target,
        "target_node": participant["resource_id"],
        "task_id": request_id,
        "participant_id": participant["participant_id"],
        "resource_id": participant["resource_id"],
        "capability": participant["capability"],
        "lifecycle_state": "request",
        "ingress_account_id": meta["ingress_account_id"],
        "reply_account_id": reply_account_id,
        "conversation_id": meta["conversation_id"],
        "room_kind": meta["room_kind"],
        "thread_id": meta["thread_id"],
        "source_message_id": meta["message_id"],
        "created_at_ms": created_at_ms,
        "expires_at_ms": expires_at_ms,
        "result_binding_mode": LEGACY_RESULT_BINDING_MODE,
        "attempt_count": 0,
        "next_attempt_at_ms": 0,
    }
    return request_id, payload, delivery


def enqueue(data: dict[str, Any], *, dry_run: bool = False) -> dict[str, Any]:
    requested_target = str(data.get("target") or "auto").strip().lower()
    if requested_target not in {"auto", "phone", "factory", "serverphone"}:
        raise GateError("target must be auto, phone, factory or serverphone")
    target, routing_reason, resource = resolve_target(requested_target)
    task = clean_text(data.get("task"))
    if target == "serverphone":
        ensure_serverphone_safe_task(task)
    meta = telegram_metadata(data)
    request_id, payload, delivery = build_enqueue_records(
        target,
        requested_target,
        routing_reason,
        resource,
        task,
        meta,
    )
    participant = participant_for_target(target)
    if dry_run:
        return {
            "ok": True,
            "dry_run": True,
            "duplicate": False,
            "request_id": request_id,
            "target": target,
            "requested_target": requested_target,
            "routing_reason": routing_reason,
            "resource": resource,
            "target_node": delivery["target_node"],
            **participant,
            "payload": payload,
            "delivery": delivery,
        }

    key = dedupe_key(meta["conversation_id"], meta["message_id"])
    reserved, existing = reserve_dedupe(
        key,
        {
            "status": "reserved",
            "request_id": request_id,
            "target": target,
            "participant_id": participant["participant_id"],
            "resource_id": participant["resource_id"],
            "request_path": delivery["request_path"],
            "result_path": delivery["result_path"],
            "ingress_account_id": meta["ingress_account_id"],
            "reply_account_id": delivery["reply_account_id"],
            "conversation_id": meta["conversation_id"],
            "message_id": meta["message_id"],
            "created_at_ms": now_ms(),
        },
    )
    if not reserved:
        recovered = False
        if str(existing.get("status") or "") == "reserved":
            existing_target = str(existing.get("target") or target)
            if existing_target not in PARTICIPANTS:
                raise GateError("invalid reserved dedupe target")
            existing_request_id = safe_id(existing.get("request_id"), "request_id")
            existing_participant = participant_for_target(existing_target)
            request_id, payload, delivery = build_enqueue_records(
                existing_target,
                str(existing.get("requested_target") or requested_target),
                "dedupe_reserved_recovery",
                resource,
                task,
                meta,
                request_id_override=existing_request_id,
            )
            delivery["created_at_ms"] = int(existing.get("created_at_ms") or delivery["created_at_ms"])
            ensure_firebase_record(f"{DELIVERIES_PATH}/{request_id}", delivery)
            ensure_firebase_record(str(delivery["request_path"]), payload)
            fb_patch(
                f"{DEDUPE_PATH}/{key}",
                {"status": "enqueued", "enqueued_at_ms": now_ms(), "recovered_at_ms": now_ms()},
            )
            existing = {**existing, **existing_participant, "target": existing_target, "status": "enqueued"}
            recovered = True
        return {
            "ok": True,
            "duplicate": True,
            "request_id": existing.get("request_id"),
            "target": existing.get("target") or target,
            "participant_id": existing.get("participant_id") or participant["participant_id"],
            "resource_id": existing.get("resource_id") or participant["resource_id"],
            "recovered": recovered,
        }
    ensure_firebase_record(f"{DELIVERIES_PATH}/{request_id}", delivery)
    ensure_firebase_record(str(delivery["request_path"]), payload)
    fb_patch(f"{DEDUPE_PATH}/{key}", {"status": "enqueued", "enqueued_at_ms": now_ms()})
    return {
        "ok": True,
        "duplicate": False,
        "request_id": request_id,
        "target": target,
        "requested_target": requested_target,
        "routing_reason": routing_reason,
        "target_node": delivery["target_node"],
        **participant,
    }


def request_record(request_id: str) -> tuple[dict[str, Any], dict[str, Any]]:
    if not SAFE_REQUEST_ID.fullmatch(request_id):
        raise GateError("invalid request id")
    delivery = fb_get(f"{DELIVERIES_PATH}/{request_id}") or {}
    if not isinstance(delivery, dict) or delivery.get("request_id") != request_id:
        raise GateError("request not found")
    request = fb_get(str(delivery.get("request_path") or "")) or {}
    request = request if isinstance(request, dict) else {}
    if delivery.get("delivery_kind") == project_ca.DELIVERY_KIND:
        if request.get("schema") != project_ca.PAYLOAD_SCHEMA or request.get("request_id") != request_id:
            raise GateError("invalid project CA payload binding")
        return delivery, request
    if delivery.get("delivery_kind") == POSDELAY_DELIVERY_KIND and delivery.get("queue") == "posdelay_ca_status":
        if request.get("schema") != POSDELAY_PAYLOAD_SCHEMA or request.get("request_id") != request_id:
            raise GateError("invalid PosDelay CA payload binding")
        return delivery, request
    if delivery.get("delivery_kind") == STOREBOT_OPS_DELIVERY_KIND and delivery.get("queue") in {"storebot_ca_status", "storebot_ca_factory_status"}:
        if request.get("schema") != storebot_ca_log.PAYLOAD_SCHEMA or request.get("request_id") != request_id:
            raise GateError("invalid StoreBot CA payload binding")
        return delivery, request
    return delivery, reconcile_terminal_record(delivery, request)


def _positive_int(value: Any, field: str) -> int:
    try:
        parsed = int(value)
    except (TypeError, ValueError) as exc:
        raise GateError(f"terminal binding {field} is invalid") from exc
    if parsed <= 0:
        raise GateError(f"terminal binding {field} is invalid")
    return parsed


def _terminal_time_bounds(delivery: Mapping[str, Any], terminal: Mapping[str, Any], current_ms: int) -> tuple[int, int, int]:
    created = _positive_int(delivery.get("created_at_ms"), "created_at_ms")
    expires = _positive_int(delivery.get("expires_at_ms"), "expires_at_ms")
    finished = _positive_int(terminal.get("finished_at_ms"), "finished_at_ms")
    if expires <= created:
        raise GateError("terminal binding expiry is invalid")
    if created > current_ms + TERMINAL_FUTURE_SKEW_MS or finished > current_ms + TERMINAL_FUTURE_SKEW_MS:
        raise GateError("terminal binding timestamp is in the future")
    if finished < created or finished > expires or current_ms > expires:
        raise GateError("terminal binding is stale")
    return created, expires, finished


def _strong_terminal_binding(delivery: Mapping[str, Any], terminal: Mapping[str, Any], current_ms: int) -> None:
    created, expires, _finished = _terminal_time_bounds(delivery, terminal, current_ms)
    request_id = str(delivery.get("request_id") or "")
    task_id = str(delivery.get("task_id") or "")
    target = str(delivery.get("target") or "")
    participant = participant_for_target(target)
    resource_id = str(delivery.get("resource_id") or "")
    if not SAFE_REQUEST_ID.fullmatch(request_id) or task_id != request_id:
        raise GateError("strong terminal request/task binding mismatch")
    if resource_id != participant["resource_id"] or delivery.get("target_node") != resource_id:
        raise GateError("strong terminal resource binding mismatch")
    nested_result = terminal.get("result") if isinstance(terminal.get("result"), Mapping) else {}
    binding = terminal.get("telegram_gate_result")
    if not isinstance(binding, Mapping):
        binding = nested_result.get("telegram_gate_result")
    if not isinstance(binding, Mapping) or binding.get("schema") != RESULT_BINDING_SCHEMA:
        raise GateError("strong terminal result binding is missing")
    expected = {
        "request_id": request_id,
        "task_id": task_id,
        "target": target,
        "resource_id": resource_id,
        "lease_epoch": _positive_int(delivery.get("lease_epoch"), "lease_epoch"),
        "fencing_token": str(delivery.get("fencing_token") or ""),
        "created_at_ms": created,
        "expires_at_ms": expires,
    }
    if not expected["fencing_token"]:
        raise GateError("terminal binding fencing_token is missing")
    for field, expected_value in expected.items():
        actual = binding.get(field)
        if field in {"lease_epoch", "created_at_ms", "expires_at_ms"}:
            try:
                actual = int(actual)
            except (TypeError, ValueError):
                pass
        if actual != expected_value:
            raise GateError(f"terminal result {field} binding mismatch")


def _legacy_terminal_binding(
    delivery: Mapping[str, Any], request: Mapping[str, Any], terminal: Mapping[str, Any], current_ms: int
) -> None:
    if delivery.get("result_binding_mode") != LEGACY_RESULT_BINDING_MODE:
        raise GateError("legacy terminal result is not explicitly allowlisted")
    request_id = str(delivery.get("request_id") or "")
    if not SAFE_REQUEST_ID.fullmatch(request_id) or delivery.get("task_id") != request_id:
        raise GateError("legacy terminal request/task binding mismatch")
    target = str(delivery.get("target") or "")
    participant = participant_for_target(target)
    resource_id = str(delivery.get("resource_id") or "")
    if resource_id != participant["resource_id"] or delivery.get("target_node") != resource_id:
        raise GateError("legacy terminal resource binding mismatch")
    queue = str(delivery.get("queue") or "")
    expected_request_path = (
        f"{pc_codex_cli_enqueue.REQUESTS_PATH}/{request_id}"
        if queue == "pc_codex_cli"
        else f"{codex_ops_enqueue.REQUESTS_PATH}/{request_id}"
        if queue == "codex_ops"
        else ""
    )
    expected_result_path = (
        f"{pc_codex_cli_enqueue.RESULTS_PATH}/{request_id}"
        if queue == "pc_codex_cli"
        else codex_ops_worker_result_path(request_id)
        if queue == "codex_ops"
        else ""
    )
    if delivery.get("request_path") != expected_request_path or delivery.get("result_path") != expected_result_path:
        raise GateError("legacy terminal scoped path binding mismatch")
    created, expires, _finished = _terminal_time_bounds(delivery, terminal, current_ms)
    request_binding = request.get("telegram_gate") if isinstance(request.get("telegram_gate"), Mapping) else {}
    expected_request_binding = {
        "task_id": request_id,
        "target": target,
        "resource_id": resource_id,
        "created_at_ms": created,
        "expires_at_ms": expires,
    }
    for field, expected_value in expected_request_binding.items():
        actual = request_binding.get(field)
        if field.endswith("_ms"):
            try:
                actual = int(actual)
            except (TypeError, ValueError):
                pass
        if actual != expected_value:
            raise GateError(f"legacy terminal request {field} binding mismatch")
    nested_result = terminal.get("result") if isinstance(terminal.get("result"), Mapping) else {}
    result_request_id = str(terminal.get("request_id") or nested_result.get("request_id") or "")
    if result_request_id and result_request_id != request_id:
        raise GateError("legacy terminal result request_id binding mismatch")
    result_resource = str(terminal.get("node") or terminal.get("worker") or nested_result.get("node") or nested_result.get("worker") or "")
    if result_resource != resource_id:
        raise GateError("legacy terminal result resource binding mismatch")


def _validate_terminal_binding(
    delivery: Mapping[str, Any], request: Mapping[str, Any], terminal: Mapping[str, Any], current_ms: int
) -> None:
    if delivery.get("result_binding_mode") == STRONG_RESULT_BINDING_MODE:
        _strong_terminal_binding(delivery, terminal, current_ms)
        return
    _legacy_terminal_binding(delivery, request, terminal, current_ms)


def reconcile_terminal_record(delivery: dict[str, Any], request: dict[str, Any]) -> dict[str, Any]:
    """Accept a terminal row only when its durable delivery binding is exact and fresh."""
    result_path = str(delivery.get("result_path") or "").strip()
    result_record = fb_get(result_path) if result_path else None
    current_ms = now_ms()
    result_error: GateError | None = None
    if isinstance(result_record, dict) and str(result_record.get("status") or "") in TERMINAL_STATUSES:
        try:
            _validate_terminal_binding(delivery, request, result_record, current_ms)
            return result_record
        except GateError as exc:
            result_error = exc
    if str(request.get("status") or "") in TERMINAL_STATUSES:
        _validate_terminal_binding(delivery, request, request, current_ms)
        return request
    if result_error is not None:
        raise result_error
    return request


def summary_from_request(request_id: str, delivery: dict[str, Any], request: dict[str, Any]) -> str:
    status = str(request.get("status") or "pending")
    result = request.get("result") if isinstance(request.get("result"), dict) else {}
    summary = result.get("summary") or request.get("error") or request.get("current_detail") or ""
    target_label = {"phone": "개인", "factory": "공장", "serverphone": "서버폰"}.get(
        str(delivery.get("target") or ""), "참가자"
    )
    title = f"[{target_label} {status}] {request_id}"
    identity = "\n".join(
        [
            f"participant_id: {delivery.get('participant_id') or ''}",
            f"resource_id: {delivery.get('resource_id') or delivery.get('target_node') or ''}",
            f"capability: {delivery.get('capability') or ''}",
        ]
    )
    message = f"{title}\n{identity}"
    if summary:
        message += f"\n{summary}"
    return redact_text(message)


def status(request_id: str) -> dict[str, Any]:
    delivery, request = request_record(request_id)
    return {
        "ok": True,
        "request_id": request_id,
        "status": request.get("status") or "pending",
        "target": delivery.get("target"),
        "target_node": delivery.get("target_node"),
        "delivery_status": delivery.get("status"),
        "message": summary_from_request(request_id, delivery, request),
    }


def validate_posdelay_live_delivery(delivery: Mapping[str, Any]) -> None:
    if not posdelay_live_send_enabled():
        raise GateError("PosDelay CA live transport is disabled")
    if delivery.get("delivery_kind") != POSDELAY_DELIVERY_KIND or delivery.get("domain") != "posdelay":
        raise GateError("invalid PosDelay CA delivery kind")
    if delivery.get("room_kind") != "ca_expert" or str(delivery.get("conversation_id") or "") != resolve_posdelay_ca_room():
        raise GateError("PosDelay CA delivery is outside the registered CA room")
    queue = str(delivery.get("queue") or "")
    expected_account = "serverphone" if queue == "posdelay_ca_status" else "factory" if queue == "pc_codex_cli" else ""
    expected_target = "serverphone" if queue == "posdelay_ca_status" else "factory" if queue == "pc_codex_cli" else ""
    if not expected_account or delivery.get("reply_account_id") != expected_account or delivery.get("target") != expected_target:
        raise GateError("PosDelay CA delivery role binding is invalid")
    if delivery.get("no_send") is not False:
        raise GateError("PosDelay CA live delivery is not explicitly promoted")


def posdelay_pending_item(request_id: str, delivery: Mapping[str, Any], current_ms: int) -> dict[str, Any] | None:
    validate_posdelay_live_delivery(delivery)
    expires_at_ms = int(delivery.get("expires_at_ms") or 0)
    if expires_at_ms <= 0 or current_ms > expires_at_ms:
        return None
    payload = fb_get(str(delivery.get("request_path") or "")) or {}
    if (
        not isinstance(payload, dict)
        or payload.get("schema") != POSDELAY_PAYLOAD_SCHEMA
        or payload.get("domain") != "posdelay"
        or payload.get("delivery_kind") != POSDELAY_DELIVERY_KIND
        or payload.get("request_id") != request_id
    ):
        return None
    message = str(payload.get("message") or "").strip()
    if not message:
        return None
    return {
        "request_id": request_id,
        "ingress_account_id": "serverphone",
        "reply_account_id": "serverphone",
        "conversation_id": delivery.get("conversation_id"),
        "thread_id": "",
        "source_message_id": "",
        "delivery_kind": POSDELAY_DELIVERY_KIND,
        "message": redact_text(message, 3000),
    }


def pending(limit: int) -> dict[str, Any]:
    raw = fb_get(DELIVERIES_PATH) or {}
    if not isinstance(raw, dict):
        raw = {}
    current_ms = now_ms()
    items: list[dict[str, Any]] = []
    ordered = sorted(
        ((str(key), value) for key, value in raw.items() if isinstance(value, dict)),
        key=lambda pair: int(pair[1].get("created_at_ms") or 0),
    )
    for request_id, delivery in ordered:
        if len(items) >= max(1, min(limit, 20)):
            break
        if delivery.get("no_send") is True:
            continue
        if delivery.get("status") == "delivered":
            continue
        if int(delivery.get("next_attempt_at_ms") or 0) > current_ms:
            continue
        if delivery.get("delivery_kind") == STOREBOT_OPS_DELIVERY_KIND:
            try:
                validate_storebot_delivery_binding(delivery, require_sendable=True)
            except GateError:
                continue
            if delivery.get("queue") in {"storebot_ca_status", "storebot_ca_factory_status"}:
                item = storebot_pending_item(request_id, delivery, current_ms)
                if item is not None:
                    items.append(item)
                continue
        if delivery.get("delivery_kind") == POSDELAY_DELIVERY_KIND:
            try:
                validate_posdelay_live_delivery(delivery)
            except GateError:
                continue
            if delivery.get("queue") == "posdelay_ca_status":
                item = posdelay_pending_item(request_id, delivery, current_ms)
                if item is not None:
                    items.append(item)
                continue
        if delivery.get("delivery_kind") == project_ca.DELIVERY_KIND:
            if not project_ca_live_send_enabled():
                continue
            try:
                item = project_ca.pending_item(
                    build_project_ca_repository(),
                    request_id,
                    now_ms=current_ms,
                    room_id=resolve_posdelay_ca_room(),
                )
            except project_ca.ProjectCaError:
                continue
            if item is not None:
                items.append(item)
            continue
        request = fb_get(str(delivery.get("request_path") or "")) or {}
        if not isinstance(request, dict):
            continue
        try:
            request = reconcile_terminal_record(delivery, request)
        except GateError:
            continue
        request_status = str(request.get("status") or "")
        if request_status not in TERMINAL_STATUSES:
            continue
        item = {
                "request_id": request_id,
                "ingress_account_id": delivery.get("ingress_account_id") or "personal",
                "reply_account_id": delivery.get("reply_account_id")
                or REPLY_ACCOUNTS.get(str(delivery.get("target") or ""), "personal"),
                "conversation_id": delivery.get("conversation_id"),
                "thread_id": delivery.get("thread_id") or "",
                "source_message_id": delivery.get("source_message_id") or "",
                "message": summary_from_request(request_id, delivery, request),
            }
        if delivery.get("delivery_kind") == STOREBOT_OPS_DELIVERY_KIND:
            item["delivery_kind"] = STOREBOT_OPS_DELIVERY_KIND
            item["ca_role"] = "factory_self_fix"
        items.append(item)
    return {"ok": True, "items": items}


def mark_delivered(request_id: str, delivery_id: str) -> dict[str, Any]:
    delivery, _request = request_record(request_id)
    if delivery.get("no_send") is True:
        raise GateError("no_send delivery cannot be marked delivered")
    if delivery.get("delivery_kind") == project_ca.DELIVERY_KIND:
        if not project_ca_live_send_enabled():
            raise GateError("project CA live transport is disabled")
        try:
            updated = project_ca.mark_delivery(
                build_project_ca_repository(),
                request_id,
                room_id=resolve_posdelay_ca_room(),
                now_ms=now_ms(),
                delivered=True,
                delivery_id=delivery_id,
            )
        except project_ca.ProjectCaError as exc:
            raise GateError(str(exc)) from exc
        return {"ok": True, "request_id": request_id, "status": updated["status"]}
    fb_patch(
        f"{DELIVERIES_PATH}/{request_id}",
        {
            "status": "delivered",
            "lifecycle_state": "telegram_delivered",
            "delivery_id": str(delivery_id or "")[:180],
            "delivered_at_ms": now_ms(),
            "last_error": "",
        },
    )
    return {"ok": True, "request_id": request_id, "status": "delivered"}


def mark_delivery_error(request_id: str, error: str) -> dict[str, Any]:
    delivery, _request = request_record(request_id)
    if delivery.get("no_send") is True:
        raise GateError("no_send delivery cannot be marked for retry")
    if delivery.get("delivery_kind") == project_ca.DELIVERY_KIND:
        if not project_ca_live_send_enabled():
            raise GateError("project CA live transport is disabled")
        try:
            updated = project_ca.mark_delivery(
                build_project_ca_repository(),
                request_id,
                room_id=resolve_posdelay_ca_room(),
                now_ms=now_ms(),
                delivered=False,
            )
        except project_ca.ProjectCaError as exc:
            raise GateError(str(exc)) from exc
        return {
            "ok": True,
            "request_id": request_id,
            "status": updated["status"],
            "attempt_count": updated["attempt_count"],
        }
    attempts = int(delivery.get("attempt_count") or 0) + 1
    delay_ms = min(5 * 60 * 1000, 5000 * (2 ** min(attempts - 1, 6)))
    fb_patch(
        f"{DELIVERIES_PATH}/{request_id}",
        {
            "status": "retry",
            "lifecycle_state": "delivery_retry",
            "attempt_count": attempts,
            "last_error": redact_text(error, 500),
            "last_attempt_at_ms": now_ms(),
            "next_attempt_at_ms": now_ms() + delay_ms,
        },
    )
    return {"ok": True, "request_id": request_id, "status": "retry", "attempt_count": attempts}


def parser() -> argparse.ArgumentParser:
    root = argparse.ArgumentParser(description="Telegram/OpenClaw Codex model-0 gate helper")
    sub = root.add_subparsers(dest="command", required=True)
    request_parser = sub.add_parser("request")
    request_parser.add_argument("--dry-run", action="store_true")
    status_parser = sub.add_parser("status")
    status_parser.add_argument("request_id")
    pending_parser = sub.add_parser("pending")
    pending_parser.add_argument("--limit", type=int, default=8)
    delivered_parser = sub.add_parser("mark-delivered")
    delivered_parser.add_argument("request_id")
    delivered_parser.add_argument("--delivery-id", default="")
    error_parser = sub.add_parser("mark-delivery-error")
    error_parser.add_argument("request_id")
    error_parser.add_argument("--error", default="")
    sub.add_parser("project-ca-once")
    sub.add_parser("health")
    return root


def main(argv: list[str]) -> int:
    args = parser().parse_args(argv)
    try:
        if args.command == "request":
            result = enqueue(read_json_stdin(), dry_run=args.dry_run)
        elif args.command == "status":
            result = status(args.request_id)
        elif args.command == "pending":
            result = pending(args.limit)
        elif args.command == "mark-delivered":
            result = mark_delivered(args.request_id, args.delivery_id)
        elif args.command == "mark-delivery-error":
            result = mark_delivery_error(args.request_id, args.error)
        elif args.command == "project-ca-once":
            result = project_generic_ca_once()
        else:
            memory_mb = available_memory_mb()
            health = runtime_health()
            result = {
                "ok": True,
                "mode": "model-0",
                "status": health["status"],
                "message": health["message"],
                "gateway": "personal_wonmux_openclaw",
                "nodes": [PERSONAL_NODE, FACTORY_NODE, SERVERPHONE_NODE],
                "participants": health["participants"],
                "resource": {
                    "personal_available_memory_mb": memory_mb,
                    "personal_min_available_memory_mb": personal_min_available_mb(),
                    "factory_fresh": health["participants"]["factory"]["fresh"],
                },
                "paths": {
                    "deliveries": DELIVERIES_PATH,
                    "personal_requests": codex_ops_enqueue.REQUESTS_PATH,
                    "factory_requests": pc_codex_cli_enqueue.REQUESTS_PATH,
                    "serverphone_requests": codex_ops_enqueue.REQUESTS_PATH,
                },
            }
    except (GateError, OSError, RuntimeError, ValueError) as exc:
        print(json.dumps({"ok": False, "error": redact_text(str(exc), 800)}, ensure_ascii=False))
        return 2
    print(json.dumps(result, ensure_ascii=False, separators=(",", ":")))
    return 0


if __name__ == "__main__":
    raise SystemExit(main(sys.argv[1:]))
