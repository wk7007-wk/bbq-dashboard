#!/system/bin/sh
if [ -z "${STOREBOT_CODEX_BASH_REEXEC:-}" ]; then
  for candidate in "${STOREBOT_TERMUX_DATA_DIR:-}" /data/data/com.sbotux /data/data/com.termux; do
    [ -n "$candidate" ] || continue
    if [ -x "$candidate/files/usr/bin/bash" ]; then
      export STOREBOT_TERMUX_DATA_DIR="$candidate"
      export STOREBOT_CODEX_BASH_REEXEC=1
      exec "$candidate/files/usr/bin/bash" "$0" "$@"
    fi
  done
fi
set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
resolve_termux_data_dir() {
  if [ -n "${STOREBOT_TERMUX_DATA_DIR:-}" ] && [ -x "$STOREBOT_TERMUX_DATA_DIR/files/usr/bin/bash" ]; then
    printf '%s\n' "$STOREBOT_TERMUX_DATA_DIR"
    return 0
  fi
  for candidate in /data/data/com.sbotux /data/data/com.termux; do
    if [ -x "$candidate/files/usr/bin/bash" ]; then
      printf '%s\n' "$candidate"
      return 0
    fi
  done
  printf '%s\n' "/data/data/com.sbotux"
}

APP_DATA_DIR="$(resolve_termux_data_dir)"
APP_PREFIX="$APP_DATA_DIR/files/usr"
export PREFIX="${PREFIX:-$APP_PREFIX}"
export PATH="$APP_PREFIX/bin:$APP_PREFIX/bin/applets:/system/bin:/system/xbin:$PATH"

SECURE_CA_ENV_LOADER="${SECURE_CA_ENV_LOADER:-$SCRIPT_DIR/secure_ca_env.sh}"
if [ ! -r "$SECURE_CA_ENV_LOADER" ]; then
  SECURE_CA_ENV_LOADER="$SCRIPT_DIR/../scripts/secure_ca_env.sh"
fi
STOREBOT_CA_ENV_FILE="${STOREBOT_CA_ENV_FILE:-$APP_DATA_DIR/files/home/.config/wonmux/ca-live.env}"
if [ ! -r "$SECURE_CA_ENV_LOADER" ]; then
  echo "secure CA env loader not found: $SECURE_CA_ENV_LOADER" >&2
  exit 66
fi
# shellcheck source=scripts/secure_ca_env.sh
source "$SECURE_CA_ENV_LOADER"
wonmux_load_secure_ca_env "$STOREBOT_CA_ENV_FILE" "${STOREBOT_CA_ENV_REQUIRED:-0}"

LOG_DIR="${STOREBOT_CODEX_HOST_LOG_DIR:-/sdcard/Download/storebot_codex_worker}"
LOG_FILE="$LOG_DIR/boot.log"
PROOT_ROOTFS_DIR="${STOREBOT_CODEX_PROOT_ROOTFS_DIR:-$PREFIX/var/lib/proot-distro/installed-rootfs}"
DISTRO="${STOREBOT_CODEX_DISTRO:-}"
BASH_PATH="${STOREBOT_CODEX_BASH_PATH:-$APP_PREFIX/bin/bash}"
WORKER_DIR="${STOREBOT_CODEX_ROOT_COPY:-/sdcard/Download/storebot_codex_worker}"
DIRECT_ROOT="${STOREBOT_CODEX_ROOT:-/root/my-first-project}"
HEALTH_URL="${STOREBOT_CODEX_HEALTH_URL:-http://127.0.0.1:8765/storebot/health}"
HEALTH_TIMEOUT_SEC="${STOREBOT_CODEX_HEALTH_TIMEOUT_SEC:-5}"
SOURCE="${1:-manual}"
DETACH="${STOREBOT_CODEX_DETACH:-0}"
MONITOR_ONLY_SOURCE="ai-ops-monitor-only"
FOREGROUND_PID_FILE="${STOREBOT_CODEX_FOREGROUND_PID_FILE:-$APP_PREFIX/tmp/storebot_codex_foreground.pid}"
CODEX_OPS_ENABLED="${CODEX_OPS_ENABLED:-1}"
CODEX_OPS_LAUNCH_SCRIPT="$WORKER_DIR/start_codex_ops_worker.sh"
CODEX_OPS_BOOT_LOG="$LOG_DIR/codex_ops_boot.log"
AI_OPS_MONITOR_ENABLED="${AI_OPS_MONITOR_ENABLED:-1}"
AI_OPS_MONITOR_LAUNCH_SCRIPT="$WORKER_DIR/start_ai_ops_monitor.sh"
AI_OPS_MONITOR_BOOT_LOG="$LOG_DIR/ai_ops_monitor_boot.log"
AUTOMATION_GOAL_DISPATCH_ENABLED="${AUTOMATION_GOAL_DISPATCH_ENABLED:-1}"
if [ "$APP_DATA_DIR" = "/data/data/com.sbotux" ]; then
  AI_OPS_DEFAULT_LOG_DIR="/sdcard/Download/ai_ops_monitor_sbotux"
  AI_OPS_DEFAULT_NODE="subphone_sbotux_ai_ops_monitor"
  AI_OPS_DEFAULT_BASE_PATH="/packhelper/ai_ops_monitor_sbotux_v2"
  AI_OPS_DEFAULT_INTERVAL_SEC="60"
else
  AI_OPS_DEFAULT_LOG_DIR="/sdcard/Download/ai_ops_monitor"
  AI_OPS_DEFAULT_NODE="subphone_ai_ops_monitor"
  AI_OPS_DEFAULT_BASE_PATH="/packhelper/ai_ops_monitor_v2"
  AI_OPS_DEFAULT_INTERVAL_SEC="300"
fi
export AI_OPS_MONITOR_LOG_DIR="${AI_OPS_MONITOR_LOG_DIR:-$AI_OPS_DEFAULT_LOG_DIR}"
export AI_OPS_MONITOR_LOCK_BASE_DIR="${AI_OPS_MONITOR_LOCK_BASE_DIR:-$AI_OPS_MONITOR_LOG_DIR}"
export AI_OPS_MONITOR_LOCK_DIR="${AI_OPS_MONITOR_LOCK_DIR:-$AI_OPS_MONITOR_LOCK_BASE_DIR/ai_ops_monitor.lock}"
export AI_OPS_MONITOR_NODE="${AI_OPS_MONITOR_NODE:-$AI_OPS_DEFAULT_NODE}"
export AI_OPS_BASE_PATH="${AI_OPS_BASE_PATH:-$AI_OPS_DEFAULT_BASE_PATH}"
export AI_OPS_MONITOR_INTERVAL_SEC="${AI_OPS_MONITOR_INTERVAL_SEC:-$AI_OPS_DEFAULT_INTERVAL_SEC}"

STOREBOT_CA_RUNTIME_ENV_KEYS=(
  STOREBOT_CA_PROJECTION_ENABLED
  STOREBOT_CA_LIVE_SEND_ENABLED
  STOREBOT_CA_FACTORY_SELF_FIX_ENABLED
  STOREBOT_CA_SCHEDULE_RECOVERY_ENABLED
  STOREBOT_CA_KILL_SWITCH
  STOREBOT_CA_IDENTITY_KEY_FILE
  STOREBOT_CA_MODULE_PATH
  STOREBOT_CA_MODULE_SHA256
  STOREBOT_TELEGRAM_BACKPLANE_DRY_RUN
  STOREBOT_TELEGRAM_BACKPLANE_KILL_SWITCH
  STOREBOT_TELEGRAM_BACKPLANE_IDENTITY_KEY_FILE
)
STOREBOT_CA_RUNTIME_ENV_ARGS=()
for ca_key in "${STOREBOT_CA_RUNTIME_ENV_KEYS[@]}"; do
  if [[ -v "$ca_key" ]]; then
    STOREBOT_CA_RUNTIME_ENV_ARGS+=("$ca_key=${!ca_key}")
  fi
done

AUTOMATION_GOAL_RUNTIME_ENV_KEYS=(
  AUTOMATION_GOAL_ID
  AUTOMATION_GOAL_OWNER_ID
  AUTOMATION_GOAL_WORKER_REVISION
  AUTOMATION_GOAL_DISPATCH_APPLY
  AUTOMATION_GOAL_KILL_SWITCH
  AUTOMATION_GOAL_WATCH_INTERVAL_SEC
  AUTOMATION_GOAL_BACKOFF_INITIAL_SEC
  AUTOMATION_GOAL_BACKOFF_MAX_SEC
  AUTOMATION_GOAL_MAX_LOG_BYTES
  AUTOMATION_PROJECT_ROOT
  AUTOMATION_GOAL_POLICY
  AUTOMATION_GOAL_RUNTIME_DIR
  AUTOMATION_GOAL_LOG_FILE
  AUTOMATION_GOAL_LOCK_FILE
)
AUTOMATION_GOAL_RUNTIME_ENV_ARGS=()
for automation_key in "${AUTOMATION_GOAL_RUNTIME_ENV_KEYS[@]}"; do
  if [[ -v "$automation_key" ]]; then
    AUTOMATION_GOAL_RUNTIME_ENV_ARGS+=("$automation_key=${!automation_key}")
  fi
done

mkdir -p "$LOG_DIR"

timestamp() {
  TZ=Asia/Seoul date +"%Y-%m-%d %H:%M:%S KST"
}

log() {
  echo "[$(timestamp)] $*" >> "$LOG_FILE"
}

if [ "$APP_DATA_DIR" = "/data/data/com.termux" ] && [ "${STOREBOT_ALLOW_LEGACY_TERMUX_WORKER:-0}" != "1" ]; then
  log "legacy com.termux StoreBot worker launch blocked source=$SOURCE app_data_dir=$APP_DATA_DIR"
  exit 0
fi

resolve_distro() {
  if [ -n "$DISTRO" ] && [ -d "$PROOT_ROOTFS_DIR/$DISTRO" ]; then
    return 0
  fi
  if [ -d "$PROOT_ROOTFS_DIR/debian" ]; then
    DISTRO="debian"
    return 0
  fi
  if [ -d "$PROOT_ROOTFS_DIR/ubuntu" ]; then
    DISTRO="ubuntu"
    return 0
  fi
  local first
  first="$(find "$PROOT_ROOTFS_DIR" -mindepth 1 -maxdepth 1 -type d -print 2>/dev/null | head -n 1)"
  if [ -n "$first" ]; then
    DISTRO="$(basename "$first")"
    return 0
  fi
  return 1
}

pid_alive() {
  local pid="$1"
  [ -n "$pid" ] && kill -0 "$pid" 2>/dev/null
}

pid_ppid() {
  local pid="$1"
  ps -o PPID= -p "$pid" 2>/dev/null | tr -d " " | head -n 1
}

foreground_owner_alive() {
  local pid
  pid="$(cat "$FOREGROUND_PID_FILE" 2>/dev/null || true)"
  if ! pid_alive "$pid"; then
    return 1
  fi
  [ "$(pid_ppid "$pid")" != "1" ]
}

is_worker_running() {
  if command -v pgrep >/dev/null 2>&1; then
    pgrep -f "python3 scripts/storebot_codex_worker.py" >/dev/null 2>&1 && return 0
  fi
  (ps -ef 2>/dev/null || ps -eo pid,args 2>/dev/null || ps -A -o pid,args 2>/dev/null || ps -A 2>/dev/null || ps 2>/dev/null) \
    | grep -F "storebot_codex_worker.py" \
    | grep -- "--watch" \
    | grep -v grep >/dev/null 2>&1
}

is_codex_ops_running() {
  if command -v pgrep >/dev/null 2>&1; then
    pgrep -f "python3 scripts/codex_ops_worker.py --watch" >/dev/null 2>&1 && return 0
  fi
  (ps -ef 2>/dev/null || ps -eo pid,args 2>/dev/null || ps -A -o pid,args 2>/dev/null || ps -A 2>/dev/null || ps 2>/dev/null) \
    | grep -F "codex_ops_worker.py" \
    | grep -- "--watch" \
    | grep -v grep >/dev/null 2>&1
}

is_ai_ops_monitor_running() {
  local pid cmdline
  [ -d "$AI_OPS_MONITOR_LOCK_DIR" ] && [ ! -L "$AI_OPS_MONITOR_LOCK_DIR" ] || return 1
  [ -f "$AI_OPS_MONITOR_LOCK_DIR/pid" ] || return 1
  pid="$(tr -d '[:space:]' <"$AI_OPS_MONITOR_LOCK_DIR/pid" 2>/dev/null || true)"
  case "$pid" in
    ''|*[!0-9]*) return 1 ;;
  esac
  [ "$pid" -gt 1 ] && kill -0 "$pid" 2>/dev/null && [ -r "/proc/$pid/cmdline" ] || return 1
  cmdline="$(tr '\0' ' ' <"/proc/$pid/cmdline" 2>/dev/null || true)"
  case "$cmdline" in
    *start_ai_ops_monitor.sh*|*ai_ops_common_monitor.py*) return 0 ;;
    *) return 1 ;;
  esac
}

start_codex_ops_worker() {
  if [ "$CODEX_OPS_ENABLED" != "1" ]; then
    log "codex_ops autostart disabled source=$SOURCE"
    return 0
  fi
  if [ ! -r "$CODEX_OPS_LAUNCH_SCRIPT" ]; then
    log "codex_ops launch helper missing path=$CODEX_OPS_LAUNCH_SCRIPT"
    return 0
  fi
  if is_codex_ops_running; then
    log "codex_ops already running source=$SOURCE"
    return 0
  fi
  log "starting codex_ops worker source=$SOURCE"
  nohup "$BASH_PATH" "$CODEX_OPS_LAUNCH_SCRIPT" >> "$CODEX_OPS_BOOT_LOG" 2>&1 &
  log "codex_ops start requested pid=$!"
}

start_ai_ops_monitor() {
  if [ "$AI_OPS_MONITOR_ENABLED" != "1" ]; then
    log "ai_ops monitor autostart disabled source=$SOURCE"
    return 0
  fi
  if [ ! -r "$AI_OPS_MONITOR_LAUNCH_SCRIPT" ]; then
    log "ai_ops monitor launch helper missing path=$AI_OPS_MONITOR_LAUNCH_SCRIPT"
    return 0
  fi
  if is_ai_ops_monitor_running; then
    log "ai_ops monitor already running source=$SOURCE"
    return 0
  fi
  log "starting ai_ops monitor source=$SOURCE"
  nohup "$BASH_PATH" "$AI_OPS_MONITOR_LAUNCH_SCRIPT" >> "$AI_OPS_MONITOR_BOOT_LOG" 2>&1 &
  log "ai_ops monitor start requested pid=$!"
}

start_automation_goal_dispatcher() {
  if [ "$AUTOMATION_GOAL_DISPATCH_ENABLED" != "1" ]; then
    log "automation goal dispatcher autostart disabled source=$SOURCE"
    return 0
  fi
  log "starting automation goal dispatcher source=$SOURCE"
  if [ "$DIRECT_PROOT" = "1" ]; then
    nohup env "${AUTOMATION_GOAL_RUNTIME_ENV_ARGS[@]}" bash -lc "
set -euo pipefail
cd '$DIRECT_ROOT'
exec bash subphone/start_automation_goal_dispatcher.sh
" >/dev/null 2>&1 &
  else
    nohup proot-distro login "$DISTRO" -- env "${AUTOMATION_GOAL_RUNTIME_ENV_ARGS[@]}" bash -lc '
set -euo pipefail
cd /root/my-first-project
exec bash subphone/start_automation_goal_dispatcher.sh
' >/dev/null 2>&1 &
  fi
  log "automation goal dispatcher start requested pid=$!"
}

health_ok() {
  if command -v python3 >/dev/null 2>&1; then
    python3 -c 'import sys, urllib.request; url=sys.argv[1]; timeout=float(sys.argv[2]); resp=urllib.request.urlopen(url, timeout=timeout); sys.exit(0 if resp.status == 200 else 1)' "$HEALTH_URL" "$HEALTH_TIMEOUT_SEC" >/dev/null 2>&1 && return 0
  fi
  if command -v curl >/dev/null 2>&1; then
    curl -fsS --max-time "$HEALTH_TIMEOUT_SEC" "$HEALTH_URL" >/dev/null 2>&1 && return 0
  fi
  return 1
}

if ! command -v proot-distro >/dev/null 2>&1; then
  log "proot-distro not found"
  exit 1
fi
if ! resolve_distro; then
  log "no installed proot distro found rootfs=$PROOT_ROOTFS_DIR"
  exit 1
fi
DIRECT_PROOT=0
if ! proot-distro login "$DISTRO" -- true >/dev/null 2>&1; then
  if [ -d "$DIRECT_ROOT" ]; then
    DIRECT_PROOT=1
    log "proot login unavailable; using direct root=$DIRECT_ROOT source=$SOURCE"
  else
    log "proot login failed and direct root missing distro=$DISTRO root=$DIRECT_ROOT"
    exit 1
  fi
fi

if [ "$SOURCE" = "$MONITOR_ONLY_SOURCE" ]; then
  if [ "$DETACH" != "1" ] || [ "$CODEX_OPS_ENABLED" != "0" ]; then
    log "monitor-only launch rejected detach=$DETACH codex_ops=$CODEX_OPS_ENABLED"
    exit 64
  fi
  termux-wake-lock >/dev/null 2>&1 || true
  start_ai_ops_monitor
  log "monitor-only launch completed node=$AI_OPS_MONITOR_NODE base=$AI_OPS_BASE_PATH"
  exit 0
fi

# The dispatcher is isolated from the StoreBot/Kakao worker and owns its own
# flock. Launching it before the worker-already-running fast path also repairs a
# missing dispatcher without restarting the chat worker.
start_automation_goal_dispatcher

stop_existing_worker() {
  log "stopping existing detached worker source=$SOURCE"
  if [ "$DIRECT_PROOT" = "1" ]; then
    bash -lc '
set +e
storebot_pids() {
  ps -eo pid=,args= 2>/dev/null | while read -r pid args; do
    [ -n "$pid" ] || continue
    case "$args" in
      *storebot_codex_worker.py*|*start_storebot_codex_worker.sh*|*run_storebot_codex_worker.sh*)
        printf "%s\n" "$pid"
        continue
        ;;
    esac
    case "$args" in
      *"codex app-server"*|*"codex exec"*)
        cwd="$(readlink "/proc/$pid/cwd" 2>/dev/null || true)"
        case "$cwd" in
          /root/my-first-project|/sdcard/Download/storebot_codex_worker)
            printf "%s\n" "$pid"
            ;;
        esac
        ;;
    esac
  done
}
for pid in $(storebot_pids); do kill -TERM "$pid" 2>/dev/null || true; done
sleep 2
for pid in $(storebot_pids); do kill -KILL "$pid" 2>/dev/null || true; done
rm -rf "${STOREBOT_CODEX_LOCK_DIR:-/root/tmp/storebot_codex_worker.lock}" /tmp/storebot_codex_worker.lock
' >> "$LOG_FILE" 2>&1 || true
  else
    proot-distro login "$DISTRO" -- bash -lc '
set +e
storebot_pids() {
  ps -eo pid=,args= 2>/dev/null | while read -r pid args; do
    [ -n "$pid" ] || continue
    case "$args" in
      *storebot_codex_worker.py*|*start_storebot_codex_worker.sh*|*run_storebot_codex_worker.sh*)
        printf "%s\n" "$pid"
        continue
        ;;
    esac
    case "$args" in
      *"codex app-server"*|*"codex exec"*)
        cwd="$(readlink "/proc/$pid/cwd" 2>/dev/null || true)"
        case "$cwd" in
          /root/my-first-project|/sdcard/Download/storebot_codex_worker)
            printf "%s\n" "$pid"
            ;;
        esac
        ;;
    esac
  done
}
for pid in $(storebot_pids); do kill -TERM "$pid" 2>/dev/null || true; done
sleep 2
for pid in $(storebot_pids); do kill -KILL "$pid" 2>/dev/null || true; done
rm -rf /tmp/storebot_codex_worker.lock
' >> "$LOG_FILE" 2>&1 || true
  fi
  rm -f "$FOREGROUND_PID_FILE" 2>/dev/null || true
  sleep 1
}

if is_worker_running || health_ok; then
  if [ "$DETACH" = "1" ]; then
    log "worker already running; detach start skipped"
    exit 0
  fi
  if foreground_owner_alive; then
    log "foreground worker already owned; start skipped source=$SOURCE"
    exit 0
  fi
  stop_existing_worker
fi

termux-wake-lock >/dev/null 2>&1 || true
start_codex_ops_worker
start_ai_ops_monitor

if [ "$DETACH" = "1" ]; then
  if [ "$DIRECT_PROOT" = "1" ]; then
    log "starting StoreBot Codex worker detached direct root=$DIRECT_ROOT source=$SOURCE"
    nohup env "${STOREBOT_CA_RUNTIME_ENV_ARGS[@]}" bash -lc "
set -euo pipefail
export PATH=\"\$HOME/.local/bin:\$HOME/.codex/bin:/usr/local/bin:/usr/bin:/bin:\$PATH\"
export STOREBOT_CODEX_LOCK_DIR=\"\${STOREBOT_CODEX_LOCK_DIR:-/root/tmp/storebot_codex_worker.lock}\"
mkdir -p /root/tmp
cd '$DIRECT_ROOT'
bash subphone/start_storebot_codex_worker.sh
" >> "$LOG_FILE" 2>&1 &
  else
    log "starting StoreBot Codex worker detached via proot=$DISTRO source=$SOURCE"
    nohup proot-distro login "$DISTRO" -- env "${STOREBOT_CA_RUNTIME_ENV_ARGS[@]}" bash -lc '
set -euo pipefail
export PATH="$HOME/.local/bin:$HOME/.codex/bin:/usr/local/bin:/usr/bin:/bin:$PATH"
cd /root/my-first-project
bash subphone/start_storebot_codex_worker.sh
' >> "$LOG_FILE" 2>&1 &
  fi

  log "detached start requested pid=$!"
  exit 0
fi

echo "$$" > "$FOREGROUND_PID_FILE"
if [ "$DIRECT_PROOT" = "1" ]; then
  log "starting StoreBot Codex worker foreground direct root=$DIRECT_ROOT source=$SOURCE pid=$$"
else
  log "starting StoreBot Codex worker foreground via proot=$DISTRO source=$SOURCE pid=$$"
fi
set +e
if [ "$DIRECT_PROOT" = "1" ]; then
  env "${STOREBOT_CA_RUNTIME_ENV_ARGS[@]}" bash -lc "
set -euo pipefail
export PATH=\"\$HOME/.local/bin:\$HOME/.codex/bin:/usr/local/bin:/usr/bin:/bin:\$PATH\"
export STOREBOT_CODEX_LOCK_DIR=\"\${STOREBOT_CODEX_LOCK_DIR:-/root/tmp/storebot_codex_worker.lock}\"
mkdir -p /root/tmp
cd '$DIRECT_ROOT'
bash subphone/start_storebot_codex_worker.sh
" >> "$LOG_FILE" 2>&1
else
  proot-distro login "$DISTRO" -- env "${STOREBOT_CA_RUNTIME_ENV_ARGS[@]}" bash -lc '
set -euo pipefail
export PATH="$HOME/.local/bin:$HOME/.codex/bin:/usr/local/bin:/usr/bin:/bin:$PATH"
cd /root/my-first-project
bash subphone/start_storebot_codex_worker.sh
' >> "$LOG_FILE" 2>&1
fi
code=$?
set -e

current_pid="$(cat "$FOREGROUND_PID_FILE" 2>/dev/null || true)"
if [ "$current_pid" = "$$" ]; then
  rm -f "$FOREGROUND_PID_FILE" 2>/dev/null || true
fi
log "foreground worker exited code=$code source=$SOURCE"
exit "$code"
