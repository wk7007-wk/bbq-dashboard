#!/usr/bin/env python3
"""Default-off, no-I/O worker adapter for StoreBot Telegram proposals."""

from __future__ import annotations

import hashlib
import hmac
import json
from collections.abc import Callable, Mapping, Sequence
from copy import deepcopy
from typing import Any

try:
    from storebot_telegram_backplane import (
        accept_delegate_result,
        accept_reply_proposal,
        build_delegate_result,
        build_reply_proposal,
        decide_recovery_action,
    )
    from storebot_telegram_chat_contract import build_function_proposal, build_lineage
    from storebot_telegram_ops_log import ReserveResult, StoreBotOpsCoordinator
    from storebot_telegram_projection import build_storebot_telegram_projection
except ModuleNotFoundError:  # pragma: no cover - package import in repo tests.
    from scripts.storebot_telegram_backplane import (
        accept_delegate_result,
        accept_reply_proposal,
        build_delegate_result,
        build_reply_proposal,
        decide_recovery_action,
    )
    from scripts.storebot_telegram_chat_contract import build_function_proposal, build_lineage
    from scripts.storebot_telegram_ops_log import ReserveResult, StoreBotOpsCoordinator
    from scripts.storebot_telegram_projection import build_storebot_telegram_projection


SCHEMA = "storebot.telegram_worker_adapter.v1"
ENVELOPE_KEYS = frozenset(
    {
        "schema", "mode", "source_projection", "recovery_ref", "recovery_decision",
        "ops_repository_mode", "ops_receipts", "no_send", "sent",
    }
)


class WorkerAdapterError(ValueError):
    pass


def _key(value: bytes | str) -> bytes:
    result = value.encode("utf-8") if isinstance(value, str) else bytes(value)
    if len(result) < 32:
        raise WorkerAdapterError("identity_key must contain at least 32 bytes")
    return result


def _opaque(prefix: str, key: bytes, value: Any) -> str:
    encoded = json.dumps(value, ensure_ascii=False, sort_keys=True, separators=(",", ":")).encode("utf-8")
    return f"{prefix}_{hmac.new(key, encoded, hashlib.sha256).hexdigest()[:32]}"


RECOVERY_STATE_SCHEMA = "storebot.telegram_recovery_state.v1"
RECOVERY_STATE_KEYS = frozenset(
    {
        "schema", "state_version", "projection_id", "source_projection", "occurrence_id",
        "gateway_package", "app_resource", "kakao_transport_owner", "primary",
        "available_resources", "wake", "delegate", "created_at_ms", "updated_at_ms",
    }
)
DELEGATE_STATE_KEYS = frozenset(
    {
        "requested", "status", "analysis_epoch", "recovery_attempt", "cas_intent_key",
        "resource", "lease_owner", "lease_epoch", "fencing_token", "claim_token",
        "claim_expires_at_ms", "claimed_at_ms", "completed_at_ms", "result_ref",
        "result_hash", "evidence_hash",
    }
)


def _base_recovery_state(
    projection: Mapping[str, Any], identity_key: bytes, now_ms: int
) -> dict[str, Any]:
    projection_id = str(projection["projection_id"])
    return {
        "schema": RECOVERY_STATE_SCHEMA,
        "state_version": 1,
        "projection_id": projection_id,
        "source_projection": dict(projection),
        "occurrence_id": _opaque("stocc", identity_key, {"projection_id": projection_id}),
        "gateway_package": "com.wonmux",
        "app_resource": "com.sbotux",
        "kakao_transport_owner": "com.sbotux",
        "primary": {"resource": "subphone_termux_ops", "available": False, "last_seen_ms": 0},
        "available_resources": ["pc_codex_resource_01"],
        "wake": {},
        "delegate": {},
        "created_at_ms": int(now_ms),
        "updated_at_ms": int(now_ms),
    }


class RepositoryRecoveryRegistry:
    """CAS-backed recovery state; no process-local state is authoritative."""

    def __init__(self, coordinator: StoreBotOpsCoordinator, identity_key: bytes) -> None:
        self.coordinator = coordinator
        self.identity_key = identity_key

    def _base_state(self, projection: Mapping[str, Any], now_ms: int) -> dict[str, Any]:
        return _base_recovery_state(projection, self.identity_key, now_ms)

    def _validate_state(
        self, state: Mapping[str, Any], *, projection: Mapping[str, Any] | None = None
    ) -> dict[str, Any]:
        value = dict(state)
        if frozenset(value) != RECOVERY_STATE_KEYS or value.get("schema") != RECOVERY_STATE_SCHEMA:
            raise WorkerAdapterError("durable recovery state schema mismatch")
        projection_id = str(value.get("projection_id") or "")
        source_projection = value.get("source_projection")
        if not isinstance(source_projection, Mapping) or source_projection.get("projection_id") != projection_id:
            raise WorkerAdapterError("durable recovery projection binding mismatch")
        if projection is not None and dict(value.get("source_projection") or {}) != dict(projection):
            raise WorkerAdapterError("durable recovery source projection conflict")
        if value.get("occurrence_id") != _opaque("stocc", self.identity_key, {"projection_id": projection_id}):
            raise WorkerAdapterError("durable recovery occurrence binding mismatch")
        if value.get("gateway_package") != "com.wonmux":
            raise WorkerAdapterError("durable recovery gateway mismatch")
        if value.get("app_resource") != "com.sbotux" or value.get("kakao_transport_owner") != "com.sbotux":
            raise WorkerAdapterError("durable recovery owner mismatch")
        if int(value.get("state_version") or 0) <= 0:
            raise WorkerAdapterError("durable recovery state version is invalid")
        if int(value.get("created_at_ms") or 0) <= 0 or int(value.get("updated_at_ms") or 0) < int(value["created_at_ms"]):
            raise WorkerAdapterError("durable recovery timestamps are invalid")
        delegate = value.get("delegate")
        if delegate:
            if not isinstance(delegate, Mapping) or frozenset(delegate) != DELEGATE_STATE_KEYS:
                raise WorkerAdapterError("durable delegate state schema mismatch")
            target = str(delegate.get("resource") or "")
            epoch = int(delegate.get("lease_epoch") or 0)
            if (
                delegate.get("requested") is not True
                or target != "pc_codex_resource_01"
                or delegate.get("lease_owner") != target
                or epoch <= 0
                or int(delegate.get("analysis_epoch") or 0) != epoch
                or int(delegate.get("recovery_attempt") or 0) != 2
                or not str(delegate.get("cas_intent_key") or "").startswith("stcas_")
            ):
                raise WorkerAdapterError("durable delegate lease binding mismatch")
            expected_fence = _opaque(
                "stfence", self.identity_key,
                {"projection_id": projection_id, "epoch": epoch, "target": target},
            )
            if delegate.get("fencing_token") != expected_fence:
                raise WorkerAdapterError("durable delegate fencing mismatch")
            if delegate.get("status") not in {"proposed", "claiming", "started", "completed"}:
                raise WorkerAdapterError("durable delegate status is invalid")
            expected_claim = _opaque(
                "stclaim", self.identity_key,
                {"projection_id": projection_id, "cas_intent_key": delegate["cas_intent_key"], "lease_epoch": epoch},
            )
            if delegate.get("status") in {"claiming", "started", "completed"}:
                if delegate.get("claim_token") != expected_claim:
                    raise WorkerAdapterError("durable delegate claim binding mismatch")
            elif any(delegate.get(field) for field in ("claim_token", "claim_expires_at_ms", "claimed_at_ms")):
                raise WorkerAdapterError("unclaimed delegate contains claim state")
            if delegate.get("status") == "completed":
                for field, prefix in (("result_ref", "stresultref_"), ("result_hash", "stresult_"), ("evidence_hash", "stevidence_")):
                    if not str(delegate.get(field) or "").startswith(prefix):
                        raise WorkerAdapterError("durable delegate result binding mismatch")
            elif any(delegate.get(field) for field in ("completed_at_ms", "result_ref", "result_hash", "evidence_hash")):
                raise WorkerAdapterError("incomplete delegate contains result state")
        return value

    def _cas(self, projection_id: str, revision: Any, state: Mapping[str, Any]) -> ReserveResult:
        return self.coordinator.cas_recovery_state(projection_id, revision, state)

    def observe(
        self, projection: Mapping[str, Any], *, now_ms: int
    ) -> tuple[str, dict[str, Any], dict[str, Any], bool]:
        projection_id = str(projection["projection_id"])
        for _ in range(6):
            snapshot = self.coordinator.read_recovery_state(projection_id)
            if not snapshot.state:
                created = self._cas(projection_id, snapshot.revision, self._base_state(projection, now_ms))
                if created.contention:
                    continue
                continue
            state = self._validate_state(snapshot.state, projection=projection)
            delegate = state.get("delegate") if isinstance(state.get("delegate"), Mapping) else {}
            if delegate:
                decision = {
                    "schema": "storebot.telegram_backplane.v1",
                    "action": "wait",
                    "target_resource": delegate["resource"],
                    "proposal": False,
                    "no_send": True,
                    "sent": False,
                    "reason": f"delegate_{delegate['status']}",
                    "analysis_epoch": int(delegate["analysis_epoch"]),
                }
                return self._recovery_ref(state, decision), decision, deepcopy(state), False
            decision = decide_recovery_action(state, int(now_ms))
            if decision["action"] not in {"wake_primary", "delegate_analysis"}:
                return self._recovery_ref(state, decision), deepcopy(decision), deepcopy(state), False
            replacement = deepcopy(state)
            replacement["state_version"] = int(state["state_version"]) + 1
            replacement["updated_at_ms"] = int(now_ms)
            if decision["action"] == "wake_primary":
                replacement["wake"] = {"attempted_at_ms": int(now_ms), "proposal_only": True}
            else:
                epoch = int(decision["analysis_epoch"])
                target = str(decision["target_resource"])
                replacement["delegate"] = {
                    "requested": True,
                    "status": "proposed",
                    "analysis_epoch": epoch,
                    "recovery_attempt": 2,
                    "cas_intent_key": str(decision["cas_intent_key"]),
                    "resource": target,
                    "lease_owner": target,
                    "lease_epoch": epoch,
                    "fencing_token": _opaque(
                        "stfence", self.identity_key,
                        {"projection_id": projection_id, "epoch": epoch, "target": target},
                    ),
                    "claim_token": "",
                    "claim_expires_at_ms": 0,
                    "claimed_at_ms": 0,
                    "completed_at_ms": 0,
                    "result_ref": "",
                    "result_hash": "",
                    "evidence_hash": "",
                }
            reserved = self._cas(projection_id, snapshot.revision, replacement)
            if reserved.contention:
                continue
            state = self._validate_state(reserved.authoritative, projection=projection)
            return self._recovery_ref(state, decision), deepcopy(decision), deepcopy(state), True
        raise WorkerAdapterError("durable recovery state CAS contention")

    def _recovery_ref(self, state: Mapping[str, Any], decision: Mapping[str, Any]) -> str:
        return _opaque(
            "strecovery",
            self.identity_key,
            {
                "projection_id": state["projection_id"],
                "action": decision["action"],
                "occurrence_id": state["occurrence_id"],
            },
        )

    def claim_delegate(
        self,
        projection_id: str,
        *,
        now_ms: int,
        sink: Callable[[Mapping[str, Any]], Mapping[str, Any] | None] | None,
    ) -> tuple[bool, dict[str, Any]]:
        if sink is None:
            return False, self.state(projection_id)
        claiming_state: dict[str, Any] = {}
        for _ in range(6):
            snapshot = self.coordinator.read_recovery_state(projection_id)
            state = self._validate_state(snapshot.state)
            delegate = dict(state.get("delegate") or {})
            status = str(delegate.get("status") or "")
            if status in {"started", "completed"}:
                return False, state
            if status == "claiming" and int(delegate.get("claim_expires_at_ms") or 0) > int(now_ms):
                return False, state
            if status not in {"proposed", "claiming"}:
                raise WorkerAdapterError("delegate is not claimable")
            claim_token = _opaque(
                "stclaim", self.identity_key,
                {
                    "projection_id": projection_id,
                    "cas_intent_key": delegate["cas_intent_key"],
                    "lease_epoch": int(delegate["lease_epoch"]),
                },
            )
            delegate.update(
                {"status": "claiming", "claim_token": claim_token, "claim_expires_at_ms": int(now_ms) + 30_000}
            )
            replacement = {**state, "delegate": delegate, "state_version": int(state["state_version"]) + 1, "updated_at_ms": int(now_ms)}
            reserved = self._cas(projection_id, snapshot.revision, replacement)
            if reserved.contention:
                continue
            claiming_state = self._validate_state(reserved.authoritative)
            break
        if not claiming_state:
            raise WorkerAdapterError("delegate claim CAS contention")
        delegate = dict(claiming_state["delegate"])
        claim_request = {
            "schema": "storebot.telegram_delegate_claim.v1",
            "projection_id": projection_id,
            "target_resource": delegate["resource"],
            "cas_intent_key": delegate["cas_intent_key"],
            "recovery_attempt": int(delegate["recovery_attempt"]),
            "lease_epoch": int(delegate["lease_epoch"]),
            "fencing_token": delegate["fencing_token"],
            "claim_token": delegate["claim_token"],
            "no_send": True,
            "sent": False,
        }
        claim = sink(deepcopy(claim_request))
        valid = isinstance(claim, Mapping) and all(
            (
                claim.get("claimed") is True,
                claim.get("target_resource") == delegate["resource"],
                claim.get("cas_intent_key") == delegate["cas_intent_key"],
                int(claim.get("recovery_attempt") or 0) == int(delegate["recovery_attempt"]),
                int(claim.get("lease_epoch") or 0) == int(delegate["lease_epoch"]),
                claim.get("fencing_token") == delegate["fencing_token"],
                claim.get("claim_token") == delegate["claim_token"],
            )
        )
        for _ in range(6):
            snapshot = self.coordinator.read_recovery_state(projection_id)
            current = self._validate_state(snapshot.state)
            current_delegate = dict(current.get("delegate") or {})
            if current_delegate.get("status") != "claiming" or current_delegate.get("claim_token") != delegate["claim_token"]:
                return False, current
            current_delegate.update(
                {
                    "status": "started" if valid else "proposed",
                    "claim_token": delegate["claim_token"] if valid else "",
                    "claim_expires_at_ms": int(delegate["claim_expires_at_ms"]) if valid else 0,
                    "claimed_at_ms": int(now_ms) if valid else 0,
                }
            )
            replacement = {
                **current,
                "delegate": current_delegate,
                "state_version": int(current["state_version"]) + 1,
                "updated_at_ms": int(now_ms),
            }
            updated = self._cas(projection_id, snapshot.revision, replacement)
            if updated.contention:
                continue
            return bool(valid), self._validate_state(updated.authoritative)
        raise WorkerAdapterError("delegate claim completion CAS contention")

    def state(self, projection_id: str) -> dict[str, Any]:
        snapshot = self.coordinator.read_recovery_state(str(projection_id))
        return self._validate_state(snapshot.state) if snapshot.state else {}

    def accept_delegate(
        self,
        projection_id: str,
        result: Mapping[str, Any],
        *,
        private_result: Mapping[str, Any],
        private_evidence: Sequence[Any],
        now_ms: int,
    ) -> dict[str, Any]:
        for _ in range(6):
            snapshot = self.coordinator.read_recovery_state(str(projection_id))
            state = self._validate_state(snapshot.state)
            delegate = dict(state.get("delegate") or {})
            if delegate.get("status") != "started":
                return {"accepted": False, "reason": "duplicate_or_unknown_delegate", "no_send": True, "sent": False}
            if (
                int(now_ms) > int(delegate.get("claim_expires_at_ms") or 0)
                or int(result.get("expires_at_ms") or 0) > int(delegate.get("claim_expires_at_ms") or 0)
            ):
                return {"accepted": False, "reason": "expired_delegate_claim", "no_send": True, "sent": False}
            accepted = accept_delegate_result(
                state,
                result,
                int(now_ms),
                private_result=private_result,
                private_evidence=private_evidence,
                identity_key=self.identity_key,
            )
            if accepted.get("accepted") is not True:
                return deepcopy(accepted)
            delegate.update(
                {
                    "status": "completed",
                    "completed_at_ms": int(now_ms),
                    "result_ref": str(result["result_ref"]),
                    "result_hash": str(result["result_hash"]),
                    "evidence_hash": str(result["evidence_hash"]),
                }
            )
            replacement = {
                **state,
                "delegate": delegate,
                "state_version": int(state["state_version"]) + 1,
                "updated_at_ms": int(now_ms),
            }
            updated = self._cas(str(projection_id), snapshot.revision, replacement)
            if updated.contention:
                continue
            self._validate_state(updated.authoritative)
            return deepcopy(accepted)
        raise WorkerAdapterError("delegate result CAS contention")


class StoreBotTelegramWorkerAdapter:
    def __init__(
        self,
        *,
        enabled: bool = False,
        identity_key: bytes | str = b"",
        ops_coordinator: StoreBotOpsCoordinator | None = None,
        delegate_sink: Callable[[Mapping[str, Any]], Mapping[str, Any] | None] | None = None,
    ) -> None:
        self.enabled = bool(enabled)
        self._identity_key = _key(identity_key) if self.enabled else b""
        self.ops_coordinator = ops_coordinator
        self.registry = (
            RepositoryRecoveryRegistry(ops_coordinator, self._identity_key)
            if self.enabled and ops_coordinator is not None
            else None
        )
        self.delegate_sink = delegate_sink

    def _evidence_pointer(self, private_task_ref: str) -> str:
        return _opaque("stev", self._identity_key, {"private_task_ref": private_task_ref})

    def record_ops_transition(
        self,
        *,
        private_task_ref: str,
        transition: str,
        status: str,
        resource: str,
        occurred_at_ms: int,
        now_ms: int,
        duration_ms: int = 0,
        severity: str = "info",
        attempt: int = 0,
    ) -> dict[str, Any]:
        """Record one typed lifecycle event without transport or persistence I/O."""

        if not self.enabled or self.ops_coordinator is None:
            raise WorkerAdapterError("durable ops repository is not configured")
        return self.ops_coordinator.append(
            private_task_ref=private_task_ref,
            transition=transition,
            status=status,
            resource=resource,
            evidence_pointer=self._evidence_pointer(private_task_ref),
            occurred_at_ms=int(occurred_at_ms),
            now_ms=int(now_ms),
            duration_ms=int(duration_ms),
            severity=severity,
            attempt=int(attempt),
        )

    def pending_ca_receipts(
        self,
        *,
        room_registry_ref: str,
        now_ms: int,
        packet_limit: int = 4,
        aggregate_size: int = 8,
    ) -> list[dict[str, Any]]:
        """Return typed references for the existing CA gate; never send them."""

        if not self.enabled or self.ops_coordinator is None:
            return []
        return self.ops_coordinator.pending_ca_outbox(
            room_registry_ref=room_registry_ref,
            now_ms=int(now_ms),
            packet_limit=int(packet_limit),
            aggregate_size=int(aggregate_size),
        )

    def reconnect_ca_receipts(self, *, room_registry_ref: str, now_ms: int) -> list[dict[str, Any]]:
        if not self.enabled or self.ops_coordinator is None:
            return []
        return self.ops_coordinator.reconnect_replay(room_registry_ref=room_registry_ref, now_ms=int(now_ms))

    def mark_ca_receipts(self, request_id: str, *, delivered: bool, now_ms: int) -> dict[str, Any]:
        if not self.enabled or self.ops_coordinator is None:
            raise WorkerAdapterError("durable ops repository is not configured")
        return self.ops_coordinator.mark_delivery(request_id, delivered=bool(delivered), now_ms=int(now_ms))

    def set_recovery_kill_switch(self, enabled: bool) -> None:
        if not self.enabled or self.ops_coordinator is None:
            raise WorkerAdapterError("durable ops repository is not configured")
        self.ops_coordinator.kill_switch = bool(enabled)

    def build_ops_failure_signal(
        self,
        *,
        private_task_ref: str,
        failure_code: str,
        risk: str,
        origin: str,
        private_root_cause_ref: str,
        private_cause_chain: Sequence[str],
        hop: int,
        recovery_eligible: bool,
        occurred_at_ms: int,
    ) -> dict[str, Any]:
        if not self.enabled or self.ops_coordinator is None:
            raise WorkerAdapterError("durable ops repository is not configured")
        return self.ops_coordinator.build_failure_signal(
            private_task_ref=private_task_ref,
            failure_code=failure_code,
            risk=risk,
            origin=origin,
            private_root_cause_ref=private_root_cause_ref,
            private_cause_chain=private_cause_chain,
            hop=int(hop),
            recovery_eligible=bool(recovery_eligible),
            occurred_at_ms=int(occurred_at_ms),
        )

    def judge_ops_failure(
        self,
        *,
        failure: Mapping[str, Any],
        now_ms: int,
    ) -> dict[str, Any]:
        if not self.enabled or self.ops_coordinator is None:
            raise WorkerAdapterError("durable ops repository is not configured")
        return self.ops_coordinator.judge_failure(
            failure=failure,
            now_ms=int(now_ms),
        )

    def _failure_receipts(
        self,
        *,
        projection_id: str,
        failure_kind: str,
        occurred_at_ms: int,
        now_ms: int,
    ) -> list[dict[str, Any]]:
        """Create the initial failure lifecycle once in the injected repository."""

        if self.ops_coordinator is None:
            return []
        if self.ops_coordinator.task_state(projection_id):
            return []
        return [
                self.record_ops_transition(
                    private_task_ref=projection_id,
                    transition="request",
                    status="pending",
                    resource="com.sbotux",
                    occurred_at_ms=occurred_at_ms,
                    now_ms=now_ms,
                ),
                self.record_ops_transition(
                    private_task_ref=projection_id,
                    transition="claim",
                    status="running",
                    resource="subphone_termux_ops",
                    occurred_at_ms=occurred_at_ms,
                    now_ms=now_ms,
                ),
                self.record_ops_transition(
                    private_task_ref=projection_id,
                    transition="worker_started",
                    status="running",
                    resource="subphone_termux_ops",
                    occurred_at_ms=occurred_at_ms,
                    now_ms=now_ms,
                ),
                self.record_ops_transition(
                    private_task_ref=projection_id,
                    transition="timeout" if failure_kind == "local_direct_timeout" else "error",
                    status="failed",
                    resource="com.sbotux",
                    occurred_at_ms=occurred_at_ms,
                    now_ms=now_ms,
                    severity="error",
                ),
                self.record_ops_transition(
                    private_task_ref=projection_id,
                    transition="recovery_proposed",
                    status="proposed",
                    resource="subphone_termux_ops",
                    occurred_at_ms=occurred_at_ms,
                    now_ms=now_ms,
                    severity="warning",
                    attempt=1,
                ),
        ]

    def observe_local_direct_failure(
        self,
        *,
        request_id: str,
        item: Mapping[str, Any],
        failure_kind: str,
        now_ms: int,
    ) -> dict[str, Any] | None:
        if not self.enabled:
            return None
        if failure_kind not in {"local_direct_timeout", "local_direct_deferred_error"}:
            raise WorkerAdapterError("failure_kind is not allowlisted")
        package_values = [
            str(item.get(field) or "").strip()
            for field in ("android_package_name", "application_id")
            if str(item.get(field) or "").strip()
        ]
        package_name = package_values[0] if package_values else ""
        canonical_event_id = str(item.get("_room_event_id") or "").strip()
        room_turn = str(item.get("_room_turn_ref") or "").strip()
        trusted_source = str(item.get("_backplane_trusted_source") or "").strip()
        trusted_capability = str(item.get("_backplane_source_capability") or "").strip()
        public_source = str(item.get("source") or "").strip()
        public_capability = str(item.get("source_capability") or "").strip()
        if not package_values or any(value != "com.sbotux" for value in package_values):
            raise WorkerAdapterError("explicit com.sbotux package identity is required")
        if not canonical_event_id or not room_turn:
            raise WorkerAdapterError("private room event and room turn refs are required")
        if trusted_source != "storebot_codex_worker_local_direct" or trusted_capability != "storebot_telegram_projection_v1":
            raise WorkerAdapterError("trusted worker source markers are required")
        if public_source and public_source != trusted_source:
            raise WorkerAdapterError("public source conflicts with trusted worker source")
        if public_capability and public_capability != trusted_capability:
            raise WorkerAdapterError("public source capability conflicts with trusted worker capability")
        if "turn_seq" not in item:
            raise WorkerAdapterError("explicit turn_seq is required")
        source_ms = int(
            item.get("message_ts_ms")
            or item.get("created_at_ms")
            or item.get("updated_at_ms")
            or now_ms
        )
        try:
            turn_seq = int(item.get("turn_seq"))
        except (TypeError, ValueError) as exc:
            raise WorkerAdapterError("turn sequence is invalid") from exc
        if turn_seq < 0:
            raise WorkerAdapterError("turn sequence must be non-negative")
        projection = build_storebot_telegram_projection(
            {
                "event_type": "transport_failure",
                "application_id": "com.sbotux",
                "resource": package_name,
                "target": str(item.get("target") or ""),
                "source": trusted_source,
                "source_capability": trusted_capability,
                "canonical_event_id": canonical_event_id,
                "room_turn": room_turn,
                "turn_seq": turn_seq,
                "failure_reason": failure_kind,
                "updated_at_ms": source_ms,
            },
            identity_key=self._identity_key,
            now_ms=int(now_ms),
        )
        if self.registry is None:
            volatile_state = _base_recovery_state(projection, self._identity_key, int(now_ms))
            decision = decide_recovery_action(volatile_state, int(now_ms))
            recovery_ref = _opaque(
                "strecovery",
                self._identity_key,
                {
                    "projection_id": projection["projection_id"],
                    "action": decision["action"],
                    "occurrence_id": volatile_state["occurrence_id"],
                },
            )
            recovery_state: dict[str, Any] = volatile_state
            recovery_action_created = False
        else:
            recovery_ref, decision, recovery_state, recovery_action_created = self.registry.observe(
                projection, now_ms=int(now_ms)
            )
        ops_receipts = self._failure_receipts(
            projection_id=str(projection["projection_id"]),
            failure_kind=failure_kind,
            occurred_at_ms=source_ms,
            now_ms=int(now_ms),
        )
        if self.registry is None and decision.get("action") == "delegate_analysis":
            decision = {**decision, "action": "wait", "reason": "durable_repository_required", "proposal": False}
        delegate = recovery_state.get("delegate") if isinstance(recovery_state.get("delegate"), Mapping) else {}
        if recovery_action_created and delegate.get("status") == "proposed":
            ops_receipts.append(
                self.record_ops_transition(
                    private_task_ref=str(projection["projection_id"]),
                    transition="recovery_proposed",
                    status="proposed",
                    resource="pc_codex_resource_01",
                    occurred_at_ms=int(now_ms),
                    now_ms=int(now_ms),
                    severity="warning",
                    attempt=int(delegate["recovery_attempt"]),
                )
            )
        if self.registry is not None and delegate.get("status") in {"proposed", "claiming"}:
            started, recovery_state = self.registry.claim_delegate(
                str(projection["projection_id"]), now_ms=int(now_ms), sink=self.delegate_sink
            )
            if started:
                delegate = dict(recovery_state["delegate"])
                ops_receipts.append(
                    self.record_ops_transition(
                        private_task_ref=str(projection["projection_id"]),
                        transition="recovery_started",
                        status="running",
                        resource="pc_codex_resource_01",
                        occurred_at_ms=int(now_ms),
                        now_ms=int(now_ms),
                        severity="warning",
                        attempt=int(delegate["recovery_attempt"]),
                    )
                )
        envelope = {
            "schema": SCHEMA,
            "mode": "proposal_only",
            "source_projection": projection,
            "recovery_ref": recovery_ref,
            "recovery_decision": decision,
            "ops_repository_mode": (
                str(self.ops_coordinator.receipt_repository.storage_kind)
                if self.ops_coordinator is not None
                else "unconfigured"
            ),
            "ops_receipts": ops_receipts,
            "no_send": True,
            "sent": False,
        }
        if frozenset(envelope) != ENVELOPE_KEYS:
            raise WorkerAdapterError("public envelope schema mismatch")
        return envelope

    def build_delegate_result(
        self,
        projection_id: str,
        *,
        private_result: Mapping[str, Any],
        private_evidence: Sequence[Any],
        now_ms: int,
    ) -> dict[str, Any]:
        if self.registry is None:
            raise WorkerAdapterError("durable recovery repository is not configured")
        state = self.registry.state(projection_id)
        projection = state.get("source_projection") if isinstance(state.get("source_projection"), Mapping) else {}
        delegate = state.get("delegate") if isinstance(state.get("delegate"), Mapping) else {}
        if not projection or delegate.get("status") != "started":
            raise WorkerAdapterError("claimed delegate state is not available")
        claim_expires_at_ms = int(delegate.get("claim_expires_at_ms") or 0)
        if int(now_ms) > claim_expires_at_ms:
            raise WorkerAdapterError("delegate claim lease has expired")
        return build_delegate_result(
            state,
            private_result=private_result,
            private_evidence=private_evidence,
            identity_key=self._identity_key,
            now_ms=int(now_ms),
            expires_at_ms=min(int(now_ms) + 60_000, claim_expires_at_ms),
        )

    def accept_delegate_result(
        self,
        projection_id: str,
        result: Mapping[str, Any],
        *,
        private_result: Mapping[str, Any],
        private_evidence: Sequence[Any],
        now_ms: int,
    ) -> dict[str, Any]:
        if self.registry is None:
            return {"accepted": False, "reason": "durable_recovery_repository_required", "ops_receipts": [], "no_send": True, "sent": False}
        accepted = self.registry.accept_delegate(
            projection_id,
            result,
            private_result=private_result,
            private_evidence=private_evidence,
            now_ms=int(now_ms),
        )
        receipts: list[dict[str, Any]] = []
        if accepted.get("accepted") is True:
            state = self.registry.state(projection_id)
            delegate = state.get("delegate") if isinstance(state.get("delegate"), Mapping) else {}
            attempt = int(delegate.get("recovery_attempt") or 0)
            receipts.extend(
                [
                    self.record_ops_transition(
                        private_task_ref=projection_id,
                        transition="recovery_result",
                        status="completed",
                        resource="pc_codex_resource_01",
                        occurred_at_ms=int(now_ms),
                        now_ms=int(now_ms),
                        attempt=attempt,
                    ),
                    self.record_ops_transition(
                        private_task_ref=projection_id,
                        transition="result",
                        status="completed",
                        resource="com.sbotux",
                        occurred_at_ms=int(now_ms),
                        now_ms=int(now_ms),
                    ),
                ]
            )
        return {**accepted, "ops_receipts": receipts}

    def build_guarded_reply_candidate(self, projection_id: str, *, now_ms: int) -> dict[str, Any]:
        if self.registry is None:
            raise WorkerAdapterError("durable recovery repository is not configured")
        state = self.registry.state(projection_id)
        projection = state.get("source_projection") if isinstance(state.get("source_projection"), Mapping) else {}
        delegate = state.get("delegate") if isinstance(state.get("delegate"), Mapping) else {}
        if not projection or delegate.get("status") != "completed":
            raise WorkerAdapterError("accepted delegate result is required")
        room_id = _opaque("stroom", self._identity_key, {"projection_id": projection_id})
        proposal = build_reply_proposal(
            projection,
            occurrence_id=state["occurrence_id"],
            room_id=room_id,
            proposal_revision=int(delegate["lease_epoch"]),
            redacted_preview="[reply_candidate]",
            lease_owner=delegate["lease_owner"],
            lease_epoch=int(delegate["lease_epoch"]),
            fencing_token=delegate["fencing_token"],
            expires_at_ms=int(now_ms) + 60_000,
            now_ms=int(now_ms),
            identity_key=self._identity_key,
        )
        accepted = accept_reply_proposal(
            proposal,
            current_request_id=proposal["request_id"],
            current_correlation_id=proposal["correlation_id"],
            current_occurrence_id=state["occurrence_id"],
            current_room_id=room_id,
            current_proposal_revision=int(delegate["lease_epoch"]),
            current_lease_owner=delegate["lease_owner"],
            current_lease_epoch=int(delegate["lease_epoch"]),
            current_fencing_token=delegate["fencing_token"],
            current_text_hash=proposal["text_hash"],
            now_ms=int(now_ms),
            identity_key=self._identity_key,
        )
        return {"proposal": proposal, "acceptance": accepted, "no_send": True, "sent": False}

    def compose_function_proposal(
        self,
        *,
        room_event_ref: str,
        room_turn_ref: str,
        turn_seq: int,
        catalog: Mapping[str, Any],
        capability_id: str,
        action_id: str,
        private_args: Mapping[str, Any],
        evidence_refs: Sequence[str],
        now_ms: int,
    ) -> dict[str, Any]:
        if not self.enabled:
            raise WorkerAdapterError("adapter is disabled")
        lineage = build_lineage(
            identity_key=self._identity_key,
            room_event_ref=room_event_ref,
            room_turn_ref=room_turn_ref,
            turn_seq=int(turn_seq),
        )
        return build_function_proposal(
            identity_key=self._identity_key,
            lineage=lineage,
            catalog=catalog,
            capability_id=capability_id,
            action_id=action_id,
            private_args=private_args,
            evidence_refs=evidence_refs,
            expires_at_ms=int(now_ms) + 60_000,
            now_ms=int(now_ms),
        )


__all__ = [
    "RepositoryRecoveryRegistry",
    "StoreBotTelegramWorkerAdapter",
    "WorkerAdapterError",
    "build_function_proposal",
    "build_lineage",
]
