#!/usr/bin/env python3
from __future__ import annotations

import argparse
import json
import secrets
import subprocess
import sys
import time
import urllib.request
from datetime import datetime, timedelta, timezone


KST = timezone(timedelta(hours=9))
DEFAULT_LOCAL_DIRECT_URL = "http://127.0.0.1:8765/storebot/request"


def now_ms() -> int:
    return int(time.time() * 1000)


def read_message(args: argparse.Namespace) -> str:
    if args.message:
        return " ".join(args.message).strip()
    if args.stdin:
        return sys.stdin.read().strip()
    if sys.stdin.isatty():
        return input("메시지> ").strip()
    return sys.stdin.read().strip()


def post_local_direct(args: argparse.Namespace, message: str) -> dict:
    request_id = args.request_id or f"manual_copy_{now_ms()}_{secrets.token_hex(3)}"
    ts_ms = now_ms()
    payload = {
        "request_id": request_id,
        "source": "termux_manual_copy",
        "transport": "termux_manual_copy",
        "room_id": args.room_id,
        "room": args.room_id,
        "room_name": args.room_name,
        "roomTitle": args.room_name,
        "sender": args.sender,
        "message": message,
        "text": message,
        "event_kind": "chat",
        "created_at_ms": ts_ms,
        "ts_ms": ts_ms,
        "local_direct": True,
        "manual_copy": True,
    }
    body = json.dumps(payload, ensure_ascii=False, separators=(",", ":")).encode("utf-8")
    req = urllib.request.Request(
        args.url,
        data=body,
        method="POST",
        headers={
            "Content-Type": "application/json; charset=utf-8",
            "Accept": "application/json",
        },
    )
    started = time.perf_counter()
    with urllib.request.urlopen(req, timeout=args.timeout_sec) as response:
        data = json.loads(response.read().decode("utf-8"))
    data["_manual_request_id"] = request_id
    data["_manual_wall_ms"] = int((time.perf_counter() - started) * 1000)
    return data


def copy_to_clipboard(text: str) -> tuple[bool, str]:
    candidates = [
        "termux-clipboard-set",
        "/data/data/com.sbotux/files/usr/bin/termux-clipboard-set",
    ]
    last_error = ""
    for candidate in candidates:
        try:
            subprocess.run(
                [candidate],
                input=text,
                text=True,
                check=True,
                stdout=subprocess.DEVNULL,
                stderr=subprocess.PIPE,
            )
            return True, candidate
        except FileNotFoundError:
            last_error = f"{candidate} not found"
        except subprocess.CalledProcessError as exc:
            last_error = (exc.stderr or str(exc)).strip()
    return False, last_error


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description="StoreBot Termux manual reply/copy helper")
    parser.add_argument("message", nargs="*", help="message to answer; reads stdin if omitted")
    parser.add_argument("--stdin", action="store_true", help="force reading message from stdin")
    parser.add_argument("--url", default=DEFAULT_LOCAL_DIRECT_URL)
    parser.add_argument("--timeout-sec", type=int, default=600)
    parser.add_argument("--room-id", default="storebot_group")
    parser.add_argument("--room-name", default="BBQ하이닉스점")
    parser.add_argument("--sender", default="수동입력")
    parser.add_argument("--request-id", default="")
    parser.add_argument("--copy", action=argparse.BooleanOptionalAction, default=True)
    parser.add_argument("--json", action="store_true", help="print raw response JSON")
    args = parser.parse_args(argv)

    message = read_message(args)
    if not message:
        print("메시지가 비어 있습니다.", file=sys.stderr)
        return 2

    started_at = datetime.now(KST).strftime("%H:%M:%S")
    try:
        response = post_local_direct(args, message)
    except Exception as exc:
        print(f"[{started_at}] 요청 실패: {exc}", file=sys.stderr)
        return 1

    if args.json:
        print(json.dumps(response, ensure_ascii=False, indent=2))
        return 0

    reply = str(response.get("reply") or "").strip()
    if response.get("skipped"):
        reply = "SKIP"
    image_request = response.get("image_request")
    if image_request and response.get("image_required"):
        image_type = image_request.get("type") if isinstance(image_request, dict) else "image"
        image_payload = image_request.get("payload") if isinstance(image_request, dict) and isinstance(image_request.get("payload"), dict) else {}
        graph_bounds = image_payload.get("graph_bounds") if isinstance(image_payload.get("graph_bounds"), dict) else {}
        print(f"[image_required:{image_type}] 앱 자동 이미지 전송 경로가 필요한 응답입니다.")
        print(
            "image_request_count=1 "
            f"image_date_range={image_payload.get('date_range', '')} "
            f"image_start_date={image_payload.get('start_date', '')} "
            f"image_end_date={image_payload.get('end_date', '')} "
            f"image_day_count={image_payload.get('day_count', 0)} "
            f"image_caption={image_payload.get('caption', '')} "
            f"image_graph_summary={graph_bounds.get('summary', '') if graph_bounds else ''}"
        )
    else:
        print("image_request_count=0")

    print(reply)
    print(
        f"\nrequest_id={response.get('_manual_request_id')} "
        f"elapsed={response.get('_manual_wall_ms')}ms "
        f"worker_elapsed={response.get('elapsed_ms')}ms "
        f"model={response.get('model')}"
    )

    if args.copy and reply and reply != "SKIP":
        ok, detail = copy_to_clipboard(reply)
        if ok:
            print(f"copied_to_clipboard={detail}")
        else:
            print(f"clipboard_copy_failed={detail}", file=sys.stderr)
            return 3
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
