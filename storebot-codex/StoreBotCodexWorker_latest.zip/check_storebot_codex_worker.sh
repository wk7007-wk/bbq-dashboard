#!/data/data/com.sbotux/files/usr/bin/bash
set -euo pipefail

export PATH="/data/data/com.sbotux/files/usr/bin:/data/data/com.sbotux/files/usr/bin/applets:/system/bin:/system/xbin:$PATH"

TERMUX_HOME="${TERMUX_HOME:-${HOME:-}}"
if [ -z "$TERMUX_HOME" ] || [ "$TERMUX_HOME" = "/" ] || [ "$TERMUX_HOME" = "/root" ]; then
  TERMUX_HOME="/data/data/com.sbotux/files/home"
fi

echo "== host processes =="
(ps -A -o PID,ARGS 2>/dev/null || ps -A 2>/dev/null || ps 2>/dev/null) | grep -E "proot-distro|storebot_codex_worker|codex exec|python3" | grep -v grep || true
echo
echo "== autostart =="
ls -l "$TERMUX_HOME/.termux/boot/10-storebot-codex.sh" "$TERMUX_HOME/.termux/boot/11-storebot-codex-watchdog.sh" "$TERMUX_HOME/.termux/storebot-codex/autostart.sh" 2>/dev/null || true
grep -n "storebot-codex/autostart.sh" "$TERMUX_HOME/.bashrc" 2>/dev/null || true
echo
echo "== boot log =="
tail -n 80 /sdcard/Download/storebot_codex_worker/boot.log 2>/dev/null || true
echo
echo "== watchdog log =="
tail -n 80 /sdcard/Download/storebot_codex_worker/watchdog.log 2>/dev/null || true
echo
echo "== local direct health =="
if command -v python3 >/dev/null 2>&1; then
  python3 -c 'import urllib.request; print(urllib.request.urlopen("http://127.0.0.1:8765/storebot/health", timeout=5).read().decode())' 2>/dev/null || true
elif command -v curl >/dev/null 2>&1; then
  curl -fsS --max-time 5 http://127.0.0.1:8765/storebot/health 2>/dev/null || true
fi
echo
echo "== power hardening =="
cmd deviceidle whitelist 2>/dev/null | grep -F "com.sbotux" || true
appops get com.sbotux RUN_IN_BACKGROUND RUN_ANY_IN_BACKGROUND START_FOREGROUND WAKE_LOCK SCHEDULE_EXACT_ALARM 2>/dev/null || true
settings get global stay_on_while_plugged_in 2>/dev/null || true
settings get system screen_off_timeout 2>/dev/null || true
echo

proot-distro login debian -- bash -lc '
set -euo pipefail
echo "== processes =="
ps aux | grep -E "storebot_codex_worker|codex exec|python3" | grep -v grep || true
echo
echo "== manual log =="
tail -n 120 /root/StoreBot/bot/logs/storebot_codex_worker.manual.log 2>/dev/null || true
echo
echo "== worker log =="
tail -n 120 /root/StoreBot/bot/logs/storebot_codex_worker.log 2>/dev/null || true
echo
echo "== files =="
ls -l /root/my-first-project/scripts/storebot_codex_worker.py /root/my-first-project/scripts/storebot_codex_replay_chat.py /root/my-first-project/STOREBOT_CODEX_WORKER.md /root/my-first-project/subphone/start_storebot_codex_worker.sh /root/my-first-project/subphone/watch_storebot_codex_worker.sh /root/.agents/skills/storebot-kakao-reply/SKILL.md /root/my-first-project/.agents/skills/storebot-kakao-reply/SKILL.md 2>/dev/null || true
python3 -c "import mcp; print('mcp python package ok')" 2>/dev/null || echo "mcp python package missing"
codex mcp get firebase-hub 2>/dev/null || true
grep -n "REASONING_EFFORT\\|--reasoning-effort\\|self-sync" /root/my-first-project/subphone/start_storebot_codex_worker.sh 2>/dev/null || true
echo
echo "== self-sync =="
cat /root/my-first-project/.storebot_codex_bundle_state.json 2>/dev/null || true
grep -n "SELF_SYNC\\|sync-once\\|bundle" /root/my-first-project/scripts/storebot_codex_worker.py 2>/dev/null | head -n 40 || true
echo
echo "== codex =="
export PATH="$HOME/.local/bin:$HOME/.codex/bin:/usr/local/bin:/usr/bin:/bin:$PATH"
command -v codex || true
codex --version || true
'
