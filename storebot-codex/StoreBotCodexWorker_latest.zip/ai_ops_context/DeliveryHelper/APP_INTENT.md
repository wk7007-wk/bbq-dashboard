<!-- source: /root/DeliveryHelper/APP_INTENT.md -->
# DeliveryHelper APP_INTENT.md

## 만든 이유
- 배달 중 주소, 건물, 동호, 현관비번, 지도 판단을 사용자가 직접 해석하는 시간을 줄인다.

## 사용자 결과
- 지도에서 어디로 가야 하는지, 어떤 건물/라인/비번인지, 현재 주문 상태가 무엇인지 즉시 보여야 한다.
- 배달 중 한손 조작으로 리스트, 핀, 지도, 후보 피드백을 빠르게 확인해야 한다.
- surface_type은 `native-apk`이다.

## 절대 기준
- 앱 코드는 파서, 규칙 로더, 캐시, 우선순위, 검증 같은 불변 로직만 가진다.
- 신규/변경 현장 지식은 코드에 추가하지 않고 외부 DB/Firebase를 SOT로 둔다.
- 아파트명, 별칭, 동 범위, 주소/현관 힌트, 비번 후보, 좌표/라인 학습값은 계속 늘어나는 운영 데이터로 본다.
- 기존 코드 상수는 호환 폴백으로만 취급하고, 신규 단지 지식 추가 경로로 쓰지 않는다.
- 단지별 동 범위처럼 현장에서 확정한 폐쇄 규칙은 Firebase rules_hub에 둔다.
- raw text, AI/파서, `address_book`, `building_memory`, 현장 피드백을 함께 보고 판단한다.
- 전표 raw 재파싱, 건물명 역매칭, 주소 후보 확장은 폰 앱에서 매 주문마다 무겁게 돌리지 않는다. PackHelper/외부 worker/Firebase DB가 정리한 확정 필드를 우선 소비한다.
- 매 주문의 앱 내부 파이프라인과 기존 LocalAI/Gemini/Groq 재검토는 precheck/evidence bundle을 만든다. GPT-5.5/Codex는 재검토 버튼 또는 주소 가공 큐에서 1차 AI 판단을 맡는다. 건물명이 없으면 worker가 Naver geocode/map 후보와 초성/별칭 건물명 검색 후보를 붙여 GPT가 주소 일치 근거로만 건물명을 판단한다. 결과는 같은 `device_key + order_timestamp`일 때만 해당 폰의 로컬 pending 주문에 선택 반영하고, 모든 주문을 동기 대기시키지 않는다.
- Groq CLI/shell AI lane은 DeliveryHelper의 주소/요청사항 분석 보조, 정규화 후보, 리스크 플래그 용도로 검토한다. Android 앱은 Groq API key를 보관하거나 Groq를 직접 호출하지 않고, 앱이 CLI를 직접 실행하는 것도 기본 금지다. CLI 인증 또는 백엔드 연결에 token/key가 필요할 수 있으나 서버/worker/shell AI 환경에만 두며, 앱은 Firebase/기존 API/worker 결과만 소비한다. 상세 계획은 `GROQ_CLI_PLAN.md`가 기준이다.
- 0차 precheck는 "앱 소스 하드코딩 판단"이 아니라 확정 규칙/Firebase SOT/캐시/AI 결과를 모은 증거다. 앱/worker가 자연어를 하드코딩으로 최종 선판단하지 않는다.
- 건물/동호/비번/공동현관비번/초성 검색 중 특정 구간 안정률이 떨어지면 DeliveryHelper 전용 Codex CLI 상주 세션을 후보 생성기로 붙인다. 승인된 보정은 `rules_hub`, `address_hints`, `building_memory`, `map_knowledge` 쪽 데이터로 환류하고, 다음 주문부터 evidence 품질을 올린다.
- 다음 확장 우선순위는 물류가 아니라 주소 가공이다. DeliveryHelper 앱은 배달 중 UI/알림/확정필드 소비를 맡고, 무거운 주소/건물/동호/비번 재가공은 StoreBotTermux/Codex 엔진 계열 worker가 Firebase 큐에서 비동기로 처리한다.
- Termux Codex 엔진 결과는 앱을 멈춰 기다리게 하지 않는다. 결과가 늦으면 현재 0차 표시를 유지하고, 같은 주문으로 확인될 때만 보정/재검토 카드나 알림으로 반영한다.
- 안정 기준은 DeliveryHelper 전용 Codex CLI 상주 세션이다. OpenClaw는 현재 운영 루트가 아니며, 사용자가 명시적으로 비교/진단을 요청할 때만 별도 확인한다. 입력은 주문 raw text, confirmed road, precheck, 초성/별칭 건물 후보, device/order key 같은 최소 envelope이며, 앱 화면/지도/UI를 직접 조작하지 않는다.
- Codex 결과도 확정값이 아니라 후보다. 같은 `device_key + order_timestamp` 확인 뒤 기존 재검토/보정 경로로만 반영하고, 실시간 배달 화면을 동기 대기시키지 않는다.
- goal mode는 승인 대기 없는 상주 모니터링/오류판정/자가교정 운영 모드다. DeliveryHelper 큐/worker/주소가공 오류, 결과 지연, 반복 보정, 데이터 불일치는 전용 AI ops가 보고/복구/self_fix까지 진행하되, 실제 주문 확정값은 기존 재검토/보정 경계를 통과해야 한다.
- 현관비번은 현재 주문 원문에서 추출한 더 구체적인 후보를 우선하고, 그 안에 포함된 짧은 저장 후보는 우선 표시하지 않는다.
- `#806 1234`, `샵806 1234`처럼 앞 숫자가 주소 호수와 겹치면 앞 숫자는 호수, 뒤 4자리 이상 숫자는 비번으로 본다. 세트가 아닌 단독 비번은 보통 4자리 기준으로 본다.
- 숨김, 삭제, 차단은 복원/확인/학습 경로를 남긴다.
- 주문 중복 판정은 주문번호/PackHelper 키 또는 같은 원문 알림 반복이 기준이다. 주소, 건물, 동호수만 같다는 이유로 새 주문을 스킵하면 주문 누락으로 본다.

## UI/동선 기준
- 지도와 하단 리스트는 서로 가리면 안 된다.
- 주문 핀과 필요한 텍스트가 기점, 장식, 배경보다 우선이다.
- 지도 위 라인/비번 캡션은 겹쳐서 모두 보이는 것보다, 일부 후보를 숨기더라도 읽히는 것을 우선한다.
- 저줌이나 캡션 밀집 상황에서는 라인/비번 캡션을 숨기는 것이 정상이다. 표시량보다 판독성을 우선한다.
- 지도 피드백은 운전 중 부담이 적은 선택지로 유지한다.
- 핀시트 큰 액션 라인은 자주 쓰는 길안내/전화/문자/GPS/보정을 우선하고, 작은 지도 버튼 라인은 보조 기능 위주로 둔다.
- 하단 리스트 주소 탭 줌은 지도 공간을 최대한 쓰되, 핀/내 위치가 잘리지 않을 최소 여백만 둔다.
- 홈/백그라운드 플로팅 주문카드는 기본 위치를 화면 정중앙 왼쪽으로 둔다.
- 자동업데이트는 앱을 계속 켜둔 상태에서도 주기적으로 재확인하고, 확인/다운로드/설치 단계가 Firebase 상태로 남아야 한다.

## 데이터/경계 기준
- DeliveryHelper는 배달 현장 판단 앱이고, PackHelper는 포장 판단 앱이다.
- DeliveryHelper 완료 기준은 native APK 기준이다. WebView/site/static-web 기준으로 대표 기기 화면 증거를 대체하지 않는다.
- PackHelper 정규화 결과(`/packhelper/delivery_orders`)는 배달 후보 입력으로 볼 수 있지만, DeliveryHelper 내부 주문 상태와 배달 완료/숨김 흐름을 대체하지 않는다.
- 물류 알림/물류 파싱은 다음 DeliveryHelper 구조 작업 범위에서 제외한다. 먼저 주문 알림 수신 안정성, 주소 가공 큐, 결과 반영 경계부터 닫는다.
- Codex 확장은 StoreBot/BankTotal/PosDelay와 세션을 섞지 않는다. DeliveryHelper 주소·비번·동호 후보는 DeliveryHelper 전용 스킬/큐/결과 경계로만 처리한다.
- 공용 서버폰 `codex_ops` 베이스를 쓰더라도 입력 envelope와 결과 경로는 DeliveryHelper 전용으로 분리한다. StoreBot 카톡, BankTotal 금융, PosDelay 플랫폼 조작 맥락을 한 세션에 섞지 않는다.
- C&I prompt는 DeliveryHelper monitor, 주소 worker, 앱 이벤트, 사용자/수동 enqueue, 또는 상주 판단 루프가 만든다. 이는 LLM 실행을 깨우는 envelope이며 C&I 판단 권한 제한이 아니다.
- C&I 자동 복구는 주소 worker/큐/schema/rules/docs/APK/업데이트센터 보정까지 허용하되, 실제 주문 확정값은 기존 재검토/보정 경계를 통과해야 한다.
- Groq 결과는 확정값이 아니라 후보/evidence다. 원본 텍스트, 확정 주소, 사용자 확인 경계를 보존하고, 최종 확정/원본 변경/영업 영향 action은 기존 안전 흐름을 통과해야 한다.
- 개인폰 Termux 연동이 필요하면 Android 앱과 같은 기기의 native Termux loopback worker를 우선한다. Ubuntu/proot는 빌드, 실험, 장기 작업 격리용이고 배달 중 앱이 의존하는 상시 localhost 서비스의 기본값으로 두지 않는다.
- 외부 DB 값 추가/수정만으로 끝나는 작업은 APK 빌드/설치 대상이 아니다.
- 빌드는 파서, 규칙 로더, 캐시, 스키마, 우선순위 같은 공통 로직이 바뀔 때만 한다.
- 확정 규칙은 OCR/AI/파서 추정보다 우선한다. 범위 밖 동은 버리고 호수 정보는 유지한다.
- TTS는 서브폰(KITCHEN) 전용이다. 개인폰(MAIN)은 토글이 남아 있어도 알림만 쓰고 발화하지 않는다.
- 차량/Android Auto 환경의 TTS는 미디어 볼륨이 아니라 내비 안내 음성 기준으로 들리게 한다.
- Firebase 지식 경로 변경 시 StoreBot, PosDelay 소비 경로까지 확인한다.
- 개인폰 실행 기준과 서브폰/주방폰 역할을 섞지 않는다.

## 수정 전 질문
- 이 변경이 현장 판단 시간을 줄이는가.
- 주소/비번 학습이나 복원 경로를 끊지 않는가.
- 지도/리스트 가시성을 실제 배달 화면 기준으로 확인했는가.

## 완료 기준
- 기준: Google Design MCP + Android Studio MCP support + 공장 PC/device evidence를 native APK 증거로 본다.
- 검증: 파서/지도/리스트 영향 테스트, representative device screenshot, accessibility snapshot, touch target, overflow 확인.
- 전달: Android 코드/리소스 변경 시 debug APK 빌드, `/sdcard/Download/DeliveryHelper_MMdd_HHmm.apk` 복사, `termux-open`.
- 업데이트: 자동업데이트 채널이 영향받으면 `version.json` + `DeliveryHelper_latest.bin` 공개 채널까지 확인한다.
- 제외: WebView/site/static-web Playwright/Axe/static deploy 기준만으로 native APK 완료를 판정하지 않는다.
- 남은 위험: 실제 네이버 지도 표시, 현장 색/겹침, Firebase 지식 누락 여부, 기기별 권한/오버레이 차이.
