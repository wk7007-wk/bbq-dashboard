#!/usr/bin/env python3
from __future__ import annotations

import argparse
import json
import secrets
import sys
import time
from pathlib import Path
from typing import Any

from storebot_codex_worker import REQUESTS_PATH, fb_get, fb_put, now_ms


DEFAULT_ROOM_ID = "storebot_group"
DEFAULT_ROOM_NAME = "BBQ하이닉스점 10"
DEFAULT_SENDER = "codex_direct"


def read_message(args: argparse.Namespace) -> str:
    if args.message.strip():
        return args.message.strip()
    if args.message_file.strip():
        return Path(args.message_file).read_text(encoding="utf-8").strip()
    if args.stdin or not sys.stdin.isatty():
        return sys.stdin.read().strip()
    return ""


def build_payload(args: argparse.Namespace, message: str) -> tuple[str, dict[str, Any]]:
    created_at = now_ms()
    key = f"direct_{created_at}_{secrets.token_hex(4)}"
    payload: dict[str, Any] = {
        "status": "pending",
        "source": args.source,
        "event_kind": args.event_kind,
        "room_id": args.room_id,
        "room_name": args.room_name,
        "sender": args.sender,
        "message": message,
        "is_owner": args.is_owner,
        "is_1on1": False,
        "ts": args.ts_ms or created_at,
        "created_at_ms": created_at,
        "injected_at_ms": created_at,
        "no_publish": not args.publish,
        "payload": {
            "direct_inject": True,
            "bypass_kakao_input": True,
            "reason": args.reason,
        },
    }
    if args.model:
        payload["codex_model"] = args.model
    if args.reasoning_effort:
        payload["codex_reasoning_effort"] = args.reasoning_effort
    if args.model_tier:
        payload["model_tier"] = args.model_tier
    if args.dry_run:
        payload["dry_run_requested"] = True
    return key, payload


def compact_status(item: dict[str, Any]) -> dict[str, Any]:
    image_request = item.get("image_request") if isinstance(item.get("image_request"), dict) else {}
    image_payload = image_request.get("payload") if isinstance(image_request.get("payload"), dict) else {}
    graph_bounds = image_payload.get("graph_bounds") if isinstance(image_payload.get("graph_bounds"), dict) else {}
    return {
        "status": item.get("status"),
        "event_kind": item.get("event_kind"),
        "source": item.get("source"),
        "room_id": item.get("room_id"),
        "room_name": item.get("room_name"),
        "no_publish": item.get("no_publish"),
        "worker": item.get("worker"),
        "model": item.get("model"),
        "reasoning_effort": item.get("reasoning_effort"),
        "model_override_reason": item.get("model_override_reason"),
        "reply_skipped": item.get("reply_skipped"),
        "publish_disabled": item.get("publish_disabled"),
        "outbound_key": item.get("outbound_key"),
        "image_request_count": 1 if image_request else 0,
        "image_request_type": image_request.get("type") if image_request else "",
        "image_fallback_policy": image_request.get("fallback_policy") if image_request else "",
        "image_start_date": image_payload.get("start_date") if image_payload else "",
        "image_end_date": image_payload.get("end_date") if image_payload else "",
        "image_date_range": image_payload.get("date_range") if image_payload else "",
        "image_day_count": image_payload.get("day_count") if image_payload else 0,
        "image_title": image_payload.get("title") if image_payload else "",
        "image_caption": image_payload.get("caption") if image_payload else "",
        "image_graph_bounds": graph_bounds,
        "image_graph_summary": graph_bounds.get("summary") if graph_bounds else "",
        "reply_len": item.get("reply_len"),
        "learning_stamp_status": item.get("learning_stamp_status"),
        "error": item.get("error"),
    }


def wait_for_result(key: str, timeout_sec: int, poll_sec: float) -> dict[str, Any] | None:
    deadline = time.monotonic() + timeout_sec
    last_status = ""
    while time.monotonic() < deadline:
        raw = fb_get(f"{REQUESTS_PATH}/{key}") or {}
        if isinstance(raw, dict):
            status = str(raw.get("status") or "")
            if status and status != last_status:
                print(f"status={status}", flush=True)
                last_status = status
            if status in {"done", "error"}:
                return raw
        time.sleep(poll_sec)
    return None


def parse_args(argv: list[str]) -> argparse.Namespace:
    parser = argparse.ArgumentParser(
        description="카톡을 경유하지 않고 StoreBot Codex 요청 큐에 직접 주입"
    )
    parser.add_argument("message_pos", nargs="*", help="주입할 메시지")
    parser.add_argument("--message", default="", help="주입할 메시지")
    parser.add_argument("--message-file", default="", help="메시지 텍스트 파일")
    parser.add_argument("--stdin", action="store_true", help="stdin에서 메시지를 읽음")
    parser.add_argument("--room-id", default=DEFAULT_ROOM_ID)
    parser.add_argument("--room-name", default=DEFAULT_ROOM_NAME)
    parser.add_argument("--sender", default=DEFAULT_SENDER)
    parser.add_argument("--source", default="codex_direct_inject")
    parser.add_argument("--event-kind", default="direct_prompt")
    parser.add_argument("--reason", default="manual_direct")
    parser.add_argument("--ts-ms", type=int, default=0)
    parser.add_argument("--is-owner", action=argparse.BooleanOptionalAction, default=True)
    parser.add_argument("--publish", action="store_true", help="처리 답변을 StoreBot 카톡 발송 큐에도 넣음")
    parser.add_argument("--model", default="", help="요청별 Codex model override")
    parser.add_argument("--reasoning-effort", default="", help="요청별 reasoning effort override")
    parser.add_argument("--model-tier", default="", help="high 지정 시 worker의 상위 모델 승격 정책 사용")
    parser.add_argument("--wait", action="store_true", help="done/error까지 기다린 뒤 요약 출력")
    parser.add_argument("--wait-timeout-sec", type=int, default=360)
    parser.add_argument("--poll-sec", type=float, default=5.0)
    parser.add_argument("--dry-run", action="store_true")
    return parser.parse_args(argv)


def main(argv: list[str]) -> int:
    args = parse_args(argv)
    if args.message_pos and not args.message:
        args.message = " ".join(args.message_pos)
    message = read_message(args)
    if not message:
        raise SystemExit("주입할 메시지가 필요합니다. 예: scripts/storebot_direct_inject.py '누락조회'")

    key, payload = build_payload(args, message)
    if args.dry_run:
        print(json.dumps({"key": key, "path": f"{REQUESTS_PATH}/{key}", "payload": payload}, ensure_ascii=False, indent=2))
        return 0

    fb_put(f"{REQUESTS_PATH}/{key}", payload)
    print(f"injected {key} no_publish={payload['no_publish']} room={args.room_name}")
    if not args.wait:
        return 0

    result = wait_for_result(key, args.wait_timeout_sec, args.poll_sec)
    if result is None:
        print(f"timeout waiting request={key}", file=sys.stderr)
        return 2
    print(json.dumps({"key": key, **compact_status(result)}, ensure_ascii=False, indent=2))
    return 1 if result.get("status") == "error" else 0


if __name__ == "__main__":
    raise SystemExit(main(sys.argv[1:]))
