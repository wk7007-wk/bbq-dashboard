#!/system/bin/sh
if [ -z "${STOREBOT_CODEX_BASH_REEXEC:-}" ]; then
  for candidate in "${STOREBOT_TERMUX_DATA_DIR:-}" /data/data/com.sbotux /data/data/com.termux; do
    [ -n "$candidate" ] || continue
    if [ -x "$candidate/files/usr/bin/bash" ]; then
      export STOREBOT_CODEX_BASH_REEXEC=1
      exec "$candidate/files/usr/bin/bash" "$0" "$@"
    fi
  done
fi
set -euo pipefail

resolve_termux_data_dir() {
  if [ -n "${STOREBOT_TERMUX_DATA_DIR:-}" ] && [ -x "$STOREBOT_TERMUX_DATA_DIR/files/usr/bin/bash" ]; then
    printf '%s\n' "$STOREBOT_TERMUX_DATA_DIR"
    return 0
  fi
  for candidate in /data/data/com.sbotux /data/data/com.termux; do
    if [ -x "$candidate/files/usr/bin/bash" ]; then
      printf '%s\n' "$candidate"
      return 0
    fi
  done
  printf '%s\n' "/data/data/com.sbotux"
}

APP_DATA_DIR="$(resolve_termux_data_dir)"
APP_PREFIX="$APP_DATA_DIR/files/usr"
export PREFIX="${PREFIX:-$APP_PREFIX}"
export PATH="$APP_PREFIX/bin:$APP_PREFIX/bin/applets:/system/bin:/system/xbin:$PATH"

PROOT_ROOTFS_DIR="${STOREBOT_CODEX_PROOT_ROOTFS_DIR:-$PREFIX/var/lib/proot-distro/installed-rootfs}"
DISTRO="${STOREBOT_CODEX_DISTRO:-}"
BASH_PATH="${STOREBOT_CODEX_BASH_PATH:-$APP_PREFIX/bin/bash}"
WATCHDOG_LOCK_DIR="${STOREBOT_CODEX_WATCHDOG_LOCK_DIR:-$APP_PREFIX/tmp/storebot_codex_watchdog.lock}"
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
CA_LIVE_STOP_HELPER="${CA_LIVE_STOP_HELPER:-$SCRIPT_DIR/restart_ca_live_runtime.sh}"
WORKER_LAUNCH_SCRIPT="${STOREBOT_RESTART_WORKER_LAUNCH_SCRIPT:-/sdcard/Download/storebot_codex_worker/launch_storebot_codex_background.sh}"
CANONICAL_MONITOR_LOG_DIR="${STOREBOT_RESTART_CANONICAL_MONITOR_LOG_DIR:-/sdcard/Download/ai_ops_monitor_canonical_sbotux}"
CANONICAL_MONITOR_LOCK_BASE_DIR="${STOREBOT_RESTART_CANONICAL_MONITOR_LOCK_BASE_DIR:-$CANONICAL_MONITOR_LOG_DIR}"
CANONICAL_MONITOR_LOCK_DIR="${STOREBOT_RESTART_CANONICAL_MONITOR_LOCK_DIR:-$CANONICAL_MONITOR_LOCK_BASE_DIR/ai_ops_monitor.lock}"
CANONICAL_MONITOR_NODE="subphone_ai_ops_monitor"
CANONICAL_MONITOR_BASE_PATH="/packhelper/ai_ops_monitor_v2"
CANONICAL_MONITOR_INTERVAL_SEC="300"
SBOTUX_MONITOR_LOG_DIR="/sdcard/Download/ai_ops_monitor_sbotux"
SBOTUX_MONITOR_LOCK_DIR="$SBOTUX_MONITOR_LOG_DIR/ai_ops_monitor.lock"
SBOTUX_MONITOR_NODE="subphone_sbotux_ai_ops_monitor"
SBOTUX_MONITOR_BASE_PATH="/packhelper/ai_ops_monitor_sbotux_v2"
SBOTUX_MONITOR_INTERVAL_SEC="60"

if [ -z "$BASH_PATH" ] || [ ! -x "$BASH_PATH" ]; then
  echo "bash executable unavailable for StoreBot restart" >&2
  exit 66
fi
for required_script in "$CA_LIVE_STOP_HELPER" "$WORKER_LAUNCH_SCRIPT"; do
  if [ ! -f "$required_script" ] || [ -L "$required_script" ]; then
    echo "StoreBot restart dependency unavailable or unsafe: $required_script" >&2
    exit 66
  fi
done
for canonical_path in "$CANONICAL_MONITOR_LOG_DIR" "$CANONICAL_MONITOR_LOCK_BASE_DIR" "$CANONICAL_MONITOR_LOCK_DIR"; do
  case "$canonical_path" in
    /*) ;;
    *)
      echo "canonical AI Ops monitor path must be absolute: $canonical_path" >&2
      exit 65
      ;;
  esac
  if [ -L "$canonical_path" ]; then
    echo "refusing symlink canonical AI Ops monitor path: $canonical_path" >&2
    exit 65
  fi
  if [ -e "$canonical_path" ] && [ ! -d "$canonical_path" ]; then
    echo "canonical AI Ops monitor path is not a directory: $canonical_path" >&2
    exit 65
  fi
done
case "$CANONICAL_MONITOR_LOCK_DIR" in
  "$CANONICAL_MONITOR_LOCK_BASE_DIR"/ai_ops_monitor.lock) ;;
  *)
    echo "canonical AI Ops monitor lock must be the exact lock-base child" >&2
    exit 65
    ;;
esac
mkdir -p -- "$CANONICAL_MONITOR_LOG_DIR"
if [ ! -d "$CANONICAL_MONITOR_LOG_DIR" ] || [ -L "$CANONICAL_MONITOR_LOG_DIR" ]; then
  echo "canonical AI Ops monitor log directory is unsafe after creation: $CANONICAL_MONITOR_LOG_DIR" >&2
  exit 65
fi
"$BASH_PATH" "$CA_LIVE_STOP_HELPER" --stop-ai-only
"$BASH_PATH" "$CA_LIVE_STOP_HELPER" --stop-codex-ops-only

resolve_distro() {
  if [ -n "$DISTRO" ] && [ -d "$PROOT_ROOTFS_DIR/$DISTRO" ]; then
    return 0
  fi
  if [ -d "$PROOT_ROOTFS_DIR/debian" ]; then
    DISTRO="debian"
    return 0
  fi
  if [ -d "$PROOT_ROOTFS_DIR/ubuntu" ]; then
    DISTRO="ubuntu"
    return 0
  fi
  local first
  first="$(find "$PROOT_ROOTFS_DIR" -mindepth 1 -maxdepth 1 -type d -print 2>/dev/null | head -n 1)"
  if [ -n "$first" ]; then
    DISTRO="$(basename "$first")"
    return 0
  fi
  return 1
}

kill_matching() {
  local pattern="$1"
  local pids
  local proot_ps=""
  if command -v proot-distro >/dev/null 2>&1 && resolve_distro; then
    proot_ps="$(proot-distro login "$DISTRO" -- ps aux 2>/dev/null | awk 'NR > 1 {print $2 " " $0}' || true)"
  fi
  pids="$(
    {
      ps -A -o PID,ARGS 2>/dev/null || true
      ps -ef 2>/dev/null | awk 'NR > 1 {print $2 " " $0}' || true
      printf "%s\n" "$proot_ps"
    } | awk -v pat="$pattern" '$0 ~ pat && $0 !~ /awk/ {print $1}' || true
  )"
  if [ -n "$pids" ]; then
    for pid in $pids; do
      kill "$pid" 2>/dev/null || true
    done
  fi
}

kill_in_proot() {
  local pattern="$1"
  if command -v proot-distro >/dev/null 2>&1 && resolve_distro; then
    proot-distro login "$DISTRO" -- bash -lc '
pattern="$1"
if command -v pkill >/dev/null 2>&1; then
  pkill -f "$pattern" 2>/dev/null || true
fi
pids="$(
  (ps aux 2>/dev/null || ps -ef 2>/dev/null || ps -A -o pid,args 2>/dev/null || true) \
    | awk -v pat="$pattern" '"'"'$0 ~ pat && $0 !~ /awk/ && $0 !~ /bash -lc/ {print $2}'"'"'
)"
if [ -n "$pids" ]; then
  kill $pids 2>/dev/null || true
fi
' kill-in-proot "$pattern" 2>/dev/null || true
  fi
}

kill_matching "storebot_codex_worker.py --watch"
sleep 1
kill_matching "proot.*storebot_codex_worker"
kill_matching "run_storebot_codex_worker.sh"
kill_matching "start_storebot_codex_worker.sh"
kill_in_proot "storebot_codex_worker.py --watch"
rm -rf /tmp/storebot_codex_worker.lock "$WATCHDOG_LOCK_DIR" 2>/dev/null || true
sleep 1

STOREBOT_CODEX_DETACH=1 \
AI_OPS_MONITOR_LOG_DIR="$SBOTUX_MONITOR_LOG_DIR" \
AI_OPS_MONITOR_LOCK_BASE_DIR="$SBOTUX_MONITOR_LOG_DIR" \
AI_OPS_MONITOR_LOCK_DIR="$SBOTUX_MONITOR_LOCK_DIR" \
AI_OPS_MONITOR_NODE="$SBOTUX_MONITOR_NODE" \
AI_OPS_BASE_PATH="$SBOTUX_MONITOR_BASE_PATH" \
AI_OPS_MONITOR_INTERVAL_SEC="$SBOTUX_MONITOR_INTERVAL_SEC" \
  "$BASH_PATH" "$WORKER_LAUNCH_SCRIPT" restart
STOREBOT_CODEX_DETACH=1 \
CODEX_OPS_ENABLED=0 \
STOREBOT_CODEX_HOST_LOG_DIR="$CANONICAL_MONITOR_LOG_DIR" \
AI_OPS_MONITOR_LOG_DIR="$CANONICAL_MONITOR_LOG_DIR" \
AI_OPS_MONITOR_LOCK_BASE_DIR="$CANONICAL_MONITOR_LOCK_BASE_DIR" \
AI_OPS_MONITOR_LOCK_DIR="$CANONICAL_MONITOR_LOCK_DIR" \
AI_OPS_MONITOR_NODE="$CANONICAL_MONITOR_NODE" \
AI_OPS_BASE_PATH="$CANONICAL_MONITOR_BASE_PATH" \
AI_OPS_MONITOR_INTERVAL_SEC="$CANONICAL_MONITOR_INTERVAL_SEC" \
  "$BASH_PATH" "$WORKER_LAUNCH_SCRIPT" ai-ops-monitor-only
