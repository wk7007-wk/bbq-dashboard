#!/usr/bin/env python3
"""No-I/O chat, function, approval, and delivery contracts for StoreBot."""

from __future__ import annotations

import hashlib
import hmac
import json
import re
import threading
from collections.abc import Mapping, Sequence
from copy import deepcopy
from typing import Any


SCHEMA = "storebot.telegram_chat_contract.v1"
DELIVERY_SCHEMA = "storebot.telegram_delivery.v1"
WONMUX_GATEWAY = "com.wonmux"
KAKAO_OWNER = "com.sbotux"
ROLES = frozenset({"dispatcher", "analyst", "reviewer", "observer", "executor"})
PARTICIPANT_KINDS = frozenset({"codex_resource", "chatgpt", "role_bot", "runtime_observer"})
EXECUTOR_RESOURCES = frozenset({"pc_codex_resource_01", "approved_virtual_executor"})
RISK_RANK = {"low": 0, "review": 1, "high": 2, "critical": 3}
WRITE_RANK = {"read": 0, "proposal": 1, "write": 2, "destructive": 3}
TERMINAL = frozenset({"completed", "failed"})
OPAQUE_RE = re.compile(r"\A[a-z][a-z0-9_]*_[0-9a-f]{24,64}\Z")
FUNCTION_PROPOSAL_KEYS = frozenset(
    {
        "schema", "proposal_id", "request_id", "thread_id", "turn_id", "parent_turn_id",
        "catalog_version", "catalog_hash", "capability_id", "action_id", "private_args_hash",
        "private_args_ref", "idempotency_key", "evidence_refs", "privacy_risk", "side_effect_risk",
        "approval_required", "approval_scope", "expires_at_ms", "lifecycle_status", "lease_owner",
        "lease_epoch", "fencing_token", "execute_count", "approval_id", "resource",
        "kakao_transport_owner", "gateway_package", "no_send", "sent",
    }
)
CLAIM_KEYS = FUNCTION_PROPOSAL_KEYS | {"executor_resource"}
TERMINAL_KEYS = CLAIM_KEYS | {"result_ref", "result_hash"}
APPROVAL_KEYS = frozenset(
    {"approval_id", "proposal_id", "idempotency_key", "scope", "approver_id", "issued_at_ms", "expires_at_ms", "used"}
)
DELIVERY_KEYS = frozenset(
    {
        "schema", "delivery_id", "proposal_id", "thread_id", "turn_id", "result_ref",
        "telegram_surface_ref", "delivery_status", "delivery_attempt", "execute_count", "resource",
        "kakao_transport_owner", "gateway_package", "no_send", "sent",
    }
)


class ChatContractError(ValueError):
    pass


def _key(value: bytes | str) -> bytes:
    result = value.encode("utf-8") if isinstance(value, str) else bytes(value)
    if len(result) < 32:
        raise ChatContractError("identity_key must contain at least 32 bytes")
    return result


def _canonical(value: Any) -> bytes:
    return json.dumps(value, ensure_ascii=False, sort_keys=True, separators=(",", ":")).encode("utf-8")


def _opaque(prefix: str, key: bytes, value: Any) -> str:
    return f"{prefix}_{hmac.new(key, _canonical(value), hashlib.sha256).hexdigest()[:32]}"


def _require_opaque(value: Any, prefix: str, field: str) -> str:
    result = str(value or "")
    if not result.startswith(f"{prefix}_") or not OPAQUE_RE.fullmatch(result):
        raise ChatContractError(f"{field} must be an opaque {prefix} ref")
    return result


def _owner_boundary(payload: Mapping[str, Any]) -> None:
    if payload.get("gateway_package") != WONMUX_GATEWAY:
        raise ChatContractError("com.wonmux is the required gateway package")
    if payload.get("resource") != KAKAO_OWNER or payload.get("kakao_transport_owner") != KAKAO_OWNER:
        raise ChatContractError("com.sbotux must remain resource and Kakao transport owner")


def build_lineage(
    *,
    identity_key: bytes | str,
    room_event_ref: str,
    room_turn_ref: str,
    turn_seq: int,
    parent_turn_id: str = "",
) -> dict[str, Any]:
    key = _key(identity_key)
    event_ref = _require_opaque(room_event_ref, "rje", "room_event_ref")
    room_ref = _require_opaque(room_turn_ref, "rjt", "room_turn_ref")
    sequence = int(turn_seq)
    if sequence < 0:
        raise ChatContractError("turn_seq must be non-negative")
    if parent_turn_id:
        _require_opaque(parent_turn_id, "stturn", "parent_turn_id")
    thread_id = _opaque("stthread", key, {"room_turn_ref": room_ref})
    turn_id = _opaque(
        "stturn",
        key,
        {"thread_id": thread_id, "room_event_ref": event_ref, "room_turn_ref": room_ref, "turn_seq": sequence},
    )
    return {
        "thread_id": thread_id,
        "turn_id": turn_id,
        "parent_turn_id": parent_turn_id,
        "turn_seq": sequence,
        "room_event_ref": event_ref,
    }


def validate_participant(participant: Mapping[str, Any]) -> None:
    if frozenset(participant) != {"participant_id", "role", "kind", "resource"}:
        raise ChatContractError("participant schema mismatch")
    _require_opaque(participant.get("participant_id"), "stactor", "participant_id")
    role = str(participant.get("role") or "")
    kind = str(participant.get("kind") or "")
    resource = str(participant.get("resource") or "")
    if role not in ROLES or kind not in PARTICIPANT_KINDS:
        raise ChatContractError("participant role or kind is not allowed")
    if kind == "chatgpt" and role != "reviewer":
        raise ChatContractError("ChatGPT participates only as reviewer")
    if kind in {"role_bot", "runtime_observer"} and role != "observer":
        raise ChatContractError("bot/runtime participants are observer-only")
    if role == "executor" and (kind != "codex_resource" or resource not in EXECUTOR_RESOURCES):
        raise ChatContractError("executor must be an approved Codex resource")


def _catalog_action(catalog: Mapping[str, Any], capability_id: str, action_id: str) -> Mapping[str, Any]:
    if frozenset(catalog) != {"catalog_version", "catalog_hash", "capabilities"}:
        raise ChatContractError("catalog snapshot schema mismatch")
    _require_opaque(catalog.get("catalog_hash"), "stcatalog", "catalog_hash")
    capabilities = catalog.get("capabilities")
    capability = capabilities.get(capability_id) if isinstance(capabilities, Mapping) else None
    actions = capability.get("actions") if isinstance(capability, Mapping) else None
    action = actions.get(action_id) if isinstance(actions, Mapping) else None
    if not isinstance(action, Mapping):
        raise ChatContractError("unknown capability_id/action_id")
    if frozenset(action) != {"privacy_risk", "side_effect_risk", "approval_scope"}:
        raise ChatContractError("catalog action schema mismatch")
    if action.get("privacy_risk") not in RISK_RANK or action.get("side_effect_risk") not in WRITE_RANK:
        raise ChatContractError("catalog risk is invalid")
    return action


def build_function_proposal(
    *,
    identity_key: bytes | str,
    lineage: Mapping[str, Any],
    catalog: Mapping[str, Any],
    capability_id: str,
    action_id: str,
    private_args: Mapping[str, Any],
    evidence_refs: Sequence[str],
    expires_at_ms: int,
    now_ms: int,
) -> dict[str, Any]:
    key = _key(identity_key)
    action = _catalog_action(catalog, capability_id, action_id)
    thread_id = _require_opaque(lineage.get("thread_id"), "stthread", "thread_id")
    turn_id = _require_opaque(lineage.get("turn_id"), "stturn", "turn_id")
    parent_turn_id = str(lineage.get("parent_turn_id") or "")
    if parent_turn_id:
        _require_opaque(parent_turn_id, "stturn", "parent_turn_id")
    refs = tuple(_require_opaque(value, "stev", "evidence_ref") for value in evidence_refs)
    expiry = int(expires_at_ms)
    if not int(now_ms) < expiry <= int(now_ms) + 5 * 60_000:
        raise ChatContractError("proposal expiry is outside the bounded window")
    args_hash = _opaque("stargs", key, private_args)
    args_ref = _opaque("stargsref", key, {"args_hash": args_hash, "turn_id": turn_id})
    request_id = _opaque("strequest", key, {"turn_id": turn_id, "capability_id": capability_id, "action_id": action_id})
    idempotency_key = _opaque(
        "stidem",
        key,
        {"request_id": request_id, "private_args_hash": args_hash, "catalog_hash": catalog["catalog_hash"]},
    )
    approval_required = RISK_RANK[action["privacy_risk"]] >= RISK_RANK["review"] or WRITE_RANK[action["side_effect_risk"]] >= WRITE_RANK["write"]
    identity = {
        "request_id": request_id,
        "thread_id": thread_id,
        "turn_id": turn_id,
        "parent_turn_id": parent_turn_id,
        "catalog_version": str(catalog["catalog_version"]),
        "catalog_hash": str(catalog["catalog_hash"]),
        "capability_id": capability_id,
        "action_id": action_id,
        "private_args_hash": args_hash,
        "private_args_ref": args_ref,
        "idempotency_key": idempotency_key,
        "evidence_refs": list(refs),
        "privacy_risk": action["privacy_risk"],
        "side_effect_risk": action["side_effect_risk"],
        "approval_required": approval_required,
        "approval_scope": str(action["approval_scope"]),
        "expires_at_ms": expiry,
    }
    return {
        "schema": SCHEMA,
        "proposal_id": _opaque("stfunction", key, identity),
        **identity,
        "lifecycle_status": "request",
        "lease_owner": "",
        "lease_epoch": 0,
        "fencing_token": "",
        "execute_count": 0,
        "approval_id": "",
        "resource": KAKAO_OWNER,
        "kakao_transport_owner": KAKAO_OWNER,
        "gateway_package": WONMUX_GATEWAY,
        "no_send": True,
        "sent": False,
    }


def validate_function_proposal(
    proposal: Mapping[str, Any],
    catalog: Mapping[str, Any],
    now_ms: int,
    *,
    identity_key: bytes | str,
) -> None:
    key = _key(identity_key)
    if frozenset(proposal) != FUNCTION_PROPOSAL_KEYS or proposal.get("schema") != SCHEMA:
        raise ChatContractError("function proposal schema mismatch")
    _owner_boundary(proposal)
    for field, prefix in (
        ("proposal_id", "stfunction"), ("request_id", "strequest"), ("thread_id", "stthread"),
        ("turn_id", "stturn"), ("catalog_hash", "stcatalog"), ("private_args_hash", "stargs"),
        ("private_args_ref", "stargsref"), ("idempotency_key", "stidem"),
    ):
        _require_opaque(proposal.get(field), prefix, field)
    for ref in proposal.get("evidence_refs") if isinstance(proposal.get("evidence_refs"), list) else ():
        _require_opaque(ref, "stev", "evidence_ref")
    if proposal.get("lifecycle_status") != "request" or proposal.get("lease_owner") or int(proposal.get("lease_epoch") or 0) != 0 or proposal.get("fencing_token"):
        raise ChatContractError("new proposal lifecycle fields are invalid")
    action = _catalog_action(catalog, str(proposal.get("capability_id") or ""), str(proposal.get("action_id") or ""))
    if proposal.get("catalog_version") != catalog.get("catalog_version") or proposal.get("catalog_hash") != catalog.get("catalog_hash"):
        raise ChatContractError("stale or mismatched catalog")
    if RISK_RANK.get(str(proposal.get("privacy_risk")), -1) < RISK_RANK[action["privacy_risk"]]:
        raise ChatContractError("privacy risk downgrade")
    if WRITE_RANK.get(str(proposal.get("side_effect_risk")), -1) < WRITE_RANK[action["side_effect_risk"]]:
        raise ChatContractError("side-effect risk downgrade")
    required = RISK_RANK[action["privacy_risk"]] >= 1 or WRITE_RANK[action["side_effect_risk"]] >= 2
    if proposal.get("approval_required") is not required or proposal.get("approval_scope") != action.get("approval_scope"):
        raise ChatContractError("approval policy mismatch")
    if int(proposal.get("expires_at_ms") or 0) < int(now_ms):
        raise ChatContractError("proposal expired")
    if proposal.get("no_send") is not True or proposal.get("sent") is not False:
        raise ChatContractError("proposal must remain no-send")
    expected_request_id = _opaque(
        "strequest",
        key,
        {
            "turn_id": proposal["turn_id"],
            "capability_id": proposal["capability_id"],
            "action_id": proposal["action_id"],
        },
    )
    expected_args_ref = _opaque(
        "stargsref",
        key,
        {"args_hash": proposal["private_args_hash"], "turn_id": proposal["turn_id"]},
    )
    expected_idempotency = _opaque(
        "stidem",
        key,
        {
            "request_id": expected_request_id,
            "private_args_hash": proposal["private_args_hash"],
            "catalog_hash": proposal["catalog_hash"],
        },
    )
    identity = {
        "request_id": expected_request_id,
        "thread_id": proposal["thread_id"],
        "turn_id": proposal["turn_id"],
        "parent_turn_id": proposal["parent_turn_id"],
        "catalog_version": proposal["catalog_version"],
        "catalog_hash": proposal["catalog_hash"],
        "capability_id": proposal["capability_id"],
        "action_id": proposal["action_id"],
        "private_args_hash": proposal["private_args_hash"],
        "private_args_ref": expected_args_ref,
        "idempotency_key": expected_idempotency,
        "evidence_refs": proposal["evidence_refs"],
        "privacy_risk": proposal["privacy_risk"],
        "side_effect_risk": proposal["side_effect_risk"],
        "approval_required": proposal["approval_required"],
        "approval_scope": proposal["approval_scope"],
        "expires_at_ms": proposal["expires_at_ms"],
    }
    if proposal["request_id"] != expected_request_id:
        raise ChatContractError("request_id integrity mismatch")
    if proposal["private_args_ref"] != expected_args_ref:
        raise ChatContractError("private_args_ref integrity mismatch")
    if proposal["idempotency_key"] != expected_idempotency:
        raise ChatContractError("idempotency integrity mismatch")
    if proposal["proposal_id"] != _opaque("stfunction", key, identity):
        raise ChatContractError("proposal_id integrity mismatch")


def build_approval_receipt(
    proposal: Mapping[str, Any],
    *,
    identity_key: bytes | str,
    approver_id: str,
    issued_at_ms: int,
    expires_at_ms: int,
) -> dict[str, Any]:
    key = _key(identity_key)
    approver = _require_opaque(approver_id, "stactor", "approver_id")
    if not int(issued_at_ms) < int(expires_at_ms) <= int(issued_at_ms) + 5 * 60_000:
        raise ChatContractError("approval expiry is invalid")
    identity = {
        "proposal_id": proposal["proposal_id"],
        "idempotency_key": proposal["idempotency_key"],
        "scope": proposal["approval_scope"],
        "approver_id": approver,
        "issued_at_ms": int(issued_at_ms),
        "expires_at_ms": int(expires_at_ms),
    }
    return {"approval_id": _opaque("stapproval", key, identity), **identity, "used": False}


def validate_approval_receipt(
    proposal: Mapping[str, Any],
    receipt: Mapping[str, Any] | None,
    *,
    identity_key: bytes | str,
    now_ms: int,
    used_approval_ids: Sequence[str] = (),
) -> str:
    if not proposal.get("approval_required"):
        return ""
    if not isinstance(receipt, Mapping):
        raise ChatContractError("approval receipt required")
    if frozenset(receipt) != APPROVAL_KEYS:
        raise ChatContractError("approval receipt schema mismatch")
    approval_id = _require_opaque(receipt.get("approval_id"), "stapproval", "approval_id")
    expected = {
        "proposal_id": proposal["proposal_id"],
        "idempotency_key": proposal["idempotency_key"],
        "scope": proposal["approval_scope"],
    }
    if any(receipt.get(key) != value for key, value in expected.items()):
        raise ChatContractError("approval scope or proposal mismatch")
    if receipt.get("used") is not False or approval_id in set(used_approval_ids):
        raise ChatContractError("approval receipt already used")
    if int(receipt.get("issued_at_ms") or 0) > int(now_ms) or int(receipt.get("expires_at_ms") or 0) < int(now_ms):
        raise ChatContractError("approval receipt expired or not active")
    identity = {
        "proposal_id": receipt["proposal_id"],
        "idempotency_key": receipt["idempotency_key"],
        "scope": receipt["scope"],
        "approver_id": receipt["approver_id"],
        "issued_at_ms": int(receipt["issued_at_ms"]),
        "expires_at_ms": int(receipt["expires_at_ms"]),
    }
    if approval_id != _opaque("stapproval", _key(identity_key), identity):
        raise ChatContractError("approval_id integrity mismatch")
    return approval_id


def _claim_transition(
    proposal: Mapping[str, Any],
    participant: Mapping[str, Any],
    *,
    identity_key: bytes | str,
    now_ms: int,
) -> dict[str, Any]:
    validate_participant(participant)
    if frozenset(proposal) != FUNCTION_PROPOSAL_KEYS or proposal.get("schema") != SCHEMA:
        raise ChatContractError("function proposal schema mismatch")
    _owner_boundary(proposal)
    if proposal.get("no_send") is not True or proposal.get("sent") is not False:
        raise ChatContractError("function proposal must remain no-send")
    if participant["role"] != "executor":
        raise ChatContractError("only executor may claim a function")
    if proposal.get("lifecycle_status") != "request" or int(proposal.get("lease_epoch") or 0) != 0:
        raise ChatContractError("function is not claimable")
    if int(proposal.get("expires_at_ms") or 0) < int(now_ms):
        raise ChatContractError("function proposal expired")
    claimed = deepcopy(dict(proposal))
    claimed["lifecycle_status"] = "claim"
    claimed["lease_owner"] = participant["participant_id"]
    claimed["lease_epoch"] = 1
    claimed["fencing_token"] = _opaque(
        "stfence",
        _key(identity_key),
        {"proposal_id": proposal["proposal_id"], "lease_owner": participant["participant_id"], "lease_epoch": 1},
    )
    claimed["executor_resource"] = participant["resource"]
    return claimed


class InMemoryFunctionLifecycle:
    """Atomic in-memory CAS fixture; it performs no external I/O."""

    def __init__(
        self,
        proposal: Mapping[str, Any],
        *,
        catalog: Mapping[str, Any],
        identity_key: bytes | str,
        now_ms: int,
    ):
        validate_function_proposal(proposal, catalog, int(now_ms), identity_key=identity_key)
        self._state = deepcopy(dict(proposal))
        self._catalog = deepcopy(dict(catalog))
        self._identity_key = _key(identity_key)
        self._lock = threading.Lock()

    def snapshot(self) -> dict[str, Any]:
        with self._lock:
            return deepcopy(self._state)

    def claim(self, participant: Mapping[str, Any], *, now_ms: int) -> dict[str, Any]:
        with self._lock:
            validate_function_proposal(
                self._state,
                self._catalog,
                int(now_ms),
                identity_key=self._identity_key,
            )
            self._state = _claim_transition(self._state, participant, identity_key=self._identity_key, now_ms=now_ms)
            return deepcopy(self._state)


def mark_worker_started(
    claimed: Mapping[str, Any],
    participant: Mapping[str, Any],
    *,
    catalog: Mapping[str, Any],
    identity_key: bytes | str,
    lease_epoch: int,
    fencing_token: str,
    approval_receipt: Mapping[str, Any] | None,
    used_approval_ids: Sequence[str],
    now_ms: int,
) -> dict[str, Any]:
    validate_participant(participant)
    if frozenset(claimed) != CLAIM_KEYS:
        raise ChatContractError("claim schema mismatch")
    canonical_proposal = {key: deepcopy(claimed[key]) for key in FUNCTION_PROPOSAL_KEYS}
    canonical_proposal.update(
        {
            "lifecycle_status": "request",
            "lease_owner": "",
            "lease_epoch": 0,
            "fencing_token": "",
            "execute_count": 0,
            "approval_id": "",
        }
    )
    validate_function_proposal(
        canonical_proposal,
        catalog,
        int(now_ms),
        identity_key=identity_key,
    )
    if claimed.get("lifecycle_status") != "claim":
        raise ChatContractError("worker_started requires claim")
    if participant.get("participant_id") != claimed.get("lease_owner") or int(lease_epoch) != int(claimed.get("lease_epoch") or 0) or fencing_token != claimed.get("fencing_token"):
        raise ChatContractError("lease or fence mismatch")
    approval_id = validate_approval_receipt(
        claimed,
        approval_receipt,
        identity_key=identity_key,
        now_ms=now_ms,
        used_approval_ids=used_approval_ids,
    )
    started = deepcopy(dict(claimed))
    started["lifecycle_status"] = "worker_started"
    started["execute_count"] = 1
    started["approval_id"] = approval_id
    return started


def complete_function(
    started: Mapping[str, Any],
    *,
    lease_owner: str,
    lease_epoch: int,
    fencing_token: str,
    result_status: str,
    result_ref: str,
    result_hash: str,
) -> dict[str, Any]:
    if frozenset(started) != CLAIM_KEYS:
        raise ChatContractError("worker_started schema mismatch")
    if started.get("lifecycle_status") != "worker_started":
        raise ChatContractError("terminal result requires worker_started")
    if lease_owner != started.get("lease_owner") or int(lease_epoch) != int(started.get("lease_epoch") or 0) or fencing_token != started.get("fencing_token"):
        raise ChatContractError("terminal lease or fence mismatch")
    if result_status not in TERMINAL:
        raise ChatContractError("terminal status is invalid")
    _require_opaque(result_ref, "stresultref", "result_ref")
    _require_opaque(result_hash, "stresult", "result_hash")
    terminal = deepcopy(dict(started))
    terminal["lifecycle_status"] = result_status
    terminal["result_ref"] = result_ref
    terminal["result_hash"] = result_hash
    terminal["no_send"] = True
    terminal["sent"] = False
    return terminal


def build_delivery_projection(terminal: Mapping[str, Any], *, identity_key: bytes | str, telegram_surface_ref: str) -> dict[str, Any]:
    if frozenset(terminal) != TERMINAL_KEYS:
        raise ChatContractError("terminal result schema mismatch")
    if terminal.get("lifecycle_status") not in TERMINAL:
        raise ChatContractError("delivery requires terminal work result")
    surface = _require_opaque(telegram_surface_ref, "sttg", "telegram_surface_ref")
    identity = {
        "proposal_id": terminal["proposal_id"],
        "thread_id": terminal["thread_id"],
        "turn_id": terminal["turn_id"],
        "result_ref": terminal["result_ref"],
        "telegram_surface_ref": surface,
    }
    return {
        "schema": DELIVERY_SCHEMA,
        "delivery_id": _opaque("stdelivery", _key(identity_key), identity),
        **identity,
        "delivery_status": "projection_ready",
        "delivery_attempt": 0,
        "execute_count": int(terminal["execute_count"]),
        "resource": KAKAO_OWNER,
        "kakao_transport_owner": KAKAO_OWNER,
        "gateway_package": WONMUX_GATEWAY,
        "no_send": True,
        "sent": False,
    }


def transition_delivery(delivery: Mapping[str, Any], event: str) -> dict[str, Any]:
    if frozenset(delivery) != DELIVERY_KEYS or delivery.get("schema") != DELIVERY_SCHEMA:
        raise ChatContractError("delivery projection schema mismatch")
    _owner_boundary(delivery)
    current = str(delivery.get("delivery_status") or "")
    transitions = {
        ("projection_ready", "delivered"): "delivered",
        ("projection_ready", "retry"): "retry",
        ("retry", "reconnect_replay"): "reconnect_replay",
        ("reconnect_replay", "delivered"): "delivered",
    }
    next_status = transitions.get((current, event))
    if not next_status:
        raise ChatContractError("invalid delivery transition")
    updated = deepcopy(dict(delivery))
    updated["delivery_status"] = next_status
    if event in {"delivered", "retry"}:
        updated["delivery_attempt"] = int(updated.get("delivery_attempt") or 0) + 1
    updated["no_send"] = True
    updated["sent"] = False
    return updated
