<!-- source: /root/my-first-project/CODEX_BRIEF.md -->
# CODEX_BRIEF.md

최신 핵심만 남기는 짧은 포인터 문서다. 긴 이력은 여기 두지 않는다.
Latest handoff only. Keep this file as a compact pointer; long history belongs in git history or topic docs.

작업 시작 전 `ABSOLUTE_RULES.md` 확인 필수: 기능 축소 금지, 검증+빌드+APK/센터 전달 완료, 위험 live action 금지, ChickenTimer 시간추가 공통 delta 규칙.

2026-07-31 KST persistent automation/WSL2:
- Main-approved program seed→immutable learning promotion→bounded worker envelope와 conflict-safe oldest-first cursor는 독립 P0/P1 없음/150 tests PASS. bundle `0731.0838-automation-persistent`, SHA `659c4af0...414b0`는 새 Hosting raw hash와 serverphone heartbeat가 exact match하고 dispatcher heartbeat/lease epoch 2가 fresh하다.
- StoreBotTermux 1075는 새 Hosting allowlist·command target version/SHA 검증을 포함해 공장 PC USB install 1회, PackageManager 1075, crash 0 PASS. program `program-c6ce44219a1677119af45bab`은 accepted receipt와 watch `automation-learning-watch-v1` 1건을 자동 생성했으며 기존 PosDelay worker가 끝날 때까지 충돌 없이 보류한다. factory runner는 dirty 10/update infeasible이므로 clean runner 채택→pending fixed model-0 `wsl2_preflight`→Order/SFA/메모리/재부팅 gate 순서다. 반복 PC AI 감사는 금지한다.

2026-07-30 KST ChickenTimer Note9 가로 시간추가 정렬 live:
- 기록된 CSS viewport로 Note9 `393×852`, Tab A 8.0 (2019) `800×1280`, 서브 노트북 `1085×1885`를 자동 분류하고 그 외 화면은 proportional fallback을 쓴다. 원거리 우선순위는 `청록 물 면적/높이 + 주황·빨강 전체 둘레 → 보호판 위 숫자`이며 지속 물 애니메이션은 없다.
- 실행 하단은 `삭제 · 추가 · -10 · -60`이다. Note9 가로의 plain running 화면은 좁은 세로 레일을 없애고 `+10 · +60`을 카운터 위 한 줄에 두며, split/add 화면은 기존 전용 배치를 유지한다. 하단 버튼은 고정 청록이 아닌 반투명 암회색이라 물이 있으면 실제 물색이 비치고 0이면 원래 어두운 바탕만 남는다.
- Board/legacy mirror/Android asset의 `index.html`·`style.css`가 동일하며 asset query는 실제 SHA-256 앞 12자리다. core/sync/smoke/wrapper와 Note9 집중 Playwright 2건 PASS; 전체 45건의 기능 판정은 42건 PASS이고 3건은 기존 시각 snapshot 기준선 차이로 남아 있다. 2026-07-30 17:40 KST `wk7007-ops-static-2026` Hosting에 timer 정적 자산만 배포했고 live `index=e21de963...`, `style=cd28230c...`, `app=5ba97c3a...`가 원본과 일치한다. 쓰기 차단 live Playwright 852×393에서 `+10/+60` 각각 약 57px, 같은 행·카운터 위·무클리핑, overflow 0, page error 0, `displayProfile=primary-phone`, `syncKey=main`을 확인했다. Android 앱은 이 Hosting을 원격 우선 로드하므로 온라인 UI 수정에는 APK 재설치가 필요 없지만 오프라인 fallback 동기화를 위해 `0730.1748` / `29756688` APK도 공개했다. update-center/Release/local SHA는 `0c31aa7d...abaf6e`, size `1425673`, PR #4 squash merge `b53e1c5`; Download는 `/sdcard/Download/ChickenTimer_20260730_1748.apk`. 물리 Note9 설치/회전 확인은 pending이다. 노트북은 19:37 KST factory PC Edge에서 정확한 `?profile=subnote`, title `Chicken Timer`, 6칸, overflow/error 0을 확인하고 성공 탭을 열어뒀다(request `timer_subnotebook_fix_verify_after_runner_20260730_1933`); 스크린샷 SHA `5004effc...e6a83`은 얻었으나 read-only sandbox `EPERM`으로 지속 가능한 파일 경로 저장만 PARTIAL이다.

2026-07-26 KST 모든 Codex 공용 하네스 재정립:
- SOT는 `rules/dispatcher_efficiency.txt`. hook은 lifecycle·고정 안전선·receipt만 맡고, 메모리 admission·리소스 배치·병렬·dedupe·토큰/속도는 dispatcher/broker가 맡는다.
- 새 세션 전용이 아니다. 어느 Codex가 요청을 받아도 완료에 필요한 capability를 먼저 만들고 `personal_main`, `factory_pc`, `serverphone`, 필요 시 `virtual oneoff`를 모두 역할별로 사용한다. 같은 일은 중복하지 않고, 충돌 없는 2개 lane씩 wave로 실행한다.
- 외부 dispatch 전 freshness/capability/locality/dirty-lock/queue age를 확인한다. capability mismatch 뒤 같은 요청을 반복하지 않고 안전한 local fallback을 먼저 쓰되 필요한 물리 검증은 다음 wave에서 생략하지 않는다.
- 이번 BankTotal 사례에서 factory PC ADB 0대인데 먼저 보낸 것은 비효율 사례다. 개인폰 read-only 분석은 정상 대체됐고, 실제 DB 적용·APK 설치는 물리 gate 전까지 보류한다.

2026-07-26 KST dynamic update center/SolNote/Browser:
- AppUpdateCenter `0725.1712`/`29749452`: native dynamic `/update-center/catalog.json`, exact-origin/64KB/schema guard, built-in fallback, 기기별 숨김·복원. remote 순서·설치 대상 우선과 client/server no-cache로 SolNote/Browser 및 새 버전을 즉시 보인다. live sha `be374829...db59826`. 이후 신규 앱은 `scripts/deploy_update_center_catalog.sh`로 APK 재빌드 없이 표시한다.
- SolNote `0725.1742`/`262061742`: 설치본 `0724.0143`/`262050143`보다 낮았던 이전 live code 회귀를 수정했다. 같은 정식 cert, live sha `20656d66...54882a1f`; 센터 업데이트 승인과 설치 후 PackageManager 재검증 pending.
- SolNote `com.wonmux.solnote.personal` `0725.0805`/`29748905`: delete + ACTION_SEND encrypted auto-save/dedupe, 성공·중복 noteId 즉시 열기, 실패 retry, 설치 version/package 표시. Python 45, JVM 137, Android compile, signed release PASS; live sha `1ad3b8de...20389a3`. 설치·실공유 물리 gate pending.
- Wonmux Browser `com.wonmux.browser` `0726.1257`/`26072612`: 별도 `:calendar_read` WebView data suffix에서만 exact Google Calendar/Accounts origin과 고정 BankTotal 정산 읽기 template을 허용한다. 일반 browser JavaScript OFF는 유지. JVM 20/static 6/lint/build, cloned-live preview와 live 4-file hash gate PASS; APK sha `5fdd4250...95093`, 개인폰 Download/설치 화면 전달 완료. 공장 signed-in Edge UIA live gate는 FAIL: 2026-07-30과 07-31 모두 170만원 각 1건이고 150만원은 0건, 모두 `종일 · BankTotal 정산`; Calendar write는 하지 않았다.
- Factory OpenClaw browser setup: `2026.7.1-2`, local loopback gateway `127.0.0.1:18789`, token auth, browser plugin, `edge-live` existing-session config까지 적용. Edge remote-debug consent가 UIA에 노출되지 않아 OpenClaw attach는 pending이나, 기존 Edge UIA로 실제 Calendar를 검증했다. Evidence: `C:\Users\wk700\AppData\Local\Temp\calendar_banktotal_verify_20260726\`.

2026-07-23 KST PosDelay AI Ops monitor repair:
- Cause: live `subphone_sbotux_ai_ops_monitor` was still running an older bundle and treated consumed `/posdelay/pc_macro/command` absence plus old `command_ack` as `consistency_missing`.
- Repair: StoreBot C&I bundle `0723.0818` / sha `60e7ff7001049237ca98691e7b3b587603fc68241f2fdf00f62bb74c2250a020` was adopted through `/subphone/cmd/storebot` request `posdelay_aiops_monitor_sync_1784781063505`; no Kakao send.
- Current PosDelay monitor: `pc_macro_command_ack` is `idle_no_command`, PosDelay severity is info-only (`metric_delta_candidate`), and app/mesh/PC macro heartbeats are fresh.

2026-07-21 KST CoreOps AI Ops queue scoping:
- `scripts/ai_ops_common_monitor.py` CoreOps `codex_ops_requests` check는 서버폰 worker가 실제 claim할 수 있는 요청만 집계한다. `target_host=pc`, `target_node=pc_codex_resource_01` 같은 PC 전용 backlog는 서버폰 worker stale/error self_fix 근거가 아니다.
- 계약 포인터: `rules/ai_ops_prompt_contract.txt`, `CODEMAP.txt`.
- 2026-07-23 KST live repair: StoreBot Codex worker bundle deployed to Hosting and adopted by the serverphone worker; exact version/sha SOT is `AttendanceBoard/docs/storebot-codex/bundle.json`. Fix covers resident `resident_response_health_empty_final` as retryable runtime/self_fix signal and delta-only reply recovery. No Kakao send was performed.

2026-07-25 KST serverphone execution recovery:
- PASS: Codex `0.145.0`, policy `minimal-managed-hooks-v2.1`, one controlled worker restart, fresh-session harmless receipts 4/4 and `HOOK_FRESH_PROBE_PASS`.
- Packet `0_145_0_hook_receipt_success_v2_1_3` sha `a042fed2caa1930fead45ab02157ce7e51e55aa50365414db2c68a29ce81e22f`; auth/app install/StoreBot/Kakao/CA/business DB mutations 0. Product lanes now continue with SolNote delete/share auto-save and Wonmux Browser safe user-driven automation.

2026-07-14 KST managed hook P0:
- P0-1~P0-8 PASS: fresh App Server/process sees exactly four managed lifecycle/safety hooks and zero user/project/plugin hooks; harmless shell/bootstrap works and an authorized disposable `rm -rf` probe is denied before execution.
- Source/install: `scripts/codex_hooks/minimal_managed_lifecycle.py` -> `/etc/codex/managed-hooks/minimal_managed_lifecycle.py`; rollback snapshot `/root/.codex/hook-recovery/snapshots/20260714T041404+0900/`.
- Model naming: ChatGPT 표시명은 정확히 `GPT-5.6 Sol/Terra/Luna`, Codex CLI는 runner가 지원하는 실제 model id다. Main chooses external worker model/range; dispatcher/broker validates `--model`, `model_decision_by=main`, packet scope, evidence, and routing. SOT: `AGENTS.md`, `rules/workflow.txt`.
- ChatGPT-max group gate: nontrivial work requires actual ChatGPT question/counterargument -> revision -> post-diff acceptance receipts; synthetic `ChatGPT perspective` is not evidence. High-risk work blocks without a receipt; usage is metered, so check official rate-limit/usage and split packets without silent main-model downgrade. SOT: `AGENTS.md`, `rules/workflow.txt`.

2026-07-10 KST StoreBotTermux thin bridge / CLI direct live gate:
- PASS steady-state: explicit local-direct action fast lane is live through serverphone worker, not PC USB ADB runner.
- Live bundle `0710.1031-explicit-lane`, sha `f3015860dee1ef26172d50fa8c2878ce5c80483fbd94986c03b5c4910dabf1be`; Hosting live `bundle.json` returned same version/sha and zip HEAD was HTTP 200.
- Serverphone heartbeat after sync `storebot_sync_worker_bundle_1783647512954_1394fbe2`: same version/sha, `bundle_status=native_sync`, `local_direct_listening=true`, `resident_app_server_active=true`.

2026-07-10 KST factory/main-PC role boundary:
- Main POS PC is business runtime only, not a Codex/repo/build resource. Game-phone repos are canonical source plus dispatcher; factory PC is the code/build/browser lane and serverphone is Android/Kakao live read-only.
- Factory normal entry is factory-local launcher handshake -> `scripts/direct_factory_entry.py` -> direct session/launcher. Missing/stale/mismatched evidence is `no_direct_session`; Firebase queue/heartbeat is explicit bypass/audit/fallback only, never liveness/update/adoption proof. Do not overwrite the existing dirty checkout. DeliveryHelper requires local remote/revision probe and a separate clean factory workspace before code work.
- Fast lane: `/packhelper/storebot_codex/explicit_pending/{requestId}` is processed before schedule/broadcast/full `/requests` scan; old `/requests` explicit action path remains compatible.
- Steady-state proofs: `storebot_ld_fast_outer_1783647620002_b` pickup `3991ms`, inner `3493ms`, total `11127ms`; `storebot_ld_fast_outer_1783647660003_c` pickup `7991ms`, inner `3202ms`, total `14773ms`; no outbound matches. First post-sync probe had pickup `34917ms`, classified as restart/poll gap.

2026-07-07 KST 기록/보고 계약 보강:
- 진행/완료 보고는 사용 리소스, MCP 사용 여부, 모델명, 모델 선택 사유, 검증 증거, 커밋/푸시 해시를 포함한다. 모델 선택 사유는 빠른/중간/강한 모델 구분, 비용/속도, live ops/ADB/Firebase/DB migration 위험 여부를 적는다.
- 가상 worker 결과와 물리 공장/서버폰 실행 증거를 구분한다. Android 앱은 빌드만으로 완료가 아니며 APK 센터 또는 다운로드 복사, size/hash, 열기 또는 접근 확인까지 본다. 버그 수정은 기능 축소가 아니라 안정화로 해결한다.

2026-07-07 KST OrderHelper SFA 매칭 패널 완료 포인터:
- OrderHelper commit `3d600a8 Add OrderHelper SFA item matching panel`, root pointer commit `759a867 Update OrderHelper matching pointer`.
- 본 페이지/SFA 비교 패널은 `1:1 매칭`, `단위 보정`, `미매칭`, `입출력`을 제공하고, SFA 원천 행은 보존한 채 `orderSiteMappings`/`orderUnitCorrections`를 localStorage와 Firebase `/order/desk_q7m9r3a8/current`, `/history/{date}` payload에 분리 저장한다.
- 검증: `node tests/orderhelper_static_checks.js`, `git diff --check`. 제한: 실제 공장 PC 브라우저/SiteBot 화면 검증은 아직 미수행.
- 2026-07-09 side note: SFA/Excel analysis cumulative localStorage history was patched locally in `/root/OrderHelper` (`index.html`, `tests/orderhelper_static_checks.js`, `APP_INTENT.md`, `CODEMAP.txt`), key `bbq_sfa_analysis_history` with `records[]`; static checks PASS, no live deploy/browser verification.

2026-07-27 KST ChickenTimer 가로 한 줄 레이아웃 배포:
- 가로 화면을 물리 순서 `1·2·3 | 4·5 | OV` 한 줄로 바꾸고 구역명을 세로 라벨로 표시했다. 구역 비율 `3.3:2.3:1.3`으로 헤더를 제외한 6개 카드 폭을 맞췄고, 가로 시작 숫자판은 2열, 진행 중 조절은 숫자 위아래, 폰 세로 숫자판은 3열이다.
- 원본/Hosting/Android asset의 `index.html`과 `style.css` 해시 일치. Node core/smoke, Playwright 28/28, Android `testDebugUnitTest`(NO-SOURCE)+`assembleDebug` PASS. live 폰 852x393/태블릿 1280x800에서 한 줄·세로 라벨·카드 동일 높이·버튼 무잘림 확인.
- update-center `0727.2244` / `29752664`, APK size `1390453`, sha256 `69002b8103d22aab012c65c0ee509f9c2df6ab715d38f6a53218f703bdea58dd`. `/sdcard/Download/ChickenTimer_20260727_2244.apk` 복사 완료, proot 권한으로 설치 화면 자동 열기는 실패해 사용자 수동 선택이 남는다.

2026-07-08 KST ChickenTimer 시간추가 안정화 배포:
- 원인: 활성 슬롯의 시간추가 입력이 `ChickenTimerBoard/app.js startMainTimer()`로 들어가면 `splitStore.clearSlot()` 뒤 `timer-core.js start()`가 새 타이머 값을 써서 기존 `durationSeconds/remainingSeconds/endAt/lastCompleted`를 리셋했다.
- 수정: UI/이동/완료표시/소리/split UX는 유지하고, `timer-core.js`에 공통 `addTime(slotId, deltaMs)` + 내부 `applyTimeDeltaMs`를 추가했다. `adjust()`도 같은 helper를 쓰며 running은 기존 `endAt`에 delta를 더하고 paused는 `remainingSeconds`만 늘린다. empty/completed의 명시 시작 UX는 유지.
- 검증/배포: `npm run test:core`, `npm run test:smoke`, `npm run test:web` 26 passed, `ChickenTimerApp ./gradlew test`, `./gradlew assembleDebug`, `ChickenTimerApp/deploy_auto_update.sh`. update-center `0708.0223` / `29724083`, APK size `1390253`, sha256 `0c4cce3d797096d6cf47d48740b7ce915d4d3e75f97bddcefdc62396a7fb8eb1`, `/sdcard/Download/ChickenTimer_20260708_0223.apk`.

2026-07-07 KST operation knowledge async/no-bottleneck automation:
- `scripts/operation_knowledge_adapter.py ingest` now prepares raw item + `/packhelper/ops_knowledge/audit` + `/packhelper/ops_knowledge/queue/{job_id}` and returns immediate ack; no summary generation is required on the input path.
- Background processing is `process-job`/`process-queue` and StoreBot actions `operation_knowledge.process_job/process_queue`; done jobs write structured summary/output variants, failed jobs leave raw input persisted and retryable/failed queue state.
- Hynix 운영메뉴얼 compact panel shows “반영됨/정리 중/확인 필요” queue status inside the panel. Hidden/held/output_disabled rows are excluded from output; restore makes them active again. Kakao send remains guarded/no-send by default; no production DB sample write or live Kakao send was used for verification.

2026-07-07 KST operation knowledge write/send opened with guards:
- `scripts/operation_knowledge_adapter.py` is now write-enabled: raw input ingest, structured summary upsert, output variant upsert, delete request, soft delete/restore, hard-delete confirm guard, audit record, payload/file backend CLI. 입력은 DB 반영이다.
- Hynix 운영메뉴얼 compact panel now allows authenticated raw input, summary save, output save, delete request, soft delete, and restore against `/packhelper/ops_knowledge/**`; read-only users see disabled controls. Static asset `https://poskds-attendance.web.app/hynix/knowledge_adapter_contract.json` mode is `write_enabled`.
- StoreBot Codex live bundle baseline is `0710.0921-explicit-fastpath` sha `4a0f69e01a2d5d3b73c6705f1e209885b065054ed098543454e239ab1987c250`; serverphone heartbeat after sync is `bundle_status=native_sync`, `local_direct_listening=true`, `resident_app_server_active=true`.
- StoreBot worker supports `operation_knowledge.ingest/upsert_summary/render_output/request_delete/delete/restore/send_reply`. Kakao output is functionally open only by explicit action + room guard + `kakao_send_enabled`; default verification path is no-send/mock. Worker bundle `0707.1740-op-knowledge-write` sha `eaef853eff0626dc14c0d5bd5c8780417edd8f432852363d764596413f73b5b4` is live at Hosting. 근무표 canonical remains `/workschedule_v2`; summary-as-schedule-source remains false.

2026-07-07 KST NotebookLM/MCP site principle correction:
- NotebookLM식 도입 의도는 단순 출력 UX가 아니라 카톡/사이트/운영메모/규칙/변경요청을 원문+출처와 함께 보존하고 요약/정리/분류해 내부 DB화한 뒤 직원용/관리자용/검색형/카톡형/사이트형 출력으로 다양화하는 사이트 전체 원칙이다.
- 근무표 자체는 정형 업무 데이터이므로 전면 도입하지 않는다. `/workschedule_v2` canonical schedule DB를 직접 출력/수정하고, 자연어 입력의 정형 command 변환, 변경요청/감사로그/운영메모 설명, 과거 기록/인건비 분석 해설에만 보조 적용한다.
- MCP는 이 흐름의 도구 호출/연결층이다. write/delete는 인증/감사/명시 승인/권한별 분리 뒤에만 열며, hard delete/no-auth mass send는 금지한다.
- 이전 read-only preview 상태는 `write_enabled` contract로 승격됐다. Firebase 운영 샘플 write와 실제 Kakao send 검증은 수행하지 않는다.

2026-07-07 KST StoreBotTermux 근무표 이미지 24h 그라데이션/운영일 기준 배포:
- Root worker: 근무표 이미지 날짜 산정은 06:00 KST 운영일 기준으로 변경. 06:00 전 `start_offset_days=0`은 전날 운영일에서 시작한다. Worker bundle `0707.0532-schedule-gradient` sha `ffc45159...`는 Hosting public `storebot-codex/bundle.json` 대조 완료.
- StoreBotTermux app: schedule PNG 타임라인은 하이닉스 날짜별과 같은 24시간 고정 그라데이션 + `00/06/12/17/24` 눈금. 야간 교차 근무는 같은 단일 PNG 안에서 22~24/00~10처럼 분할 표시한다. Update-channel `.59/1064` sha `4885e1bf...`는 Hosting public `storebot-termux/version.json`/latest bin 대조 완료.
- 숫자 가독성: 사용자 피드백 `게이지 숫자가 뭉개지는거같은데` 반영. Hynix site/StoreBotTermux PNG 모두 눈금 숫자를 굵은 밝은 라벨/테두리로 분리하고 `어두움/밝음/저녁` 프론트 노출 금지는 유지.
- 적용: factory PC USB ADB에서 `R39M30RWR2F device`/`SM_G975N` 확인 후 `install -r` 성공, dumpsys `versionName=0.118.3-storebot.59`, `versionCode=1064`, `lastUpdateTime=2026-07-07 06:12:11` 확인. Kakao live send/강제 이미지 트리거/Firebase DB state 보정은 하지 않음.

2026-07-06 KST StoreBotTermux 근무표 broadcast 재발 방지 code-ready:
- Root worker: image-required broadcast는 이미지 성공 증거 없이 `sent`/`last_sent_schedule_hash`로 승격하지 않고 `image_capture_or_generation_pending` retry로 남긴다. `fallback_policy=explicit_text_mode`일 때만 text-only 성공 허용. `next_due_at_ms`는 성공 시 `last_sent+21600000`, 실패 시 짧은 retry다. 07/21 fixed `schedule_fixed_briefing` 생성은 제거 상태 유지, 새 자동 요청명은 `sched_work_schedule_broadcast_auto_*`.
- StoreBotTermux app: pending queue broadcast ack는 `image_sent/image_send_status/attachment_uri_status` 증거가 있을 때만 state `sent`를 patch하고, `interval_ms` 1000배 입력은 6h ms로 정규화한다. 실패/skip은 `image_capture_or_generation_pending` + 5m retry. Worker bundle `0706.2220` sha `adcf8461...`와 StoreBotTermux update-channel `.57/1062` sha `6668a897...`는 Hosting 배포 완료. 서버폰 채택, live state 보정, 카카오 실발송 검증은 별도 live lane.

2026-07-05 KST latest ops snapshot:
- WorkSchedule 공식 repo `/root/WorkSchedule`: 최신 기준 `ae373b2`. UI grep 기준/브리핑/운영메뉴얼/근무수정/카톡 이미지 확인 UI OK. 공장 PC detached root `origin/master` `0228165`에서 일반 PowerShell `scripts\verify_workschedule_site.ps1` 실브라우저 검증 완료: `workschedule_verify ok missing=0`, readonly/briefing/manual/work_edit/date/employee/start/end/role/save_dry_run_only/Firebase non-GET write guard 모두 pass. Result `C:\Users\wk700\AppData\Local\Temp\pw-artifacts-codex\workschedule_site_verify_20260705_001326_1b7acd3a\result.json`, screenshot `C:\Users\wk700\AppData\Local\Temp\pw-artifacts-codex\workschedule_site_verify_20260705_001326_1b7acd3a\workschedule.png`.
- StoreBot/근무표: root `174eccb`가 `/workschedule_v2` 기반 6시간 자동발송 + 5분 debounce 상태머신과 override 우선 병합을 추가했고, `a61ce26` broadcast ack meta는 `origin/master`에 포함. live state `/packhelper/storebot_termux/work_schedule_broadcast_state` 생성 확인(`interval_ms=21600000`, `debounce_ms=300000`, `dry_run=true`, `publish_gate=false`, `source_path=/workschedule_v2`, `status=idle`). 실제 카톡 발송은 금지/미실행. `/root/StoreBotTermux` 로컬 HEAD `56217a1`은 ack 보강 patch 내용과 동일해 별도 patch 산출물은 포인터로 쓰지 않는다. StoreBotTermux-fresh origin은 upstream `https://github.com/termux/termux-app.git`, ahead 66; fork `https://github.com/wk7007-wk/termux-app.git` 부재로 remote 추가/원격 반영 보류.
- ChickenTimer: update-center `0727.2244` / `29752664` 배포 완료. Public `version.json`, `ChickenTimer_latest.bin`, `index.html`, `style.css` 확인됨(size `1390453`, sha256 `69002b8103d22aab012c65c0ee509f9c2df6ab715d38f6a53218f703bdea58dd`). `/sdcard/Download/ChickenTimer_20260727_2244.apk` 전달 완료, 설치 화면 자동 열기는 proot 권한 제한으로 미완료.
- PosDelay: read-only 점검은 완료. live 정상 판정/수정은 별도 lane.
- factory PC worker: alive/idle이나 heartbeat `code_revision=620a4a5`로 stale; 최신 root commits와 동기화 필요.
- MCP/NotebookLM 설계: 자체 MCP 규격을 만들지 않고 공식 MCP `tools`/`resources`/`prompts` 위에 내부 DB adapter/server를 둔다. NotebookLM식 흐름은 입력 원문/출처 보존, 요약/분류 DB화, 다양한 출력 파생을 위한 사이트 전체 원칙이며 SOT/원천 DB/실행 엔진이 아니다. StoreBot hot path 대체 금지, read-only 도구층 먼저.

2026-07-04 KST 추가 요청 분류/지속관리 계약 보강. 기준은 `AGENTS.md` Goal-mode/dispatcher, 템플릿은 `rules/progress_update_template.txt`와 `rules/worker_delegation_prompt_template.txt`, 강제 검사는 `scripts/check_progress_contract.py --require-plan`을 본다.

2026-07-05 KST WorkSchedule site verification complete: factory PC 일반 PowerShell 실브라우저 검증 `workschedule_verify ok missing=0`; `readonly_banner=true`, `briefing_visible=true`, `manual_visible=true`, `work_edit_visible=true`, 근무수정 입력/date/employee/start/end/role 확인, `save_dry_run_only=true`, `firebase_non_get_write=[]`, `missing=[]`.

2026-07-04 KST factory PC MCP inventory final verification. Resource: `factory_pc:pc_codex_resource_01 via pc_codex_cli`. Final pushed docs are based on factory-PC runtime/config inspection and WorkSchedule Playwright smoke. Installed: `playwright`, repo-scoped `filesystem`, `firebase`, bundled `node_repl`. Installable: `git`, `fetch`. Pending auth: `github`. Pending choice: `search`, `IBM/ContextForge/watsonx`, `PlayMCP/Kakao`, `regulation/public data`, `news/weather/calendar`. Original factory checkout had preexisting dirty/unresolved MCP files and unrelated StoreBotTermux update-channel edits; those were preserved, and the final commit was produced from a clean factory-PC worktree based on `origin/master`.

2026-07-04 KST factory PC MCP inventory/installer lane 시작. 공장 PC 전용 browser/Playwright 검증과 무거운 MCP 후보 설치를 분리하기 위해 `config/factory_pc_mcp_inventory.json`, `MCP_FACTORY_PC_INVENTORY.md`, `scripts/bootstrap_factory_mcp.ps1`를 추가했다. 상태 분류는 `installed`, `installable`, `pending_auth`, `pending_choice`, `missing`이며, Playwright/browser smoke는 factory PC lane 전용이다. 실제 factory PC 설치/검증 결과는 queued worker proof 뒤에만 `installed`로 올린다.

## SOT
- `AGENTS.md`: 장기 협업/배포/역할 분담 SOT
- `rules/workflow.txt`: 절차 SOT
- `CODEMAP.txt`: 문서/스크립트 지도

## current pointers
- active lanes:
  - StoreBot/WorkSchedule broadcast state: `scripts/storebot_codex_worker.py`, `/workschedule_v2`, `/packhelper/storebot_termux/work_schedule_broadcast_state`
  - PosDelay live 판정/수정: read-only 점검 후 별도 lane
- verified:
  - ChickenTimer update-center: `https://poskds-attendance.web.app/chicken-timer/version.json` and `ChickenTimer_latest.bin`
  - WorkSchedule general PowerShell Playwright smoke: result `C:\Users\wk700\AppData\Local\Temp\pw-artifacts-codex\workschedule_site_verify_20260705_001326_1b7acd3a\result.json`
- factory PC only:
  - stale worker sync from `620a4a5` to latest root commits
- StoreBotTermux:
  - `StoreBotTermux-fresh` origin is upstream termux-app and ahead 66; fork remote is absent, so remote apply remains deferred
  - `/root/StoreBotTermux` local HEAD `56217a1` already contains the ack state update; no separate patch pointer remains
  - live Kakao send remains blocked; broadcast state is dry-run gated

## 읽는 순서
1. `AGENTS.md`
2. `CODEX_BRIEF.md`
3. `CODEMAP.txt`
4. `AI_HANDOFF.md`
5. 대상 프로젝트 `APP_INTENT.md` / `CODEMAP.txt`

## 다음 포인터
- 현재 작업판: `AI_HANDOFF.md`
- 문서 구조 기준: `MD_STRUCTURE_AUDIT.md`
- 진행보고/worker prompt 계약(요청분류/지속관리 추적 포함): `rules/progress_update_template.txt`, `rules/worker_delegation_prompt_template.txt`
