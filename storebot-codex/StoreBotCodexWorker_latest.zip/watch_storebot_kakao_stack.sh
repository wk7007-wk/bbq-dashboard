#!/system/bin/sh
set -eu

SCRIPT_PATH="$0"
case "$SCRIPT_PATH" in
  */*)
    ;;
  *)
    SCRIPT_PATH="$(command -v "$SCRIPT_PATH" 2>/dev/null || printf '%s\n' "$SCRIPT_PATH")"
    ;;
esac
SCRIPT_DIR="$(cd "$(dirname "$SCRIPT_PATH")" && pwd)"
ROOT_DIR="$(cd "$SCRIPT_DIR/.." && pwd)"

ADB_BIN="${ADB_BIN:-adb}"
ADB_STATE_FILE="${STOREBOT_KAKAO_STACK_ADB_STATE_FILE:-$SCRIPT_DIR/adb_wireless_state.json}"
COOLDOWN_SEC="${STOREBOT_KAKAO_STACK_COOLDOWN_SEC:-300}"
FORWARD_PORT="${STOREBOT_KAKAO_STACK_FORWARD_PORT:-18765}"
HEALTH_TIMEOUT_SEC="${STOREBOT_KAKAO_STACK_HEALTH_TIMEOUT_SEC:-5}"
RESTART_SCRIPT="${STOREBOT_KAKAO_STACK_RESTART_SCRIPT:-/sdcard/Download/storebot_codex_worker/restart_storebot_codex_worker.sh}"
LOCAL_RESTART_SCRIPT="${STOREBOT_KAKAO_STACK_LOCAL_RESTART_SCRIPT:-$SCRIPT_DIR/restart_storebot_codex_worker.sh}"
MODE="once"
DRY_RUN=0
RUN_MODE="${STOREBOT_KAKAO_STACK_RUN_MODE:-adb}"
ADB_TARGET=""
FORWARD_SET=0

export PATH="${PATH:-}:/system/bin:/system/xbin"

DEFAULT_STATE_DIR="${HOME:-/tmp}/.cache/storebot_kakao_stack"
STATE_DIR="${STOREBOT_KAKAO_STACK_STATE_DIR:-$DEFAULT_STATE_DIR}"
if ! mkdir -p "$STATE_DIR" 2>/dev/null; then
  STATE_DIR="${TMPDIR:-/tmp}/storebot_kakao_stack"
  mkdir -p "$STATE_DIR"
fi
LOCK_DIR="${STOREBOT_KAKAO_STACK_LOCK_DIR:-$STATE_DIR/watch.lock}"
LAST_RECOVERY_FILE="${STOREBOT_KAKAO_STACK_LAST_RECOVERY_FILE:-$STATE_DIR/last_recovery_epoch}"

usage() {
  cat <<'EOF'
Usage: watch_storebot_kakao_stack.sh [--status|--once] [--adb|--local] [--dry-run]

Tasker/server-phone upper watchdog for the StoreBot Kakao stack.
It only checks status, wakes packages, and restarts/repairs the local worker.
It never injects Kakao messages, publishes replies, or calls manual reply tools.

Options:
  --adb      Run from a controller/PC/Wonmux through adb. This is the default.
  --local    Run inside server-phone Termux/Tasker without adb.
  --status   Print package/worker/local-direct status only.
  --once     Check once and recover if needed. This is the default.
  --dry-run  Print recovery commands without executing them.
  --help     Show this help.
EOF
}

while [ "$#" -gt 0 ]; do
  case "$1" in
    --status)
      MODE="status"
      ;;
    --once)
      MODE="once"
      ;;
    --dry-run)
      DRY_RUN=1
      ;;
    --local)
      RUN_MODE="local"
      ;;
    --adb)
      RUN_MODE="adb"
      ;;
    --help|-h)
      usage
      exit 0
      ;;
    *)
      echo "unknown argument: $1" >&2
      usage >&2
      exit 2
      ;;
  esac
  shift
done

case "$RUN_MODE" in
  adb|local)
    ;;
  *)
    echo "invalid run mode: $RUN_MODE" >&2
    usage >&2
    exit 2
    ;;
esac

timestamp() {
  TZ=Asia/Seoul date +"%Y-%m-%d %H:%M:%S KST" 2>/dev/null || date +"%Y-%m-%d %H:%M:%S"
}

log() {
  printf '[%s] %s\n' "$(timestamp)" "$*"
}

pid_alive() {
  local pid="$1"
  [ -n "$pid" ] && kill -0 "$pid" 2>/dev/null
}

acquire_lock() {
  if mkdir "$LOCK_DIR" 2>/dev/null; then
    echo "$$" > "$LOCK_DIR/pid"
    return 0
  fi
  local old_pid
  old_pid="$(cat "$LOCK_DIR/pid" 2>/dev/null || true)"
  if pid_alive "$old_pid"; then
    log "another watchdog run is active pid=$old_pid"
    exit 0
  fi
  rm -rf "$LOCK_DIR"
  mkdir "$LOCK_DIR"
  echo "$$" > "$LOCK_DIR/pid"
}

cleanup() {
  if [ "$RUN_MODE" = "adb" ] && [ "$FORWARD_SET" = "1" ] && command -v "$ADB_BIN" >/dev/null 2>&1 && [ -n "$ADB_TARGET" ]; then
    "$ADB_BIN" -s "$ADB_TARGET" forward --remove "tcp:$FORWARD_PORT" >/dev/null 2>&1 || true
  fi
  rm -rf "$LOCK_DIR" 2>/dev/null || true
}

acquire_lock
trap cleanup EXIT INT TERM

require_adb() {
  if ! command -v "$ADB_BIN" >/dev/null 2>&1; then
    log "adb not found: $ADB_BIN"
    exit 1
  fi
}

connected_devices() {
  "$ADB_BIN" devices 2>/dev/null | awk 'NR > 1 && $2 == "device" {print $1}'
}

state_serial() {
  [ -r "$ADB_STATE_FILE" ] || return 1
  if command -v python3 >/dev/null 2>&1; then
    python3 - "$ADB_STATE_FILE" <<'PY' 2>/dev/null || true
import json
import sys
from pathlib import Path

try:
    data = json.loads(Path(sys.argv[1]).read_text(encoding="utf-8"))
except Exception:
    data = {}
if isinstance(data, dict):
    for key in ("serial", "endpoint"):
        value = str(data.get(key) or "").strip()
        if value:
            print(value)
            raise SystemExit
    host = str(data.get("host") or "").strip()
    port = str(data.get("port") or "").strip()
    if host and port:
        print(f"{host}:{port}")
PY
    return 0
  fi
  sed -n 's/.*"endpoint"[[:space:]]*:[[:space:]]*"\([^"]*\)".*/\1/p' "$ADB_STATE_FILE" | head -n 1
}

resolve_adb_target() {
  local env_serial="${ADB_SERIAL:-}"
  if [ -n "$env_serial" ]; then
    printf '%s\n' "$env_serial"
    return 0
  fi

  local state_target devices count
  state_target="$(state_serial | head -n 1 || true)"
  devices="$(connected_devices || true)"
  if [ -n "$state_target" ] && printf '%s\n' "$devices" | grep -Fxq "$state_target"; then
    printf '%s\n' "$state_target"
    return 0
  fi
  count="$(printf '%s\n' "$devices" | sed '/^$/d' | wc -l | tr -d ' ')"
  if [ "$count" = "1" ]; then
    printf '%s\n' "$devices" | sed '/^$/d' | head -n 1
    return 0
  fi
  if [ -n "$state_target" ]; then
    printf '%s\n' "$state_target"
    return 0
  fi
  return 1
}

adb_cmd() {
  "$ADB_BIN" -s "$ADB_TARGET" "$@"
}

adb_shell_capture() {
  local command="$1"
  local output
  set +e
  output="$(adb_cmd shell "$command" 2>/dev/null)"
  local code=$?
  set -e
  printf '%s' "$output" | tr -d '\r'
  return "$code"
}

local_shell_capture() {
  local command="$1"
  local output
  set +e
  output="$(sh -c "$command" 2>/dev/null)"
  local code=$?
  set -e
  printf '%s' "$output" | tr -d '\r'
  return "$code"
}

shell_capture() {
  if [ "$RUN_MODE" = "local" ]; then
    local_shell_capture "$1"
  else
    adb_shell_capture "$1"
  fi
}

local_command_exists() {
  local cmd="$1"
  command -v "$cmd" >/dev/null 2>&1
}

check_local_environment() {
  local missing=""
  if ! local_command_exists pm && ! local_command_exists cmd; then
    missing="${missing} pm/cmd"
  fi
  for tool in pidof am; do
    if ! local_command_exists "$tool"; then
      missing="${missing} $tool"
    fi
  done
  if [ -n "$missing" ]; then
    log "local mode warning: Android command(s) missing:${missing}; run this on server-phone Termux/Tasker, not inside proot/PC"
  fi
  if ! local_command_exists curl && ! local_command_exists toybox && ! local_command_exists nc && ! local_command_exists python3; then
    log "local mode warning: curl/toybox nc/python3 missing; local-direct health may be unknown"
  fi
  if [ ! -r "$LOCAL_RESTART_SCRIPT" ]; then
    log "local mode note: worker restart disabled because $LOCAL_RESTART_SCRIPT is not readable; package wake only"
  elif [ ! -x "$LOCAL_RESTART_SCRIPT" ]; then
    log "local mode note: worker restart will use sh ./$(basename "$LOCAL_RESTART_SCRIPT") because $LOCAL_RESTART_SCRIPT is not executable"
  fi
}

target_connected() {
  [ -n "$ADB_TARGET" ] || return 1
  adb_cmd get-state >/dev/null 2>&1
}

ensure_target_connected() {
  if target_connected; then
    return 0
  fi
  case "$ADB_TARGET" in
    *:*)
      if [ "$MODE" = "once" ] && [ "$DRY_RUN" = "0" ]; then
        log "adb target not connected; trying adb connect $ADB_TARGET"
        "$ADB_BIN" connect "$ADB_TARGET" >/dev/null 2>&1 || true
      fi
      ;;
  esac
  target_connected
}

pkg_installed() {
  local pkg="$1"
  local out
  out="$(shell_capture "cmd package path $pkg 2>/dev/null || pm path $pkg 2>/dev/null || true")"
  [ -n "$out" ]
}

pkg_pids() {
  local pkg="$1"
  local out
  out="$(shell_capture "pidof $pkg 2>/dev/null || true")"
  if [ -n "$out" ]; then
    printf '%s\n' "$out"
    return 0
  fi
  shell_capture "(ps -A -o PID,ARGS 2>/dev/null || ps -A 2>/dev/null || ps 2>/dev/null) | grep -F '$pkg' | grep -v grep | awk '{print \$1}' || true"
}

pkg_running() {
  local pkg="$1"
  local pids
  pids="$(pkg_pids "$pkg" | tr '\n' ' ' | sed 's/[[:space:]]*$//')"
  [ -n "$pids" ]
}

print_pkg_status() {
  local pkg="$1"
  local label="$2"
  local installed="no"
  local running="no"
  local pids="-"
  if pkg_installed "$pkg"; then
    installed="yes"
    pids="$(pkg_pids "$pkg" | tr '\n' ' ' | sed 's/[[:space:]]*$//')"
    if [ -n "$pids" ]; then
      running="yes"
    else
      pids="-"
    fi
  fi
  printf 'package %-22s pkg=%s installed=%s running=%s pid=%s\n' "$label" "$pkg" "$installed" "$running" "$pids"
}

worker_process_status() {
  local out
  out="$(shell_capture "(ps -A -o PID,ARGS 2>/dev/null || ps -ef 2>/dev/null || ps 2>/dev/null) | grep -F 'storebot_codex_worker.py' | grep -F -- '--watch' | grep -v grep || true")"
  if [ -n "$out" ]; then
    printf '%s\n' "$out"
    return 0
  fi
  return 1
}

read_local_direct_health_adb() {
  adb_cmd forward --remove "tcp:$FORWARD_PORT" >/dev/null 2>&1 || true
  if ! adb_cmd forward "tcp:$FORWARD_PORT" "tcp:8765" >/dev/null 2>&1; then
    return 2
  fi
  FORWARD_SET=1
  if command -v python3 >/dev/null 2>&1; then
    python3 - "http://127.0.0.1:$FORWARD_PORT/storebot/health" "$HEALTH_TIMEOUT_SEC" <<'PY' 2>/dev/null
import sys
import urllib.request

url = sys.argv[1]
timeout = float(sys.argv[2])
with urllib.request.urlopen(url, timeout=timeout) as response:
    body = response.read(1000).decode("utf-8", errors="replace")
    print(body)
    raise SystemExit(0 if response.status == 200 else 1)
PY
    return $?
  fi
  if command -v curl >/dev/null 2>&1; then
    curl -fsS --max-time "$HEALTH_TIMEOUT_SEC" "http://127.0.0.1:$FORWARD_PORT/storebot/health"
    return $?
  fi
  return 2
}

read_local_direct_health_local() {
  local url="http://127.0.0.1:8765/storebot/health"
  if command -v curl >/dev/null 2>&1; then
    curl -fsS --max-time "$HEALTH_TIMEOUT_SEC" "$url"
    return $?
  fi
  if command -v toybox >/dev/null 2>&1; then
    read_local_direct_health_nc toybox
    return $?
  fi
  if command -v nc >/dev/null 2>&1; then
    read_local_direct_health_nc nc
    return $?
  fi
  if command -v python3 >/dev/null 2>&1; then
    python3 - "$url" "$HEALTH_TIMEOUT_SEC" <<'PY' 2>/dev/null
import sys
import urllib.request

url = sys.argv[1]
timeout = float(sys.argv[2])
with urllib.request.urlopen(url, timeout=timeout) as response:
    body = response.read(1000).decode("utf-8", errors="replace")
    print(body)
    raise SystemExit(0 if response.status == 200 else 1)
PY
    return $?
  fi
  printf 'local health check unavailable: curl/python3 not found\n'
  return 2
}

read_local_direct_health_nc() {
  local tool="$1"
  local response_file="$STATE_DIR/local_direct_health.$$"
  local status_line
  rm -f "$response_file" 2>/dev/null || true
  set +e
  if command -v timeout >/dev/null 2>&1; then
    if [ "$tool" = "toybox" ]; then
      printf 'GET /storebot/health HTTP/1.0\r\nHost: 127.0.0.1\r\nConnection: close\r\n\r\n' | timeout "$HEALTH_TIMEOUT_SEC" toybox nc 127.0.0.1 8765 > "$response_file" 2>/dev/null
    else
      printf 'GET /storebot/health HTTP/1.0\r\nHost: 127.0.0.1\r\nConnection: close\r\n\r\n' | timeout "$HEALTH_TIMEOUT_SEC" nc 127.0.0.1 8765 > "$response_file" 2>/dev/null
    fi
  elif [ "$tool" = "toybox" ]; then
    printf 'GET /storebot/health HTTP/1.0\r\nHost: 127.0.0.1\r\nConnection: close\r\n\r\n' | toybox nc 127.0.0.1 8765 > "$response_file" 2>/dev/null
  else
    printf 'GET /storebot/health HTTP/1.0\r\nHost: 127.0.0.1\r\nConnection: close\r\n\r\n' | nc 127.0.0.1 8765 > "$response_file" 2>/dev/null
  fi
  local code=$?
  set -e
  if [ "$code" -ne 0 ]; then
    rm -f "$response_file" 2>/dev/null || true
    return "$code"
  fi
  status_line="$(head -n 1 "$response_file" 2>/dev/null | tr -d '\r')"
  tr -d '\r' < "$response_file" | awk 'body {print} /^$/ {body=1}' 2>/dev/null || true
  rm -f "$response_file" 2>/dev/null || true
  case "$status_line" in
    *" 200 "*|*" 200")
      return 0
      ;;
  esac
  return 1
}

read_local_direct_health() {
  if [ "$RUN_MODE" = "local" ]; then
    read_local_direct_health_local
  else
    read_local_direct_health_adb
  fi
}

cooldown_active() {
  [ -r "$LAST_RECOVERY_FILE" ] || return 1
  local now last elapsed
  now="$(date +%s)"
  last="$(cat "$LAST_RECOVERY_FILE" 2>/dev/null || echo 0)"
  case "$last" in
    ''|*[!0-9]*)
      last=0
      ;;
  esac
  elapsed=$((now - last))
  [ "$elapsed" -lt "$COOLDOWN_SEC" ]
}

mark_recovery() {
  date +%s > "$LAST_RECOVERY_FILE"
}

run_shell_action() {
  local label="$1"
  local command="$2"
  if [ "$DRY_RUN" = "1" ]; then
    if [ "$RUN_MODE" = "local" ]; then
      log "dry-run: $label: local shell: $command"
    else
      log "dry-run: $label: adb -s $ADB_TARGET shell $command"
    fi
    return 0
  fi
  if [ "$RUN_MODE" = "local" ]; then
    if sh -c "$command" >/dev/null 2>&1; then
      log "ok: $label"
      return 0
    fi
  elif adb_cmd shell "$command" >/dev/null 2>&1; then
    log "ok: $label"
    return 0
  fi
  log "warn: failed: $label"
  return 0
}

wake_package() {
  local pkg="$1"
  local label="$2"
  if ! pkg_installed "$pkg"; then
    log "skip wake: $label not installed pkg=$pkg"
    return 0
  fi
  run_shell_action "wake $label" "am start --user 0 -a android.intent.action.MAIN -c android.intent.category.LAUNCHER -p $pkg >/dev/null 2>&1 || monkey -p $pkg -c android.intent.category.LAUNCHER 1 >/dev/null 2>&1 || true"
}

termux_run_command() {
  local pkg="$1"
  local label="$2"
  if ! pkg_installed "$pkg"; then
    log "skip RunCommand: $label not installed pkg=$pkg"
    return 0
  fi
  run_shell_action "restart worker via $label RunCommandService" "am startservice --user 0 -n $pkg/com.termux.app.RunCommandService -a com.termux.RUN_COMMAND --es com.termux.RUN_COMMAND_PATH $RESTART_SCRIPT --ez com.termux.RUN_COMMAND_BACKGROUND true >/dev/null 2>&1 || am start-foreground-service --user 0 -n $pkg/com.termux.app.RunCommandService -a com.termux.RUN_COMMAND --es com.termux.RUN_COMMAND_PATH $RESTART_SCRIPT --ez com.termux.RUN_COMMAND_BACKGROUND true >/dev/null 2>&1 || true"
}

restart_worker_local() {
  if [ -r "$LOCAL_RESTART_SCRIPT" ]; then
    local restart_dir restart_name restart_cmd
    restart_dir="$(dirname "$LOCAL_RESTART_SCRIPT")"
    restart_name="$(basename "$LOCAL_RESTART_SCRIPT")"
    restart_cmd="sh ./$restart_name"
    if [ "$DRY_RUN" = "1" ]; then
      log "dry-run: local worker restart: $restart_cmd"
      return 0
    fi
    if (cd "$restart_dir" && sh "./$restart_name") >/dev/null 2>&1; then
      log "ok: local worker restart requested"
      return 0
    fi
    log "warn: local worker restart script failed: $restart_cmd"
    return 0
  fi
  log "skip local worker restart: $LOCAL_RESTART_SCRIPT not readable; package wake only"
}

storebot_repair_worker() {
  if ! pkg_installed "com.sbotux"; then
    log "skip StoreBotTermux repair broadcast: com.sbotux not installed"
    return 0
  fi
  run_shell_action "StoreBotTermux wake receiver" "am broadcast -a com.sbotux.STOREBOT_WAKE_FROM_SERVERPHONE_GUARD -p com.sbotux >/dev/null 2>&1 || true"
  run_shell_action "StoreBotTermux repair worker broadcast" "am broadcast -n com.sbotux/.app.StoreBotTermuxOpsReceiver -a com.sbotux.STOREBOT_REPAIR_WORKER >/dev/null 2>&1 || true"
}

target_is_serverphone() {
  pkg_installed "com.sbotux" && return 0
  pkg_installed "com.nelife.serverphoneguard" && return 0
  return 1
}

recover_stack() {
  if ! target_is_serverphone; then
    log "recovery blocked: target lacks com.sbotux/serverphoneguard marker; refusing possible personal/Wonmux target"
    return 3
  fi
  if cooldown_active; then
    log "recovery cooldown active (${COOLDOWN_SEC}s); not restarting again"
    return 2
  fi

  log "recovery sequence started"
  run_shell_action "screen wake" "input keyevent KEYCODE_WAKEUP >/dev/null 2>&1 || true"
  storebot_repair_worker
  wake_package "com.sbotux" "StoreBotTermux"
  wake_package "com.termux" "Termux"
  if [ "$RUN_MODE" = "local" ]; then
    restart_worker_local
  else
    termux_run_command "com.sbotux" "StoreBotTermux"
    termux_run_command "com.termux" "Termux"
  fi
  wake_package "com.kakao.talk" "KakaoTalk"
  if [ "$DRY_RUN" = "0" ]; then
    mark_recovery
  fi
  log "recovery sequence requested"
}

if [ "$RUN_MODE" = "adb" ]; then
  require_adb
  if ! ADB_TARGET="$(resolve_adb_target)"; then
    log "no ADB target. Set ADB_SERIAL or update $ADB_STATE_FILE"
    exit 1
  fi
  log "mode=$MODE run_mode=$RUN_MODE dry_run=$DRY_RUN adb_target=$ADB_TARGET"

  if ! ensure_target_connected; then
    log "ADB target is not connected: $ADB_TARGET"
    exit 1
  fi
else
  check_local_environment
  log "mode=$MODE run_mode=$RUN_MODE dry_run=$DRY_RUN local_restart_script=$LOCAL_RESTART_SCRIPT"
fi

print_pkg_status "com.kakao.talk" "KakaoTalk"
print_pkg_status "com.sbotux" "StoreBotTermux"
print_pkg_status "com.termux" "Termux"
print_pkg_status "net.dinglisch.android.taskerm" "Tasker"
print_pkg_status "com.nelife.serverphoneguard" "ServerPhoneGuard"

WORKER_RUNNING="no"
WORKER_LINES="$(worker_process_status || true)"
if [ -n "$WORKER_LINES" ]; then
  WORKER_RUNNING="yes"
fi
printf 'worker_process running=%s\n' "$WORKER_RUNNING"
if [ -n "$WORKER_LINES" ]; then
  printf '%s\n' "$WORKER_LINES" | sed 's/^/worker_process_line /'
fi

HEALTH_STATUS="unknown"
HEALTH_BODY=""
set +e
HEALTH_BODY="$(read_local_direct_health)"
HEALTH_CODE=$?
set -e
case "$HEALTH_CODE" in
  0)
    HEALTH_STATUS="ok"
    ;;
  2)
    HEALTH_STATUS="unknown"
    ;;
  *)
    HEALTH_STATUS="fail"
    ;;
esac
printf 'local_direct_health status=%s port=8765\n' "$HEALTH_STATUS"
if [ -n "$HEALTH_BODY" ]; then
  printf '%s\n' "$HEALTH_BODY" | head -n 5 | sed 's/^/local_direct_health_body /'
fi

NEEDS_RECOVERY=0
REASONS=""
if ! pkg_installed "com.kakao.talk"; then
  NEEDS_RECOVERY=1
  REASONS="${REASONS} kakao_missing"
elif ! pkg_running "com.kakao.talk"; then
  NEEDS_RECOVERY=1
  REASONS="${REASONS} kakao_not_running"
fi
if ! pkg_installed "com.sbotux" && ! pkg_installed "com.termux"; then
  NEEDS_RECOVERY=1
  REASONS="${REASONS} no_storebot_termux_host"
fi
if [ "$WORKER_RUNNING" != "yes" ]; then
  NEEDS_RECOVERY=1
  REASONS="${REASONS} worker_not_running"
fi
if [ "$HEALTH_STATUS" = "fail" ]; then
  NEEDS_RECOVERY=1
  REASONS="${REASONS} local_direct_failed"
elif [ "$HEALTH_STATUS" = "unknown" ] && [ "$WORKER_RUNNING" != "yes" ]; then
  NEEDS_RECOVERY=1
  REASONS="${REASONS} local_direct_unknown"
fi

if [ "$RUN_MODE" = "local" ] && [ "$NEEDS_RECOVERY" != "0" ] && ! target_is_serverphone; then
  log "local mode warning: server-phone marker package not found; run --local inside server-phone Termux/Tasker, and use default --adb from proot/PC/Wonmux"
fi

if [ "$NEEDS_RECOVERY" = "0" ]; then
  log "status ok: no recovery needed"
  exit 0
fi

log "status needs recovery:$REASONS"
if [ "$MODE" = "status" ]; then
  exit 2
fi

recover_stack
