#!/usr/bin/env python3
"""Typed StoreBot operational receipts for the Telegram CA room.

Only the StoreBot external worker produces receipts.  Projection is a separate
transport-only step run by the server-phone AI Ops worker.  Raw Kakao content,
room/member/store/order data, exceptions and credentials are never accepted by
this contract.
"""

from __future__ import annotations

import hashlib
import hmac
import json
import os
import re
import stat
from dataclasses import dataclass
from pathlib import Path
from typing import Any, Callable, Mapping, Protocol


DOMAIN = "storebot"
RECEIPT_SCHEMA = "storebot.ca_receipt.v1"
PAYLOAD_SCHEMA = "storebot.ca_telegram_payload.v1"
DELIVERY_SCHEMA = "storebot.ca_live_delivery.v1"
DELIVERY_KIND = "storebot_ops_receipt"
RECEIPTS_PATH = "/packhelper/openclaw_telegram_gate/storebot_ca/receipts"
PAYLOADS_PATH = "/packhelper/openclaw_telegram_gate/storebot_ca/payloads"
QUARANTINE_PATH = "/packhelper/openclaw_telegram_gate/storebot_ca/quarantine"
DELIVERIES_PATH = "/packhelper/openclaw_telegram_gate/deliveries"
SERVERPHONE_RESOURCE = "subphone_termux_ops"
SERVERPHONE_ACCOUNT = "serverphone"

TRANSITION_STATUS = {
    "worker_started": frozenset({"running"}),
    "result": frozenset({"completed"}),
    "error": frozenset({"failed"}),
    "timeout": frozenset({"failed"}),
    "stage_status": frozenset({"observed"}),
    "schedule_timeout": frozenset({"failed"}),
    "schedule_recovery_started": frozenset({"running"}),
    "schedule_recovery_result": frozenset({"completed", "failed"}),
}
SEVERITIES = frozenset({"info", "warning", "error", "critical"})
SAFE_FAILURE_CODES = frozenset(
    {
        "none",
        "worker_error",
        "worker_timeout",
        "policy_block",
        "rejected_request",
        "unknown_failure",
        "missing_stage",
        "worker_timeout",
        "phone_timeout",
        "kakao_ack_timeout",
    }
)
INPUT_KEYS = frozenset(
    {
        "private_task_ref",
        "transition",
        "status",
        "resource_id",
        "occurred_at_ms",
        "duration_ms",
        "severity",
        "failure_code",
        "action_count",
        "action_ok_count",
        "action_error_count",
        "stage",
        "stage_result",
        "content_variant",
        "recovery_state",
    }
)
RECEIPT_KEYS = frozenset(
    {
        "schema",
        "domain",
        "receipt_id",
        "task_id",
        "transition",
        "status",
        "resource_id",
        "capability",
        "occurred_at_ms",
        "duration_ms",
        "severity",
        "failure_code",
        "action_count",
        "action_ok_count",
        "action_error_count",
        "stage",
        "stage_result",
        "content_variant",
        "recovery_state",
        "evidence_pointer",
        "origin",
        "recovery_eligible",
        "projection_status",
        "claim_owner",
        "claim_epoch",
        "claim_expires_at_ms",
        "delivery_id",
    }
)
OPAQUE_RE = re.compile(r"^[a-z][a-z0-9_]*_[0-9a-f]{24,64}$")
RECEIPT_ID_RE = re.compile(r"^stca_[0-9a-f]{32}$")
SCHEDULE_STAGES = (
    "schedule_fire",
    "worker_pickup",
    "realtime_data",
    "image_build",
    "outbound_publish",
    "phone_receive",
    "kakao_send",
    "ack",
)
SCHEDULE_STAGE_TIMEOUT_MS = {
    "schedule_fire": 120_000,
    "worker_pickup": 180_000,
    "realtime_data": 180_000,
    "image_build": 120_000,
    "outbound_publish": 60_000,
    "phone_receive": 120_000,
    "kakao_send": 180_000,
    "ack": 120_000,
}


class StoreBotCaError(ValueError):
    pass


@dataclass(frozen=True)
class Snapshot:
    revision: Any
    value: Mapping[str, Any]


@dataclass(frozen=True)
class ReserveResult:
    created: bool
    authoritative: Mapping[str, Any]
    contention: bool = False


class StoreBotCaRepository(Protocol):
    is_durable: bool

    def read_record(self, path: str) -> Snapshot: ...

    def reserve_record(self, path: str, value: Mapping[str, Any]) -> ReserveResult: ...

    def cas_record(self, path: str, revision: Any, value: Mapping[str, Any]) -> ReserveResult: ...

    def query_receipts_page(self, *, limit: int, cursor: Mapping[str, Any] | None) -> Mapping[str, Any]: ...

    def query_deliveries_page(self, *, limit: int, cursor: Mapping[str, Any] | None) -> Mapping[str, Any]: ...


class FirebaseStoreBotCaRepository:
    """Durable Firebase CAS adapter. Construction itself performs no I/O."""

    is_durable = True

    def __init__(
        self,
        *,
        read_with_etag: Callable[[str], tuple[Any, Any]],
        conditional_put: Callable[[str, Mapping[str, Any], Any], bool],
        query_receipts_page: Callable[..., Mapping[str, Any]] | None = None,
        query_deliveries_page: Callable[..., Mapping[str, Any]] | None = None,
    ) -> None:
        self._read_with_etag = read_with_etag
        self._conditional_put = conditional_put
        self._query_receipts_page = query_receipts_page
        self._query_deliveries_page = query_deliveries_page

    def read_record(self, path: str) -> Snapshot:
        value, revision = self._read_with_etag(path)
        if value in (None, {}):
            return Snapshot(revision, {})
        if not isinstance(value, Mapping):
            raise StoreBotCaError("durable record must be an object")
        return Snapshot(revision, dict(value))

    def reserve_record(self, path: str, value: Mapping[str, Any]) -> ReserveResult:
        candidate = dict(value)
        for _ in range(4):
            snapshot = self.read_record(path)
            if snapshot.value:
                if dict(snapshot.value) != candidate:
                    raise StoreBotCaError("conflicting durable record")
                return ReserveResult(False, dict(snapshot.value))
            if self._conditional_put(path, candidate, snapshot.revision):
                return ReserveResult(True, candidate)
        raise StoreBotCaError("durable reservation contention")

    def cas_record(self, path: str, revision: Any, value: Mapping[str, Any]) -> ReserveResult:
        snapshot = self.read_record(path)
        if snapshot.revision != revision:
            return ReserveResult(False, dict(snapshot.value), contention=True)
        candidate = dict(value)
        if not self._conditional_put(path, candidate, revision):
            return ReserveResult(False, dict(snapshot.value), contention=True)
        return ReserveResult(True, candidate)

    def query_receipts_page(self, *, limit: int, cursor: Mapping[str, Any] | None) -> Mapping[str, Any]:
        if self._query_receipts_page is None:
            raise StoreBotCaError("receipt page reader is unavailable")
        return self._query_receipts_page(RECEIPTS_PATH, limit=limit, cursor=cursor)

    def query_deliveries_page(self, *, limit: int, cursor: Mapping[str, Any] | None) -> Mapping[str, Any]:
        if self._query_deliveries_page is None:
            raise StoreBotCaError("delivery page reader is unavailable")
        return self._query_deliveries_page(DELIVERIES_PATH, limit=limit, cursor=cursor)


def _identity_key(value: bytes | str) -> bytes:
    key = value.encode("utf-8") if isinstance(value, str) else bytes(value)
    if len(key) < 32 or len(key) > 4096:
        raise StoreBotCaError("identity key length is invalid")
    return key


def read_identity_key(path_value: str | None = None) -> bytes:
    verify_module_integrity()
    path_text = str(path_value or os.environ.get("STOREBOT_CA_IDENTITY_KEY_FILE") or "").strip()
    if not path_text:
        raise StoreBotCaError("StoreBot CA identity key file is not configured")
    path = Path(path_text)
    descriptor = os.open(path, os.O_RDONLY | getattr(os, "O_CLOEXEC", 0) | getattr(os, "O_NOFOLLOW", 0))
    try:
        metadata = os.fstat(descriptor)
        if not stat.S_ISREG(metadata.st_mode) or stat.S_IMODE(metadata.st_mode) != 0o600:
            raise StoreBotCaError("StoreBot CA identity key file must be a regular 0600 file")
        value = os.read(descriptor, 4097)
    finally:
        os.close(descriptor)
    return _identity_key(value)


def verify_module_integrity() -> None:
    configured = str(os.environ.get("STOREBOT_CA_MODULE_PATH") or "").strip()
    expected = str(os.environ.get("STOREBOT_CA_MODULE_SHA256") or "").strip().lower()
    if not configured or not expected:
        raise StoreBotCaError("StoreBot CA module path/hash is not configured")
    if not re.fullmatch(r"[0-9a-f]{64}", expected):
        raise StoreBotCaError("StoreBot CA module hash is invalid")
    configured_path = Path(configured)
    if not configured_path.is_absolute() or configured_path.resolve() != Path(__file__).resolve():
        raise StoreBotCaError("StoreBot CA module path does not match the loaded module")
    actual = hashlib.sha256(configured_path.read_bytes()).hexdigest()
    if not hmac.compare_digest(actual, expected):
        raise StoreBotCaError("StoreBot CA module hash mismatch")


def _opaque(prefix: str, key: bytes, value: Any, length: int = 32) -> str:
    encoded = json.dumps(value, ensure_ascii=False, sort_keys=True, separators=(",", ":")).encode("utf-8")
    return f"{prefix}_{hmac.new(key, encoded, hashlib.sha256).hexdigest()[:length]}"


def _bounded_count(value: Any) -> int:
    try:
        result = int(value or 0)
    except (TypeError, ValueError) as exc:
        raise StoreBotCaError("action count is invalid") from exc
    if result < 0 or result > 10_000:
        raise StoreBotCaError("action count is outside the bounded range")
    return result


def classify_schedule_stage_ledger(ledger: Mapping[str, Any], *, now_ms: int) -> dict[str, Any]:
    """Return typed stage facts only; raw stage messages/evidence are ignored."""

    if not isinstance(ledger, Mapping):
        raise StoreBotCaError("schedule ledger must be an object")
    event_kind = str(ledger.get("event_kind") or "")
    if not (event_kind.startswith("schedule_") or event_kind == "work_schedule_broadcast"):
        return {"eligible": False, "observed": [], "timeout": None, "content_variant": "none"}
    stages = ledger.get("stages")
    if not isinstance(stages, Mapping):
        stages = {}
    observed: list[dict[str, Any]] = []
    timeout: dict[str, Any] | None = None
    image_observed = False
    present: list[tuple[int, str, str, int]] = []
    for index, stage in enumerate(SCHEDULE_STAGES):
        raw = stages.get(stage)
        record = raw if isinstance(raw, Mapping) else {}
        status = str(record.get("status") or "").lower()
        updated = int(record.get("updated_at_ms") or record.get("updated_at") or record.get("ts") or 0)
        if status in {"started", "done", "error", "timeout", "skipped"}:
            observed.append({"stage": stage, "stage_result": status, "occurred_at_ms": max(1, updated)})
            present.append((index, stage, status, updated))
            if stage == "image_build" and status != "skipped":
                image_observed = True
    if present:
        index, stage, status, updated = present[-1]
        if status in {"error", "timeout"}:
            timeout = {"stage": stage, "stage_result": status, "elapsed_ms": max(0, int(now_ms) - updated)}
        elif status == "started" and updated > 0 and int(now_ms) - updated > SCHEDULE_STAGE_TIMEOUT_MS[stage]:
            timeout = {"stage": stage, "stage_result": "timeout", "elapsed_ms": int(now_ms) - updated}
        elif status in {"done", "skipped"} and index + 1 < len(SCHEDULE_STAGES):
            next_stage = SCHEDULE_STAGES[index + 1]
            if updated > 0 and int(now_ms) - updated > SCHEDULE_STAGE_TIMEOUT_MS[next_stage]:
                timeout = {"stage": next_stage, "stage_result": "missing", "elapsed_ms": int(now_ms) - updated}
    if timeout:
        stage = str(timeout["stage"])
        timeout["failure_code"] = (
            "phone_timeout"
            if stage == "phone_receive"
            else "kakao_ack_timeout"
            if stage in {"kakao_send", "ack"}
            else "missing_stage"
            if stage == "schedule_fire" or timeout.get("stage_result") == "missing"
            else "worker_timeout"
        )
    return {
        "eligible": True,
        "observed": observed,
        "timeout": timeout,
        "content_variant": "image" if image_observed or event_kind == "work_schedule_broadcast" else "text",
    }


def projection_enabled() -> bool:
    return _flag("STOREBOT_CA_PROJECTION_ENABLED") and not _flag("STOREBOT_CA_KILL_SWITCH")


def live_send_enabled() -> bool:
    return projection_enabled() and _flag("STOREBOT_CA_LIVE_SEND_ENABLED") and not _flag("STOREBOT_CA_KILL_SWITCH")


def factory_self_fix_enabled() -> bool:
    return (
        projection_enabled()
        and _flag("STOREBOT_CA_FACTORY_SELF_FIX_ENABLED")
        and not _flag("STOREBOT_CA_KILL_SWITCH")
    )


def _flag(name: str) -> bool:
    return str(os.environ.get(name) or "").strip().lower() in {"1", "true", "yes", "on"}


class StoreBotCaLog:
    def __init__(self, *, identity_key: bytes | str, repository: StoreBotCaRepository) -> None:
        if not bool(getattr(repository, "is_durable", False)):
            raise StoreBotCaError("StoreBot CA repository must be durable")
        self.key = _identity_key(identity_key)
        self.repository = repository

    def build_receipt(self, event: Mapping[str, Any]) -> dict[str, Any]:
        if not isinstance(event, Mapping) or not event:
            raise StoreBotCaError("typed StoreBot event is required")
        unknown = frozenset(event) - INPUT_KEYS
        if unknown:
            raise StoreBotCaError("raw or unknown StoreBot event field is forbidden")
        private_ref = str(event.get("private_task_ref") or "").strip()
        if not private_ref or len(private_ref) > 240:
            raise StoreBotCaError("private_task_ref is invalid")
        transition = str(event.get("transition") or "")
        status = str(event.get("status") or "")
        if transition not in TRANSITION_STATUS or status not in TRANSITION_STATUS[transition]:
            raise StoreBotCaError("StoreBot transition/status is invalid")
        resource = str(event.get("resource_id") or "")
        if resource != SERVERPHONE_RESOURCE:
            raise StoreBotCaError("StoreBot producer must be the external serverphone worker")
        occurred = int(event.get("occurred_at_ms") or 0)
        duration = int(event.get("duration_ms") or 0)
        if occurred <= 0 or duration < 0 or duration > 24 * 60 * 60 * 1000:
            raise StoreBotCaError("StoreBot event timing is invalid")
        severity = str(event.get("severity") or "info")
        if severity not in SEVERITIES:
            raise StoreBotCaError("StoreBot severity is invalid")
        failure_code = str(event.get("failure_code") or "none")
        if failure_code not in SAFE_FAILURE_CODES:
            raise StoreBotCaError("StoreBot failure_code is not allowlisted")
        counts = {
            "action_count": _bounded_count(event.get("action_count")),
            "action_ok_count": _bounded_count(event.get("action_ok_count")),
            "action_error_count": _bounded_count(event.get("action_error_count")),
        }
        if counts["action_ok_count"] + counts["action_error_count"] > counts["action_count"]:
            raise StoreBotCaError("StoreBot action counts are inconsistent")
        task_id = _opaque("sttask", self.key, {"private_task_ref": private_ref})
        stage = str(event.get("stage") or "none")
        stage_result = str(event.get("stage_result") or "none")
        content_variant = str(event.get("content_variant") or "none")
        recovery_state = str(event.get("recovery_state") or "none")
        if stage not in frozenset({"none", *SCHEDULE_STAGES}):
            raise StoreBotCaError("StoreBot schedule stage is invalid")
        if stage_result not in {"none", "started", "done", "error", "timeout", "skipped", "missing"}:
            raise StoreBotCaError("StoreBot stage result is invalid")
        if content_variant not in {"none", "text", "image"}:
            raise StoreBotCaError("StoreBot schedule content variant is invalid")
        if recovery_state not in {"none", "requested", "resumed_request", "resumed_outbound", "skipped", "failed"}:
            raise StoreBotCaError("StoreBot recovery state is invalid")
        identity = {
            "task_id": task_id,
            "transition": transition,
            "status": status,
            "stage": stage,
            "stage_result": stage_result,
        }
        receipt_id = _opaque("stca", self.key, identity)
        receipt = {
            "schema": RECEIPT_SCHEMA,
            "domain": DOMAIN,
            "receipt_id": receipt_id,
            "task_id": task_id,
            "transition": transition,
            "status": status,
            "resource_id": resource,
            "capability": "storebot_external_worker_runtime",
            "occurred_at_ms": occurred,
            "duration_ms": duration,
            "severity": severity,
            "failure_code": failure_code,
            **counts,
            "stage": stage,
            "stage_result": stage_result,
            "content_variant": content_variant,
            "recovery_state": recovery_state,
            "evidence_pointer": _opaque("stev", self.key, identity),
            "origin": "storebot_external_worker",
            "recovery_eligible": transition in {"error", "timeout", "schedule_timeout"}
            and failure_code in {"worker_error", "worker_timeout", "missing_stage", "phone_timeout", "kakao_ack_timeout"},
            "projection_status": "ready",
            "claim_owner": "",
            "claim_epoch": 0,
            "claim_expires_at_ms": 0,
            "delivery_id": "",
        }
        self.validate_receipt(receipt)
        return receipt

    def produce(self, event: Mapping[str, Any]) -> ReserveResult:
        receipt = self.build_receipt(event)
        path = f"{RECEIPTS_PATH}/{receipt['receipt_id']}"
        existing = self.repository.read_record(path).value
        if existing:
            self.validate_receipt(existing)
            binding = ("receipt_id", "task_id", "transition", "status", "resource_id", "origin")
            if any(existing.get(field) != receipt.get(field) for field in binding):
                raise StoreBotCaError("conflicting StoreBot receipt identity")
            return ReserveResult(False, dict(existing))
        try:
            return self.repository.reserve_record(path, receipt)
        except StoreBotCaError:
            authoritative = self.repository.read_record(path).value
            if authoritative:
                self.validate_receipt(authoritative)
                binding = ("receipt_id", "task_id", "transition", "status", "resource_id", "origin")
                if all(authoritative.get(field) == receipt.get(field) for field in binding):
                    return ReserveResult(False, dict(authoritative), contention=True)
            raise

    @staticmethod
    def validate_receipt(receipt: Mapping[str, Any]) -> None:
        if frozenset(receipt) != RECEIPT_KEYS:
            raise StoreBotCaError("StoreBot receipt schema contains forbidden or missing fields")
        if receipt.get("schema") != RECEIPT_SCHEMA or receipt.get("domain") != DOMAIN:
            raise StoreBotCaError("StoreBot receipt schema/domain mismatch")
        if not RECEIPT_ID_RE.fullmatch(str(receipt.get("receipt_id") or "")):
            raise StoreBotCaError("StoreBot receipt id is invalid")
        for field, prefix in (("task_id", "sttask"), ("evidence_pointer", "stev")):
            value = str(receipt.get(field) or "")
            if not value.startswith(prefix + "_") or not OPAQUE_RE.fullmatch(value):
                raise StoreBotCaError(f"StoreBot receipt {field} is invalid")
        transition = str(receipt.get("transition") or "")
        if transition not in TRANSITION_STATUS or receipt.get("status") not in TRANSITION_STATUS[transition]:
            raise StoreBotCaError("StoreBot receipt transition/status mismatch")
        if receipt.get("resource_id") != SERVERPHONE_RESOURCE or receipt.get("origin") != "storebot_external_worker":
            raise StoreBotCaError("StoreBot receipt producer binding mismatch")
        if receipt.get("severity") not in SEVERITIES or receipt.get("failure_code") not in SAFE_FAILURE_CODES:
            raise StoreBotCaError("StoreBot receipt enum is invalid")
        if receipt.get("stage") not in {"none", *SCHEDULE_STAGES}:
            raise StoreBotCaError("StoreBot receipt stage is invalid")

    def _claim(self, receipt_id: str, now_ms: int) -> Snapshot | None:
        path = f"{RECEIPTS_PATH}/{receipt_id}"
        for _ in range(4):
            snapshot = self.repository.read_record(path)
            receipt = dict(snapshot.value)
            if not receipt:
                return None
            self.validate_receipt(receipt)
            state = str(receipt.get("projection_status") or "")
            if state in {"projected", "rejected"}:
                return None
            if state == "claimed" and int(receipt.get("claim_expires_at_ms") or 0) > int(now_ms):
                return None
            receipt.update(
                {
                    "projection_status": "claimed",
                    "claim_owner": SERVERPHONE_RESOURCE,
                    "claim_epoch": int(receipt.get("claim_epoch") or 0) + 1,
                    "claim_expires_at_ms": int(now_ms) + 60_000,
                }
            )
            claimed = self.repository.cas_record(path, snapshot.revision, receipt)
            if claimed.contention:
                continue
            return self.repository.read_record(path)
        return None

    def _delivery_id(self, receipt_id: str, room_id: str) -> str:
        return _opaque("stcalive", self.key, {"receipt_id": receipt_id, "room_id": room_id})

    @staticmethod
    def _message(receipt: Mapping[str, Any]) -> str:
        label = {
            "worker_started": "시작",
            "result": "완료",
            "error": "오류",
            "timeout": "타임아웃",
            "stage_status": "근무표 단계",
            "schedule_timeout": "근무표 미발송 감지",
            "schedule_recovery_started": "근무표 복구 시작",
            "schedule_recovery_result": "근무표 복구 결과",
        }[str(receipt["transition"])]
        return "\n".join(
            (
                f"[서버폰 StoreBot {label}]",
                f"status: {receipt['status']}",
                f"severity: {receipt['severity']}",
                f"actions: total={int(receipt['action_count'])} ok={int(receipt['action_ok_count'])} error={int(receipt['action_error_count'])}",
                f"failure: {receipt['failure_code']}",
                f"stage: {receipt['stage']}={receipt['stage_result']}",
                f"variant: {receipt['content_variant']}",
                f"recovery: {receipt['recovery_state']}",
                f"receipt: {receipt['receipt_id']}",
                f"evidence: {receipt['evidence_pointer']}",
            )
        )

    def _project_claimed(self, snapshot: Snapshot, room_id: str, now_ms: int, live_send: bool) -> dict[str, Any]:
        receipt = dict(snapshot.value)
        self.validate_receipt(receipt)
        if receipt.get("projection_status") != "claimed" or receipt.get("claim_owner") != SERVERPHONE_RESOURCE:
            raise StoreBotCaError("StoreBot receipt claim binding is invalid")
        receipt_id = str(receipt["receipt_id"])
        delivery_id = self._delivery_id(receipt_id, room_id)
        payload = {
            "schema": PAYLOAD_SCHEMA,
            "domain": DOMAIN,
            "delivery_kind": DELIVERY_KIND,
            "request_id": delivery_id,
            "receipt_ref": receipt_id,
            "status": "ready",
            "message": self._message(receipt),
            "created_at_ms": int(now_ms),
        }
        delivery = {
            "schema": DELIVERY_SCHEMA,
            "domain": DOMAIN,
            "status": "waiting",
            "request_id": delivery_id,
            "task_id": delivery_id,
            "queue": "storebot_ca_status",
            "request_path": f"{PAYLOADS_PATH}/{delivery_id}",
            "result_path": "",
            "target": "serverphone",
            "target_node": SERVERPHONE_RESOURCE,
            "participant_id": "serverphone",
            "resource_id": SERVERPHONE_RESOURCE,
            "capability": "storebot_ops_status_only",
            "lifecycle_state": "request",
            "ingress_account_id": SERVERPHONE_ACCOUNT,
            "reply_account_id": SERVERPHONE_ACCOUNT,
            "conversation_id": room_id,
            "room_kind": "ca_expert",
            "thread_id": "",
            "source_message_id": "",
            "created_at_ms": int(now_ms),
            "expires_at_ms": int(now_ms) + 24 * 60 * 60 * 1000,
            "attempt_count": 0,
            "next_attempt_at_ms": 0,
            "delivery_kind": DELIVERY_KIND,
            "receipt_refs": [receipt_id],
            "aggregate_count": 1,
            "no_send": not bool(live_send),
            "sent": False,
        }
        self.repository.reserve_record(str(delivery["request_path"]), payload)
        self.repository.reserve_record(f"{DELIVERIES_PATH}/{delivery_id}", delivery)
        receipt.update(
            {
                "projection_status": "projected",
                "claim_expires_at_ms": 0,
                "delivery_id": delivery_id,
            }
        )
        committed = self.repository.cas_record(
            f"{RECEIPTS_PATH}/{receipt_id}", snapshot.revision, receipt
        )
        if committed.contention:
            authoritative = self.repository.read_record(f"{RECEIPTS_PATH}/{receipt_id}").value
            if authoritative.get("delivery_id") != delivery_id:
                raise StoreBotCaError("StoreBot receipt projection contention")
        return delivery

    def _quarantine(self, receipt_id: str, error_code: str, now_ms: int) -> None:
        safe_id = receipt_id if RECEIPT_ID_RE.fullmatch(receipt_id) else _opaque("stcapoison", self.key, receipt_id)
        quarantine_id = _opaque("stcaquarantine", self.key, {"receipt": safe_id, "error": error_code})
        self.repository.reserve_record(
            f"{QUARANTINE_PATH}/{quarantine_id}",
            {
                "schema": "storebot.ca_quarantine.v1",
                "quarantine_id": quarantine_id,
                "receipt_ref": safe_id,
                "error_code": error_code,
                "occurred_at_ms": int(now_ms),
                "raw_included": False,
            },
        )

    def project_backlog(
        self,
        *,
        room_id: str,
        now_ms: int,
        live_send: bool,
        page_size: int = 100,
        max_pages: int = 100,
    ) -> dict[str, Any]:
        if not re.fullmatch(r"-[0-9]+", str(room_id or "")):
            raise StoreBotCaError("StoreBot CA room id is invalid")
        projected = 0
        rejected = 0
        scanned = 0
        cursor: Mapping[str, Any] | None = None
        for _ in range(max(1, int(max_pages))):
            page = self.repository.query_receipts_page(limit=max(1, min(1000, int(page_size))), cursor=cursor)
            items = page.get("items") if isinstance(page, Mapping) else None
            if not isinstance(items, list):
                raise StoreBotCaError("StoreBot receipt page is invalid")
            for value in items:
                scanned += 1
                receipt_id = str(value.get("receipt_id") or "") if isinstance(value, Mapping) else ""
                try:
                    if not isinstance(value, Mapping):
                        raise StoreBotCaError("receipt is not an object")
                    self.validate_receipt(value)
                    claimed = self._claim(receipt_id, now_ms)
                    if claimed is not None:
                        self._project_claimed(claimed, room_id, now_ms, live_send)
                        projected += 1
                except (StoreBotCaError, TypeError, ValueError):
                    self._quarantine(receipt_id, "invalid_typed_receipt", now_ms)
                    rejected += 1
            cursor = page.get("next_cursor") if isinstance(page, Mapping) else None
            if page.get("exhausted") is True or not cursor:
                break
        return {"scanned": scanned, "projected": projected, "rejected": rejected}


__all__ = [
    "DELIVERIES_PATH",
    "DELIVERY_KIND",
    "DELIVERY_SCHEMA",
    "DOMAIN",
    "FirebaseStoreBotCaRepository",
    "PAYLOAD_SCHEMA",
    "PAYLOADS_PATH",
    "RECEIPT_SCHEMA",
    "RECEIPTS_PATH",
    "ReserveResult",
    "SERVERPHONE_ACCOUNT",
    "SERVERPHONE_RESOURCE",
    "Snapshot",
    "StoreBotCaError",
    "StoreBotCaLog",
    "factory_self_fix_enabled",
    "classify_schedule_stage_ledger",
    "live_send_enabled",
    "projection_enabled",
    "read_identity_key",
    "verify_module_integrity",
]
