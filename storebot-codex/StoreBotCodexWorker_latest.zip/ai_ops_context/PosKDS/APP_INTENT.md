<!-- source: /root/PosKDS/APP_INTENT.md -->
# PosKDS APP_INTENT.md

## 만든 이유
- KDS 화면의 조리중 건수, 주문번호, 완료 정보를 안정적으로 읽어 PosDelay와 운영 대시보드가 같은 기준을 보게 한다.
- native APK KDS operations app이라서 UI 변경도 현장 운영 경계에 바로 연결된다.

## 사용자 결과
- 주문 폭주 때 KDS 건수와 주문번호가 누락되거나 0으로 잘못 내려가면 안 된다.
- Firebase, Gist, FCM, monitor heartbeat 중 일부가 실패해도 가능한 채널은 계속 살아야 한다.

## 절대 기준
- KDS 화면이 비었다는 이유만으로 조리중 건수를 0으로 강제하지 않는다. 주문번호나 이전 상태 보정 기준을 먼저 본다.
- 자동수락/배달료/영업정지 실행 판단은 PosDelay가 한다. PosKDS는 KDS 상태를 업로드하는 센서다.
- SA 키와 토큰은 런타임 로드 기준을 유지하고 하드코딩하지 않는다.
- Firebase read-only preflight로 config/status/heartbeat/order/KDS source를 먼저 확인한다.

## UI/동선 기준
- 앱 화면보다 접근성 서비스, foreground service, 알림바 건수, heartbeat가 운영 기준이다.
- 접근성 권한이 꺼지거나 KDS 앱 UI 패턴이 바뀌면 원인을 monitor에 드러내야 한다.
- UI 작업은 대표 기기 screenshot, accessibility label/snapshot, touch target, overflow, KDS 가시성을 같이 본다.
- 공장 PC 또는 device evidence가 없으면 UI 완료로 보지 않는다.

## 데이터/경계 기준
- 주요 경로는 `/app_update/poskds.json`, `/kds_status`, `/kds_log`, `/kds_dump`, `/kds_history`, `/monitor/poskds/status`다.
- PosDelay가 소비하는 건수 의미를 바꾸면 PosDelay APP_INTENT와 CODEMAP을 같이 확인한다.
- KDS 안정 운영 중에는 임의 UI 개편보다 파싱 안정성, heartbeat, 업데이트 경로를 우선한다.
- 영업 중 업데이트, KDS live state write, destructive change는 별도 safety flow와 명시 승인 없이는 금지한다.

## C&I / AI Ops 경계
- C&I는 heartbeat stale, 접근성 파싱 실패, upload 채널 실패, AppUpdater 실패, PosDelay 소비값 불일치를 self_fix 후보로 올린다.
- 자동 복구는 코드/설정/문서/APK/업데이트센터 보정까지 허용한다.
- KDS 원본 앱 직접 조작, PosDelay 실행 명령 우회, 건수 0 강제 보정은 금지한다.
- CLI/LLM은 prompt envelope가 있어야 깨어난다. monitor/worker/사용자/수동 enqueue 또는 상주 판단 루프가 prompt를 주입하며, 이것은 C&I 판단 권한 제한이 아니다.

## 수정 전 질문
- 이 변경이 KDS 건수 누락이나 오판을 줄이는가.
- PosDelay가 읽는 값의 의미가 그대로 유지되는가.
- 접근성 권한/foreground 유지/업데이트 채널을 같이 확인했는가.

## 완료 기준
- 검증: KDS 파싱, Firebase upload, monitor heartbeat, Android 빌드.
- 전달: Android 변경 시 debug APK 복사, 설치 화면, 업데이트센터 채널 반영.
- UI 완료: representative device screenshot, accessibility snapshot, touch target, overflow, KDS visibility.
- 추가 배포가 있으면 update channel까지 반영한다.
- 남은 위험: KDS 앱 UI 변경, Doze 지연, Firebase/Gist/FCM 부분 장애.
