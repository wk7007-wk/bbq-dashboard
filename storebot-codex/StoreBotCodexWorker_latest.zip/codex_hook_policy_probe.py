#!/usr/bin/env python3
"""Read-only Codex hook policy compatibility and adoption evidence probe."""

from __future__ import annotations

import argparse
import hashlib
import json
import os
from pathlib import Path
import subprocess
import sys
from typing import Any

try:
    import tomllib
except ModuleNotFoundError:  # pragma: no cover - Python 3.11+ is required in production
    tomllib = None


POLICY_FILE = "minimal_managed_lifecycle.py"
EXPECTED_WORKER_FUNCTIONS = ("codex_command", "codex_resume_command")
DEFAULT_REQUIREMENTS = Path("/") / "etc" / "codex" / "requirements.toml"
DEFAULT_MANAGED_HOOK = Path("/") / "etc" / "codex" / "managed-hooks" / POLICY_FILE


def sha256_file(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for chunk in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def policy_version(path: Path) -> str:
    namespace: dict[str, Any] = {}
    source = path.read_text(encoding="utf-8")
    for line in source.splitlines():
        if not line.startswith("POLICY_VERSION = "):
            continue
        value = line.split("=", 1)[1].strip()
        try:
            parsed = json.loads(value)
        except json.JSONDecodeError:
            return ""
        return parsed if isinstance(parsed, str) else ""
    return ""


def worker_ignore_config_contract(path: Path) -> dict[str, Any]:
    result = {
        "path": str(path),
        "sha256": "",
        "behavior": "actual_argv_subprocess",
        "functions": {},
        "ok": False,
        "error": "",
    }
    try:
        result["sha256"] = sha256_file(path)
        completed = subprocess.run(
            [sys.executable, str(path), "--print-hook-argv-contract"],
            text=True,
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE,
            timeout=15,
            check=False,
            env=os.environ.copy(),
        )
    except (OSError, subprocess.TimeoutExpired) as exc:
        result["error"] = f"worker_source_unreadable:{type(exc).__name__}"
        return result
    if completed.returncode != 0 or len(completed.stdout) > 65536 or len(completed.stderr) > 65536:
        result["error"] = "worker_argv_contract_failed"
        result["returncode"] = completed.returncode
        return result
    try:
        payload = json.loads(completed.stdout.strip().splitlines()[-1])
    except (IndexError, json.JSONDecodeError):
        result["error"] = "worker_argv_contract_invalid_json"
        return result
    if payload.get("status") != "PASS" or payload.get("behavior") != "actual_argv":
        result["error"] = "worker_argv_contract_behavior_unverified"
        return result
    expected_model = payload.get("model")
    expected_effort = payload.get("reasoning_effort")

    def option_value(argv: list[Any], option: str) -> Any:
        try:
            index = argv.index(option)
        except ValueError:
            return None
        return argv[index + 1] if index + 1 < len(argv) else None

    for name, key in zip(EXPECTED_WORKER_FUNCTIONS, ("exec_argv", "resume_argv"), strict=True):
        argv = payload.get(key)
        has_flag = isinstance(argv, list) and argv[:2] == ["codex", "exec"] and argv.count("--ignore-user-config") == 1
        model_ok = isinstance(argv, list) and option_value(argv, "-m") == expected_model
        effort_ok = isinstance(argv, list) and f'model_reasoning_effort="{expected_effort}"' in argv
        resume_ok = name != "codex_resume_command" or (isinstance(argv, list) and "resume" in argv)
        result["functions"][name] = {
            "ignore_user_config": has_flag,
            "model_preserved": model_ok,
            "reasoning_effort_preserved": effort_ok,
            "resume_shape": resume_ok,
        }
    result["ok"] = all(item["ignore_user_config"] for item in result["functions"].values())
    result["ok"] = result["ok"] and all(
        item["model_preserved"] and item["reasoning_effort_preserved"] and item["resume_shape"]
        for item in result["functions"].values()
    )
    if not result["ok"]:
        result["error"] = "worker_missing_ignore_user_config"
    return result


def _config_has_legacy_hooks(path: Path) -> tuple[bool, str]:
    try:
        raw = path.read_bytes()
    except OSError as exc:
        return True, f"config_unreadable:{type(exc).__name__}"
    if not raw.strip():
        return False, "empty"
    if path.name == "hooks.json":
        return True, "legacy_hooks_json"
    if tomllib is None:
        return (b"hook" in raw.lower()), "tomllib_unavailable"
    try:
        data = tomllib.loads(raw.decode("utf-8"))
    except (UnicodeDecodeError, tomllib.TOMLDecodeError):
        return (b"hook" in raw.lower()), "unparseable_hook_config"
    if "hooks" in data:
        return True, "legacy_hook_table"
    return False, "no_hook_table"


def _legacy_candidates(home: Path, project_root: Path) -> list[Path]:
    code_home = Path(os.environ.get("CODEX_HOME") or (home / ".codex"))
    candidates = [code_home / "config.toml", code_home / "hooks.json", code_home / "hooks"]
    current = project_root.resolve()
    while True:
        project_config = current / ".codex"
        candidates.extend((project_config / "config.toml", project_config / "hooks.json", project_config / "hooks"))
        if current.parent == current:
            break
        current = current.parent
    seen: set[str] = set()
    unique: list[Path] = []
    for path in candidates:
        key = str(path)
        if key not in seen:
            seen.add(key)
            unique.append(path)
    return unique


def legacy_findings(home: Path, project_root: Path) -> list[dict[str, Any]]:
    findings: list[dict[str, Any]] = []
    for path in _legacy_candidates(home, project_root):
        if path.is_dir():
            files = sorted(item for item in path.rglob("*") if item.is_file())
            if files:
                findings.append(
                    {
                        "kind": "legacy_hook_directory",
                        "path": str(path),
                        "file_count": len(files),
                        "sample": [str(item.relative_to(path)) for item in files[:5]],
                    }
                )
            continue
        if not path.is_file():
            continue
        active, reason = _config_has_legacy_hooks(path)
        if active:
            findings.append(
                {
                    "kind": reason,
                    "path": str(path),
                    "sha256": sha256_file(path),
                    "size": path.stat().st_size,
                }
            )
    return findings


def managed_state(requirements: Path, installed_hook: Path, source_hook: Path) -> dict[str, Any]:
    expected = {
        "policy_version": policy_version(source_hook),
        "sha256": sha256_file(source_hook),
        "source_path": str(source_hook),
    }
    result: dict[str, Any] = {
        "status": "absent",
        "expected": expected,
        "requirements_path": str(requirements),
        "requirements_sha256": "",
        "installed_path": str(installed_hook),
        "installed_policy_version": "",
        "installed_sha256": "",
        "errors": [],
    }
    if not expected["policy_version"]:
        result["status"] = "invalid_source"
        result["errors"].append("policy_version_missing")
        return result
    requirements_exists = requirements.is_file()
    installed_exists = installed_hook.is_file()
    if not requirements_exists and not installed_exists:
        return result
    if not requirements_exists or not installed_exists:
        result["status"] = "incomplete"
        result["errors"].append("managed_requirements_or_hook_missing")
        return result
    result["requirements_sha256"] = sha256_file(requirements)
    result["installed_sha256"] = sha256_file(installed_hook)
    try:
        result["installed_policy_version"] = policy_version(installed_hook)
    except (OSError, SyntaxError):
        result["errors"].append("installed_hook_unreadable")
    if result["installed_sha256"] != expected["sha256"]:
        result["errors"].append("managed_hook_hash_mismatch")
    if result["installed_policy_version"] != expected["policy_version"]:
        result["errors"].append("managed_hook_policy_mismatch")
    if tomllib is None:
        result["errors"].append("tomllib_unavailable")
    else:
        try:
            config = tomllib.loads(requirements.read_text(encoding="utf-8"))
        except (OSError, UnicodeDecodeError, tomllib.TOMLDecodeError):
            result["errors"].append("managed_requirements_unreadable")
        else:
            if config.get("allow_managed_hooks_only") is not True:
                result["errors"].append("allow_managed_hooks_only_not_true")
            if (config.get("features") or {}).get("hooks") is not True:
                result["errors"].append("managed_hooks_feature_not_true")
            hooks = config.get("hooks") or {}
            if hooks.get("managed_dir") != str(installed_hook.parent):
                result["errors"].append("managed_dir_mismatch")
            expected_command = f"python3 {installed_hook}"
            for event in ("SessionStart", "PreToolUse", "PostToolUse", "Stop"):
                groups = hooks.get(event)
                if not isinstance(groups, list) or len(groups) != 1:
                    result["errors"].append(f"managed_{event}_group_mismatch")
                    continue
                handlers = groups[0].get("hooks") if isinstance(groups[0], dict) else None
                if not isinstance(handlers, list) or len(handlers) != 1:
                    result["errors"].append(f"managed_{event}_handler_mismatch")
                    continue
                if handlers[0].get("type") != "command":
                    result["errors"].append(f"managed_{event}_handler_type_mismatch")
                if handlers[0].get("command") != expected_command:
                    result["errors"].append(f"managed_{event}_command_mismatch")
    result["status"] = "exact" if not result["errors"] else "mismatch"
    return result


def inspect_policy(
    *,
    source_hook: Path,
    worker_source: Path,
    requirements: Path,
    installed_hook: Path,
    home: Path,
    project_root: Path,
) -> dict[str, Any]:
    try:
        managed = managed_state(requirements, installed_hook, source_hook)
    except (OSError, SyntaxError) as exc:
        managed = {
            "status": "invalid_source",
            "expected": {"policy_version": "", "sha256": "", "source_path": str(source_hook)},
            "errors": [f"policy_source_unreadable:{type(exc).__name__}"],
        }
    worker = worker_ignore_config_contract(worker_source)
    legacy = legacy_findings(home, project_root)
    legacy_inheritance_blocked = managed["status"] == "exact"
    legacy_inheritance_risk = [] if legacy_inheritance_blocked else legacy
    compatible = worker["ok"] and managed["status"] == "exact" and not legacy_inheritance_risk
    probe_path = Path(__file__).resolve()
    return {
        "status": "PASS" if compatible else "FAIL",
        "compatible": compatible,
        "execution_contract": "codex_exec_ignore_user_config",
        "worker": worker,
        "managed": managed,
        "legacy_findings": legacy,
        "legacy_inheritance_blocked": legacy_inheritance_blocked,
        "legacy_inheritance_risk": legacy_inheritance_risk,
        "active_mutation_performed": False,
        "admin_adoption": {
            "required": not compatible,
            "plane": "out_of_band_hooks_list_config_batchWrite",
            "evidence_command": f"python3 {probe_path} --json --require-compatible --project-root {project_root}",
            "rule": "inventory_snapshot_then_atomic_cutover_then_fresh_process_probe",
            "fresh_turn_harmless_tool_proof_required": True,
            "fresh_turn_proof_scope": [
                "ordinary_pwd",
                "codex_version",
                "codex_exec_help",
                "managed_requirements_read_with_stderr_redirect",
            ],
        },
    }


def parse_args(argv: list[str]) -> argparse.Namespace:
    repo_root = Path(__file__).resolve().parents[1]
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--json", action="store_true")
    parser.add_argument("--require-compatible", action="store_true")
    parser.add_argument("--source-hook", default=str(repo_root / "scripts" / "codex_hooks" / POLICY_FILE))
    parser.add_argument("--worker-source", default=str(repo_root / "scripts" / "codex_ops_worker.py"))
    parser.add_argument("--requirements", default=str(DEFAULT_REQUIREMENTS))
    parser.add_argument("--installed-hook", default=str(DEFAULT_MANAGED_HOOK))
    parser.add_argument("--home", default=str(Path.home()))
    parser.add_argument("--project-root", default=str(repo_root))
    return parser.parse_args(argv)


def main(argv: list[str]) -> int:
    args = parse_args(argv)
    result = inspect_policy(
        source_hook=Path(args.source_hook).expanduser(),
        worker_source=Path(args.worker_source).expanduser(),
        requirements=Path(args.requirements).expanduser(),
        installed_hook=Path(args.installed_hook).expanduser(),
        home=Path(args.home).expanduser(),
        project_root=Path(args.project_root).expanduser(),
    )
    if args.json:
        print(json.dumps(result, ensure_ascii=False, sort_keys=True))
    else:
        managed = result["managed"]
        expected = managed.get("expected") or {}
        print(
            f"{result['status']} policy={expected.get('policy_version') or 'unknown'} "
            f"hash={str(expected.get('sha256') or '')[:12]} managed={managed.get('status')} "
            f"legacy={len(result['legacy_findings'])} worker_ignore_config={result['worker']['ok']}"
        )
    return 3 if args.require_compatible and not result["compatible"] else 0


if __name__ == "__main__":
    raise SystemExit(main(sys.argv[1:]))
