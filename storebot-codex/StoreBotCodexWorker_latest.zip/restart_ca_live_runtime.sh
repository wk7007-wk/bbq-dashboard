#!/system/bin/sh
if [ -z "${CA_LIVE_BASH_REEXEC:-}" ]; then
  for candidate in "${STOREBOT_TERMUX_DATA_DIR:-}" /data/data/com.sbotux /data/data/com.termux; do
    [ -n "$candidate" ] || continue
    if [ -x "$candidate/files/usr/bin/bash" ]; then
      export STOREBOT_TERMUX_DATA_DIR="$candidate"
      export CA_LIVE_BASH_REEXEC=1
      exec "$candidate/files/usr/bin/bash" "$0" "$@"
    fi
  done
fi
set -euo pipefail

resolve_termux_data_dir() {
  if [ -n "${STOREBOT_TERMUX_DATA_DIR:-}" ] && [ -x "$STOREBOT_TERMUX_DATA_DIR/files/usr/bin/bash" ]; then
    printf '%s\n' "$STOREBOT_TERMUX_DATA_DIR"
    return 0
  fi
  for candidate in /data/data/com.sbotux /data/data/com.termux; do
    if [ -x "$candidate/files/usr/bin/bash" ]; then
      printf '%s\n' "$candidate"
      return 0
    fi
  done
  printf '%s\n' "/data/data/com.sbotux"
}

APP_DATA_DIR="$(resolve_termux_data_dir)"
if [ "$APP_DATA_DIR" = "/data/data/com.sbotux" ]; then
  DEFAULT_MONITOR_LOCK_BASE_DIR="/sdcard/Download/ai_ops_monitor_sbotux"
else
  DEFAULT_MONITOR_LOCK_BASE_DIR="/sdcard/Download/ai_ops_monitor"
fi
MONITOR_LOCK_DIR="${AI_OPS_MONITOR_LOCK_DIR:-${AI_OPS_MONITOR_LOCK_BASE_DIR:-$DEFAULT_MONITOR_LOCK_BASE_DIR}/ai_ops_monitor.lock}"
CODEX_OPS_LOCK_DIR="${CODEX_OPS_LOCK_DIR:-${CODEX_OPS_LOCK_BASE_DIR:-/sdcard/Download/codex_ops_worker}/codex_ops_worker.lock}"
if [ "$APP_DATA_DIR" = "/data/data/com.sbotux" ]; then
  case "$MONITOR_LOCK_DIR" in
    /sdcard/Download/ai_ops_monitor|/sdcard/Download/ai_ops_monitor/*)
      echo "refusing legacy com.termux AI Ops monitor lock from com.sbotux" >&2
      exit 65
      ;;
  esac
fi
CANONICAL_MONITOR_LOG_DIR="${CA_LIVE_CANONICAL_MONITOR_LOG_DIR:-/sdcard/Download/ai_ops_monitor_canonical_sbotux}"
CANONICAL_MONITOR_LOCK_BASE_DIR="${CA_LIVE_CANONICAL_MONITOR_LOCK_BASE_DIR:-$CANONICAL_MONITOR_LOG_DIR}"
CANONICAL_MONITOR_LOCK_DIR="${CA_LIVE_CANONICAL_MONITOR_LOCK_DIR:-$CANONICAL_MONITOR_LOCK_BASE_DIR/ai_ops_monitor.lock}"
CANONICAL_MONITOR_NODE="subphone_ai_ops_monitor"
CANONICAL_MONITOR_BASE_PATH="/packhelper/ai_ops_monitor_v2"
CANONICAL_MONITOR_INTERVAL_SEC="300"
SBOTUX_MONITOR_NODE="subphone_sbotux_ai_ops_monitor"
SBOTUX_MONITOR_BASE_PATH="/packhelper/ai_ops_monitor_sbotux_v2"
STOP_TIMEOUT_SEC="${CA_LIVE_MONITOR_STOP_TIMEOUT_SEC:-15}"
ORPHAN_LIMIT="${CA_LIVE_MONITOR_ORPHAN_LIMIT:-4}"
RESTART_SCRIPT="${CA_LIVE_STOREBOT_RESTART_SCRIPT:-/sdcard/Download/storebot_codex_worker/restart_storebot_codex_worker.sh}"
RESTART_BASH="${CA_LIVE_RESTART_BASH:-${STOREBOT_CODEX_BASH_PATH:-$(command -v bash || true)}}"
MODE="restart"

if [ "${1:-}" = "--stop-ai-only" ]; then
  if [ "$#" -ne 1 ]; then
    echo "--stop-ai-only does not accept additional arguments" >&2
    exit 64
  fi
  MODE="stop-ai-only"
  shift
elif [ "${1:-}" = "--stop-codex-ops-only" ]; then
  if [ "$#" -ne 1 ]; then
    echo "--stop-codex-ops-only does not accept additional arguments" >&2
    exit 64
  fi
  MODE="stop-codex-ops-only"
  shift
fi

case "$STOP_TIMEOUT_SEC" in
  ''|*[!0-9]*)
    echo "invalid CA live monitor stop timeout" >&2
    exit 64
    ;;
esac
if [ "$STOP_TIMEOUT_SEC" -lt 1 ] || [ "$STOP_TIMEOUT_SEC" -gt 60 ]; then
  echo "CA live monitor stop timeout must be 1..60 seconds" >&2
  exit 64
fi
case "$ORPHAN_LIMIT" in
  ''|*[!0-9]*)
    echo "invalid CA live monitor orphan limit" >&2
    exit 64
    ;;
esac
if [ "$ORPHAN_LIMIT" -lt 1 ] || [ "$ORPHAN_LIMIT" -gt 4 ]; then
  echo "CA live monitor orphan limit must be 1..4" >&2
  exit 64
fi

pid_is_running() {
  local pid="$1" state
  kill -0 "$pid" 2>/dev/null || return 1
  state="$(awk '{print $3}' "/proc/$pid/stat" 2>/dev/null || true)"
  [ "$state" != "Z" ]
}

classify_exact_monitor_pid() {
  local pid="$1" item next env_item
  local node_value="" base_value="" env_node="" node_count=0 base_count=0 env_node_count=0
  local has_python_script=0 has_start_script=0 has_watch=0
  local -a argv=() environ=()
  [ -r "/proc/$pid/cmdline" ] && [ -r "/proc/$pid/environ" ] || return 1
  mapfile -d '' -t argv <"/proc/$pid/cmdline" 2>/dev/null || return 1
  for ((index = 0; index < ${#argv[@]}; index++)); do
    item="${argv[$index]}"
    case "$item" in
      ai_ops_common_monitor.py|*/ai_ops_common_monitor.py) has_python_script=1 ;;
      start_ai_ops_monitor.sh|*/start_ai_ops_monitor.sh) has_start_script=1 ;;
      --watch) has_watch=1 ;;
      --node)
        node_count=$((node_count + 1))
        next="${argv[$((index + 1))]:-}"
        node_value="$next"
        ;;
      --node=*)
        node_count=$((node_count + 1))
        node_value="${item#--node=}"
        ;;
    esac
  done
  [ "$has_python_script" -eq 1 ] || [ "$has_start_script" -eq 1 ] || return 1
  if [ "$has_python_script" -eq 1 ] && { [ "$has_watch" -ne 1 ] || [ "$node_count" -ne 1 ]; }; then
    return 2
  fi
  [ "$node_count" -le 1 ] || return 2

  mapfile -d '' -t environ <"/proc/$pid/environ" 2>/dev/null || return 2
  for env_item in "${environ[@]}"; do
    case "$env_item" in
      AI_OPS_BASE_PATH=*)
        base_count=$((base_count + 1))
        base_value="${env_item#AI_OPS_BASE_PATH=}"
        ;;
      AI_OPS_MONITOR_NODE=*)
        env_node_count=$((env_node_count + 1))
        env_node="${env_item#AI_OPS_MONITOR_NODE=}"
        ;;
    esac
  done
  [ "$base_count" -eq 1 ] && [ "$env_node_count" -le 1 ] || return 2
  if [ "$node_count" -eq 0 ]; then
    [ "$env_node_count" -eq 1 ] || return 2
    node_value="$env_node"
  elif [ "$env_node_count" -eq 1 ] && [ "$env_node" != "$node_value" ]; then
    return 2
  fi
  case "$node_value|$base_value" in
    "$SBOTUX_MONITOR_NODE|$SBOTUX_MONITOR_BASE_PATH"|"$CANONICAL_MONITOR_NODE|$CANONICAL_MONITOR_BASE_PATH") return 0 ;;
    *) return 2 ;;
  esac
}

classify_sbotux_python_watch_pid() {
  classify_exact_monitor_pid "$1"
}

classify_exact_codex_ops_pid() {
  local pid="$1" item env_item
  local has_python_script=0 has_start_script=0 has_watch=0 node_count=0 node_value=""
  local -a argv=() environ=()
  [ -r "/proc/$pid/cmdline" ] && [ -r "/proc/$pid/environ" ] || return 1
  mapfile -d '' -t argv <"/proc/$pid/cmdline" 2>/dev/null || return 1
  for item in "${argv[@]}"; do
    case "$item" in
      codex_ops_worker.py|*/codex_ops_worker.py) has_python_script=1 ;;
      start_codex_ops_worker.sh|*/start_codex_ops_worker.sh) has_start_script=1 ;;
      --watch) has_watch=1 ;;
    esac
  done
  if [ "$has_python_script" -eq 1 ]; then
    [ "$has_start_script" -eq 0 ] && [ "$has_watch" -eq 1 ] || return 2
    mapfile -d '' -t environ <"/proc/$pid/environ" 2>/dev/null || return 2
    for env_item in "${environ[@]}"; do
      case "$env_item" in
        CODEX_OPS_NODE=*)
          node_count=$((node_count + 1))
          node_value="${env_item#CODEX_OPS_NODE=}"
          ;;
      esac
    done
    [ "$node_count" -eq 1 ] && [ "$node_value" = "subphone_termux_ops" ] || return 2
    return 0
  fi
  [ "$has_start_script" -eq 1 ] && [ "$has_watch" -eq 0 ] || return 1
  return 0
}

stop_sbotux_orphan_monitors() {
  local proc pid result deadline running
  local mismatches=0
  local -a matches=()
  [ "$APP_DATA_DIR" = "/data/data/com.sbotux" ] || return 0

  for proc in /proc/[0-9]*/cmdline; do
    [ -r "$proc" ] || continue
    pid="${proc#/proc/}"
    pid="${pid%/cmdline}"
    [ "$pid" != "$$" ] || continue
    pid_is_running "$pid" || continue
    if classify_sbotux_python_watch_pid "$pid"; then
      matches+=("$pid")
    else
      result=$?
      if [ "$result" -eq 2 ]; then
        mismatches=$((mismatches + 1))
      fi
    fi
  done
  if [ "${#matches[@]}" -gt "$ORPHAN_LIMIT" ]; then
    echo "too many signalable com.sbotux AI Ops monitor processes" >&2
    return 1
  fi

  for pid in "${matches[@]}"; do
    pid_is_running "$pid" || continue
    if ! classify_sbotux_python_watch_pid "$pid"; then
      echo "AI Ops monitor pid changed before TERM: $pid" >&2
      return 1
    fi
  done
  for pid in "${matches[@]}"; do
    pid_is_running "$pid" || continue
    kill -TERM "$pid"
  done

  deadline=$((SECONDS + STOP_TIMEOUT_SEC))
  while [ "$SECONDS" -lt "$deadline" ]; do
    running=0
    for pid in "${matches[@]}"; do
      if pid_is_running "$pid"; then
        running=1
        break
      fi
    done
    [ "$running" -eq 0 ] && break
    sleep 1
  done
  for pid in "${matches[@]}"; do
    pid_is_running "$pid" || continue
    if ! classify_sbotux_python_watch_pid "$pid"; then
      echo "AI Ops monitor pid changed before KILL: $pid" >&2
      return 1
    fi
    kill -KILL "$pid"
  done
  if [ "$mismatches" -gt 0 ]; then
    echo "signalable AI Ops monitor has an unexpected node/base binding" >&2
    return 1
  fi
  return 0
}

stop_codex_ops_orphans() {
  local proc pid result deadline running
  local mismatches=0
  local -a matches=()
  [ "$APP_DATA_DIR" = "/data/data/com.sbotux" ] || return 0

  for proc in /proc/[0-9]*/cmdline; do
    [ -r "$proc" ] || continue
    pid="${proc#/proc/}"
    pid="${pid%/cmdline}"
    [ "$pid" != "$$" ] || continue
    pid_is_running "$pid" || continue
    if classify_exact_codex_ops_pid "$pid"; then
      matches+=("$pid")
    else
      result=$?
      if [ "$result" -eq 2 ]; then
        mismatches=$((mismatches + 1))
      fi
    fi
  done
  if [ "${#matches[@]}" -gt "$ORPHAN_LIMIT" ]; then
    echo "too many signalable codex_ops processes" >&2
    return 1
  fi
  if [ "$mismatches" -gt 0 ]; then
    echo "signalable codex_ops process has an unexpected node or argv binding" >&2
    return 1
  fi
  for pid in "${matches[@]}"; do
    pid_is_running "$pid" || continue
    classify_exact_codex_ops_pid "$pid" || {
      echo "codex_ops pid changed before TERM: $pid" >&2
      return 1
    }
    kill -TERM "$pid"
  done
  deadline=$((SECONDS + STOP_TIMEOUT_SEC))
  while [ "$SECONDS" -lt "$deadline" ]; do
    running=0
    for pid in "${matches[@]}"; do
      if pid_is_running "$pid"; then running=1; break; fi
    done
    [ "$running" -eq 0 ] && break
    sleep 1
  done
  for pid in "${matches[@]}"; do
    pid_is_running "$pid" || continue
    classify_exact_codex_ops_pid "$pid" || {
      echo "codex_ops pid changed before KILL: $pid" >&2
      return 1
    }
    kill -KILL "$pid"
  done
}

remove_monitor_lock() {
  local lock_dir="$1" pid_file="$1/pid" entry
  if [ -L "$lock_dir" ]; then
    echo "refusing symlink AI Ops monitor lock: $lock_dir" >&2
    return 1
  fi
  [ -d "$lock_dir" ] || return 0
  if [ -L "$pid_file" ] || { [ -e "$pid_file" ] && [ ! -f "$pid_file" ]; }; then
    echo "invalid AI Ops monitor lock pid file: $pid_file" >&2
    return 1
  fi
  for entry in "$lock_dir"/* "$lock_dir"/.[!.]* "$lock_dir"/..?*; do
    [ -e "$entry" ] || [ -L "$entry" ] || continue
    if [ "$entry" != "$pid_file" ]; then
      echo "AI Ops monitor lock contains unexpected files: $lock_dir" >&2
      return 1
    fi
  done
  rm -f -- "$pid_file"
  if ! rmdir -- "$lock_dir"; then
    echo "AI Ops monitor lock contains unexpected files: $lock_dir" >&2
    return 1
  fi
}

stop_monitor_from_lock() {
  local lock_dir="$1" pid_file="$1/pid" pid deadline
  [ -e "$lock_dir" ] || return 0
  if [ -L "$lock_dir" ] || [ ! -d "$lock_dir" ]; then
    echo "invalid AI Ops monitor lock: $lock_dir" >&2
    return 1
  fi
  if [ -L "$pid_file" ] || [ ! -f "$pid_file" ]; then
    echo "invalid AI Ops monitor lock pid file: $pid_file" >&2
    return 1
  fi
  pid="$([ -f "$pid_file" ] && tr -d '[:space:]' <"$pid_file" || true)"
  case "$pid" in
    ''|*[!0-9]*)
      echo "invalid AI Ops monitor lock pid" >&2
      return 1
      ;;
  esac
  if [ ! -e "/proc/$pid" ]; then
    remove_monitor_lock "$lock_dir"
    return 0
  fi
  if ! classify_exact_monitor_pid "$pid"; then
    echo "AI Ops monitor lock pid does not match an exact monitor node/base" >&2
    return 1
  fi

  kill -TERM "$pid"
  deadline=$((SECONDS + STOP_TIMEOUT_SEC))
  while pid_is_running "$pid" && classify_exact_monitor_pid "$pid" && [ "$SECONDS" -lt "$deadline" ]; do
    sleep 1
  done
  if pid_is_running "$pid"; then
    if ! classify_exact_monitor_pid "$pid"; then
      echo "AI Ops monitor lock pid changed before KILL: $pid" >&2
      return 1
    fi
    kill -KILL "$pid"
    deadline=$((SECONDS + 5))
    while pid_is_running "$pid" && classify_exact_monitor_pid "$pid" && [ "$SECONDS" -lt "$deadline" ]; do
      sleep 1
    done
  fi
  if pid_is_running "$pid"; then
    echo "AI Ops monitor did not stop: pid=$pid" >&2
    return 1
  fi
  remove_monitor_lock "$lock_dir"
}

stop_codex_ops_from_lock() {
  local lock_dir="$CODEX_OPS_LOCK_DIR" pid_file="$CODEX_OPS_LOCK_DIR/pid" pid deadline
  [ -e "$lock_dir" ] || return 0
  if [ -L "$lock_dir" ] || [ ! -d "$lock_dir" ]; then
    echo "invalid codex_ops lock: $lock_dir" >&2
    return 1
  fi
  if [ -L "$pid_file" ] || [ ! -f "$pid_file" ]; then
    echo "invalid codex_ops lock pid file: $pid_file" >&2
    return 1
  fi
  pid="$(tr -d '[:space:]' <"$pid_file" 2>/dev/null || true)"
  case "$pid" in
    ''|*[!0-9]*) echo "invalid codex_ops lock pid" >&2; return 1 ;;
  esac
  if [ ! -e "/proc/$pid" ]; then
    remove_monitor_lock "$lock_dir"
    return 0
  fi
  if ! classify_exact_codex_ops_pid "$pid"; then
    echo "codex_ops lock pid does not match the exact worker" >&2
    return 1
  fi
  kill -TERM "$pid"
  deadline=$((SECONDS + STOP_TIMEOUT_SEC))
  while pid_is_running "$pid" && classify_exact_codex_ops_pid "$pid" && [ "$SECONDS" -lt "$deadline" ]; do
    sleep 1
  done
  if pid_is_running "$pid"; then
    classify_exact_codex_ops_pid "$pid" || {
      echo "codex_ops lock pid changed before KILL: $pid" >&2
      return 1
    }
    kill -KILL "$pid"
  fi
  remove_monitor_lock "$lock_dir"
}

if [ "$MODE" = "restart" ]; then
  if [ -z "$RESTART_BASH" ] || [ ! -x "$RESTART_BASH" ]; then
    echo "bash executable unavailable for StoreBot restart" >&2
    exit 66
  fi
  if [ ! -f "$RESTART_SCRIPT" ] || [ -L "$RESTART_SCRIPT" ]; then
    echo "StoreBot restart script unavailable or unsafe: $RESTART_SCRIPT" >&2
    exit 66
  fi
  exec "$RESTART_BASH" "$RESTART_SCRIPT" "$@"
fi

if [ "$MODE" = "stop-codex-ops-only" ]; then
  stop_codex_ops_from_lock
  stop_codex_ops_orphans
  exit 0
fi

stop_monitor_from_lock "$MONITOR_LOCK_DIR"
if [ "$CANONICAL_MONITOR_LOCK_DIR" != "$MONITOR_LOCK_DIR" ]; then
  stop_monitor_from_lock "$CANONICAL_MONITOR_LOCK_DIR"
fi
stop_sbotux_orphan_monitors
exit 0
