#!/usr/bin/env python3
from __future__ import annotations

import argparse
import json
import re
import subprocess
import sys
import tempfile
import time
from pathlib import Path
from typing import Any

from codex_ops_adb_check import compact_text, parse_devices, resolve_adb_path, select_device


DEFAULT_KAKAO_PACKAGE = "com.kakao.talk"
ALLOWED_MODES = {"check", "wake_screen", "foreground"}
ADB_UNAVAILABLE_EXIT = 2
CHECK_FAILED_EXIT = 3


def now_ms() -> int:
    return int(time.time() * 1000)


def bool_field(value: Any) -> bool:
    if isinstance(value, bool):
        return value
    if isinstance(value, (int, float)):
        return value != 0
    return str(value or "").strip().lower() in {"1", "true", "yes", "y", "on"}


def kakao_request_requested(item: dict[str, Any]) -> bool:
    return bool_field(item.get("kakao_check")) or bool_field(item.get("kakao_wake"))


def normalize_mode(item: dict[str, Any]) -> str:
    wake_requested = bool_field(item.get("kakao_wake"))
    raw_mode = str(item.get("kakao_wake_mode") or "").strip().lower()
    if raw_mode not in ALLOWED_MODES:
        raw_mode = "foreground" if wake_requested else "check"
    if not wake_requested:
        return "check"
    return raw_mode


def normalize_kakao_spec(item: dict[str, Any]) -> dict[str, Any]:
    mode = normalize_mode(item)
    return {
        "enabled": kakao_request_requested(item),
        "mode": mode,
        "adb_path": str(item.get("adb_path") or "").strip(),
        "serial": str(item.get("kakao_serial") or item.get("adb_serial") or item.get("serial") or "").strip(),
        "package": str(item.get("kakao_package") or item.get("package") or DEFAULT_KAKAO_PACKAGE).strip()
        or DEFAULT_KAKAO_PACKAGE,
        "screenshot": bool_field(item.get("kakao_screenshot") or item.get("screenshot")),
        "logcat_tail": max(0, int(item.get("kakao_logcat_tail") or item.get("logcat_tail") or 0)),
        "timeout_sec": max(3, int(item.get("kakao_timeout_sec") or item.get("adb_timeout_sec") or 15)),
    }


def _run(cmd: list[str], timeout_sec: int) -> subprocess.CompletedProcess[str]:
    return subprocess.run(
        cmd,
        text=True,
        stdout=subprocess.PIPE,
        stderr=subprocess.PIPE,
        timeout=timeout_sec,
        check=False,
    )


def _adb_base(adb_path: str, serial: str = "") -> list[str]:
    cmd = [adb_path]
    if serial:
        cmd.extend(["-s", serial])
    return cmd


def shell(base: list[str], args: list[str], timeout_sec: int) -> subprocess.CompletedProcess[str]:
    return _run(base + ["shell", *args], timeout_sec)


def command_result(proc: subprocess.CompletedProcess[str], limit: int = 1200) -> dict[str, Any]:
    text = f"{proc.stdout}\n{proc.stderr}".strip()
    return {
        "returncode": proc.returncode,
        "stdout_tail": compact_text(proc.stdout, limit),
        "stderr_tail": compact_text(proc.stderr, limit),
        "output_tail": compact_text(text, limit),
    }


def package_version(text: str) -> dict[str, str]:
    result: dict[str, str] = {}
    for key in ("versionName", "versionCode"):
        match = re.search(rf"\b{key}=([^\s]+)", text)
        if match:
            result[key] = match.group(1)
    return result


def check_package(base: list[str], package_name: str, timeout_sec: int) -> dict[str, Any]:
    pm_path = shell(base, ["pm", "path", package_name], timeout_sec)
    installed = pm_path.returncode == 0 and f"package:" in pm_path.stdout
    dumpsys = shell(base, ["dumpsys", "package", package_name], timeout_sec) if installed else None
    version_text = f"{dumpsys.stdout}\n{dumpsys.stderr}" if dumpsys else ""
    return {
        "package_name": package_name,
        "installed": installed,
        "pm_path": command_result(pm_path),
        "version": package_version(version_text),
    }


def check_pid(base: list[str], package_name: str, timeout_sec: int) -> dict[str, Any]:
    proc = shell(base, ["pidof", package_name], timeout_sec)
    pids = [part for part in proc.stdout.strip().split() if part.isdigit()]
    return {"running": bool(pids), "pids": pids, **command_result(proc, 800)}


def extract_top_package(text: str) -> str:
    patterns = [
        r"mCurrentFocus=.*?\s([A-Za-z0-9_.]+)/[A-Za-z0-9_.$/]+",
        r"mFocusedApp=.*?\s([A-Za-z0-9_.]+)/[A-Za-z0-9_.$/]+",
        r"topResumedActivity=.*?\s([A-Za-z0-9_.]+)/[A-Za-z0-9_.$/]+",
        r"ResumedActivity:.*?\s([A-Za-z0-9_.]+)/[A-Za-z0-9_.$/]+",
    ]
    for pattern in patterns:
        match = re.search(pattern, text)
        if match:
            return match.group(1)
    return ""


def check_foreground(base: list[str], package_name: str, timeout_sec: int) -> dict[str, Any]:
    window_proc = shell(base, ["dumpsys", "window", "windows"], timeout_sec)
    activity_proc = shell(base, ["dumpsys", "activity", "activities"], timeout_sec)
    combined = f"{window_proc.stdout}\n{window_proc.stderr}\n{activity_proc.stdout}\n{activity_proc.stderr}"
    top_package = extract_top_package(combined)
    return {
        "top_package": top_package,
        "is_target": bool(top_package and top_package == package_name),
        "window": command_result(window_proc, 1200),
        "activity": command_result(activity_proc, 1200),
    }


def check_power(base: list[str], timeout_sec: int) -> dict[str, Any]:
    proc = shell(base, ["dumpsys", "power"], timeout_sec)
    text = f"{proc.stdout}\n{proc.stderr}"
    interactive: bool | None = None
    match = re.search(r"\bmInteractive=(true|false)", text)
    if match:
        interactive = match.group(1) == "true"
    elif "Display Power: state=ON" in text or "state=ON" in text:
        interactive = True
    elif "Display Power: state=OFF" in text or "state=OFF" in text:
        interactive = False
    return {"interactive": interactive, **command_result(proc, 1200)}


def check_keyguard(base: list[str], timeout_sec: int) -> dict[str, Any]:
    proc = shell(base, ["dumpsys", "window", "policy"], timeout_sec)
    text = f"{proc.stdout}\n{proc.stderr}"
    locked: bool | None = None
    true_tokens = ("isStatusBarKeyguard=true", "mShowingLockscreen=true", "showing=true")
    false_tokens = ("isStatusBarKeyguard=false", "mShowingLockscreen=false", "showing=false")
    if any(token in text for token in true_tokens):
        locked = True
    elif any(token in text for token in false_tokens):
        locked = False
    return {"locked": locked, **command_result(proc, 1200)}


def take_screenshot(base: list[str], req_id: str, timeout_sec: int) -> dict[str, Any]:
    out_dir = Path(tempfile.gettempdir()) / "codex_ops_kakao_screenshots"
    out_dir.mkdir(parents=True, exist_ok=True)
    safe_req = re.sub(r"[^0-9A-Za-z_.-]+", "_", req_id or "kakao")[:80]
    screenshot_path = out_dir / f"{safe_req}_{now_ms()}.png"
    try:
        proc = subprocess.run(
            base + ["exec-out", "screencap", "-p"],
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE,
            timeout=timeout_sec,
            check=False,
        )
    except Exception as exc:
        return {"status": "failed", "reason": compact_text(exc, 500)}
    if proc.returncode == 0 and proc.stdout:
        screenshot_path.write_bytes(proc.stdout)
        return {"status": "done", "path": str(screenshot_path), "bytes": len(proc.stdout)}
    return {
        "status": "failed",
        "returncode": proc.returncode,
        "stderr_tail": compact_text(proc.stderr.decode("utf-8", errors="replace"), 1200),
    }


def run_kakao_wake(item: dict[str, Any], req_id: str = "") -> dict[str, Any]:
    spec = normalize_kakao_spec(item)
    started = now_ms()
    if not spec.get("enabled"):
        return {"status": "kakao_skipped", "enabled": False, "duration_ms": 0}

    resolver = resolve_adb_path({"adb_path": spec.get("adb_path")})
    adb_path = str(resolver.get("adb_path") or "")
    result: dict[str, Any] = {
        "status": "adb_unavailable",
        "enabled": True,
        "mode": spec["mode"],
        "package": spec["package"],
        "adb_path": adb_path,
        "adb_path_source": resolver.get("adb_path_source") or "",
        "adb_candidates": resolver.get("adb_candidates") or [],
        "serial": "",
        "checks": {},
        "safety": {
            "message_send": False,
            "chat_touch": False,
            "text_input": False,
            "unlock": False,
            "install": False,
            "allowed_actions": ["adb devices", "package/process/top checks", "KEYCODE_WAKEUP", "launcher foreground"],
        },
        "duration_ms": 0,
    }
    if not adb_path:
        result["reason"] = "adb command not found"
        result["duration_ms"] = now_ms() - started
        return result

    timeout_sec = int(spec["timeout_sec"])
    try:
        devices_proc = _run([adb_path, "devices", "-l"], timeout_sec)
    except Exception as exc:
        result["reason"] = compact_text(exc, 500)
        result["duration_ms"] = now_ms() - started
        return result

    devices = parse_devices(devices_proc.stdout)
    serial, select_error = select_device(devices, str(spec.get("serial") or ""))
    result["devices"] = devices
    result["serial"] = serial
    result["checks"]["devices"] = command_result(devices_proc, 1200)
    if select_error:
        result["reason"] = select_error
        result["duration_ms"] = now_ms() - started
        return result

    base = _adb_base(adb_path, serial)
    package_name = str(spec["package"])
    result["checks"]["package"] = check_package(base, package_name, timeout_sec)
    result["checks"]["pid"] = check_pid(base, package_name, timeout_sec)
    result["checks"]["foreground_before"] = check_foreground(base, package_name, timeout_sec)
    result["checks"]["power_before"] = check_power(base, timeout_sec)
    result["checks"]["keyguard_before"] = check_keyguard(base, timeout_sec)
    result["foreground_before_package"] = result["checks"]["foreground_before"].get("top_package") or ""
    result["screen_interactive_before"] = result["checks"]["power_before"].get("interactive")
    result["keyguard_locked_before"] = result["checks"]["keyguard_before"].get("locked")

    if not result["checks"]["package"].get("installed"):
        result["status"] = "kakao_check_failed"
        result["reason"] = f"{package_name} is not installed"
        result["duration_ms"] = now_ms() - started
        return result

    mode = str(spec["mode"])
    if mode in {"wake_screen", "foreground"}:
        proc = shell(base, ["input", "keyevent", "KEYCODE_WAKEUP"], timeout_sec)
        result["checks"]["wake_screen"] = {
            "status": "done" if proc.returncode == 0 else "failed",
            **command_result(proc, 1200),
        }
        time.sleep(0.5)

    if mode == "foreground":
        proc = shell(base, ["monkey", "-p", package_name, "-c", "android.intent.category.LAUNCHER", "1"], timeout_sec)
        result["checks"]["bring_foreground"] = {
            "status": "done" if proc.returncode == 0 else "failed",
            **command_result(proc, 1200),
        }
        time.sleep(1.0)

    result["checks"]["foreground_after"] = check_foreground(base, package_name, timeout_sec)
    result["checks"]["power_after"] = check_power(base, timeout_sec)
    result["checks"]["keyguard_after"] = check_keyguard(base, timeout_sec)
    result["foreground_after_package"] = result["checks"]["foreground_after"].get("top_package") or ""
    result["screen_interactive_after"] = result["checks"]["power_after"].get("interactive")
    result["keyguard_locked_after"] = result["checks"]["keyguard_after"].get("locked")

    if spec.get("screenshot"):
        result["checks"]["screenshot"] = take_screenshot(base, req_id, timeout_sec)

    logcat_tail = int(spec.get("logcat_tail") or 0)
    if logcat_tail:
        proc = _run(base + ["logcat", "-d", "-t", str(logcat_tail)], max(timeout_sec, 30))
        result["checks"]["logcat"] = {
            "status": "done" if proc.returncode == 0 else "failed",
            **command_result(proc, 4000),
        }

    if mode == "foreground":
        foreground_ok = bool(result["checks"]["foreground_after"].get("is_target"))
        bring_ok = result["checks"].get("bring_foreground", {}).get("status") == "done"
        result["status"] = "kakao_wake_done" if foreground_ok and bring_ok else "kakao_wake_failed"
        if not foreground_ok:
            result["reason"] = f"foreground package is {result['foreground_after_package'] or 'unknown'}"
    elif mode == "wake_screen":
        wake_ok = result["checks"].get("wake_screen", {}).get("status") == "done"
        result["status"] = "kakao_wake_done" if wake_ok else "kakao_wake_failed"
    else:
        result["status"] = "kakao_checked"

    result["duration_ms"] = now_ms() - started
    return result


def exit_code_for_result(result: dict[str, Any]) -> int:
    status = str(result.get("status") or "")
    if status in {"kakao_checked", "kakao_wake_done", "kakao_skipped"}:
        return 0
    if status == "adb_unavailable":
        return ADB_UNAVAILABLE_EXIT
    return CHECK_FAILED_EXIT


def parse_args(argv: list[str]) -> argparse.Namespace:
    parser = argparse.ArgumentParser(description="Safe KakaoTalk check/wake helper for codex_ops USB ADB")
    parser.add_argument("--json", action="store_true", help="JSON 결과 출력. 현재 출력은 항상 JSON입니다.")
    parser.add_argument("--adb-path", default="")
    parser.add_argument("--serial", default="")
    parser.add_argument("--package", default=DEFAULT_KAKAO_PACKAGE)
    parser.add_argument("--mode", choices=sorted(ALLOWED_MODES), default="check")
    parser.add_argument("--wake-screen", action="store_true")
    parser.add_argument("--bring-foreground", action="store_true")
    parser.add_argument("--screenshot", action="store_true")
    parser.add_argument("--logcat-tail", type=int, default=0)
    parser.add_argument("--timeout-sec", type=int, default=15)
    parser.add_argument("--request-id", default="")
    return parser.parse_args(argv)


def main(argv: list[str]) -> int:
    args = parse_args(argv)
    mode = args.mode
    wake_requested = args.mode != "check" or args.wake_screen or args.bring_foreground
    if args.bring_foreground:
        mode = "foreground"
        wake_requested = True
    elif args.wake_screen and mode == "check":
        mode = "wake_screen"
        wake_requested = True
    item = {
        "kakao_check": True,
        "kakao_wake": wake_requested,
        "kakao_wake_mode": mode,
        "kakao_package": args.package,
        "adb_path": args.adb_path,
        "adb_serial": args.serial,
        "kakao_screenshot": args.screenshot,
        "kakao_logcat_tail": args.logcat_tail,
        "kakao_timeout_sec": args.timeout_sec,
    }
    result = run_kakao_wake(item, args.request_id)
    print(json.dumps(result, ensure_ascii=False, indent=2))
    return exit_code_for_result(result)


if __name__ == "__main__":
    raise SystemExit(main(sys.argv[1:]))
