#!/usr/bin/env python3
"""Publish one main-approved immutable program request; shadow by default."""

from __future__ import annotations

import argparse
import hashlib
import json
from pathlib import Path
import re
import sys
import time
from typing import Any

ROOT = Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))
from scripts import automation_goal_dispatcher as reducer
from scripts import automation_goal_dispatch_firebase as adapter
from scripts import automation_goal_program_compiler as compiler


PRODUCER = "automation-program-publisher-v1"
PUBLISH_CLOCK_BACKDATE_MS = 5_000


class ProgramPublishError(ValueError):
    def __init__(self, message: str, *, code: str = "invalid_program_publish") -> None:
        super().__init__(message)
        self.code = code


class BoundedArgumentParser(argparse.ArgumentParser):
    def error(self, message: str) -> None:
        print(
            json.dumps({"status": "invalid", "error_code": "invalid_arguments", "error": message}, sort_keys=True),
            file=sys.stderr,
        )
        raise SystemExit(2)


def _immutable_cas(transport: Any, path: str, value: dict[str, Any]) -> str:
    existing, etag = transport.get_with_etag(path)
    if existing is not None:
        if reducer.canonical_hash(existing) != reducer.canonical_hash(value):
            raise ProgramPublishError("immutable projection conflict", code="projection_conflict")
        return "noop"
    if transport.compare_and_put(path, value, etag):
        return "created"
    winner = transport.get(path)
    if reducer.canonical_hash(winner) != reducer.canonical_hash(value):
        raise ProgramPublishError("immutable projection CAS conflict", code="projection_conflict")
    return "noop"


def build_documents(
    *,
    state: dict[str, Any],
    policy: dict[str, Any],
    program_id: str,
    goal_id: str,
    goal_epoch: int,
    worker_revision: str,
    source_revision: str,
    target_node: str,
    resource_id: str,
    model_id: str,
    reasoning_effort: str,
    created_at_ms: int,
    ttl_seconds: int,
    request_id: str | None = None,
) -> dict[str, Any]:
    reducer.validate_policy(policy)
    if not isinstance(state, dict) or reducer.canonical_hash(state) == reducer.canonical_hash({}):
        raise ProgramPublishError("canonical goal state is required")
    state = adapter._hydrate_rtdb_state(state)
    active = state.get("active_goal")
    if not isinstance(active, dict) or active.get("goal_id") != goal_id or active.get("goal_epoch") != goal_epoch:
        raise ProgramPublishError("active goal binding mismatch", code="goal_binding_mismatch")
    if (
        not isinstance(worker_revision, str)
        or re.fullmatch(r"[0-9a-f]{12}|[0-9a-f]{40}", worker_revision) is None
        or not isinstance(source_revision, str)
        or compiler.HEX40.fullmatch(source_revision) is None
        or not source_revision.startswith(worker_revision)
    ):
        raise ProgramPublishError("worker/source revision binding is invalid", code="revision_binding_mismatch")
    seed_policy = policy["program_seed"]
    if not isinstance(ttl_seconds, int) or not 1 <= ttl_seconds <= seed_policy["max_ttl_seconds"]:
        raise ProgramPublishError("ttl_seconds exceeds policy")
    config = compiler._load_json(compiler.DEFAULT_PROGRAMS)
    program = config["programs"][0]
    binding = seed_policy["allowed_programs"].get(program_id)
    local_binding = {
        "program_hash": compiler.program_hash(program),
        "config_hash": reducer.canonical_hash(config),
        "compiler_sha256": hashlib.sha256(Path(compiler.__file__).read_bytes()).hexdigest(),
    }
    if binding != local_binding:
        raise ProgramPublishError("local program attestation differs from policy", code="local_attestation_mismatch")
    compile_request = {
        "schema_version": 1, "program_id": program_id, "goal_id": goal_id,
        "goal_epoch": goal_epoch, "source_revision": source_revision,
        "target_node": target_node, "resource_id": resource_id,
        "model_id": model_id, "reasoning_effort": reasoning_effort,
    }
    compiler.compile_watch_task(compile_request, config, policy)
    identity = {
        "goal_id": goal_id, "goal_epoch": goal_epoch, "program_id": program_id,
        "expected_state_hash": reducer.canonical_hash(state), "worker_revision": worker_revision,
        "source_revision": source_revision,
        "target_node": target_node, "resource_id": resource_id,
        "model_id": model_id, "reasoning_effort": reasoning_effort,
    }
    request_id = adapter._safe_id(request_id, "request_id") if request_id else f"program-{reducer.canonical_hash(identity)[:24]}"
    if not request_id.startswith("program-"):
        raise ProgramPublishError("request_id must use program- namespace")
    sequence_id = f"seq-{created_at_ms:013d}-{reducer.canonical_hash({'request_id': request_id})[:16]}"
    request = {
        "schema_version": 1,
        "request_id": request_id,
        "goal_id": goal_id,
        "goal_epoch": goal_epoch,
        "program_id": program_id,
        **local_binding,
        "expected_state_hash": reducer.canonical_hash(state),
        "worker_revision": worker_revision,
        "source_revision": source_revision,
        "target_node": target_node,
        "resource_id": resource_id,
        "model_id": model_id,
        "reasoning_effort": reasoning_effort,
        "producer": PRODUCER,
        "created_at_ms": created_at_ms,
        "expires_at_ms": created_at_ms + ttl_seconds * 1000,
        "sequence_id": sequence_id,
    }
    request["item_hash"] = reducer.canonical_hash({key: value for key, value in request.items() if key != "item_hash"})
    sequence = {
        "schema_version": 1, "sequence_id": sequence_id, "request_id": request_id,
        "item_hash": request["item_hash"], "created_at_ms": created_at_ms,
    }
    if set(request) != adapter.PROGRAM_REQUEST_FIELDS or set(sequence) != adapter.PROGRAM_SEQUENCE_FIELDS:
        raise ProgramPublishError("internal program projection schema mismatch")
    return {"request": request, "sequence": sequence}


def publish(*, transport: Any, documents: dict[str, Any], apply: bool = False) -> dict[str, Any]:
    request = documents["request"]
    request_path = f"{adapter.PROGRAM_REQUESTS_ROOT}/{request['request_id']}"
    sequence_scope = adapter.scoped_sequence_path(
        adapter.PROGRAM_SEQUENCE_ROOT, request["goal_id"], request["goal_epoch"]
    )
    sequence_path = f"{sequence_scope}/{request['sequence_id']}"
    result = {
        "status": "shadow" if not apply else "published",
        "request_id": request["request_id"], "item_hash": request["item_hash"],
        "request_path": request_path, "sequence_path": sequence_path,
        "receipt_path": f"{adapter.PROGRAM_RECEIPTS_ROOT}/{request['request_id']}",
    }
    if apply:
        result["request_write"] = _immutable_cas(transport, request_path, request)
        result["sequence_write"] = _immutable_cas(transport, sequence_path, documents["sequence"])
    return result


def main(argv: list[str] | None = None) -> int:
    parser = BoundedArgumentParser(description=__doc__)
    parser.add_argument("--program-id", required=True)
    parser.add_argument("--goal-id", required=True)
    parser.add_argument("--goal-epoch", required=True, type=int)
    parser.add_argument("--worker-revision", required=True)
    parser.add_argument("--source-revision", required=True)
    parser.add_argument("--target-node", required=True)
    parser.add_argument("--resource-id", required=True)
    parser.add_argument("--model-id", required=True)
    parser.add_argument("--reasoning-effort", required=True)
    parser.add_argument("--ttl-seconds", type=int, default=3600)
    parser.add_argument("--request-id")
    parser.add_argument("--policy", default=str(reducer.DEFAULT_POLICY))
    parser.add_argument("--apply", action="store_true")
    try:
        args = parser.parse_args(argv)
        policy = reducer.load_policy(args.policy)
        transport = adapter.CodexOpsFirebaseTransport()
        state = transport.get(f"{adapter.AUTOMATION_ROOT}/goals/{args.goal_id}")
        docs = build_documents(
            state=state, policy=policy, program_id=args.program_id,
            goal_id=args.goal_id, goal_epoch=args.goal_epoch,
            worker_revision=args.worker_revision, source_revision=args.source_revision,
            target_node=args.target_node,
            resource_id=args.resource_id, model_id=args.model_id,
            # The resident adapter captures ``now`` once at the beginning of an
            # iteration.  Backdate immutable inbox timestamps slightly so a
            # request discovered later in that same iteration is not mistaken
            # for a future-dated/expired item.
            reasoning_effort=args.reasoning_effort,
            created_at_ms=int(time.time() * 1000) - PUBLISH_CLOCK_BACKDATE_MS,
            ttl_seconds=args.ttl_seconds, request_id=args.request_id,
        )
        print(json.dumps(publish(transport=transport, documents=docs, apply=args.apply), ensure_ascii=False, sort_keys=True))
        return 0
    except SystemExit:
        raise
    except Exception as exc:
        print(json.dumps({"status": "invalid", "error_code": getattr(exc, "code", "program_publish_error"), "error": str(exc)}, ensure_ascii=False, sort_keys=True), file=sys.stderr)
        return 2


if __name__ == "__main__":
    raise SystemExit(main())
