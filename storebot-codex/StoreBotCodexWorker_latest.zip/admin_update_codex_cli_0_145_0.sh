#!/usr/bin/env bash
set -Eeuo pipefail

# Out-of-band, model-0 server-phone Codex CLI updater.
# This script is intentionally fixed-version and accepts no arguments.

TARGET_VERSION="0.145.0"
TARGET_PACKAGE="@openai/codex@0.145.0"
TARGET_INTEGRITY="sha512-/PSPSFujjjmiyVFvG2yu/grOFhsWdokTH8t2KGWhXSo/M5n/dIDsnbsnO82/7bLtIoDuzQf7ATBUMWqPWQINlQ=="
TARGET_NATIVE_PACKAGE="@openai/codex@0.145.0-linux-arm64"
TARGET_NATIVE_INTEGRITY="sha512-8OLcPXaAol/FOrRoDxWhIiHIFa73KRsM41EKocjRZOwiT4TcelzJWn3dHyiuSb7teWF25rrslvSPyvhULYRRCQ=="
EXPECTED_VISIBLE_PATH="/root/.local/bin/codex"
ADMIN_STATE_ROOT="/root/.local/state/wonmux-codex-admin"
RELEASE_PARENT="/root/.local/lib/wonmux-codex"
RELEASE_DIR="$RELEASE_PARENT/$TARGET_VERSION"
RUN_STAMP="$(date -u +%Y%m%dT%H%M%SZ)"
BACKUP_DIR="$ADMIN_STATE_ROOT/backups/$RUN_STAMP"
LOG_DIR="$BACKUP_DIR/logs"
BACKUP_ENTRY="$BACKUP_DIR/codex.visible.entry"
SWITCHED=0
STAGING_DIR=""
DOWNLOAD_DIR=""

if (($# != 0)); then
  echo "arguments_not_allowed" >&2
  exit 64
fi

for required in codex npm node python3 timeout sha256sum readlink cp mv ln mktemp date awk head tr grep find sort tail dirname mkdir rm uname; do
  command -v "$required" >/dev/null 2>&1 || {
    echo "missing_required_command:$required" >&2
    exit 2
  }
done

mkdir -p "$LOG_DIR" "$RELEASE_PARENT" "$(dirname "$EXPECTED_VISIBLE_PATH")"

run_bounded() {
  local label="$1"
  local seconds="$2"
  shift 2
  local log_file="$LOG_DIR/$label.log"
  set +e
  timeout --signal=TERM --kill-after=5s "${seconds}s" "$@" >"$log_file" 2>&1
  local rc=$?
  set -e
  local bounded_log="$log_file.bounded"
  tail -c 12000 "$log_file" >"$bounded_log"
  mv -f -- "$bounded_log" "$log_file"
  if [[ -s "$log_file" ]]; then
    tail -c 12000 "$log_file"
    printf '\n'
  fi
  if ((rc != 0)); then
    echo "bounded_command_failed:$label:$rc" >&2
    return "$rc"
  fi
}

restore_visible_entry() {
  if ((SWITCHED == 0)); then
    return 0
  fi
  local restore_tmp
  restore_tmp="$(dirname "$EXPECTED_VISIBLE_PATH")/.codex.restore.$RUN_STAMP"
  cp -a -- "$BACKUP_ENTRY" "$restore_tmp"
  mv -Tf -- "$restore_tmp" "$EXPECTED_VISIBLE_PATH"
  SWITCHED=0
  echo "rollback_restored_visible_entry" >&2
}

cleanup() {
  local rc=$?
  if ((rc != 0)); then
    restore_visible_entry || true
  fi
  if [[ -n "$STAGING_DIR" && -d "$STAGING_DIR" ]]; then
    rm -rf -- "$STAGING_DIR"
  fi
  if [[ -n "$DOWNLOAD_DIR" && -d "$DOWNLOAD_DIR" ]]; then
    rm -rf -- "$DOWNLOAD_DIR"
  fi
  exit "$rc"
}
trap cleanup EXIT
trap 'exit 130' INT
trap 'exit 143' TERM

CURRENT_PATH="$(command -v codex)"
if [[ "$CURRENT_PATH" != "$EXPECTED_VISIBLE_PATH" ]]; then
  echo "unexpected_codex_path:$CURRENT_PATH" >&2
  exit 3
fi
CURRENT_REAL_PATH="$(readlink -f "$CURRENT_PATH")"
NODE_ARCH="$(node -p 'process.arch')"
MACHINE_ARCH="$(uname -m)"
if [[ "$NODE_ARCH" != "arm64" || "$MACHINE_ARCH" != "aarch64" ]]; then
  echo "unexpected_architecture:node=$NODE_ARCH:machine=$MACHINE_ARCH" >&2
  exit 3
fi
CURRENT_ENTRY_SHA256="$(sha256sum "$CURRENT_REAL_PATH" | awk '{print $1}')"
run_bounded preflight_version 15 "$CURRENT_PATH" --version
CURRENT_VERSION_LINE="$(head -n 1 "$LOG_DIR/preflight_version.log" | tr -d '\r')"
if [[ ! "$CURRENT_VERSION_LINE" =~ ^codex-cli[[:space:]]+[0-9]+\.[0-9]+\.[0-9]+([.-][0-9A-Za-z.-]+)?$ ]]; then
  echo "unrecognized_current_version:$CURRENT_VERSION_LINE" >&2
  exit 4
fi

run_bounded npm_registry_contract 30 npm view "$TARGET_PACKAGE" version dist.integrity --json
python3 - "$LOG_DIR/npm_registry_contract.log" "$TARGET_VERSION" "$TARGET_INTEGRITY" <<'PY'
import json
import sys
from pathlib import Path

payload = json.loads(Path(sys.argv[1]).read_text(encoding="utf-8"))
if payload.get("version") != sys.argv[2]:
    raise SystemExit("registry_version_mismatch")
if payload.get("dist.integrity") != sys.argv[3]:
    raise SystemExit("registry_integrity_mismatch")
PY
run_bounded npm_registry_native_contract 30 npm view "$TARGET_NATIVE_PACKAGE" version dist.integrity --json
python3 - "$LOG_DIR/npm_registry_native_contract.log" "0.145.0-linux-arm64" "$TARGET_NATIVE_INTEGRITY" <<'PY'
import json
import sys
from pathlib import Path

payload = json.loads(Path(sys.argv[1]).read_text(encoding="utf-8"))
if payload.get("version") != sys.argv[2]:
    raise SystemExit("native_registry_version_mismatch")
if payload.get("dist.integrity") != sys.argv[3]:
    raise SystemExit("native_registry_integrity_mismatch")
PY

# Verify the downloaded native tarball bytes independently of npm's registry
# metadata response. The bounded temporary payload is deleted on every exit;
# only its digest, size and verified SRI are retained as admin evidence.
DOWNLOAD_DIR="$(mktemp -d "$ADMIN_STATE_ROOT/.native-download.XXXXXX")"
run_bounded npm_pack_native 120 npm pack "$TARGET_NATIVE_PACKAGE" \
  --pack-destination "$DOWNLOAD_DIR" --ignore-scripts
python3 - "$DOWNLOAD_DIR" "$TARGET_NATIVE_INTEGRITY" "$BACKUP_DIR/native-tarball-evidence.json" <<'PY'
import base64
import hashlib
import json
import sys
from pathlib import Path

download_dir = Path(sys.argv[1])
expected_sri = sys.argv[2]
evidence_path = Path(sys.argv[3])
tarballs = sorted(download_dir.glob("*.tgz"))
if len(tarballs) != 1 or not tarballs[0].is_file():
    raise SystemExit("native_tarball_count_mismatch")
sha512_digest = hashlib.sha512()
sha256_digest = hashlib.sha256()
size = 0
with tarballs[0].open("rb") as handle:
    for chunk in iter(lambda: handle.read(1024 * 1024), b""):
        sha512_digest.update(chunk)
        sha256_digest.update(chunk)
        size += len(chunk)
computed_sri = "sha512-" + base64.b64encode(sha512_digest.digest()).decode("ascii")
if computed_sri != expected_sri:
    raise SystemExit("native_tarball_sri_mismatch")
payload = {
    "file_name": tarballs[0].name,
    "size": size,
    "sha256": sha256_digest.hexdigest(),
    "computed_sri": computed_sri,
    "expected_sri": expected_sri,
    "sri_verified": True,
}
evidence_path.write_text(json.dumps(payload, indent=2, sort_keys=True) + "\n", encoding="utf-8")
PY

cp -a -- "$CURRENT_PATH" "$BACKUP_ENTRY"
{
  printf 'target_version=%s\n' "$TARGET_VERSION"
  printf 'target_package=%s\n' "$TARGET_PACKAGE"
  printf 'target_integrity=%s\n' "$TARGET_INTEGRITY"
  printf 'target_native_package=%s\n' "$TARGET_NATIVE_PACKAGE"
  printf 'target_native_integrity=%s\n' "$TARGET_NATIVE_INTEGRITY"
  printf 'node_arch=%s\n' "$NODE_ARCH"
  printf 'machine_arch=%s\n' "$MACHINE_ARCH"
  printf 'current_path=%s\n' "$CURRENT_PATH"
  printf 'current_real_path=%s\n' "$CURRENT_REAL_PATH"
  printf 'current_version=%s\n' "$CURRENT_VERSION_LINE"
  printf 'current_entry_sha256=%s\n' "$CURRENT_ENTRY_SHA256"
  printf 'backup_created_at=%s\n' "$RUN_STAMP"
} >"$BACKUP_DIR/package-state.env"
run_bounded npm_prefix_before 15 npm prefix --global
run_bounded npm_root_before 15 npm root --global
run_bounded npm_package_before 20 npm ls --global @openai/codex --json --depth=0 || true

CODEX_STATE_ROOT="${CODEX_HOME:-/root/.codex}"
AUTH_HASH_BEFORE="absent"
if [[ -f "$CODEX_STATE_ROOT/auth.json" ]]; then
  AUTH_HASH_BEFORE="$(sha256sum "$CODEX_STATE_ROOT/auth.json" | awk '{print $1}')"
fi

printf 'auth_sha256_before=%s\n' "$AUTH_HASH_BEFORE" >>"$BACKUP_DIR/package-state.env"
if [[ -d "$CODEX_STATE_ROOT/packages/standalone" ]]; then
  find "$CODEX_STATE_ROOT/packages/standalone" -maxdepth 4 -type f -printf '%P\t%s\t%T@\n' \
    | LC_ALL=C sort >"$BACKUP_DIR/standalone-package-state.tsv"
fi

if [[ -x "$RELEASE_DIR/bin/codex" ]]; then
  run_bounded staged_existing_version 15 "$RELEASE_DIR/bin/codex" --version
  grep -Fxq "codex-cli $TARGET_VERSION" "$LOG_DIR/staged_existing_version.log" || {
    echo "existing_release_version_mismatch" >&2
    exit 5
  }
else
  if [[ -e "$RELEASE_DIR" ]]; then
    echo "existing_release_not_executable:$RELEASE_DIR" >&2
    exit 5
  fi
  STAGING_DIR="$(mktemp -d "$RELEASE_PARENT/.${TARGET_VERSION}.tmp.XXXXXX")"
  run_bounded npm_install_fixed 240 npm install --global --prefix "$STAGING_DIR" --no-audit --no-fund "$TARGET_PACKAGE"
  [[ -x "$STAGING_DIR/bin/codex" ]] || {
    echo "staged_codex_missing" >&2
    exit 6
  }
  run_bounded staged_version 15 "$STAGING_DIR/bin/codex" --version
  grep -Fxq "codex-cli $TARGET_VERSION" "$LOG_DIR/staged_version.log" || {
    echo "staged_version_mismatch" >&2
    exit 6
  }
  mv -- "$STAGING_DIR" "$RELEASE_DIR"
  STAGING_DIR=""
fi

NATIVE_PACKAGE_JSON="$(find "$RELEASE_DIR/lib/node_modules" -path '*/@openai/codex-linux-arm64/package.json' -type f -print -quit)"
if [[ -z "$NATIVE_PACKAGE_JSON" ]]; then
  echo "native_arm64_package_missing" >&2
  exit 6
fi
NATIVE_PACKAGE_DIR="$(dirname "$NATIVE_PACKAGE_JSON")"
NATIVE_PAYLOAD="$NATIVE_PACKAGE_DIR/vendor/aarch64-unknown-linux-musl/bin/codex"
[[ -x "$NATIVE_PAYLOAD" ]] || {
  echo "native_arm64_payload_missing" >&2
  exit 6
}
python3 - "$NATIVE_PACKAGE_JSON" <<'PY'
import json
import sys
from pathlib import Path

payload = json.loads(Path(sys.argv[1]).read_text(encoding="utf-8"))
if payload.get("version") != "0.145.0-linux-arm64":
    raise SystemExit("native_installed_version_mismatch")
PY
NATIVE_PACKAGE_JSON_SHA256="$(sha256sum "$NATIVE_PACKAGE_JSON" | awk '{print $1}')"
NATIVE_PAYLOAD_SHA256="$(sha256sum "$NATIVE_PAYLOAD" | awk '{print $1}')"

LINK_TMP="$(dirname "$EXPECTED_VISIBLE_PATH")/.codex.switch.$RUN_STAMP"
ln -s -- "$RELEASE_DIR/bin/codex" "$LINK_TMP"
mv -Tf -- "$LINK_TMP" "$EXPECTED_VISIBLE_PATH"
SWITCHED=1

run_bounded post_1_version 15 "$EXPECTED_VISIBLE_PATH" --version
grep -Fxq "codex-cli $TARGET_VERSION" "$LOG_DIR/post_1_version.log" || {
  echo "post_version_mismatch" >&2
  exit 7
}
run_bounded post_2_help 20 "$EXPECTED_VISIBLE_PATH" --help
run_bounded post_3_exec_help 20 "$EXPECTED_VISIBLE_PATH" exec --ignore-user-config --help
run_bounded post_4_resume_help 20 "$EXPECTED_VISIBLE_PATH" exec --ignore-user-config resume --help

AUTH_HASH_AFTER="absent"
if [[ -f "$CODEX_STATE_ROOT/auth.json" ]]; then
  AUTH_HASH_AFTER="$(sha256sum "$CODEX_STATE_ROOT/auth.json" | awk '{print $1}')"
fi
if [[ "$AUTH_HASH_AFTER" != "$AUTH_HASH_BEFORE" ]]; then
  echo "auth_state_changed" >&2
  exit 8
fi

NEW_REAL_PATH="$(readlink -f "$EXPECTED_VISIBLE_PATH")"
NEW_ENTRY_SHA256="$(sha256sum "$NEW_REAL_PATH" | awk '{print $1}')"
python3 - "$BACKUP_DIR/install-evidence.json" "$BACKUP_DIR/native-tarball-evidence.json" <<PY
import json
import sys
from pathlib import Path

native_tarball = json.loads(Path(sys.argv[2]).read_text(encoding="utf-8"))
payload = {
    "status": "PASS",
    "mode": "model-0-out-of-band",
    "target_version": "$TARGET_VERSION",
    "target_package": "$TARGET_PACKAGE",
    "target_integrity": "$TARGET_INTEGRITY",
    "target_native_package": "$TARGET_NATIVE_PACKAGE",
    "target_native_integrity": "$TARGET_NATIVE_INTEGRITY",
    "previous_version": "$CURRENT_VERSION_LINE",
    "previous_path": "$CURRENT_REAL_PATH",
    "previous_sha256": "$CURRENT_ENTRY_SHA256",
    "visible_path": "$EXPECTED_VISIBLE_PATH",
    "installed_path": "$NEW_REAL_PATH",
    "installed_sha256": "$NEW_ENTRY_SHA256",
    "native_package_json": "$NATIVE_PACKAGE_JSON",
    "native_package_json_sha256": "$NATIVE_PACKAGE_JSON_SHA256",
    "native_payload": "$NATIVE_PAYLOAD",
    "native_payload_sha256": "$NATIVE_PAYLOAD_SHA256",
    "native_payload_executable": True,
    "native_tarball": native_tarball,
    "native_tarball_sri_verified": native_tarball.get("sri_verified") is True,
    "backup_dir": "$BACKUP_DIR",
    "auth_sha256_unchanged": True,
    "binary_probes_only": True,
    "lifecycle_hook_fresh_turn_proof_required": True,
    "probes": [
        "codex --version",
        "codex --help",
        "codex exec --ignore-user-config --help",
        "codex exec --ignore-user-config resume --help",
    ],
    "uninstall_performed": False,
    "data_clear_performed": False,
    "auth_overwrite_performed": False,
}
Path(sys.argv[1]).write_text(json.dumps(payload, indent=2, sort_keys=True) + "\n", encoding="utf-8")
print(json.dumps(payload, sort_keys=True))
PY

rm -rf -- "$DOWNLOAD_DIR"
DOWNLOAD_DIR=""
SWITCHED=0
trap - EXIT INT TERM
echo "PASS evidence=$BACKUP_DIR/install-evidence.json"
