#!/usr/bin/env python3
"""Generic masked AI Ops project report to Telegram CA lifecycle.

This module performs no network I/O by itself. Callers inject a durable CAS
repository and an already registered CA room. Raw monitor messages/context are
never copied; only project/domain/severity and typed issue codes survive.
"""

from __future__ import annotations

import hashlib
import hmac
import json
import re
import threading
from copy import deepcopy
from dataclasses import dataclass
from pathlib import Path
from typing import Any, Callable, Mapping, Protocol


REGISTRY_SCHEMA = "project.telegram_ca_registry.v1"
EVENT_SCHEMA = "project.telegram_ca_event.v1"
TASK_SCHEMA = "project.telegram_ca_task.v1"
RECEIPT_SCHEMA = "project.telegram_ca_receipt.v1"
PROJECTION_SCHEMA = "project.telegram_ca_projection.v1"
PAYLOAD_SCHEMA = "project.telegram_ca_payload.v1"
DELIVERY_SCHEMA = "project.telegram_ca_delivery.v1"
DELIVERY_KIND = "generic_project_ops_event"
BASE_PATH = "/packhelper/openclaw_telegram_gate/project_ca"
EVENTS_PATH = f"{BASE_PATH}/events"
TASKS_PATH = f"{BASE_PATH}/tasks"
PROJECTIONS_PATH = f"{BASE_PATH}/projections"
PAYLOADS_PATH = f"{BASE_PATH}/payloads"
RATE_PATH = f"{BASE_PATH}/rate"
DELIVERIES_PATH = "/packhelper/openclaw_telegram_gate/deliveries"
SEVERITIES = {"ok": 0, "info": 0, "warn": 1, "error": 2, "critical": 3}
TOKEN_RE = re.compile(r"^[A-Za-z][A-Za-z0-9_.:-]{0,79}$")
DOMAIN_RE = re.compile(r"^[a-z][a-z0-9_]{1,63}$")
ROOM_RE = re.compile(r"^-[0-9]+$")


class ProjectCaError(ValueError):
    pass


@dataclass(frozen=True)
class Snapshot:
    revision: Any
    value: Mapping[str, Any]


@dataclass(frozen=True)
class CasResult:
    created: bool
    value: Mapping[str, Any]
    contention: bool = False


class ProjectCaRepository(Protocol):
    def read(self, path: str) -> Snapshot: ...
    def reserve(self, path: str, value: Mapping[str, Any]) -> CasResult: ...
    def cas(self, path: str, revision: Any, value: Mapping[str, Any]) -> CasResult: ...


class FakeProjectCaRepository:
    """Shared-state test repository with CAS and restart semantics."""

    def __init__(self, shared: dict[str, Any] | None = None) -> None:
        self._shared = shared if shared is not None else {}
        self._shared.setdefault("values", {})
        self._shared.setdefault("revisions", {})
        self._lock = self._shared.setdefault("lock", threading.Lock())

    def read(self, path: str) -> Snapshot:
        with self._lock:
            return Snapshot(
                self._shared["revisions"].get(path, 0),
                deepcopy(self._shared["values"].get(path) or {}),
            )

    def reserve(self, path: str, value: Mapping[str, Any]) -> CasResult:
        candidate = dict(value)
        with self._lock:
            existing = self._shared["values"].get(path)
            if isinstance(existing, dict):
                if existing != candidate:
                    raise ProjectCaError("conflicting reservation")
                return CasResult(False, deepcopy(existing))
            self._shared["values"][path] = deepcopy(candidate)
            self._shared["revisions"][path] = 1
            return CasResult(True, candidate)

    def cas(self, path: str, revision: Any, value: Mapping[str, Any]) -> CasResult:
        candidate = dict(value)
        with self._lock:
            current_revision = self._shared["revisions"].get(path, 0)
            current = deepcopy(self._shared["values"].get(path) or {})
            if revision != current_revision:
                return CasResult(False, current, contention=True)
            self._shared["values"][path] = deepcopy(candidate)
            self._shared["revisions"][path] = int(current_revision) + 1
            return CasResult(True, candidate)


class FirebaseProjectCaRepository:
    """Injected Firebase CAS adapter. Construction and import perform no I/O."""

    def __init__(
        self,
        *,
        read_with_etag: Callable[[str], tuple[Any, Any]],
        conditional_put: Callable[[str, Mapping[str, Any], Any], bool],
    ) -> None:
        self._read_with_etag = read_with_etag
        self._conditional_put = conditional_put

    def read(self, path: str) -> Snapshot:
        value, revision = self._read_with_etag(path)
        if value in (None, {}):
            value = {}
        if not isinstance(value, Mapping):
            raise ProjectCaError("durable record is not an object")
        return Snapshot(revision, dict(value))

    def reserve(self, path: str, value: Mapping[str, Any]) -> CasResult:
        candidate = dict(value)
        for _ in range(4):
            current = self.read(path)
            if current.value:
                if dict(current.value) != candidate:
                    raise ProjectCaError("conflicting durable reservation")
                return CasResult(False, dict(current.value))
            if self._conditional_put(path, candidate, current.revision):
                return CasResult(True, candidate)
        raise ProjectCaError("durable reservation contention")

    def cas(self, path: str, revision: Any, value: Mapping[str, Any]) -> CasResult:
        current = self.read(path)
        if current.revision != revision:
            return CasResult(False, dict(current.value), contention=True)
        candidate = dict(value)
        if not self._conditional_put(path, candidate, revision):
            return CasResult(False, dict(current.value), contention=True)
        return CasResult(True, candidate)


def load_registry(path: str | Path) -> dict[str, Any]:
    try:
        registry = json.loads(Path(path).read_text(encoding="utf-8"))
    except (OSError, json.JSONDecodeError) as exc:
        raise ProjectCaError("project CA registry unavailable") from exc
    validate_registry(registry)
    return registry


def validate_registry(registry: Mapping[str, Any]) -> None:
    if registry.get("schema") != REGISTRY_SCHEMA:
        raise ProjectCaError("project CA registry schema")
    if not str(registry.get("source_path") or "").startswith("/packhelper/ai_ops_monitor"):
        raise ProjectCaError("project CA source path")
    if int(registry.get("max_snapshot_age_ms") or 0) not in range(60_000, 900_001):
        raise ProjectCaError("project CA snapshot age")
    projects = registry.get("projects")
    if not isinstance(projects, Mapping) or len(projects) != 8:
        raise ProjectCaError("project CA registry must contain eight projects")
    for project, raw in projects.items():
        if not TOKEN_RE.fullmatch(str(project)) or not isinstance(raw, Mapping):
            raise ProjectCaError("project CA project record")
        if not DOMAIN_RE.fullmatch(str(raw.get("domain") or "")):
            raise ProjectCaError("project CA domain")
        if int(raw.get("cooldown_sec") or 0) not in range(0, 3601):
            raise ProjectCaError("project CA cooldown")
        if int(raw.get("max_per_hour") or 0) not in range(1, 61):
            raise ProjectCaError("project CA hourly limit")
        if not isinstance(raw.get("live_delivery_allowed"), bool):
            raise ProjectCaError("project CA live delivery policy")


class ProjectCaLifecycle:
    def __init__(
        self,
        *,
        registry: Mapping[str, Any],
        repository: ProjectCaRepository,
        identity_key: bytes,
        room_id: str,
    ) -> None:
        validate_registry(registry)
        if len(identity_key) < 32:
            raise ProjectCaError("project CA identity key")
        if not ROOM_RE.fullmatch(str(room_id)):
            raise ProjectCaError("project CA room")
        self.registry = dict(registry)
        self.repository = repository
        self.identity_key = bytes(identity_key)
        self.room_id = str(room_id)

    def ingest_snapshot(
        self, snapshot: Mapping[str, Any], *, now_ms: int, live_send_enabled: bool = False
    ) -> dict[str, Any]:
        checked_at = int(snapshot.get("checked_at_ms") or 0)
        max_age = int(self.registry["max_snapshot_age_ms"])
        if checked_at <= 0 or checked_at > now_ms + 30_000 or now_ms - checked_at > max_age:
            raise ProjectCaError("monitor snapshot stale")
        reports = snapshot.get("projects")
        if not isinstance(reports, Mapping):
            raise ProjectCaError("monitor projects missing")
        outcomes = []
        for project, policy in self.registry["projects"].items():
            report = reports.get(project)
            if not isinstance(report, Mapping):
                outcomes.append({"project": project, "status": "missing"})
                continue
            outcomes.append(
                self._ingest_project(project, policy, report, checked_at, now_ms, live_send_enabled)
            )
        return {
            "status": "projected_no_send" if not live_send_enabled else "live_transport_prepared",
            "project_count": len(outcomes),
            "projected": sum(item.get("status") in {"projected", "replayed"} for item in outcomes),
            "throttled": sum(item.get("status") == "throttled" for item in outcomes),
            "outcomes": outcomes,
            "no_send": not live_send_enabled,
        }

    def _ingest_project(
        self,
        project: str,
        policy: Mapping[str, Any],
        report: Mapping[str, Any],
        checked_at: int,
        now_ms: int,
        live_send_enabled: bool,
    ) -> dict[str, Any]:
        domain = str(report.get("domain") or "")
        if domain != policy["domain"]:
            return {"project": project, "status": "rejected_domain"}
        severity = str(report.get("severity") or "")
        if severity not in SEVERITIES:
            return {"project": project, "status": "rejected_severity"}
        issue_codes = _issue_codes(report.get("issues"))
        fingerprint = self._id("fp", {"project": project, "domain": domain, "severity": severity, "codes": issue_codes})
        occurrence_id = self._id("occ", {"project": project, "checked_at_ms": checked_at, "fingerprint": fingerprint})
        admitted = self._admit(project, policy, occurrence_id, fingerprint, severity, now_ms)
        if not admitted:
            return {"project": project, "status": "throttled", "occurrence_id": occurrence_id}

        event_id = self._id("evt", {"occurrence_id": occurrence_id})
        task_id = self._id("task", {"event_id": event_id})
        projection_id = self._id("proj", {"task_id": task_id})
        delivery_id = self._id("pca", {"projection_id": projection_id, "room_id": self.room_id})
        fencing_token = self._id("fence", {"task_id": task_id, "lease_epoch": 1})
        # Immutable occurrence records must be byte-for-byte reproducible after
        # a worker restart.  The monitor timestamp, not the poll time, is their
        # durable creation clock.
        record_ms = checked_at
        self_fix = report.get("self_fix") if isinstance(report.get("self_fix"), Mapping) else {}
        self_fix_ref = (
            self._id("fixref", {"project": project, "request_id": str(self_fix.get("request_id") or "")})
            if self_fix.get("request_id") else ""
        )
        event = {
            "schema": EVENT_SCHEMA,
            "event_id": event_id,
            "occurrence_id": occurrence_id,
            "project": project,
            "domain": domain,
            "severity": severity,
            "issue_codes": issue_codes,
            "source_checked_at_ms": checked_at,
            "observed_at_ms": record_ms,
            "source_ref": f"{self.registry['source_path']}/projects/{project}",
            "masked": True,
            "self_fix_status": _safe_token(self_fix.get("status"), allow_empty=True),
            "existing_self_fix_ref": self_fix_ref,
            "no_send": True,
            "kakao_authority": False,
        }
        event_created = self.repository.reserve(f"{EVENTS_PATH}/{event_id}", event).created
        receipts = {}
        for sequence, (transition, status) in enumerate(
            (("request", "pending"), ("claim", "running"), ("worker_started", "running"), ("result", "completed")),
            start=1,
        ):
            receipt = self._receipt(task_id, transition, status, sequence, record_ms, fencing_token)
            receipts[receipt["receipt_id"]] = receipt
        task = {
            "schema": TASK_SCHEMA,
            "task_id": task_id,
            "project": project,
            "event_ref": event_id,
            "lease_epoch": 1,
            "fencing_token": fencing_token,
            "sequence": 4,
            "last_transition": "result",
            "receipts": receipts,
            "safety_boundary": "masked_status_only_existing_self_fix_no_kakao_no_business_action",
        }
        self._reserve_initial_task(task)
        projection = {
            "schema": PROJECTION_SCHEMA,
            "projection_id": projection_id,
            "task_id": task_id,
            "project": project,
            "severity": severity,
            "issue_codes": issue_codes,
            "receipt_refs": list(receipts),
            "existing_self_fix_ref": self_fix_ref,
            "fencing_token": fencing_token,
            "created_at_ms": record_ms,
            "masked": True,
        }
        self.repository.reserve(f"{PROJECTIONS_PATH}/{projection_id}", projection)
        message = _message(project, severity, issue_codes, projection_id, self_fix_ref)
        payload = {
            "schema": PAYLOAD_SCHEMA,
            "request_id": delivery_id,
            "project": project,
            "status": "ready",
            "message": message,
            "projection_ref": projection_id,
            "created_at_ms": record_ms,
        }
        payload_path = f"{PAYLOADS_PATH}/{delivery_id}"
        self.repository.reserve(payload_path, payload)
        sendable = bool(live_send_enabled and policy.get("live_delivery_allowed") is True)
        delivery = {
            "schema": DELIVERY_SCHEMA,
            "request_id": delivery_id,
            "task_id": task_id,
            "project": project,
            "domain": domain,
            "delivery_kind": DELIVERY_KIND,
            "status": "waiting" if sendable else "prepared_no_send",
            "lifecycle_state": "projection_ready",
            "queue": "generic_project_ca_status",
            "request_path": payload_path,
            "result_path": payload_path,
            "target": "serverphone",
            "target_node": "subphone_termux_ops",
            "resource_id": "subphone_termux_ops",
            "reply_account_id": "serverphone",
            "conversation_id": self.room_id,
            "room_kind": "ca_expert",
            "created_at_ms": record_ms,
            "expires_at_ms": record_ms + 24 * 60 * 60 * 1000,
            "attempt_count": 0,
            "next_attempt_at_ms": 0,
            "lease_epoch": 1,
            "fencing_token": fencing_token,
            "no_send": not sendable,
            "sent": False,
            "kakao_authority": False,
            "business_action_authority": False,
        }
        persisted_delivery = self._reserve_initial_delivery(delivery)
        return {
            "project": project,
            "status": "projected" if event_created else "replayed",
            "event_id": event_id,
            "task_id": task_id,
            "delivery_id": delivery_id,
            "no_send": persisted_delivery.get("no_send") is not False,
        }

    def _reserve_initial_task(self, task: Mapping[str, Any]) -> None:
        path = f"{TASKS_PATH}/{task['task_id']}"
        snapshot = self.repository.read(path)
        if not snapshot.value:
            self.repository.reserve(path, task)
            return
        existing = snapshot.value
        if (
            existing.get("schema") != TASK_SCHEMA
            or existing.get("task_id") != task.get("task_id")
            or existing.get("project") != task.get("project")
            or existing.get("event_ref") != task.get("event_ref")
            or existing.get("lease_epoch") != task.get("lease_epoch")
            or existing.get("fencing_token") != task.get("fencing_token")
        ):
            raise ProjectCaError("project CA task replay binding")
        existing_receipts = existing.get("receipts")
        if not isinstance(existing_receipts, Mapping):
            raise ProjectCaError("project CA task replay receipts")
        for receipt_id, initial in task["receipts"].items():
            if existing_receipts.get(receipt_id) != initial:
                raise ProjectCaError("project CA initial receipt replay binding")

    def _reserve_initial_delivery(self, delivery: Mapping[str, Any]) -> Mapping[str, Any]:
        path = f"{DELIVERIES_PATH}/{delivery['request_id']}"
        snapshot = self.repository.read(path)
        if not snapshot.value:
            return self.repository.reserve(path, delivery).value
        existing = snapshot.value
        for field in (
            "schema",
            "request_id",
            "task_id",
            "project",
            "domain",
            "delivery_kind",
            "request_path",
            "conversation_id",
            "room_kind",
            "lease_epoch",
            "fencing_token",
            "kakao_authority",
            "business_action_authority",
        ):
            if existing.get(field) != delivery.get(field):
                raise ProjectCaError("project CA delivery replay binding")
        return existing

    def _admit(
        self,
        project: str,
        policy: Mapping[str, Any],
        occurrence_id: str,
        fingerprint: str,
        severity: str,
        now_ms: int,
    ) -> bool:
        path = f"{RATE_PATH}/{project}"
        for _ in range(6):
            snapshot = self.repository.read(path)
            current = dict(snapshot.value)
            decisions = dict(current.get("decisions") or {})
            previous_decision = decisions.get(occurrence_id)
            if isinstance(previous_decision, Mapping):
                return previous_decision.get("decision") == "admitted"
            if current.get("last_occurrence_id") == occurrence_id:
                return current.get("last_decision") == "admitted"
            window_start = int(current.get("window_start_ms") or now_ms)
            count = int(current.get("window_count") or 0)
            if now_ms - window_start >= 60 * 60 * 1000 or now_ms < window_start:
                window_start, count = now_ms, 0
            last_at = int(current.get("last_admitted_at_ms") or 0)
            same = current.get("last_fingerprint") == fingerprint
            severity_increased = SEVERITIES[severity] > SEVERITIES.get(str(current.get("last_severity")), -1)
            cooldown = int(policy["cooldown_sec"]) * 1000
            admitted = count < int(policy["max_per_hour"]) and (
                not same or severity_increased or last_at <= 0 or now_ms - last_at >= cooldown
            )
            replacement = dict(current)
            replacement.update({"last_occurrence_id": occurrence_id, "last_decision": "admitted" if admitted else "throttled"})
            decisions[occurrence_id] = {
                "decision": "admitted" if admitted else "throttled",
                "decided_at_ms": now_ms,
            }
            if len(decisions) > 64:
                ordered = sorted(
                    decisions.items(),
                    key=lambda item: int(item[1].get("decided_at_ms") or 0),
                    reverse=True,
                )[:64]
                decisions = dict(ordered)
            replacement["decisions"] = decisions
            if admitted:
                replacement.update({
                    "window_start_ms": window_start,
                    "window_count": count + 1,
                    "last_admitted_at_ms": now_ms,
                    "last_fingerprint": fingerprint,
                    "last_severity": severity,
                })
            result = self.repository.cas(path, snapshot.revision, replacement)
            if result.created:
                return admitted
        raise ProjectCaError("project CA rate CAS contention")

    def _receipt(
        self, task_id: str, transition: str, status: str, sequence: int, now_ms: int, fencing_token: str
    ) -> dict[str, Any]:
        receipt_id = self._id("rcpt", {"task_id": task_id, "transition": transition, "sequence": sequence})
        return {
            "schema": RECEIPT_SCHEMA,
            "receipt_id": receipt_id,
            "task_id": task_id,
            "transition": transition,
            "status": status,
            "sequence": sequence,
            "attempt": 1,
            "lease_epoch": 1,
            "fencing_token": fencing_token,
            "resource": "subphone_termux_ops",
            "occurred_at_ms": now_ms,
            "no_send": True,
            "sent": False,
        }

    def _id(self, prefix: str, value: Mapping[str, Any]) -> str:
        raw = json.dumps(value, ensure_ascii=False, sort_keys=True, separators=(",", ":")).encode("utf-8")
        return f"{prefix}_{hmac.new(self.identity_key, raw, hashlib.sha256).hexdigest()[:32]}"


def pending_item(
    repository: ProjectCaRepository, request_id: str, *, now_ms: int, room_id: str
) -> dict[str, Any] | None:
    delivery = dict(repository.read(f"{DELIVERIES_PATH}/{request_id}").value)
    _validate_delivery(delivery, request_id=request_id, room_id=room_id, require_sendable=True)
    _validate_task_binding(repository, delivery)
    if int(delivery.get("expires_at_ms") or 0) <= now_ms:
        return None
    if delivery.get("status") not in {"waiting", "retry"} or delivery.get("sent") is True:
        return None
    if int(delivery.get("next_attempt_at_ms") or 0) > now_ms:
        return None
    payload = dict(repository.read(str(delivery["request_path"])).value)
    if (
        payload.get("schema") != PAYLOAD_SCHEMA
        or payload.get("request_id") != request_id
        or payload.get("project") != delivery.get("project")
        or payload.get("status") != "ready"
    ):
        raise ProjectCaError("project CA payload binding")
    return {
        "request_id": request_id,
        "ingress_account_id": "serverphone",
        "reply_account_id": "serverphone",
        "conversation_id": room_id,
        "thread_id": "",
        "source_message_id": "",
        "delivery_kind": DELIVERY_KIND,
        "ca_role": "project_status",
        "message": str(payload.get("message") or "")[:1200],
    }


def mark_delivery(
    repository: ProjectCaRepository,
    request_id: str,
    *,
    room_id: str,
    now_ms: int,
    delivered: bool,
    delivery_id: str = "",
) -> dict[str, Any]:
    path = f"{DELIVERIES_PATH}/{request_id}"
    for _ in range(6):
        snapshot = repository.read(path)
        delivery = dict(snapshot.value)
        _validate_delivery(delivery, request_id=request_id, room_id=room_id, require_sendable=True)
        _validate_task_binding(repository, delivery)
        if delivery.get("status") == "delivered":
            _append_delivery_receipt(repository, delivery, now_ms, "delivered")
            return delivery
        replacement = dict(delivery)
        if delivered:
            telegram_delivery_id = str(delivery_id or "").strip()
            if telegram_delivery_id and not re.fullmatch(r"[0-9]{1,20}", telegram_delivery_id):
                raise ProjectCaError("project CA Telegram delivery id")
            replacement.update({
                "status": "delivered", "lifecycle_state": "telegram_delivered", "sent": True,
                "delivery_id": telegram_delivery_id, "delivered_at_ms": now_ms,
                "last_error_code": "", "next_attempt_at_ms": 0,
            })
            receipt_status = "delivered"
        else:
            attempts = int(delivery.get("attempt_count") or 0) + 1
            delay = min(5 * 60 * 1000, 5000 * (2 ** min(attempts - 1, 6)))
            replacement.update({
                "status": "retry", "lifecycle_state": "delivery_retry", "attempt_count": attempts,
                "last_error_code": "telegram_delivery_failed", "last_attempt_at_ms": now_ms,
                "next_attempt_at_ms": now_ms + delay,
            })
            receipt_status = "retry"
        result = repository.cas(path, snapshot.revision, replacement)
        if result.created:
            _append_delivery_receipt(repository, replacement, now_ms, receipt_status)
            return replacement
    raise ProjectCaError("project CA delivery CAS contention")


def _append_delivery_receipt(
    repository: ProjectCaRepository, delivery: Mapping[str, Any], now_ms: int, status: str
) -> None:
    task_path = f"{TASKS_PATH}/{delivery['task_id']}"
    for _ in range(6):
        snapshot = repository.read(task_path)
        task = dict(snapshot.value)
        if task.get("schema") != TASK_SCHEMA or task.get("fencing_token") != delivery.get("fencing_token"):
            raise ProjectCaError("project CA task fencing")
        receipts = dict(task.get("receipts") or {})
        attempt = int(delivery.get("attempt_count") or 0)
        raw = f"{delivery['request_id']}:{status}:{attempt}".encode()
        receipt_id = "rcpt_" + hashlib.sha256(raw).hexdigest()[:32]
        if receipt_id in receipts:
            return
        sequence = int(task.get("sequence") or 0) + 1
        receipts[receipt_id] = {
            "schema": RECEIPT_SCHEMA,
            "receipt_id": receipt_id,
            "task_id": task["task_id"],
            "transition": "delivery",
            "status": status,
            "sequence": sequence,
            "attempt": max(1, attempt),
            "lease_epoch": int(task["lease_epoch"]),
            "fencing_token": task["fencing_token"],
            "resource": "personal_gateway",
            "occurred_at_ms": now_ms,
            "no_send": False,
            "sent": status == "delivered",
        }
        replacement = dict(task)
        replacement.update({"receipts": receipts, "sequence": sequence, "last_transition": "delivery"})
        if repository.cas(task_path, snapshot.revision, replacement).created:
            return
    raise ProjectCaError("project CA task receipt CAS contention")


def _validate_delivery(
    delivery: Mapping[str, Any], *, request_id: str, room_id: str, require_sendable: bool
) -> None:
    if (
        delivery.get("schema") != DELIVERY_SCHEMA
        or delivery.get("delivery_kind") != DELIVERY_KIND
        or delivery.get("request_id") != request_id
        or delivery.get("conversation_id") != room_id
        or delivery.get("room_kind") != "ca_expert"
        or delivery.get("reply_account_id") != "serverphone"
        or delivery.get("target_node") != "subphone_termux_ops"
        or delivery.get("kakao_authority") is not False
        or delivery.get("business_action_authority") is not False
    ):
        raise ProjectCaError("project CA delivery binding")
    if require_sendable and delivery.get("no_send") is not False:
        raise ProjectCaError("project CA delivery is not promoted")


def _validate_task_binding(repository: ProjectCaRepository, delivery: Mapping[str, Any]) -> None:
    task = repository.read(f"{TASKS_PATH}/{delivery.get('task_id')}").value
    if (
        task.get("schema") != TASK_SCHEMA
        or task.get("task_id") != delivery.get("task_id")
        or task.get("lease_epoch") != delivery.get("lease_epoch")
        or task.get("fencing_token") != delivery.get("fencing_token")
    ):
        raise ProjectCaError("project CA task fencing")


def _issue_codes(value: Any) -> list[str]:
    if value in (None, []):
        return []
    if not isinstance(value, list):
        raise ProjectCaError("project CA issues shape")
    codes = set()
    for item in value[:32]:
        if not isinstance(item, Mapping):
            raise ProjectCaError("project CA issue record")
        source = _safe_token(item.get("source"))
        code = _safe_token(item.get("code"))
        severity = str(item.get("severity") or "")
        if severity not in SEVERITIES:
            raise ProjectCaError("project CA issue severity")
        codes.add(f"{source}:{code}:{severity}")
    return sorted(codes)[:8]


def _safe_token(value: Any, *, allow_empty: bool = False) -> str:
    text = str(value or "").strip()
    if not text and allow_empty:
        return ""
    if not TOKEN_RE.fullmatch(text):
        raise ProjectCaError("project CA token")
    return text


def _message(project: str, severity: str, codes: list[str], projection_id: str, self_fix_ref: str) -> str:
    lines = [f"[프로젝트 상태] {project}", f"severity: {severity}", f"codes: {','.join(codes) if codes else 'none'}", f"projection: {projection_id}"]
    if self_fix_ref:
        lines.append(f"existing_self_fix: {self_fix_ref}")
    return "\n".join(lines)[:1200]
