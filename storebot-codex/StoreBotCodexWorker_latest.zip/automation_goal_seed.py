#!/usr/bin/env python3
"""Compile a bounded JSON task list into a canonical automation goal state.

This is a pure model-0 admission tool.  It performs no network, Firebase, AI,
process, or output-file action.  Every task is probed through the production
reducer with a deterministic synthetic resource receipt before the state is
emitted to stdout.
"""

from __future__ import annotations

import argparse
import copy
import json
from pathlib import Path
import sys
from typing import Any

try:
    from scripts import automation_goal_dispatcher as reducer
except ModuleNotFoundError:  # Direct execution from the scripts directory.
    import automation_goal_dispatcher as reducer  # type: ignore[no-redef]


SYNTHETIC_NOW = "2000-01-01T00:00:00Z"
SYNTHETIC_LEASE_EXPIRY = "2000-01-01T00:05:00Z"


class SeedValidationError(ValueError):
    def __init__(self, message: str, *, code: str = "invalid_seed") -> None:
        super().__init__(message)
        self.code = code


def _task_id(task: Any, index: int) -> str:
    if not isinstance(task, dict):
        raise SeedValidationError(f"tasks[{index}] must be an object")
    task_id = task.get("task_id")
    if not isinstance(task_id, str) or not task_id:
        raise SeedValidationError(f"tasks[{index}].task_id is required")
    return task_id


def _dependency_graph(tasks: list[dict[str, Any]]) -> tuple[list[str], dict[str, set[str]]]:
    task_ids: list[str] = []
    seen: set[str] = set()
    dependencies: dict[str, set[str]] = {}
    for index, task in enumerate(tasks):
        task_id = _task_id(task, index)
        if task_id in seen:
            raise SeedValidationError(f"duplicate task_id: {task_id}", code="duplicate_task_id")
        seen.add(task_id)
        task_ids.append(task_id)
        raw_dependencies = task.get("dependencies")
        if not isinstance(raw_dependencies, list) or not all(
            isinstance(item, str) and item for item in raw_dependencies
        ):
            raise SeedValidationError(f"task {task_id} dependencies must be a string list")
        dependencies[task_id] = set(raw_dependencies)

    known = set(task_ids)
    for task_id, required in dependencies.items():
        unknown = sorted(required - known)
        if unknown:
            raise SeedValidationError(
                f"task {task_id} has unknown dependencies: {unknown}",
                code="unknown_dependency",
            )
        if task_id in required:
            raise SeedValidationError(f"task {task_id} depends on itself", code="dependency_cycle")

    completed: set[str] = set()
    remaining = set(task_ids)
    while remaining:
        ready = sorted(task_id for task_id in remaining if dependencies[task_id] <= completed)
        if not ready:
            raise SeedValidationError(
                f"dependency cycle: {sorted(remaining)}", code="dependency_cycle"
            )
        completed.update(ready)
        remaining.difference_update(ready)
    return task_ids, dependencies


def _synthetic_dispatch_event(
    goal_id: str,
    goal_epoch: int,
    task: dict[str, Any],
) -> dict[str, Any]:
    task_id = str(task["task_id"])
    lease_material = {
        "goal_id": goal_id,
        "goal_epoch": goal_epoch,
        "task_id": task_id,
        "resource_id": task.get("resource_id"),
        "capability": task.get("capability"),
    }
    return {
        "type": "dispatch",
        "parent_goal": goal_id,
        "goal_epoch": goal_epoch,
        "now": SYNTHETIC_NOW,
        "resource_snapshot": {
            "status": "ready",
            "checked_at": SYNTHETIC_NOW,
            "resource_id": task.get("resource_id"),
            "capability": task.get("capability"),
            "supported_models": [task.get("model_id")],
            "capacity": 1,
            "lease_id": f"seed-{reducer.canonical_hash(lease_material)[:20]}",
            "lease_epoch": goal_epoch,
            "lease_expires_at": SYNTHETIC_LEASE_EXPIRY,
        },
    }


def _probe_task(
    goal_id: str,
    goal_epoch: int,
    task: dict[str, Any],
    dependencies: set[str],
    policy: dict[str, Any],
) -> str:
    probe = reducer.create_state(goal_id, goal_epoch, next_tasks=[copy.deepcopy(task)])
    probe["completed"] = {
        dependency: {
            "child_id": f"seed-dependency-{reducer.canonical_hash(dependency)[:16]}",
            "status": "done",
            "evidence_hash": reducer.canonical_hash({"dependency": dependency}),
            "request_id": f"seed-request-{reducer.canonical_hash(dependency)[:16]}",
        }
        for dependency in sorted(dependencies)
    }
    try:
        _updated, decision = reducer.reduce_dispatch(
            probe,
            _synthetic_dispatch_event(goal_id, goal_epoch, task),
            policy,
        )
    except reducer.GoalDispatchValidationError as exc:
        raise SeedValidationError(
            f"task {task.get('task_id')} failed reducer validation: {exc}",
            code="task_contract_invalid",
        ) from exc
    envelope = decision.get("next_child")
    if decision.get("status") != "dispatched" or not isinstance(envelope, dict):
        raise SeedValidationError(
            f"task {task.get('task_id')} is not dispatchable: {decision.get('status')}",
            code="task_not_dispatchable",
        )
    child_id = envelope.get("child_id")
    if not isinstance(child_id, str) or not child_id:
        raise SeedValidationError("reducer did not return child identity", code="missing_child_identity")
    return child_id


def compile_seed(
    goal_id: str,
    goal_epoch: int,
    tasks: Any,
    policy: dict[str, Any] | None = None,
) -> dict[str, Any]:
    """Validate tasks with reducer gates and return an unpersisted canonical state value."""

    if not isinstance(goal_id, str) or not goal_id:
        raise SeedValidationError("goal_id is required")
    if not isinstance(goal_epoch, int) or isinstance(goal_epoch, bool) or goal_epoch < 1:
        raise SeedValidationError("goal_epoch must be a positive integer")
    if not isinstance(tasks, list) or not tasks:
        raise SeedValidationError("tasks must be a non-empty JSON list")
    if not all(isinstance(task, dict) for task in tasks):
        raise SeedValidationError("every task must be an object")

    active_policy = reducer.load_policy() if policy is None else copy.deepcopy(policy)
    reducer.validate_policy(active_policy)
    max_children = active_policy["budgets"]["max_total_children_per_goal"]
    if len(tasks) > max_children:
        raise SeedValidationError("task count exceeds goal child budget", code="goal_child_budget_exceeded")
    task_ids, dependency_graph = _dependency_graph(tasks)

    child_owners: dict[str, str] = {}
    for task_id, task in zip(task_ids, tasks):
        child_id = _probe_task(
            goal_id,
            goal_epoch,
            task,
            dependency_graph[task_id],
            active_policy,
        )
        previous = child_owners.get(child_id)
        if previous is not None:
            raise SeedValidationError(
                f"duplicate child identity for {previous} and {task_id}: {child_id}",
                code="duplicate_child_identity",
            )
        child_owners[child_id] = task_id

    reserved_tokens = sum(int(task["token_budget"]) for task in tasks)
    if reserved_tokens > active_policy["budgets"]["max_total_tokens_per_goal"]:
        raise SeedValidationError(
            "task reservations exceed goal token budget", code="goal_token_budget_exceeded"
        )

    return reducer.create_state(goal_id, goal_epoch, next_tasks=copy.deepcopy(tasks))


def _read_tasks(path: str | None) -> Any:
    if path:
        return json.loads(Path(path).read_text(encoding="utf-8"))
    return json.load(sys.stdin)


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--goal-id", required=True)
    parser.add_argument("--goal-epoch", required=True, type=int)
    parser.add_argument("--input", help="JSON task-list path; stdin when omitted")
    parser.add_argument("--policy", default=str(reducer.DEFAULT_POLICY))
    args = parser.parse_args(argv)
    try:
        policy = json.loads(Path(args.policy).read_text(encoding="utf-8"))
        state = compile_seed(args.goal_id, args.goal_epoch, _read_tasks(args.input), policy)
    except (SeedValidationError, reducer.GoalDispatchValidationError, OSError, json.JSONDecodeError) as exc:
        code = getattr(exc, "code", "invalid_json_or_io")
        print(
            reducer.canonical_json({"status": "invalid", "error_code": code, "error": str(exc)}),
            file=sys.stderr,
        )
        return 2
    print(reducer.canonical_json(state))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
