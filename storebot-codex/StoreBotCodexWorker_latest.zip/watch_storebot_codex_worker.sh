#!/system/bin/sh
if [ -z "${STOREBOT_CODEX_BASH_REEXEC:-}" ]; then
  for candidate in "${STOREBOT_TERMUX_DATA_DIR:-}" /data/data/com.sbotux /data/data/com.termux; do
    [ -n "$candidate" ] || continue
    if [ -x "$candidate/files/usr/bin/bash" ]; then
      export STOREBOT_CODEX_BASH_REEXEC=1
      exec "$candidate/files/usr/bin/bash" "$0" "$@"
    fi
  done
fi
set -u

resolve_termux_data_dir() {
  if [ -n "${STOREBOT_TERMUX_DATA_DIR:-}" ] && [ -x "$STOREBOT_TERMUX_DATA_DIR/files/usr/bin/bash" ]; then
    printf '%s\n' "$STOREBOT_TERMUX_DATA_DIR"
    return 0
  fi
  for candidate in /data/data/com.sbotux /data/data/com.termux; do
    if [ -x "$candidate/files/usr/bin/bash" ]; then
      printf '%s\n' "$candidate"
      return 0
    fi
  done
  printf '%s\n' "/data/data/com.sbotux"
}

APP_DATA_DIR="$(resolve_termux_data_dir)"
APP_PREFIX="$APP_DATA_DIR/files/usr"
export PREFIX="${PREFIX:-$APP_PREFIX}"
export PATH="$APP_PREFIX/bin:$APP_PREFIX/bin/applets:/system/bin:/system/xbin:$PATH"

ROOT_COPY="${STOREBOT_CODEX_ROOT_COPY:-/sdcard/Download/storebot_codex_worker}"
LOG_DIR="${STOREBOT_CODEX_HOST_LOG_DIR:-$ROOT_COPY}"
LOG_FILE="$LOG_DIR/watchdog.log"
LOCK_DIR="${STOREBOT_CODEX_WATCHDOG_LOCK_DIR:-$APP_PREFIX/tmp/storebot_codex_watchdog.lock}"
INTERVAL_SEC="${STOREBOT_CODEX_WATCHDOG_INTERVAL_SEC:-60}"
HEALTH_URL="${STOREBOT_CODEX_HEALTH_URL:-http://127.0.0.1:8765/storebot/health}"
HEALTH_TIMEOUT_SEC="${STOREBOT_CODEX_HEALTH_TIMEOUT_SEC:-5}"
SOURCE="${1:-manual}"
BASH_PATH="${STOREBOT_CODEX_BASH_PATH:-$APP_PREFIX/bin/bash}"

mkdir -p "$LOG_DIR"

timestamp() {
  TZ=Asia/Seoul date +"%Y-%m-%d %H:%M:%S KST"
}

log() {
  echo "[$(timestamp)] $*" >> "$LOG_FILE"
}

pid_alive() {
  local pid="$1"
  [ -n "$pid" ] && kill -0 "$pid" 2>/dev/null
}

if ! mkdir "$LOCK_DIR" 2>/dev/null; then
  old_pid="$(cat "$LOCK_DIR/pid" 2>/dev/null || true)"
  if pid_alive "$old_pid"; then
    log "watchdog already running pid=$old_pid source=$SOURCE"
    exit 0
  fi
  rm -rf "$LOCK_DIR"
  if ! mkdir "$LOCK_DIR" 2>/dev/null; then
    log "watchdog lock busy source=$SOURCE"
    exit 0
  fi
fi

cleanup() {
  rm -rf "$LOCK_DIR"
}
trap cleanup EXIT INT TERM
echo "$$" > "$LOCK_DIR/pid"

is_worker_running() {
  if command -v pgrep >/dev/null 2>&1; then
    pgrep -af "storebot_codex_worker.py" 2>/dev/null | grep -- "--watch" >/dev/null 2>&1 && return 0
  fi
  (ps -ef 2>/dev/null || ps -eo pid,args 2>/dev/null || ps -A -o pid,args 2>/dev/null || ps -A -o PID,ARGS 2>/dev/null || ps -A 2>/dev/null || ps 2>/dev/null) \
    | grep "storebot_codex_worker.py" \
    | grep -- "--watch" \
    | grep -v grep >/dev/null 2>&1
}

health_ok() {
  if command -v python3 >/dev/null 2>&1; then
    python3 -c 'import sys, urllib.request; url=sys.argv[1]; timeout=float(sys.argv[2]); resp=urllib.request.urlopen(url, timeout=timeout); sys.exit(0 if resp.status == 200 else 1)' "$HEALTH_URL" "$HEALTH_TIMEOUT_SEC" >/dev/null 2>&1 && return 0
  fi
  if command -v curl >/dev/null 2>&1; then
    curl -fsS --max-time "$HEALTH_TIMEOUT_SEC" "$HEALTH_URL" >/dev/null 2>&1
    code=$?
    [ "$code" = "0" ] && return 0
  fi
  return 2
}

start_worker() {
  if [ ! -r "$ROOT_COPY/launch_storebot_codex_background.sh" ]; then
    log "launch helper missing path=$ROOT_COPY/launch_storebot_codex_background.sh"
    return 1
  fi
  "$BASH_PATH" "$ROOT_COPY/launch_storebot_codex_background.sh" watchdog >> "$LOG_FILE" 2>&1
}

log "watchdog started source=$SOURCE interval=${INTERVAL_SEC}s health=$HEALTH_URL"
ok_loops=0

while true; do
  termux-wake-lock >/dev/null 2>&1 || true

  running="no"
  if is_worker_running; then
    running="yes"
  fi

  health="unknown"
  health_ok
  health_code=$?
  if [ "$health_code" = "0" ]; then
    health="ok"
  elif [ "$health_code" = "2" ]; then
    health="unknown"
  else
    health="fail"
  fi

  if [ "$health" = "fail" ] || { [ "$health" = "unknown" ] && [ "$running" != "yes" ]; }; then
    log "revive requested running=$running health=$health"
    if start_worker; then
      log "revive launch requested"
    else
      log "revive launch failed"
    fi
    ok_loops=0
    sleep 15
  else
    ok_loops=$((ok_loops + 1))
    if [ "$ok_loops" -ge 10 ]; then
      log "watchdog ok running=$running health=$health"
      ok_loops=0
    fi
  fi

  sleep "$INTERVAL_SEC"
done
