#!/usr/bin/env python3
from __future__ import annotations

import argparse
import json
import re
import subprocess
import sys
import tempfile
import time
import urllib.parse
import urllib.request
from pathlib import Path
from typing import Any

from codex_ops_adb_check import compact_text, parse_devices, resolve_adb_path, select_device


DEFAULT_POSDELAY_PACKAGE = "com.posdelay.app"
DEFAULT_FIREBASE_BASE = "https://poskds-4ba60-default-rtdb.asia-southeast1.firebasedatabase.app"
ALLOWED_WAKE_MODES = {"check", "foreground"}
ADB_UNAVAILABLE_EXIT = 2
CHECK_FAILED_EXIT = 3

FIREBASE_PATHS = {
    "app_heartbeat": "/posdelay/app_heartbeat",
    "monitoring_app_latest": "/posdelay/monitoring/app_latest",
    "monitoring_app": "/posdelay/monitoring/app",
    "ad_state": "/posdelay/ad_state",
    "alert": "/posdelay/alert",
}

ERROR_PATTERNS = (
    "AndroidRuntime",
    "FATAL EXCEPTION",
    "ANR",
    "Process com.posdelay.app",
    "PosDelay",
    "Exception",
)


def now_ms() -> int:
    return int(time.time() * 1000)


def bool_field(value: Any) -> bool:
    if isinstance(value, bool):
        return value
    if isinstance(value, (int, float)):
        return value != 0
    return str(value or "").strip().lower() in {"1", "true", "yes", "y", "on"}


def posdelay_request_requested(item: dict[str, Any]) -> bool:
    return bool_field(item.get("posdelay_check")) or bool_field(item.get("posdelay_wake"))


def normalize_wake_mode(item: dict[str, Any]) -> str:
    wake_requested = bool_field(item.get("posdelay_wake")) or bool_field(item.get("posdelay_bring_foreground"))
    raw_mode = str(item.get("posdelay_wake_mode") or "").strip().lower()
    if raw_mode not in ALLOWED_WAKE_MODES:
        raw_mode = "foreground" if wake_requested else "check"
    return raw_mode if wake_requested else "check"


def _int_value(value: Any, default: int) -> int:
    try:
        return int(value)
    except (TypeError, ValueError):
        return default


def normalize_spec(item: dict[str, Any]) -> dict[str, Any]:
    return {
        "enabled": posdelay_request_requested(item),
        "mode": normalize_wake_mode(item),
        "adb_path": str(item.get("adb_path") or "").strip(),
        "serial": str(item.get("posdelay_serial") or item.get("adb_serial") or item.get("serial") or "").strip(),
        "package": str(item.get("posdelay_package") or DEFAULT_POSDELAY_PACKAGE).strip() or DEFAULT_POSDELAY_PACKAGE,
        "screenshot": bool_field(item.get("posdelay_screenshot") or item.get("screenshot")),
        "screenshot_on_fail": bool_field(item.get("posdelay_screenshot_on_fail") or item.get("screenshot_on_fail")),
        "logcat_tail": max(0, _int_value(item.get("posdelay_logcat_tail") or item.get("logcat_tail"), 0)),
        "timeout_sec": max(3, _int_value(item.get("posdelay_timeout_sec") or item.get("adb_timeout_sec"), 15)),
        "firebase_base": str(item.get("firebase_base") or DEFAULT_FIREBASE_BASE).strip() or DEFAULT_FIREBASE_BASE,
        "firebase_timeout_sec": max(1.0, float(item.get("firebase_timeout_sec") or 3.0)),
        "firebase": not bool_field(item.get("posdelay_no_firebase") or item.get("no_firebase")),
        "battery": bool_field(item.get("posdelay_battery") or item.get("battery")),
        "scheduled": bool_field(item.get("posdelay_scheduled") or item.get("scheduled")),
        "state_file": str(item.get("posdelay_state_file") or item.get("state_file") or "").strip(),
        "deep_every_sec": max(60, _int_value(item.get("posdelay_deep_every_sec") or item.get("deep_every_sec"), 180)),
        "logcat_every_sec": max(60, _int_value(item.get("posdelay_logcat_every_sec") or item.get("logcat_every_sec"), 300)),
        "log_jsonl": str(item.get("posdelay_log_jsonl") or item.get("log_jsonl") or "").strip(),
    }


def _run(cmd: list[str], timeout_sec: int) -> subprocess.CompletedProcess[str]:
    return subprocess.run(
        cmd,
        text=True,
        stdout=subprocess.PIPE,
        stderr=subprocess.PIPE,
        timeout=timeout_sec,
        check=False,
    )


def _adb_base(adb_path: str, serial: str = "") -> list[str]:
    cmd = [adb_path]
    if serial:
        cmd.extend(["-s", serial])
    return cmd


def shell(base: list[str], args: list[str], timeout_sec: int) -> subprocess.CompletedProcess[str]:
    return _run(base + ["shell", *args], timeout_sec)


def command_result(proc: subprocess.CompletedProcess[str], limit: int = 1200) -> dict[str, Any]:
    text = f"{proc.stdout}\n{proc.stderr}".strip()
    return {
        "returncode": proc.returncode,
        "stdout_tail": compact_text(proc.stdout, limit),
        "stderr_tail": compact_text(proc.stderr, limit),
        "output_tail": compact_text(text, limit),
    }


def package_version(text: str) -> dict[str, str]:
    result: dict[str, str] = {}
    for key in ("versionName", "versionCode"):
        match = re.search(rf"\b{key}=([^\s]+)", text)
        if match:
            result[key] = match.group(1)
    return result


def check_package(base: list[str], package_name: str, timeout_sec: int) -> dict[str, Any]:
    pm_path = shell(base, ["pm", "path", package_name], timeout_sec)
    installed = pm_path.returncode == 0 and "package:" in pm_path.stdout
    dumpsys = shell(base, ["dumpsys", "package", package_name], timeout_sec) if installed else None
    version_text = f"{dumpsys.stdout}\n{dumpsys.stderr}" if dumpsys else ""
    return {
        "package_name": package_name,
        "installed": installed,
        "pm_path": command_result(pm_path),
        "version": package_version(version_text),
    }


def check_pid(base: list[str], package_name: str, timeout_sec: int) -> dict[str, Any]:
    proc = shell(base, ["pidof", package_name], timeout_sec)
    pids = [part for part in proc.stdout.strip().split() if part.isdigit()]
    return {"running": bool(pids), "pids": pids, **command_result(proc, 800)}


def _extract_top_activity(text: str) -> tuple[str, str]:
    patterns = [
        r"mCurrentFocus=.*?\s([A-Za-z0-9_.]+)/([A-Za-z0-9_.$/]+)",
        r"mFocusedApp=.*?\s([A-Za-z0-9_.]+)/([A-Za-z0-9_.$/]+)",
        r"topResumedActivity=.*?\s([A-Za-z0-9_.]+)/([A-Za-z0-9_.$/]+)",
        r"ResumedActivity:.*?\s([A-Za-z0-9_.]+)/([A-Za-z0-9_.$/]+)",
    ]
    for pattern in patterns:
        match = re.search(pattern, text)
        if match:
            return match.group(1), match.group(2)
    return "", ""


def check_foreground(base: list[str], package_name: str, timeout_sec: int) -> dict[str, Any]:
    window_proc = shell(base, ["dumpsys", "window", "windows"], timeout_sec)
    activity_proc = shell(base, ["dumpsys", "activity", "activities"], timeout_sec)
    combined = f"{window_proc.stdout}\n{window_proc.stderr}\n{activity_proc.stdout}\n{activity_proc.stderr}"
    top_package, top_activity = _extract_top_activity(combined)
    return {
        "top_package": top_package,
        "top_activity": top_activity,
        "is_target": bool(top_package and top_package == package_name),
        "window": command_result(window_proc, 1200),
        "activity": command_result(activity_proc, 1200),
    }


def check_power(base: list[str], timeout_sec: int) -> dict[str, Any]:
    proc = shell(base, ["dumpsys", "power"], timeout_sec)
    text = f"{proc.stdout}\n{proc.stderr}"
    interactive: bool | None = None
    match = re.search(r"\bmInteractive=(true|false)", text)
    if match:
        interactive = match.group(1) == "true"
    elif "state=ON" in text:
        interactive = True
    elif "state=OFF" in text:
        interactive = False
    return {"interactive": interactive, **command_result(proc, 1200)}


def check_keyguard(base: list[str], timeout_sec: int) -> dict[str, Any]:
    proc = shell(base, ["dumpsys", "window", "policy"], timeout_sec)
    text = f"{proc.stdout}\n{proc.stderr}"
    locked: bool | None = None
    if any(token in text for token in ("isStatusBarKeyguard=true", "mShowingLockscreen=true", "showing=true")):
        locked = True
    elif any(token in text for token in ("isStatusBarKeyguard=false", "mShowingLockscreen=false", "showing=false")):
        locked = False
    return {"locked": locked, **command_result(proc, 1200)}


def check_battery(base: list[str], timeout_sec: int) -> dict[str, Any]:
    proc = shell(base, ["dumpsys", "battery"], timeout_sec)
    text = f"{proc.stdout}\n{proc.stderr}"
    parsed: dict[str, Any] = {}
    for key in ("level", "status", "health", "plugged", "temperature"):
        match = re.search(rf"^\s*{re.escape(key)}:\s*([^\r\n]+)", text, re.MULTILINE)
        if match:
            parsed[key] = match.group(1).strip()
    return {"parsed": parsed, **command_result(proc, 1200)}


def take_screenshot(base: list[str], req_id: str, timeout_sec: int) -> dict[str, Any]:
    out_dir = Path(tempfile.gettempdir()) / "codex_ops_posdelay_screenshots"
    out_dir.mkdir(parents=True, exist_ok=True)
    safe_req = re.sub(r"[^0-9A-Za-z_.-]+", "_", req_id or "posdelay")[:80]
    screenshot_path = out_dir / f"{safe_req}_{now_ms()}.png"
    try:
        proc = subprocess.run(
            base + ["exec-out", "screencap", "-p"],
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE,
            timeout=timeout_sec,
            check=False,
        )
    except Exception as exc:
        return {"status": "failed", "reason": compact_text(exc, 500)}
    if proc.returncode == 0 and proc.stdout:
        screenshot_path.write_bytes(proc.stdout)
        return {"status": "done", "path": str(screenshot_path), "bytes": len(proc.stdout)}
    return {
        "status": "failed",
        "returncode": proc.returncode,
        "stderr_tail": compact_text(proc.stderr.decode("utf-8", errors="replace"), 1200),
    }


def analyze_logcat(text: str) -> dict[str, Any]:
    matched: list[str] = []
    for line in text.splitlines():
        if any(pattern in line for pattern in ERROR_PATTERNS):
            matched.append(compact_text(line, 500))
    return {"matched_count": len(matched), "matched_tail": matched[-20:]}


def encoded_url(base_url: str, path: str, query: dict[str, str] | None = None) -> str:
    safe_path = "/".join(urllib.parse.quote(part, safe="") for part in path.split("/") if part)
    url = f"{base_url.rstrip('/')}/{safe_path}.json"
    if query:
        url += "?" + urllib.parse.urlencode(query)
    return url


def firebase_get(base_url: str, path: str, timeout: float, query: dict[str, str] | None = None) -> Any:
    with urllib.request.urlopen(encoded_url(base_url, path, query), timeout=timeout) as response:
        raw = response.read().decode("utf-8")
    if not raw or raw == "null":
        return None
    return json.loads(raw)


def query_last(base_url: str, path: str, limit: int, timeout: float) -> dict[str, Any]:
    query = {"orderBy": json.dumps("$key"), "limitToLast": str(max(1, limit))}
    value = firebase_get(base_url, path, timeout, query)
    return value if isinstance(value, dict) else {}


def normalize_ts_ms(value: Any) -> int:
    if not isinstance(value, (int, float)):
        return 0
    ts = int(value)
    if 0 < ts < 100_000_000_000:
        return ts * 1000
    return ts


def extract_ts_ms(value: Any) -> int:
    if not isinstance(value, dict):
        return 0
    for key in (
        "updated_at_ms",
        "ts_epoch_ms",
        "ts_ms",
        "ts",
        "timestamp",
        "finished_at_ms",
        "created_at_ms",
        "started_at_ms",
    ):
        ts = normalize_ts_ms(value.get(key))
        if ts > 0:
            return ts
    heartbeat = value.get("heartbeat")
    if isinstance(heartbeat, dict):
        return extract_ts_ms(heartbeat)
    return 0


def age_sec(value: Any) -> int:
    ts = normalize_ts_ms(value)
    if ts <= 0:
        return -1
    return max(0, int((now_ms() - ts) / 1000))


def rows_from_dict(value: Any) -> list[dict[str, Any]]:
    rows: list[dict[str, Any]] = []
    if not isinstance(value, dict):
        return rows
    for key, row in sorted(value.items()):
        if isinstance(row, dict):
            item = dict(row)
            item["_key"] = key
            rows.append(item)
    return rows


def summarize_monitoring(raw: Any) -> dict[str, Any]:
    rows = rows_from_dict(raw)
    rows.sort(key=extract_ts_ms, reverse=True)
    latest = rows[0] if rows else {}
    return {
        "count": len(rows),
        "latest_key": latest.get("_key") or "",
        "latest_age_sec": age_sec(extract_ts_ms(latest)),
        "latest_status": latest.get("status") or latest.get("state") or latest.get("foreground") or "",
        "latest_version": latest.get("version_name") or latest.get("app_version_name") or latest.get("version") or "",
    }


def summarize_firebase_data(data: dict[str, Any]) -> dict[str, Any]:
    heartbeat = data.get("app_heartbeat") if isinstance(data.get("app_heartbeat"), dict) else {}
    latest = data.get("monitoring_app_latest") if isinstance(data.get("monitoring_app_latest"), dict) else {}
    ad_state = data.get("ad_state") if isinstance(data.get("ad_state"), dict) else {}
    alert = data.get("alert") if isinstance(data.get("alert"), dict) else {}
    return {
        "app_heartbeat_age_sec": age_sec(extract_ts_ms(heartbeat)),
        "app_heartbeat_status": heartbeat.get("status") or heartbeat.get("state") or "",
        "app_heartbeat_version": heartbeat.get("version_name") or heartbeat.get("app_version_name") or "",
        "monitoring_app_latest_age_sec": age_sec(extract_ts_ms(latest)),
        "monitoring_app_latest_status": latest.get("status") or latest.get("state") or latest.get("foreground") or "",
        "monitoring_app_latest_version": latest.get("version_name") or latest.get("app_version_name") or latest.get("version") or "",
        "monitoring_app_recent": summarize_monitoring(data.get("monitoring_app")),
        "ad_state_updated_age_sec": age_sec(extract_ts_ms(ad_state)),
        "ad_state_keys": sorted(str(key) for key in ad_state.keys())[:30] if isinstance(ad_state, dict) else [],
        "alert_age_sec": age_sec(extract_ts_ms(alert)),
        "alert_status": alert.get("status") or alert.get("severity") or alert.get("type") or "",
        "alert_message_tail": compact_text(alert.get("message") or alert.get("text") or "", 300),
    }


def fetch_firebase_summary(base_url: str, timeout: float) -> dict[str, Any]:
    data: dict[str, Any] = {}
    errors: list[str] = []
    for name, path in FIREBASE_PATHS.items():
        try:
            if name == "monitoring_app":
                data[name] = query_last(base_url, path, 10, timeout)
            else:
                data[name] = firebase_get(base_url, path, timeout)
        except Exception as exc:  # noqa: BLE001 - Firebase is best-effort; ADB check must continue.
            errors.append(f"{name}: {exc.__class__.__name__}: {compact_text(exc, 160)}")
            data[name] = None
    return {"available": not errors, "errors": errors, "data": summarize_firebase_data(data)}


def load_state(path: str) -> dict[str, Any]:
    if not path:
        return {}
    try:
        return json.loads(Path(path).read_text(encoding="utf-8"))
    except Exception:
        return {}


def save_state(path: str, state: dict[str, Any]) -> None:
    if not path:
        return
    target = Path(path)
    target.parent.mkdir(parents=True, exist_ok=True)
    target.write_text(json.dumps(state, ensure_ascii=False, indent=2, sort_keys=True), encoding="utf-8")


def due(now: int, last: Any, every_sec: int) -> bool:
    last_ms = normalize_ts_ms(last)
    return last_ms <= 0 or now - last_ms >= every_sec * 1000


def throttle_state(spec: dict[str, Any]) -> dict[str, Any]:
    current = now_ms()
    state = load_state(str(spec.get("state_file") or ""))
    scheduled = bool(spec.get("scheduled"))
    deep_due = True
    logcat_due = int(spec.get("logcat_tail") or 0) > 0
    if scheduled:
        deep_due = due(current, state.get("last_deep_ms"), int(spec.get("deep_every_sec") or 180))
        logcat_due = bool(spec.get("logcat_tail")) and due(
            current,
            state.get("last_logcat_ms"),
            int(spec.get("logcat_every_sec") or 300),
        )
    return {
        "scheduled": scheduled,
        "state_file": str(spec.get("state_file") or ""),
        "deep_due": deep_due,
        "logcat_due": logcat_due,
        "deep_every_sec": int(spec.get("deep_every_sec") or 180),
        "logcat_every_sec": int(spec.get("logcat_every_sec") or 300),
        "loaded_state": {"last_light_ms": state.get("last_light_ms"), "last_deep_ms": state.get("last_deep_ms"), "last_logcat_ms": state.get("last_logcat_ms")},
    }


def update_throttle_state(spec: dict[str, Any], throttle: dict[str, Any]) -> None:
    path = str(spec.get("state_file") or "")
    if not path:
        return
    state = load_state(path)
    current = now_ms()
    state["last_light_ms"] = current
    if throttle.get("deep_due"):
        state["last_deep_ms"] = current
    if throttle.get("logcat_due"):
        state["last_logcat_ms"] = current
    save_state(path, state)


def append_jsonl(path: str, result: dict[str, Any]) -> None:
    if not path:
        return
    target = Path(path)
    target.parent.mkdir(parents=True, exist_ok=True)
    with target.open("a", encoding="utf-8") as handle:
        handle.write(json.dumps(result, ensure_ascii=False, separators=(",", ":")) + "\n")


def finalize_result(
    result: dict[str, Any],
    spec: dict[str, Any],
    throttle: dict[str, Any],
    started: int,
) -> dict[str, Any]:
    result["duration_ms"] = now_ms() - started
    try:
        update_throttle_state(spec, throttle)
    except Exception as exc:  # noqa: BLE001 - logging helper must not hide the real result.
        result.setdefault("warnings", []).append(f"state_update_failed: {compact_text(exc, 200)}")
    try:
        append_jsonl(str(spec.get("log_jsonl") or ""), result)
    except Exception as exc:  # noqa: BLE001
        result.setdefault("warnings", []).append(f"log_jsonl_failed: {compact_text(exc, 200)}")
    return result


def summarize_health(result: dict[str, Any]) -> dict[str, Any]:
    issues: list[str] = []
    checks = result.get("checks") if isinstance(result.get("checks"), dict) else {}
    package = checks.get("package") if isinstance(checks.get("package"), dict) else {}
    pid = checks.get("pid") if isinstance(checks.get("pid"), dict) else {}
    foreground = checks.get("foreground_before") if isinstance(checks.get("foreground_before"), dict) else {}
    power = checks.get("power_before") if isinstance(checks.get("power_before"), dict) else {}
    keyguard = checks.get("keyguard_before") if isinstance(checks.get("keyguard_before"), dict) else {}
    firebase_data = ((result.get("firebase") or {}).get("data") if isinstance(result.get("firebase"), dict) else {}) or {}

    if not package.get("installed"):
        issues.append("package_missing")
    if package.get("installed") and not pid.get("running"):
        issues.append("process_not_running")
    if foreground.get("top_package") and not foreground.get("is_target"):
        issues.append("foreground_not_posdelay")
    if power.get("interactive") is False:
        issues.append("screen_not_interactive")
    if keyguard.get("locked") is True:
        issues.append("keyguard_locked")

    heartbeat_age = firebase_data.get("app_heartbeat_age_sec")
    if isinstance(heartbeat_age, int) and heartbeat_age >= 0 and heartbeat_age > 10 * 60:
        issues.append("firebase_app_heartbeat_stale")
    monitoring_age = firebase_data.get("monitoring_app_latest_age_sec")
    if isinstance(monitoring_age, int) and monitoring_age >= 0 and monitoring_age > 10 * 60:
        issues.append("firebase_monitoring_stale")

    logcat = checks.get("logcat") if isinstance(checks.get("logcat"), dict) else {}
    analysis = logcat.get("analysis") if isinstance(logcat.get("analysis"), dict) else {}
    if int(analysis.get("matched_count") or 0) > 0:
        issues.append("logcat_error_patterns_present")

    status = "ok"
    if any(issue in issues for issue in ("package_missing", "process_not_running")):
        status = "fail"
    elif issues:
        status = "warn"
    return {"status": status, "severity": status, "issues": issues}


def run_posdelay_watchdog(item: dict[str, Any], req_id: str = "") -> dict[str, Any]:
    spec = normalize_spec(item)
    started = now_ms()
    throttle = throttle_state(spec)
    if not spec.get("enabled"):
        return finalize_result({"status": "posdelay_skipped", "enabled": False, "throttle": throttle}, spec, throttle, started)

    resolver = resolve_adb_path({"adb_path": spec.get("adb_path")})
    adb_path = str(resolver.get("adb_path") or "")
    result: dict[str, Any] = {
        "status": "adb_unavailable",
        "enabled": True,
        "mode": spec["mode"],
        "package": spec["package"],
        "adb_path": adb_path,
        "adb_path_source": resolver.get("adb_path_source") or "",
        "adb_candidates": resolver.get("adb_candidates") or [],
        "serial": "",
        "checks": {},
        "firebase": {},
        "health": {},
        "throttle": throttle,
        "safety": {
            "platform_ad_click": False,
            "baemin_coupang_input": False,
            "text_input": False,
            "unlock": False,
            "install": False,
            "foreground_default": False,
        },
    }
    if not adb_path:
        result["reason"] = "adb command not found"
        result["health"] = {"status": "fail", "severity": "fail", "issues": ["adb_unavailable"]}
        return finalize_result(result, spec, throttle, started)

    timeout_sec = int(spec["timeout_sec"])
    try:
        devices_proc = _run([adb_path, "devices", "-l"], timeout_sec)
    except Exception as exc:
        result["reason"] = compact_text(exc, 500)
        result["health"] = {"status": "fail", "severity": "fail", "issues": ["adb_devices_failed"]}
        return finalize_result(result, spec, throttle, started)

    devices = parse_devices(devices_proc.stdout)
    serial, select_error = select_device(devices, str(spec.get("serial") or ""))
    result["devices"] = devices
    result["serial"] = serial
    result["checks"]["devices"] = command_result(devices_proc, 1200)
    if throttle.get("deep_due") and bool(spec.get("firebase")):
        result["firebase"] = fetch_firebase_summary(str(spec["firebase_base"]), float(spec["firebase_timeout_sec"]))
    elif bool(spec.get("firebase")):
        result["firebase"] = {"skipped": True, "reason": "scheduled deep throttle"}
    else:
        result["firebase"] = {"skipped": True, "reason": "firebase disabled"}
    if select_error:
        result["reason"] = select_error
        result["health"] = {"status": "fail", "severity": "fail", "issues": ["adb_device_unavailable"]}
        return finalize_result(result, spec, throttle, started)

    base = _adb_base(adb_path, serial)
    package_name = str(spec["package"])
    result["checks"]["package"] = check_package(base, package_name, timeout_sec)
    result["checks"]["pid"] = check_pid(base, package_name, timeout_sec)
    result["checks"]["foreground_before"] = check_foreground(base, package_name, timeout_sec)
    result["checks"]["power_before"] = check_power(base, timeout_sec)
    result["checks"]["keyguard_before"] = check_keyguard(base, timeout_sec)
    result["foreground_before_package"] = result["checks"]["foreground_before"].get("top_package") or ""
    result["foreground_before_activity"] = result["checks"]["foreground_before"].get("top_activity") or ""
    result["screen_interactive_before"] = result["checks"]["power_before"].get("interactive")
    result["keyguard_locked_before"] = result["checks"]["keyguard_before"].get("locked")

    if throttle.get("deep_due") and bool(spec.get("battery")):
        result["checks"]["battery"] = check_battery(base, timeout_sec)
    elif bool(spec.get("battery")):
        result["checks"]["battery"] = {"status": "skipped", "reason": "scheduled deep throttle"}

    if result.get("firebase"):
        pass
    elif throttle.get("deep_due") and bool(spec.get("firebase")):
        result["firebase"] = fetch_firebase_summary(str(spec["firebase_base"]), float(spec["firebase_timeout_sec"]))
    elif bool(spec.get("firebase")):
        result["firebase"] = {"skipped": True, "reason": "scheduled deep throttle"}
    else:
        result["firebase"] = {"skipped": True, "reason": "firebase disabled"}

    if not result["checks"]["package"].get("installed"):
        result["health"] = summarize_health(result)
        result["status"] = "posdelay_check_failed"
        return finalize_result(result, spec, throttle, started)

    if str(spec["mode"]) == "foreground":
        proc = shell(base, ["monkey", "-p", package_name, "-c", "android.intent.category.LAUNCHER", "1"], timeout_sec)
        result["checks"]["bring_posdelay_foreground"] = {
            "status": "done" if proc.returncode == 0 else "failed",
            **command_result(proc),
        }
        time.sleep(1.0)

    result["checks"]["foreground_after"] = check_foreground(base, package_name, timeout_sec)
    result["checks"]["power_after"] = check_power(base, timeout_sec)
    result["checks"]["keyguard_after"] = check_keyguard(base, timeout_sec)
    result["foreground_after_package"] = result["checks"]["foreground_after"].get("top_package") or ""
    result["foreground_after_activity"] = result["checks"]["foreground_after"].get("top_activity") or ""
    result["screen_interactive_after"] = result["checks"]["power_after"].get("interactive")
    result["keyguard_locked_after"] = result["checks"]["keyguard_after"].get("locked")

    if int(spec.get("logcat_tail") or 0) and throttle.get("logcat_due"):
        proc = _run(base + ["logcat", "-d", "-t", str(int(spec["logcat_tail"]))], max(timeout_sec, 30))
        log_text = f"{proc.stdout}\n{proc.stderr}"
        result["checks"]["logcat"] = {
            "status": "done" if proc.returncode == 0 else "failed",
            **command_result(proc, 5000),
            "analysis": analyze_logcat(log_text),
        }
    elif int(spec.get("logcat_tail") or 0):
        result["checks"]["logcat"] = {"status": "skipped", "reason": "scheduled logcat throttle"}

    result["health"] = summarize_health(result)
    if spec.get("screenshot") or (spec.get("screenshot_on_fail") and result["health"].get("status") != "ok"):
        result["checks"]["screenshot"] = take_screenshot(base, req_id, timeout_sec)

    foreground_failed = (
        isinstance(result["checks"].get("bring_posdelay_foreground"), dict)
        and result["checks"]["bring_posdelay_foreground"].get("status") == "failed"
    )
    result["status"] = "posdelay_wake_failed" if foreground_failed else (
        "posdelay_wake_done" if str(spec["mode"]) == "foreground" else "posdelay_checked"
    )
    return finalize_result(result, spec, throttle, started)


def exit_code_for_result(result: dict[str, Any]) -> int:
    status = str(result.get("status") or "")
    if status in {"posdelay_checked", "posdelay_wake_done", "posdelay_skipped"}:
        return 0
    if status == "adb_unavailable":
        return ADB_UNAVAILABLE_EXIT
    return CHECK_FAILED_EXIT


def parse_args(argv: list[str]) -> argparse.Namespace:
    parser = argparse.ArgumentParser(description="PosDelay light USB ADB watchdog for factory PC")
    parser.add_argument("--json", action="store_true", help="JSON 결과 출력. 현재 출력은 항상 JSON입니다.")
    parser.add_argument("--adb-path", default="")
    parser.add_argument("--serial", default="")
    parser.add_argument("--package", default=DEFAULT_POSDELAY_PACKAGE)
    parser.add_argument("--wake", action="store_true", help="명시 opt-in일 때만 PosDelay 앱 foreground 전환")
    parser.add_argument("--bring-foreground", action="store_true", help="--wake와 동일한 명시 foreground opt-in")
    parser.add_argument("--screenshot", action="store_true")
    parser.add_argument("--screenshot-on-fail", action="store_true")
    parser.add_argument("--logcat-tail", type=int, default=0)
    parser.add_argument("--timeout-sec", type=int, default=15)
    parser.add_argument("--firebase-base", default=DEFAULT_FIREBASE_BASE)
    parser.add_argument("--firebase-timeout-sec", type=float, default=3.0)
    parser.add_argument("--no-firebase", action="store_true")
    parser.add_argument("--battery", action="store_true")
    parser.add_argument("--scheduled", action="store_true", help="state-file 기준 deep/logcat throttle 적용")
    parser.add_argument("--state-file", default="")
    parser.add_argument("--deep-every-sec", type=int, default=180)
    parser.add_argument("--logcat-every-sec", type=int, default=300)
    parser.add_argument("--log-jsonl", default="")
    parser.add_argument("--request-id", default="")
    return parser.parse_args(argv)


def main(argv: list[str]) -> int:
    args = parse_args(argv)
    wake_requested = args.wake or args.bring_foreground
    item = {
        "posdelay_check": True,
        "posdelay_wake": wake_requested,
        "posdelay_wake_mode": "foreground" if wake_requested else "check",
        "posdelay_package": args.package,
        "posdelay_screenshot": args.screenshot,
        "posdelay_screenshot_on_fail": args.screenshot_on_fail,
        "posdelay_logcat_tail": args.logcat_tail,
        "posdelay_timeout_sec": args.timeout_sec,
        "posdelay_battery": args.battery,
        "posdelay_scheduled": args.scheduled,
        "posdelay_state_file": args.state_file,
        "posdelay_deep_every_sec": args.deep_every_sec,
        "posdelay_logcat_every_sec": args.logcat_every_sec,
        "posdelay_log_jsonl": args.log_jsonl,
        "no_firebase": args.no_firebase,
        "firebase_base": args.firebase_base,
        "firebase_timeout_sec": args.firebase_timeout_sec,
        "adb_path": args.adb_path,
        "adb_serial": args.serial,
    }
    result = run_posdelay_watchdog(item, args.request_id)
    print(json.dumps(result, ensure_ascii=False, indent=2))
    return exit_code_for_result(result)


if __name__ == "__main__":
    raise SystemExit(main(sys.argv[1:]))
