<!-- source: /root/my-first-project/Schedule/APP_INTENT.md -->
# Schedule APP_INTENT.md

## 만든 이유
- 직원도 볼 수 있는 근무/출근 읽기 전용 보조 화면을 타이머에서 분리한다.

## 사용자 결과
- 공식 근무스케줄 주소는 `OrderHelper/`와 일관성 있는 `https://wk7007-wk.github.io/WorkSchedule/`가 기준이다.
- 이 `Schedule/` 화면은 Firebase Hosting에 남은 읽기 전용 보조 화면으로만 본다.
- 화면 제목은 `Schedule`이며, 내용은 근무달력, 당일 근무자, 출근기록 필터를 바로 보여준다.
- 레시피와 타이머 조작은 이 사이트에 넣지 않는다.

## 절대 기준
- 근무표/출근기록은 보기 전용이어야 한다.
- 직원 공개 가능성을 전제로 하므로 수정 버튼, 관리자 조작, 레시피 편집 기능을 섞지 않는다.
- `chicken-timer/dashboard.html`이나 `.../Schedule/` 같은 타이머/Firebase 보조 주소를 공식 근무스케줄 주소로 쓰지 않는다.

## 데이터/경계 기준
- 읽기 경로: `/workschedule_v2/**` 및 출근 기록 `/workschedule_v2/attendance/{date}/{empId}`.
- 쓰기 금지: Schedule 보조 화면은 Firebase GET만 사용한다.
- 원본은 `/root/my-first-project/Schedule`, 공개 복사본은 `/root/my-first-project/AttendanceBoard/docs/Schedule`이다.

## C&I / AI Ops 경계
- C&I는 JS 오류, 읽기 경로 실패, Firebase Hosting 복사본 불일치, 공식 주소 안내 회귀를 self_fix 후보로 올린다.
- 자동 복구는 읽기 전용 화면 코드/문서/호스팅 복사본 보정과 배포까지 허용한다.
- 직원 공개 화면에 쓰기 버튼, 관리자 조작, 레시피/타이머 편집 기능을 추가하는 자동 복구는 금지한다.
- CLI/LLM은 prompt envelope가 있어야 깨어난다. monitor/worker/사용자/수동 enqueue 또는 상주 판단 루프가 prompt를 주입하며, 이것은 C&I 판단 권한 제한이 아니다.

## 완료 기준
- 검증: JS 문법 검사, 브라우저 smoke, 기존 ChickenTimer 회귀 테스트.
- 전달: Firebase Hosting 보조 화면 배포 후 `https://poskds-attendance.web.app/Schedule/` 접속 가능. 공식 안내 주소는 `https://wk7007-wk.github.io/WorkSchedule/`.
