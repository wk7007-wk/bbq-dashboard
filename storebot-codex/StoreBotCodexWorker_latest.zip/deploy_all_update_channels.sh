#!/bin/sh
set -u

ROOT_DIR="$(CDPATH= cd -- "$(dirname -- "$0")/.." && pwd)"
BASE_URL="https://poskds-attendance.web.app"
FAILED=""

build_one() {
  APP_ID="$1"
  LABEL="$2"
  APP_DIR="$3"
  HOSTED_APK_NAME="$4"
  RELEASE_NOTES="$5"

  HOST_DIR="$ROOT_DIR/AttendanceBoard/docs/$APP_ID"
  META_FILE="$APP_DIR/app/build/outputs/apk/debug/output-metadata.json"
  APK_URL="$BASE_URL/$APP_ID/$HOSTED_APK_NAME"

  printf '\n== %s ==\n' "$LABEL"
  mkdir -p "$HOST_DIR"

  if ! sh "$APP_DIR/gradlew" -p "$APP_DIR" :app:assembleDebug; then
    FAILED="$FAILED $APP_ID"
    sh "$APP_DIR/gradlew" -p "$APP_DIR" --stop >/dev/null 2>&1 || true
    return
  fi
  sh "$APP_DIR/gradlew" -p "$APP_DIR" --stop >/dev/null 2>&1 || true

  APK_SOURCE="$(find "$APP_DIR/app/build/outputs/apk/debug" -maxdepth 1 -type f -name '*.apk' | sort | head -n 1)"
  if [ -z "$APK_SOURCE" ] || [ ! -f "$META_FILE" ]; then
    printf '%s build output missing\n' "$LABEL"
    FAILED="$FAILED $APP_ID"
    return
  fi

  VERSION_CODE="$(python3 -c 'import json,sys; print(json.load(open(sys.argv[1]))["elements"][0]["versionCode"])' "$META_FILE")"
  VERSION_NAME="$(python3 -c 'import json,sys; print(json.load(open(sys.argv[1]))["elements"][0]["versionName"])' "$META_FILE")"
  SHA256="$(sha256sum "$APK_SOURCE" | awk '{print $1}')"
  UPDATED_AT="$(TZ=Asia/Seoul date +%Y-%m-%dT%H:%M:%S%z)"

  cp "$APK_SOURCE" "$HOST_DIR/$HOSTED_APK_NAME"
  python3 "$ROOT_DIR/scripts/write_update_manifest.py" \
    --host-dir "$HOST_DIR" \
    --channel-id "$APP_ID" \
    --label "$LABEL" \
    --version-code "$VERSION_CODE" \
    --version-name "$VERSION_NAME" \
    --artifact-url "$APK_URL" \
    --artifact-sha256 "$SHA256" \
    --release-notes "$RELEASE_NOTES" \
    --updated-at "$UPDATED_AT"
  cat > "$HOST_DIR/index.html" <<EOF
<!doctype html>
<html lang="ko">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>$LABEL 업데이트</title>
  <style>
    body { margin:0; min-height:100vh; display:grid; place-items:center; background:#f6f7fb; color:#171717; font-family:sans-serif; }
    main { width:min(92vw, 460px); padding:32px; border:1px solid #d7dbe5; border-radius:18px; background:#fff; box-shadow:0 20px 70px rgba(0,0,0,.12); }
    h1 { margin:0 0 8px; font-size:28px; }
    p { color:#555; line-height:1.55; }
    a { display:block; margin-top:24px; padding:18px; border-radius:10px; background:#2563eb; color:white; text-align:center; font-weight:700; text-decoration:none; }
    small { display:block; margin-top:18px; color:#777; word-break:break-all; }
  </style>
</head>
<body>
  <main>
    <h1>$LABEL 업데이트</h1>
    <p>버전 $VERSION_NAME ($VERSION_CODE)</p>
    <p>$RELEASE_NOTES</p>
    <a href="$HOSTED_APK_NAME" download="${LABEL}_latest.apk">$LABEL APK 다운로드</a>
    <small>SHA-256: $SHA256</small>
  </main>
</body>
</html>
EOF
  printf '%s ready: %s (%s)\n' "$LABEL" "$VERSION_NAME" "$VERSION_CODE"
}

build_one "poskds" "PosKDS" "/root/PosKDS" "PosKDS_latest.bin" "PosKDS 업데이트 센터 배포"
build_one "banktotal" "BankTotal" "/root/BankTotal" "BankTotal_latest.bin" "BankTotal 업데이트 센터 배포"
build_one "workschedule" "WorkSchedule" "/root/WorkSchedule" "WorkSchedule_latest.bin" "WorkSchedule 업데이트 센터 배포"
build_one "notallyx" "NotallyX" "/root/NotallyX" "NotallyX_latest.bin" "NotallyX 업데이트 센터 배포"

if [ -n "$FAILED" ]; then
  printf '\nFAILED:%s\n' "$FAILED" >&2
  exit 1
fi

firebase deploy --only hosting:attendance --project poskds-4ba60
printf '\nAll update channels deployed.\n'
