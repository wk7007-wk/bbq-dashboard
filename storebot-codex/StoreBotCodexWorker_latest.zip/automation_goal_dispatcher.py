#!/usr/bin/env python3
"""Pure model-0 reducer for bounded goal-to-worker dispatch.

This module only validates inputs and returns a new state plus a decision.  It
does not write Firebase, start workers, poll monitors, or perform network I/O.
"""

from __future__ import annotations

import copy
from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path
import re
from typing import Any


ROOT = Path(__file__).resolve().parents[1]
DEFAULT_POLICY = ROOT / "config" / "automation_goal_dispatch_policy.json"
LANES = ("next", "watch", "backlog", "blocked")
HEX64 = re.compile(r"[0-9a-f]{64}")
HEX40 = re.compile(r"[0-9a-f]{40}")
TASK_REQUIRED = {
    "task_id", "dependencies", "resource_id", "capability", "locks",
    "context_tokens", "token_budget", "model_id", "model_decision_by",
    "risk_flags", "input_evidence_hash", "source_revision", "task_fingerprint",
    "prompt", "prompt_bytes", "cwd", "profile", "is_owner", "reasoning_effort", "target_host",
    "target_node", "ttl_seconds", "timeout_seconds", "done_criteria", "forbidden", "risk_assessment",
}
TASK_OPTIONAL = {"learning_evidence", "learning_verification", "recurring_watch"}
WORKER_TERMINAL_STATUSES = {"done", "error", "failed_timeout", "stale_killed", "rejected", "expired"}
WORKER_PROFILES = {"read_only", "patch", "yolo"}
WORKER_REASONING_EFFORTS = {"minimal", "low", "medium", "high", "xhigh"}
WORKER_TARGET_HOSTS = {"subphone", "pc", "any"}
FIREBASE_FORBIDDEN_KEY = re.compile(r"[.#$/\[\]\x00-\x1f\x7f]")


class GoalDispatchValidationError(ValueError):
    def __init__(self, message: str, *, code: str = "invalid_input") -> None:
        super().__init__(message)
        self.code = code


def canonical_json(value: Any) -> str:
    return json.dumps(value, ensure_ascii=False, sort_keys=True, separators=(",", ":"))


def canonical_hash(value: Any) -> str:
    return hashlib.sha256(canonical_json(value).encode("utf-8")).hexdigest()


def firebase_storage_key(namespace: str, external_id: str) -> str:
    """Return a deterministic Firebase-safe internal key for an external label."""

    _string(namespace, "storage namespace")
    _string(external_id, "storage external id")
    material = {"namespace": namespace, "external_id": external_id}
    return f"{namespace}_{canonical_hash(material)[:32]}"


def _firebase_safe_key(value: Any, label: str) -> str:
    key = _string(value, label)
    if FIREBASE_FORBIDDEN_KEY.search(key):
        raise GoalDispatchValidationError(
            f"{label} is not Firebase-key-safe", code="invalid_firebase_key"
        )
    return key


def _mapping_entry(mapping: dict[str, Any], namespace: str, external_id: str) -> Any:
    hashed = firebase_storage_key(namespace, external_id)
    if hashed in mapping:
        return mapping[hashed]
    return mapping.get(external_id)  # Safe legacy in-memory probe compatibility.


def _entry_child_id(value: Any) -> str | None:
    if isinstance(value, dict):
        child_id = value.get("child_id")
        return child_id if isinstance(child_id, str) else None
    return value if isinstance(value, str) else None


def load_policy(path: str | Path = DEFAULT_POLICY) -> dict[str, Any]:
    value = json.loads(Path(path).read_text(encoding="utf-8"))
    validate_policy(value)
    return value


def _string(value: Any, label: str) -> str:
    if not isinstance(value, str) or not value:
        raise GoalDispatchValidationError(f"{label} must be a non-empty string")
    return value


def _string_list(value: Any, label: str) -> list[str]:
    if not isinstance(value, list) or not all(isinstance(item, str) and item for item in value):
        raise GoalDispatchValidationError(f"{label} must be a string list")
    return list(value)


def _integer(value: Any, label: str, *, minimum: int = 0) -> int:
    if not isinstance(value, int) or isinstance(value, bool) or value < minimum:
        raise GoalDispatchValidationError(f"{label} must be an integer >= {minimum}")
    return value


def _digest(value: Any, pattern: re.Pattern[str], label: str) -> str:
    if not isinstance(value, str) or pattern.fullmatch(value) is None:
        raise GoalDispatchValidationError(f"{label} is invalid")
    return value


def _timestamp(value: Any, label: str) -> datetime:
    raw = _string(value, label)
    try:
        parsed = datetime.fromisoformat(raw.replace("Z", "+00:00"))
    except ValueError as exc:
        raise GoalDispatchValidationError(f"{label} is invalid") from exc
    if parsed.tzinfo is None:
        raise GoalDispatchValidationError(f"{label} requires timezone")
    return parsed.astimezone(timezone.utc)


def validate_policy(policy: dict[str, Any]) -> None:
    if not isinstance(policy, dict):
        raise GoalDispatchValidationError("policy must be an object", code="invalid_policy")
    required = {
        "version", "schema_version", "model_lane", "kill_switch", "allowed_model_ids",
        "terminal_statuses", "successful_terminal_statuses", "fail_closed_risk_flags",
        "max_prompt_bytes", "resource", "learning", "program_seed", "budgets",
    }
    if set(policy) != required:
        raise GoalDispatchValidationError("policy keys are invalid", code="invalid_policy")
    _string(policy["version"], "policy.version")
    if policy["schema_version"] != 1 or policy["model_lane"] != "model-0":
        raise GoalDispatchValidationError("policy schema/model lane is invalid", code="invalid_policy")
    if not isinstance(policy["kill_switch"], bool):
        raise GoalDispatchValidationError("policy.kill_switch must be boolean", code="invalid_policy")
    allowed = _string_list(policy["allowed_model_ids"], "policy.allowed_model_ids")
    terminal = set(_string_list(policy["terminal_statuses"], "policy.terminal_statuses"))
    successful = set(_string_list(policy["successful_terminal_statuses"], "policy.successful_terminal_statuses"))
    if not allowed or terminal != WORKER_TERMINAL_STATUSES or successful != {"done"}:
        raise GoalDispatchValidationError("policy model/status lists are invalid", code="invalid_policy")
    if not _string_list(policy["fail_closed_risk_flags"], "policy.fail_closed_risk_flags"):
        raise GoalDispatchValidationError("policy risk flags are required", code="invalid_policy")
    _integer(policy["max_prompt_bytes"], "policy.max_prompt_bytes", minimum=1)
    if set(policy["resource"]) != {"max_snapshot_age_seconds", "allowed_capabilities"}:
        raise GoalDispatchValidationError("policy.resource keys are invalid", code="invalid_policy")
    _integer(policy["resource"]["max_snapshot_age_seconds"], "resource age", minimum=1)
    if not _string_list(policy["resource"]["allowed_capabilities"], "resource.allowed_capabilities"):
        raise GoalDispatchValidationError("resource capabilities are required", code="invalid_policy")
    learning_keys = {
        "max_payload_bytes", "max_evidence_per_task", "allowed_producers",
        "allowed_policy_hashes", "max_inbox_scan", "max_rejections_per_once",
        "max_item_bytes", "max_snapshot_bytes", "max_ttl_seconds", "max_goal_epoch",
        "promotion_allowlist",
    }
    if set(policy["learning"]) != learning_keys:
        raise GoalDispatchValidationError("policy.learning keys are invalid", code="invalid_policy")
    for key in (
        "max_payload_bytes", "max_evidence_per_task", "max_inbox_scan",
        "max_rejections_per_once", "max_item_bytes", "max_snapshot_bytes",
        "max_ttl_seconds", "max_goal_epoch",
    ):
        value = policy["learning"][key]
        _integer(value, f"policy.learning.{key}", minimum=1)
    producers = _string_list(policy["learning"]["allowed_producers"], "policy.learning.allowed_producers")
    if not producers:
        raise GoalDispatchValidationError("learning producers are required", code="invalid_policy")
    policy_hashes = _string_list(policy["learning"]["allowed_policy_hashes"], "policy.learning.allowed_policy_hashes")
    if not policy_hashes:
        raise GoalDispatchValidationError("learning policy hashes are required", code="invalid_policy")
    for digest in policy_hashes:
        _digest(digest, HEX64, "policy.learning.allowed_policy_hashes")
    promotion_allowlist = policy["learning"]["promotion_allowlist"]
    if not isinstance(promotion_allowlist, dict) or not promotion_allowlist:
        raise GoalDispatchValidationError("learning promotion allowlist is required", code="invalid_policy")
    for task_id, rows in promotion_allowlist.items():
        _string(task_id, "policy.learning.promotion_allowlist task_id")
        if not isinstance(rows, list) or not rows:
            raise GoalDispatchValidationError("learning promotion rows are required", code="invalid_policy")
        for row in rows:
            if not isinstance(row, dict) or set(row) != {"family", "classification"}:
                raise GoalDispatchValidationError("learning promotion row is invalid", code="invalid_policy")
            _string(row["family"], "learning promotion family")
            _string(row["classification"], "learning promotion classification")
    program_seed = policy["program_seed"]
    expected_program_seed = {
        "allowed_producers", "allowed_programs", "max_inbox_scan",
        "max_rejections_per_once", "max_item_bytes", "max_ttl_seconds", "max_goal_epoch",
    }
    if not isinstance(program_seed, dict) or set(program_seed) != expected_program_seed:
        raise GoalDispatchValidationError("program seed policy is invalid", code="invalid_policy")
    if not _string_list(program_seed["allowed_producers"], "program_seed.allowed_producers"):
        raise GoalDispatchValidationError("program seed producers are required", code="invalid_policy")
    for key in ("max_inbox_scan", "max_rejections_per_once", "max_item_bytes", "max_ttl_seconds", "max_goal_epoch"):
        _integer(program_seed[key], f"program_seed.{key}", minimum=1)
    programs = program_seed["allowed_programs"]
    if not isinstance(programs, dict) or not programs:
        raise GoalDispatchValidationError("program seed allowlist is required", code="invalid_policy")
    for program_id, binding in programs.items():
        _string(program_id, "program_seed program_id")
        if not isinstance(binding, dict) or set(binding) != {"program_hash", "config_hash", "compiler_sha256"}:
            raise GoalDispatchValidationError("program seed binding is invalid", code="invalid_policy")
        for field, digest in binding.items():
            _digest(digest, HEX64, f"program_seed.{field}")
    expected_budgets = {
        "max_context_tokens_per_child", "max_token_budget_per_child",
        "max_total_tokens_per_goal", "max_total_children_per_goal", "max_consecutive_children",
    }
    if not isinstance(policy["budgets"], dict) or set(policy["budgets"]) != expected_budgets:
        raise GoalDispatchValidationError("policy budget keys are invalid", code="invalid_policy")
    for key, value in policy["budgets"].items():
        _integer(value, f"policy.budgets.{key}", minimum=1)


def create_state(
    goal_id: str,
    goal_epoch: int,
    *,
    next_tasks: list[dict[str, Any]] | None = None,
    watch_tasks: list[dict[str, Any]] | None = None,
    backlog_tasks: list[dict[str, Any]] | None = None,
) -> dict[str, Any]:
    _string(goal_id, "goal_id")
    _integer(goal_epoch, "goal_epoch", minimum=1)
    return {
        "schema_version": 1,
        "active_goal": {"goal_id": goal_id, "goal_epoch": goal_epoch, "status": "active"},
        "now": None,
        "next": copy.deepcopy(next_tasks or []),
        "watch": copy.deepcopy(watch_tasks or []),
        "backlog": copy.deepcopy(backlog_tasks or []),
        "blocked": [],
        "completed": {},
        "children": {},
        "consumed_receipts": {},
        "consumed_learning_snapshots": {},
        "held_resources": {},
        "held_locks": {},
        "budget_usage": {"total_children": 0, "total_tokens": 0, "consecutive_children": 0},
    }


def _validate_state(state: Any) -> None:
    if not isinstance(state, dict):
        raise GoalDispatchValidationError("state must be an object")
    goal = state.get("active_goal")
    if not isinstance(goal, dict) or goal.get("status") != "active":
        raise GoalDispatchValidationError("one active goal is required")
    _string(goal.get("goal_id"), "active goal id")
    _integer(goal.get("goal_epoch"), "active goal epoch", minimum=1)
    for lane in LANES:
        if not isinstance(state.get(lane), list):
            raise GoalDispatchValidationError(f"state.{lane} must be a list")
    if state.get("now") is not None and not isinstance(state["now"], dict):
        raise GoalDispatchValidationError("state.now must be null or an object")
    for field in (
        "completed", "children", "consumed_receipts", "consumed_learning_snapshots",
        "held_resources", "held_locks",
    ):
        if not isinstance(state.get(field), dict):
            raise GoalDispatchValidationError(f"state.{field} must be an object")
        for key in state[field]:
            _firebase_safe_key(key, f"state.{field} key")
    usage = state.get("budget_usage")
    if not isinstance(usage, dict) or set(usage) != {"total_children", "total_tokens", "consecutive_children"}:
        raise GoalDispatchValidationError("state budget usage is invalid")
    for field, value in usage.items():
        _integer(value, f"state.budget_usage.{field}")


def _bind_active_goal(state: dict[str, Any], event: dict[str, Any]) -> None:
    goal = state["active_goal"]
    if event.get("parent_goal") != goal["goal_id"]:
        raise GoalDispatchValidationError("event parent does not match active goal", code="parent_mismatch")
    if event.get("goal_epoch") != goal["goal_epoch"]:
        raise GoalDispatchValidationError("event epoch does not match active goal", code="epoch_mismatch")


def _task_id(task: Any) -> str:
    if not isinstance(task, dict):
        raise GoalDispatchValidationError("task must be an object")
    return _string(task.get("task_id"), "task_id")


def _validate_risk_assessment(task: dict[str, Any]) -> None:
    assessment = task.get("risk_assessment")
    if not isinstance(assessment, dict):
        raise GoalDispatchValidationError("risk_assessment is required")
    expected = {
        "task_id", "task_fingerprint", "prompt_hash", "risk_flags", "classified_by", "assessment_hash",
    }
    if set(assessment) != expected:
        raise GoalDispatchValidationError("risk_assessment keys are invalid")
    classification = {
        "task_id": task["task_id"],
        "task_fingerprint": task["task_fingerprint"],
        "prompt_hash": canonical_hash(task["prompt"]),
        "risk_flags": task["risk_flags"],
        "classified_by": "main",
    }
    if assessment != {**classification, "assessment_hash": canonical_hash(classification)}:
        raise GoalDispatchValidationError("risk_assessment binding mismatch", code="risk_binding_mismatch")


def _single_line_contract_items(value: Any, label: str, *, required: bool = False) -> list[str]:
    items = _string_list(value, label)
    if required and not items:
        raise GoalDispatchValidationError(f"{label} cannot be empty")
    for item in items:
        if item != item.strip() or any(ord(character) < 32 or ord(character) == 127 for character in item):
            raise GoalDispatchValidationError(f"{label} items must be trimmed single-line text")
    return items


def _safety_contract(task: dict[str, Any]) -> dict[str, Any]:
    body = {
        "capability": task["capability"],
        "locks": task["locks"],
        "done_criteria": task["done_criteria"],
        "forbidden": task["forbidden"],
    }
    return {**body, "contract_hash": canonical_hash(body)}


def _worker_prompt(task: dict[str, Any]) -> str:
    contract = _safety_contract(task)
    lock_text = ", ".join(contract["locks"]) if contract["locks"] else "none"
    lines = [
        task["prompt"],
        "",
        "## Bounded execution contract",
        f"capability: {contract['capability']}",
        f"locks: {lock_text}",
        "완료 조건:",
        *(f"- {item}" for item in contract["done_criteria"]),
        "금지 조건:",
        *(f"- {item}" for item in contract["forbidden"]),
        f"safety_contract_hash: {contract['contract_hash']}",
    ]
    evidence = task.get("learning_evidence")
    if evidence:
        lines.extend(
            [
                "",
                "## Immutable learning evidence pointers",
                canonical_json(evidence),
            ]
        )
    verification = task.get("learning_verification")
    if verification:
        lines.extend(
            [
                "",
                "## Model-0 verification receipt",
                canonical_json(verification),
            ]
        )
    return "\n".join(lines)


def _normalized_task(task: dict[str, Any], state: dict[str, Any], policy: dict[str, Any]) -> dict[str, Any]:
    task_id = _task_id(task)
    unknown = set(task) - TASK_REQUIRED - TASK_OPTIONAL
    missing = TASK_REQUIRED - set(task)
    if unknown or missing:
        raise GoalDispatchValidationError(f"task {task_id} schema mismatch")
    result = copy.deepcopy(task)
    for field in ("dependencies", "risk_flags"):
        result[field] = sorted(set(_string_list(task[field], f"task.{task_id}.{field}")))
    result["locks"] = sorted(set(_single_line_contract_items(task["locks"], f"task.{task_id}.locks")))
    for field in ("done_criteria", "forbidden"):
        result[field] = _single_line_contract_items(
            task[field], f"task.{task_id}.{field}", required=True
        )
    for field in ("resource_id", "capability", "model_id", "model_decision_by", "cwd", "profile", "reasoning_effort", "target_host", "target_node"):
        _string(task[field], f"task.{task_id}.{field}")
    result["capability"] = _single_line_contract_items(
        [task["capability"]], f"task.{task_id}.capability", required=True
    )[0]
    if task["profile"] not in WORKER_PROFILES:
        raise GoalDispatchValidationError(f"task {task_id} profile is not worker-compatible")
    if not isinstance(task["is_owner"], bool):
        raise GoalDispatchValidationError(f"task {task_id} is_owner must be boolean")
    if task["profile"] in {"patch", "yolo"} and task["is_owner"] is not True:
        raise GoalDispatchValidationError(f"task {task_id} write profile requires is_owner=true")
    if task["reasoning_effort"] not in WORKER_REASONING_EFFORTS:
        raise GoalDispatchValidationError(f"task {task_id} reasoning_effort is not worker-compatible")
    if task["target_host"] not in WORKER_TARGET_HOSTS:
        raise GoalDispatchValidationError(f"task {task_id} target_host is not worker-compatible")
    for field in ("context_tokens", "token_budget"):
        _integer(task[field], f"task.{task_id}.{field}")
    _integer(task["ttl_seconds"], f"task.{task_id}.ttl_seconds", minimum=1)
    _integer(task["timeout_seconds"], f"task.{task_id}.timeout_seconds", minimum=1)
    prompt = _string(task["prompt"], f"task.{task_id}.prompt")
    prompt_bytes = len(prompt.encode("utf-8"))
    if task["prompt_bytes"] != prompt_bytes:
        raise GoalDispatchValidationError(f"task {task_id} prompt_bytes mismatch")
    if prompt_bytes > policy["max_prompt_bytes"]:
        raise GoalDispatchValidationError(f"task {task_id} prompt exceeds cap")
    _digest(task["input_evidence_hash"], HEX64, f"task {task_id} input_evidence_hash")
    _digest(task["source_revision"], HEX40, f"task {task_id} source_revision")
    _digest(task["task_fingerprint"], HEX64, f"task {task_id} task_fingerprint")
    if "learning_evidence" in task:
        if not isinstance(task["learning_evidence"], list):
            raise GoalDispatchValidationError(f"task {task_id} learning_evidence is invalid")
        for pointer in task["learning_evidence"]:
            if not isinstance(pointer, dict):
                raise GoalDispatchValidationError(f"task {task_id} learning pointer is invalid")
            if set(pointer) == {"snapshot_id", "evidence_hash"}:
                _string(pointer["snapshot_id"], "learning snapshot_id")
                _digest(pointer["evidence_hash"], HEX64, "learning evidence_hash")
                continue
            expected_pointer = {
                "inbox_id", "snapshot_path", "snapshot_id", "snapshot_hash",
                "policy_hash", "item_hash",
            }
            if set(pointer) != expected_pointer:
                raise GoalDispatchValidationError(f"task {task_id} learning pointer schema mismatch")
            if not str(pointer["snapshot_path"]).startswith(
                "/packhelper/automation_dispatch_v1/learning/snapshots/automation-rule-snapshot-"
            ):
                raise GoalDispatchValidationError(f"task {task_id} learning snapshot path is invalid")
            for field in ("snapshot_hash", "policy_hash", "item_hash"):
                _digest(pointer[field], HEX64, f"learning {field}")
            _string(pointer["inbox_id"], "learning inbox_id")
            _string(pointer["snapshot_id"], "learning snapshot_id")
    if "learning_verification" in task:
        verification = task["learning_verification"]
        expected_verification = {
            "schema_version", "verified_by", "snapshot_body_hash_verified",
            "snapshot_identity_verified", "inbox_item_hash_verified",
            "sequence_binding_verified", "policy_allowlist_verified",
            "snapshot_hash", "item_hash", "policy_hash", "verification_hash",
        }
        if not isinstance(verification, dict) or set(verification) != expected_verification:
            raise GoalDispatchValidationError(
                f"task {task_id} learning verification schema mismatch"
            )
        if verification.get("schema_version") != 1 or verification.get("verified_by") != "model-0":
            raise GoalDispatchValidationError(
                f"task {task_id} learning verification identity mismatch"
            )
        for field in (
            "snapshot_body_hash_verified", "snapshot_identity_verified",
            "inbox_item_hash_verified", "sequence_binding_verified",
            "policy_allowlist_verified",
        ):
            if verification.get(field) is not True:
                raise GoalDispatchValidationError(
                    f"task {task_id} learning verification is not fail-closed"
                )
        for field in ("snapshot_hash", "item_hash", "policy_hash"):
            _digest(verification.get(field), HEX64, f"learning verification {field}")
        verification_body = {
            key: value for key, value in verification.items() if key != "verification_hash"
        }
        if verification.get("verification_hash") != canonical_hash(verification_body):
            raise GoalDispatchValidationError(
                f"task {task_id} learning verification hash mismatch"
            )
    if "recurring_watch" in task and not isinstance(task["recurring_watch"], bool):
        raise GoalDispatchValidationError(f"task {task_id} recurring_watch must be boolean")
    _validate_risk_assessment(result)
    result["parent_goal"] = state["active_goal"]["goal_id"]
    result["goal_epoch"] = state["active_goal"]["goal_epoch"]
    if len(_worker_prompt(result).encode("utf-8")) > policy["max_prompt_bytes"]:
        raise GoalDispatchValidationError(f"task {task_id} worker prompt exceeds cap")
    return result


def _block(state: dict[str, Any], task: dict[str, Any], reason: str, **details: Any) -> None:
    row = copy.deepcopy(task)
    row["block_reason"] = reason
    row.update(details)
    state["blocked"].append(row)


def _budget_block_reason(task: dict[str, Any], usage: dict[str, int], policy: dict[str, Any]) -> str | None:
    budget = policy["budgets"]
    if task["context_tokens"] > budget["max_context_tokens_per_child"]:
        return "context_budget_exceeded"
    if task["token_budget"] > budget["max_token_budget_per_child"]:
        return "child_token_budget_exceeded"
    if usage["total_tokens"] + task["token_budget"] > budget["max_total_tokens_per_goal"]:
        return "goal_token_budget_exceeded"
    if usage["total_children"] >= budget["max_total_children_per_goal"]:
        return "goal_child_budget_exceeded"
    if usage["consecutive_children"] >= budget["max_consecutive_children"]:
        return "consecutive_child_budget_exceeded"
    return None


def _resource_ready(task: dict[str, Any], event: dict[str, Any], policy: dict[str, Any]) -> bool:
    snapshot = event.get("resource_snapshot")
    if not isinstance(snapshot, dict):
        return False
    required = {
        "status", "checked_at", "resource_id", "capability", "supported_models",
        "capacity", "lease_id", "lease_epoch", "lease_expires_at",
    }
    if set(snapshot) != required or snapshot.get("status") != "ready":
        return False
    try:
        now = _timestamp(event.get("now"), "dispatch.now")
        checked = _timestamp(snapshot.get("checked_at"), "resource.checked_at")
        expires = _timestamp(snapshot.get("lease_expires_at"), "resource.lease_expires_at")
    except GoalDispatchValidationError:
        return False
    age = (now - checked).total_seconds()
    if age < 0 or age > policy["resource"]["max_snapshot_age_seconds"] or expires <= now:
        return False
    if snapshot.get("resource_id") != task["resource_id"] or snapshot.get("capability") != task["capability"]:
        return False
    models = snapshot.get("supported_models")
    if not isinstance(models, list) or task["model_id"] not in models:
        return False
    if not isinstance(snapshot.get("capacity"), int) or isinstance(snapshot["capacity"], bool) or snapshot["capacity"] < 1:
        return False
    if not isinstance(snapshot.get("lease_epoch"), int) or isinstance(snapshot["lease_epoch"], bool) or snapshot["lease_epoch"] < 1:
        return False
    return isinstance(snapshot.get("lease_id"), str) and bool(snapshot["lease_id"])


def _identity(task: dict[str, Any]) -> dict[str, Any]:
    contract = _safety_contract(task)
    identity = {
        "parent_goal": task["parent_goal"], "goal_epoch": task["goal_epoch"],
        "task_id": task["task_id"], "task_fingerprint": task["task_fingerprint"],
        "source_revision": task["source_revision"], "input_evidence_hash": task["input_evidence_hash"],
        "prompt_hash": canonical_hash(task["prompt"]),
        "model_id": task["model_id"], "reasoning_effort": task["reasoning_effort"],
        "profile": task["profile"], "is_owner": task["is_owner"],
        "risk_assessment_hash": task["risk_assessment"]["assessment_hash"],
        "capability": task["capability"], "locks": task["locks"],
        "done_criteria": task["done_criteria"], "forbidden": task["forbidden"],
        "safety_contract_hash": contract["contract_hash"],
        "worker_prompt_hash": canonical_hash(_worker_prompt(task)),
        "target_host": task["target_host"], "target_node": task["target_node"],
    }
    if task.get("learning_evidence"):
        identity["learning_evidence_hash"] = canonical_hash(task["learning_evidence"])
    if task.get("learning_verification"):
        identity["learning_verification_hash"] = canonical_hash(task["learning_verification"])
    if task.get("recurring_watch") is True:
        identity["recurring_watch"] = True
    return identity


def _make_child(
    task: dict[str, Any], snapshot: dict[str, Any], event_now: str, policy: dict[str, Any]
) -> tuple[dict[str, Any], dict[str, Any]]:
    identity = _identity(task)
    safety_contract = _safety_contract(task)
    worker_prompt = _worker_prompt(task)
    worker_prompt_bytes = len(worker_prompt.encode("utf-8"))
    if worker_prompt_bytes > policy["max_prompt_bytes"]:
        raise GoalDispatchValidationError(f"task {task['task_id']} worker prompt exceeds cap")
    child_id = f"child-{canonical_hash(identity)[:24]}"
    request_binding = {
        **identity, "child_id": child_id, "resource_id": task["resource_id"],
        "lease_id": snapshot["lease_id"], "lease_epoch": snapshot["lease_epoch"],
        "policy_version": policy["version"],
    }
    request_id = f"request-{canonical_hash(request_binding)[:24]}"
    child = {
        **task,
        "child_id": child_id,
        "request_id": request_id,
        "status": "pending",
        "policy_version": policy["version"],
        "lease_id": snapshot["lease_id"],
        "lease_epoch": snapshot["lease_epoch"],
        "lease_expires_at": snapshot["lease_expires_at"],
        "safety_contract_hash": safety_contract["contract_hash"],
        "worker_prompt_hash": canonical_hash(worker_prompt),
    }
    created_at_ms = int(_timestamp(event_now, "dispatch.now").timestamp() * 1000)
    envelope = {
        "task": worker_prompt,
        "prompt": worker_prompt,
        "prompt_bytes": worker_prompt_bytes,
        "context_tokens": task["context_tokens"],
        "token_budget": task["token_budget"],
        "cwd": task["cwd"],
        "profile": task["profile"],
        "is_owner": task["is_owner"],
        "model": task["model_id"],
        "reasoning_effort": task["reasoning_effort"],
        "target_host": task["target_host"],
        "target_node": task["target_node"],
        "created_at_ms": created_at_ms,
        "ttl_ms": task["ttl_seconds"] * 1000,
        "timeout_sec": task["timeout_seconds"],
        "status": "pending",
        "child_id": child_id,
        "request_id": request_id,
        "parent_goal": task["parent_goal"],
        "goal_epoch": task["goal_epoch"],
        "source_revision": task["source_revision"],
        "task_fingerprint": task["task_fingerprint"],
        "input_evidence_hash": task["input_evidence_hash"],
        "policy_version": policy["version"],
        "resource_id": task["resource_id"],
        "capability": task["capability"],
        "locks": copy.deepcopy(task["locks"]),
        "done_criteria": copy.deepcopy(task["done_criteria"]),
        "forbidden": copy.deepcopy(task["forbidden"]),
        "safety_contract_hash": safety_contract["contract_hash"],
        "lease_id": snapshot["lease_id"],
        "lease_epoch": snapshot["lease_epoch"],
        "lease_expires_at": snapshot["lease_expires_at"],
    }
    return child, envelope


def _dispatch_next(state: dict[str, Any], event: dict[str, Any], policy: dict[str, Any]) -> tuple[dict[str, Any], dict[str, Any]]:
    if policy["kill_switch"]:
        return state, {"status": "kill_switch", "reason": "automation_dispatch_disabled"}
    if state["now"] is not None:
        return state, {"status": "busy", "child_id": state["now"]["child_id"]}

    saw_temporary = False
    last_block: dict[str, Any] | None = None
    index = 0
    while index < len(state["next"]):
        raw = state["next"][index]
        task = _normalized_task(raw, state, policy)
        completed_dependencies = {
            dependency: _mapping_entry(state["completed"], "task", dependency)
            for dependency in task["dependencies"]
        }
        failed = [
            dependency
            for dependency, row in completed_dependencies.items()
            if isinstance(row, dict)
            and row.get("status") not in policy["successful_terminal_statuses"]
        ]
        missing = [
            dependency
            for dependency, row in completed_dependencies.items()
            if not isinstance(row, dict)
        ]
        permanent_reason: str | None = None
        details: dict[str, Any] = {}
        if failed:
            permanent_reason, details = "dependency_failed", {"dependencies": failed}
        elif set(task["risk_flags"]) & set(policy["fail_closed_risk_flags"]):
            permanent_reason = "high_risk_fail_closed"
            details = {"risk_flags": sorted(set(task["risk_flags"]) & set(policy["fail_closed_risk_flags"]))}
        elif task["model_decision_by"] != "main":
            permanent_reason = "model_decision_not_main"
        elif task["model_id"] not in policy["allowed_model_ids"]:
            permanent_reason = "model_not_allowlisted"
        else:
            permanent_reason = _budget_block_reason(task, state["budget_usage"], policy)
        if permanent_reason:
            state["next"].pop(index)
            _block(state, task, permanent_reason, **details)
            last_block = {"status": "blocked", "task_id": task["task_id"], "reason": permanent_reason}
            continue
        resource_held = _mapping_entry(
            state["held_resources"], "resource", task["resource_id"]
        )
        lock_held = any(
            _mapping_entry(state["held_locks"], "lock", lock) is not None
            for lock in task["locks"]
        )
        if missing or resource_held is not None or lock_held:
            saw_temporary = True
            index += 1
            continue
        if not _resource_ready(task, event, policy):
            saw_temporary = True
            index += 1
            continue

        snapshot = event["resource_snapshot"]
        child, envelope = _make_child(task, snapshot, event["now"], policy)
        state["next"].pop(index)
        if child["child_id"] in state["children"]:
            return state, {"status": "child_replay", "child_id": child["child_id"], "task_id": task["task_id"]}
        state["now"] = copy.deepcopy(child)
        state["children"][child["child_id"]] = copy.deepcopy(child)
        state["held_resources"][firebase_storage_key("resource", task["resource_id"])] = {
            "resource_id": task["resource_id"],
            "child_id": child["child_id"],
        }
        for lock in task["locks"]:
            state["held_locks"][firebase_storage_key("lock", lock)] = {
                "lock": lock,
                "child_id": child["child_id"],
            }
        usage = state["budget_usage"]
        usage["total_children"] += 1
        usage["total_tokens"] += task["token_budget"]
        usage["consecutive_children"] += 1
        return state, {"status": "dispatched", "next_child": copy.deepcopy(envelope)}
    if not state["next"]:
        if last_block is not None:
            return state, last_block
        return state, {"status": "idle", "reason": "next_lane_empty"}
    return state, {"status": "resource_unavailable" if saw_temporary else "idle"}


def _terminal_receipt(state: dict[str, Any], event: dict[str, Any], policy: dict[str, Any]) -> tuple[dict[str, Any], dict[str, Any]]:
    receipt_id = _firebase_safe_key(event.get("receipt_id"), "terminal receipt_id")
    fingerprint = canonical_hash(event)
    if receipt_id in state["consumed_receipts"]:
        if state["consumed_receipts"][receipt_id] != fingerprint:
            raise GoalDispatchValidationError("receipt replay payload changed", code="receipt_conflict")
        return state, {"status": "receipt_replay", "receipt_id": receipt_id}
    _bind_active_goal(state, event)
    evidence = event.get("evidence")
    if not isinstance(evidence, dict) or event.get("evidence_hash") != canonical_hash(evidence):
        raise GoalDispatchValidationError("terminal evidence hash mismatch", code="evidence_hash_mismatch")
    terminal_status = event.get("terminal_status")
    if terminal_status not in policy["terminal_statuses"]:
        raise GoalDispatchValidationError("receipt terminal_status is invalid")
    child_id = event.get("child_id")
    child = state["children"].get(child_id)
    if child is None or state["now"] is None or state["now"].get("child_id") != child_id:
        raise GoalDispatchValidationError("receipt child is not current", code="unknown_child")
    bindings = ("request_id", "source_revision", "task_fingerprint", "input_evidence_hash")
    for field in bindings:
        if event.get(field) != child.get(field):
            raise GoalDispatchValidationError(f"terminal {field} binding mismatch", code="child_binding_mismatch")
    if event.get("parent_goal") != child["parent_goal"] or event.get("goal_epoch") != child["goal_epoch"]:
        raise GoalDispatchValidationError("terminal goal binding mismatch", code="child_binding_mismatch")
    actual = _integer(event.get("actual_token_usage"), "actual_token_usage")
    budget_overrun = actual > child["token_budget"]
    if budget_overrun and terminal_status == "done":
        raise GoalDispatchValidationError(
            "successful terminal cannot exceed token reservation", code="token_budget_overrun"
        )

    completed_child = copy.deepcopy(child)
    completed_child.update({"status": terminal_status, "actual_token_usage": actual, "terminal_evidence_hash": event["evidence_hash"]})
    state["children"][child_id] = completed_child
    recurring_success = (
        child.get("recurring_watch") is True
        and terminal_status in policy["successful_terminal_statuses"]
        and not budget_overrun
    )
    if not recurring_success:
        state["completed"][firebase_storage_key("task", child["task_id"])] = {
            "task_id": child["task_id"],
            "child_id": child_id, "status": terminal_status, "evidence_hash": event["evidence_hash"],
            "request_id": child["request_id"],
        }
    state["now"] = None
    resource_key = firebase_storage_key("resource", child["resource_id"])
    if _entry_child_id(state["held_resources"].get(resource_key)) == child_id:
        del state["held_resources"][resource_key]
    for lock in child["locks"]:
        lock_key = firebase_storage_key("lock", lock)
        if _entry_child_id(state["held_locks"].get(lock_key)) == child_id:
            del state["held_locks"][lock_key]
    state["budget_usage"]["total_tokens"] += actual - child["token_budget"]
    state["consumed_receipts"][receipt_id] = fingerprint
    accepted = {
        "receipt_id": receipt_id, "child_id": child_id, "request_id": child["request_id"],
        "task_id": child["task_id"], "terminal_status": terminal_status,
    }
    if budget_overrun:
        _block(
            state,
            child,
            "actual_token_budget_exceeded",
            reserved_token_budget=child["token_budget"],
            actual_token_usage=actual,
            terminal_status=terminal_status,
        )
        return state, {
            "status": "terminal_budget_overrun_blocked",
            "accepted_terminal": accepted,
        }
    if recurring_success:
        recurring_task = {key: copy.deepcopy(child[key]) for key in TASK_REQUIRED}
        recurring_task["recurring_watch"] = True
        state["watch"].append(recurring_task)
        state["budget_usage"]["consecutive_children"] = 0
        return state, {
            "status": "terminal_accepted_recurring_watch",
            "accepted_terminal": accepted,
        }
    next_state, next_result = _dispatch_next(state, event, policy)
    result: dict[str, Any] = {"status": "terminal_accepted", "accepted_terminal": accepted}
    if "next_child" in next_result:
        result["next_child"] = next_result["next_child"]
    else:
        result["next_status"] = next_result["status"]
    return next_state, result


def _learning_snapshot(state: dict[str, Any], event: dict[str, Any], policy: dict[str, Any]) -> tuple[dict[str, Any], dict[str, Any]]:
    snapshot_id = _firebase_safe_key(event.get("snapshot_id"), "learning snapshot_id")
    fingerprint = canonical_hash(event)
    consumed = state["consumed_learning_snapshots"]
    if snapshot_id in consumed:
        if consumed[snapshot_id] != fingerprint:
            raise GoalDispatchValidationError("learning snapshot replay changed", code="receipt_conflict")
        return state, {"status": "learning_snapshot_replay", "snapshot_id": snapshot_id}
    evidence = event.get("evidence")
    if not isinstance(evidence, dict) or event.get("evidence_hash") != canonical_hash(evidence):
        raise GoalDispatchValidationError("learning evidence hash mismatch", code="evidence_hash_mismatch")
    if len(canonical_json(evidence).encode("utf-8")) > policy["learning"]["max_payload_bytes"]:
        raise GoalDispatchValidationError("learning evidence exceeds payload cap")
    targets = set(_string_list(event.get("target_task_ids", []), "target_task_ids"))
    attached: list[str] = []
    cap_reached: list[str] = []
    for lane in ("watch", "backlog"):
        for task in state[lane]:
            task_id = _task_id(task)
            if task_id not in targets:
                continue
            rows = task.setdefault("learning_evidence", [])
            if not isinstance(rows, list):
                raise GoalDispatchValidationError("task learning evidence is invalid")
            if len(rows) >= policy["learning"]["max_evidence_per_task"]:
                cap_reached.append(task_id)
                continue
            rows.append({"snapshot_id": snapshot_id, "evidence_hash": event["evidence_hash"]})
            attached.append(task_id)
    consumed[snapshot_id] = fingerprint
    return state, {
        "status": "learning_evidence_attached", "attached_to": attached,
        "cap_reached": cap_reached, "ignored_targets": sorted(targets - set(attached) - set(cap_reached)),
    }


def _promote_existing_watch_once(
    state: dict[str, Any], event: dict[str, Any], policy: dict[str, Any]
) -> tuple[dict[str, Any], dict[str, Any]]:
    expected_keys = {
        "type", "inbox_id", "parent_goal", "goal_epoch", "snapshot_path",
        "snapshot_id", "snapshot_hash", "policy_hash", "action", "target_lane",
        "task_id", "task_fingerprint", "prompt_hash", "risk_assessment_hash",
        "producer", "created_at_ms", "expires_at_ms", "item_hash",
        "model0_verification",
    }
    if set(event) != expected_keys:
        raise GoalDispatchValidationError("learning promotion event keys are invalid")
    inbox_id = _firebase_safe_key(event.get("inbox_id"), "learning inbox_id")
    fingerprint = canonical_hash(event)
    consumed = state["consumed_learning_snapshots"]
    consumed_key = firebase_storage_key("learning_inbox", inbox_id)
    if consumed_key in consumed:
        if consumed[consumed_key] != fingerprint:
            raise GoalDispatchValidationError("learning inbox replay changed", code="receipt_conflict")
        return state, {"status": "learning_promotion_replay", "inbox_id": inbox_id}
    _bind_active_goal(state, event)
    if event.get("action") != "promote_existing_watch_once" or event.get("target_lane") != "watch":
        raise GoalDispatchValidationError("learning promotion action is invalid")
    for field in ("snapshot_hash", "policy_hash", "item_hash", "task_fingerprint", "prompt_hash", "risk_assessment_hash"):
        _digest(event.get(field), HEX64, f"learning {field}")
    for field in ("snapshot_path", "snapshot_id", "producer"):
        _string(event.get(field), f"learning {field}")
    verification = event.get("model0_verification")
    if not isinstance(verification, dict):
        raise GoalDispatchValidationError(
            "learning model-0 verification is missing", code="learning_verification_missing"
        )
    created = _integer(event.get("created_at_ms"), "learning created_at_ms", minimum=1)
    expires = _integer(event.get("expires_at_ms"), "learning expires_at_ms", minimum=1)
    if expires <= created or expires - created > policy["learning"]["max_ttl_seconds"] * 1000:
        raise GoalDispatchValidationError("learning expiry is invalid")
    if event.get("producer") not in policy["learning"]["allowed_producers"]:
        raise GoalDispatchValidationError("learning producer is not allowlisted", code="producer_not_allowed")
    if event.get("policy_hash") not in policy["learning"]["allowed_policy_hashes"]:
        raise GoalDispatchValidationError("learning policy is not allowlisted", code="policy_not_allowed")

    task_id = _string(event.get("task_id"), "learning task_id")
    if task_id not in policy["learning"]["promotion_allowlist"]:
        raise GoalDispatchValidationError("learning task is not promotion-allowlisted", code="promotion_not_allowed")
    if isinstance(state.get("now"), dict) and state["now"].get("task_id") == task_id:
        raise GoalDispatchValidationError("learning target is current", code="learning_target_now")
    if any(isinstance(row, dict) and row.get("task_id") == task_id for row in state["next"]):
        raise GoalDispatchValidationError("learning target is already next", code="learning_target_next")
    if _mapping_entry(state["completed"], "task", task_id) is not None:
        raise GoalDispatchValidationError("learning target is completed", code="learning_target_completed")
    matches = [index for index, row in enumerate(state["watch"]) if isinstance(row, dict) and row.get("task_id") == task_id]
    if len(matches) != 1:
        raise GoalDispatchValidationError("learning target watch binding is missing", code="learning_target_missing")
    index = matches[0]
    normalized = _normalized_task(state["watch"][index], state, policy)
    bindings = {
        "task_fingerprint": normalized["task_fingerprint"],
        "prompt_hash": canonical_hash(normalized["prompt"]),
        "risk_assessment_hash": normalized["risk_assessment"]["assessment_hash"],
    }
    for field, actual in bindings.items():
        if event.get(field) != actual:
            raise GoalDispatchValidationError(
                f"learning {field} binding mismatch", code="learning_task_binding_mismatch"
            )
    promoted = copy.deepcopy(state["watch"][index])
    rows = promoted.setdefault("learning_evidence", [])
    if len(rows) >= policy["learning"]["max_evidence_per_task"]:
        raise GoalDispatchValidationError("task learning evidence cap reached", code="learning_evidence_cap")
    rows.append(
        {
            "inbox_id": inbox_id,
            "snapshot_path": event["snapshot_path"],
            "snapshot_id": event["snapshot_id"],
            "snapshot_hash": event["snapshot_hash"],
            "policy_hash": event["policy_hash"],
            "item_hash": event["item_hash"],
        }
    )
    promoted["learning_verification"] = copy.deepcopy(verification)
    state["watch"].pop(index)
    state["next"].append(promoted)
    consumed[consumed_key] = fingerprint
    return state, {
        "status": "learning_watch_promoted",
        "inbox_id": inbox_id,
        "task_id": task_id,
        "snapshot_id": event["snapshot_id"],
    }


def _main_checkpoint(state: dict[str, Any], event: dict[str, Any]) -> tuple[dict[str, Any], dict[str, Any]]:
    receipt_id = _firebase_safe_key(event.get("receipt_id"), "checkpoint receipt_id")
    fingerprint = canonical_hash(event)
    if receipt_id in state["consumed_receipts"]:
        if state["consumed_receipts"][receipt_id] != fingerprint:
            raise GoalDispatchValidationError("checkpoint replay changed", code="receipt_conflict")
        return state, {"status": "checkpoint_replay", "receipt_id": receipt_id}
    _bind_active_goal(state, event)
    evidence = event.get("evidence")
    if not isinstance(evidence, dict) or event.get("evidence_hash") != canonical_hash(evidence):
        raise GoalDispatchValidationError("checkpoint evidence hash mismatch", code="evidence_hash_mismatch")
    if event.get("signed_by") != "main":
        raise GoalDispatchValidationError("checkpoint signer must be main")
    base = {
        "receipt_id": receipt_id,
        "checkpoint_id": event.get("checkpoint_id"),
        "parent_goal": event.get("parent_goal"),
        "goal_epoch": event.get("goal_epoch"),
        "signed_by": event.get("signed_by"),
        "evidence_hash": event.get("evidence_hash"),
    }
    _string(base["checkpoint_id"], "checkpoint_id")
    if event.get("signature_hash") != canonical_hash(base):
        raise GoalDispatchValidationError("checkpoint signature mismatch")
    state["budget_usage"]["consecutive_children"] = 0
    state["consumed_receipts"][receipt_id] = fingerprint
    return state, {"status": "checkpoint_accepted", "receipt_id": receipt_id}


def reduce_dispatch(state: dict[str, Any], event: dict[str, Any], policy: dict[str, Any]) -> tuple[dict[str, Any], dict[str, Any]]:
    validate_policy(policy)
    _validate_state(state)
    if not isinstance(event, dict) or not isinstance(event.get("type"), str):
        raise GoalDispatchValidationError("event.type is required")
    updated = copy.deepcopy(state)
    if event["type"] == "dispatch":
        _bind_active_goal(updated, event)
        return _dispatch_next(updated, event, policy)
    if event["type"] == "terminal_receipt":
        return _terminal_receipt(updated, event, policy)
    if event["type"] == "automation_learning_snapshot":
        return _learning_snapshot(updated, event, policy)
    if event["type"] == "automation_learning_promote_watch_once":
        return _promote_existing_watch_once(updated, event, policy)
    if event["type"] == "main_checkpoint":
        return _main_checkpoint(updated, event)
    raise GoalDispatchValidationError("unknown event type", code="unknown_event")


__all__ = [
    "DEFAULT_POLICY", "GoalDispatchValidationError", "canonical_hash", "canonical_json",
    "create_state", "firebase_storage_key", "load_policy", "reduce_dispatch", "validate_policy",
]
