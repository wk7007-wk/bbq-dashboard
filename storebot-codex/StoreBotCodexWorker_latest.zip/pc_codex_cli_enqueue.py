#!/usr/bin/env python3
from __future__ import annotations

import argparse
import json
import os
import secrets
import sys
from pathlib import Path
from typing import Any

from storebot_codex_worker import fb_get, fb_put, now_ms


DEFAULT_BASE_PATH = "/packhelper/pc_codex_cli"
BASE_PATH = os.environ.get("PC_CODEX_CLI_BASE_PATH", DEFAULT_BASE_PATH).rstrip("/")
REQUESTS_PATH = f"{BASE_PATH}/requests"
RESULTS_PATH = f"{BASE_PATH}/results"
DEFAULT_NODE = "pc_codex_resource_01"
DEFAULT_CWD = "/root/my-first-project"
DEFAULT_REQUEST_TIMEOUT_SEC = 1200
WSL2_PREFLIGHT_COMMAND = "wsl2_preflight"
WSL2_PREFLIGHT_TIMEOUT_SEC = 60
SERVERPHONE_THERMAL_COMMAND = "serverphone_thermal_diag"
STOREBOT_LOCAL_DIRECT_PROBE_COMMAND = "storebot_local_direct_probe"
SERVERPHONE_STOREBOT_CA_ACTIVATE_COMMAND = "serverphone_storebot_ca_activate"
SERVERPHONE_CODEX_ADMIN_APPLY_COMMAND = "serverphone_codex_admin_apply"
SERVERPHONE_CODEX_HOOK_RESTART_VERIFY_COMMAND = "serverphone_codex_hook_restart_verify"
RUNNER_UPDATE_PLAN_COMMAND = "runner_update_plan"
DELIVERYHELPER_WORKSPACE_BOOTSTRAP_COMMAND = "deliveryhelper_workspace_bootstrap"
DELIVERYHELPER_WORKSPACE_STATUS_COMMAND = "deliveryhelper_workspace_status"
DEFAULT_SERVERPHONE_SERIAL = "R39M30RWR2F"
DEFAULT_SERVERPHONE_ADB_PATH = r"C:\Users\wk700\platform-tools\adb.exe"
DEFAULT_SERVERPHONE_LOGCAT_LIMIT = 300
DEFAULT_STOREBOT_LOCAL_DIRECT_PORT = 8765
DEFAULT_STOREBOT_HOST_FORWARD_PORT = 18765
DEFAULT_STOREBOT_LOCAL_DIRECT_ENDPOINT = "/storebot/request"
DEFAULT_STOREBOT_EXPECTED_MODEL = "SM-G975N"
COMMANDS = {
    "health",
    "status",
    "sync",
    "codex_exec",
    "codex_resume",
    WSL2_PREFLIGHT_COMMAND,
    SERVERPHONE_THERMAL_COMMAND,
    STOREBOT_LOCAL_DIRECT_PROBE_COMMAND,
    SERVERPHONE_STOREBOT_CA_ACTIVATE_COMMAND,
    SERVERPHONE_CODEX_ADMIN_APPLY_COMMAND,
    SERVERPHONE_CODEX_HOOK_RESTART_VERIFY_COMMAND,
    RUNNER_UPDATE_PLAN_COMMAND,
    DELIVERYHELPER_WORKSPACE_BOOTSTRAP_COMMAND,
    DELIVERYHELPER_WORKSPACE_STATUS_COMMAND,
    "stop",
    "shutdown",
}
TERMINAL_STATUSES = {"done", "error", "failed_timeout", "rejected", "expired"}


def read_prompt(args: argparse.Namespace) -> tuple[str, str]:
    if args.prompt_file.strip():
        path = Path(args.prompt_file).expanduser()
        return path.read_text(encoding="utf-8"), path.name
    if args.prompt_text:
        return args.prompt_text, "prompt_text.md"
    if args.stdin or not sys.stdin.isatty():
        return sys.stdin.read(), "stdin.md"
    return "", ""


def build_payload(args: argparse.Namespace) -> tuple[str, dict[str, Any]]:
    command = args.command.strip()
    if command not in COMMANDS:
        raise SystemExit(f"--command must be one of: {', '.join(sorted(COMMANDS))}")
    fixed_ca_activation = command == SERVERPHONE_STOREBOT_CA_ACTIVATE_COMMAND
    fixed_admin_apply = command == SERVERPHONE_CODEX_ADMIN_APPLY_COMMAND
    fixed_hook_restart_verify = command == SERVERPHONE_CODEX_HOOK_RESTART_VERIFY_COMMAND
    fixed_wsl2_preflight = command == WSL2_PREFLIGHT_COMMAND
    if fixed_wsl2_preflight:
        if args.prompt_file.strip() or args.prompt_text or args.stdin:
            raise SystemExit("wsl2_preflight rejects prompt, stdin, and script path input")
        if (
            args.cwd.strip() != DEFAULT_CWD
            or args.branch.strip()
            or args.resume_session_id.strip()
            or args.allow_codex_exec
            or args.request_dry_run
            or args.model.strip()
            or args.reasoning_effort.strip()
            or args.profile != "read_only"
            or args.timeout_sec != DEFAULT_REQUEST_TIMEOUT_SEC
            or args.serial.strip() != DEFAULT_SERVERPHONE_SERIAL
            or args.adb_path.strip() != DEFAULT_SERVERPHONE_ADB_PATH
            or args.limit != DEFAULT_SERVERPHONE_LOGCAT_LIMIT
            or args.expected_serial.strip() != DEFAULT_SERVERPHONE_SERIAL
            or args.expected_model_contains.strip() != DEFAULT_STOREBOT_EXPECTED_MODEL
            or args.local_port != DEFAULT_STOREBOT_LOCAL_DIRECT_PORT
            or args.host_forward_port != DEFAULT_STOREBOT_HOST_FORWARD_PORT
            or args.endpoint.strip() != DEFAULT_STOREBOT_LOCAL_DIRECT_ENDPOINT
            or args.probe_timeout_sec != 90
            or args.request_text.strip()
            or args.deliveryhelper_revision.strip()
            or args.room_id.strip()
            or args.room_name.strip()
            or args.sender.strip()
        ):
            raise SystemExit("wsl2_preflight accepts only its fixed read-only command fields")
    if fixed_ca_activation:
        if args.prompt_file.strip() or args.prompt_text or args.stdin:
            raise SystemExit("serverphone_storebot_ca_activate rejects prompt and stdin input")
        if (
            args.branch.strip()
            or args.resume_session_id.strip()
            or args.allow_codex_exec
            or args.request_dry_run
            or args.model.strip()
            or args.reasoning_effort.strip()
            or args.profile != "read_only"
        ):
            raise SystemExit("serverphone_storebot_ca_activate accepts only its fixed device fields")
    if fixed_admin_apply:
        if args.prompt_file.strip() or args.prompt_text or args.stdin:
            raise SystemExit("serverphone_codex_admin_apply rejects prompt and stdin input")
        if (
            args.branch.strip()
            or args.resume_session_id.strip()
            or args.allow_codex_exec
            or args.request_dry_run
            or args.model.strip()
            or args.reasoning_effort.strip()
            or args.profile != "read_only"
            or args.serial.strip() != DEFAULT_SERVERPHONE_SERIAL
            or args.expected_serial.strip() != DEFAULT_SERVERPHONE_SERIAL
            or args.expected_model_contains.strip() != DEFAULT_STOREBOT_EXPECTED_MODEL
            or args.adb_path.strip() != DEFAULT_SERVERPHONE_ADB_PATH
            or args.request_text.strip()
            or args.room_id.strip()
            or args.room_name.strip()
            or args.sender.strip()
        ):
            raise SystemExit("serverphone_codex_admin_apply accepts no prompt, model, profile, or device overrides")
    if fixed_hook_restart_verify:
        if args.prompt_file.strip() or args.prompt_text or args.stdin:
            raise SystemExit("serverphone_codex_hook_restart_verify rejects prompt and stdin input")
        if (
            args.target_node.strip() != DEFAULT_NODE
            or args.cwd.strip() != DEFAULT_CWD
            or args.branch.strip()
            or args.resume_session_id.strip()
            or args.allow_codex_exec
            or args.request_dry_run
            or args.model.strip()
            or args.reasoning_effort.strip()
            or args.profile != "read_only"
            or args.serial.strip() != DEFAULT_SERVERPHONE_SERIAL
            or args.expected_serial.strip() != DEFAULT_SERVERPHONE_SERIAL
            or args.expected_model_contains.strip() != DEFAULT_STOREBOT_EXPECTED_MODEL
            or args.adb_path.strip() != DEFAULT_SERVERPHONE_ADB_PATH
            or args.endpoint.strip() != DEFAULT_STOREBOT_LOCAL_DIRECT_ENDPOINT
            or args.local_port != DEFAULT_STOREBOT_LOCAL_DIRECT_PORT
            or args.host_forward_port != DEFAULT_STOREBOT_HOST_FORWARD_PORT
            or args.request_text.strip()
            or args.deliveryhelper_revision.strip()
            or args.room_id.strip()
            or args.room_name.strip()
            or args.sender.strip()
        ):
            raise SystemExit("serverphone_codex_hook_restart_verify accepts no prompt, model, profile, path, or device overrides")
    fixed_no_prompt = fixed_ca_activation or fixed_admin_apply or fixed_hook_restart_verify or fixed_wsl2_preflight
    prompt_text, prompt_name = ("", "") if fixed_no_prompt else read_prompt(args)
    if command in {"codex_exec", "codex_resume"}:
        if not args.allow_codex_exec:
            raise SystemExit(f"{command} requires --allow-codex-exec")
        if not prompt_text.strip():
            raise SystemExit(f"{command} requires --prompt-file, --prompt-text, or stdin")
    if command == "codex_resume" and not args.resume_session_id.strip():
        raise SystemExit("codex_resume requires --resume-session-id")

    created_at = now_ms()
    key = args.request_id.strip() or f"pccli_{created_at}_{secrets.token_hex(4)}"
    payload: dict[str, Any] = {
        "status": "pending",
        "command": command,
        "target_node": args.target_node.strip() or DEFAULT_NODE,
        "source": args.source,
        "requester": args.requester,
        "created_at_ms": created_at,
        "ttl_ms": args.ttl_ms,
        "timeout_sec": WSL2_PREFLIGHT_TIMEOUT_SEC if fixed_wsl2_preflight else args.timeout_sec,
    }
    if not fixed_wsl2_preflight:
        payload["cwd"] = args.cwd.strip()
    if args.branch.strip():
        payload["branch"] = args.branch.strip()
    if args.profile.strip() and not fixed_no_prompt:
        payload["profile"] = args.profile.strip()
    if args.model.strip():
        payload["model"] = args.model.strip()
    if args.reasoning_effort.strip():
        payload["reasoning_effort"] = args.reasoning_effort.strip()
    if args.allow_codex_exec:
        payload["allow_codex_exec"] = True
    if args.request_dry_run:
        payload["dry_run"] = True
    if command == SERVERPHONE_THERMAL_COMMAND:
        payload["serial"] = args.serial.strip() or DEFAULT_SERVERPHONE_SERIAL
        payload["adb_path"] = args.adb_path.strip() or DEFAULT_SERVERPHONE_ADB_PATH
        payload["limit"] = args.limit
    if command == STOREBOT_LOCAL_DIRECT_PROBE_COMMAND:
        request_text = args.request_text.strip() or prompt_text.strip()
        if not request_text:
            raise SystemExit("storebot_local_direct_probe requires --request-text, --prompt-text, --prompt-file, or stdin")
        payload["expected_serial"] = args.expected_serial.strip() or args.serial.strip() or DEFAULT_SERVERPHONE_SERIAL
        payload["expected_model_contains"] = args.expected_model_contains.strip() or DEFAULT_STOREBOT_EXPECTED_MODEL
        payload["adb_path"] = args.adb_path.strip() or DEFAULT_SERVERPHONE_ADB_PATH
        payload["local_port"] = args.local_port
        payload["host_forward_port"] = args.host_forward_port
        payload["endpoint"] = args.endpoint.strip() or DEFAULT_STOREBOT_LOCAL_DIRECT_ENDPOINT
        payload["request_text"] = request_text
        if args.probe_timeout_sec > 0:
            payload["probe_timeout_sec"] = args.probe_timeout_sec
        if args.room_id.strip():
            payload["room_id"] = args.room_id.strip()
        if args.room_name.strip():
            payload["room_name"] = args.room_name.strip()
        if args.sender.strip():
            payload["sender"] = args.sender.strip()
    if command == SERVERPHONE_STOREBOT_CA_ACTIVATE_COMMAND:
        payload["expected_serial"] = args.expected_serial.strip() or DEFAULT_SERVERPHONE_SERIAL
        payload["expected_model_contains"] = args.expected_model_contains.strip() or DEFAULT_STOREBOT_EXPECTED_MODEL
        payload["adb_path"] = args.adb_path.strip() or DEFAULT_SERVERPHONE_ADB_PATH
    if command == DELIVERYHELPER_WORKSPACE_BOOTSTRAP_COMMAND:
        payload["deliveryhelper_revision"] = args.deliveryhelper_revision.strip()
    if args.resume_session_id.strip():
        payload["resume_session_id"] = args.resume_session_id.strip()
    if prompt_text and not fixed_no_prompt:
        payload["prompt_file_content"] = prompt_text
        payload["prompt_file_name"] = prompt_name
    return key, payload


def compact_status(item: dict[str, Any]) -> dict[str, Any]:
    result = item.get("result") if isinstance(item.get("result"), dict) else {}
    compact = {
        "status": item.get("status"),
        "command": item.get("command"),
        "worker": item.get("worker") or item.get("node"),
        "resolved_cwd": item.get("resolved_cwd"),
        "returncode": item.get("returncode"),
        "duration_ms": item.get("duration_ms"),
        "summary": result.get("summary"),
        "blocker": result.get("blocker"),
        "error": item.get("error"),
    }
    if item.get("command") == WSL2_PREFLIGHT_COMMAND:
        compact.update(
            {
                "model_lane": result.get("model_lane"),
                "ai_invocations": result.get("ai_invocations"),
                "eligible_for_apply": result.get("eligible_for_apply"),
                "receipt": result.get("receipt"),
            }
        )
    return compact


def wait_for_result(key: str, timeout_sec: int, poll_sec: float) -> dict[str, Any] | None:
    deadline = now_ms() + timeout_sec * 1000
    last_status = ""
    while now_ms() < deadline:
        raw = fb_get(f"{REQUESTS_PATH}/{key}") or {}
        if isinstance(raw, dict):
            status = str(raw.get("status") or "")
            if status and status != last_status:
                print(f"status={status}", flush=True)
                last_status = status
            if status in TERMINAL_STATUSES:
                return raw
        import time

        time.sleep(poll_sec)
    return None


def parse_args(argv: list[str]) -> argparse.Namespace:
    parser = argparse.ArgumentParser(description="Enqueue direct-ish factory PC Codex CLI runner requests")
    parser.add_argument("--command", required=True, choices=sorted(COMMANDS))
    parser.add_argument("--target-node", "--node", dest="target_node", default=DEFAULT_NODE)
    parser.add_argument("--cwd", default=DEFAULT_CWD)
    parser.add_argument("--branch", default="", help="sync target branch; runner only accepts allowed branches")
    parser.add_argument("--prompt-file", default="")
    parser.add_argument("--prompt-text", default="")
    parser.add_argument("--stdin", action="store_true")
    parser.add_argument("--resume-session-id", default="")
    parser.add_argument("--allow-codex-exec", action="store_true", help="required for codex_exec and codex_resume")
    parser.add_argument("--request-dry-run", action="store_true", help="runner builds codex command/prompt but does not execute it")
    parser.add_argument("--profile", choices=["read_only", "patch", "yolo"], default="read_only")
    parser.add_argument("--model", default="")
    parser.add_argument("--reasoning-effort", default="")
    parser.add_argument("--serial", default=DEFAULT_SERVERPHONE_SERIAL, help="serverphone serial for serverphone_thermal_diag")
    parser.add_argument("--adb-path", default=DEFAULT_SERVERPHONE_ADB_PATH, help="absolute factory-PC adb.exe path for serverphone_thermal_diag")
    parser.add_argument("--limit", type=int, default=DEFAULT_SERVERPHONE_LOGCAT_LIMIT, help="logcat line limit for serverphone_thermal_diag")
    parser.add_argument("--expected-serial", default=DEFAULT_SERVERPHONE_SERIAL, help="serverphone serial for storebot_local_direct_probe")
    parser.add_argument("--expected-model-contains", default=DEFAULT_STOREBOT_EXPECTED_MODEL, help="adb devices -l model substring for storebot_local_direct_probe")
    parser.add_argument("--local-port", type=int, default=DEFAULT_STOREBOT_LOCAL_DIRECT_PORT, help="device local-direct port for storebot_local_direct_probe")
    parser.add_argument("--host-forward-port", type=int, default=DEFAULT_STOREBOT_HOST_FORWARD_PORT, help="host tcp forward port for storebot_local_direct_probe")
    parser.add_argument("--endpoint", default=DEFAULT_STOREBOT_LOCAL_DIRECT_ENDPOINT, help="local-direct HTTP endpoint for storebot_local_direct_probe")
    parser.add_argument("--request-text", default="", help="chat text for storebot_local_direct_probe")
    parser.add_argument("--deliveryhelper-revision", default="", help="fixed DeliveryHelper revision for workspace bootstrap")
    parser.add_argument("--room-id", default="", help="optional StoreBot room_id for storebot_local_direct_probe")
    parser.add_argument("--room-name", default="", help="optional StoreBot room_name for storebot_local_direct_probe")
    parser.add_argument("--sender", default="", help="optional sender label for storebot_local_direct_probe")
    parser.add_argument("--probe-timeout-sec", type=int, default=90, help="overall timeout for storebot_local_direct_probe")
    parser.add_argument("--request-timeout-sec", "--timeout-sec", dest="timeout_sec", type=int, default=DEFAULT_REQUEST_TIMEOUT_SEC)
    parser.add_argument("--ttl-ms", type=int, default=6 * 60 * 60 * 1000)
    parser.add_argument("--requester", default="personal_codex")
    parser.add_argument("--source", default="personal_codex_pc_cli")
    parser.add_argument("--request-id", default="")
    parser.add_argument("--wait", action="store_true")
    parser.add_argument("--wait-timeout-sec", type=int, default=1500)
    parser.add_argument("--poll-sec", type=float, default=5.0)
    parser.add_argument("--dry-run", action="store_true", help="print payload only; do not write Firebase")
    return parser.parse_args(argv)


def main(argv: list[str]) -> int:
    args = parse_args(argv)
    key, payload = build_payload(args)
    output = {"key": key, "path": f"{REQUESTS_PATH}/{key}", "payload": payload}
    if args.dry_run:
        print(json.dumps(output, ensure_ascii=False, indent=2))
        return 0
    fb_put(f"{REQUESTS_PATH}/{key}", payload)
    print(f"enqueued {key} path={REQUESTS_PATH}/{key} command={payload['command']} target_node={payload['target_node']}")
    if not args.wait:
        return 0
    result = wait_for_result(key, args.wait_timeout_sec, args.poll_sec)
    if result is None:
        print(f"timeout waiting pc cli request={key}", file=sys.stderr)
        return 2
    print(json.dumps({"key": key, **compact_status(result)}, ensure_ascii=False, indent=2))
    return 0 if result.get("status") == "done" else 1


if __name__ == "__main__":
    raise SystemExit(main(sys.argv[1:]))
