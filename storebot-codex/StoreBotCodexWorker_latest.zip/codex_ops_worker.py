#!/usr/bin/env python3
from __future__ import annotations

import argparse
import hashlib
import json
import os
import re
import secrets
import signal
import shutil
import subprocess
import sys
import tempfile
import time
import urllib.error
import urllib.request
from pathlib import Path
from typing import Any

from codex_ops_adb_check import adb_check_requested, run_adb_check
from codex_ops_kakao_wake import exit_code_for_result as kakao_exit_code_for_result
from codex_ops_kakao_wake import kakao_request_requested, run_kakao_wake
from codex_ops_posdelay_watchdog import exit_code_for_result as posdelay_exit_code_for_result
from codex_ops_posdelay_watchdog import posdelay_request_requested, run_posdelay_watchdog
from codex_ops_storebottermux_watchdog import exit_code_for_result as storebottermux_exit_code_for_result
from codex_ops_storebottermux_watchdog import run_storebottermux_watchdog, storebottermux_request_requested
from codex_sdk_runner import choose_engine, normalize_engine, probe_codex_sdk
from storebot_codex_worker import compact_error, fb_get, fb_get_query, fb_patch, fb_put, fb_url, now_ms, sanitize_key


CODEX_OPS_BASE_PATH = os.environ.get("CODEX_OPS_BASE_PATH", "/packhelper/codex_ops_v2").rstrip("/")
AI_OPS_BASE_PATH = os.environ.get("AI_OPS_BASE_PATH", "/packhelper/ai_ops_monitor_v2").rstrip("/")
REQUESTS_PATH = f"{CODEX_OPS_BASE_PATH}/requests"
RESULTS_PATH = f"{CODEX_OPS_BASE_PATH}/results"
HEARTBEAT_PATH = f"{CODEX_OPS_BASE_PATH}/heartbeat"
LOCKS_PATH = f"{CODEX_OPS_BASE_PATH}/locks"
ALLOWED_REASONING = {"minimal", "low", "medium", "high", "xhigh"}
ALLOWED_PROFILES = {"read_only", "patch", "yolo"}
RUNNING_STATUSES = {
    "running",
    "processing",
    "building",
    "needs_approval",
    "adb_testing",
    "kakao_testing",
    "posdelay_testing",
    "storebottermux_testing",
}
TERMINAL_STATUSES = {"done", "error", "failed_timeout", "stale_killed", "rejected", "expired"}
CLAIMABLE_STATUSES = {"pending"}
PAUSED_EXTERNAL_STATUSES = {"paused_external_session"}
DEFAULT_CWD = "/root/my-first-project"
RESUME_PROMPT_ACTION = "codex_resume_prompt_file"
ADB_CHECK_ACTION = "adb_check"
DIRECT_PROBE_ACTION = "direct_probe"
PROMPT_SPOOL_DIR_NAME = ".codex_ops_prompt_spool"
SESSION_ID_RE = re.compile(r"^[0-9A-Fa-f]{8}-[0-9A-Fa-f]{4}-[0-9A-Fa-f]{4}-[0-9A-Fa-f]{4}-[0-9A-Fa-f]{12}$")
SHARED_CONTEXT_DIR = Path(DEFAULT_CWD) / "ai_ops_context"
CODEX_PATH_PREFIX = "/root/.nvm/versions/node/v22.22.1/bin:/root/.local/bin:/root/.codex/bin:/usr/local/bin:/usr/bin:/bin"
SEVERITY_SCORE = {"ok": 0, "info": 0, "warn": 1, "error": 2, "critical": 3}
DEFAULT_LOCK_TTL_SEC = 30 * 60
DEFAULT_CODEX_PREFLIGHT_TIMEOUT_SEC = 5
DEFAULT_CODEX_PREFLIGHT_CACHE_SEC = 60
DEFAULT_ORPHAN_CHILD_GRACE_SEC = 120
AUTOMATION_BOUNDED_CAPABILITY = "read_only_analysis"
AUTOMATION_BOUNDED_MAX_TOKEN_BUDGET = 16_000
AUTOMATION_BOUNDED_MAX_CONTEXT_TOKENS = 4_000
AUTOMATION_BOUNDED_MAX_TIMEOUT_SEC = 90
AUTOMATION_BOUNDED_CONTEXT_WINDOW = 16_000
AUTOMATION_BOUNDED_COMPACT_LIMIT = 12_000
AUTOMATION_BOUNDED_TOOL_OUTPUT_LIMIT = 1_000
AUTOMATION_BOUNDED_REQUIRED_FORBIDDEN = frozenset(
    {
        "tool_use",
        "file_or_repo_read",
        "file_or_repo_write",
        "git_mutation",
        "build_or_package",
        "deploy_or_publish",
        "network_access",
        "firebase_read_or_write",
        "adb_or_device_action",
        "physical_action",
        "process_start_stop_or_signal",
    }
)
HOOK_POLICY_PROBE_NAME = "codex_hook_policy_probe.py"
HOOK_POLICY_SOURCE_NAME = "minimal_managed_lifecycle.py"
ALLOWED_TARGET_HOSTS = {"subphone", "pc", "any"}
FOREIGN_POSIX_CWD_PREFIXES = ("/root", "/sdcard", "/data")
REQUEST_PROGRESS_CLEAR_FIELDS = {
    "live_status": None,
    "current_phase": None,
    "current_detail": None,
    "current_elapsed_ms": None,
    "codex_process_pid": None,
    "codex_process_worker_started_at_ms": None,
}
BUNDLE_STATE_FILE_NAME = ".storebot_codex_bundle_state.json"
BUNDLE_METADATA_FILE_NAMES = (
    BUNDLE_STATE_FILE_NAME,
    "native_bundle_sync.json",
    "bundle.json",
    "bundle_manifest.json",
)
REQUIRED_BUNDLE_HELPERS = (
    "scripts/codex_hook_policy_probe.py",
    "scripts/codex_fresh_hook_receipt_verifier.py",
    "scripts/codex_hooks/minimal_managed_lifecycle.py",
    "scripts/codex_ops_worker.py",
    "scripts/codex_ops_enqueue.py",
    "scripts/codex_sdk_runner.py",
    "scripts/storebot_codex_worker.py",
    "subphone/start_codex_ops_worker.sh",
)

PROJECT_CONTRACTS: dict[str, str] = {
    "DeliveryHelper": (
        "DeliveryHelper 완료 기준: Android 코드/리소스 변경 시 "
        "`/root/my-first-project/scripts/deploy_deliveryhelper_update.sh`로 debug APK 빌드와 "
        "업데이트센터 `deliveryhelper/version.json`, `DeliveryHelper_latest.bin` 배포까지 수행합니다. "
        "주소/비번 확정값은 기존 재검토/보정 경계를 통과해야 하며 실시간 주문 화면을 동기 대기시키지 않습니다."
    ),
    "PosDelay": (
        "PosDelay 완료 기준: Android 코드/리소스 변경 시 "
        "`/root/my-first-project/scripts/deploy_posdelay_update.sh`로 debug APK 빌드와 "
        "업데이트센터 `posdelay/version.json`, `PosDelay_latest.bin` 배포까지 수행합니다. "
        "배민/쿠팡 실제 실행은 기존 엔진 큐, 충돌 그룹, 휴먼 딜레이 경계를 통과해야 합니다."
    ),
    "BankTotal": (
        "BankTotal 완료 기준: Android 코드/리소스 변경 시 "
        "`/root/my-first-project/scripts/deploy_banktotal_update.sh`로 debug APK 빌드와 "
        "업데이트센터 `banktotal/version.json`, `BankTotal_latest.bin` 배포까지 수행합니다. "
        "금액, 회차, 반복 원본, SFA/물류 확정 변경은 기존 Repository/LocalApiServer/전용 rule 경계를 통과해야 합니다."
    ),
    "OrderHelper": (
        "OrderHelper 완료 기준: 웹 코드 변경 시 정적 검사와 GitHub Pages 반영 확인을 수행합니다. "
        "SFA 파일 스캔 실행자는 PC/SiteBot이고 서버폰 Termux는 `/monitor/main_pc/*`, "
        "`/order/desk_q7m9r3a8/current`, `sfaCompare/latest`, `sfaActualHistory`, `unitInference/latest` 감시와 self_fix를 맡습니다. "
        "재고스냅샷+실발주 입고량으로 실사용량/단위환산 리포트는 올릴 수 있지만, 실발주값, 발주 품목, 단위, 환산 원본은 자동 확정하지 않습니다."
    ),
    "StoreBot": (
        "StoreBot 완료 기준: worker/스킬/MD 변경 시 StoreBot Codex bundle을 생성하고 서버폰 worker 반영 및 heartbeat를 확인합니다. "
        "카톡 자연어 첫 판단은 Codex AI가 하며 worker/App 하드코딩 선분류를 추가하지 않습니다."
    ),
}


class OpsError(RuntimeError):
    pass


class CodexPreflightError(OpsError):
    def __init__(self, preflight: dict[str, Any]):
        self.preflight = preflight
        super().__init__(codex_preflight_error_message(preflight))


_CODEX_PREFLIGHT_CACHE: dict[str, Any] = {"key": "", "checked_at_ms": 0, "result": {}}
_LAST_LIVE_STATUS_BY_REQ: dict[str, dict[str, Any]] = {}


def log(message: str) -> None:
    print(message, flush=True)


def current_git_revision(repo: str = DEFAULT_CWD) -> str:
    try:
        return subprocess.check_output(
            ["git", "-C", repo, "rev-parse", "--short=12", "HEAD"],
            text=True,
            stderr=subprocess.DEVNULL,
            timeout=5,
        ).strip()
    except Exception:
        return str(os.environ.get("CODEX_CODE_REVISION") or "").strip() or "unknown"


def read_json_dict(path: Path) -> dict[str, Any]:
    try:
        data = json.loads(path.read_text(encoding="utf-8"))
    except Exception:
        return {}
    return data if isinstance(data, dict) else {}


def sha256_file(path: Path) -> str:
    try:
        return hashlib.sha256(path.read_bytes()).hexdigest()
    except OSError:
        return ""


def first_text(*values: Any) -> str:
    for value in values:
        text = str(value or "").strip()
        if text:
            return text
    return ""


def bundle_runtime_info(repo: str | Path = DEFAULT_CWD) -> dict[str, Any]:
    path = Path(str(repo or DEFAULT_CWD)).expanduser()
    git_dir_present = (path / ".git").exists()
    metadata_sources: list[str] = []
    version = ""
    bundle_sha256 = ""
    source_revision = ""
    manifest_url = ""
    status = ""
    applied_at_ms = 0
    manifest_sha256 = ""
    state_sha256 = ""

    for name in BUNDLE_METADATA_FILE_NAMES:
        metadata_path = path / name
        data = read_json_dict(metadata_path)
        if not data:
            continue
        metadata_sources.append(name)
        version = first_text(version, data.get("bundle_version"), data.get("version"))
        bundle_sha256 = first_text(bundle_sha256, data.get("bundle_sha256"), data.get("sha256"))
        source_revision = first_text(source_revision, data.get("source_revision"), data.get("code_revision"))
        manifest_url = first_text(manifest_url, data.get("manifest_url"), data.get("bundle_url"), data.get("url"))
        status = first_text(status, data.get("status"))
        try:
            applied_at_ms = applied_at_ms or int(data.get("applied_at_ms") or 0)
        except Exception:
            applied_at_ms = applied_at_ms or 0
        if name == BUNDLE_STATE_FILE_NAME:
            state_sha256 = sha256_file(metadata_path)
        else:
            manifest_sha256 = first_text(manifest_sha256, sha256_file(metadata_path))

    required_present = [name for name in REQUIRED_BUNDLE_HELPERS if (path / name).is_file()]
    required_missing = [name for name in REQUIRED_BUNDLE_HELPERS if name not in required_present]
    metadata_has_identity = bool(version and source_revision and (bundle_sha256 or manifest_sha256))
    bundle_copy_ok = bool((not git_dir_present) and metadata_has_identity and not required_missing)
    if git_dir_present:
        runtime_mode = "git_repo"
    elif metadata_sources or required_present:
        runtime_mode = "bundle_copy"
    else:
        runtime_mode = "filesystem_copy"

    return {
        "runtime_mode": runtime_mode,
        "git_dir_present": git_dir_present,
        "bundle_copy_ok": bundle_copy_ok,
        "bundle_metadata_present": bool(metadata_sources),
        "bundle_metadata_sources": metadata_sources,
        "bundle_version": version,
        "bundle_sha256": bundle_sha256,
        "bundle_manifest_sha256": manifest_sha256,
        "bundle_state_sha256": state_sha256,
        "bundle_status": status,
        "bundle_applied_at_ms": applied_at_ms,
        "bundle_manifest_url": manifest_url,
        "source_revision": source_revision,
        "required_helpers_present": required_present,
        "required_helpers_missing": required_missing,
    }


def file_mtime_ms(path: str) -> int:
    try:
        return int(Path(path).stat().st_mtime * 1000)
    except OSError:
        return 0


def decode_stream(value: Any) -> str:
    if value is None:
        return ""
    if isinstance(value, bytes):
        return value.decode("utf-8", errors="replace")
    return str(value)


def subprocess_group_kwargs() -> dict[str, Any]:
    if os.name == "nt":
        creationflags = getattr(subprocess, "CREATE_NEW_PROCESS_GROUP", 0)
        return {"creationflags": creationflags} if creationflags else {}
    return {"start_new_session": True}


def terminate_process_tree(proc: subprocess.Popen[Any] | None, grace_sec: float = 5.0) -> None:
    if proc is None or proc.poll() is not None:
        return
    if os.name == "nt":
        try:
            subprocess.run(
                ["taskkill", "/PID", str(proc.pid), "/T", "/F"],
                stdout=subprocess.DEVNULL,
                stderr=subprocess.DEVNULL,
                timeout=max(1, int(grace_sec) + 5),
                check=False,
            )
        except Exception:
            try:
                proc.kill()
            except Exception:
                pass
        try:
            proc.wait(timeout=max(1, grace_sec))
        except subprocess.TimeoutExpired:
            pass
        return
    try:
        os.killpg(proc.pid, signal.SIGTERM)
    except ProcessLookupError:
        return
    except Exception:
        try:
            proc.terminate()
        except Exception:
            pass
    try:
        proc.wait(timeout=max(1, grace_sec))
        return
    except subprocess.TimeoutExpired:
        pass
    try:
        os.killpg(proc.pid, signal.SIGKILL)
    except ProcessLookupError:
        return
    except Exception:
        try:
            proc.kill()
        except Exception:
            pass
    try:
        proc.wait(timeout=max(1, grace_sec))
    except subprocess.TimeoutExpired:
        pass


def normalize_target_host(value: Any, default: str = "") -> str:
    text = str(value or default).strip().lower()
    return text if text in ALLOWED_TARGET_HOSTS else default


def is_foreign_posix_cwd(value: Any) -> bool:
    text = str(value or "").strip().replace("\\", "/").rstrip("/")
    if not text.startswith("/"):
        return False
    return any(text == prefix or text.startswith(f"{prefix}/") for prefix in FOREIGN_POSIX_CWD_PREFIXES)


def should_ignore_requested_cwd(requested: Any, args: argparse.Namespace) -> bool:
    worker_host = normalize_target_host(getattr(args, "host", "subphone"), "subphone")
    return (worker_host == "pc" or os.name == "nt") and is_foreign_posix_cwd(requested)


def request_matches_worker(item: dict[str, Any], args: argparse.Namespace) -> bool:
    worker_host = normalize_target_host(getattr(args, "host", "subphone"), "subphone")
    target_host = normalize_target_host(item.get("target_host"), "")
    if worker_host == "pc":
        if target_host not in {"pc", "any"}:
            return False
    else:
        if target_host not in {"", "subphone", "any"}:
            return False
    target_node = str(item.get("target_node") or "").strip()
    if target_node and target_node != args.node:
        return False
    return True


def request_cwd_value(item: dict[str, Any]) -> str:
    return str(item.get("cwd") or item.get("project_dir") or item.get("projectDir") or "").strip()


def is_resume_prompt_request(item: dict[str, Any]) -> bool:
    action = str(item.get("action") or item.get("mode") or "").strip()
    return action == RESUME_PROMPT_ACTION


def is_adb_direct_request(item: dict[str, Any]) -> bool:
    action = str(item.get("action") or item.get("mode") or "").strip()
    return action == ADB_CHECK_ACTION or bool_field(item.get("adb_only"))


def bool_field(value: Any) -> bool:
    if isinstance(value, bool):
        return value
    if isinstance(value, (int, float)):
        return value != 0
    return str(value or "").strip().lower() in {"1", "true", "yes", "y", "on"}


def validate_session_id(value: Any) -> str:
    session_id = str(value or "").strip()
    if not SESSION_ID_RE.fullmatch(session_id):
        raise OpsError("session_id must be a UUID-like string")
    return session_id


def load_pending(limit: int, args: argparse.Namespace) -> list[tuple[str, dict[str, Any]]]:
    raw = fb_get(REQUESTS_PATH) or {}
    if not isinstance(raw, dict):
        return []
    items: list[tuple[str, dict[str, Any]]] = []
    for key, item in raw.items():
        if not isinstance(item, dict):
            continue
        if str(item.get("status") or "pending") not in CLAIMABLE_STATUSES:
            continue
        if not request_matches_worker(item, args):
            continue
        items.append((str(key), item))
    items.sort(key=lambda pair: int(pair[1].get("created_at_ms") or 0))
    return items[:limit]


def firebase_get_with_etag(path: str, timeout: int = 20) -> tuple[Any, str]:
    req = urllib.request.Request(
        fb_url(path),
        headers={
            "Accept": "application/json",
            "X-Firebase-ETag": "true",
        },
        method="GET",
    )
    try:
        with urllib.request.urlopen(req, timeout=timeout) as resp:
            body = resp.read().decode("utf-8")
            etag = str(resp.headers.get("ETag") or "")
    except urllib.error.HTTPError as exc:
        body = exc.read().decode("utf-8", errors="replace")
        raise OpsError(f"firebase GET {path} etag failed: HTTP {exc.code} {body[:300]}") from exc
    except urllib.error.URLError as exc:
        raise OpsError(f"firebase GET {path} etag failed: {exc}") from exc
    return (json.loads(body) if body else None), etag


def firebase_conditional_put(path: str, payload: Any, etag: str, timeout: int = 20) -> bool:
    data = json.dumps(payload, ensure_ascii=False, separators=(",", ":")).encode("utf-8")
    headers = {
        "Content-Type": "application/json; charset=utf-8",
        "If-Match": etag,
    }
    req = urllib.request.Request(fb_url(path), data=data, headers=headers, method="PUT")
    try:
        with urllib.request.urlopen(req, timeout=timeout) as resp:
            resp.read()
            return True
    except urllib.error.HTTPError as exc:
        if exc.code == 412:
            return False
        body = exc.read().decode("utf-8", errors="replace")
        raise OpsError(f"firebase conditional PUT {path} failed: HTTP {exc.code} {body[:300]}") from exc
    except urllib.error.URLError as exc:
        raise OpsError(f"firebase conditional PUT {path} failed: {exc}") from exc


def firebase_delete(path: str, timeout: int = 20) -> None:
    req = urllib.request.Request(fb_url(path), method="DELETE")
    try:
        with urllib.request.urlopen(req, timeout=timeout) as resp:
            resp.read()
    except urllib.error.HTTPError as exc:
        body = exc.read().decode("utf-8", errors="replace")
        raise OpsError(f"firebase DELETE {path} failed: HTTP {exc.code} {body[:300]}") from exc
    except urllib.error.URLError as exc:
        raise OpsError(f"firebase DELETE {path} failed: {exc}") from exc


def request_scope(item: dict[str, Any]) -> str:
    project = str(item.get("project") or "").strip()
    if project:
        return f"project_{sanitize_key(project)}"
    cwd_name = Path(request_cwd_value(item) or DEFAULT_CWD).expanduser().name
    return f"cwd_{sanitize_key(cwd_name)}"


def lock_scopes(item: dict[str, Any], args: argparse.Namespace) -> list[str]:
    scopes = []
    if getattr(args, "global_lock", False):
        scopes.append("global")
    if is_resume_prompt_request(item):
        session_id = str(item.get("session_id") or "").strip()
        if SESSION_ID_RE.fullmatch(session_id):
            scopes.append(f"codex_session_{sanitize_key(session_id)}")
    scopes.append(request_scope(item))
    deduped: list[str] = []
    for scope in scopes:
        if scope and scope not in deduped:
            deduped.append(scope)
    return deduped


def lock_ttl_ms(item: dict[str, Any], args: argparse.Namespace) -> int:
    timeout_sec = int(item.get("timeout_sec") or args.timeout_sec)
    ttl_sec = max(int(args.lock_ttl_sec), timeout_sec + 300)
    return ttl_sec * 1000


def acquire_lock(scope: str, req_id: str, item: dict[str, Any], args: argparse.Namespace) -> dict[str, str] | None:
    path = f"{LOCKS_PATH}/{sanitize_key(scope)}"
    owner = f"{args.node}:{os.getpid()}:{args.worker_started_at_ms}:{req_id}:{secrets.token_hex(3)}"
    now = now_ms()
    payload = {
        "scope": scope,
        "owner": owner,
        "worker": args.node,
        "pid": os.getpid(),
        "request_id": req_id,
        "project": item.get("project") or "",
        "cwd": item.get("cwd") or "",
        "acquired_at_ms": now,
        "expires_at_ms": now + lock_ttl_ms(item, args),
    }
    for _ in range(3):
        current, etag = firebase_get_with_etag(path)
        if isinstance(current, dict):
            expires_at = int(current.get("expires_at_ms") or 0)
            if expires_at > now_ms():
                return None
        if firebase_conditional_put(path, payload, etag):
            return {"path": path, "owner": owner, "scope": scope}
        time.sleep(0.2)
    return None


def acquire_request_locks(req_id: str, item: dict[str, Any], args: argparse.Namespace) -> list[dict[str, str]] | None:
    acquired: list[dict[str, str]] = []
    for scope in lock_scopes(item, args):
        lock = acquire_lock(scope, req_id, item, args)
        if not lock:
            release_locks(acquired)
            return None
        acquired.append(lock)
    return acquired


def release_locks(locks: list[dict[str, str]]) -> None:
    for lock in reversed(locks):
        try:
            current = fb_get(lock["path"]) or {}
            if isinstance(current, dict) and current.get("owner") == lock["owner"]:
                firebase_delete(lock["path"])
        except Exception as exc:
            log(f"lock release warning {lock.get('scope')}: {compact_error(str(exc), 300)}")


def release_request_locks(req_id: str, item: dict[str, Any], args: argparse.Namespace) -> None:
    for scope in lock_scopes(item, args) + ["global", request_scope(item)]:
        path = f"{LOCKS_PATH}/{sanitize_key(scope)}"
        try:
            current = fb_get(path) or {}
            if (
                isinstance(current, dict)
                and current.get("request_id") == req_id
                and current.get("worker") == args.node
            ):
                firebase_delete(path)
        except Exception as exc:
            log(f"lock cleanup warning {scope}: {compact_error(str(exc), 300)}")


def claim_request(req_id: str, args: argparse.Namespace, started: int) -> dict[str, Any] | None:
    path = f"{REQUESTS_PATH}/{req_id}"
    for _ in range(3):
        current, etag = firebase_get_with_etag(path)
        if not isinstance(current, dict):
            return None
        if str(current.get("status") or "pending") not in CLAIMABLE_STATUSES:
            return None
        if not request_matches_worker(current, args):
            return None
        claimed = dict(current)
        claimed.update(
            {
                "status": "running",
                "worker": args.node,
                "started_at_ms": started,
                "claim_pid": os.getpid(),
                "claim_worker_started_at_ms": int(getattr(args, "worker_started_at_ms", 0) or 0),
            }
        )
        if firebase_conditional_put(path, claimed, etag):
            return claimed
        time.sleep(0.2)
    return None


def is_codex_exec_for_cwd(cmdline: list[str], cwd: str) -> bool:
    if not cwd or "exec" not in cmdline:
        return False
    if not any("codex" in Path(part).name for part in cmdline):
        return False
    for index, part in enumerate(cmdline[:-1]):
        if part == "-C" and cmdline[index + 1] == cwd:
            return True
    return False


def powershell_executable() -> str:
    return shutil.which("powershell.exe") or shutil.which("powershell") or shutil.which("pwsh") or ""


def find_codex_exec_pids_windows(cwd: str) -> list[int]:
    if not cwd:
        return []
    powershell = powershell_executable()
    if not powershell:
        return []
    script = r"""
$cwd = $args[0]
$items = Get-CimInstance Win32_Process -ErrorAction SilentlyContinue
if (-not $items) { $items = Get-WmiObject Win32_Process -ErrorAction SilentlyContinue }
$items | Where-Object {
  $cmd = [string]$_.CommandLine
  $cmd -and
    ($cmd -match '(^|[\\/\s"`])codex(\.exe)?(["`\s]|$)') -and
    ($cmd -match '(^|\s)exec(\s|$)') -and
    $cmd.Contains($cwd)
} | ForEach-Object { $_.ProcessId }
""".strip()
    try:
        completed = subprocess.run(
            [powershell, "-NoProfile", "-NonInteractive", "-Command", script, cwd],
            text=True,
            capture_output=True,
            timeout=5,
            check=False,
        )
    except Exception as exc:
        log(f"warning: cannot list Windows codex exec pids: {compact_error(str(exc), 300)}")
        return []
    if completed.returncode != 0:
        stderr = compact_error(completed.stderr or completed.stdout or "powershell process query failed", 300)
        log(f"warning: Windows codex exec pid query failed: {stderr}")
        return []
    pids: list[int] = []
    for line in completed.stdout.splitlines():
        try:
            value = int(line.strip())
        except (TypeError, ValueError):
            continue
        if value > 0 and value != os.getpid():
            pids.append(value)
    return sorted(set(pids))


def find_codex_exec_pids(cwd: str) -> list[int]:
    if os.name == "nt":
        return find_codex_exec_pids_windows(cwd)
    pids: list[int] = []
    current_pid = os.getpid()
    proc_dir = Path("/proc")
    for entry in proc_dir.iterdir() if proc_dir.exists() else []:
        if not entry.name.isdigit():
            continue
        pid = int(entry.name)
        if pid == current_pid:
            continue
        try:
            raw = (entry / "cmdline").read_bytes()
        except OSError:
            continue
        if not raw:
            continue
        cmdline = [part.decode("utf-8", errors="replace") for part in raw.split(b"\0") if part]
        if is_codex_exec_for_cwd(cmdline, cwd):
            pids.append(pid)
    return sorted(set(pids))


def pid_is_alive(pid: Any) -> bool:
    try:
        value = int(pid)
    except (TypeError, ValueError):
        return False
    if value <= 0:
        return False
    try:
        os.kill(value, 0)
        return True
    except ProcessLookupError:
        return False
    except PermissionError:
        return True
    except OSError:
        return False


def request_process_env(req_id: str, args: argparse.Namespace) -> dict[str, str]:
    env = os.environ.copy()
    env["CODEX_OPS_REQUEST_ID"] = str(req_id)
    env["CODEX_OPS_WORKER_STARTED_AT_MS"] = str(int(getattr(args, "worker_started_at_ms", 0) or 0))
    return env


def posix_pid_matches_request(pid: int, req_id: str) -> bool:
    if pid <= 1 or pid == os.getpid():
        return False
    try:
        values = (Path(f"/proc/{pid}") / "environ").read_bytes().split(b"\0")
    except OSError:
        return False
    expected = f"CODEX_OPS_REQUEST_ID={req_id}".encode("utf-8")
    return expected in values


def find_request_process_pids(req_id: str, item: dict[str, Any]) -> list[int]:
    """Return only descendants carrying this request's explicit process marker."""
    if os.name == "nt":
        # Windows does not expose another process environment through the
        # portable APIs used here. Fail closed instead of killing by cwd/PID.
        return []
    candidates: set[int] = set()
    recorded = item.get("codex_process_pid")
    if not recorded and isinstance(item.get("live_status"), dict):
        recorded = item["live_status"].get("process_pid")
    try:
        recorded_pid = int(recorded or 0)
    except (TypeError, ValueError):
        recorded_pid = 0
    if recorded_pid > 1:
        candidates.add(recorded_pid)
    proc_dir = Path("/proc")
    for entry in proc_dir.iterdir() if proc_dir.exists() else []:
        if entry.name.isdigit():
            candidates.add(int(entry.name))
    return sorted(pid for pid in candidates if posix_pid_matches_request(pid, req_id))


def request_lock_state(req_id: str, item: dict[str, Any]) -> dict[str, Any]:
    path = f"{LOCKS_PATH}/{sanitize_key(request_scope(item))}"
    try:
        current = fb_get(path) or {}
    except Exception:
        return {}
    if not isinstance(current, dict):
        return {}
    if current.get("request_id") != req_id:
        return {}
    return current


def lock_owner_started_at(lock: dict[str, Any]) -> int:
    owner = str(lock.get("owner") or "")
    parts = owner.split(":")
    if len(parts) < 4:
        return 0
    try:
        return int(parts[2])
    except (TypeError, ValueError):
        return 0


def terminate_windows_pid_tree(pid: int) -> None:
    try:
        subprocess.run(
            ["taskkill", "/PID", str(pid), "/T", "/F"],
            stdout=subprocess.DEVNULL,
            stderr=subprocess.DEVNULL,
            timeout=10,
            check=False,
        )
    except Exception as exc:
        log(f"warning: cannot taskkill orphan codex pid={pid}: {compact_error(str(exc), 300)}")


def terminate_posix_pid_tree(pid: int, sig: signal.Signals) -> None:
    try:
        pgid = os.getpgid(pid)
    except ProcessLookupError:
        return
    except Exception:
        pgid = 0
    try:
        if pgid > 0 and pgid != os.getpgrp():
            os.killpg(pgid, sig)
        else:
            os.kill(pid, sig)
    except ProcessLookupError:
        pass
    except PermissionError:
        log(f"warning: cannot terminate orphan codex pid={pid}")


def terminate_request_processes(req_id: str, item: dict[str, Any], pids: list[int] | None = None) -> list[int]:
    pids = list(pids if pids is not None else find_request_process_pids(req_id, item))
    if not pids:
        return []
    if os.name == "nt":
        return []
    pids = [pid for pid in pids if posix_pid_matches_request(pid, req_id)]
    if not pids:
        return []
    for pid in pids:
        terminate_posix_pid_tree(pid, signal.SIGTERM)
    time.sleep(2)
    remaining = [pid for pid in pids if Path(f"/proc/{pid}").exists()]
    for pid in remaining:
        terminate_posix_pid_tree(pid, signal.SIGKILL)
    return pids


def orphan_fence_matches(expected: dict[str, Any], current: Any) -> bool:
    if not isinstance(current, dict):
        return False
    fields = ("status", "worker", "claim_pid", "claim_worker_started_at_ms", "started_at_ms")
    return all(current.get(field) == expected.get(field) for field in fields)


def conditional_orphan_patch(req_id: str, expected: dict[str, Any], patch: dict[str, Any]) -> bool:
    path = f"{REQUESTS_PATH}/{req_id}"
    current, etag = firebase_get_with_etag(path)
    if not orphan_fence_matches(expected, current):
        return False
    updated = dict(current)
    updated.update(patch)
    return bool(firebase_conditional_put(path, updated, etag))


def monitor_issue_key(project: str, issues: list[dict[str, Any]]) -> str:
    codes = [
        f"{item.get('source')}:{item.get('code')}"
        for item in issues
        if SEVERITY_SCORE.get(str(item.get("severity")), 0) >= 2
    ]
    if not codes:
        codes = [f"{item.get('source')}:{item.get('code')}" for item in issues]
    import hashlib

    digest = hashlib.sha1("|".join(sorted(codes)).encode("utf-8")).hexdigest()[:12]
    return f"{sanitize_key(project)}_{digest}"


def stale_self_fix_reason(item: dict[str, Any]) -> str:
    if str(item.get("source") or "") != "ai_ops_common_monitor":
        return ""
    project = str(item.get("project") or "").strip()
    expected_key = str(item.get("monitor_issue_key") or "").strip()
    if not project or not expected_key:
        return ""
    project_key = sanitize_key(project)
    try:
        current = fb_get(f"{AI_OPS_BASE_PATH}/projects/{project_key}/latest") or {}
        if not isinstance(current, dict) or "issues" not in current:
            current = fb_get(f"{AI_OPS_BASE_PATH}/latest/projects/{project_key}") or {}
    except Exception as exc:
        log(f"monitor issue check warning {project}: {compact_error(str(exc), 300)}")
        return ""
    if not isinstance(current, dict):
        return ""
    issues = current.get("issues") or []
    if not isinstance(issues, list):
        return ""
    current_key = monitor_issue_key(project, [item for item in issues if isinstance(item, dict)])
    if current_key != expected_key:
        return f"monitor issue changed: {expected_key} -> {current_key}"
    current_severity = str(current.get("severity") or "ok")
    if item.get("detected_error_issue_codes") and SEVERITY_SCORE.get(current_severity, 0) < 2:
        return f"monitor severity downgraded to {current_severity}"
    return ""


def cleanup_orphaned_running(args: argparse.Namespace) -> int:
    threshold_min = int(args.orphan_running_min or 0)
    requeue_limit = int(getattr(args, "orphan_requeue_limit", 0) or 0)
    worker_started_at_ms = int(getattr(args, "worker_started_at_ms", 0) or 0)
    child_grace_ms = max(
        1,
        int(getattr(args, "orphan_child_grace_sec", DEFAULT_ORPHAN_CHILD_GRACE_SEC) or DEFAULT_ORPHAN_CHILD_GRACE_SEC),
    ) * 1000
    if threshold_min <= 0 and requeue_limit <= 0:
        return 0
    raw = fb_get(REQUESTS_PATH) or {}
    if not isinstance(raw, dict):
        return 0
    count = 0
    now = now_ms()
    threshold_ms = threshold_min * 60000
    for req_id, item in raw.items():
        if not isinstance(item, dict):
            continue
        status = str(item.get("status") or "").strip()
        if status not in RUNNING_STATUSES:
            continue
        if not request_matches_worker(item, args):
            continue
        started = int(item.get("started_at_ms") or item.get("created_at_ms") or 0)
        lock = request_lock_state(str(req_id), item)
        lock_started_at = lock_owner_started_at(lock)
        claim_worker_started_at = int(item.get("claim_worker_started_at_ms") or 0)
        explicit_previous_worker_run = (
            worker_started_at_ms > 0
            and str(item.get("worker") or "") == args.node
            and claim_worker_started_at > 0
            and claim_worker_started_at != worker_started_at_ms
        )
        legacy_previous_worker_run = claim_worker_started_at <= 0 and (
            worker_started_at_ms > 0
            and str(item.get("worker") or "") == args.node
            and started > 0
            and started < worker_started_at_ms - 10000
        ) or (
            worker_started_at_ms > 0
            and str(lock.get("worker") or "") == args.node
            and lock_started_at > 0
            and lock_started_at < worker_started_at_ms - 10000
        )
        previous_worker_run = explicit_previous_worker_run or legacy_previous_worker_run
        claim_pid = int(item.get("claim_pid") or 0)
        lock_pid = int(lock.get("pid") or 0)
        lock_expired = int(lock.get("expires_at_ms") or 0) > 0 and int(lock.get("expires_at_ms") or 0) <= now
        lock_pid_alive = lock_pid > 0 and pid_is_alive(lock_pid)
        dead_claim_pid = claim_pid > 0 and not pid_is_alive(claim_pid)
        dead_lock_pid = lock_pid > 0 and not lock_pid_alive
        request_process_pids = find_request_process_pids(str(req_id), item)
        same_cwd_codex_pids = find_codex_exec_pids(request_cwd_value(item))
        unscoped_codex_pids = [pid for pid in same_cwd_codex_pids if pid not in request_process_pids]
        dead_process_orphan = dead_claim_pid or dead_lock_pid
        previous_worker_orphan = previous_worker_run and (not lock_pid_alive or lock_expired or explicit_previous_worker_run)
        timed_out_running = started > 0 and threshold_ms > 0 and now - started > threshold_ms
        request_timeout_sec = max(1, int(item.get("timeout_sec") or getattr(args, "timeout_sec", 1) or 1))
        request_timed_out = started > 0 and now - started >= request_timeout_sec * 1000
        if not previous_worker_orphan and not dead_process_orphan and not timed_out_running:
            continue
        if dead_process_orphan:
            reason = "worker_claim_pid_dead"
        elif previous_worker_orphan:
            reason = "worker_restarted_before_result"
        else:
            reason = f"running_older_than_{threshold_min}min"
        orphan_detected_at = int(item.get("orphan_detected_at_ms") or 0)
        child_grace_expired = orphan_detected_at > 0 and now - orphan_detected_at >= child_grace_ms
        if (request_process_pids or unscoped_codex_pids) and (previous_worker_orphan or dead_process_orphan):
            if not request_timed_out and not timed_out_running and not child_grace_expired:
                if orphan_detected_at <= 0 and not args.dry_run:
                    conditional_orphan_patch(
                        str(req_id),
                        item,
                        {
                            "orphan_detected_at_ms": now,
                            "orphan_reason": reason,
                            "orphan_request_process_pids": request_process_pids,
                            "orphan_unscoped_codex_pids": unscoped_codex_pids,
                        },
                    )
                log(
                    f"orphan grace {req_id} request_pids={request_process_pids} "
                    f"unscoped_pids={unscoped_codex_pids}"
                )
                continue
        requeued = int(item.get("orphan_requeue_count") or 0)
        if (
            (previous_worker_orphan or dead_process_orphan)
            and not request_process_pids
            and not unscoped_codex_pids
            and requeued < requeue_limit
        ):
            payload = {
                "status": "pending",
                "worker": None,
                "started_at_ms": None,
                "claim_pid": None,
                "claim_worker_started_at_ms": None,
                "orphan_requeue_count": requeued + 1,
                "orphan_requeued_at_ms": now,
                "orphan_previous_worker": args.node,
                "orphan_previous_started_at_ms": started,
                "orphan_reason": reason,
                "error": "",
            }
            payload.update(REQUEST_PROGRESS_CLEAR_FIELDS)
            if not args.dry_run and conditional_orphan_patch(str(req_id), item, payload):
                release_request_locks(str(req_id), item, args)
            elif not args.dry_run:
                log(f"orphan requeue fence lost {req_id}")
                continue
            log(f"requeued orphaned {req_id}" + (" dry_run" if args.dry_run else ""))
            count += 1
            continue
        terminal_status = "failed_timeout" if request_timed_out or timed_out_running else "stale_killed"
        error = (
            "orphaned running task with dead worker claim pid"
            if dead_process_orphan
            else "orphaned running task from previous worker start"
            if previous_worker_orphan
            else f"orphaned running task older than {threshold_min}min; previous worker is no longer active"
        )
        payload = {
            "status": terminal_status,
            "worker": args.node,
            "finished_at_ms": now,
            "duration_ms": now - started,
            "returncode": 1,
            "project": item.get("project") or "",
            "cwd": request_cwd_value(item),
            "profile": item.get("profile") or "",
            "model": item.get("model") or args.model,
            "reasoning_effort": item.get("reasoning_effort") or args.reasoning_effort,
            "error": error,
        }
        payload["result"] = terminal_result_payload(
            str(req_id),
            item,
            args,
            started,
            now,
            terminal_status,
            error,
            {
                "summary": error,
                "orphan_reason": reason,
                "request_process_pids": request_process_pids,
                "unscoped_codex_pids_preserved": unscoped_codex_pids,
            },
            1,
        )
        payload.update(REQUEST_PROGRESS_CLEAR_FIELDS)
        if not args.dry_run:
            if not conditional_orphan_patch(str(req_id), item, payload):
                log(f"orphan terminal fence lost {req_id}")
                continue
            killed_pids = terminate_request_processes(str(req_id), item, request_process_pids)
            if killed_pids:
                payload["orphan_killed_pids"] = killed_pids
                payload["result"]["orphan_killed_pids"] = killed_pids
                fb_patch(f"{REQUESTS_PATH}/{req_id}", {"orphan_killed_pids": killed_pids, "result": payload["result"]})
            release_request_locks(str(req_id), item, args)
            fb_put(f"{RESULTS_PATH}/{req_id}", payload)
        log(f"{terminal_status} {req_id}" + (" dry_run" if args.dry_run else ""))
        count += 1
    return count


def normalize_reasoning(value: Any, default: str) -> str:
    text = str(value or default).strip().lower()
    return text if text in ALLOWED_REASONING else default


def normalize_profile(value: Any) -> str:
    text = str(value or "patch").strip().lower()
    return text if text in ALLOWED_PROFILES else "patch"


def output_summary(text: str, limit: int = 1800) -> str:
    return re.sub(r"\s+", " ", text).strip()[:limit]


def file_tail(path: str, limit: int = 1200) -> str:
    try:
        file_path = Path(path)
        if not file_path.exists():
            return ""
        size = file_path.stat().st_size
        with file_path.open("rb") as handle:
            if size > limit * 2:
                handle.seek(max(0, size - limit * 2))
            raw = handle.read()
        text = raw.decode("utf-8", errors="replace")
        if size > limit * 2:
            lines = text.splitlines()
            text = "\n".join(lines[1:]) if len(lines) > 1 else text
        return text.strip()[-limit:]
    except Exception:
        return ""


def command_summary(cmd: list[str]) -> str:
    safe_parts: list[str] = []
    skip_next = False
    for part in cmd:
        if skip_next:
            safe_parts.append(part)
            skip_next = False
            continue
        safe_parts.append(part)
        if part in {"-C", "-m", "-c", "-o"}:
            skip_next = True
    return " ".join(safe_parts)[:500]


def run_short_command(cmd: list[str], cwd: Path | None = None, timeout: int = 5) -> dict[str, Any]:
    started = now_ms()
    try:
        completed = subprocess.run(
            cmd,
            cwd=str(cwd) if cwd else None,
            text=True,
            capture_output=True,
            timeout=max(1, timeout),
            check=False,
            env=os.environ.copy(),
        )
        return {
            "command": command_summary(cmd),
            "returncode": completed.returncode,
            "stdout": capped_text(completed.stdout or ""),
            "stderr": capped_text(completed.stderr or ""),
            "stdout_len": len(completed.stdout or ""),
            "stderr_len": len(completed.stderr or ""),
            "duration_ms": now_ms() - started,
        }
    except subprocess.TimeoutExpired as exc:
        stdout = decode_stream(exc.stdout)
        stderr = decode_stream(exc.stderr) or "timeout"
        return {
            "command": command_summary(cmd),
            "returncode": 124,
            "stdout": capped_text(stdout),
            "stderr": capped_text(stderr),
            "stdout_len": len(stdout),
            "stderr_len": len(stderr),
            "duration_ms": now_ms() - started,
            "timeout": True,
        }
    except Exception as exc:
        return {
            "command": command_summary(cmd),
            "returncode": 1,
            "stdout": "",
            "stderr": compact_error(str(exc), 500),
            "stdout_len": 0,
            "stderr_len": len(str(exc)),
            "duration_ms": now_ms() - started,
            "exception": True,
        }


def first_line(value: str, limit: int = 300) -> str:
    lines = value.strip().splitlines()
    return (lines[0] if lines else "")[:limit]


def hook_policy_preflight(cwd: Path | None = None, timeout_sec: int = DEFAULT_CODEX_PREFLIGHT_TIMEOUT_SEC) -> dict[str, Any]:
    scripts_dir = Path(__file__).resolve().parent
    probe_path = scripts_dir / HOOK_POLICY_PROBE_NAME
    source_hook = scripts_dir / "codex_hooks" / HOOK_POLICY_SOURCE_NAME
    project_root = cwd if cwd and cwd.exists() and cwd.is_dir() else scripts_dir.parent
    if not probe_path.is_file() or not source_hook.is_file():
        return {
            "status": "FAIL",
            "compatible": False,
            "error": "hook_policy_probe_or_source_missing",
            "probe_path": str(probe_path),
            "source_hook": str(source_hook),
            "active_mutation_performed": False,
        }
    command = [
        sys.executable,
        str(probe_path),
        "--json",
        "--require-compatible",
        "--source-hook",
        str(source_hook),
        "--worker-source",
        str(Path(__file__).resolve()),
        "--project-root",
        str(project_root),
    ]
    command_result = run_short_command(command, cwd=project_root, timeout=max(1, timeout_sec))
    output = str(command_result.get("stdout") or "").strip()
    payload: dict[str, Any] = {}
    if output:
        try:
            parsed = json.loads(output.splitlines()[-1])
            if isinstance(parsed, dict):
                payload = parsed
        except json.JSONDecodeError:
            payload = {}
    compatible = command_result.get("returncode") == 0 and payload.get("compatible") is True
    if not payload:
        payload = {
            "status": "FAIL",
            "compatible": False,
            "error": "hook_policy_probe_invalid_output",
            "active_mutation_performed": False,
        }
    payload["compatible"] = compatible
    payload["probe_returncode"] = int(command_result.get("returncode") or 0)
    payload["probe_duration_ms"] = int(command_result.get("duration_ms") or 0)
    if not compatible and not payload.get("error"):
        payload["error"] = compact_error(
            str(command_result.get("stderr") or "hook policy is incompatible"), 500
        )
    return payload


def codex_cli_preflight(
    cwd: Path | None = None,
    timeout_sec: int = DEFAULT_CODEX_PREFLIGHT_TIMEOUT_SEC,
    cache_ttl_sec: int = 0,
) -> dict[str, Any]:
    ensure_runtime_path()
    checked_at = now_ms()
    timeout = max(1, min(30, int(timeout_sec or DEFAULT_CODEX_PREFLIGHT_TIMEOUT_SEC)))
    codex_path = shutil.which("codex") or ""
    command_cwd = cwd if cwd and cwd.exists() and cwd.is_dir() else None
    cache_key = f"{codex_path}|{command_cwd or ''}|{timeout}"
    cached = _CODEX_PREFLIGHT_CACHE.get("result")
    if (
        cache_ttl_sec > 0
        and isinstance(cached, dict)
        and _CODEX_PREFLIGHT_CACHE.get("key") == cache_key
        and checked_at - int(_CODEX_PREFLIGHT_CACHE.get("checked_at_ms") or 0) <= cache_ttl_sec * 1000
    ):
        return dict(cached)
    if not codex_path:
        result = {
            "codex_path": "",
            "codex_path_present": False,
            "codex_available": False,
            "codex_preflight_ok": False,
            "codex_preflight_error": "codex command not found in PATH",
            "codex_version": "",
            "codex_preflight_returncode": 127,
            "codex_preflight_duration_ms": 0,
            "codex_preflight_checked_at_ms": checked_at,
        }
    else:
        hook_policy = hook_policy_preflight(command_cwd, timeout_sec=timeout)
        if not hook_policy.get("compatible"):
            result = {
                "codex_path": codex_path,
                "codex_path_present": True,
                "codex_available": False,
                "codex_preflight_ok": False,
                "codex_preflight_error": compact_error(
                    str(hook_policy.get("error") or "hook policy is incompatible"), 500
                ),
                "codex_version": "",
                "codex_preflight_returncode": int(hook_policy.get("probe_returncode") or 3),
                "codex_preflight_duration_ms": int(hook_policy.get("probe_duration_ms") or 0),
                "codex_preflight_checked_at_ms": checked_at,
                "hook_policy": hook_policy,
            }
            _CODEX_PREFLIGHT_CACHE.update({"key": cache_key, "checked_at_ms": checked_at, "result": dict(result)})
            return result
        command_result = run_short_command([codex_path, "--version"], cwd=command_cwd, timeout=timeout)
        ok = command_result.get("returncode") == 0
        output = str(command_result.get("stdout") or "").strip() or str(command_result.get("stderr") or "").strip()
        error = "" if ok else compact_error(output or "codex --version failed", 500)
        result = {
            "codex_path": codex_path,
            "codex_path_present": True,
            "codex_available": ok,
            "codex_preflight_ok": ok,
            "codex_preflight_error": error,
            "codex_version": first_line(output, 200) if ok else "",
            "codex_preflight_returncode": int(command_result.get("returncode") or 0),
            "codex_preflight_duration_ms": int(command_result.get("duration_ms") or 0),
            "codex_preflight_checked_at_ms": checked_at,
            "codex_preflight_timeout": bool(command_result.get("timeout")),
            "command_result": command_result,
            "hook_policy": hook_policy,
        }
    _CODEX_PREFLIGHT_CACHE.update({"key": cache_key, "checked_at_ms": checked_at, "result": dict(result)})
    return result


def codex_preflight_error_message(preflight: dict[str, Any]) -> str:
    if preflight.get("codex_preflight_error"):
        return f"codex preflight failed: {preflight.get('codex_preflight_error')}"
    return "codex preflight failed"


def require_codex_cli_preflight(cwd: Path, args: argparse.Namespace) -> dict[str, Any]:
    preflight = codex_cli_preflight(
        cwd,
        timeout_sec=int(getattr(args, "codex_preflight_timeout_sec", DEFAULT_CODEX_PREFLIGHT_TIMEOUT_SEC) or DEFAULT_CODEX_PREFLIGHT_TIMEOUT_SEC),
        cache_ttl_sec=0,
    )
    if not preflight.get("codex_preflight_ok"):
        raise CodexPreflightError(preflight)
    return preflight


def git_snapshot(repo: str | Path = DEFAULT_CWD) -> dict[str, Any]:
    path = Path(str(repo or DEFAULT_CWD)).expanduser()
    bundle_info = bundle_runtime_info(path)
    snapshot: dict[str, Any] = {
        "code_revision": str(os.environ.get("CODEX_CODE_REVISION") or "").strip() or "unknown",
        "source_revision": "",
        "git_branch": "",
        "git_available": False,
        "git_root": "",
        "git_error": "",
        "dirty_count": -1,
        "dirty_files_sample": [],
        "git_status_error": "",
        **bundle_info,
    }
    try:
        root = run_short_command(["git", "-C", str(path), "rev-parse", "--show-toplevel"], timeout=5)
        if root.get("returncode") == 0 and str(root.get("stdout") or "").strip():
            snapshot["git_available"] = True
            snapshot["git_root"] = str(root.get("stdout") or "").strip()
        elif root.get("stderr"):
            snapshot["git_error"] = compact_error(str(root.get("stderr") or ""), 500)
        rev = run_short_command(["git", "-C", str(path), "rev-parse", "--short=12", "HEAD"], timeout=5)
        if rev.get("returncode") == 0 and str(rev.get("stdout") or "").strip():
            snapshot["code_revision"] = str(rev.get("stdout") or "").strip()
            snapshot["source_revision"] = snapshot["code_revision"]
            snapshot["git_available"] = True
        elif rev.get("stderr") and not snapshot.get("git_error"):
            snapshot["git_error"] = compact_error(str(rev.get("stderr") or ""), 500)
        branch = run_short_command(["git", "-C", str(path), "rev-parse", "--abbrev-ref", "HEAD"], timeout=5)
        if branch.get("returncode") == 0:
            snapshot["git_branch"] = str(branch.get("stdout") or "").strip()
        status = run_short_command(["git", "-C", str(path), "status", "--short"], timeout=5)
        if status.get("returncode") == 0:
            lines = [line for line in str(status.get("stdout") or "").splitlines() if line.strip()]
            snapshot["dirty_count"] = len(lines)
            snapshot["dirty_files_sample"] = lines[:20]
        else:
            snapshot["git_status_error"] = compact_error(str(status.get("stderr") or ""), 500)
    except Exception as exc:
        snapshot["git_status_error"] = compact_error(str(exc), 500)
    if not snapshot.get("git_available") and bundle_info.get("source_revision"):
        snapshot["code_revision"] = str(bundle_info.get("source_revision") or "")
        snapshot["source_revision"] = str(bundle_info.get("source_revision") or "")
    if not snapshot.get("git_branch") and snapshot.get("code_revision") not in {"", "unknown"}:
        snapshot["git_branch"] = "detached" if snapshot.get("git_available") else "bundle_copy"
    return snapshot


def live_status_payload(
    req_id: str,
    item: dict[str, Any],
    cwd: Path,
    requested_cwd: str,
    cwd_source: str,
    profile: str,
    model: str,
    effort: str,
    started: int,
    timeout_sec: int,
    phase: str,
    detail: str,
    cmd: list[str] | None = None,
    stdout_path: str = "",
    stderr_path: str = "",
) -> dict[str, Any]:
    elapsed_ms = max(0, now_ms() - started)
    payload: dict[str, Any] = {
        "request_id": req_id,
        "project": item.get("project") or "",
        "cwd": str(cwd),
        "requested_cwd": requested_cwd,
        "resolved_cwd": str(cwd),
        "cwd_source": cwd_source,
        "profile": profile,
        "model": model,
        "reasoning_effort": effort,
        "phase": phase,
        "detail": detail,
        "elapsed_ms": elapsed_ms,
        "elapsed_sec": round(elapsed_ms / 1000, 1),
        "timeout_sec": timeout_sec,
        "updated_at_ms": now_ms(),
    }
    if cmd:
        payload["command"] = command_summary(cmd)
    stdout_tail = file_tail(stdout_path, 1200) if stdout_path else ""
    stderr_tail = file_tail(stderr_path, 1200) if stderr_path else ""
    if stdout_tail:
        payload["stdout_tail"] = stdout_tail
    if stderr_tail:
        payload["stderr_tail"] = stderr_tail
    return payload


def publish_live_status(req_id: str, args: argparse.Namespace, live_status: dict[str, Any]) -> None:
    phase = str(live_status.get("phase") or "")
    detail = str(live_status.get("detail") or "")
    _LAST_LIVE_STATUS_BY_REQ[req_id] = dict(live_status)
    heartbeat_extra = {
        "current_phase": phase,
        "current_detail": detail,
        "current_project": live_status.get("project") or "",
        "current_cwd": live_status.get("cwd") or "",
        "current_requested_cwd": live_status.get("requested_cwd") or "",
        "current_resolved_cwd": live_status.get("resolved_cwd") or live_status.get("cwd") or "",
        "current_cwd_source": live_status.get("cwd_source") or "",
        "current_profile": live_status.get("profile") or "",
        "current_command": live_status.get("command") or "",
        "current_timeout_sec": live_status.get("timeout_sec") or 0,
    }
    if live_status.get("stdout_tail"):
        heartbeat_extra["current_stdout_tail"] = live_status.get("stdout_tail")
    if live_status.get("stderr_tail"):
        heartbeat_extra["current_stderr_tail"] = live_status.get("stderr_tail")
    write_heartbeat(
        args,
        0,
        "processing",
        current_request=req_id,
        current_started_at_ms=int(live_status.get("updated_at_ms") or now_ms()) - int(live_status.get("elapsed_ms") or 0),
        extra=heartbeat_extra,
    )
    fb_patch(
        f"{REQUESTS_PATH}/{req_id}",
        {
            "live_status": live_status,
            "current_phase": phase,
            "current_detail": detail,
            "current_elapsed_ms": live_status.get("elapsed_ms") or 0,
        },
    )


def publish_request_process(req_id: str, args: argparse.Namespace, pid: int) -> None:
    fb_patch(
        f"{REQUESTS_PATH}/{req_id}",
        {
            "codex_process_pid": int(pid),
            "codex_process_worker_started_at_ms": int(getattr(args, "worker_started_at_ms", 0) or 0),
        },
    )


def latest_live_status(req_id: str, item: dict[str, Any]) -> dict[str, Any]:
    live_status = _LAST_LIVE_STATUS_BY_REQ.get(req_id)
    if isinstance(live_status, dict):
        return dict(live_status)
    item_live_status = item.get("live_status")
    return dict(item_live_status) if isinstance(item_live_status, dict) else {}


def terminal_result_payload(
    req_id: str,
    item: dict[str, Any],
    args: argparse.Namespace,
    started: int,
    finished: int,
    status: str,
    error: str,
    result: dict[str, Any] | None = None,
    returncode: int = 1,
) -> dict[str, Any]:
    payload = dict(result or {})
    payload.setdefault("summary", output_summary(error or status))
    payload.setdefault("terminal_status", status)
    payload.setdefault("request_id", req_id)
    payload.setdefault("worker", getattr(args, "node", ""))
    payload.setdefault("node", getattr(args, "node", ""))
    payload.setdefault("host", getattr(args, "host", ""))
    payload.setdefault("returncode", returncode)
    payload.setdefault("duration_ms", max(0, finished - started))
    payload.setdefault("project", item.get("project") or "")
    payload.setdefault("cwd", request_cwd_value(item) or getattr(args, "cwd", "") or DEFAULT_CWD)
    payload.setdefault("profile", item.get("profile") or "")
    payload.setdefault("model", item.get("model") or getattr(args, "model", ""))
    payload.setdefault("reasoning_effort", item.get("reasoning_effort") or getattr(args, "reasoning_effort", ""))
    payload.setdefault("code_revision", getattr(args, "code_revision", "") or os.environ.get("CODEX_CODE_REVISION", "") or "")
    live_status = latest_live_status(req_id, item)
    if live_status:
        payload.setdefault("live_status", live_status)
        if live_status.get("stdout_tail"):
            payload.setdefault("stdout_tail", str(live_status.get("stdout_tail") or ""))
        if live_status.get("stderr_tail"):
            payload.setdefault("stderr_tail", str(live_status.get("stderr_tail") or ""))
    return payload


def ensure_runtime_path() -> str:
    current = os.environ.get("PATH", "")
    parts = [p for p in CODEX_PATH_PREFIX.split(":") if p]
    for path in current.split(":"):
        if path and path not in parts:
            parts.append(path)
    next_path = ":".join(parts)
    os.environ["PATH"] = next_path
    return next_path


def is_bounded_automation_request(item: dict[str, Any]) -> bool:
    forbidden = item.get("forbidden")
    token_budget = item.get("token_budget")
    context_tokens = item.get("context_tokens")
    timeout_sec = item.get("timeout_sec")
    return (
        isinstance(item.get("parent_goal"), str)
        and bool(item.get("parent_goal"))
        and item.get("capability") == AUTOMATION_BOUNDED_CAPABILITY
        and item.get("profile") == "read_only"
        and item.get("is_owner") is False
        and isinstance(forbidden, list)
        and AUTOMATION_BOUNDED_REQUIRED_FORBIDDEN <= set(forbidden)
        and isinstance(token_budget, int)
        and not isinstance(token_budget, bool)
        and 1 <= token_budget <= AUTOMATION_BOUNDED_MAX_TOKEN_BUDGET
        and isinstance(context_tokens, int)
        and not isinstance(context_tokens, bool)
        and 1 <= context_tokens <= AUTOMATION_BOUNDED_MAX_CONTEXT_TOKENS
        and isinstance(timeout_sec, int)
        and not isinstance(timeout_sec, bool)
        and 1 <= timeout_sec <= AUTOMATION_BOUNDED_MAX_TIMEOUT_SEC
    )


def codex_jsonl_usage(stdout: str) -> dict[str, int]:
    usage: dict[str, int] = {}
    for line in stdout.splitlines():
        try:
            value = json.loads(line)
        except (TypeError, ValueError):
            continue
        candidate = value.get("usage") if isinstance(value, dict) and value.get("type") == "turn.completed" else None
        if not isinstance(candidate, dict):
            continue
        next_usage: dict[str, int] = {}
        for field in ("input_tokens", "cached_input_tokens", "output_tokens", "reasoning_output_tokens"):
            raw = candidate.get(field, 0)
            if not isinstance(raw, int) or isinstance(raw, bool) or raw < 0:
                next_usage = {}
                break
            next_usage[field] = raw
        if next_usage:
            usage = next_usage
    if not usage:
        return {}
    uncached_input = max(0, usage["input_tokens"] - usage["cached_input_tokens"])
    usage["uncached_input_tokens"] = uncached_input
    usage["total_reported_tokens"] = usage["input_tokens"] + usage["output_tokens"]
    usage["budgeted_tokens"] = uncached_input + usage["output_tokens"]
    # Admission uses the stable full turn total. Cache hits remain diagnostic
    # only; they must not make the same automation packet pass or fail at
    # random across otherwise identical runs.
    usage["reservation_tokens"] = usage["total_reported_tokens"]
    return usage


def build_prompt(
    req_id: str,
    item: dict[str, Any],
    cwd: Path,
    profile: str,
    cwd_notice: str = "",
) -> str:
    task = str(item.get("task") or item.get("prompt") or item.get("message") or "").strip()
    if not task:
        raise OpsError("task missing")
    if is_bounded_automation_request(item):
        return (
            "This is one isolated bounded automation review. Use only the data already present "
            "in the task below. Do not call tools, inspect files, read AGENTS.md, use network, "
            "or obtain external context. Return at most eight concise lines and stop.\n\n"
            f"request_id: {req_id}\n"
            f"token_budget: {item['token_budget']}\n"
            f"context_budget: {item['context_tokens']}\n\n"
            f"{task}\n"
        )
    project = str(item.get("project") or "").strip()
    contract = PROJECT_CONTRACTS.get(project, "")
    auto_coding = item.get("auto_coding_allowed") is True
    must_attempt = item.get("must_attempt_repair") is True
    repair_scope = str(item.get("repair_scope") or "").strip()
    self_fix_contract = ""
    if auto_coding or must_attempt:
        self_fix_contract = (
            "이 요청은 자동 self_fix입니다. 단순 분석 리포트만 쓰고 끝내지 말고, "
            "안전 경계 안에서 재현 가능한 원인이나 명백한 코드/설정/문서 문제가 확인되면 직접 수정, 검증, 필요한 빌드/배포까지 시도하세요. "
            "직접 고칠 수 없는 외부 상태, 권한, 장비, 원본 데이터 경계 문제라면 무엇이 막는지와 다음 복구 명령만 짧게 남기세요.\n"
        )
    if repair_scope:
        self_fix_contract += f"self_fix_scope: {repair_scope}\n"
    return (
        "당신은 서버폰 Termux 안에서 실행되는 Codex 작업 세션입니다.\n"
        "목적은 ADB가 불안정할 때 개인폰 Codex 또는 StoreBot AI가 보낸 프로젝트 작업을 서버폰 로컬 repo에서 대신 처리하는 것입니다.\n"
        "현재 Codex 운영 세션과 같은 원칙으로 일합니다: AGENTS.md -> CODEX_BRIEF.md -> CODEMAP.txt -> rules/ai_ops_prompt_contract.txt -> 대상 앱 문서를 먼저 보고, 기존 미커밋 변경은 되돌리지 않습니다.\n"
        f"대상 repo나 문서가 없으면 공유 스냅샷 `{SHARED_CONTEXT_DIR}/INDEX.md`와 `ai_ops_context/<project>/APP_INTENT.md`, `CODEMAP.txt`를 먼저 확인하세요.\n"
        "approval_policy=never, sandbox=danger-full-access/read-only profile 환경입니다. destructive reset/checkout/force push 금지, 비밀정보/빌드 산출물 커밋 금지입니다.\n"
        "goal mode 요청은 사용자 승인 대기 없이 분석/복구/수정을 계속 진행하라는 뜻입니다. 승인 딜레이 때문에 멈추지 마세요.\n"
        f"{self_fix_contract}"
        "앱 코드나 리소스를 바꿨으면 직접 빌드하고, 해당 앱에 업데이트센터 채널이 있으면 version.json/latest.bin 배포까지 완료하세요.\n"
        "문서 의도와 코드 경로가 바뀌면 APP_INTENT.md/CODEMAP.txt와 루트 포인터를 짧게 갱신하세요.\n"
        "카톡 채팅방 대화에 개입하지 마세요. StoreBot 운영방 답변을 만들지 마세요.\n"
        "현재 요청은 Firebase codex_ops 큐에서 온 프로젝트 작업입니다.\n"
        f"request_id: {req_id}\n"
        f"profile: {profile}\n"
        f"cwd: {cwd}\n"
        f"{cwd_notice}"
        f"project_contract: {contract or '대상 프로젝트 문서와 CODEMAP 기준으로 빌드/검증/전달 완료 조건을 판단합니다.'}\n"
        "작업 후에는 무엇을 바꿨는지, 어떤 검증을 했는지, 남은 위험만 짧게 요약하세요.\n\n"
        "## 작업 지시\n"
        f"{task}\n"
    )


def resolve_cwd(requested: Path, fallback: str, ignore_requested: bool = False) -> tuple[Path, str, str]:
    fallback_path = Path(fallback).expanduser()
    if ignore_requested:
        if fallback_path.exists() and fallback_path.is_dir():
            notice = (
                f"requested_cwd_ignored_foreign_posix: {requested}\n"
                f"fallback_cwd_used: {fallback_path}\n"
            )
            return fallback_path, notice, "fallback_foreign_posix"
        raise OpsError(f"foreign cwd ignored: {requested}; fallback cwd not found: {fallback_path}")
    if requested.exists() and requested.is_dir():
        return requested, "", "requested"
    if fallback_path.exists() and fallback_path.is_dir():
        notice = (
            f"requested_cwd_missing: {requested}\n"
            f"fallback_cwd_used: {fallback_path}\n"
            "대상 프로젝트 repo가 이 실행 환경에 없으면 그것이 self_fix 대상입니다. "
            f"공유 문서 스냅샷 `{SHARED_CONTEXT_DIR}/INDEX.md`와 대상 앱 APP_INTENT/CODEMAP 스냅샷을 먼저 읽고, "
            "repo 경로 복구 가능 여부를 판단하세요.\n"
        )
        return fallback_path, notice, "fallback_missing"
    raise OpsError(f"cwd not found: {requested}; fallback cwd not found: {fallback_path}")


def codex_command(
    output_path: str,
    cwd: Path,
    model: str,
    effort: str,
    profile: str,
    *,
    bounded_automation: bool = False,
) -> list[str]:
    sandbox = "read-only" if profile == "read_only" else "danger-full-access"
    cmd = [
        "codex",
        "exec",
        "--ignore-user-config",
        "--json",
        "-o",
        output_path,
        "-C",
        str(cwd),
        "-c",
        f'sandbox_mode="{sandbox}"',
        "-c",
        'approval_policy="never"',
        "--skip-git-repo-check",
    ]
    if bounded_automation:
        cmd.extend(
            [
                "--ephemeral",
                "-c", "project_doc_max_bytes=0",
                "-c", f"model_context_window={AUTOMATION_BOUNDED_CONTEXT_WINDOW}",
                "-c", f"model_auto_compact_token_limit={AUTOMATION_BOUNDED_COMPACT_LIMIT}",
                "-c", f"tool_output_token_limit={AUTOMATION_BOUNDED_TOOL_OUTPUT_LIMIT}",
                "-c", 'model_verbosity="low"',
            ]
        )
    if model:
        cmd.extend(["-m", model])
    if effort:
        cmd.extend(["-c", f'model_reasoning_effort="{effort}"'])
    cmd.append("-")
    return cmd


def safe_prompt_file_slug(value: Any, fallback: str = "prompt") -> str:
    raw = str(value or "").replace("\\", "/").split("/")[-1]
    stem = Path(raw).stem or raw
    text = re.sub(r"[^0-9A-Za-z._-]+", "_", stem).strip("._-")
    return (text or fallback)[:80]


def prompt_spool_dir(args: argparse.Namespace) -> Path:
    configured = str(os.environ.get("CODEX_OPS_PROMPT_SPOOL_DIR") or "").strip()
    base = Path(configured).expanduser() if configured else Path(args.cwd or DEFAULT_CWD).expanduser() / PROMPT_SPOOL_DIR_NAME
    base.mkdir(parents=True, exist_ok=True)
    try:
        base.chmod(0o700)
    except OSError:
        pass
    return base


def resume_prompt_text(item: dict[str, Any]) -> str:
    for key in ("prompt_file_content", "prompt_text", "prompt"):
        value = item.get(key)
        if value is not None and str(value).strip():
            return str(value)
    raise OpsError("prompt_text or prompt_file_content missing")


def write_resume_prompt_file(req_id: str, item: dict[str, Any], args: argparse.Namespace) -> Path:
    text = resume_prompt_text(item)
    spool_dir = prompt_spool_dir(args)
    timestamp = time.strftime("%Y%m%dT%H%M%SZ", time.gmtime())
    req_slug = safe_prompt_file_slug(req_id, "request")
    name_slug = safe_prompt_file_slug(item.get("prompt_file_name") or item.get("prompt_filename"), "prompt")
    prompt_path = spool_dir / f"{timestamp}_{req_slug}_{name_slug}.md"
    prompt_path.write_text(text, encoding="utf-8")
    try:
        prompt_path.chmod(0o600)
    except OSError:
        pass
    return prompt_path


def resume_prompt_instruction(prompt_file: Path) -> str:
    prompt_ref = prompt_file.as_posix() if hasattr(prompt_file, "as_posix") else str(prompt_file)
    return f"{prompt_ref} 파일을 읽고 그 내용을 원문 기준으로 그대로 이어서 작업해."


def codex_resume_command(
    output_path: str,
    cwd: Path,
    model: str,
    effort: str,
    profile: str,
    session_id: str,
    prompt_file: Path,
) -> list[str]:
    sandbox = "read-only" if profile == "read_only" else "danger-full-access"
    short_prompt = resume_prompt_instruction(prompt_file)
    cmd = [
        "codex",
        "exec",
        "--ignore-user-config",
        "--json",
        "-o",
        output_path,
        "-C",
        str(cwd),
        "-c",
        f'sandbox_mode="{sandbox}"',
        "-c",
        'approval_policy="never"',
        "--skip-git-repo-check",
    ]
    if model:
        cmd.extend(["-m", model])
    if effort:
        cmd.extend(["-c", f'model_reasoning_effort="{effort}"'])
    cmd.extend(["resume", session_id, short_prompt])
    return cmd


def hook_argv_contract_payload() -> dict[str, Any]:
    probe_cwd = Path("/tmp/codex-hook-argv-contract")
    model = "contract-probe-model"
    effort = "low"
    exec_argv = codex_command("/tmp/codex-hook-exec.out", probe_cwd, model, effort, "read_only")
    resume_argv = codex_resume_command(
        "/tmp/codex-hook-resume.out",
        probe_cwd,
        model,
        effort,
        "read_only",
        "00000000-0000-0000-0000-000000000000",
        Path("/tmp/codex-hook-prompt.md"),
    )
    return {
        "status": "PASS",
        "behavior": "actual_argv",
        "model": model,
        "reasoning_effort": effort,
        "exec_argv": exec_argv,
        "resume_argv": resume_argv,
    }


def lock_status_payload(locks: list[dict[str, str]]) -> dict[str, Any]:
    return {
        "acquired": True,
        "count": len(locks),
        "scopes": [lock.get("scope", "") for lock in locks],
        "paths": [lock.get("path", "") for lock in locks],
    }


def capped_text(text: str, limit: int = 4000) -> str:
    if len(text) <= limit:
        return text
    return text[-limit:]


def sdk_runner_command(request_json: str) -> list[str]:
    return [sys.executable, str(Path(__file__).with_name("codex_sdk_runner.py")), "run", "--request-json", request_json]


def sdk_can_fallback(result: dict[str, Any]) -> bool:
    status = str(result.get("status") or "")
    stage = str(result.get("stage") or "")
    return status == "unavailable" or not bool_field(result.get("started_turn")) or stage in {
        "probe",
        "input",
        "import",
        "connect",
        "start_thread",
        "resume_thread",
    }


def run_codex_sdk_prompt(
    req_id: str,
    item: dict[str, Any],
    args: argparse.Namespace,
    prompt: str,
    cwd: Path,
    requested_cwd: str,
    cwd_source: str,
    profile: str,
    model: str,
    effort: str,
    timeout_sec: int,
    thread_id: str = "",
) -> dict[str, Any]:
    started = now_ms()
    heartbeat_sec = max(15, int(getattr(args, "active_heartbeat_sec", 60) or 60))
    payload = {
        "prompt": prompt,
        "cwd": str(cwd),
        "profile": profile,
        "model": model,
        "reasoning_effort": effort,
        "thread_id": thread_id,
    }
    request_file = tempfile.NamedTemporaryFile(prefix="codex_sdk_", suffix=".json", mode="w", encoding="utf-8", delete=False)
    json.dump(payload, request_file, ensure_ascii=False)
    request_path = request_file.name
    request_file.close()
    stdout_file = tempfile.NamedTemporaryFile(prefix="codex_sdk_", suffix=".stdout", mode="w+", encoding="utf-8", delete=False)
    stderr_file = tempfile.NamedTemporaryFile(prefix="codex_sdk_", suffix=".stderr", mode="w+", encoding="utf-8", delete=False)
    stdout_path = stdout_file.name
    stderr_path = stderr_file.name
    cmd = sdk_runner_command(request_path)
    proc: subprocess.Popen[str] | None = None
    stdout = ""
    stderr = ""
    try:
        publish_live_status(
            req_id,
            args,
            live_status_payload(
                req_id,
                item,
                cwd,
                requested_cwd,
                cwd_source,
                profile,
                model,
                effort,
                started,
                timeout_sec,
                "starting_codex_sdk",
                "Codex SDK runner is being started",
                cmd,
            ),
        )
        proc = subprocess.Popen(
            cmd,
            stdout=stdout_file,
            stderr=stderr_file,
            text=True,
            env=request_process_env(req_id, args),
            **subprocess_group_kwargs(),
        )
        publish_request_process(req_id, args, proc.pid)
        publish_live_status(
            req_id,
            args,
            live_status_payload(
                req_id,
                item,
                cwd,
                requested_cwd,
                cwd_source,
                profile,
                model,
                effort,
                started,
                timeout_sec,
                "codex_sdk_running",
                "Codex SDK runner is processing the request",
                cmd,
                stdout_path,
                stderr_path,
            ),
        )
        deadline = time.monotonic() + timeout_sec
        next_heartbeat = time.monotonic()
        while proc.poll() is None:
            current = time.monotonic()
            if current >= next_heartbeat:
                try:
                    publish_live_status(
                        req_id,
                        args,
                        live_status_payload(
                            req_id,
                            item,
                            cwd,
                            requested_cwd,
                            cwd_source,
                            profile,
                            model,
                            effort,
                            started,
                            timeout_sec,
                            "codex_sdk_running",
                            "Codex SDK runner is still running",
                            cmd,
                            stdout_path,
                            stderr_path,
                        ),
                    )
                except Exception as exc:
                    log(f"heartbeat warning {req_id}: {compact_error(str(exc), 300)}")
                next_heartbeat = current + heartbeat_sec
            if current >= deadline:
                terminate_process_tree(proc)
                stdout_file.flush()
                stderr_file.flush()
                stdout = Path(stdout_path).read_text(encoding="utf-8", errors="replace")
                stderr = Path(stderr_path).read_text(encoding="utf-8", errors="replace")
                return {
                    "status": "failed_timeout",
                    "returncode": -9,
                    "duration_ms": now_ms() - started,
                    "summary": f"codex sdk timeout after {timeout_sec}s",
                    "error": f"codex sdk timeout after {timeout_sec}s",
                    "stdout": capped_text(stdout),
                    "stderr": capped_text(stderr),
                    "stdout_len": len(stdout),
                    "stderr_len": len(stderr),
                    "started_turn": True,
                    "stage": "timeout",
                }
            time.sleep(min(5.0, max(0.2, deadline - current)))

        stdout_file.flush()
        stderr_file.flush()
        stdout = Path(stdout_path).read_text(encoding="utf-8", errors="replace")
        stderr = Path(stderr_path).read_text(encoding="utf-8", errors="replace")
        lines = [line for line in stdout.splitlines() if line.strip()]
        if not lines:
            return {
                "status": "error",
                "returncode": proc.returncode if proc else 1,
                "duration_ms": now_ms() - started,
                "summary": compact_error(stderr or "codex sdk runner produced no JSON", 1200),
                "error": compact_error(stderr or "codex sdk runner produced no JSON", 1200),
                "stdout": capped_text(stdout),
                "stderr": capped_text(stderr),
                "started_turn": False,
                "stage": "runner_output",
            }
        result = json.loads(lines[-1])
        result["stdout"] = capped_text(stdout)
        result["stderr"] = capped_text(stderr)
        result["stdout_len"] = len(stdout)
        result["stderr_len"] = len(stderr)
        result["duration_ms"] = int(result.get("duration_ms") or now_ms() - started)
        return result
    finally:
        for handle in (stdout_file, stderr_file):
            try:
                handle.close()
            except Exception:
                pass
        for path in (request_path, stdout_path, stderr_path):
            try:
                Path(path).unlink(missing_ok=True)
            except Exception:
                pass


def run_codex_resume_prompt_file_exec(
    req_id: str,
    item: dict[str, Any],
    args: argparse.Namespace,
    locks: list[dict[str, str]],
) -> dict[str, Any]:
    profile = normalize_profile(item.get("profile"))
    if profile in {"patch", "yolo"} and item.get("is_owner") is not True:
        raise OpsError(f"profile {profile} requires is_owner=true")
    session_id = validate_session_id(item.get("session_id"))
    requested_cwd_text = request_cwd_value(item)
    fallback_cwd = args.cwd or DEFAULT_CWD
    requested_cwd = Path(requested_cwd_text or fallback_cwd).expanduser()
    cwd, _cwd_notice, cwd_source = resolve_cwd(
        requested_cwd,
        fallback_cwd,
        should_ignore_requested_cwd(requested_cwd_text or requested_cwd, args),
    )
    model = str(item.get("model") or args.model or "").strip()
    effort = normalize_reasoning(item.get("reasoning_effort"), args.reasoning_effort)
    timeout_sec = int(item.get("timeout_sec") or args.timeout_sec)
    prompt_file = write_resume_prompt_file(req_id, item, args)
    dry_run_requested = bool_field(item.get("dry_run"))
    if dry_run_requested:
        output_path = str(prompt_file.with_suffix(".codex-output.txt"))
    else:
        output_file = tempfile.NamedTemporaryFile(prefix="codex_resume_", suffix=".txt", delete=False)
        output_path = output_file.name
        output_file.close()
    cmd = codex_resume_command(output_path, cwd, model, effort, profile, session_id, prompt_file)
    started = now_ms()
    stdout = ""
    stderr = ""
    output = ""
    returncode = 0
    error = ""
    status = "done"
    heartbeat_sec = max(15, int(getattr(args, "active_heartbeat_sec", 60) or 60))

    base_result: dict[str, Any] = {
        "session_id": session_id,
        "prompt_file": str(prompt_file),
        "dry_run": dry_run_requested,
        "command": command_summary(cmd),
        "lock_status": lock_status_payload(locks),
    }

    if dry_run_requested:
        summary = "dry_run: prompt file saved and codex resume command was built"
        result = {
            **base_result,
            "status": "dry_run",
            "returncode": 0,
            "summary": summary,
            "output_len": 0,
            "stdout": "",
            "stderr": "",
            "stdout_len": 0,
            "stderr_len": 0,
        }
        return {
            "status": "done",
            "returncode": 0,
            "duration_ms": now_ms() - started,
            "profile": profile,
            "cwd": str(cwd),
            "requested_cwd": requested_cwd_text,
            "cwd_source": cwd_source,
            "model": model,
            "reasoning_effort": effort,
            "result": result,
            "error": "",
        }

    codex_preflight = require_codex_cli_preflight(cwd, args)
    base_result["codex_preflight"] = {
        key: value for key, value in codex_preflight.items() if key != "command_result"
    }

    stdout_file = tempfile.NamedTemporaryFile(prefix="codex_resume_", suffix=".stdout", mode="w+", encoding="utf-8", delete=False)
    stderr_file = tempfile.NamedTemporaryFile(prefix="codex_resume_", suffix=".stderr", mode="w+", encoding="utf-8", delete=False)
    stdout_path = stdout_file.name
    stderr_path = stderr_file.name
    proc: subprocess.Popen[str] | None = None
    try:
        publish_live_status(
            req_id,
            args,
            live_status_payload(
                req_id,
                item,
                cwd,
                requested_cwd_text,
                cwd_source,
                profile,
                model,
                effort,
                started,
                timeout_sec,
                "starting_codex_resume_exec",
                "Codex resume subprocess is being started",
                cmd,
            ),
        )
        proc = subprocess.Popen(
            cmd,
            stdout=stdout_file,
            stderr=stderr_file,
            text=True,
            env=request_process_env(req_id, args),
            **subprocess_group_kwargs(),
        )
        publish_request_process(req_id, args, proc.pid)
        publish_live_status(
            req_id,
            args,
            live_status_payload(
                req_id,
                item,
                cwd,
                requested_cwd_text,
                cwd_source,
                profile,
                model,
                effort,
                started,
                timeout_sec,
                "codex_resume_exec_running",
                "Codex resume is processing the prompt file",
                cmd,
                stdout_path,
                stderr_path,
            ),
        )
        deadline = time.monotonic() + timeout_sec
        next_heartbeat = time.monotonic()
        while proc.poll() is None:
            current = time.monotonic()
            if current >= next_heartbeat:
                try:
                    publish_live_status(
                        req_id,
                        args,
                        live_status_payload(
                            req_id,
                            item,
                            cwd,
                            requested_cwd_text,
                            cwd_source,
                            profile,
                            model,
                            effort,
                            started,
                            timeout_sec,
                            "codex_resume_exec_running",
                            "Codex resume is still running; see stdout/stderr tail for activity",
                            cmd,
                            stdout_path,
                            stderr_path,
                        ),
                    )
                except Exception as exc:
                    log(f"heartbeat warning {req_id}: {compact_error(str(exc), 300)}")
                next_heartbeat = current + heartbeat_sec
            if current >= deadline:
                terminate_process_tree(proc)
                status = "failed_timeout"
                returncode = -9
                error = f"codex resume timeout after {timeout_sec}s"
                break
            time.sleep(min(5.0, max(0.2, deadline - current)))

        stdout_file.flush()
        stderr_file.flush()
        stdout = Path(stdout_path).read_text(encoding="utf-8", errors="replace")
        stderr = Path(stderr_path).read_text(encoding="utf-8", errors="replace")
        output = Path(output_path).read_text(encoding="utf-8", errors="replace").strip()
        if not error and proc is not None:
            returncode = int(proc.returncode or 0)
            if returncode != 0:
                status = "error"
                error = compact_error(stderr or stdout or output or "codex resume exec failed", 1200)
        publish_live_status(
            req_id,
            args,
            live_status_payload(
                req_id,
                item,
                cwd,
                requested_cwd_text,
                cwd_source,
                profile,
                model,
                effort,
                started,
                timeout_sec,
                "codex_resume_exec_finished",
                "Codex resume subprocess finished; result is being recorded",
                cmd,
                stdout_path,
                stderr_path,
            ),
        )
    finally:
        for handle in (stdout_file, stderr_file):
            try:
                handle.close()
            except Exception:
                pass
        for path in (output_path, stdout_path, stderr_path):
            try:
                Path(path).unlink(missing_ok=True)
            except Exception:
                pass

    summary_source = output or stdout or stderr or error or "codex resume completed"
    summary = output_summary(summary_source)
    result = {
        **base_result,
        "status": status,
        "returncode": returncode,
        "summary": summary,
        "output_len": len(output or ""),
        "stdout": capped_text(stdout or ""),
        "stderr": capped_text(stderr or ""),
        "stdout_len": len(stdout or ""),
        "stderr_len": len(stderr or ""),
    }
    return {
        "status": status,
        "returncode": returncode,
        "duration_ms": now_ms() - started,
        "profile": profile,
        "cwd": str(cwd),
        "requested_cwd": requested_cwd_text,
        "cwd_source": cwd_source,
        "model": model,
        "reasoning_effort": effort,
        "result": result,
        "codex_preflight": base_result.get("codex_preflight"),
        "error": error,
    }


def run_codex_resume_prompt_file(
    req_id: str,
    item: dict[str, Any],
    args: argparse.Namespace,
    locks: list[dict[str, str]],
) -> dict[str, Any]:
    engine_requested = normalize_engine(item.get("engine") or getattr(args, "engine", "auto"))
    if bool_field(item.get("dry_run")) or engine_requested == "exec":
        result = run_codex_resume_prompt_file_exec(req_id, item, args, locks)
        result["engine_requested"] = engine_requested
        result["engine_used"] = "exec"
        result["engine_fallback_reason"] = "dry_run_or_exec_requested" if bool_field(item.get("dry_run")) else ""
        if isinstance(result.get("result"), dict):
            result["result"]["engine_requested"] = engine_requested
            result["result"]["engine_used"] = "exec"
        return result

    profile = normalize_profile(item.get("profile"))
    if profile in {"patch", "yolo"} and item.get("is_owner") is not True:
        raise OpsError(f"profile {profile} requires is_owner=true")
    session_id = validate_session_id(item.get("session_id"))
    requested_cwd_text = request_cwd_value(item)
    fallback_cwd = args.cwd or DEFAULT_CWD
    requested_cwd = Path(requested_cwd_text or fallback_cwd).expanduser()
    cwd, _cwd_notice, cwd_source = resolve_cwd(
        requested_cwd,
        fallback_cwd,
        should_ignore_requested_cwd(requested_cwd_text or requested_cwd, args),
    )
    model = str(item.get("model") or args.model or "").strip()
    effort = normalize_reasoning(item.get("reasoning_effort"), args.reasoning_effort)
    timeout_sec = int(item.get("timeout_sec") or args.timeout_sec)
    probe = probe_codex_sdk()
    selected_engine, select_reason = choose_engine(engine_requested, probe)
    if selected_engine == "sdk":
        prompt_file = write_resume_prompt_file(req_id, item, args)
        short_prompt = resume_prompt_instruction(prompt_file)
        sdk_result = run_codex_sdk_prompt(
            req_id,
            item,
            args,
            short_prompt,
            cwd,
            requested_cwd_text,
            cwd_source,
            profile,
            model,
            effort,
            timeout_sec,
            thread_id=session_id,
        )
        if str(sdk_result.get("status") or "") == "done":
            summary = output_summary(str(sdk_result.get("summary") or "codex sdk resume completed"))
            return {
                "status": "done",
                "returncode": 0,
                "duration_ms": int(sdk_result.get("duration_ms") or 0),
                "profile": profile,
                "cwd": str(cwd),
                "requested_cwd": requested_cwd_text,
                "cwd_source": cwd_source,
                "model": model,
                "reasoning_effort": effort,
                "engine_requested": engine_requested,
                "engine_used": "sdk",
                "engine_fallback_reason": "",
                "sdk_probe": sdk_result.get("probe") or probe,
                "result": {
                    "status": "done",
                    "returncode": 0,
                    "summary": summary,
                    "output_len": int(sdk_result.get("output_len") or len(summary)),
                    "stdout": capped_text(str(sdk_result.get("stdout") or "")),
                    "stderr": capped_text(str(sdk_result.get("stderr") or "")),
                    "stdout_len": int(sdk_result.get("stdout_len") or 0),
                    "stderr_len": int(sdk_result.get("stderr_len") or 0),
                    "session_id": session_id,
                    "prompt_file": str(prompt_file),
                    "lock_status": lock_status_payload(locks),
                    "engine_requested": engine_requested,
                    "engine_used": "sdk",
                    "sdk": sdk_result,
                },
                "error": "",
            }
        if not sdk_can_fallback(sdk_result):
            return {
                "status": str(sdk_result.get("status") or "error"),
                "returncode": int(sdk_result.get("returncode") or 1),
                "duration_ms": int(sdk_result.get("duration_ms") or 0),
                "profile": profile,
                "cwd": str(cwd),
                "requested_cwd": requested_cwd_text,
                "cwd_source": cwd_source,
                "model": model,
                "reasoning_effort": effort,
                "engine_requested": engine_requested,
                "engine_used": "sdk",
                "engine_fallback_reason": "",
                "sdk_probe": sdk_result.get("probe") or probe,
                "result": {"summary": output_summary(sdk_result.get("summary") or sdk_result.get("error") or ""), "sdk": sdk_result},
                "error": str(sdk_result.get("error") or sdk_result.get("summary") or "codex sdk failed"),
            }
        select_reason = str(sdk_result.get("error") or sdk_result.get("summary") or select_reason)

    fallback = run_codex_resume_prompt_file_exec(req_id, item, args, locks)
    fallback["engine_requested"] = engine_requested
    fallback["engine_used"] = "exec"
    fallback["engine_fallback_reason"] = select_reason
    fallback["sdk_probe"] = probe
    if isinstance(fallback.get("result"), dict):
        fallback["result"]["engine_requested"] = engine_requested
        fallback["result"]["engine_used"] = "exec"
        fallback["result"]["engine_fallback_reason"] = select_reason
        fallback["result"]["sdk_probe"] = probe
    return fallback


def run_codex_task(req_id: str, item: dict[str, Any], args: argparse.Namespace) -> dict[str, Any]:
    profile = normalize_profile(item.get("profile"))
    if profile in {"patch", "yolo"} and item.get("is_owner") is not True:
        raise OpsError(f"profile {profile} requires is_owner=true")
    bounded_automation = is_bounded_automation_request(item)
    automation_marked = isinstance(item.get("parent_goal"), str) or isinstance(item.get("child_id"), str)
    if automation_marked and item.get("capability") == AUTOMATION_BOUNDED_CAPABILITY and not bounded_automation:
        raise OpsError("bounded automation request violates the isolated token/context contract")
    requested_cwd_text = request_cwd_value(item)
    fallback_cwd = args.cwd or DEFAULT_CWD
    if bounded_automation:
        requested_cwd = Path("/tmp")
        cwd, cwd_notice, cwd_source = Path("/tmp"), "bounded_automation_isolated_cwd\n", "bounded_isolated"
    else:
        requested_cwd = Path(requested_cwd_text or fallback_cwd).expanduser()
        cwd, cwd_notice, cwd_source = resolve_cwd(
            requested_cwd,
            fallback_cwd,
            should_ignore_requested_cwd(requested_cwd_text or requested_cwd, args),
        )
    model = str(item.get("model") or args.model or "").strip()
    effort = "low" if bounded_automation else normalize_reasoning(item.get("reasoning_effort"), args.reasoning_effort)
    timeout_sec = int(item.get("timeout_sec") or args.timeout_sec)
    if bounded_automation:
        timeout_sec = min(timeout_sec, AUTOMATION_BOUNDED_MAX_TIMEOUT_SEC)
    prompt = build_prompt(req_id, item, cwd, profile, cwd_notice)
    engine_requested = "exec" if bounded_automation else normalize_engine(item.get("engine") or getattr(args, "engine", "auto"))
    sdk_probe: dict[str, Any] = {}
    engine_fallback_reason = ""
    if engine_requested != "exec":
        sdk_probe = probe_codex_sdk()
        selected_engine, engine_fallback_reason = choose_engine(engine_requested, sdk_probe)
        if selected_engine == "sdk":
            sdk_result = run_codex_sdk_prompt(
                req_id,
                item,
                args,
                prompt,
                cwd,
                requested_cwd_text,
                cwd_source,
                profile,
                model,
                effort,
                timeout_sec,
            )
            if str(sdk_result.get("status") or "") == "done":
                summary = output_summary(str(sdk_result.get("summary") or "codex sdk completed"))
                return {
                    "summary": summary,
                    "output_len": int(sdk_result.get("output_len") or len(summary)),
                    "stdout_len": int(sdk_result.get("stdout_len") or 0),
                    "stderr_len": int(sdk_result.get("stderr_len") or 0),
                    "duration_ms": int(sdk_result.get("duration_ms") or 0),
                    "profile": profile,
                    "cwd": str(cwd),
                    "requested_cwd": requested_cwd_text,
                    "cwd_source": cwd_source,
                    "model": model,
                    "reasoning_effort": effort,
                    "engine_requested": engine_requested,
                    "engine_used": "sdk",
                    "engine_fallback_reason": "",
                    "sdk_probe": sdk_result.get("probe") or sdk_probe,
                    "sdk": sdk_result,
                }
            if str(sdk_result.get("status") or "") == "failed_timeout":
                raise subprocess.TimeoutExpired(["codex_sdk_runner"], timeout_sec)
            if not sdk_can_fallback(sdk_result):
                raise OpsError(compact_error(sdk_result.get("error") or sdk_result.get("summary") or "codex sdk failed", 1200))
            engine_fallback_reason = str(sdk_result.get("error") or sdk_result.get("summary") or engine_fallback_reason)
    codex_preflight = require_codex_cli_preflight(cwd, args)

    output_file = tempfile.NamedTemporaryFile(prefix="codex_ops_", suffix=".txt", delete=False)
    output_path = output_file.name
    output_file.close()
    stdout_file = tempfile.NamedTemporaryFile(prefix="codex_ops_", suffix=".stdout", mode="w+", encoding="utf-8", delete=False)
    stderr_file = tempfile.NamedTemporaryFile(prefix="codex_ops_", suffix=".stderr", mode="w+", encoding="utf-8", delete=False)
    stdout_path = stdout_file.name
    stderr_path = stderr_file.name
    started = now_ms()
    heartbeat_sec = max(15, int(getattr(args, "active_heartbeat_sec", 60) or 60))
    cmd = codex_command(
        output_path,
        cwd,
        model,
        effort,
        profile,
        bounded_automation=bounded_automation,
    )
    proc: subprocess.Popen[str] | None = None
    try:
        publish_live_status(
            req_id,
            args,
            live_status_payload(
                req_id,
                item,
                cwd,
                requested_cwd_text,
                cwd_source,
                profile,
                model,
                effort,
                started,
                timeout_sec,
                "starting_codex_exec",
                "Codex subprocess is being started",
                cmd,
            ),
        )
        proc = subprocess.Popen(
            cmd,
            stdin=subprocess.PIPE,
            stdout=stdout_file,
            stderr=stderr_file,
            text=True,
            env=request_process_env(req_id, args),
            **subprocess_group_kwargs(),
        )
        publish_request_process(req_id, args, proc.pid)
        try:
            if proc.stdin:
                proc.stdin.write(prompt)
                proc.stdin.close()
        except BrokenPipeError:
            pass

        publish_live_status(
            req_id,
            args,
            live_status_payload(
                req_id,
                item,
                cwd,
                requested_cwd_text,
                cwd_source,
                profile,
                model,
                effort,
                started,
                timeout_sec,
                "codex_exec_running",
                "Codex is processing the request",
                cmd,
                stdout_path,
                stderr_path,
            ),
        )
        deadline = time.monotonic() + timeout_sec
        next_heartbeat = time.monotonic()
        while proc.poll() is None:
            current = time.monotonic()
            if current >= next_heartbeat:
                try:
                    publish_live_status(
                        req_id,
                        args,
                        live_status_payload(
                            req_id,
                            item,
                            cwd,
                            requested_cwd_text,
                            cwd_source,
                            profile,
                            model,
                            effort,
                            started,
                            timeout_sec,
                            "codex_exec_running",
                            "Codex is still running; see stdout/stderr tail for activity",
                            cmd,
                            stdout_path,
                            stderr_path,
                        ),
                    )
                except Exception as exc:
                    log(f"heartbeat warning {req_id}: {compact_error(str(exc), 300)}")
                next_heartbeat = current + heartbeat_sec
            if current >= deadline:
                terminate_process_tree(proc)
                stdout_file.flush()
                stderr_file.flush()
                stdout = Path(stdout_path).read_text(encoding="utf-8", errors="replace")
                stderr = Path(stderr_path).read_text(encoding="utf-8", errors="replace")
                output = Path(output_path).read_text(encoding="utf-8", errors="replace").strip()
                raise subprocess.TimeoutExpired(cmd, timeout_sec, output=stdout or output, stderr=stderr)
            time.sleep(min(5.0, max(0.2, deadline - current)))

        stdout_file.flush()
        stderr_file.flush()
        stdout = Path(stdout_path).read_text(encoding="utf-8", errors="replace")
        stderr = Path(stderr_path).read_text(encoding="utf-8", errors="replace")
        output = Path(output_path).read_text(encoding="utf-8", errors="replace").strip()
        publish_live_status(
            req_id,
            args,
            live_status_payload(
                req_id,
                item,
                cwd,
                requested_cwd_text,
                cwd_source,
                profile,
                model,
                effort,
                started,
                timeout_sec,
                "codex_exec_finished",
                "Codex subprocess finished; result is being recorded",
                cmd,
                stdout_path,
                stderr_path,
            ),
        )
    finally:
        for handle in (stdout_file, stderr_file):
            try:
                handle.close()
            except Exception:
                pass
        for path in (output_path, stdout_path, stderr_path):
            try:
                Path(path).unlink(missing_ok=True)
            except Exception:
                pass
    if proc is None:
        raise OpsError("codex process did not start")
    if proc.returncode != 0:
        raise OpsError(compact_error(stderr or stdout or output or "codex exec failed", 1200))
    if not output.strip():
        fallback = output_summary(stdout or stderr)
        if not fallback:
            raise OpsError("codex exec returned success with empty output")
        output = fallback
    token_usage = codex_jsonl_usage(stdout) if bounded_automation else {}
    if bounded_automation and not token_usage:
        raise OpsError("bounded automation Codex result omitted turn.completed usage")
    actual_token_usage = token_usage.get("reservation_tokens", 0)
    token_budget = int(item.get("token_budget") or 0) if bounded_automation else 0
    return {
        "summary": output_summary(output),
        "output_len": len(output),
        "stdout_len": len(stdout or ""),
        "stderr_len": len(stderr or ""),
        "duration_ms": now_ms() - started,
        "profile": profile,
        "cwd": str(cwd),
        "requested_cwd": requested_cwd_text,
        "cwd_source": cwd_source,
        "model": model,
        "reasoning_effort": effort,
        "engine_requested": engine_requested,
        "engine_used": "exec",
        "engine_fallback_reason": engine_fallback_reason,
        "sdk_probe": sdk_probe,
        "codex_preflight": {
            key: value for key, value in codex_preflight.items() if key != "command_result"
        },
        "bounded_automation": bounded_automation,
        "token_usage": token_usage,
        "actual_token_usage": actual_token_usage,
        "token_budget_exceeded": bool(bounded_automation and actual_token_usage > token_budget),
    }


def is_expired(item: dict[str, Any]) -> bool:
    ttl_ms = int(item.get("ttl_ms") or 0)
    created_at = int(item.get("created_at_ms") or 0)
    return ttl_ms > 0 and created_at > 0 and now_ms() - created_at > ttl_ms


def mark_expired(req_id: str, item: dict[str, Any], args: argparse.Namespace, started: int, reason: str) -> None:
    finished = now_ms()
    payload = {
        "status": "expired",
        "worker": args.node,
        "finished_at_ms": finished,
        "expired_at_ms": finished,
        "duration_ms": finished - started,
        "returncode": 0,
        "project": item.get("project") or "",
        "cwd": request_cwd_value(item),
        "profile": item.get("profile") or "",
        "model": item.get("model") or args.model,
        "reasoning_effort": item.get("reasoning_effort") or args.reasoning_effort,
        "result": terminal_result_payload(req_id, item, args, started, finished, "expired", reason, {"summary": reason}, 0),
        "error": "",
    }
    payload.update(REQUEST_PROGRESS_CLEAR_FIELDS)
    fb_patch(f"{REQUESTS_PATH}/{req_id}", payload)
    fb_put(f"{RESULTS_PATH}/{req_id}", payload)
    log(f"expired {req_id}: {reason}")


def mark_error(
    req_id: str,
    item: dict[str, Any],
    args: argparse.Namespace,
    started: int,
    error: str,
    status: str = "error",
    result: dict[str, Any] | None = None,
    returncode: int = 1,
) -> None:
    finished = now_ms()
    payload = {
        "status": status,
        "worker": args.node,
        "finished_at_ms": finished,
        "duration_ms": finished - started,
        "returncode": returncode,
        "project": item.get("project") or "",
        "cwd": request_cwd_value(item),
        "profile": item.get("profile") or "",
        "model": item.get("model") or args.model,
        "reasoning_effort": item.get("reasoning_effort") or args.reasoning_effort,
        "error": error,
    }
    payload["result"] = terminal_result_payload(req_id, item, args, started, finished, status, error, result, returncode)
    payload.update(REQUEST_PROGRESS_CLEAR_FIELDS)
    fb_patch(f"{REQUESTS_PATH}/{req_id}", payload)
    fb_put(f"{RESULTS_PATH}/{req_id}", payload)
    log(f"{status} {req_id}: {error}")


def run_optional_adb_post_check(
    req_id: str,
    item: dict[str, Any],
    args: argparse.Namespace,
    run_result: dict[str, Any],
    started: int,
) -> dict[str, Any] | None:
    if not adb_check_requested(item):
        return None
    cwd_text = str(run_result.get("cwd") or request_cwd_value(item) or args.cwd or DEFAULT_CWD)
    cwd = Path(cwd_text).expanduser()
    profile = str(run_result.get("profile") or item.get("profile") or "")
    model = str(run_result.get("model") or item.get("model") or args.model)
    effort = str(run_result.get("reasoning_effort") or item.get("reasoning_effort") or args.reasoning_effort)
    timeout_sec = int(item.get("adb_timeout_sec") or item.get("timeout_sec") or args.timeout_sec)
    fb_patch(f"{REQUESTS_PATH}/{req_id}", {"status": "adb_testing"})
    publish_live_status(
        req_id,
        args,
        live_status_payload(
            req_id,
            item,
            cwd,
            str(run_result.get("requested_cwd") or request_cwd_value(item)),
            str(run_result.get("cwd_source") or ""),
            profile,
            model,
            effort,
            started,
            timeout_sec,
            "adb_testing",
            "Optional USB ADB post-check is running",
        ),
    )
    adb_result = run_adb_check(item, req_id)
    fb_patch(
        f"{REQUESTS_PATH}/{req_id}",
        {
            "adb_result": adb_result,
            "current_phase": "adb_testing_finished",
            "current_detail": str(adb_result.get("status") or ""),
        },
    )
    return adb_result


def is_kakao_direct_request(item: dict[str, Any]) -> bool:
    action = str(item.get("action") or item.get("mode") or "").strip()
    return action == "kakao_wake_check" or kakao_request_requested(item)


def is_storebottermux_direct_request(item: dict[str, Any]) -> bool:
    action = str(item.get("action") or item.get("mode") or "").strip()
    return action == "storebottermux_watchdog" or storebottermux_request_requested(item)


def is_posdelay_direct_request(item: dict[str, Any]) -> bool:
    action = str(item.get("action") or item.get("mode") or "").strip()
    return action == "posdelay_watchdog" or posdelay_request_requested(item)


def adb_direct_success(adb_result: dict[str, Any]) -> bool:
    if str(adb_result.get("status") or "") != "adb_done":
        return False
    checks = adb_result.get("checks") if isinstance(adb_result.get("checks"), dict) else {}
    install_check = checks.get("install") if isinstance(checks.get("install"), dict) else None
    if isinstance(install_check, dict) and install_check.get("status") == "failed":
        return False
    package_after_install = checks.get("package_after_install") if isinstance(checks.get("package_after_install"), dict) else {}
    if isinstance(install_check, dict) and package_after_install and not package_after_install.get("installed"):
        return False
    package_check = checks.get("package") if isinstance(checks.get("package"), dict) else {}
    if not install_check and package_check and not package_check.get("installed"):
        return False
    return True


def is_direct_probe_request(item: dict[str, Any]) -> bool:
    for key in ("action", "mode", "command", "request", "profile"):
        if str(item.get(key) or "").strip().lower() == DIRECT_PROBE_ACTION:
            return True
    return bool_field(item.get(DIRECT_PROBE_ACTION) or item.get("direct_probe_requested"))


def direct_probe_env_sample() -> dict[str, str]:
    keys = [
        "PATH",
        "HOME",
        "PWD",
        "SHELL",
        "USER",
        "PREFIX",
        "ANDROID_ROOT",
        "ANDROID_DATA",
        "PROOT_DISTRO",
        "CODEX_OPS_BASE_PATH",
        "CODEX_OPS_NODE",
        "CODEX_OPS_HOST",
    ]
    return {key: str(os.environ.get(key) or "") for key in keys if os.environ.get(key) is not None}


def run_direct_probe_request(
    req_id: str,
    item: dict[str, Any],
    args: argparse.Namespace,
    started: int,
    publish: bool = True,
) -> dict[str, Any]:
    requested_cwd_text = request_cwd_value(item) or args.cwd or DEFAULT_CWD
    fallback_cwd = args.cwd or DEFAULT_CWD
    requested_cwd = Path(requested_cwd_text).expanduser()
    cwd_source = "requested"
    cwd_notice = ""
    try:
        cwd, cwd_notice, cwd_source = resolve_cwd(
            requested_cwd,
            fallback_cwd,
            should_ignore_requested_cwd(requested_cwd_text, args),
        )
    except Exception as exc:
        cwd = requested_cwd
        cwd_source = "missing"
        cwd_notice = compact_error(str(exc), 500)
    profile = "read_only"
    model = str(item.get("model") or args.model or "").strip()
    effort = normalize_reasoning(item.get("reasoning_effort"), args.reasoning_effort)
    timeout_sec = max(1, min(30, int(item.get("direct_probe_timeout_sec") or item.get("probe_timeout_sec") or 5)))
    ensure_runtime_path()
    if publish:
        publish_live_status(
            req_id,
            args,
            live_status_payload(
                req_id,
                item,
                cwd,
                requested_cwd_text,
                cwd_source,
                profile,
                model,
                effort,
                started,
                timeout_sec,
                "direct_probe",
                "Worker direct readiness probe is collecting local process and repo state",
            ),
        )

    cwd_exists = cwd.exists() and cwd.is_dir()
    command_cwd = cwd if cwd_exists else None
    commands: dict[str, Any] = {
        "pwd": run_short_command(["pwd"], cwd=command_cwd, timeout=timeout_sec) if cwd_exists else {
            "command": "pwd",
            "returncode": 1,
            "stdout": "",
            "stderr": f"cwd missing: {cwd}",
            "stdout_len": 0,
            "stderr_len": len(str(cwd)),
            "duration_ms": 0,
        },
        "git_root": run_short_command(["git", "-C", str(cwd), "rev-parse", "--show-toplevel"], timeout=timeout_sec),
        "git_revision": run_short_command(["git", "-C", str(cwd), "rev-parse", "--short=12", "HEAD"], timeout=timeout_sec),
        "git_branch": run_short_command(["git", "-C", str(cwd), "rev-parse", "--abbrev-ref", "HEAD"], timeout=timeout_sec),
        "git_status_short": run_short_command(["git", "-C", str(cwd), "status", "--short"], timeout=timeout_sec),
        "python_version": run_short_command([sys.executable, "--version"], cwd=command_cwd, timeout=timeout_sec),
    }
    codex_preflight = codex_cli_preflight(command_cwd, timeout_sec=timeout_sec, cache_ttl_sec=0)
    commands["codex_version"] = codex_preflight.get("command_result") or {
        "command": "codex --version",
        "returncode": codex_preflight.get("codex_preflight_returncode") or 127,
        "stdout": "",
        "stderr": codex_preflight.get("codex_preflight_error") or "codex preflight failed",
        "stdout_len": 0,
        "stderr_len": len(str(codex_preflight.get("codex_preflight_error") or "")),
        "duration_ms": codex_preflight.get("codex_preflight_duration_ms") or 0,
    }
    git_info = git_snapshot(cwd)
    python_ok = commands["python_version"].get("returncode") == 0
    git_ok = commands["git_revision"].get("returncode") == 0
    codex_ok = bool(codex_preflight.get("codex_preflight_ok"))
    bundle_runtime_ok = bool(git_info.get("bundle_copy_ok"))
    if cwd_exists and python_ok and codex_ok and git_ok:
        probe_status = "ok"
    elif cwd_exists and python_ok and codex_ok and bundle_runtime_ok:
        probe_status = "ok_with_bundle_runtime"
    else:
        probe_status = "degraded"
    probe_ok = probe_status in {"ok", "ok_with_bundle_runtime"}
    revision_label = git_info.get("source_revision") or git_info.get("code_revision") or "unknown"
    summary = (
        f"direct_probe={probe_status} cwd={cwd} "
        f"runtime_mode={git_info.get('runtime_mode') or ''} "
        f"revision={revision_label} "
        f"bundle_version={git_info.get('bundle_version') or ''} "
        f"bundle_sha256={(git_info.get('bundle_sha256') or '')[:12]} "
        f"branch={git_info.get('git_branch') or ''} "
        f"git_available={'yes' if git_info.get('git_available') else 'no'} "
        f"dirty_count={git_info.get('dirty_count')} "
        f"codex_preflight={'ok' if codex_ok else 'failed'}"
    ).strip()
    finished = now_ms()
    result = {
        "probe_status": probe_status,
        "probe_ok": probe_ok,
        "summary": summary,
        "cwd_exists": cwd_exists,
        "cwd_notice": cwd_notice,
        "commands": commands,
        "git": git_info,
        "runtime": {
            "runtime_mode": git_info.get("runtime_mode") or "",
            "python_executable": sys.executable,
            "python_version": sys.version.split()[0],
            "codex_path": codex_preflight.get("codex_path") or "",
            "codex_preflight_ok": codex_ok,
            "codex_preflight_error": codex_preflight.get("codex_preflight_error") or "",
            "codex_version": codex_preflight.get("codex_version") or "",
            "git_available": bool(git_info.get("git_available")),
            "which_python3": shutil.which("python3") or "",
            "which_git": shutil.which("git") or "",
            "platform": sys.platform,
            "pid": os.getpid(),
        },
        "bundle": {
            "bundle_copy_ok": bool(git_info.get("bundle_copy_ok")),
            "bundle_metadata_present": bool(git_info.get("bundle_metadata_present")),
            "bundle_metadata_sources": git_info.get("bundle_metadata_sources") or [],
            "bundle_version": git_info.get("bundle_version") or "",
            "bundle_sha256": git_info.get("bundle_sha256") or "",
            "bundle_manifest_sha256": git_info.get("bundle_manifest_sha256") or "",
            "bundle_state_sha256": git_info.get("bundle_state_sha256") or "",
            "bundle_status": git_info.get("bundle_status") or "",
            "bundle_applied_at_ms": git_info.get("bundle_applied_at_ms") or 0,
            "bundle_manifest_url": git_info.get("bundle_manifest_url") or "",
            "source_revision": git_info.get("source_revision") or "",
            "required_helpers_present": git_info.get("required_helpers_present") or [],
            "required_helpers_missing": git_info.get("required_helpers_missing") or [],
        },
        "codex_preflight": {
            key: value for key, value in codex_preflight.items() if key != "command_result"
        },
        "env": direct_probe_env_sample(),
    }
    payload: dict[str, Any] = {
        "status": "done",
        "worker": args.node,
        "finished_at_ms": finished,
        "duration_ms": finished - started,
        "returncode": 0,
        "project": item.get("project") or "",
        "cwd": str(cwd),
        "requested_cwd": requested_cwd_text,
        "resolved_cwd": str(cwd),
        "cwd_source": cwd_source,
        "profile": profile,
        "model": model,
        "reasoning_effort": effort,
        "engine_requested": normalize_engine(item.get("engine") or getattr(args, "engine", "auto")),
        "engine_used": DIRECT_PROBE_ACTION,
        "engine_fallback_reason": "",
        "code_revision": git_info.get("code_revision") or "unknown",
        "source_revision": git_info.get("source_revision") or "",
        "runtime_mode": git_info.get("runtime_mode") or "",
        "git_available": bool(git_info.get("git_available")),
        "git_branch": git_info.get("git_branch") or "",
        "dirty_count": git_info.get("dirty_count"),
        "dirty_files_sample": git_info.get("dirty_files_sample") or [],
        "bundle_version": git_info.get("bundle_version") or "",
        "bundle_sha256": git_info.get("bundle_sha256") or "",
        "bundle_manifest_sha256": git_info.get("bundle_manifest_sha256") or "",
        "bundle_status": git_info.get("bundle_status") or "",
        "bundle_applied_at_ms": git_info.get("bundle_applied_at_ms") or 0,
        "required_helpers_present": git_info.get("required_helpers_present") or [],
        "required_helpers_missing": git_info.get("required_helpers_missing") or [],
        "codex_preflight_ok": codex_ok,
        "codex_preflight_error": codex_preflight.get("codex_preflight_error") or "",
        "codex_version": codex_preflight.get("codex_version") or "",
        "result": result,
        "error": "",
    }
    payload.update(REQUEST_PROGRESS_CLEAR_FIELDS)
    return payload


def run_adb_direct_request(
    req_id: str,
    item: dict[str, Any],
    args: argparse.Namespace,
    started: int,
) -> dict[str, Any]:
    cwd_text = request_cwd_value(item) or args.cwd or DEFAULT_CWD
    cwd = Path(cwd_text).expanduser()
    profile = normalize_profile(item.get("profile"))
    model = str(item.get("model") or args.model or "").strip()
    effort = normalize_reasoning(item.get("reasoning_effort"), args.reasoning_effort)
    timeout_sec = int(item.get("adb_timeout_sec") or item.get("timeout_sec") or args.timeout_sec)
    fb_patch(f"{REQUESTS_PATH}/{req_id}", {"status": "adb_testing"})
    publish_live_status(
        req_id,
        args,
        live_status_payload(
            req_id,
            item,
            cwd,
            cwd_text,
            "requested",
            profile,
            model,
            effort,
            started,
            timeout_sec,
            "adb_testing",
            "Direct USB ADB check/install helper is running",
        ),
    )
    if not adb_check_requested(item):
        adb_result = {"status": "adb_skipped", "enabled": False, "reason": "adb_check not enabled"}
    else:
        adb_result = run_adb_check(item, req_id)
    success = adb_direct_success(adb_result)
    status = "done" if success else "error"
    returncode = 0 if success else 1
    checks = adb_result.get("checks") if isinstance(adb_result.get("checks"), dict) else {}
    package_check = checks.get("package_after_install") if isinstance(checks.get("package_after_install"), dict) else {}
    if not package_check:
        package_check = checks.get("package") if isinstance(checks.get("package"), dict) else {}
    install_check = checks.get("install") if isinstance(checks.get("install"), dict) else {}
    version = package_check.get("version") if isinstance(package_check.get("version"), dict) else {}
    failed = adb_result.get("failed_checks") if isinstance(adb_result.get("failed_checks"), list) else []
    summary = (
        f"adb_result={adb_result.get('status') or ''} "
        f"serial={adb_result.get('serial') or ''} "
        f"adb_path={adb_result.get('adb_path') or ''} "
        f"install={install_check.get('status') or ''} "
        f"versionName={version.get('versionName') or ''} "
        f"versionCode={version.get('versionCode') or ''} "
        f"lastUpdateTime={version.get('lastUpdateTime') or ''} "
        f"failed={','.join(str(x) for x in failed)}"
    ).strip()
    error = "" if success else str(
        adb_result.get("reason")
        or install_check.get("output_tail")
        or adb_result.get("status")
        or "adb direct request failed"
    )
    finished = now_ms()
    payload: dict[str, Any] = {
        "status": status,
        "worker": args.node,
        "finished_at_ms": finished,
        "duration_ms": finished - started,
        "returncode": returncode,
        "project": item.get("project") or "",
        "cwd": cwd_text,
        "requested_cwd": cwd_text,
        "resolved_cwd": cwd_text,
        "cwd_source": "requested",
        "profile": profile,
        "model": model,
        "reasoning_effort": effort,
        "engine_requested": normalize_engine(item.get("engine") or getattr(args, "engine", "auto")),
        "engine_used": "adb_direct",
        "engine_fallback_reason": "",
        "adb_result": adb_result,
        "result": {"summary": summary, "adb_result": adb_result},
        "error": compact_error(error, 1200),
    }
    payload.update(REQUEST_PROGRESS_CLEAR_FIELDS)
    return payload


def run_storebottermux_direct_request(
    req_id: str,
    item: dict[str, Any],
    args: argparse.Namespace,
    started: int,
) -> dict[str, Any]:
    cwd_text = request_cwd_value(item) or args.cwd or DEFAULT_CWD
    cwd = Path(cwd_text).expanduser()
    profile = normalize_profile(item.get("profile"))
    model = str(item.get("model") or args.model or "").strip()
    effort = normalize_reasoning(item.get("reasoning_effort"), args.reasoning_effort)
    timeout_sec = int(item.get("storebottermux_timeout_sec") or item.get("adb_timeout_sec") or item.get("timeout_sec") or args.timeout_sec)
    fb_patch(f"{REQUESTS_PATH}/{req_id}", {"status": "storebottermux_testing"})
    publish_live_status(
        req_id,
        args,
        live_status_payload(
            req_id,
            item,
            cwd,
            cwd_text,
            "requested",
            profile,
            model,
            effort,
            started,
            timeout_sec,
            "storebottermux_testing",
            "StoreBotTermux reply pipeline USB ADB watchdog is running",
        ),
    )
    helper_item = dict(item)
    if not storebottermux_request_requested(helper_item):
        helper_item["storebottermux_check"] = True
        helper_item["storebottermux_wake"] = False
        helper_item["storebottermux_wake_mode"] = "check"
    storebottermux_result = run_storebottermux_watchdog(helper_item, req_id)
    returncode = storebottermux_exit_code_for_result(storebottermux_result)
    status = "done" if returncode == 0 else "error"
    health = storebottermux_result.get("health") if isinstance(storebottermux_result.get("health"), dict) else {}
    summary = (
        f"storebottermux_result={storebottermux_result.get('status')} "
        f"health={health.get('severity') or ''} "
        f"issues={','.join(health.get('issues') or []) if isinstance(health.get('issues'), list) else ''} "
        f"adb_path={storebottermux_result.get('adb_path') or ''} "
        f"serial={storebottermux_result.get('serial') or ''}"
    ).strip()
    error = "" if returncode == 0 else str(
        storebottermux_result.get("reason") or storebottermux_result.get("status") or "storebottermux watchdog failed"
    )
    finished = now_ms()
    payload: dict[str, Any] = {
        "status": status,
        "worker": args.node,
        "finished_at_ms": finished,
        "duration_ms": finished - started,
        "returncode": returncode,
        "project": item.get("project") or "",
        "cwd": cwd_text,
        "requested_cwd": cwd_text,
        "resolved_cwd": cwd_text,
        "cwd_source": "requested",
        "profile": profile,
        "model": model,
        "reasoning_effort": effort,
        "engine_requested": normalize_engine(item.get("engine") or getattr(args, "engine", "auto")),
        "engine_used": "storebottermux_watchdog",
        "engine_fallback_reason": "",
        "storebottermux_result": storebottermux_result,
        "result": {"summary": summary, "storebottermux_result": storebottermux_result},
        "error": error,
    }
    payload.update(REQUEST_PROGRESS_CLEAR_FIELDS)
    return payload


def run_posdelay_direct_request(
    req_id: str,
    item: dict[str, Any],
    args: argparse.Namespace,
    started: int,
) -> dict[str, Any]:
    cwd_text = request_cwd_value(item) or args.cwd or DEFAULT_CWD
    cwd = Path(cwd_text).expanduser()
    profile = normalize_profile(item.get("profile"))
    model = str(item.get("model") or args.model or "").strip()
    effort = normalize_reasoning(item.get("reasoning_effort"), args.reasoning_effort)
    timeout_sec = int(item.get("posdelay_timeout_sec") or item.get("adb_timeout_sec") or item.get("timeout_sec") or args.timeout_sec)
    fb_patch(f"{REQUESTS_PATH}/{req_id}", {"status": "posdelay_testing"})
    publish_live_status(
        req_id,
        args,
        live_status_payload(
            req_id,
            item,
            cwd,
            cwd_text,
            "requested",
            profile,
            model,
            effort,
            started,
            timeout_sec,
            "posdelay_testing",
            "PosDelay light USB ADB watchdog is running",
        ),
    )
    helper_item = dict(item)
    if not posdelay_request_requested(helper_item):
        helper_item["posdelay_check"] = True
        helper_item["posdelay_wake"] = False
        helper_item["posdelay_wake_mode"] = "check"
    posdelay_result = run_posdelay_watchdog(helper_item, req_id)
    returncode = posdelay_exit_code_for_result(posdelay_result)
    status = "done" if returncode == 0 else "error"
    health = posdelay_result.get("health") if isinstance(posdelay_result.get("health"), dict) else {}
    summary = (
        f"posdelay_result={posdelay_result.get('status')} "
        f"health={health.get('status') or health.get('severity') or ''} "
        f"issues={','.join(health.get('issues') or []) if isinstance(health.get('issues'), list) else ''} "
        f"adb_path={posdelay_result.get('adb_path') or ''} "
        f"serial={posdelay_result.get('serial') or ''} "
        f"foreground={posdelay_result.get('foreground_before_package') or ''}"
    ).strip()
    error = "" if returncode == 0 else str(
        posdelay_result.get("reason") or posdelay_result.get("status") or "posdelay watchdog failed"
    )
    finished = now_ms()
    payload: dict[str, Any] = {
        "status": status,
        "worker": args.node,
        "finished_at_ms": finished,
        "duration_ms": finished - started,
        "returncode": returncode,
        "project": item.get("project") or "",
        "cwd": cwd_text,
        "requested_cwd": cwd_text,
        "resolved_cwd": cwd_text,
        "cwd_source": "requested",
        "profile": profile,
        "model": model,
        "reasoning_effort": effort,
        "engine_requested": normalize_engine(item.get("engine") or getattr(args, "engine", "auto")),
        "engine_used": "posdelay_watchdog",
        "engine_fallback_reason": "",
        "posdelay_result": posdelay_result,
        "result": {"summary": summary, "posdelay_result": posdelay_result},
        "error": error,
    }
    payload.update(REQUEST_PROGRESS_CLEAR_FIELDS)
    return payload


def run_kakao_direct_request(
    req_id: str,
    item: dict[str, Any],
    args: argparse.Namespace,
    started: int,
) -> dict[str, Any]:
    cwd_text = request_cwd_value(item) or args.cwd or DEFAULT_CWD
    cwd = Path(cwd_text).expanduser()
    profile = normalize_profile(item.get("profile"))
    model = str(item.get("model") or args.model or "").strip()
    effort = normalize_reasoning(item.get("reasoning_effort"), args.reasoning_effort)
    timeout_sec = int(item.get("kakao_timeout_sec") or item.get("adb_timeout_sec") or item.get("timeout_sec") or args.timeout_sec)
    fb_patch(f"{REQUESTS_PATH}/{req_id}", {"status": "kakao_testing"})
    publish_live_status(
        req_id,
        args,
        live_status_payload(
            req_id,
            item,
            cwd,
            cwd_text,
            "requested",
            profile,
            model,
            effort,
            started,
            timeout_sec,
            "kakao_testing",
            "Safe KakaoTalk USB ADB check/wake helper is running",
        ),
    )
    helper_item = dict(item)
    if not kakao_request_requested(helper_item):
        helper_item["kakao_check"] = True
        helper_item["kakao_wake"] = False
        helper_item["kakao_wake_mode"] = "check"
    kakao_result = run_kakao_wake(helper_item, req_id)
    returncode = kakao_exit_code_for_result(kakao_result)
    status = "done" if returncode == 0 else "error"
    summary = (
        f"kakao_result={kakao_result.get('status')} "
        f"adb_path={kakao_result.get('adb_path') or ''} "
        f"serial={kakao_result.get('serial') or ''} "
        f"before={kakao_result.get('foreground_before_package') or ''} "
        f"after={kakao_result.get('foreground_after_package') or ''}"
    ).strip()
    error = "" if returncode == 0 else str(kakao_result.get("reason") or kakao_result.get("status") or "kakao helper failed")
    finished = now_ms()
    payload: dict[str, Any] = {
        "status": status,
        "worker": args.node,
        "finished_at_ms": finished,
        "duration_ms": finished - started,
        "returncode": returncode,
        "project": item.get("project") or "",
        "cwd": cwd_text,
        "requested_cwd": cwd_text,
        "resolved_cwd": cwd_text,
        "cwd_source": "requested",
        "profile": profile,
        "model": model,
        "reasoning_effort": effort,
        "engine_requested": normalize_engine(item.get("engine") or getattr(args, "engine", "auto")),
        "engine_used": "kakao_helper",
        "engine_fallback_reason": "",
        "kakao_result": kakao_result,
        "result": {"summary": summary, "kakao_result": kakao_result},
        "error": error,
    }
    payload.update(REQUEST_PROGRESS_CLEAR_FIELDS)
    return payload


def process_one(req_id: str, item: dict[str, Any], args: argparse.Namespace) -> bool:
    started = now_ms()
    locks = acquire_request_locks(req_id, item, args)
    if locks is None:
        log(f"locked {req_id}: waiting for active lock")
        return False
    try:
        claimed_item = claim_request(req_id, args, started)
        if not claimed_item:
            log(f"claim skipped {req_id}: no longer pending")
            return False
        if is_expired(claimed_item):
            mark_expired(req_id, claimed_item, args, started, "request ttl expired")
            return True
        stale_reason = stale_self_fix_reason(claimed_item)
        if stale_reason:
            mark_expired(req_id, claimed_item, args, started, stale_reason)
            return True
        if is_direct_probe_request(claimed_item):
            payload = run_direct_probe_request(req_id, claimed_item, args, started)
            fb_patch(f"{REQUESTS_PATH}/{req_id}", payload)
            fb_put(f"{RESULTS_PATH}/{req_id}", payload)
            result = payload.get("result") if isinstance(payload.get("result"), dict) else {}
            log(f"done {req_id} direct_probe={result.get('probe_status') or ''}")
            return True
        if is_adb_direct_request(claimed_item):
            payload = run_adb_direct_request(req_id, claimed_item, args, started)
            fb_patch(f"{REQUESTS_PATH}/{req_id}", payload)
            fb_put(f"{RESULTS_PATH}/{req_id}", payload)
            log(f"{payload['status']} {req_id} adb_result={payload['adb_result'].get('status')}")
            return True
        if is_posdelay_direct_request(claimed_item):
            payload = run_posdelay_direct_request(req_id, claimed_item, args, started)
            fb_patch(f"{REQUESTS_PATH}/{req_id}", payload)
            fb_put(f"{RESULTS_PATH}/{req_id}", payload)
            log(f"{payload['status']} {req_id} posdelay_result={payload['posdelay_result'].get('status')}")
            return True
        if is_storebottermux_direct_request(claimed_item):
            payload = run_storebottermux_direct_request(req_id, claimed_item, args, started)
            fb_patch(f"{REQUESTS_PATH}/{req_id}", payload)
            fb_put(f"{RESULTS_PATH}/{req_id}", payload)
            log(
                f"{payload['status']} {req_id} "
                f"storebottermux_result={payload['storebottermux_result'].get('status')}"
            )
            return True
        if is_kakao_direct_request(claimed_item):
            payload = run_kakao_direct_request(req_id, claimed_item, args, started)
            fb_patch(f"{REQUESTS_PATH}/{req_id}", payload)
            fb_put(f"{RESULTS_PATH}/{req_id}", payload)
            log(f"{payload['status']} {req_id} kakao_result={payload['kakao_result'].get('status')}")
            return True
        if is_resume_prompt_request(claimed_item):
            result = run_codex_resume_prompt_file(req_id, claimed_item, args, locks)
            adb_result = (
                run_optional_adb_post_check(req_id, claimed_item, args, result, started)
                if result.get("status") == "done"
                else None
            )
            finished = now_ms()
            payload = {
                "status": result["status"],
                "worker": args.node,
                "finished_at_ms": finished,
                "duration_ms": finished - started,
                "returncode": result["returncode"],
                "project": claimed_item.get("project") or "",
                "cwd": result["cwd"],
                "requested_cwd": result.get("requested_cwd") or "",
                "resolved_cwd": result["cwd"],
                "cwd_source": result.get("cwd_source") or "",
                "profile": result["profile"],
                "model": result["model"],
                "reasoning_effort": result["reasoning_effort"],
                "engine_requested": result.get("engine_requested") or normalize_engine(claimed_item.get("engine") or getattr(args, "engine", "auto")),
                "engine_used": result.get("engine_used") or "exec",
                "engine_fallback_reason": result.get("engine_fallback_reason") or "",
                "result": terminal_result_payload(
                    req_id,
                    claimed_item,
                    args,
                    started,
                    finished,
                    result["status"],
                    result.get("error") or "",
                    result["result"],
                    result["returncode"],
                ),
                "error": result.get("error") or "",
            }
            if result.get("sdk_probe"):
                payload["sdk_probe"] = result.get("sdk_probe")
            if result.get("codex_preflight"):
                payload["codex_preflight"] = result.get("codex_preflight")
            if adb_result is not None:
                payload["adb_result"] = adb_result
                if isinstance(payload["result"], dict):
                    payload["result"]["adb_result"] = adb_result
            payload.update(REQUEST_PROGRESS_CLEAR_FIELDS)
            fb_patch(f"{REQUESTS_PATH}/{req_id}", payload)
            fb_put(f"{RESULTS_PATH}/{req_id}", payload)
            log(f"{result['status']} {req_id}")
            return True
        result = run_codex_task(req_id, claimed_item, args)
        adb_result = run_optional_adb_post_check(req_id, claimed_item, args, result, started)
        finished = now_ms()
        terminal_status = "rejected" if result.get("token_budget_exceeded") is True else "done"
        terminal_error = (
            "actual token usage exceeded bounded reservation"
            if terminal_status == "rejected"
            else ""
        )
        terminal_details = {
            "summary": result["summary"],
            "output_len": result["output_len"],
            "engine_used": result.get("engine_used") or "exec",
        }
        if result.get("bounded_automation") is True:
            terminal_details.update(
                {
                    "actual_token_usage": result.get("actual_token_usage"),
                    "token_usage": result.get("token_usage"),
                    "token_budget_exceeded": result.get("token_budget_exceeded") is True,
                }
            )
        payload = {
            "status": terminal_status,
            "worker": args.node,
            "finished_at_ms": finished,
            "duration_ms": finished - started,
            "returncode": 0 if terminal_status == "done" else 2,
            "project": claimed_item.get("project") or "",
            "cwd": result["cwd"],
            "requested_cwd": result.get("requested_cwd") or "",
            "resolved_cwd": result["cwd"],
            "cwd_source": result.get("cwd_source") or "",
            "profile": result["profile"],
            "model": result["model"],
            "reasoning_effort": result["reasoning_effort"],
            "engine_requested": result.get("engine_requested") or normalize_engine(claimed_item.get("engine") or getattr(args, "engine", "auto")),
            "engine_used": result.get("engine_used") or "exec",
            "engine_fallback_reason": result.get("engine_fallback_reason") or "",
            "result": terminal_result_payload(
                req_id,
                claimed_item,
                args,
                started,
                finished,
                terminal_status,
                terminal_error,
                terminal_details,
                0 if terminal_status == "done" else 2,
            ),
            "error": terminal_error,
        }
        if result.get("sdk_probe"):
            payload["sdk_probe"] = result.get("sdk_probe")
        if result.get("codex_preflight"):
            payload["codex_preflight"] = result.get("codex_preflight")
        if adb_result is not None:
            payload["adb_result"] = adb_result
            payload["result"]["adb_result"] = adb_result
        payload.update(REQUEST_PROGRESS_CLEAR_FIELDS)
        fb_patch(f"{REQUESTS_PATH}/{req_id}", payload)
        fb_put(f"{RESULTS_PATH}/{req_id}", payload)
        log(f"{terminal_status} {req_id}")
        return True
    except CodexPreflightError as exc:
        error = compact_error(str(exc), 1200)
        preflight = {key: value for key, value in exc.preflight.items() if key != "command_result"}
        mark_error(
            req_id,
            item,
            args,
            started,
            error,
            result={"summary": error, "codex_preflight": preflight},
            returncode=int(exc.preflight.get("codex_preflight_returncode") or 1),
        )
        return True
    except subprocess.TimeoutExpired as exc:
        timeout_sec = int(item.get("timeout_sec") or args.timeout_sec)
        stdout_tail = capped_text(decode_stream(getattr(exc, "output", "")), 4000)
        stderr_tail = capped_text(decode_stream(getattr(exc, "stderr", "")), 4000)
        error = f"codex ops timeout after {timeout_sec}s"
        result: dict[str, Any] = {
            "summary": error,
            "timeout_sec": timeout_sec,
            "engine_used": "exec",
        }
        if stdout_tail:
            result["stdout_tail"] = stdout_tail
        if stderr_tail:
            result["stderr_tail"] = stderr_tail
        mark_error(
            req_id,
            item,
            args,
            started,
            error,
            status="failed_timeout",
            result=result,
            returncode=-9,
        )
        return True
    except OpsError as exc:
        error = compact_error(str(exc), 1200)
        status = "rejected" if "requires is_owner=true" in error else "error"
        mark_error(req_id, item, args, started, error, status=status)
        return True
    except Exception as exc:
        mark_error(req_id, item, args, started, compact_error(str(exc), 1200))
        return True
    finally:
        release_locks(locks)
        _LAST_LIVE_STATUS_BY_REQ.pop(req_id, None)


def write_heartbeat(
    args: argparse.Namespace,
    pending: int,
    status: str,
    current_request: str = "",
    current_started_at_ms: int = 0,
    last_error: str = "",
    extra: dict[str, Any] | None = None,
) -> None:
    git_info = git_snapshot(getattr(args, "cwd", DEFAULT_CWD))
    codex_preflight = codex_cli_preflight(
        Path(str(getattr(args, "cwd", DEFAULT_CWD) or DEFAULT_CWD)).expanduser(),
        timeout_sec=int(getattr(args, "codex_preflight_timeout_sec", DEFAULT_CODEX_PREFLIGHT_TIMEOUT_SEC) or DEFAULT_CODEX_PREFLIGHT_TIMEOUT_SEC),
        cache_ttl_sec=int(getattr(args, "codex_preflight_cache_sec", DEFAULT_CODEX_PREFLIGHT_CACHE_SEC) or 0),
    )
    hook_policy = codex_preflight.get("hook_policy") if isinstance(codex_preflight.get("hook_policy"), dict) else {}
    managed_hook = hook_policy.get("managed") if isinstance(hook_policy.get("managed"), dict) else {}
    expected_hook = managed_hook.get("expected") if isinstance(managed_hook.get("expected"), dict) else {}
    payload: dict[str, Any] = {
        "node": args.node,
        "host": args.host,
        "status": status,
        "pending": pending,
        "ts": now_ms(),
        "pid": os.getpid(),
        "cwd": args.cwd,
        "model": args.model,
        "supported_models": [args.model],
        "reasoning_effort": args.reasoning_effort,
        "supported_reasoning_efforts": sorted(ALLOWED_REASONING),
        "engine": getattr(args, "engine", "auto"),
        "worker_started_at_ms": args.worker_started_at_ms,
        "code_revision": git_info.get("code_revision") or getattr(args, "code_revision", "") or "unknown",
        "source_revision": git_info.get("source_revision") or "",
        "runtime_mode": git_info.get("runtime_mode") or "",
        "git_available": bool(git_info.get("git_available")),
        "git_branch": git_info.get("git_branch") or getattr(args, "git_branch", "") or "",
        "dirty_count": git_info.get("dirty_count", getattr(args, "dirty_count", -1)),
        "dirty_files_sample": git_info.get("dirty_files_sample") or getattr(args, "dirty_files_sample", []),
        "bundle_version": git_info.get("bundle_version") or "",
        "bundle_sha256": git_info.get("bundle_sha256") or "",
        "bundle_manifest_sha256": git_info.get("bundle_manifest_sha256") or "",
        "bundle_status": git_info.get("bundle_status") or "",
        "bundle_applied_at_ms": git_info.get("bundle_applied_at_ms") or 0,
        "required_helpers_present": git_info.get("required_helpers_present") or [],
        "required_helpers_missing": git_info.get("required_helpers_missing") or [],
        "script_mtime_ms": args.script_mtime_ms,
        "codex_available": bool(codex_preflight.get("codex_preflight_ok")),
        "codex_path": codex_preflight.get("codex_path") or "",
        "codex_path_present": bool(codex_preflight.get("codex_path_present")),
        "codex_preflight_ok": bool(codex_preflight.get("codex_preflight_ok")),
        "codex_preflight_error": codex_preflight.get("codex_preflight_error") or "",
        "codex_version": codex_preflight.get("codex_version") or "",
        "codex_preflight_returncode": codex_preflight.get("codex_preflight_returncode"),
        "codex_preflight_duration_ms": codex_preflight.get("codex_preflight_duration_ms"),
        "codex_preflight_checked_at_ms": codex_preflight.get("codex_preflight_checked_at_ms"),
        "hook_policy_status": hook_policy.get("status") or "unknown",
        "hook_policy_compatible": hook_policy.get("compatible") is True,
        "hook_policy_version": expected_hook.get("policy_version") or "",
        "hook_policy_source_sha256": expected_hook.get("sha256") or "",
        "hook_policy_installed_sha256": managed_hook.get("installed_sha256") or "",
        "hook_policy_managed_status": managed_hook.get("status") or "unknown",
        "hook_policy_legacy_risk_count": len(hook_policy.get("legacy_inheritance_risk") or []),
        "hook_policy_active_mutation_performed": hook_policy.get("active_mutation_performed") is True,
    }
    if git_info.get("git_status_error"):
        payload["git_status_error"] = git_info.get("git_status_error")
    if current_request:
        payload["current_request"] = current_request
        payload["current_started_at_ms"] = current_started_at_ms
        payload["current_elapsed_ms"] = max(0, now_ms() - current_started_at_ms)
    if last_error:
        payload["last_error"] = last_error
    elif status != "error":
        payload["last_error"] = ""
    if extra:
        payload.update(extra)
    fb_put(f"{HEARTBEAT_PATH}/{sanitize_key(args.node)}", payload)


def run_once(args: argparse.Namespace) -> int:
    cleanup_orphaned_running(args)
    pending = load_pending(args.scan_limit, args)
    write_heartbeat(args, len(pending), "idle" if not pending else "processing")
    if args.dry_run:
        for req_id, item in pending:
            log(
                "pending "
                f"{req_id} action={item.get('action') or item.get('mode') or ''} "
                f"session_id={item.get('session_id') or ''} profile={item.get('profile')} cwd={request_cwd_value(item)} "
                f"target_host={item.get('target_host') or ''} target_node={item.get('target_node') or ''}"
            )
        return len(pending)
    processed = 0
    for req_id, item in pending:
        if processed >= args.limit:
            break
        if process_one(req_id, item, args):
            processed += 1
    remaining_hint = max(0, len(pending) - processed)
    write_heartbeat(args, remaining_hint, "idle")
    return processed


def parse_args(argv: list[str]) -> argparse.Namespace:
    parser = argparse.ArgumentParser(description="서버폰 Termux Codex ops worker")
    parser.add_argument("--watch", action="store_true")
    parser.add_argument("--once", action="store_true")
    parser.add_argument("--dry-run", action="store_true")
    parser.add_argument("--poll-sec", type=float, default=float(os.environ.get("CODEX_OPS_POLL_SEC", "10")))
    parser.add_argument("--limit", type=int, default=int(os.environ.get("CODEX_OPS_LIMIT", "1")))
    parser.add_argument("--scan-limit", type=int, default=int(os.environ.get("CODEX_OPS_SCAN_LIMIT", "20")))
    parser.add_argument("--timeout-sec", type=int, default=int(os.environ.get("CODEX_OPS_TIMEOUT_SEC", "1200")))
    parser.add_argument("--active-heartbeat-sec", type=int, default=int(os.environ.get("CODEX_OPS_ACTIVE_HEARTBEAT_SEC", "60")))
    parser.add_argument(
        "--codex-preflight-timeout-sec",
        type=int,
        default=int(os.environ.get("CODEX_OPS_PREFLIGHT_TIMEOUT_SEC", str(DEFAULT_CODEX_PREFLIGHT_TIMEOUT_SEC))),
    )
    parser.add_argument(
        "--codex-preflight-cache-sec",
        type=int,
        default=int(os.environ.get("CODEX_OPS_PREFLIGHT_CACHE_SEC", str(DEFAULT_CODEX_PREFLIGHT_CACHE_SEC))),
    )
    parser.add_argument("--orphan-running-min", type=int, default=int(os.environ.get("CODEX_OPS_ORPHAN_RUNNING_MIN", "90")))
    parser.add_argument("--orphan-requeue-limit", type=int, default=int(os.environ.get("CODEX_OPS_ORPHAN_REQUEUE_LIMIT", "1")))
    parser.add_argument(
        "--orphan-child-grace-sec",
        type=int,
        default=int(os.environ.get("CODEX_OPS_ORPHAN_CHILD_GRACE_SEC", str(DEFAULT_ORPHAN_CHILD_GRACE_SEC))),
    )
    parser.add_argument("--lock-ttl-sec", type=int, default=int(os.environ.get("CODEX_OPS_LOCK_TTL_SEC", str(DEFAULT_LOCK_TTL_SEC))))
    parser.add_argument("--global-lock", action="store_true", default=os.environ.get("CODEX_OPS_GLOBAL_LOCK", "0") == "1")
    parser.add_argument("--cwd", default=os.environ.get("CODEX_OPS_CWD", DEFAULT_CWD))
    parser.add_argument("--model", default=os.environ.get("CODEX_OPS_MODEL", "gpt-5.5"))
    parser.add_argument("--reasoning-effort", default=os.environ.get("CODEX_OPS_REASONING_EFFORT", "xhigh"))
    parser.add_argument("--engine", choices=["auto", "sdk", "exec"], default=os.environ.get("CODEX_OPS_ENGINE", "auto"))
    parser.add_argument("--host", choices=["subphone", "pc"], default=os.environ.get("CODEX_OPS_HOST", "subphone"))
    parser.add_argument("--node", default=os.environ.get("CODEX_OPS_NODE", "subphone_termux_ops"))
    parser.add_argument("--direct-probe-dry-run", action="store_true", help="Firebase 없이 로컬 direct_probe payload를 출력")
    args = parser.parse_args(argv)
    args.host = normalize_target_host(args.host, "subphone")
    args.reasoning_effort = normalize_reasoning(args.reasoning_effort, "xhigh")
    args.engine = normalize_engine(args.engine)
    args.limit = max(1, int(args.limit))
    args.scan_limit = max(args.limit, int(args.scan_limit))
    args.lock_ttl_sec = max(60, int(args.lock_ttl_sec))
    args.codex_preflight_timeout_sec = max(1, min(30, int(args.codex_preflight_timeout_sec)))
    args.codex_preflight_cache_sec = max(0, int(args.codex_preflight_cache_sec))
    args.orphan_child_grace_sec = max(1, int(args.orphan_child_grace_sec))
    args.worker_started_at_ms = now_ms()
    git_info = git_snapshot(args.cwd)
    args.code_revision = git_info.get("code_revision") or current_git_revision(args.cwd)
    args.git_branch = git_info.get("git_branch") or ""
    args.dirty_count = git_info.get("dirty_count", -1)
    args.dirty_files_sample = git_info.get("dirty_files_sample") or []
    args.script_mtime_ms = file_mtime_ms(__file__)
    if not args.watch and not args.once and not args.direct_probe_dry_run:
        args.once = True
    return args


def main(argv: list[str]) -> int:
    if argv == ["--print-hook-argv-contract"]:
        print(json.dumps(hook_argv_contract_payload(), ensure_ascii=False, sort_keys=True))
        return 0
    args = parse_args(argv)
    if args.direct_probe_dry_run:
        item = {
            "action": DIRECT_PROBE_ACTION,
            "mode": DIRECT_PROBE_ACTION,
            "direct_probe": True,
            "cwd": args.cwd,
            "project": Path(args.cwd).expanduser().name or "my-first-project",
            "profile": "read_only",
            "created_at_ms": now_ms(),
        }
        payload = run_direct_probe_request("local_direct_probe", item, args, now_ms(), publish=False)
        print(json.dumps(payload, ensure_ascii=False, indent=2, sort_keys=True))
        return 0 if payload.get("status") == "done" else 1
    if args.watch:
        while True:
            try:
                run_once(args)
            except Exception as exc:
                error = compact_error(str(exc), 500)
                log(f"loop error: {error}")
                try:
                    write_heartbeat(args, 0, "error", last_error=error)
                except Exception:
                    pass
            time.sleep(args.poll_sec)
    return run_once(args)


if __name__ == "__main__":
    raise SystemExit(main(sys.argv[1:]))
