<!-- source: /root/AppUpdateCenter/APP_INTENT.md -->
# AppUpdateCenter APP_INTENT.md

## 만든 이유
- 여러 Android 앱의 업데이트 상태를 한 화면에서 확인하고, 앱이 먹통이어도 최신 APK 설치 화면까지 열 수 있게 한다.

## 사용자 결과
- 각 앱의 현재 설치 버전과 서버 최신 버전을 비교해 `최신/업데이트 가능/미설치/채널 없음`을 바로 본다.
- 서버 APK가 있으면 앱별 다운로드 후 Android 설치 승인 화면을 연다.
- 다운로드된 APK는 하루가 지나면 자동 삭제해 저장공간이 쌓이지 않게 한다.
- 최신 상태여도 재설치 버튼은 살아 있어야 한다. 앱이 꼬였을 때 같은 버전을 다시 설치할 수 있어야 한다.
- 신규 앱은 업데이트센터 APK를 다시 빌드하지 않고 Hosting의 `update-center/catalog.json`에 추가하면 목록에 들어온다.
- 폰마다 필요 없는 앱은 해당 기기의 메인 목록에서 숨기고 `숨긴 앱 관리`에서 복원한다. 다른 폰과 공통 catalog에는 영향을 주지 않는다.
- 첫 화면에는 remote catalog 순서를 반영하고 업데이트·설치·직접다운로드가 필요한 앱을 우선 배치한다. 목록 출처와 전체/화면/숨김 개수를 항상 보여준다.

## 절대 기준
- 앱별 내부 업데이트 버튼에만 의존하지 않는다.
- 무인 silent install은 시도하지 않는다. Android 정책상 사용자 설치 승인을 전제로 한다.
- 앱 전용 다운로드 폴더의 APK만 자동 정리한다. 사용자의 공용 다운로드 파일은 건드리지 않는다.
- 서버 manifest 스키마는 공통으로 유지한다: `appVersionCode`, `appVersionName`, `apkUrl`, `sha256`, `enabled`, `releaseNotes`, `updatedAt`.
- manifest가 없는 프로젝트도 목록에서 숨기지 않고 `채널 없음`으로 표시한다.
- 버튼 비활성화로 막지 않는다. 채널 없음/확인 전 상태에서도 버튼은 다시 확인을 수행한다.
- manifest 조회가 실패해도 GitHub rolling release의 앱별 `*_latest.bin` exact URL로 다운로드/재설치할 수 있어야 한다.
- 앱 내부 다운로드가 실패하면 같은 앱의 GitHub Pages metadata 안내 화면을 열어 서브폰에서도 수동 복구 동선을 유지한다.
- StoreBot 운영앱은 `StoreBotTermux`(`com.sbotux`)만 catalog에 둔다. 퇴역 `StoreBot`과 NotallyX는 기존 APK를 삭제하지 않되 remote/내장 catalog에서 제외한다.
- catalog와 version metadata는 `https://wk7007-wk.github.io/bbq-dashboard/updates` exact origin만 읽고, catalog는 `id/label/apkName/packages/enabled` 최소 필드만 허용한다.
- APK는 `https://github.com/wk7007-wk/bbq-dashboard/releases/download/app-updates/{catalog apkName}`만 요청한다. cache-bust는 양의 versionCode `v` query만 허용하고, 1회 redirect는 HTTPS `release-assets.githubusercontent.com`의 release asset 경로만 허용한다.
- 다운로드 후 manifest SHA/size/package/certificate와 설치본 signing lineage를 검증하고 불일치 APK는 삭제한 뒤 설치 화면을 열지 않는다.
- remote catalog가 없거나 timeout/크기/schema 검증에 실패하면 내장 catalog로 복귀한다. WebView, JavaScript bridge, cleartext URL, 임의 download origin은 쓰지 않는다.
- catalog/manifest/latest APK 요청은 클라이언트 캐시를 사용하지 않고 `no-cache` 재검증한다. 새 목록과 새 버전이 이전 캐시에 묻히면 안 된다.
- 설치 앱 검색은 명시 package query와 `MAIN/LAUNCHER` intent query를 함께 쓰며 `QUERY_ALL_PACKAGES`는 쓰지 않는다.
- `업데이트 센터` 항목과 `숨긴 앱 관리` 진입점은 숨길 수 없다.
- `전체 목록`은 업데이트 필터를 즉시 해제하고, `숨긴 앱 관리 > 모두 복원`은 해당 기기의 숨김 설정을 초기화한다.

## C&I / AI Ops 경계
- C&I는 manifest 누락, SHA 불일치, 다운로드 실패, 설치 인텐트 실패, 업데이트센터 배포 누락을 감지해 self_fix prompt를 만들 수 있다.
- 자동 복구는 앱별 deploy 스크립트, `version.json`, `*_latest.bin`, 문서 포인터 보정까지 허용한다.
- 무인 silent install, 사용자 공용 다운로드 삭제, manifest schema 임의 변경은 금지한다.
- CLI/LLM은 prompt envelope가 있어야 깨어난다. monitor/worker/사용자/수동 enqueue 또는 상주 판단 루프가 prompt를 주입하며, 이것은 C&I 판단 권한 제한이 아니다.

## 완료 기준
- 설치된 패키지 versionCode와 서버 versionCode 비교가 된다.
- APK 다운로드, SHA-256 검증, 설치 화면 열기가 된다.
- debug APK를 `/sdcard/Download`에 전달하고 앱 자체 업데이트 채널에도 배포한다.
