#!/usr/bin/env python3
"""Fail closed before diagnostic payloads cross a persistence boundary."""

from __future__ import annotations

import math
import re
from typing import Any


_RAW_PII_KEYS = {
    "address",
    "address_text",
    "chat_message",
    "chat_text",
    "common_entrance",
    "common_entrance_password",
    "door_code",
    "door_password",
    "entrance_code",
    "entrance_password",
    "from",
    "gate_password",
    "jibun_address",
    "message",
    "message_preview",
    "message_text",
    "messages",
    "passcode",
    "passwd",
    "password",
    "password_text",
    "phone",
    "phone_number",
    "raw_chat",
    "raw_message",
    "raw_text",
    "reply_text",
    "road_address",
    "room",
    "room_id",
    "room_name",
    "room_title",
    "sender",
    "sender_label",
    "sender_label_redacted",
    "sender_name",
    "telephone",
    "공동현관",
    "공동현관_비밀번호",
    "공동현관비밀번호",
}

_RAW_PII_SUFFIXES = (
    "_address",
    "_address_text",
    "_chat_message",
    "_chat_text",
    "_claim_preview",
    "_common_entrance",
    "_common_entrance_password",
    "_door_code",
    "_door_password",
    "_entrance_code",
    "_entrance_password",
    "_gate_password",
    "_jibun_address",
    "_message",
    "_message_preview",
    "_message_text",
    "_messages",
    "_passcode",
    "_password",
    "_password_text",
    "_phone",
    "_phone_number",
    "_preview",
    "_raw_chat",
    "_raw_message",
    "_raw_text",
    "_reply_text",
    "_road_address",
    "_room",
    "_room_id",
    "_room_name",
    "_room_title",
    "_scan_preview",
    "_sender",
    "_sender_label",
    "_sender_label_redacted",
    "_sender_name",
    "_telephone",
    "_공동현관",
    "_공동현관_비밀번호",
    "_공동현관비밀번호",
)

_SENSITIVE_HASH_TOKENS = {
    "address",
    "chat",
    "door",
    "entrance",
    "message",
    "password",
    "phone",
    "raw",
    "reply",
    "room",
    "sender",
    "telephone",
}
_HASH_SUFFIXES = {"digest", "fingerprint", "hash", "md5", "sha", "sha1", "sha256"}

# These fields conventionally carry uncontrolled prose. Diagnostic decisions must
# instead survive as structured code/source/stage/status/reason_code fields.
_UNCONTROLLED_NARRATIVE_KEYS = {
    "body",
    "content",
    "description",
    "detail",
    "error",
    "errors",
    "exception",
    "exceptions",
    "log",
    "logs",
    "message",
    "messages",
    "note",
    "notes",
    "prompt",
    "reason",
    "stderr",
    "stderr_tail",
    "stdout",
    "stdout_tail",
    "summary",
    "text",
    "traceback",
}
_UNCONTROLLED_NARRATIVE_SUFFIXES = (
    "_body",
    "_content",
    "_description",
    "_detail",
    "_error",
    "_exception",
    "_log",
    "_message",
    "_note",
    "_prompt",
    "_reason",
    "_stderr",
    "_stderr_tail",
    "_stdout",
    "_stdout_tail",
    "_summary",
    "_text",
    "_traceback",
)

# Persisted diagnostics are a deliberately small read model. Unknown fields are
# dropped; a value being JSON serializable is not enough to make it safe. These
# containers may hold only fields that pass the scalar rules below.
_SAFE_CONTAINER_KEYS = {
    "actions",
    "bundle_sync_checks",
    "ca_projection_input",
    "ca_recovery_transitions",
    "checks",
    "consistency_checks",
    "data_quality_checks",
    "details",
    "detected_error_issue_codes",
    "detected_issue_codes",
    "error_issue_codes",
    "events",
    "evidence",
    "heartbeats",
    "issue_codes",
    "issues",
    "kakao_reply_flows",
    "local_json_checks",
    "metric_checks",
    "metrics",
    "pre_self_heal",
    "projects",
    "queues",
    "records",
    "recovery_clear",
    "reply_target",
    "results",
    "runtime_issues",
    "self_fix",
    "self_fix_results",
    "single_requests",
    "stage_order",
    "stages",
    "status_checks",
    "storebot_watchdog",
    "targets",
}
_SAFE_DYNAMIC_MAP_KEYS = {"projects", "self_fix_results", "stages", "targets"}
_SAFE_DYNAMIC_MAP_VALUES = {
    "projects": {"BankTotal", "CoreOps", "DeliveryHelper", "MainPC", "OrderHelper", "PosDelay", "SolNote", "StoreBot"},
    "self_fix_results": {"BankTotal", "CoreOps", "DeliveryHelper", "MainPC", "OrderHelper", "PosDelay", "SolNote", "StoreBot"},
    "stages": {
        "ack",
        "image_build",
        "kakao_send",
        "outbound_publish",
        "phone_receive",
        "realtime_data",
        "schedule_fire",
        "worker_pickup",
    },
    "targets": {
        "address_book_runner",
        "factory_pc",
        "legacy_ai_factory_home_pc",
        "legacy_subphone_posdelay",
        "map_knowledge_runner",
        "storebot_codex_worker",
        "storebot_termux_transport",
        "subphone_posdelay",
    },
}
_SAFE_TOKEN_LIST_KEYS = {
    "actions",
    "ca_recovery_transitions",
    "detected_error_issue_codes",
    "detected_issue_codes",
    "error_issue_codes",
    "issue_codes",
    "runtime_issues",
    "stage_order",
}

_SAFE_ENUM_KEYS = {
    "action",
    "category",
    "code",
    "content_variant",
    "contract",
    "domain",
    "event",
    "exception_type",
    "health",
    "heartbeat_source",
    "issue",
    "kind",
    "last_action_issue",
    "last_transport",
    "method",
    "mode",
    "model",
    "name",
    "node",
    "operation",
    "output_category",
    "profile",
    "project",
    "reason_code",
    "reasoning_effort",
    "recovery_action",
    "repair_scope",
    "request_status",
    "requester",
    "resolution",
    "role",
    "route",
    "route_stage",
    "safety_boundary",
    "severity",
    "source",
    "stage",
    "state",
    "status",
    "stage_result",
    "summary_code",
    "target_host",
    "target_node",
    "transport",
    "transition",
    "type",
}
_SAFE_ENUM_KEY_SUFFIXES = (
    "_action",
    "_category",
    "_code",
    "_health",
    "_issue",
    "_kind",
    "_mode",
    "_profile",
    "_reason_code",
    "_resolution",
    "_role",
    "_route",
    "_severity",
    "_source",
    "_stage",
    "_state",
    "_status",
    "_transport",
    "_type",
)
_SAFE_IDENTIFIER_KEYS = {
    "issue_key",
    "monitor_issue_key",
    "outbound_key",
    "private_task_ref",
    "request_id",
    "selected_capability_id",
}
_SAFE_IDENTIFIER_KEY_SUFFIXES = ("_id", "_key")
_SAFE_PATH_KEYS = {"cwd", "evidence_pointer", "monitor_path", "path", "report_path"}
_SAFE_PATH_KEY_SUFFIXES = ("_cwd", "_path", "_pointer")
_SAFE_VERSION_KEYS = {"code_revision", "package_name", "version", "version_name"}
_SAFE_VERSION_KEY_SUFFIXES = ("_package_name", "_revision", "_version", "_version_name")
_SAFE_TIMESTAMP_TEXT_KEYS = {"checked_at", "checked_at_kst", "created_at_kst", "finished_at_kst", "updated_at_kst"}

_SAFE_NUMERIC_KEYS = {
    "age",
    "attempts",
    "battery_level",
    "count",
    "depth",
    "elapsed",
    "exit_code",
    "http_status",
    "length",
    "limit",
    "offset",
    "pid",
    "port",
    "progress",
    "ratio",
    "returncode",
    "retries",
    "score",
    "size",
    "temperature",
    "threshold",
    "timestamp",
    "ts",
    "version_code",
}
_SAFE_NUMERIC_KEY_SUFFIXES = (
    "_age",
    "_attempts",
    "_bytes",
    "_c",
    "_count",
    "_depth",
    "_duration",
    "_elapsed",
    "_len",
    "_length",
    "_limit",
    "_min",
    "_minutes",
    "_ms",
    "_offset",
    "_percent",
    "_pid",
    "_port",
    "_progress",
    "_ratio",
    "_retries",
    "_retry_count",
    "_score",
    "_sec",
    "_seconds",
    "_size",
    "_temperature",
    "_threshold",
    "_timestamp",
    "_ts",
    "_unsent",
    "_version_code",
)
_SAFE_BOOL_KEYS = {
    "active",
    "alive",
    "diagnostic_enqueued",
    "delivery_acked",
    "enabled",
    "fallback",
    "found",
    "fresh",
    "hash_pending",
    "kakao_publish",
    "local_recovery",
    "ok",
    "present",
    "recovery_paused",
    "recent",
    "recovered",
    "redacted",
    "required",
    "resident_session_preboot_ready",
    "screen_scan_source",
    "self_fix_enqueued",
    "skipped",
    "supported",
    "request_terminal",
    "outbound_sent",
    "outbound_image_sent",
    "ca_projection_input_ready",
}
_SAFE_BOOL_KEY_PREFIXES = ("bypass_", "can_", "has_", "is_", "must_", "no_", "should_")
_SAFE_BOOL_KEY_SUFFIXES = (
    "_active",
    "_allowed",
    "_available",
    "_capable",
    "_deferred",
    "_disabled",
    "_enabled",
    "_fallback",
    "_found",
    "_fresh",
    "_healthy",
    "_listening",
    "_noise",
    "_ok",
    "_present",
    "_published",
    "_required",
    "_skipped",
    "_stale",
    "_success",
    "_valid",
)

_SAFE_TOKEN_RE = re.compile(r"^[A-Za-z][A-Za-z0-9_.:/+-]{0,191}$")
_SAFE_IDENTIFIER_RE = re.compile(r"^(?=[A-Za-z0-9_.:+/-]{1,256}$)(?=.*[A-Za-z])[A-Za-z0-9_.:+/-]+$")
_SAFE_VERSION_RE = re.compile(r"^[A-Za-z0-9][A-Za-z0-9_.+-]{0,127}$")
_SAFE_PATH_RE = re.compile(r"^(?:/[A-Za-z0-9._~:/-]*|[A-Za-z]:\\[A-Za-z0-9._~:\\/-]*)$")
_SAFE_KST_RE = re.compile(r"^\d{4}-\d{2}-\d{2} \d{2}:\d{2}:\d{2} KST$")
_SAFE_UTC_ISO_RE = re.compile(r"^\d{4}-\d{2}-\d{2}T\d{2}:\d{2}:\d{2}(?:\.\d{1,6})?(?:Z|\+00:00)$")
_PHONE_VALUE_RE = re.compile(
    r"(?<!\d)(?:01[016789][ -]?\d{3,4}[ -]?\d{4}|0\d{1,2}[ -]?\d{3,4}[ -]?\d{4})(?!\d)"
)
_CREDENTIAL_VALUE_RE = re.compile(
    r"(?:password|passwd|passcode)\s*[:=_-]\s*\S+|"
    r"(?:비밀번호|공동현관(?:비밀번호)?)\s*[:=_-]?\s*\d{2,}",
    re.IGNORECASE,
)
_ADDRESS_VALUE_RE = re.compile(r"[가-힣A-Za-z0-9]+(?:로|길)\s*\d+")
_GOVERNMENT_ID_VALUE_RE = re.compile(r"(?<!\d)\d{6}-[1-8]\d{6}(?!\d)")
_PAYMENT_CARD_VALUE_RE = re.compile(r"(?<!\d)(?:\d[ -]?){15}\d(?!\d)")
_ACCOUNT_VALUE_RE = re.compile(r"(?<!\d)\d{2,6}(?:-\d{2,6}){2,3}(?!\d)")
_API_TOKEN_VALUE_RE = re.compile(
    r"(?:sk[-_](?:live|test|proj)[-_][A-Za-z0-9_-]{4,}|"
    r"github_pat_[A-Za-z0-9_]{4,}|gh[pousr]_[A-Za-z0-9]{4,}|"
    r"AIza[A-Za-z0-9_-]{8,}|api[_-]?key[:=_-][A-Za-z0-9_-]{4,}|"
    r"(?:token|pat)[:=_-][A-Za-z0-9_-]{4,}|"
    r"bearer\s+[A-Za-z0-9._~+/-]{8,})",
    re.IGNORECASE,
)
_EMAIL_VALUE_RE = re.compile(r"(?<![A-Za-z0-9._%+-])[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Za-z]{2,}(?![A-Za-z0-9.-])")
_ACCOUNT_LABEL_VALUE_RE = re.compile(r"(?:account|acct|계좌)\s*[:=_-]\s*\d{6,}", re.IGNORECASE)
_CARD_CANDIDATE_RE = re.compile(r"(?<!\d)(?:\d[ -]?){12,18}\d(?!\d)")
_COMPACT_GOVERNMENT_ID_RE = re.compile(
    r"(?<!\d)\d{2}(?:0[1-9]|1[0-2])(?:0[1-9]|[12]\d|3[01])[1-8]\d{6}(?!\d)"
)
_DROP = object()


def normalize_diagnostic_key(key: Any) -> str:
    raw = str(key or "").strip()
    raw = re.sub(r"[\s-]+", "_", raw)
    raw = re.sub(r"(.)([A-Z][a-z]+)", r"\1_\2", raw)
    return re.sub(r"(?<=[a-z0-9])(?=[A-Z])", "_", raw).lower()


def is_sensitive_hash_key(key: Any) -> bool:
    normalized = normalize_diagnostic_key(key)
    parts = normalized.split("_")
    return bool(parts and parts[-1] in _HASH_SUFFIXES and _SENSITIVE_HASH_TOKENS.intersection(parts[:-1]))


def is_raw_pii_key(key: Any) -> bool:
    normalized = normalize_diagnostic_key(key)
    return (
        normalized in _RAW_PII_KEYS
        or normalized.endswith(_RAW_PII_SUFFIXES)
        or is_sensitive_hash_key(normalized)
    )


def is_uncontrolled_narrative_key(key: Any) -> bool:
    normalized = normalize_diagnostic_key(key)
    return normalized in _UNCONTROLLED_NARRATIVE_KEYS or normalized.endswith(_UNCONTROLLED_NARRATIVE_SUFFIXES)


def redaction_marker(reason_code: str) -> dict[str, Any]:
    return {
        "redacted": True,
        "reason_code": reason_code,
    }


def _is_safe_enum_key(key: str) -> bool:
    return key in _SAFE_ENUM_KEYS or key.endswith(_SAFE_ENUM_KEY_SUFFIXES)


def _is_safe_identifier_key(key: str) -> bool:
    return key in _SAFE_IDENTIFIER_KEYS or key.endswith(_SAFE_IDENTIFIER_KEY_SUFFIXES)


def _is_safe_path_key(key: str) -> bool:
    return key in _SAFE_PATH_KEYS or key.endswith(_SAFE_PATH_KEY_SUFFIXES)


def _is_safe_version_key(key: str) -> bool:
    return key in _SAFE_VERSION_KEYS or key.endswith(_SAFE_VERSION_KEY_SUFFIXES)


def _is_safe_numeric_key(key: str) -> bool:
    return key in _SAFE_NUMERIC_KEYS or key.endswith(_SAFE_NUMERIC_KEY_SUFFIXES)


def _is_safe_bool_key(key: str) -> bool:
    return (
        key in _SAFE_BOOL_KEYS
        or key.startswith(_SAFE_BOOL_KEY_PREFIXES)
        or key.endswith(_SAFE_BOOL_KEY_SUFFIXES)
    )


def _is_safe_hash_key(key: str) -> bool:
    if is_sensitive_hash_key(key):
        return False
    parts = key.split("_")
    return bool(parts and parts[-1] in _HASH_SUFFIXES)


def _safe_hash_value(key: str, value: str) -> bool:
    suffix = key.split("_")[-1]
    lengths = {"md5": {32}, "sha1": {40}, "sha256": {64}, "sha": {40, 64}}
    allowed_lengths = lengths.get(suffix, {32, 40, 64})
    return len(value) in allowed_lengths and re.fullmatch(r"[0-9a-fA-F]+", value) is not None


def _contains_sensitive_text(value: str) -> bool:
    return bool(
        _PHONE_VALUE_RE.search(value)
        or _CREDENTIAL_VALUE_RE.search(value)
        or _ADDRESS_VALUE_RE.search(value)
        or _GOVERNMENT_ID_VALUE_RE.search(value)
        or _COMPACT_GOVERNMENT_ID_RE.search(value)
        or _PAYMENT_CARD_VALUE_RE.search(value)
        or _ACCOUNT_VALUE_RE.search(value)
        or _ACCOUNT_LABEL_VALUE_RE.search(value)
        or _API_TOKEN_VALUE_RE.search(value)
        or _EMAIL_VALUE_RE.search(value)
        or _contains_luhn_card(value)
    )


def _contains_luhn_card(value: str) -> bool:
    for match in _CARD_CANDIDATE_RE.finditer(value):
        digits = [int(char) for char in match.group(0) if char.isdigit()]
        total = 0
        parity = len(digits) % 2
        for index, digit in enumerate(digits):
            if index % 2 == parity:
                digit *= 2
                if digit > 9:
                    digit -= 9
            total += digit
        if total % 10 == 0:
            return True
    return False


def _safe_string_value(key: str, value: str) -> Any:
    if not value:
        return ""
    if key in _SAFE_TIMESTAMP_TEXT_KEYS:
        if key == "checked_at":
            return value if _SAFE_UTC_ISO_RE.fullmatch(value) else _DROP
        return value if _SAFE_KST_RE.fullmatch(value) else _DROP
    if _is_safe_hash_key(key):
        return value if _safe_hash_value(key, value) else _DROP
    if _contains_sensitive_text(value):
        return _DROP
    if _is_safe_path_key(key):
        if ".." in re.split(r"[\\/]", value) or "?" in value or "#" in value:
            return _DROP
        return value if _SAFE_PATH_RE.fullmatch(value) else _DROP
    if _is_safe_version_key(key):
        return value if _SAFE_VERSION_RE.fullmatch(value) else _DROP
    if _is_safe_identifier_key(key):
        return value if _SAFE_IDENTIFIER_RE.fullmatch(value) else _DROP
    if _is_safe_enum_key(key):
        return value if _SAFE_TOKEN_RE.fullmatch(value) else _DROP
    return _DROP


def _safe_numeric_value(key: str, value: int | float) -> bool:
    if isinstance(value, bool) or not isinstance(value, (int, float)) or not math.isfinite(value):
        return False

    # Epoch fields may legitimately be 13 digits; duration/age/count fields may
    # not.  Keep the bounds explicit so card/RRN/phone-shaped numbers cannot be
    # smuggled through a numerically named metric.
    if key in {"at_ms", "timestamp_ms", "ts_ms"} or key.endswith(("_at_ms", "_timestamp_ms", "_ts_ms")):
        return value == 0 or 946_684_800_000 <= value <= 4_102_444_800_000
    if key == "ts" or key == "timestamp" or key.endswith("_timestamp"):
        return (
            value == 0
            or 946_684_800 <= value <= 4_102_444_800
            or 946_684_800_000 <= value <= 4_102_444_800_000
        )
    if key.endswith(("_age_sec", "_sec", "_seconds")):
        return -1 <= value <= 315_576_000
    if key.endswith(("_duration", "_elapsed", "_ms")) or key in {"elapsed"}:
        return -1 <= value <= 604_800_000
    if key.endswith(("_bytes", "_size")) or key in {"length", "size"}:
        return 0 <= value <= 999_999_999
    if key.endswith("_port") or key == "port":
        return False
    if key.endswith("_pid") or key == "pid":
        return 0 <= value <= 4_294_967_295
    if key.endswith(("_count", "_attempts", "_retries", "_retry_count")) or key in {
        "attempts", "count", "depth", "limit", "offset", "retries"
    }:
        return -1 <= value <= 1_000_000_000
    if key in {"battery_level", "progress"} or key.endswith(("_percent", "_progress")):
        return 0 <= value <= 100
    if key == "http_status":
        return 0 <= value <= 599
    if key in {"exit_code", "returncode", "version_code"}:
        return -2_147_483_648 <= value <= 2_147_483_647
    if key == "temperature" or key.endswith(("_temperature", "_temperature_c", "_c")):
        return -100 <= value <= 300
    if key == "ratio" or key.endswith("_ratio"):
        return -1 <= value <= 100
    if key == "score" or key.endswith("_score"):
        return -1_000_000 <= value <= 1_000_000
    return -999_999_999 <= value <= 999_999_999


def _known_field(key: str) -> bool:
    return (
        key in _SAFE_CONTAINER_KEYS
        or key in _SAFE_TIMESTAMP_TEXT_KEYS
        or _is_safe_enum_key(key)
        or _is_safe_identifier_key(key)
        or _is_safe_path_key(key)
        or _is_safe_version_key(key)
        or _is_safe_hash_key(key)
        or _is_safe_numeric_key(key)
        or _is_safe_bool_key(key)
    )


def _project_list(value: list[Any] | tuple[Any, ...], key: str, active_containers: set[int]) -> list[Any]:
    projected: list[Any] = []
    for item in value:
        if isinstance(item, str):
            if (
                key in _SAFE_TOKEN_LIST_KEYS
                and _SAFE_TOKEN_RE.fullmatch(item)
                and not _contains_sensitive_text(item)
            ):
                projected.append(item)
            continue
        if isinstance(item, dict):
            child = _project_mapping(item, active_containers)
        elif isinstance(item, (list, tuple)):
            child = _project_container(item, key, active_containers)
        elif item is not None and not isinstance(item, (bool, int, float)):
            child = redaction_marker("non_json_value")
        else:
            # Scalar lists are not part of the persisted diagnostic contract.
            continue
        if child is not _DROP:
            projected.append(child)
    return projected


def _project_dynamic_map(value: dict[Any, Any], key: str, active_containers: set[int]) -> dict[str, Any]:
    projected: dict[str, Any] = {}
    allowed_keys = _SAFE_DYNAMIC_MAP_VALUES.get(key, set())
    for map_key, item in value.items():
        if not isinstance(map_key, str) or map_key not in allowed_keys:
            continue
        if isinstance(item, dict):
            child = _project_mapping(item, active_containers)
        elif isinstance(item, (list, tuple)):
            child = _project_container(item, key, active_containers)
        else:
            continue
        if child is not _DROP:
            projected[map_key] = child
    return projected


def _project_container(value: Any, key: str, active_containers: set[int]) -> Any:
    if value is None:
        return None
    if not isinstance(value, (dict, list, tuple)):
        return redaction_marker("non_json_value")
    identity = id(value)
    if identity in active_containers:
        return redaction_marker("recursive_reference")
    active_containers.add(identity)
    try:
        if isinstance(value, dict):
            if key in _SAFE_DYNAMIC_MAP_KEYS:
                return _project_dynamic_map(value, key, active_containers)
            return _project_mapping(value, active_containers)
        return _project_list(value, key, active_containers)
    except Exception:
        return redaction_marker("container_read_error")
    finally:
        active_containers.discard(identity)


def _project_field(value: Any, key: str, active_containers: set[int]) -> Any:
    if key in _SAFE_CONTAINER_KEYS:
        return _project_container(value, key, active_containers)
    if value is None:
        return None if _known_field(key) else _DROP
    if isinstance(value, bool):
        return value if _is_safe_bool_key(key) else _DROP
    if isinstance(value, int):
        return value if _is_safe_numeric_key(key) and _safe_numeric_value(key, value) else _DROP
    if isinstance(value, float):
        if not _is_safe_numeric_key(key):
            return _DROP
        if not math.isfinite(value):
            return redaction_marker("non_finite_number")
        return value if _safe_numeric_value(key, value) else _DROP
    if isinstance(value, str):
        return _safe_string_value(key, value)
    if _known_field(key):
        return redaction_marker("non_json_value")
    return _DROP


def _project_mapping(value: dict[Any, Any], active_containers: set[int]) -> dict[str, Any]:
    projected: dict[str, Any] = {}
    for raw_key, item in value.items():
        if not isinstance(raw_key, str):
            continue
        key = normalize_diagnostic_key(raw_key)
        if (
            not key
            or _contains_sensitive_text(raw_key)
            or is_raw_pii_key(key)
            or is_uncontrolled_narrative_key(key)
        ):
            continue
        child = _project_field(item, key, active_containers)
        if child is not _DROP:
            projected[raw_key] = child
    return projected


def _redact_diagnostic_payload(value: Any, active_containers: set[int]) -> Any:
    if isinstance(value, dict):
        return _project_container(value, "", active_containers)
    if isinstance(value, (list, tuple)):
        return _project_container(value, "", active_containers)
    return redaction_marker("non_diagnostic_root")


def redact_diagnostic_payload(value: Any) -> Any:
    """Return a JSON-safe structural copy without raw or guessable personal data.

    Raw narrative fields are removed instead of hashed because phone numbers,
    addresses, room/sender labels, passwords, and short messages are guessable.
    Unsupported or recursive values become a small structured marker so one bad
    diagnostic value cannot break the monitor's persistence path.
    """

    try:
        return _redact_diagnostic_payload(value, set())
    except Exception:
        return redaction_marker("redaction_failed")
