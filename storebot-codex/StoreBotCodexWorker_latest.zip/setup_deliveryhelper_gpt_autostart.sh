#!/data/data/com.sbotux/files/usr/bin/bash
set -euo pipefail

BOOT_DIR="${TERMUX_BOOT_DIR:-/data/data/com.sbotux/files/home/.termux/boot}"
BOOT_FILE="${BOOT_DIR}/03-deliveryhelper-gpt-worker.sh"
ROOT_DIR="${DELIVERYHELPER_GPT_ROOT:-/root/my-first-project}"

mkdir -p "$BOOT_DIR"

cat > "$BOOT_FILE" <<'BOOT'
#!/data/data/com.sbotux/files/usr/bin/bash
# DeliveryHelper GPT 1차 재검토 worker watchdog 자동 기동.

ROOT_DIR="${DELIVERYHELPER_GPT_ROOT:-/root/my-first-project}"
CONFIG_FILE="$ROOT_DIR/subphone/config.env"

pgrep -f "watch_deliveryhelper_gpt_reanalyze_worker.sh" >/dev/null && exit 0

if [ -f "$CONFIG_FILE" ]; then
  set -a
  . "$CONFIG_FILE"
  set +a
fi

setsid bash "$ROOT_DIR/subphone/watch_deliveryhelper_gpt_reanalyze_worker.sh" >/dev/null 2>&1 &
exit 0
BOOT

chmod +x "$BOOT_FILE"
"$BOOT_FILE"

echo "installed $BOOT_FILE"
