<!-- source: /root/PosDelay/APP_INTENT.md -->
# PosDelay APP_INTENT.md

## 만든 이유
- 주문 폭주 때 자동수락, 배달료, 영업정지, 지연을 안정적으로 조정해 매장 운영을 보호한다.
- 서브폰을 실행 전담으로 둬 개인폰의 상시 실행 부담과 리소스 사용을 최소화한다.

## 사용자 결과
- 현재 처리량과 정책 상태가 맞게 보여야 한다.
- 위험한 호출이나 잘못된 임계값으로 배민/쿠팡 운영을 망치지 않아야 한다.

## 2026-07-21 CA typed monitoring 로컬 빌드
- Android unified queue의 canonical `/posdelay/ops_events` start/result 생성은 production 호출점에 연결했다. raw 운영 로그·메시지·주문/매장/폰/자격증명은 typed event에서 제외한다.
- queue가 실제 적재를 확정한 뒤에만 collision-free opaque execution id를 만든다. duplicate callback은 execution id 없는 skip으로 분리해 typed result를 만들지 않고, 실제 queued/clear/role-window 결과만 start/result id를 공유한다.
- Python Telegram observer와 외부 gate adapter는 code-ready/default-off다. live flags/restart/physical E2E가 승인되기 전에는 CA 실송신·상주 감시·factory self_fix enqueue를 활성화하지 않는다.
- 로컬 검증: version `0721.2053(29725326)`, JVM `35 tests/0 failures`, Python observer `24 passed`, assembleDebug PASS, APK sha256 `9109e92a276749a4cf55e0a13426616000fec70f537d5e4e36528b1edbc65974`.
- 설치·update-center 배포·Telegram live send는 하지 않았다.

## 2026-07-08 설정 동기화/설치 상태 포인터
- 설정 업로드는 Firebase PUT 성공 ACK 뒤에만 applied revision을 저장한다. 실패 시 local pending metadata를 유지하고 capped retry를 예약하며, `start()`는 최신 local AdManager snapshot으로 pending upload를 재시도한다.
- 최신 배포 기준: versionName `0708.2257`, versionCode `29725317`, `testDebugUnitTest`/`assembleDebug` PASS, debug APK sha256 `76752fe4569b956738b83c4bba393b42cc1e78d6fa826f0b8e0ae41334ead5b2`.
- update-center PASS: `https://poskds-attendance.web.app/posdelay/version.json` 및 live bin이 같은 version/sha/size를 가리킨다.
- 설치 루트: ADB가 `.bin`을 거부하므로 live bin을 byte-identical `.apk` staging path로 복사한 뒤 같은 sha 확인 후 install한다.
- 서버폰 설치 PASS: factory PC USB ADB request `pccli_1783520959257_8dac4346`, serial/model `R39M30RWR2F`/`SM_G975N`, package `com.posdelay.app`, install `Success`, lastUpdateTime `2026-07-08 23:31:18`. 개인폰은 `personal_phone_blocked_no_serial`.

## 2026-07-15 배달료 확인형 실행 기준
- 배달료 기준이상값/미만값 적용은 광고 스케줄과 독립적으로 24시간 평가한다. 광고시간 밖에서도 배달료 적용·복원과 영업 재개는 허용하되 신규 영업정지 같은 위험 동작은 계속 차단한다.
- 배달료 상태는 명령 전송이나 PUT 응답만으로 바꾸지 않는다. engine execution token, exact `request_id`/`settings_epoch`/목표 금액, Baemin GET `readback_fee`가 모두 맞는 성공 결과 뒤에만 `lastAppliedFee`와 방어 상태를 확정한다. PUT 전용 `/delivery-fee/AGENCY_DELIVERY/rules`를 조회에 재사용하지 않고, `/v4/store/shops/{shopId}` 상세 GET의 `deliveryFees[]`에서 `AGENCY_DELIVERY` 규칙을 명시 선택해 검증한다.
- 설정 변경이 실행 lock/cooldown과 겹쳐도 완료 후 bounded 재평가로 새 목표값을 적용한다. Gate OFF 복구는 영속 pending+백오프로 재시작 뒤에도 `resume`/`fee_restore` 확인을 이어간다.
- 개인폰 MAIN/STANDBY는 설정·표시만 담당하며 플랫폼 실행을 하지 않는다. KITCHEN/TAKEOVER 단일 실행 역할만 배달료 명령과 실제 조회 검증을 수행한다.
- 배포 기준: PosDelay commit `b090c95`, version `0715.0535(29725319)`, clean worktree `25 tests/0 failures`·assemble PASS, APK sha256 `a63660e60e19fc1091f66c630f30d92821d4527f3d9af0b536c6f6868e0ea625`, update-center root commit `a82f16d`.
- 서버폰 설치 PASS: factory USB request `pccli_1784062210050_41b1a111`, serial/model `R39M30RWR2F`/`SM_G975N`, `install -r` 1회 `Success`, lastUpdateTime `2026-07-15 05:51:18`.
- 물리 readback PASS: request `pccli_1784062320601_6786a7b2`, gate request `gate_1784062427017_224adbba`, epoch `44`, target/readback `2000/2000`, status `SUCCESS`. 다음 heartbeat는 `action_locked=false`, `fee_last_applied=2000`, `fee_readback_verified=true`, `health=OK`로 수렴했다.

## 절대 기준
- PosDelay는 native APK/live operations app 이다.
- Firebase는 read-only preflight 원본으로만 본다. live action, pause/resume, 영업 영향 조작, destructive write 는 별도 safety flow 와 명시 승인 없이는 금지한다.
- UI 변경 완료는 representative device screenshot, accessibility snapshot, touch target, overflow, 그리고 공장 PC/device evidence 확인까지 묶어서 본다.
- UI 기준 후보는 Google Design / Android Studio 이고, debug APK 및 update channel 전달은 배포 단위에서만 따진다.
- 자동수락, 배달료, 영업정지의 기준 데이터를 섞지 않는다.
- KDS 처리중 건수, 프린터 30분 활성 가게배달 건수, 배민1/쿠팡이츠 의미를 분리한다.
- 배달료 `미만/0건 금액 0원`과 `미만 0원+배민클럽`은 다른 모드다. `0원`은 기존 배달료 복원 동작만 하고, `0원+배민클럽`은 기존 `0원` 동작에 MP_BAEMIN_CLUB 가게배달팁 즉시할인 등록/종료를 추가한다.
- 배달료 `0원+배민클럽`은 임계값 미만 구간에서 등록 상태를 유지하고, 임계값 이상/영업정지 구간에서는 종료한다. 배민배달(OD_BAEMIN_CLUB) 팁은 건드리지 않는다.
- 배민/쿠팡 웹·API 자동화는 플랫폼별 큐와 충돌 그룹으로 직렬 실행한다. 같은 플랫폼 동시 호출, 중복 등록, 중복 종료는 금지한다.
- 모든 배민/쿠팡 웹·API 자동화에는 사람 조작처럼 보이는 랜덤 소수점 초 단위 휴먼 딜레이를 적용해 리미트와 차단 위험을 낮춘다.
- PosDelay 운영 기준이 `PosDelay_설정.txt`인 동안 legacy watcher 전환값을 임의로 바꾸지 않는다.
- 서브폰에서는 PosDelay가 주문/지연/방어 실행 우선권을 가진다. StoreBot의 카카오 화면 보조 감시는 PosDelay 유휴 또는 안전 구간에서만 허용한다.
- Codex CLI/codex_ops를 기본 AI ops 경계로 두고, OpenClaw가 충분히 빠르고 안정적이면 PosDelay 전용 agent/session 후보로만 붙인다. 역할은 상태 조회, 로그/원인 요약, 명령 후보 생성까지이며, 플랫폼 조작을 직접 실행하지 않는다.
- OpenClaw가 제안한 실행도 기존 PosDelay 엔진/명령 큐/충돌 그룹/휴먼 딜레이를 반드시 통과해야 한다. 배민/쿠팡 직접 조작이나 같은 플랫폼 동시 호출은 금지한다.
- goal mode는 승인 대기 없는 상주 모니터링/오류판정/자가교정 운영 모드다. PosDelay 오류 분석/보고/self_fix는 heartbeat stale, action_log 이상, 큐 정체, 실행 실패, 반복 임계값 보정까지 넓게 보고 멈추지 않고 진행하되, 배민/쿠팡 실행은 기존 엔진 큐와 충돌 그룹을 반드시 통과한다.
- KDS/광고/영업정지 hot path 안정성은 Android 앱의 foreground service, 접근성, 로컬 상태, 재시작 복구 기준으로 판단한다.
- Python/CLI watchdog은 분석, 상태 대조, self-fix 요청 생성 보조층이다. 플랫폼 직접 조작이나 hot path 대체 실행자가 아니다.
- 광고 설정이나 상태 변경으로 KDS count가 변하지 않을 수 있으므로 Android 앱은 설정 적용 뒤 자동화 재평가를 트리거해야 한다.
- Activity/WebExecutor가 없는 백그라운드 광고 자동화는 실패 반복 대신 기존 광고 safety gate를 재확인한 뒤, 실제 변경이 필요한 경우에만 Activity 기동을 요청한다.
- 광고 Activity 재평가도 엔진과 같은 KDS 금액환산 count를 기준으로 한다.
- 서버폰(KITCHEN)은 foreground service + WakeLock/WifiLock + Doze whitelist + restart alarm fallback 기준으로 생존성을 유지한다.
- 개인폰 PosDelay는 설정/모니터링/확인 중심이다. 서브폰처럼 무기한 WakeLock, 고성능 WifiLock, 화면 점유를 기본값으로 쓰지 않는다.
- 현재 개인폰 1대는 `device_key=d2dbdc4075acad22` 기준으로 `MAIN` 자동 고정한다. KDS 접근성이나 같은 폰 broadcast가 켜져도 이 개인폰을 `KITCHEN`으로 승격하지 않는다.
- 역할은 화면 토글로 수동 지정하지 않는다. 현재 개인폰 ID는 MAIN, Firebase SOT에 등록된 서브폰 ID나 KDS 접근성 연결은 KITCHEN으로 자동 판정한다.
- 광고시간 밖에서는 배민/쿠팡 광고, 지연, 신규 영업정지 같은 위험 action을 차단한다. 배달료 기준이상값/미만값 적용과 영업 재개는 복구·보호 동작으로 계속 실행하며 heartbeat, monitoring, settings sync도 유지한다.
- 광고 자동화 SOT는 `/posdelay/ad_settings`다. 서버폰은 FirebaseSettingsSync로 이를 SharedPreferences에 적용하고, 배민/쿠팡 광고 판단은 zone 배열을 우선 사용한다.
- 광고 legacy threshold 값은 zone 메타데이터/구버전 fallback이다. `0`도 명시값으로 보존하며, zone 배열이 있을 때 threshold 숫자만으로 실제 동작을 판정하지 않는다.
- `runtime_config_v2/shop_pause`는 영업정지/재개 SOT이며 배민/쿠팡 광고 금액/ON/OFF 판단을 덮어쓰지 않는다.
- MAIN/STANDBY 개인폰은 설정, 모니터링, 페일오버 후보 역할이다. 자동/원격/스케줄/forceRun 실행은 KITCHEN/PRIMARY 또는 TAKEOVER에서만 통과한다.

## UI/동선 기준
- 임계값 화면은 같은 패턴으로 보여야 한다.
- 추상 정책 화면이나 별도 진입점을 늘리지 않는다.
- 배달료 조정 화면의 `미만/0건 금액`은 `0원`과 `0원+배민클럽`을 구분해서 보여준다. `0원+배민클럽`을 단순 `0원`처럼 표시하지 않는다.
- 실제 운영 중 쓰는 상황, 제어, 임계값 흐름을 먼저 보여준다.

## 데이터/경계 기준
- 개인폰은 설정/모니터링, 서브폰은 실행 전담 기준을 유지한다.
- PosDelay 운영 이벤트 canonical은 `/posdelay/ops_events/{eventId}`다. unified queue의 typed start/result와 KDS raw/adjusted/weighted·printer count, 실제 decision source/target/result, freshness/revision, opaque evidence만 허용하며 raw 로그·메시지·주문·매장·폰·자격증명·stack은 넣지 않는다.
- expected source/target은 event caller 값이 아니라 task canonical mapping에서 판정한다. observer는 expected/actual source나 target이 task mapping과 다르면 fail-closed하고 CA payload를 만들지 않는다.
- 기존 `/posdelay/engine/tasks/{taskId}` private 상태는 소비자 호환용으로 유지하며 raw `last_msg`는 이 legacy 경로에만 허용한다. Telegram CA는 이 경로를 읽지 않는다.
- Telegram CA는 canonical event의 status-only projection이다. `domain=posdelay`, `delivery_kind=posdelay_ops_event`, deterministic dedupe/CAS/replay를 쓰며 기본 `no_send`; 별도 승인·live gate 검증 전에는 전송하지 않는다.
- observer production adapter는 ops event bounded query와 flat committed-receipt/미완료 claim cursor page, due-delivery 전용 page를 필수로 받는다. 각 page의 실제 row 수는 limit 이하이며 backlog는 durable cursor로 순차 소진한다. poison row는 raw 원문 없는 typed quarantine receipt로 격리해 다음 event를 막지 않는다.
- receipt authoritative SOT는 독립 flat `/posdelay/ca_projection/receipts/{receiptId}` CAS다. `/posdelay/ca_projection/tasks/{taskId}`에는 sequence/last transition/time/receipt pointer와 전환 중 단일 pending pointer만 O(1)로 두며 receipt를 누적하지 않는다. task pending → flat receipt pending → task finalize → receipt committed의 two-path reconcile/compensation과 monotonic fencing으로 중간 실패·takeover를 수렴한다.
- coalesce/rate-limit은 durable global projection guard와 monotonic fencing으로 cross-process 경쟁을 막는다. pending도 rate capacity에 포함하고 만료 lease는 회수하며, I/O 전후 live clock/fence를 재검증하고 낮은 fence의 동일 receipt는 새 owner가 보상 수렴한다.
- outbox 전역 guard는 lease/fence/cursor만 O(1)로 유지하고 영구 assignment map을 저장하지 않는다. `/posdelay/ca_projection/outbox_claims/{receiptId}` receipt별 CAS claim이 단일 ownership SOT이며, 재시작·takeover는 같은 deterministic delivery를 복구해 중복 배정을 막는다.
- contract rejection만 raw 없는 quarantine+seen 처리한다. repository/CAS transient는 retryable poll 결과로 남기고 seen 처리하지 않아 다음 poll이 재시도한다. 이미 delivery에 배정된 receipt는 신규 batch에서 제외한다.
- 일관성 이상 복구는 observability refresh, 사용자 알림, factory self_fix enqueue만 허용한다. 앱 액션 재실행·engine trigger·gate command를 복구기가 직접 호출하지 않고, 모든 영업 action은 기존 engine queue/conflict/human-delay 경계를 유지한다.
- 서브폰 존재 이유는 실행 안정성을 한곳에 모으고 개인폰 리소스를 줄이는 이원화다. 두 기기가 같은 앱을 설치해도 역할별 실행 강도는 달라야 한다.
- 역할 판정은 모델명이 아니라 현재 개인폰 고유 device_key와 저장 역할을 기준으로 한다. 같은 Ultra 모델이라도 현재 개인폰 ID가 아니면 MAIN 고정 예외를 적용하지 않는다.
- 서브폰의 foreground, 접근성, 절전 예외는 StoreBot과 공유 자원이므로 PosDelay 자동화를 방해하는 화면 점유를 기본값으로 두지 않는다.
- OpenClaw 입력은 `domain=posdelay` envelope로 분리하고, KDS/프린터/엔진/action_log 요약처럼 필요한 최소 운영 데이터만 보낸다. StoreBot 카톡, DeliveryHelper 주소, BankTotal 금융 맥락과 같은 세션에 섞지 않는다.
- 공용 서버폰 `codex_ops` 베이스를 쓰더라도 PosDelay 운영 맥락은 전용 envelope/session/result 경로로 분리한다.
- C&I prompt는 PosDelay monitor, action_log/metric/crash/update 이벤트, 사용자/수동 enqueue, 또는 상주 판단 루프가 만든다. 이는 LLM 실행을 깨우는 envelope이며 C&I 판단 권한 제한이 아니다.
- C&I 자동 복구는 코드/설정/문서/APK/업데이트센터 보정까지 허용하되, 배민/쿠팡 실행은 기존 엔진 큐, 충돌 그룹, 휴먼 딜레이를 반드시 통과해야 한다.
- 무활동 리포트는 KDS/프린터 압력만으로 만들지 않는다. 실제 실행 후보나 서킷 차단이 30분 이상 지속될 때만 `/posdelay/error_reports`에 올린다.
- TTS는 서브폰(KITCHEN) 전용이다. 개인폰(MAIN)은 설정값이 켜져도 발화하지 않는다.
- 차량/Android Auto 환경의 TTS는 미디어 볼륨이 아니라 내비 안내 음성 기준으로 들리게 한다.
- PC 매크로가 읽는 값과 앱/대시보드 저장값이 같은 의미인지 확인한다.
- PC 매크로 heartbeat stale 복구는 먼저 `/monitor/main_pc/status`를 같이 본다. main_pc가 살아 있으면 `/monitor/main_pc/cmd="restart_posdelay_pc"`로 PosDelay PC 매크로만 갱신/재시작하고, main_pc도 stale이면 PC 전원/네트워크/Windows watchdog 외부 경계로 본다.
- PC 매크로 heartbeat의 짧은 시작/재연결/목표값 반영 지연은 즉시 장애로 보지 않는다. 같은 신호가 지속될 때만 `health=WARN`으로 self_fix 후보가 된다.
- `/posdelay/pc_macro/command` force_update는 ack 후 같은 nonce일 때만 command node를 소비해야 한다. 소비되지 않은 command는 재시작 때 반복 실행과 `force_update_pending` 오탐을 만든다.
- AI Ops consistency check는 소비 완료된 command node 부재를 `idle_no_command`로 본다. 살아 있는 command가 ack 없이 grace를 넘길 때만 command_ack 장애로 승격한다.
- KDS 안정 운영 중에는 PosKDS 코드를 직접 건드리지 않고 PosDelay/PackHelper/DH 쪽 보완을 먼저 본다.
- KDS 금액 환산 기준은 2026-06-15 KST부터 live 적용한다. 전체 KDS `orders[]`를 PackHelper capture `total_amount`와 매칭해 3만원당 1건으로 환산하고, 마이너스/홀·내점·매장/1.5만원 미만 소액 추가는 오차가 아니라 skip으로 분리한다.
- KDS 화면의 `처리/조리중 N`은 버리지 않는다. `orders[]`가 일부만 보이는 부분 노출 상태에서는 visible orders 금액환산값에 보이지 않는 나머지 건수를 fallback으로 더하고, 최종 `weighted_count`는 보정된 처리 count보다 낮아지지 않아야 한다.
- live 적용 범위는 배민/쿠팡 광고, 지연, 영업정지 count다. 배달료 조정 count와 자동수락 KDS count는 기존 기준을 유지한다.
- 메인 PC 영업중지는 `/posdelay/signal_snapshot/kds/weighted_count`를 사용한다. 자동수락 KDS는 `/posdelay/signal_snapshot/kds/count`를 우선 유지하고, fresh snapshot raw를 `/kds_status` 0 fallback으로 덮지 않는다.
- KDS `orders[]`가 없는 count-only 상태에서는 30분 stale/보정 후 `adjusted_count`를 live weighted fallback 기준으로 쓴다. 보정 count가 0이면 `weighted_count`도 0이어야 한다.
- KDS 주문번호 최초 등장 추적은 부분 노출/일시 0건으로 즉시 지우지 않는다. 오래된 조리중 주문이 다시 보일 때 새 주문처럼 live count에 되살아나면 안 된다.
- KDS `kds_paused` 상태라도 원본 `count=0`은 stale count 제거용 zero reset으로 반드시 반영한다.
- CLI 상주 엔진은 `/posdelay/kds_amount_weight_test/latest`와 daily events를 읽어 매칭 누락, 0원 금액, raw/adjusted count 대비 delta, `apply_to_live=true` 상태를 감시하고 오차/미확인 발생 시 self_fix 코딩 보정 후보를 생성한다.
- 단, 금액환산 metric timestamp만 오래됐고 `/posdelay/signal_snapshot/kds`가 최신이며 `weighted_count`가 metric과 일치하면 live 경로 정상 공백으로 본다.
- 영업정지 ON/OFF, 기준 소스, `runtime_config_v2` 정책은 새로고침이나 Firebase 순간 실패 뒤에도 마지막 저장 상태를 보여야 한다. 개인폰 설정 화면도 `/posdelay/ad_settings` 전체 PUT을 적용해 오래된 로컬 `gate_settings` 값으로 돌아가면 안 된다.
- 광고 정상 판정은 3축을 따로 본다: 개인폰 설정(`/posdelay/ad_settings`), 서버폰 적용 상태(`settings_sync`/applied revision), 실제 동작(`/posdelay/ad_state.last_decision_reason`와 action log).

## 수정 전 질문
- 이 변경이 운영 안전성을 높이는가.
- 화면명이나 카운트 소스를 혼동시키지 않는가.
- PC 소비값, 앱 저장값, 대시보드 표시가 같은 기준인가.
- 같은 플랫폼 자동화가 동시에 호출되지 않는가.
- 휴먼 딜레이와 상태 중복 방지가 모든 실행 경로에 적용되는가.

## 완료 기준
- 검증: 설정 저장, PC 소비값, 큐 직렬 실행, 휴먼 딜레이 적용, Android 빌드, 필요 시 실제 Firebase 값 확인
- UI 작업은 대표 기기 screenshot/accessibility/touch target/overflow evidence 와 공장 PC device evidence 까지 확인해야 완료다.
- APK 전달은 debug APK 복사와 설치 화면 노출, 필요 시 update channel 확인까지 포함한다.
- 영업정지 설정 저장은 앱 상태 JSON, SharedPreferences, `runtime_config_v2` 캐시 복원이 같은 값으로 수렴해야 완료다.
- 광고 설정 저장은 `/posdelay/ad_settings` zone/threshold 원문, 서버폰 applied revision, `/posdelay/ad_state.last_decision_reason`이 같은 count/source 기준으로 수렴해야 완료다.
- 금액 환산 KDS live 적용은 Firebase `kds_amount_weight_test/latest`가 `apply_to_live=true`, `live_weighted_count`, `fallback_count_basis`, `match_error_rate_pct`, `delta_vs_raw_pct`, `delta_vs_adjusted_pct`를 남기고 광고/지연/영업정지 경로가 weighted count를 읽어야 완료다.
- 0624.0410 안정화는 기존 data 패키지 복구, Android 빌드, 서버/서브폰 설치, 업데이트센터 공개 배포 확인까지 완료 기준이다.
- 0624.0443 paused-zero reset은 `kds_paused` 중 원본 `count=0`이 `signal_snapshot.kds.count/weighted_count=0`으로 수렴해야 완료다.
- 전달: Android 변경 시 debug APK 복사와 `termux-open`
- 남은 위험: 메인 PC 서비스 반영 지연, 영업 중 오작동 가능성
