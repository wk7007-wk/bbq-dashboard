#!/usr/bin/env python3
"""Minimal managed Codex lifecycle/safety hook.

This hook deliberately does not implement model routing, worker routing, context
freshness, repository allowlists, or changing collaboration policy. Those
belong to the dispatcher/broker. The managed hook keeps only stable local
invariants and non-blocking lifecycle/evidence receipts.
"""

from __future__ import annotations

import dataclasses
import datetime as dt
import fcntl
import hashlib
import json
import os
from pathlib import Path
import re
import shlex
import sys
import tempfile
from typing import Any, Iterable


POLICY_VERSION = "minimal-managed-hooks-v2.1"
DEFAULT_STATE_DIR = Path("/root/.codex/managed-hook-state")
STATE_DIR_ENV = "CODEX_MINIMAL_HOOK_STATE_DIR"

PROTECTED_PATH_MARKERS = (
    "/etc/codex/requirements.toml",
    "/etc/codex/managed-hooks",
    "/root/.codex/config.toml",
    "/root/.codex/hooks",
    "/root/my-first-project/.codex/hooks",
)

EDIT_TOOL_NAMES = {
    "apply_patch",
    "edit",
    "multiedit",
    "write",
}

SHELL_TOOL_NAMES = {
    "bash",
    "shell",
    "exec_command",
    "functions.exec_command",
    "functions.exec",
}

SENSITIVE_PATTERNS = {
    "aws_access_key": re.compile(r"\bAKIA[0-9A-Z]{16}\b"),
    "google_api_key": re.compile(r"\bAIza[0-9A-Za-z_-]{30,}\b"),
    "openai_style_key": re.compile(r"\bsk-[A-Za-z0-9_-]{16,}\b"),
    "bearer_token": re.compile(r"(?i)\bbearer\s+[A-Za-z0-9._~+/-]{16,}"),
    "secret_assignment": re.compile(
        r"(?i)\b(?:password|passwd|secret|token|api[_-]?key)\b\s*[:=]\s*[^\s,;]{6,}"
    ),
}


@dataclasses.dataclass(frozen=True)
class Decision:
    reason: str
    code: str


def _utc_now() -> str:
    return dt.datetime.now(dt.timezone.utc).isoformat(timespec="seconds")


def _event_name(data: dict[str, Any]) -> str:
    for key in ("hook_event_name", "hookEventName", "eventName", "event"):
        value = data.get(key)
        if isinstance(value, str) and value:
            return value
    specific = data.get("hookSpecificOutput")
    if isinstance(specific, dict):
        value = specific.get("hookEventName")
        if isinstance(value, str):
            return value
    return ""


def _tool_name(data: dict[str, Any]) -> str:
    for key in ("tool_name", "toolName", "tool"):
        value = data.get(key)
        if isinstance(value, str):
            return value
    return ""


def _normalized_tool_name(value: str) -> str:
    return value.strip().replace("-", "_").lower()


def _tool_input(data: dict[str, Any]) -> Any:
    if "tool_input" in data:
        return data["tool_input"]
    return data.get("toolInput")


def _command_from_input(value: Any) -> str:
    if isinstance(value, dict):
        for key in ("cmd", "command", "script"):
            command = value.get(key)
            if isinstance(command, str):
                return command
    if isinstance(value, str):
        return value
    return ""


def _compact_json(value: Any) -> str:
    try:
        return json.dumps(value, ensure_ascii=False, sort_keys=True, default=str)
    except Exception:  # noqa: BLE001 - evidence hashing must never block a tool
        return repr(value)


def _sha256_value(value: Any) -> str:
    return hashlib.sha256(_compact_json(value).encode("utf-8", "replace")).hexdigest()


def _strip_heredoc_bodies(command: str) -> str:
    """Remove heredoc data while retaining commands after each terminator."""

    kept: list[str] = []
    pending: list[tuple[str, bool]] = []
    for line in command.splitlines(keepends=True):
        if pending:
            delimiter, strip_tabs = pending[0]
            candidate = line.rstrip("\r\n")
            if strip_tabs:
                candidate = candidate.lstrip("\t")
            if candidate == delimiter:
                pending.pop(0)
            continue

        kept.append(line)
        if "<<" not in line:
            continue
        lexer = shlex.shlex(line, posix=True, punctuation_chars="<>;&|")
        lexer.whitespace_split = True
        tokens = list(lexer)
        index = 0
        while index < len(tokens):
            if tokens[index] != "<<":
                index += 1
                continue
            if index + 1 >= len(tokens):
                raise ValueError("heredoc delimiter missing")
            raw_delimiter = tokens[index + 1]
            strip_tabs = raw_delimiter.startswith("-")
            delimiter = raw_delimiter[1:] if strip_tabs else raw_delimiter
            if not delimiter or delimiter in {";", "&", "|", ">", "<"}:
                raise ValueError("invalid heredoc delimiter")
            pending.append((delimiter, strip_tabs))
            index += 2
    if pending:
        raise ValueError("unterminated heredoc")
    return "".join(kept)


def _shell_segments(command: str) -> list[list[str]]:
    """Return command segments without treating heredoc data as commands."""

    command_without_data = _strip_heredoc_bodies(command)
    lexer = shlex.shlex(command_without_data, posix=True, punctuation_chars=";&|\n")
    lexer.whitespace = " \t\r"
    lexer.whitespace_split = True
    tokens = list(lexer)

    segments: list[list[str]] = []
    current: list[str] = []
    for token in tokens:
        if token in {";", "&&", "||", "|", "&", "\n"}:
            if current:
                segments.append(current)
                current = []
            continue
        current.append(token)
    if current:
        segments.append(current)
    return segments


def _unwrap_command(tokens: list[str]) -> list[str]:
    tokens = list(tokens)
    while tokens and re.fullmatch(r"[A-Za-z_][A-Za-z0-9_]*=.*", tokens[0]):
        tokens.pop(0)
    if tokens and Path(tokens[0]).name == "env":
        tokens.pop(0)
        while tokens and (tokens[0].startswith("-") or "=" in tokens[0]):
            tokens.pop(0)
    while tokens and Path(tokens[0]).name in {"sudo", "command", "nohup"}:
        tokens.pop(0)
    if tokens and Path(tokens[0]).name == "timeout":
        tokens.pop(0)
        while tokens and tokens[0].startswith("-"):
            tokens.pop(0)
        if tokens and re.fullmatch(r"\d+(?:\.\d+)?[smhd]?", tokens[0]):
            tokens.pop(0)
    return tokens


def _has_flags(tokens: Iterable[str], short_flags: set[str]) -> bool:
    seen: set[str] = set()
    for token in tokens:
        if token.startswith("--"):
            continue
        if token.startswith("-"):
            seen.update(token[1:])
    return short_flags.issubset(seen)


def _git_decision(args: list[str]) -> Decision | None:
    if not args:
        return None
    index = 0
    while index < len(args):
        token = args[index]
        if token in {"-C", "-c", "--git-dir", "--work-tree", "--namespace"}:
            index += 2
            continue
        if token.startswith(("--git-dir=", "--work-tree=", "--namespace=")):
            index += 1
            continue
        if token in {"--no-pager", "--paginate", "--literal-pathspecs", "--no-optional-locks"}:
            index += 1
            continue
        if token == "--":
            index += 1
        break
    if index >= len(args):
        return None
    subcommand = args[index]
    rest = args[index + 1 :]
    if subcommand == "reset" and "--hard" in rest:
        return Decision("git reset --hard requires an out-of-band admin approval path", "git_reset_hard")
    if subcommand == "clean" and _has_flags(rest, {"f"}):
        return Decision("git clean with force requires an out-of-band admin approval path", "git_clean_force")
    if subcommand == "checkout" and "--" in rest:
        return Decision("git checkout path reversion requires an out-of-band admin approval path", "git_checkout_revert")
    if subcommand == "restore" and ("--source" in rest or "--staged" in rest):
        return Decision("git restore of tracked content requires an out-of-band admin approval path", "git_restore_revert")
    return None


def _adb_decision(args: list[str]) -> Decision | None:
    del args
    return Decision(
        "ADB execution and evidence collection require the factory-PC physical safety flow",
        "adb_physical_boundary",
    )


def _simple_command_decision(tokens: list[str]) -> Decision | None:
    tokens = _unwrap_command(tokens)
    if not tokens:
        return None
    executable = Path(tokens[0]).name.lower()
    args = tokens[1:]

    if any(marker in tokens[0] for marker in ("$(", "`")) or tokens[0].startswith("$"):
        return Decision("dynamic command position is fail-closed", "shell_dynamic_executable")

    if executable in {"bash", "sh", "zsh"}:
        for index, token in enumerate(args):
            if token.startswith("-") and not token.startswith("--") and "c" in token[1:]:
                if index + 1 >= len(args):
                    return Decision("shell command string is missing", "shell_parse_unknown")
                return _shell_decision(args[index + 1])

    if executable == "eval":
        payload = " ".join(args)
        if not payload or "$" in payload or "`" in payload:
            return Decision("dynamic eval is fail-closed", "shell_dynamic_eval")
        return _shell_decision(payload)

    if executable == "rm" and (
        (_has_flags(args, {"r"}) or "--recursive" in args)
        and (_has_flags(args, {"f"}) or "--force" in args)
    ):
        return Decision("recursive forced deletion requires an out-of-band admin approval path", "rm_recursive_force")
    if executable.startswith("mkfs") or executable in {"wipefs", "shred"}:
        return Decision(f"destructive filesystem tool '{executable}' is fail-closed", "filesystem_destructive")
    if executable == "dd" and any(token.startswith("of=/dev/") for token in args):
        return Decision("raw block-device writes are fail-closed", "block_device_write")
    if executable == "git":
        decision = _git_decision(args)
        if decision:
            return decision
    if executable in {"adb", "adb.exe"}:
        decision = _adb_decision(args)
        if decision:
            return decision
    if executable == "firebase" and any(token in {"database:remove", "firestore:delete"} for token in args):
        return Decision("Firebase destructive delete requires the application safety flow", "firebase_delete")
    if executable == "curl":
        lowered = [token.lower() for token in args]
        has_delete = any(token in {"-xdelete", "--request=delete"} for token in lowered)
        has_delete = has_delete or any(
            lowered[index] in {"-x", "--request"} and index + 1 < len(lowered) and lowered[index + 1] == "delete"
            for index in range(len(lowered))
        )
        if has_delete and any(token.startswith(("http://", "https://")) for token in lowered):
            return Decision("network DELETE requires an out-of-band admin approval path", "network_delete")

    live_markers = {
        "--live-send",
        "--execute-payment",
        "--execute-order",
        "--confirm-bank-write",
        "kakao_send_enabled=true",
        "publish_gate=true",
    }
    if any(token.lower() in live_markers for token in tokens):
        return Decision("explicit live business mutation requires the application safety flow", "live_business_mutation")
    return None


def _command_substitution_decision(command: str, depth: int) -> Decision | None:
    if depth > 6:
        return Decision("nested shell expansion is fail-closed", "shell_dynamic_expansion")
    index = 0
    while True:
        start = command.find("$(", index)
        if start < 0:
            break
        cursor = start + 2
        nesting = 1
        while cursor < len(command) and nesting:
            if command.startswith("$(", cursor):
                nesting += 1
                cursor += 2
                continue
            if command[cursor] == ")":
                nesting -= 1
                if nesting == 0:
                    break
            cursor += 1
        if nesting:
            return Decision("unterminated command substitution is fail-closed", "shell_dynamic_expansion")
        inner = command[start + 2 : cursor]
        decision = _shell_decision(inner, depth + 1)
        if decision:
            return decision
        index = cursor + 1

    backtick_start = command.find("`")
    while backtick_start >= 0:
        backtick_end = command.find("`", backtick_start + 1)
        if backtick_end < 0:
            return Decision("unterminated backtick substitution is fail-closed", "shell_dynamic_expansion")
        decision = _shell_decision(command[backtick_start + 1 : backtick_end], depth + 1)
        if decision:
            return decision
        backtick_start = command.find("`", backtick_end + 1)
    return None


def _indirect_write_decision(command: str) -> Decision | None:
    variable = r"(?:\$[A-Za-z_0-9@*#?!-][A-Za-z0-9_]*|\$\{[^}\n]+\})"
    if re.search(rf">{{1,2}}\s*['\"]?{variable}", command):
        return Decision("variable-indirect output target is fail-closed", "shell_indirect_write")
    if re.search(rf"(?:^|[;&|]\s*|\s)(?:tee|cp|mv|install|chmod|chown|sed\s+-i)\b[^\n]*{variable}", command):
        return Decision("variable-indirect mutation target is fail-closed", "shell_indirect_write")
    return None


def _shell_decision(command: str, depth: int = 0) -> Decision | None:
    decision = _command_substitution_decision(command, depth)
    if decision:
        return decision
    decision = _indirect_write_decision(command)
    if decision:
        return decision
    try:
        segments = _shell_segments(command)
    except ValueError:
        return Decision("unparseable shell input is fail-closed", "shell_parse_unknown")
    for segment in segments:
        decision = _simple_command_decision(segment)
        if decision:
            return decision
    return None


def _protected_edit_decision(tool_name: str, tool_input: Any) -> Decision | None:
    normalized = _normalized_tool_name(tool_name)
    if normalized not in EDIT_TOOL_NAMES:
        return None

    targets: list[str] = []
    if normalized == "apply_patch":
        patch = ""
        if isinstance(tool_input, dict):
            for key in ("patch", "input"):
                value = tool_input.get(key)
                if isinstance(value, str):
                    patch = value
                    break
        elif isinstance(tool_input, str):
            patch = tool_input
        for line in patch.splitlines():
            match = re.match(r"^\*\*\* (?:Add|Update|Delete) File:\s*(.+?)\s*$", line)
            if match:
                targets.append(match.group(1))
                continue
            move_match = re.match(r"^\*\*\* Move to:\s*(.+?)\s*$", line)
            if move_match:
                targets.append(move_match.group(1))
    else:
        def collect_paths(value: Any) -> None:
            if isinstance(value, dict):
                for key, item in value.items():
                    if key in {"file_path", "filePath", "path", "filename"} and isinstance(item, str):
                        targets.append(item)
                    elif key in {"edits", "files"}:
                        collect_paths(item)
            elif isinstance(value, list):
                for item in value:
                    collect_paths(item)

        collect_paths(tool_input)

    if any(_mentions_protected_path(target) for target in targets):
        return Decision("managed hook/config paths require the out-of-band admin plane", "managed_path_edit")
    return None


def _mentions_protected_path(command: str) -> bool:
    if any(marker in command for marker in PROTECTED_PATH_MARKERS):
        return True
    return bool(
        re.search(r"(?:^|[/\\\s'\"])\.codex[/\\](?:config\.toml|hooks)(?:[/\\]|\b)", command)
        or re.search(r"\$(?:\{)?CODEX_HOME(?:\})?[/\\](?:config\.toml|hooks)(?:[/\\]|\b)", command)
        or re.search(r"(?:^|[\s'\"=])(?:/)?etc[/\\]codex(?:[/\\]|\b)", command)
    )


def _protected_shell_write_decision(command: str) -> Decision | None:
    if not _mentions_protected_path(command):
        return None
    read_only_tools = {
        "[",
        "cat",
        "cmp",
        "diff",
        "find",
        "grep",
        "head",
        "less",
        "ls",
        "more",
        "readlink",
        "realpath",
        "rg",
        "sed",
        "sha256sum",
        "stat",
        "tail",
        "test",
        "wc",
    }
    try:
        segments = _shell_segments(command)
    except ValueError:
        return Decision("managed path command could not be parsed safely", "managed_path_shell_write")

    def protected_redirect_target(tokens: list[str]) -> bool:
        for index, token in enumerate(tokens):
            match = re.match(r"^(?:\d*)>>?(.*)$", token)
            if not match:
                continue
            target = match.group(1)
            if not target and index + 1 < len(tokens):
                target = tokens[index + 1]
            if target and target not in {"&1", "&2"} and _mentions_protected_path(target):
                return True
        return False

    def positional_args(tokens: list[str]) -> list[str]:
        values: list[str] = []
        skip_next = False
        for token in tokens:
            if skip_next:
                skip_next = False
                continue
            if re.match(r"^(?:\d*)>>?$", token):
                skip_next = True
                continue
            if re.match(r"^(?:\d*)>>?.+", token):
                continue
            if token.startswith("-"):
                continue
            values.append(token)
        return values

    for segment in segments:
        if not _mentions_protected_path(" ".join(segment)):
            continue
        unwrapped = _unwrap_command(segment)
        if not unwrapped:
            return Decision("managed hook/config paths require the out-of-band admin plane", "managed_path_shell_write")
        executable = Path(unwrapped[0]).name.lower()
        args = unwrapped[1:]
        if protected_redirect_target(args):
            return Decision("managed hook/config paths require the out-of-band admin plane", "managed_path_shell_write")
        if executable == "sed" and any(token == "-i" or token.startswith("-i") for token in args):
            return Decision("managed hook/config paths require the out-of-band admin plane", "managed_path_shell_write")
        if executable in {"rm", "mv", "chmod", "chown", "tee"}:
            return Decision("managed hook/config paths require the out-of-band admin plane", "managed_path_shell_write")
        if executable in {"cp", "install"}:
            operands = positional_args(args)
            destination = operands[-1] if operands else ""
            if destination and _mentions_protected_path(destination):
                return Decision("managed hook/config paths require the out-of-band admin plane", "managed_path_shell_write")
            if executable == "install" or not destination:
                return Decision("managed hook/config paths require the out-of-band admin plane", "managed_path_shell_write")
            continue
        if executable not in read_only_tools:
            return Decision("managed hook/config paths require the out-of-band admin plane", "managed_path_shell_write")
    return None


def _external_tool_decision(tool_name: str) -> Decision | None:
    name = _normalized_tool_name(tool_name)
    if name in SHELL_TOOL_NAMES or name in EDIT_TOOL_NAMES:
        return None
    risky_domain = re.search(r"adb|kakao|payment|bank|order|firebase", name)
    risky_action = re.search(r"(?:^|__|/|_)(?:delete|remove|destroy|send|purchase|pay|install|uninstall|force_stop)(?:$|__|/|_)", name)
    if risky_domain and risky_action:
        return Decision("external live/destructive tool requires its application safety flow", "external_risky_tool")
    return None


def pre_tool_decision(data: dict[str, Any]) -> Decision | None:
    tool_name = _tool_name(data)
    tool_input = _tool_input(data)
    decision = _protected_edit_decision(tool_name, tool_input)
    if decision:
        return decision

    normalized = _normalized_tool_name(tool_name)
    if normalized in SHELL_TOOL_NAMES:
        command = _command_from_input(tool_input)
        decision = _protected_shell_write_decision(command)
        if decision:
            return decision
        decision = _shell_decision(command)
        if decision:
            return decision
    return _external_tool_decision(tool_name)


def _state_dir(env: dict[str, str]) -> Path:
    value = env.get(STATE_DIR_ENV)
    return Path(value).expanduser() if value else DEFAULT_STATE_DIR


def _safe_identifier(value: Any) -> str:
    text = str(value or "unknown")
    if re.fullmatch(r"[A-Za-z0-9_.-]{1,128}", text):
        return text
    return hashlib.sha256(text.encode("utf-8", "replace")).hexdigest()[:32]


def _prepare_state_dir(root: Path) -> None:
    root.mkdir(parents=True, exist_ok=True, mode=0o700)
    root.chmod(0o700)


def _atomic_json(path: Path, payload: dict[str, Any]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True, mode=0o700)
    encoded = json.dumps(payload, ensure_ascii=False, sort_keys=True, indent=2) + "\n"
    temporary = path.with_name(path.name + f".tmp-{os.getpid()}")
    with temporary.open("w", encoding="utf-8") as handle:
        os.chmod(temporary, 0o600)
        handle.write(encoded)
        handle.flush()
        os.fsync(handle.fileno())
    os.replace(temporary, path)


def _append_jsonl(path: Path, payload: dict[str, Any]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True, mode=0o700)
    with path.open("a", encoding="utf-8") as handle:
        os.chmod(path, 0o600)
        handle.write(json.dumps(payload, ensure_ascii=False, sort_keys=True) + "\n")
        handle.flush()
        os.fsync(handle.fileno())


def _with_state_lock(root: Path, callback: Any) -> None:
    _prepare_state_dir(root)
    lock_path = root / "state.lock"
    with lock_path.open("a+", encoding="utf-8") as lock:
        os.chmod(lock_path, 0o600)
        fcntl.flock(lock.fileno(), fcntl.LOCK_EX)
        callback()
        fcntl.flock(lock.fileno(), fcntl.LOCK_UN)


def record_session_start(data: dict[str, Any], env: dict[str, str]) -> Path:
    root = _state_dir(env)
    session_id = _safe_identifier(data.get("session_id"))
    session_path = root / "sessions" / f"{session_id}.json"
    now = _utc_now()

    def update() -> None:
        existing: dict[str, Any] = {}
        if session_path.exists():
            try:
                existing = json.loads(session_path.read_text(encoding="utf-8"))
            except (OSError, json.JSONDecodeError):
                existing = {}
        start_count = int(existing.get("startCount", 0)) + 1
        source = str(data.get("source") or "unknown")
        record = {
            "policyVersion": POLICY_VERSION,
            "sessionId": str(data.get("session_id") or "unknown"),
            "state": "active",
            "source": source,
            "cwd": str(data.get("cwd") or ""),
            "transcriptPathHash": _sha256_value(data.get("transcript_path")),
            "firstStartedAt": existing.get("firstStartedAt", now),
            "lastStartedAt": now,
            "startCount": start_count,
            "reloadCount": int(existing.get("reloadCount", 0)) + int(source in {"resume", "clear", "compact"}),
        }
        active_path = root / "active.json"
        active: dict[str, Any] = {}
        if active_path.exists():
            try:
                active = json.loads(active_path.read_text(encoding="utf-8"))
            except (OSError, json.JSONDecodeError):
                active = {}
        previous_session = active.get("currentSessionId") or active.get("sessionId")
        sessions = active.get("sessions") if isinstance(active.get("sessions"), dict) else {}
        sessions[record["sessionId"]] = {
            "lastStartedAt": now,
            "source": source,
            "state": "active",
        }
        record["previousActiveSessionId"] = previous_session
        _atomic_json(session_path, record)
        _atomic_json(
            active_path,
            {
                "policyVersion": POLICY_VERSION,
                "currentSessionId": record["sessionId"],
                "lastStartedAt": now,
                "source": source,
                "handoffFrom": previous_session,
                "sessions": sessions,
            },
        )
        _append_jsonl(
            root / "lifecycle.jsonl",
            {
                "event": "session_start",
                "policyVersion": POLICY_VERSION,
                "sessionId": record["sessionId"],
                "source": source,
                "timestamp": now,
            },
        )

    _with_state_lock(root, update)
    return session_path


def _tool_response(data: dict[str, Any]) -> Any:
    for key in ("tool_response", "toolResponse", "tool_output", "toolOutput", "tool_result", "toolResult"):
        if key in data:
            return data[key]
    return None


def _redaction_flags(value: Any) -> list[str]:
    text = _compact_json(value)
    return sorted(name for name, pattern in SENSITIVE_PATTERNS.items() if pattern.search(text))


def _tool_succeeded(response: Any) -> bool | None:
    if isinstance(response, dict):
        if response.get("isError") is True or response.get("error"):
            return False
        for key in ("exit_code", "exitCode", "returncode"):
            value = response.get(key)
            if isinstance(value, int):
                return value == 0
    return None


def _harmless_fresh_turn_probe(data: dict[str, Any]) -> str:
    if _normalized_tool_name(_tool_name(data)) not in SHELL_TOOL_NAMES:
        return ""
    command = _command_from_input(_tool_input(data)).strip()
    managed_read = "sed -n '1,5p' /" + "etc/codex/requirements.toml 2>/dev/null"
    return {
        "pwd": "ordinary_pwd",
        "/root/.local/bin/codex --version": "codex_version",
        "/root/.local/bin/codex exec --help": "codex_exec_help",
        managed_read: "managed_requirements_read",
    }.get(command, "")


def record_post_tool(data: dict[str, Any], env: dict[str, str]) -> tuple[Path, list[str]]:
    root = _state_dir(env)
    response = _tool_response(data)
    flags = _redaction_flags(response)
    harmless_probe = _harmless_fresh_turn_probe(data)
    succeeded = _tool_succeeded(response)
    if harmless_probe and succeeded is None:
        # Codex CLI 0.145 only constructs/runs PostToolUse after
        # success_for_logging() is true. Its shell tool_response is not an
        # exit-code mapping, so the event itself is the success evidence for
        # these four fixed harmless probes.
        succeeded = True
    receipt = {
        "event": "post_tool",
        "policyVersion": POLICY_VERSION,
        "timestamp": _utc_now(),
        "sessionId": str(data.get("session_id") or "unknown"),
        "turnId": str(data.get("turn_id") or "unknown"),
        "toolName": _tool_name(data),
        "inputSha256": _sha256_value(_tool_input(data)),
        "outputSha256": _sha256_value(response),
        "succeeded": succeeded,
        "redactionFlags": flags,
    }
    if harmless_probe:
        receipt["harmlessFreshTurnProbe"] = harmless_probe
    date_key = dt.datetime.now(dt.timezone.utc).strftime("%Y-%m-%d")
    path = root / "receipts" / f"{date_key}.jsonl"
    _with_state_lock(root, lambda: _append_jsonl(path, receipt))
    return path, flags


def record_stop(data: dict[str, Any], env: dict[str, str]) -> None:
    root = _state_dir(env)
    session_id = _safe_identifier(data.get("session_id"))
    now = _utc_now()
    receipt = {
        "event": "turn_stop",
        "policyVersion": POLICY_VERSION,
        "timestamp": now,
        "sessionId": str(data.get("session_id") or "unknown"),
        "turnId": str(data.get("turn_id") or "unknown"),
    }

    def update() -> None:
        session_path = root / "sessions" / f"{session_id}.json"
        if session_path.exists():
            try:
                session = json.loads(session_path.read_text(encoding="utf-8"))
            except (OSError, json.JSONDecodeError):
                session = {"sessionId": receipt["sessionId"], "policyVersion": POLICY_VERSION}
            session["state"] = "idle"
            session["lastStoppedAt"] = now
            session["lastTurnId"] = receipt["turnId"]
            _atomic_json(session_path, session)

        active_path = root / "active.json"
        if active_path.exists():
            try:
                active = json.loads(active_path.read_text(encoding="utf-8"))
            except (OSError, json.JSONDecodeError):
                active = {}
            sessions = active.get("sessions") if isinstance(active.get("sessions"), dict) else {}
            entry = sessions.get(receipt["sessionId"])
            if isinstance(entry, dict):
                entry["state"] = "idle"
                entry["lastStoppedAt"] = now
            active["sessions"] = sessions
            active["lastStoppedSessionId"] = receipt["sessionId"]
            active["lastStoppedAt"] = now
            _atomic_json(active_path, active)
        _append_jsonl(root / "lifecycle.jsonl", receipt)

    _with_state_lock(root, update)


def _context_output(event: str, message: str) -> dict[str, Any]:
    return {
        "systemMessage": message,
        "hookSpecificOutput": {
            "hookEventName": event,
            "additionalContext": message,
        },
    }


def _deny_output(decision: Decision) -> dict[str, Any]:
    message = f"[{POLICY_VERSION}:{decision.code}] {decision.reason}"
    return {
        "systemMessage": message,
        "hookSpecificOutput": {
            "hookEventName": "PreToolUse",
            "permissionDecision": "deny",
            "permissionDecisionReason": message,
        },
    }


def handle(data: dict[str, Any], env: dict[str, str]) -> tuple[int, str, str]:
    event = _event_name(data).lower()
    if event == "sessionstart":
        try:
            record_session_start(data, env)
        except Exception:  # noqa: BLE001 - lifecycle evidence is warning-only
            pass
        message = (
            f"{POLICY_VERSION} active: ordinary work is allowed; destructive, live-business, "
            "and physical-device mutations stay fail-closed. Dynamic routing belongs to the dispatcher/broker."
        )
        return 0, json.dumps(_context_output("SessionStart", message), ensure_ascii=False), ""
    if event == "pretooluse":
        decision = pre_tool_decision(data)
        if decision is None:
            return 0, "", ""
        return 0, json.dumps(_deny_output(decision), ensure_ascii=False), ""
    if event == "posttooluse":
        try:
            _, flags = record_post_tool(data, env)
        except Exception:  # noqa: BLE001 - PostTool must never block ordinary work
            return 0, "", ""
        if flags:
            message = f"{POLICY_VERSION}: sensitive-looking tool output detected; raw values were not stored in receipts."
            return 0, json.dumps({"systemMessage": message}, ensure_ascii=False), ""
        return 0, "", ""
    if event == "stop":
        try:
            record_stop(data, env)
        except Exception:  # noqa: BLE001 - Stop receipt must be non-blocking
            pass
    return 0, "", ""


def _self_test() -> int:
    failures: list[str] = []
    allowed = (
        "pwd",
        "git status --short",
        "python3 -m pytest -q tests/test_example.py",
        "python3 scripts/factory_pc_direct_inject.py --help",
        "bash scripts/bootstrap_factory_cli_context.sh",
        "codex --help",
        "sed -n '1,20p' /etc/codex/requirements.toml",
    )
    denied = {
        "rm -rf build": "rm_recursive_force",
        "git reset --hard HEAD~1": "git_reset_hard",
        "git clean -fdx": "git_clean_force",
        "curl -X DELETE https://example.invalid/data": "network_delete",
        "adb devices -l": "adb_physical_boundary",
        "adb install app.apk": "adb_physical_boundary",
        "adb shell pm clear com.example": "adb_physical_boundary",
        "python3 worker.py --live-send": "live_business_mutation",
        "cp new.py /etc/codex/managed-hooks/hook.py": "managed_path_shell_write",
    }
    for command in allowed:
        decision = pre_tool_decision({"tool_name": "exec_command", "tool_input": {"cmd": command}})
        if decision is not None:
            failures.append(f"allowed command denied: {command}: {decision}")
    for command, expected in denied.items():
        decision = pre_tool_decision({"tool_name": "exec_command", "tool_input": {"cmd": command}})
        if decision is None or decision.code != expected:
            failures.append(f"denied command mismatch: {command}: {decision!r}, expected={expected}")
    edit_decision = pre_tool_decision(
        {"tool_name": "apply_patch", "tool_input": {"patch": "*** Update File: /etc/codex/requirements.toml"}}
    )
    if edit_decision is None or edit_decision.code != "managed_path_edit":
        failures.append(f"protected edit mismatch: {edit_decision!r}")

    with tempfile.TemporaryDirectory(prefix="minimal-managed-hook-test-") as temp:
        env = {STATE_DIR_ENV: temp}
        session = {
            "hook_event_name": "SessionStart",
            "session_id": "session-test",
            "source": "startup",
            "cwd": "/tmp",
            "transcript_path": "/tmp/transcript.jsonl",
        }
        handle(session, env)
        session["source"] = "resume"
        handle(session, env)
        session_data = json.loads((Path(temp) / "sessions" / "session-test.json").read_text())
        if session_data.get("startCount") != 2 or session_data.get("reloadCount") != 1:
            failures.append(f"session lifecycle mismatch: {session_data!r}")

        secret = "sk-test_secret_value_1234567890"
        post = {
            "hook_event_name": "PostToolUse",
            "session_id": "session-test",
            "turn_id": "turn-test",
            "tool_name": "exec_command",
            "tool_input": {"cmd": "status"},
            "tool_response": {"exit_code": 0, "output": f"token={secret}"},
        }
        code, _, _ = handle(post, env)
        receipts = "".join(path.read_text() for path in (Path(temp) / "receipts").glob("*.jsonl"))
        if code != 0 or secret in receipts or "openai_style_key" not in receipts:
            failures.append("post-tool receipt was blocking, leaked raw data, or missed redaction")

    if failures:
        for failure in failures:
            print(f"FAIL: {failure}", file=sys.stderr)
        return 1
    print(f"PASS: {POLICY_VERSION} self-test")
    return 0


def _load_input() -> dict[str, Any]:
    payload = json.load(sys.stdin)
    if not isinstance(payload, dict):
        raise ValueError("hook payload must be a JSON object")
    return payload


def main() -> int:
    if "--self-test" in sys.argv[1:]:
        return _self_test()
    try:
        data = _load_input()
        code, stdout, stderr = handle(data, dict(os.environ))
    except Exception as exc:  # noqa: BLE001
        print(f"{POLICY_VERSION}: {exc}", file=sys.stderr)
        return 1
    if stdout:
        print(stdout)
    if stderr:
        print(stderr, file=sys.stderr)
    return code


if __name__ == "__main__":
    raise SystemExit(main())
