#!/usr/bin/env python3
"""Pure recovery and reply-proposal state for the StoreBot Telegram backplane."""

from __future__ import annotations

import hashlib
import hmac
import json
from collections.abc import Mapping, Sequence
from typing import Any, Literal

try:
    from storebot_telegram_projection import (
        ProjectionValidationError,
        redact_projection_preview,
        validate_storebot_telegram_projection,
    )
except ModuleNotFoundError:  # pragma: no cover - package import in repo tests.
    from scripts.storebot_telegram_projection import (
        ProjectionValidationError,
        redact_projection_preview,
        validate_storebot_telegram_projection,
    )


Resource = Literal[
    "personal_gateway",
    "personal_wonmux_codex",
    "pc_codex_resource_01",
    "subphone_termux_ops",
    "com.sbotux",
]

RESOURCES = frozenset(
    {
        "personal_gateway",
        "personal_wonmux_codex",
        "pc_codex_resource_01",
        "subphone_termux_ops",
        "com.sbotux",
    }
)
DELEGATE_RESOURCES = ("pc_codex_resource_01",)
STOREBOT_RESOURCE = "com.sbotux"
WONMUX_PACKAGE = "com.wonmux"
SCHEMA = "storebot.telegram_backplane.v1"
DELEGATE_RESULT_SCHEMA = "storebot.telegram_delegate_result.v1"
MAX_RESULT_TTL_MS = 5 * 60_000
MAX_PROPOSAL_TTL_MS = 2 * 60_000
DELEGATE_RESULT_KEYS = frozenset(
    {
        "schema",
        "request_id",
        "correlation_id",
        "occurrence_id",
        "source_projection_id",
        "target_resource",
        "lease_owner",
        "lease_epoch",
        "fencing_token",
        "result_ref",
        "result_hash",
        "evidence_hash",
        "status",
        "expires_at_ms",
        "no_send",
        "sent",
    }
)
REPLY_PROPOSAL_KEYS = frozenset(
    {
        "schema",
        "proposal_id",
        "request_id",
        "correlation_id",
        "occurrence_id",
        "room_id",
        "proposal_revision",
        "text_hash",
        "lease_owner",
        "lease_epoch",
        "fencing_token",
        "expires_at_ms",
        "redacted_preview",
        "guarded_outbound_candidate",
        "proposal",
        "sent",
    }
)


class BackplaneValidationError(ValueError):
    pass


def _hash(prefix: str, value: Mapping[str, Any]) -> str:
    encoded = json.dumps(value, ensure_ascii=False, sort_keys=True, separators=(",", ":"))
    return f"{prefix}_{hashlib.sha256(encoded.encode('utf-8')).hexdigest()[:24]}"


def _identity_key(value: bytes | str) -> bytes:
    key = value.encode("utf-8") if isinstance(value, str) else bytes(value)
    if len(key) < 32:
        raise BackplaneValidationError("identity_key must contain at least 32 bytes")
    return key


def _secret_hash(prefix: str, identity_key: bytes | str, value: Mapping[str, Any]) -> str:
    encoded = json.dumps(value, ensure_ascii=False, sort_keys=True, separators=(",", ":")).encode("utf-8")
    return f"{prefix}_{hmac.new(_identity_key(identity_key), encoded, hashlib.sha256).hexdigest()[:32]}"


def _resource(value: Any, *, field: str) -> str:
    result = str(value or "").strip()
    if result == WONMUX_PACKAGE:
        raise BackplaneValidationError(f"{WONMUX_PACKAGE} is gateway-only, not {field}")
    if result not in RESOURCES:
        raise BackplaneValidationError(f"unknown {field}: {result or '<empty>'}")
    return result


def _validate_owner_boundary(state: Mapping[str, Any]) -> None:
    if not {"gateway_package", "app_resource", "kakao_transport_owner"}.issubset(state):
        raise BackplaneValidationError("gateway, app, and transport ownership fields are required")
    gateway_package = str(state.get("gateway_package") or "")
    if gateway_package != WONMUX_PACKAGE:
        raise BackplaneValidationError("gateway_package must be com.wonmux")
    app_resource = str(state.get("app_resource") or "")
    transport_owner = str(state.get("kakao_transport_owner") or "")
    if app_resource != STOREBOT_RESOURCE or transport_owner != STOREBOT_RESOURCE:
        raise BackplaneValidationError("Kakao app and transport ownership must remain com.sbotux")


def _decision(action: str, *, target: str = "", **extra: Any) -> dict[str, Any]:
    result = {
        "schema": SCHEMA,
        "action": action,
        "target_resource": target,
        "proposal": action in {"wake_primary", "delegate_analysis", "ca_escalation"},
        "no_send": True,
        "sent": False,
    }
    result.update(extra)
    return result


def decide_recovery_action(state: Mapping[str, Any], now_ms: int) -> dict[str, Any]:
    """Choose one bounded recovery proposal without performing any action."""

    if not isinstance(state, Mapping):
        raise BackplaneValidationError("state must be a mapping")
    _validate_owner_boundary(state)
    current = int(now_ms)
    projection = state.get("source_projection")
    try:
        validate_storebot_telegram_projection(projection, now_ms=current)
    except (ProjectionValidationError, TypeError) as exc:
        raise BackplaneValidationError("source_projection is invalid") from exc

    primary = state.get("primary") if isinstance(state.get("primary"), Mapping) else {}
    primary_resource = _resource(primary.get("resource") or "subphone_termux_ops", field="primary resource")
    fresh_for_ms = max(0, int(state.get("primary_fresh_for_ms") or 30_000))
    last_seen_ms = int(primary.get("last_seen_ms") or 0)
    primary_available = primary.get("available") is not False
    heartbeat_future = last_seen_ms > current + 30_000
    if primary_available and not heartbeat_future and last_seen_ms > 0 and current - last_seen_ms <= fresh_for_ms:
        return _decision("none", reason="primary_fresh")

    wake = state.get("wake") if isinstance(state.get("wake"), Mapping) else {}
    attempted_at_ms = int(wake.get("attempted_at_ms") or 0)
    wake_timeout_ms = max(0, int(state.get("wake_timeout_ms") or 20_000))
    cooldown_ms = max(0, int(state.get("wake_cooldown_ms") or 10_000))
    if attempted_at_ms <= 0:
        occurrence = str(projection["projection_id"])
        return _decision(
            "wake_primary",
            target=primary_resource,
            reason="primary_stale_first_attempt",
            occurrence_id=_hash("stocc", {"projection": occurrence, "phase": "wake"}),
            cooldown_until_ms=current + cooldown_ms,
        )
    if current < attempted_at_ms + wake_timeout_ms or current < attempted_at_ms + cooldown_ms:
        return _decision(
            "wait",
            target=primary_resource,
            reason="wake_cooldown",
            retry_at_ms=max(attempted_at_ms + wake_timeout_ms, attempted_at_ms + cooldown_ms),
        )

    delegate = state.get("delegate") if isinstance(state.get("delegate"), Mapping) else {}
    current_epoch = max(0, int(delegate.get("analysis_epoch") or 0))
    already_requested = bool(delegate.get("requested") is True or current_epoch > 0)
    available = frozenset(str(item) for item in state.get("available_resources", ()))
    target = next((item for item in DELEGATE_RESOURCES if item in available), "")
    if not already_requested and target:
        next_epoch = current_epoch + 1
        cas_key = _hash(
            "stcas",
            {
                "projection": projection["projection_id"],
                "analysis_epoch": next_epoch,
                "target": target,
            },
        )
        return _decision(
            "delegate_analysis",
            target=target,
            reason="primary_wake_timeout",
            analysis_epoch=next_epoch,
            cas_intent_key=cas_key,
            cas_expected_epoch=current_epoch,
        )
    if already_requested and str(delegate.get("status") or "").lower() in {"requested", "claimed", "started", "running"}:
        return _decision(
            "wait",
            target=str(delegate.get("resource") or target),
            reason="delegate_inflight",
            analysis_epoch=current_epoch,
        )
    return _decision(
        "ca_escalation",
        target="personal_gateway",
        reason="all_recovery_resources_unavailable",
        intent={"category": "ca_incident", "proposal": True, "sent": False},
    )


def build_delegate_result(
    state: Mapping[str, Any],
    *,
    private_result: Mapping[str, Any],
    private_evidence: Sequence[Any],
    identity_key: bytes | str,
    now_ms: int,
    expires_at_ms: int,
) -> dict[str, Any]:
    if not isinstance(private_result, Mapping) or not private_result:
        raise BackplaneValidationError("non-empty private_result is required")
    if isinstance(private_evidence, (str, bytes)) or not isinstance(private_evidence, Sequence) or not private_evidence:
        raise BackplaneValidationError("non-empty private_evidence is required")
    projection = state.get("source_projection")
    try:
        validate_storebot_telegram_projection(projection, now_ms=int(now_ms))
    except (ProjectionValidationError, TypeError) as exc:
        raise BackplaneValidationError("source_projection is invalid") from exc
    delegate = state.get("delegate") if isinstance(state.get("delegate"), Mapping) else {}
    expiry = int(expires_at_ms)
    if not int(now_ms) < expiry <= int(now_ms) + MAX_RESULT_TTL_MS:
        raise BackplaneValidationError("delegate result expiry is invalid")
    result_hash = _secret_hash("stresult", identity_key, private_result)
    evidence_hash = _secret_hash("stevidence", identity_key, {"items": list(private_evidence)})
    binding = {
        "source_projection_id": projection["projection_id"],
        "occurrence_id": str(state.get("occurrence_id") or ""),
        "target_resource": str(delegate.get("resource") or ""),
        "lease_owner": str(delegate.get("lease_owner") or ""),
        "lease_epoch": int(delegate.get("lease_epoch") or 0),
        "fencing_token": str(delegate.get("fencing_token") or ""),
        "result_hash": result_hash,
        "evidence_hash": evidence_hash,
    }
    result = {
        "schema": DELEGATE_RESULT_SCHEMA,
        "request_id": projection["request_id"],
        "correlation_id": projection["correlation_id"],
        **binding,
        "result_ref": _secret_hash("stresultref", identity_key, binding),
        "status": "complete",
        "expires_at_ms": expiry,
        "no_send": True,
        "sent": False,
    }
    if frozenset(result) != DELEGATE_RESULT_KEYS:
        raise BackplaneValidationError("delegate result schema mismatch")
    return result


def accept_delegate_result(
    state: Mapping[str, Any],
    result: Mapping[str, Any],
    now_ms: int,
    *,
    private_result: Mapping[str, Any],
    private_evidence: Sequence[Any],
    identity_key: bytes | str,
) -> dict[str, Any]:
    """Fence results unless private content, evidence, source, and lease all match."""

    delegate = state.get("delegate") if isinstance(state.get("delegate"), Mapping) else {}
    try:
        expected = build_delegate_result(
            state,
            private_result=private_result,
            private_evidence=private_evidence,
            identity_key=identity_key,
            now_ms=int(now_ms),
            expires_at_ms=int(result.get("expires_at_ms") or 0),
        )
        _resource(expected["target_resource"], field="delegate target")
        _resource(expected["lease_owner"], field="delegate lease owner")
    except BackplaneValidationError:
        return {"accepted": False, "reason": "invalid_delegate_binding", "no_send": True, "sent": False}
    expires_at_ms = int(result.get("expires_at_ms") or 0)
    accepted = (
        frozenset(result) == DELEGATE_RESULT_KEYS
        and expected["target_resource"] in DELEGATE_RESOURCES
        and expected["lease_owner"] == expected["target_resource"]
        and expected["lease_epoch"] > 0
        and expected["fencing_token"].startswith("stfence_")
        and dict(result) == expected
        and int(now_ms) <= expires_at_ms <= int(now_ms) + MAX_RESULT_TTL_MS
    )
    return {
        "accepted": accepted,
        "reason": "accepted" if accepted else "fenced_late_or_old_epoch",
        "source_projection_id": str(result.get("source_projection_id") or ""),
        "result_hash": str(result.get("result_hash") or ""),
        "no_send": True,
        "sent": False,
    }


def build_reply_proposal(
    source_projection: Mapping[str, Any],
    *,
    occurrence_id: str,
    room_id: str,
    proposal_revision: int,
    redacted_preview: str,
    lease_owner: Resource,
    lease_epoch: int,
    fencing_token: str,
    expires_at_ms: int,
    now_ms: int,
    identity_key: bytes | str,
) -> dict[str, Any]:
    validate_storebot_telegram_projection(source_projection, now_ms=int(now_ms))
    owner = _resource(lease_owner, field="lease owner")
    if owner not in DELEGATE_RESOURCES:
        raise BackplaneValidationError("lease owner must be an approved delegate")
    if not str(occurrence_id).startswith("stocc_") or not str(room_id).startswith("stroom_"):
        raise BackplaneValidationError("occurrence_id and room_id must be opaque")
    if not str(fencing_token).startswith("stfence_"):
        raise BackplaneValidationError("fencing_token must be opaque")
    if int(proposal_revision) <= 0 or int(lease_epoch) <= 0:
        raise BackplaneValidationError("proposal_revision and lease_epoch must be positive")
    if not int(now_ms) < int(expires_at_ms) <= int(now_ms) + MAX_PROPOSAL_TTL_MS:
        raise BackplaneValidationError("proposal expiry is outside the bounded window")
    preview = redact_projection_preview(redacted_preview)
    text_hash = _secret_hash("sttxt", identity_key, {"redacted_preview": preview})
    identity = {
        "request_id": source_projection["request_id"],
        "correlation_id": source_projection["correlation_id"],
        "occurrence_id": occurrence_id,
        "room_id": room_id,
        "proposal_revision": int(proposal_revision),
        "text_hash": text_hash,
        "lease_owner": owner,
        "lease_epoch": int(lease_epoch),
        "fencing_token": fencing_token,
        "expires_at_ms": int(expires_at_ms),
    }
    return {
        "schema": SCHEMA,
        "proposal_id": _secret_hash("stproposal", identity_key, identity),
        **identity,
        "redacted_preview": preview,
        "guarded_outbound_candidate": False,
        "proposal": True,
        "sent": False,
    }


def accept_reply_proposal(
    proposal: Mapping[str, Any],
    *,
    current_request_id: str,
    current_correlation_id: str,
    current_occurrence_id: str,
    current_room_id: str,
    current_proposal_revision: int,
    current_lease_owner: Resource,
    current_lease_epoch: int,
    current_fencing_token: str,
    current_text_hash: str,
    now_ms: int,
    identity_key: bytes | str,
) -> dict[str, Any]:
    owner = _resource(current_lease_owner, field="current lease owner")
    preview = str(proposal.get("redacted_preview") or "")
    recomputed_text_hash = _secret_hash("sttxt", identity_key, {"redacted_preview": preview})
    identity = {
        "request_id": proposal.get("request_id"),
        "correlation_id": proposal.get("correlation_id"),
        "occurrence_id": proposal.get("occurrence_id"),
        "room_id": proposal.get("room_id"),
        "proposal_revision": int(proposal.get("proposal_revision") or 0),
        "text_hash": proposal.get("text_hash"),
        "lease_owner": proposal.get("lease_owner"),
        "lease_epoch": int(proposal.get("lease_epoch") or 0),
        "fencing_token": proposal.get("fencing_token"),
        "expires_at_ms": int(proposal.get("expires_at_ms") or 0),
    }
    expires_at_ms = int(proposal.get("expires_at_ms") or 0)
    matches = (
        frozenset(proposal) == REPLY_PROPOSAL_KEYS
        and proposal.get("schema") == SCHEMA
        and proposal.get("proposal_id") == _secret_hash("stproposal", identity_key, identity)
        and proposal.get("proposal") is True
        and proposal.get("guarded_outbound_candidate") is False
        and preview == redact_projection_preview(preview)
        and proposal.get("text_hash") == recomputed_text_hash
        and proposal.get("request_id") == current_request_id
        and proposal.get("correlation_id") == current_correlation_id
        and proposal.get("occurrence_id") == current_occurrence_id
        and proposal.get("room_id") == current_room_id
        and int(proposal.get("proposal_revision") or 0) == int(current_proposal_revision)
        and proposal.get("lease_owner") == owner
        and int(proposal.get("lease_epoch") or 0) == int(current_lease_epoch)
        and proposal.get("fencing_token") == current_fencing_token
        and proposal.get("text_hash") == current_text_hash
        and int(now_ms) < expires_at_ms <= int(now_ms) + MAX_PROPOSAL_TTL_MS
        and proposal.get("sent") is False
    )
    return {
        "proposal_id": str(proposal.get("proposal_id") or ""),
        "accepted": matches,
        "reason": "exact_guard_match" if matches else "fenced_or_expired",
        "guarded_outbound_candidate": matches,
        "sent": False,
    }
