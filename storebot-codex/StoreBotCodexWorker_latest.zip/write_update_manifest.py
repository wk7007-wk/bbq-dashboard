#!/usr/bin/env python3
from __future__ import annotations

import argparse
import json
from pathlib import Path


def write_json(path: Path, payload: dict) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(payload, ensure_ascii=False, indent=2, sort_keys=True) + "\n", encoding="utf-8")


def read_json(path: Path) -> dict:
    if not path.exists():
        return {}
    try:
        data = json.loads(path.read_text(encoding="utf-8"))
    except Exception:
        return {}
    return data if isinstance(data, dict) else {}


def compact(value: str, limit: int = 1000) -> str:
    text = " ".join(str(value or "").split())
    return text[:limit].strip()


def history_url(artifact_url: str, history_name: str) -> str:
    base = str(artifact_url or "").rsplit("/", 1)[0]
    return f"{base}/{history_name}" if base else history_name


def build_history(args: argparse.Namespace, manifest: dict) -> dict:
    history_path = Path(args.host_dir) / args.history_name
    previous = read_json(history_path)
    entries = previous.get("entries")
    if not isinstance(entries, list):
        entries = []

    entry = {
        "appVersionCode": int(args.version_code),
        "appVersionName": args.version_name,
        "artifactUrl": args.artifact_url,
        "channel": args.channel_id,
        "label": args.label,
        "releaseNotes": args.release_notes,
        "sha256": args.artifact_sha256,
        "updatedAt": args.updated_at,
    }
    filtered = [
        item
        for item in entries
        if not (
            isinstance(item, dict)
            and int(item.get("appVersionCode") or -1) == int(args.version_code)
            and str(item.get("channel") or "") == args.channel_id
        )
    ]
    return {
        "channel": args.channel_id,
        "entries": [entry, *filtered][: max(1, int(args.history_limit))],
        "label": args.label,
        "latest": entry,
        "latestManifest": manifest,
        "schemaVersion": 1,
        "updatedAt": args.updated_at,
    }


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description="Write update-center manifest and release history")
    parser.add_argument("--host-dir", required=True)
    parser.add_argument("--channel-id", required=True)
    parser.add_argument("--label", required=True)
    parser.add_argument("--version-code", required=True, type=int)
    parser.add_argument("--version-name", required=True)
    parser.add_argument("--artifact-url", required=True)
    parser.add_argument("--artifact-sha256", required=True)
    parser.add_argument("--release-notes", required=True)
    parser.add_argument("--updated-at", required=True)
    parser.add_argument("--manifest-name", default="version.json")
    parser.add_argument("--history-name", default="history.json")
    parser.add_argument("--history-limit", default=50, type=int)
    return parser.parse_args()


def main() -> int:
    args = parse_args()
    host_dir = Path(args.host_dir)
    notes = compact(args.release_notes) or f"{args.label} 업데이트"
    args.release_notes = notes
    manifest = {
        "appVersionCode": int(args.version_code),
        "appVersionName": args.version_name,
        "apkUrl": args.artifact_url,
        "enabled": True,
        "historyUrl": history_url(args.artifact_url, args.history_name),
        "releaseNotes": notes,
        "sha256": args.artifact_sha256,
        "updatedAt": args.updated_at,
    }
    write_json(host_dir / args.manifest_name, manifest)
    write_json(host_dir / args.history_name, build_history(args, manifest))
    print(f"update manifest written: {args.channel_id} {args.version_name} ({args.version_code})")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
