#!/usr/bin/env python3
from __future__ import annotations

import argparse
import copy
import hashlib
import json
import re
import sys
import time
from pathlib import Path
from typing import Any


KNOWLEDGE_ROOT = "/packhelper/ops_knowledge"
RAW_ITEMS_PATH = f"{KNOWLEDGE_ROOT}/raw_items"
STRUCTURED_SUMMARIES_PATH = f"{KNOWLEDGE_ROOT}/structured_summaries"
OUTPUT_VARIANTS_PATH = f"{KNOWLEDGE_ROOT}/output_variants"
DELETE_REQUESTS_PATH = f"{KNOWLEDGE_ROOT}/delete_requests"
QUEUE_PATH = f"{KNOWLEDGE_ROOT}/queue"
AUDIT_PATH = f"{KNOWLEDGE_ROOT}/audit"
OPS_MANUAL_ROOT = "/packhelper/ops_manual"
WORKSCHEDULE_V2_PATH = "/workschedule_v2"
WORKSCHEDULE_ATTENDANCE_PATH = f"{WORKSCHEDULE_V2_PATH}/attendance"
SCHEMA_VERSION = "operation_knowledge_write.v1"
MCP_CONTRACT_VERSION = "mcp_adapter_contract.v2"
HARD_DELETE_CONFIRM_PREFIX = "hard-delete:"
OUTPUT_VARIANT_KEYS = (
    "staff_brief",
    "manager_checklist",
    "search_answer",
    "kakao_reply",
    "site_manual_section",
)
DEFAULT_REQUESTED_OUTPUTS = ("structured_summary", *OUTPUT_VARIANT_KEYS)
OUTPUT_EXCLUDED_STATUSES = {"hidden", "held", "output_disabled", "deleted", "archived"}
WRITE_ACTIONS = {
    "operation_knowledge.ingest",
    "operation_knowledge.process_job",
    "operation_knowledge.process_queue",
    "operation_knowledge.upsert_summary",
    "operation_knowledge.upsert_output_variant",
    "operation_knowledge.soft_delete",
    "operation_knowledge.restore",
    "operation_knowledge.request_delete",
}


class OperationKnowledgeError(ValueError):
    """Raised when operation knowledge input violates the adapter contract."""


def now_ms() -> int:
    return int(time.time() * 1000)


def compact_text(value: Any, limit: int = 0) -> str:
    text = re.sub(r"\s+", " ", str(value or "").strip())
    if limit and len(text) > limit:
        return text[: max(0, limit - 1)].rstrip() + "..."
    return text


def unique_strings(items: list[Any]) -> list[str]:
    result: list[str] = []
    seen: set[str] = set()
    for item in items:
        text = compact_text(item)
        if not text:
            continue
        key = text.casefold()
        if key in seen:
            continue
        seen.add(key)
        result.append(text)
    return result


def as_list(value: Any) -> list[str]:
    if value is None or value == "":
        return []
    if isinstance(value, (list, tuple)):
        raw_items = list(value)
    elif isinstance(value, str):
        raw_items = re.split(r"[\n,]", value)
    else:
        raw_items = [value]
    return unique_strings(raw_items)


def normalize_requested_outputs(value: Any) -> list[str]:
    requested = as_list(value)
    if not requested:
        return list(DEFAULT_REQUESTED_OUTPUTS)
    allowed = set(DEFAULT_REQUESTED_OUTPUTS)
    return [item for item in requested if item in allowed]


def stable_id(prefix: str, payload: dict[str, Any]) -> str:
    encoded = json.dumps(payload, ensure_ascii=False, sort_keys=True, separators=(",", ":")).encode("utf-8")
    return f"{prefix}_{hashlib.sha256(encoded).hexdigest()[:16]}"


def sanitize_key(value: Any, fallback: str = "item") -> str:
    text = compact_text(value or fallback, 120)
    text = re.sub(r"[.#$/\[\]?\s]+", "_", text)
    text = re.sub(r"[^0-9A-Za-z가-힣_-]+", "_", text).strip("_")
    return (text or fallback)[:120]


def is_output_visible(item: dict[str, Any] | None) -> bool:
    if not isinstance(item, dict):
        return False
    status = compact_text(item.get("status") or "", 40).lower()
    visibility = compact_text(item.get("visibility") or "", 40).lower()
    if bool(item.get("deleted")):
        return False
    if status in OUTPUT_EXCLUDED_STATUSES or visibility in OUTPUT_EXCLUDED_STATUSES:
        return False
    if item.get("output_enabled") is False or item.get("render_enabled") is False:
        return False
    return True


def int_or_default(value: Any, default: int = 0) -> int:
    try:
        return int(value)
    except (TypeError, ValueError):
        return default


def target_path(target_type: str, source_id: str) -> str:
    target = compact_text(target_type or "raw", 40).lower()
    item_id = sanitize_key(source_id)
    if target in {"raw", "raw_item", "input"}:
        return f"{RAW_ITEMS_PATH}/{item_id}"
    if target in {"summary", "structured_summary"}:
        return f"{STRUCTURED_SUMMARIES_PATH}/{item_id}"
    if target in {"output", "output_variant", "variant"}:
        return f"{OUTPUT_VARIANTS_PATH}/{item_id}"
    raise OperationKnowledgeError(f"unsupported target_type: {target_type}")


def normalize_raw_item(item: dict[str, Any]) -> dict[str, Any]:
    if not isinstance(item, dict):
        raise OperationKnowledgeError("raw item must be an object")
    text = str(item.get("text") or item.get("raw_text") or item.get("body") or item.get("content") or "").strip()
    if not text:
        raise OperationKnowledgeError("raw item text is required")
    raw = {
        "source": compact_text(item.get("source") or "manual_input", 120),
        "channel": compact_text(item.get("channel") or item.get("source_channel") or "site", 80),
        "text": text,
        "author": compact_text(item.get("author") or item.get("sender") or "", 80),
        "timestamp": item.get("timestamp") or item.get("timestamp_ms") or item.get("created_at_ms") or "",
        "tags": as_list(item.get("tags")),
        "source_path": compact_text(item.get("source_path") or "", 180),
        "raw_preserved": True,
    }
    raw["id"] = compact_text(item.get("id") or item.get("raw_id") or stable_id("raw", raw), 80)
    raw["status"] = compact_text(item.get("status") or "active", 40)
    return raw


def split_points(text: str) -> list[str]:
    lines = []
    for raw_line in str(text or "").replace("\r\n", "\n").split("\n"):
        line = compact_text(re.sub(r"^[#>\-\d.)\s]+", "", raw_line))
        if line:
            lines.append(line)
    if len(lines) <= 1:
        lines = [compact_text(part) for part in re.split(r"(?<=[.!?。])\s+|[;；]", compact_text(text)) if compact_text(part)]
    return unique_strings(lines)[:5]


def infer_category(text: str, tags: list[str]) -> str:
    blob = " ".join([text, *tags]).casefold()
    if any(token in blob for token in ("근무표", "스케줄", "shift", "schedule", "근무 변경")):
        return "schedule_request"
    if any(token in blob for token in ("출근", "퇴근", "attendance", "실근태")):
        return "attendance_record"
    if any(token in blob for token in ("운영메뉴얼", "manual", "규칙", "rule", "절차")):
        return "ops_manual"
    if any(token in blob for token in ("클레임", "고객", "complaint", "incident")):
        return "customer_incident"
    if any(token in blob for token in ("인건비", "매출", "리포트", "report", "분석")):
        return "analysis_report"
    return "general_ops"


def infer_audience(text: str, tags: list[str], category: str) -> str:
    blob = " ".join([text, category, *tags]).casefold()
    if any(token in blob for token in ("관리자", "manager", "승인", "검토", "checklist")):
        return "manager"
    if any(token in blob for token in ("직원", "staff", "crew", "브리핑")):
        return "staff"
    if category in {"schedule_request", "attendance_record", "analysis_report"}:
        return "manager"
    return "mixed"


def summarize_items(raw_items: list[dict[str, Any]]) -> str:
    first_points = []
    for raw in raw_items:
        points = split_points(raw["text"])
        if points:
            first_points.append(points[0])
    return compact_text(" / ".join(first_points), 220) if first_points else ""


def structure_raw_items(raw_items: list[dict[str, Any]] | dict[str, Any]) -> dict[str, Any]:
    normalized = [normalize_raw_item(item) for item in (raw_items if isinstance(raw_items, list) else [raw_items])]
    tags = unique_strings([tag for raw in normalized for tag in raw.get("tags", [])])
    text_blob = "\n".join(raw["text"] for raw in normalized)
    category = infer_category(text_blob, tags)
    key_points = unique_strings([point for raw in normalized for point in split_points(raw["text"])])[:7]
    citations = [
        {
            "source_id": raw["id"],
            "source": raw["source"],
            "channel": raw["channel"],
            "author": raw["author"],
            "timestamp": raw["timestamp"],
            "source_path": raw.get("source_path") or "",
        }
        for raw in normalized
    ]
    confidence = 0.72 if len(normalized) > 1 or tags else 0.58
    return {
        "id": stable_id("summary", {"source_ids": [raw["id"] for raw in normalized], "category": category}),
        "summary": summarize_items(normalized),
        "key_points": key_points,
        "category": category,
        "audience": infer_audience(text_blob, tags, category),
        "source_ids": [raw["id"] for raw in normalized],
        "citations": citations,
        "confidence": confidence,
        "status": "active",
        "source_contract": {
            "raw_preserved": True,
            "summary_is_derived": True,
            "summary_is_canonical_source": False,
            "canonical_schedule_source": WORKSCHEDULE_V2_PATH,
            "attendance_source": WORKSCHEDULE_ATTENDANCE_PATH,
            "summary_as_schedule_source_allowed": False,
        },
    }


def generate_output_variants(structured: dict[str, Any], query: str = "") -> dict[str, Any]:
    points = list(structured.get("key_points") or [])
    summary = compact_text(structured.get("summary"), 220)
    citations = list(structured.get("citations") or [])
    source_ids = list(structured.get("source_ids") or [])
    checklist = [f"확인: {point}" for point in points[:5]]
    if not checklist and summary:
        checklist = [f"확인: {summary}"]
    return {
        "staff_brief": {
            "text": compact_text(summary or "확인된 원문을 기준으로 직원용 브리핑을 준비합니다.", 260),
            "source_ids": source_ids,
            "citations": citations,
        },
        "manager_checklist": {
            "items": checklist,
            "source_ids": source_ids,
            "citations": citations,
        },
        "search_answer": {
            "query": compact_text(query, 160),
            "answer": compact_text(summary or (points[0] if points else ""), 320),
            "source_ids": source_ids,
            "citations": citations,
        },
        "kakao_reply": {
            "text": compact_text(summary or "원문 확인 후 답변할 내용입니다.", 180),
            "send_enabled": True,
            "send_guard": {
                "explicit_action_required": True,
                "room_guard_required": True,
                "mass_send_disabled": True,
                "audit_required": True,
            },
            "source_ids": source_ids,
            "citations": citations,
        },
        "site_manual_section": {
            "title": structured.get("category") or "general_ops",
            "summary": summary,
            "body": "\n".join(points),
            "source_ids": source_ids,
            "citations": citations,
        },
    }


def build_mcp_adapter_contract(mode: str = "write_enabled") -> dict[str, Any]:
    write_mode = mode in {"write_enabled", "live_enabled"}
    return {
        "schema_version": MCP_CONTRACT_VERSION,
        "mode": "write_enabled" if write_mode else "read_only_preview",
        "standard_concepts": ["resources", "tools", "prompts"],
        "resources": [
            {
                "name": "operation_knowledge.raw_items",
                "uri": "firebase://packhelper/ops_knowledge/raw_items",
                "source_path": RAW_ITEMS_PATH,
                "read_only": not write_mode,
                "canonical": False,
                "purpose": "preserve raw inputs with source metadata",
            },
            {
                "name": "operation_knowledge.structured_summaries",
                "uri": "firebase://packhelper/ops_knowledge/structured_summaries",
                "source_path": STRUCTURED_SUMMARIES_PATH,
                "read_only": not write_mode,
                "canonical": False,
                "purpose": "derived summaries and classifications",
            },
            {
                "name": "operation_knowledge.output_variants",
                "uri": "firebase://packhelper/ops_knowledge/output_variants",
                "source_path": OUTPUT_VARIANTS_PATH,
                "read_only": not write_mode,
                "canonical": False,
                "purpose": "derived output variants for site/search/Kakao",
            },
            {
                "name": "operation_knowledge.delete_requests",
                "uri": "firebase://packhelper/ops_knowledge/delete_requests",
                "source_path": DELETE_REQUESTS_PATH,
                "read_only": not write_mode,
                "canonical": False,
                "purpose": "reviewable delete requests and soft-delete intents",
            },
            {
                "name": "operation_knowledge.queue",
                "uri": "firebase://packhelper/ops_knowledge/queue",
                "source_path": QUEUE_PATH,
                "read_only": not write_mode,
                "canonical": False,
                "purpose": "background jobs for summaries, classification, and output variants",
            },
            {
                "name": "operation_knowledge.audit",
                "uri": "firebase://packhelper/ops_knowledge/audit",
                "source_path": AUDIT_PATH,
                "read_only": True,
                "canonical": False,
                "purpose": "append-only action audit records",
            },
            {
                "name": "workschedule.canonical_schedule",
                "uri": "firebase://workschedule_v2",
                "source_path": WORKSCHEDULE_V2_PATH,
                "read_only": True,
                "canonical": True,
                "purpose": "canonical schedule data source",
            },
            {
                "name": "ops_manual.entries",
                "uri": "firebase://packhelper/ops_manual/entries",
                "source_path": f"{OPS_MANUAL_ROOT}/entries",
                "read_only": False if write_mode else True,
                "canonical": True,
                "purpose": "approved operations manual entries",
            },
        ],
        "tools": [
            {
                "name": "operation_knowledge.preview_structure",
                "description": "Normalize raw items and return a derived summary without writing.",
                "annotations": {"readOnlyHint": True},
                "side_effects": "none",
                "mutates": False,
                "risk_level": "low",
            },
            {
                "name": "operation_knowledge.ingest",
                "description": "Persist a raw site/Kakao/manual input, audit, and pending background job without waiting for summary generation.",
                "annotations": {"readOnlyHint": False},
                "side_effects": "db_write",
                "mutates": True,
                "enabled": write_mode,
                "risk_level": "medium",
                "required_auth": "operator",
                "audit_required": True,
                "no_blocking_ai_on_ingest": True,
                "async_processing": True,
                "immediate_ack": True,
            },
            {
                "name": "operation_knowledge.process_job",
                "description": "Process one pending queue job into derived summary and output variants.",
                "annotations": {"readOnlyHint": False},
                "side_effects": "db_write",
                "mutates": True,
                "enabled": write_mode,
                "risk_level": "medium",
                "required_auth": "worker",
                "audit_required": True,
            },
            {
                "name": "operation_knowledge.process_queue",
                "description": "Process pending operation knowledge queue jobs in priority order.",
                "annotations": {"readOnlyHint": False},
                "side_effects": "db_write",
                "mutates": True,
                "enabled": write_mode,
                "risk_level": "medium",
                "required_auth": "worker",
                "audit_required": True,
            },
            {
                "name": "operation_knowledge.upsert_summary",
                "description": "Persist a structured summary derived from preserved raw input.",
                "annotations": {"readOnlyHint": False},
                "side_effects": "db_write",
                "mutates": True,
                "enabled": write_mode,
                "risk_level": "medium",
                "required_auth": "operator",
                "audit_required": True,
            },
            {
                "name": "operation_knowledge.upsert_output_variant",
                "description": "Persist a staff, manager, search, Kakao, or site output variant.",
                "annotations": {"readOnlyHint": False},
                "side_effects": "db_write",
                "mutates": True,
                "enabled": write_mode,
                "risk_level": "medium",
                "required_auth": "operator",
                "audit_required": True,
            },
            {
                "name": "operation_knowledge.request_delete",
                "description": "Create a reviewable delete request without hard deleting data.",
                "annotations": {"readOnlyHint": False},
                "side_effects": "db_write",
                "mutates": True,
                "enabled": write_mode,
                "risk_level": "medium",
                "required_auth": "operator",
                "audit_required": True,
                "hard_delete_disabled": True,
            },
            {
                "name": "operation_knowledge.soft_delete",
                "description": "Mark a raw input, summary, or output as deleted while preserving audit.",
                "annotations": {"readOnlyHint": False},
                "side_effects": "db_write",
                "mutates": True,
                "enabled": write_mode,
                "risk_level": "high",
                "required_auth": "owner",
                "audit_required": True,
                "hard_delete_disabled": True,
            },
            {
                "name": "operation_knowledge.restore",
                "description": "Restore a soft-deleted raw input, summary, or output.",
                "annotations": {"readOnlyHint": False},
                "side_effects": "db_write",
                "mutates": True,
                "enabled": write_mode,
                "risk_level": "medium",
                "required_auth": "owner",
                "audit_required": True,
            },
            {
                "name": "kakao.send_reply",
                "description": "Queue one explicit StoreBotTermux Kakao reply for a guarded room/action.",
                "annotations": {"readOnlyHint": False},
                "side_effects": "kakao_send_queue",
                "mutates": True,
                "enabled": write_mode,
                "risk_level": "high",
                "required_auth": "explicit_action",
                "audit_required": True,
                "room_guard_required": True,
                "mass_send_disabled": True,
            },
            {
                "name": "workschedule.apply_change",
                "description": "Schedule writes stay on the existing confirmed schedule flow.",
                "annotations": {"readOnlyHint": False},
                "side_effects": "db_write",
                "mutates": True,
                "enabled": True,
                "risk_level": "high",
                "required_auth": "confirmed_schedule_flow",
                "audit_required": True,
                "summary_as_schedule_source": False,
            },
        ],
        "prompts": [
            {
                "name": "operation_knowledge.summarize_with_citations",
                "description": "Summarize raw inputs while preserving source ids and citations.",
                "read_only": False,
                "write_tool_allowed": "operation_knowledge.upsert_summary",
                "audit_required": True,
            },
            {
                "name": "operation_knowledge.output_variant",
                "description": "Create output variants and optionally persist them.",
                "read_only": False,
                "write_tool_allowed": "operation_knowledge.upsert_output_variant",
                "kakao_send_requires_explicit_action": True,
            },
        ],
        "guards": {
            "read_only": not write_mode,
            "writes_enabled": write_mode,
            "firebase_writes_enabled": write_mode,
            "no_blocking_ai_on_ingest": True,
            "async_processing": True,
            "immediate_ack": True,
            "kakao_send_enabled": write_mode,
            "kakao_send_default_no_send": True,
            "explicit_action_required": True,
            "room_guard_required": True,
            "mass_send_disabled": True,
            "audit_required": True,
            "soft_delete_first": True,
            "hard_delete_disabled": True,
            "hard_delete_explicit_confirm_prefix": HARD_DELETE_CONFIRM_PREFIX,
            "canonical_schedule_source": WORKSCHEDULE_V2_PATH,
            "attendance_source": WORKSCHEDULE_ATTENDANCE_PATH,
            "summary_as_schedule_source_allowed": False,
        },
    }


def ensure_write_enabled_adapter_contract(contract: dict[str, Any]) -> None:
    if contract.get("mode") not in {"write_enabled", "live_enabled"}:
        raise OperationKnowledgeError("adapter contract must be write enabled")
    guards = contract.get("guards") if isinstance(contract.get("guards"), dict) else {}
    for key in (
        "writes_enabled",
        "firebase_writes_enabled",
        "kakao_send_enabled",
        "audit_required",
        "no_blocking_ai_on_ingest",
        "async_processing",
        "immediate_ack",
    ):
        if guards.get(key) is not True:
            raise OperationKnowledgeError(f"{key} must be true")
    if guards.get("hard_delete_disabled") is not True:
        raise OperationKnowledgeError("hard delete must stay disabled by default")
    if guards.get("canonical_schedule_source") != WORKSCHEDULE_V2_PATH:
        raise OperationKnowledgeError("canonical schedule source drift")
    if guards.get("summary_as_schedule_source_allowed") is not False:
        raise OperationKnowledgeError("summary cannot be a schedule source")
    tools = contract.get("tools") if isinstance(contract.get("tools"), list) else []
    names = {tool.get("name") for tool in tools if isinstance(tool, dict)}
    for required in WRITE_ACTIONS | {"kakao.send_reply", "workschedule.apply_change"}:
        if required not in names:
            raise OperationKnowledgeError(f"missing enabled tool: {required}")
    for tool in tools:
        if not isinstance(tool, dict):
            raise OperationKnowledgeError("tool contract must be an object")
        if tool.get("mutates") and tool.get("audit_required") is not True:
            raise OperationKnowledgeError(f"mutating tool must require audit: {tool.get('name')}")


def ensure_read_only_adapter_contract(contract: dict[str, Any]) -> None:
    if contract.get("mode") != "read_only_preview":
        raise OperationKnowledgeError("adapter contract must be read-only preview")
    guards = contract.get("guards") if isinstance(contract.get("guards"), dict) else {}
    for key in ("writes_enabled", "firebase_writes_enabled", "kakao_send_enabled"):
        if guards.get(key) is not False:
            raise OperationKnowledgeError(f"{key} must remain false")
    if guards.get("summary_as_schedule_source_allowed") is not False:
        raise OperationKnowledgeError("summary cannot be a schedule source")


def audit_record(
    *,
    actor: str,
    channel: str,
    source: str,
    action: str,
    source_id: str,
    before: Any = None,
    after: Any = None,
    status: str = "prepared",
    reason: str = "",
) -> dict[str, Any]:
    ts = now_ms()
    payload = {
        "schema_version": 1,
        "actor": compact_text(actor or "unknown", 120),
        "channel": compact_text(channel or "unknown", 80),
        "source": compact_text(source or "operation_knowledge_adapter", 120),
        "action": compact_text(action, 80),
        "source_id": compact_text(source_id, 120),
        "timestamp": ts,
        "timestamp_ms": ts,
        "before": before,
        "after": after,
        "status": compact_text(status, 60),
    }
    if reason:
        payload["reason"] = compact_text(reason, 300)
    payload["id"] = stable_id("audit", payload)
    return payload


def queue_job_payload(
    raw: dict[str, Any],
    *,
    actor: str = "unknown",
    channel: str = "",
    source: str = "",
    priority: int | None = None,
    requested_outputs: Any = None,
    job_type: str = "summary_and_outputs",
) -> dict[str, Any]:
    outputs = normalize_requested_outputs(requested_outputs)
    source_id = compact_text(raw.get("id"), 120)
    try:
        priority_value = int(priority if priority is not None else raw.get("priority") or 5)
    except (TypeError, ValueError):
        priority_value = 5
    job_id = stable_id(
        "opsq",
        {
            "source_id": source_id,
            "type": job_type,
            "requested_outputs": outputs,
            "actor": compact_text(actor or "unknown", 120),
            "channel": compact_text(channel or raw.get("channel") or "unknown", 80),
        },
    )
    ts = now_ms()
    return {
        "job_id": job_id,
        "source_id": source_id,
        "type": job_type,
        "status": "pending",
        "priority": priority_value,
        "created_at": ts,
        "created_at_ms": ts,
        "updated_at_ms": ts,
        "attempts": 0,
        "requested_outputs": outputs,
        "actor": compact_text(actor or "unknown", 120),
        "channel": compact_text(channel or raw.get("channel") or "unknown", 80),
        "source": compact_text(source or raw.get("source") or "operation_knowledge_adapter", 120),
        "source_path": f"{RAW_ITEMS_PATH}/{sanitize_key(source_id)}",
        "no_blocking_ai_on_ingest": True,
        "async_processing": True,
    }


def immediate_ack_payload(raw: dict[str, Any], job: dict[str, Any]) -> dict[str, Any]:
    text = compact_text(raw.get("text"), 120)
    return {
        "ok": True,
        "source_id": raw["id"],
        "queue_job_id": job["job_id"],
        "status": "accepted",
        "message": "반영됨. 정리 중입니다.",
        "minimal_output": {
            "variant_key": "ack",
            "text": "반영됨. 정리 중입니다.",
            "source_ids": [raw["id"]],
            "raw_preview": text,
        },
        "immediate_ack": True,
        "async_processing": True,
        "no_blocking_ai_on_ingest": True,
    }


def mutation_result(
    *,
    operation: str,
    writes: list[dict[str, Any]],
    audit: dict[str, Any],
    payload: dict[str, Any],
    mode: str = "payload",
    extra: dict[str, Any] | None = None,
) -> dict[str, Any]:
    result = {
        "ok": True,
        "schema_version": SCHEMA_VERSION,
        "mode": "write_enabled",
        "operation": operation,
        "backend": mode,
        "payload": payload,
        "writes": writes,
        "audit_record": audit,
        "firebase_payload": {"writes": writes, "audit": audit},
        "guards": build_mcp_adapter_contract()["guards"],
    }
    if extra:
        result.update(extra)
    return result


def ingest_raw_item(
    item: dict[str, Any],
    *,
    actor: str = "unknown",
    channel: str = "",
    source: str = "",
    before: Any = None,
    priority: int | None = None,
    requested_outputs: Any = None,
) -> dict[str, Any]:
    raw = normalize_raw_item(item)
    ts = now_ms()
    raw["updated_at_ms"] = ts
    raw.setdefault("created_at_ms", ts)
    raw["deleted"] = False
    raw.setdefault("visibility", "active")
    raw.setdefault("output_enabled", True)
    job = queue_job_payload(
        raw,
        actor=actor,
        channel=channel or raw["channel"],
        source=source or raw["source"],
        priority=priority,
        requested_outputs=requested_outputs or item.get("requested_outputs"),
    )
    ack = immediate_ack_payload(raw, job)
    audit = audit_record(
        actor=actor,
        channel=channel or raw["channel"],
        source=source or raw["source"],
        action="operation_knowledge.ingest",
        source_id=raw["id"],
        before=before,
        after=raw,
        status="prepared",
    )
    writes = [
        {"method": "put", "path": f"{RAW_ITEMS_PATH}/{sanitize_key(raw['id'])}", "value": raw},
        {"method": "put", "path": f"{QUEUE_PATH}/{sanitize_key(job['job_id'])}", "value": job},
        {"method": "put", "path": f"{AUDIT_PATH}/{sanitize_key(audit['id'])}", "value": audit},
    ]
    return mutation_result(
        operation="operation_knowledge.ingest",
        writes=writes,
        audit=audit,
        payload=raw,
        extra={
            "ack": ack,
            "queue_job": job,
            "queue_path": f"{QUEUE_PATH}/{sanitize_key(job['job_id'])}",
            "status": "accepted",
            "input_persisted": True,
            "summary_pending": True,
            "immediate_ack": True,
            "async_processing": True,
            "no_blocking_ai_on_ingest": True,
        },
    )


def upsert_structured_summary(
    summary: dict[str, Any] | None = None,
    *,
    raw_items: list[dict[str, Any]] | None = None,
    actor: str = "unknown",
    channel: str = "",
    source: str = "",
    before: Any = None,
) -> dict[str, Any]:
    if summary is None:
        if not raw_items:
            raise OperationKnowledgeError("summary or raw_items is required")
        summary = structure_raw_items(raw_items)
    if not isinstance(summary, dict):
        raise OperationKnowledgeError("summary must be an object")
    item = copy.deepcopy(summary)
    item["id"] = compact_text(item.get("id") or stable_id("summary", item), 80)
    item.setdefault("status", "active")
    item["updated_at_ms"] = now_ms()
    item["deleted"] = False
    item.setdefault("source_contract", {})
    item["source_contract"].update(
        {
            "summary_is_derived": True,
            "summary_is_canonical_source": False,
            "canonical_schedule_source": WORKSCHEDULE_V2_PATH,
            "attendance_source": WORKSCHEDULE_ATTENDANCE_PATH,
            "summary_as_schedule_source_allowed": False,
        }
    )
    audit = audit_record(
        actor=actor,
        channel=channel or "site",
        source=source or "operation_knowledge_adapter",
        action="operation_knowledge.upsert_summary",
        source_id=item["id"],
        before=before,
        after=item,
        status="prepared",
    )
    writes = [
        {"method": "put", "path": f"{STRUCTURED_SUMMARIES_PATH}/{sanitize_key(item['id'])}", "value": item},
        {"method": "put", "path": f"{AUDIT_PATH}/{sanitize_key(audit['id'])}", "value": audit},
    ]
    return mutation_result(operation="operation_knowledge.upsert_summary", writes=writes, audit=audit, payload=item)


def upsert_output_variant(
    variant_key: str,
    variant: dict[str, Any],
    *,
    actor: str = "unknown",
    channel: str = "",
    source: str = "",
    before: Any = None,
) -> dict[str, Any]:
    key = compact_text(variant_key, 80)
    if key not in OUTPUT_VARIANT_KEYS:
        raise OperationKnowledgeError(f"unsupported output variant: {variant_key}")
    if not isinstance(variant, dict):
        raise OperationKnowledgeError("variant must be an object")
    item = copy.deepcopy(variant)
    item["variant_key"] = key
    item["id"] = compact_text(item.get("id") or stable_id("output", {"variant_key": key, "variant": item}), 80)
    item["status"] = compact_text(item.get("status") or "active", 40)
    item["updated_at_ms"] = now_ms()
    item["deleted"] = False
    if key == "kakao_reply":
        item["send_enabled"] = bool(item.get("send_enabled", True))
        item["send_guard"] = {
            **{
                "explicit_action_required": True,
                "room_guard_required": True,
                "mass_send_disabled": True,
                "audit_required": True,
            },
            **(item.get("send_guard") if isinstance(item.get("send_guard"), dict) else {}),
        }
    audit = audit_record(
        actor=actor,
        channel=channel or "site",
        source=source or "operation_knowledge_adapter",
        action="operation_knowledge.upsert_output_variant",
        source_id=item["id"],
        before=before,
        after=item,
        status="prepared",
    )
    writes = [
        {"method": "put", "path": f"{OUTPUT_VARIANTS_PATH}/{sanitize_key(item['id'])}", "value": item},
        {"method": "put", "path": f"{AUDIT_PATH}/{sanitize_key(audit['id'])}", "value": audit},
    ]
    return mutation_result(operation="operation_knowledge.upsert_output_variant", writes=writes, audit=audit, payload=item)


def render_output_payload(
    structured: dict[str, Any],
    *,
    query: str = "",
    variant_key: str = "",
    actor: str = "unknown",
    channel: str = "",
    source: str = "",
    upsert: bool = False,
) -> dict[str, Any]:
    if not is_output_visible(structured):
        return {
            "ok": True,
            "schema_version": SCHEMA_VERSION,
            "mode": "write_enabled",
            "operation": "operation_knowledge.render_output",
            "output_variants": {},
            "variant_key": variant_key,
            "excluded": True,
            "exclude_reason": compact_text(structured.get("status") or structured.get("visibility") or "output_disabled", 80),
            "guards": build_mcp_adapter_contract()["guards"],
        }
    variants = generate_output_variants(structured, query=query)
    if not variant_key:
        return {
            "ok": True,
            "schema_version": SCHEMA_VERSION,
            "mode": "write_enabled",
            "operation": "operation_knowledge.render_output",
            "output_variants": variants,
            "guards": build_mcp_adapter_contract()["guards"],
        }
    if variant_key not in variants:
        raise OperationKnowledgeError(f"unsupported output variant: {variant_key}")
    if not upsert:
        return {
            "ok": True,
            "schema_version": SCHEMA_VERSION,
            "mode": "write_enabled",
            "operation": "operation_knowledge.render_output",
            "variant_key": variant_key,
            "output_variant": variants[variant_key],
            "guards": build_mcp_adapter_contract()["guards"],
        }
    return upsert_output_variant(variant_key, variants[variant_key], actor=actor, channel=channel, source=source)


def delete_request_payload(
    target_type: str,
    source_id: str,
    *,
    actor: str = "unknown",
    channel: str = "",
    source: str = "",
    reason: str = "",
) -> dict[str, Any]:
    target = target_path(target_type, source_id)
    request = {
        "id": stable_id("delete_req", {"target": target, "source_id": source_id, "reason": reason, "ts": now_ms()}),
        "target_type": compact_text(target_type, 40),
        "source_id": compact_text(source_id, 120),
        "target_path": target,
        "reason": compact_text(reason, 300),
        "status": "pending_review",
        "created_at_ms": now_ms(),
        "hard_delete": False,
        "soft_delete_first": True,
    }
    audit = audit_record(
        actor=actor,
        channel=channel or "site",
        source=source or "operation_knowledge_adapter",
        action="operation_knowledge.request_delete",
        source_id=source_id,
        before=None,
        after=request,
        status="prepared",
        reason=reason,
    )
    writes = [
        {"method": "put", "path": f"{DELETE_REQUESTS_PATH}/{sanitize_key(request['id'])}", "value": request},
        {"method": "put", "path": f"{AUDIT_PATH}/{sanitize_key(audit['id'])}", "value": audit},
    ]
    return mutation_result(operation="operation_knowledge.request_delete", writes=writes, audit=audit, payload=request)


def soft_delete_payload(
    target_type: str,
    source_id: str,
    *,
    actor: str = "unknown",
    channel: str = "",
    source: str = "",
    reason: str = "",
    before: Any = None,
) -> dict[str, Any]:
    patch = {
        "deleted": True,
        "status": "hidden",
        "visibility": "hidden",
        "output_enabled": False,
        "deleted_at_ms": now_ms(),
        "delete_reason": compact_text(reason, 300),
        "updated_at_ms": now_ms(),
    }
    path = target_path(target_type, source_id)
    audit = audit_record(
        actor=actor,
        channel=channel or "site",
        source=source or "operation_knowledge_adapter",
        action="operation_knowledge.soft_delete",
        source_id=source_id,
        before=before,
        after=patch,
        status="prepared",
        reason=reason,
    )
    writes = [
        {"method": "patch", "path": path, "value": patch},
        {"method": "put", "path": f"{AUDIT_PATH}/{sanitize_key(audit['id'])}", "value": audit},
    ]
    return mutation_result(operation="operation_knowledge.soft_delete", writes=writes, audit=audit, payload=patch)


def restore_payload(
    target_type: str,
    source_id: str,
    *,
    actor: str = "unknown",
    channel: str = "",
    source: str = "",
    before: Any = None,
) -> dict[str, Any]:
    patch = {
        "deleted": False,
        "status": "active",
        "visibility": "active",
        "output_enabled": True,
        "restored_at_ms": now_ms(),
        "updated_at_ms": now_ms(),
        "delete_reason": None,
    }
    path = target_path(target_type, source_id)
    audit = audit_record(
        actor=actor,
        channel=channel or "site",
        source=source or "operation_knowledge_adapter",
        action="operation_knowledge.restore",
        source_id=source_id,
        before=before,
        after=patch,
        status="prepared",
    )
    writes = [
        {"method": "patch", "path": path, "value": patch},
        {"method": "put", "path": f"{AUDIT_PATH}/{sanitize_key(audit['id'])}", "value": audit},
    ]
    return mutation_result(operation="operation_knowledge.restore", writes=writes, audit=audit, payload=patch)


def hard_delete_payload(
    target_type: str,
    source_id: str,
    *,
    explicit_confirm: str = "",
    actor: str = "unknown",
    channel: str = "",
    source: str = "",
    reason: str = "",
    before: Any = None,
) -> dict[str, Any]:
    expected = HARD_DELETE_CONFIRM_PREFIX + sanitize_key(source_id)
    if explicit_confirm != expected:
        raise OperationKnowledgeError("hard delete requires explicit_confirm token")
    path = target_path(target_type, source_id)
    audit = audit_record(
        actor=actor,
        channel=channel or "site",
        source=source or "operation_knowledge_adapter",
        action="operation_knowledge.hard_delete",
        source_id=source_id,
        before=before,
        after=None,
        status="prepared",
        reason=reason,
    )
    writes = [
        {"method": "delete", "path": path, "value": None},
        {"method": "put", "path": f"{AUDIT_PATH}/{sanitize_key(audit['id'])}", "value": audit},
    ]
    return mutation_result(operation="operation_knowledge.hard_delete", writes=writes, audit=audit, payload={"target_path": path})


def process_queue_failure_payload(
    job: dict[str, Any],
    *,
    reason: str,
    actor: str = "codex_worker",
    channel: str = "worker",
    source: str = "operation_knowledge_adapter",
) -> dict[str, Any]:
    job_id = compact_text(job.get("job_id") or stable_id("opsq", job), 120)
    source_id = compact_text(job.get("source_id"), 120)
    attempts = int_or_default(job.get("attempts"), 0) + 1
    patch = {
        "status": "failed",
        "attempts": attempts,
        "retryable": attempts < 3,
        "last_error": compact_text(reason, 300),
        "updated_at_ms": now_ms(),
        "failed_at_ms": now_ms(),
    }
    audit = audit_record(
        actor=actor,
        channel=channel,
        source=source,
        action="operation_knowledge.process_job",
        source_id=source_id or job_id,
        before=job,
        after=patch,
        status="failed",
        reason=reason,
    )
    writes = [
        {"method": "patch", "path": f"{QUEUE_PATH}/{sanitize_key(job_id)}", "value": patch},
        {"method": "put", "path": f"{AUDIT_PATH}/{sanitize_key(audit['id'])}", "value": audit},
    ]
    return mutation_result(
        operation="operation_knowledge.process_job",
        writes=writes,
        audit=audit,
        payload=patch,
        extra={
            "status": "failed",
            "queue_job_id": job_id,
            "source_id": source_id,
            "input_persisted": True,
            "summary_persisted": False,
            "retryable": patch["retryable"],
        },
    )


def process_queue_job(
    job: dict[str, Any],
    raw_item: dict[str, Any] | None,
    *,
    actor: str = "codex_worker",
    channel: str = "worker",
    source: str = "operation_knowledge_adapter",
    fail_reason: str = "",
) -> dict[str, Any]:
    if not isinstance(job, dict):
        raise OperationKnowledgeError("queue job must be an object")
    job_id = compact_text(job.get("job_id") or stable_id("opsq", job), 120)
    if fail_reason:
        return process_queue_failure_payload(job, reason=fail_reason, actor=actor, channel=channel, source=source)
    if not isinstance(raw_item, dict):
        return process_queue_failure_payload(job, reason="raw input missing", actor=actor, channel=channel, source=source)
    raw = normalize_raw_item(raw_item)
    raw.setdefault("status", raw_item.get("status") or "active")
    raw["deleted"] = bool(raw_item.get("deleted", False))
    raw["visibility"] = raw_item.get("visibility", "active")
    raw["output_enabled"] = raw_item.get("output_enabled", True)
    if not is_output_visible(raw):
        patch = {
            "status": "output_disabled",
            "attempts": int_or_default(job.get("attempts"), 0) + 1,
            "retryable": False,
            "updated_at_ms": now_ms(),
            "processed_at_ms": now_ms(),
            "source_id": raw["id"],
        }
        audit = audit_record(
            actor=actor,
            channel=channel,
            source=source,
            action="operation_knowledge.process_job",
            source_id=raw["id"],
            before=job,
            after=patch,
            status="output_disabled",
        )
        writes = [
            {"method": "patch", "path": f"{QUEUE_PATH}/{sanitize_key(job_id)}", "value": patch},
            {"method": "put", "path": f"{AUDIT_PATH}/{sanitize_key(audit['id'])}", "value": audit},
        ]
        return mutation_result(
            operation="operation_knowledge.process_job",
            writes=writes,
            audit=audit,
            payload=patch,
            extra={
                "status": "output_disabled",
                "queue_job_id": job_id,
                "source_id": raw["id"],
                "input_persisted": True,
                "summary_persisted": False,
                "output_variant_ids": [],
                "retryable": False,
            },
        )
    requested = normalize_requested_outputs(job.get("requested_outputs"))
    summary_result = upsert_structured_summary(
        None,
        raw_items=[raw],
        actor=actor,
        channel=channel,
        source=source,
    )
    summary = summary_result["payload"]
    writes = list(summary_result.get("writes") or [])
    output_variant_ids: list[str] = []
    if any(item in OUTPUT_VARIANT_KEYS for item in requested):
        variants = generate_output_variants(summary)
        for variant_key in OUTPUT_VARIANT_KEYS:
            if variant_key not in requested:
                continue
            variant_result = upsert_output_variant(
                variant_key,
                variants[variant_key],
                actor=actor,
                channel=channel,
                source=source,
            )
            output_variant_ids.append(variant_result["payload"]["id"])
            writes.extend(variant_result.get("writes") or [])
    patch = {
        "status": "done",
        "attempts": int_or_default(job.get("attempts"), 0) + 1,
        "retryable": False,
        "updated_at_ms": now_ms(),
        "processed_at_ms": now_ms(),
        "source_id": raw["id"],
        "summary_id": summary["id"],
        "output_variant_ids": output_variant_ids,
    }
    audit = audit_record(
        actor=actor,
        channel=channel,
        source=source,
        action="operation_knowledge.process_job",
        source_id=raw["id"],
        before=job,
        after=patch,
        status="done",
    )
    writes.extend(
        [
            {"method": "patch", "path": f"{QUEUE_PATH}/{sanitize_key(job_id)}", "value": patch},
            {"method": "put", "path": f"{AUDIT_PATH}/{sanitize_key(audit['id'])}", "value": audit},
        ]
    )
    return mutation_result(
        operation="operation_knowledge.process_job",
        writes=writes,
        audit=audit,
        payload={"structured_summary": summary, "output_variant_ids": output_variant_ids},
        extra={
            "status": "done",
            "queue_job_id": job_id,
            "source_id": raw["id"],
            "summary_id": summary["id"],
            "output_variant_ids": output_variant_ids,
            "input_persisted": True,
            "summary_persisted": True,
            "retryable": False,
        },
    )


def build_operation_knowledge_preview(raw_items: list[dict[str, Any]] | dict[str, Any], query: str = "") -> dict[str, Any]:
    normalized = [normalize_raw_item(item) for item in (raw_items if isinstance(raw_items, list) else [raw_items])]
    structured = structure_raw_items(normalized)
    variants = generate_output_variants(structured, query=query)
    contract = build_mcp_adapter_contract("write_enabled")
    ensure_write_enabled_adapter_contract(contract)
    return {
        "schema_version": SCHEMA_VERSION,
        "mode": "write_enabled",
        "raw_items": normalized,
        "structured_summary": structured,
        "output_variants": variants,
        "mcp_adapter_contract": contract,
        "guards": contract["guards"],
    }


def build_operation_knowledge_site_contract() -> dict[str, Any]:
    preview = build_operation_knowledge_preview(sample_raw_items(), query="근무 변경 요청")
    return {
        "schema_version": SCHEMA_VERSION,
        "mode": "write_enabled",
        "site_surface": "AttendanceBoard/docs/hynix",
        "raw_item_fields": ["source", "channel", "text", "author", "timestamp", "tags"],
        "structured_fields": [
            "summary",
            "key_points",
            "category",
            "audience",
            "source_ids",
            "citations",
            "confidence",
            "status",
        ],
        "output_variants": list(OUTPUT_VARIANT_KEYS),
        "write_paths": {
            "raw_inputs_path": RAW_ITEMS_PATH,
            "structured_summaries_path": STRUCTURED_SUMMARIES_PATH,
            "output_variants_path": OUTPUT_VARIANTS_PATH,
            "delete_requests_path": DELETE_REQUESTS_PATH,
            "queue_path": QUEUE_PATH,
            "audit_path": AUDIT_PATH,
        },
        "source_separation": {
            "raw_inputs_path": RAW_ITEMS_PATH,
            "structured_summaries_path": STRUCTURED_SUMMARIES_PATH,
            "output_variants_path": OUTPUT_VARIANTS_PATH,
            "ops_manual_source": OPS_MANUAL_ROOT,
            "canonical_schedule_source": WORKSCHEDULE_V2_PATH,
            "attendance_source": WORKSCHEDULE_ATTENDANCE_PATH,
            "summary_as_schedule_source_allowed": False,
        },
        "safety": {
            "required_auth": "operator_or_owner",
            "audit_required": True,
            "soft_delete_first": True,
            "hard_delete_disabled": True,
            "no_blocking_ai_on_ingest": True,
            "async_processing": True,
            "immediate_ack": True,
            "kakao_send_enabled": True,
            "kakao_send_default_no_send": True,
            "explicit_action_required": True,
            "room_guard_required": True,
            "mass_send_disabled": True,
        },
        "preview_sample": {
            "raw_items": preview["raw_items"],
            "structured_summary": preview["structured_summary"],
            "output_variants": preview["output_variants"],
        },
        "mcp_adapter_contract": preview["mcp_adapter_contract"],
    }


def sample_raw_items() -> list[dict[str, Any]]:
    return [
        {
            "source": "hynix_site_form",
            "channel": "site",
            "text": "운영메모: 야간 근무표 변경 요청은 원문을 보존하고 관리자 확인용 체크리스트로 먼저 보여준다.",
            "author": "operator",
            "timestamp": "2026-07-07T09:00:00+09:00",
            "tags": ["schedule", "ops_manual"],
        },
        {
            "source": "storebot_kakao",
            "channel": "kakao",
            "text": "내일 근무 바꿔 달라는 카톡은 출처와 요청 내용을 남긴 뒤 확인용으로 정리한다.",
            "author": "staff",
            "timestamp": "2026-07-07T09:03:00+09:00",
            "tags": ["schedule"],
        },
    ]


def load_json_arg(value: str) -> Any:
    if value == "-":
        return json.load(sys.stdin)
    stripped = value.lstrip()
    if stripped.startswith("{") or stripped.startswith("["):
        return json.loads(value)
    path = Path(value)
    if path.exists():
        return json.loads(path.read_text(encoding="utf-8"))
    return json.loads(value)


def path_parts(path: str) -> list[str]:
    return [part for part in path.strip("/").split("/") if part]


def deep_set(root: dict[str, Any], path: str, value: Any, *, merge: bool = False, delete: bool = False) -> None:
    parts = path_parts(path)
    if not parts:
        raise OperationKnowledgeError("empty backend path")
    node = root
    for part in parts[:-1]:
        node = node.setdefault(part, {})
        if not isinstance(node, dict):
            raise OperationKnowledgeError("file backend path collides with scalar")
    key = parts[-1]
    if delete:
        node.pop(key, None)
    elif merge and isinstance(node.get(key), dict) and isinstance(value, dict):
        node[key].update(value)
    else:
        node[key] = value


def apply_file_backend(state_file: str, writes: list[dict[str, Any]]) -> dict[str, Any]:
    path = Path(state_file)
    if path.exists():
        root = json.loads(path.read_text(encoding="utf-8"))
        if not isinstance(root, dict):
            raise OperationKnowledgeError("state file must contain a JSON object")
    else:
        root = {}
    for write in writes:
        method = str(write.get("method") or "").lower()
        write_path = str(write.get("path") or "")
        if method == "put":
            deep_set(root, write_path, write.get("value"))
        elif method == "patch":
            deep_set(root, write_path, write.get("value"), merge=True)
        elif method == "delete":
            deep_set(root, write_path, None, delete=True)
        else:
            raise OperationKnowledgeError(f"unsupported write method: {method}")
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(root, ensure_ascii=False, indent=2, sort_keys=True) + "\n", encoding="utf-8")
    return root


def load_file_backend_state(state_file: str) -> dict[str, Any]:
    path = Path(state_file)
    if not path.exists():
        return {}
    root = json.loads(path.read_text(encoding="utf-8"))
    if not isinstance(root, dict):
        raise OperationKnowledgeError("state file must contain a JSON object")
    return root


def deep_get(root: dict[str, Any], path: str) -> Any:
    node: Any = root
    for part in path_parts(path):
        if not isinstance(node, dict) or part not in node:
            return None
        node = node[part]
    return node


def queue_jobs_from_state(root: dict[str, Any], *, status: str = "pending") -> list[dict[str, Any]]:
    queue = deep_get(root, QUEUE_PATH)
    if not isinstance(queue, dict):
        return []
    jobs: list[dict[str, Any]] = []
    for key, value in queue.items():
        if not isinstance(value, dict):
            continue
        item = dict(value)
        item.setdefault("job_id", key)
        if status and item.get("status") != status:
            continue
        jobs.append(item)
    jobs.sort(key=lambda item: (int_or_default(item.get("priority"), 5), int_or_default(item.get("created_at_ms") or item.get("created_at"), 0), item.get("job_id") or ""))
    return jobs


def raw_item_for_job(root: dict[str, Any], job: dict[str, Any]) -> dict[str, Any] | None:
    source_id = compact_text(job.get("source_id"), 120)
    if not source_id:
        return None
    item = deep_get(root, f"{RAW_ITEMS_PATH}/{sanitize_key(source_id)}")
    return item if isinstance(item, dict) else None


def process_queue_file_backend(
    state_file: str,
    *,
    limit: int = 10,
    job_id: str = "",
    actor: str = "codex_worker",
    channel: str = "worker",
    source: str = "operation_knowledge_adapter",
    fail_reason: str = "",
) -> dict[str, Any]:
    root = load_file_backend_state(state_file)
    jobs = queue_jobs_from_state(root)
    if job_id:
        jobs = [job for job in jobs if job.get("job_id") == job_id or sanitize_key(job.get("job_id")) == sanitize_key(job_id)]
    selected = jobs[: max(0, int_or_default(limit, 0))]
    results: list[dict[str, Any]] = []
    for job in selected:
        raw_item = raw_item_for_job(root, job)
        result = process_queue_job(job, raw_item, actor=actor, channel=channel, source=source, fail_reason=fail_reason)
        root = apply_file_backend(state_file, result.get("writes") or [])
        results.append(result)
    return {
        "ok": True,
        "schema_version": SCHEMA_VERSION,
        "mode": "write_enabled",
        "operation": "operation_knowledge.process_queue",
        "backend": "file",
        "state_file": state_file,
        "processed_count": len(results),
        "results": results,
        "guards": build_mcp_adapter_contract()["guards"],
    }


def finalize_backend(result: dict[str, Any], args: argparse.Namespace) -> dict[str, Any]:
    backend = getattr(args, "backend", "payload")
    if backend == "file":
        result = dict(result)
        result["backend"] = "file"
        result["file_state"] = apply_file_backend(args.state_file, result.get("writes") or [])
        result["state_file"] = args.state_file
    return result


def print_json(payload: Any, *, compact: bool = False) -> None:
    if compact:
        print(json.dumps(payload, ensure_ascii=False, separators=(",", ":")))
    else:
        print(json.dumps(payload, ensure_ascii=False, indent=2, sort_keys=True))


def add_backend_args(parser: argparse.ArgumentParser) -> None:
    parser.add_argument("--backend", choices=["payload", "file"], default="payload")
    parser.add_argument("--state-file", default="/tmp/operation_knowledge_state.json")
    parser.add_argument("--actor", default="codex")
    parser.add_argument("--channel", default="cli")
    parser.add_argument("--source", default="operation_knowledge_adapter")
    parser.add_argument("--compact", action="store_true")


def parse_args(argv: list[str]) -> argparse.Namespace:
    parser = argparse.ArgumentParser(description="Operation knowledge write-enabled adapter")
    subparsers = parser.add_subparsers(dest="command")

    contract_parser = subparsers.add_parser("contract", help="print MCP-compatible write-enabled adapter contract")
    contract_parser.add_argument("--site", action="store_true", help="print Hynix site contract asset")
    contract_parser.add_argument("--compact", action="store_true")

    preview_parser = subparsers.add_parser("preview", help="print raw-to-structured output preview")
    preview_parser.add_argument("--input-json", default="", help="raw item list/object JSON, path, or -")
    preview_parser.add_argument("--query", default="")
    preview_parser.add_argument("--sample", action="store_true")
    preview_parser.add_argument("--compact", action="store_true")

    ingest_parser = subparsers.add_parser("ingest", help="prepare or apply a raw input write")
    ingest_parser.add_argument("--input-json", required=True, help="raw item object JSON, path, or -")
    ingest_parser.add_argument("--priority", type=int, default=5)
    ingest_parser.add_argument("--requested-outputs", default="")
    add_backend_args(ingest_parser)

    process_job_parser = subparsers.add_parser("process-job", help="process one operation knowledge queue job")
    process_job_parser.add_argument("--job-json", default="", help="queue job JSON, path, or -")
    process_job_parser.add_argument("--raw-json", default="", help="raw item JSON, path, or -")
    process_job_parser.add_argument("--job-id", default="", help="queue job id for file backend")
    process_job_parser.add_argument("--fail-reason", default="")
    add_backend_args(process_job_parser)

    process_queue_parser = subparsers.add_parser("process-queue", help="process pending operation knowledge queue jobs from file backend")
    process_queue_parser.add_argument("--limit", type=int, default=10)
    process_queue_parser.add_argument("--job-id", default="")
    process_queue_parser.add_argument("--fail-reason", default="")
    add_backend_args(process_queue_parser)

    summary_parser = subparsers.add_parser("upsert-summary", help="prepare or apply a structured summary upsert")
    summary_parser.add_argument("--input-json", required=True, help="summary object or raw item/list JSON, path, or -")
    summary_parser.add_argument("--raw", action="store_true", help="treat input as raw item/list and derive a summary")
    add_backend_args(summary_parser)

    output_parser = subparsers.add_parser("render-output", help="render output variants and optionally upsert one")
    output_parser.add_argument("--input-json", required=True, help="structured summary JSON, path, or -")
    output_parser.add_argument("--query", default="")
    output_parser.add_argument("--variant", default="")
    output_parser.add_argument("--upsert", action="store_true")
    add_backend_args(output_parser)

    variant_parser = subparsers.add_parser("upsert-output", help="prepare or apply an output variant upsert")
    variant_parser.add_argument("--variant", required=True)
    variant_parser.add_argument("--input-json", required=True, help="variant object JSON, path, or -")
    add_backend_args(variant_parser)

    request_delete_parser = subparsers.add_parser("request-delete", help="create a reviewable delete request")
    request_delete_parser.add_argument("--target-type", required=True)
    request_delete_parser.add_argument("--source-id", required=True)
    request_delete_parser.add_argument("--reason", default="")
    add_backend_args(request_delete_parser)

    delete_parser = subparsers.add_parser("delete", help="soft-delete by default; hard delete needs explicit confirm")
    delete_parser.add_argument("--target-type", required=True)
    delete_parser.add_argument("--source-id", required=True)
    delete_parser.add_argument("--reason", default="")
    delete_parser.add_argument("--hard", action="store_true")
    delete_parser.add_argument("--explicit-confirm", default="")
    add_backend_args(delete_parser)

    restore_parser = subparsers.add_parser("restore", help="restore a soft-deleted item")
    restore_parser.add_argument("--target-type", required=True)
    restore_parser.add_argument("--source-id", required=True)
    add_backend_args(restore_parser)

    parser.add_argument("--input-json", default="", help=argparse.SUPPRESS)
    parser.add_argument("--query", default="", help=argparse.SUPPRESS)
    parser.add_argument("--contract-only", action="store_true", help=argparse.SUPPRESS)
    parser.add_argument("--sample", action="store_true", help=argparse.SUPPRESS)
    parser.add_argument("--compact", action="store_true", help=argparse.SUPPRESS)
    return parser.parse_args(argv)


def main(argv: list[str] | None = None) -> int:
    args = parse_args(argv or sys.argv[1:])
    command = args.command or ("contract" if args.contract_only else "preview")
    if command == "contract":
        payload = build_operation_knowledge_site_contract() if getattr(args, "site", False) else build_mcp_adapter_contract()
        print_json(payload, compact=args.compact)
        return 0
    if command == "preview":
        raw_items = sample_raw_items() if args.sample or not args.input_json else load_json_arg(args.input_json)
        print_json(build_operation_knowledge_preview(raw_items, query=args.query), compact=args.compact)
        return 0
    if command == "ingest":
        result = ingest_raw_item(
            load_json_arg(args.input_json),
            actor=args.actor,
            channel=args.channel,
            source=args.source,
            priority=args.priority,
            requested_outputs=args.requested_outputs,
        )
        print_json(finalize_backend(result, args), compact=args.compact)
        return 0
    if command == "process-job":
        if args.backend == "file" and args.job_id:
            payload = process_queue_file_backend(
                args.state_file,
                limit=1,
                job_id=args.job_id,
                actor=args.actor,
                channel=args.channel,
                source=args.source,
                fail_reason=args.fail_reason,
            )
            print_json(payload, compact=args.compact)
            return 0
        if not args.job_json or not args.raw_json:
            raise OperationKnowledgeError("process-job needs --job-json and --raw-json unless --backend file --job-id is used")
        result = process_queue_job(
            load_json_arg(args.job_json),
            load_json_arg(args.raw_json),
            actor=args.actor,
            channel=args.channel,
            source=args.source,
            fail_reason=args.fail_reason,
        )
        print_json(finalize_backend(result, args), compact=args.compact)
        return 0
    if command == "process-queue":
        if args.backend != "file":
            raise OperationKnowledgeError("process-queue requires --backend file")
        print_json(
            process_queue_file_backend(
                args.state_file,
                limit=args.limit,
                job_id=args.job_id,
                actor=args.actor,
                channel=args.channel,
                source=args.source,
                fail_reason=args.fail_reason,
            ),
            compact=args.compact,
        )
        return 0
    if command == "upsert-summary":
        payload = load_json_arg(args.input_json)
        raw_items = payload if isinstance(payload, list) else [payload]
        result = upsert_structured_summary(
            None if args.raw else payload,
            raw_items=raw_items if args.raw else None,
            actor=args.actor,
            channel=args.channel,
            source=args.source,
        )
        print_json(finalize_backend(result, args), compact=args.compact)
        return 0
    if command == "render-output":
        result = render_output_payload(
            load_json_arg(args.input_json),
            query=args.query,
            variant_key=args.variant,
            actor=args.actor,
            channel=args.channel,
            source=args.source,
            upsert=args.upsert,
        )
        print_json(finalize_backend(result, args) if args.upsert else result, compact=args.compact)
        return 0
    if command == "upsert-output":
        result = upsert_output_variant(args.variant, load_json_arg(args.input_json), actor=args.actor, channel=args.channel, source=args.source)
        print_json(finalize_backend(result, args), compact=args.compact)
        return 0
    if command == "request-delete":
        result = delete_request_payload(
            args.target_type,
            args.source_id,
            actor=args.actor,
            channel=args.channel,
            source=args.source,
            reason=args.reason,
        )
        print_json(finalize_backend(result, args), compact=args.compact)
        return 0
    if command == "delete":
        if args.hard:
            result = hard_delete_payload(
                args.target_type,
                args.source_id,
                explicit_confirm=args.explicit_confirm,
                actor=args.actor,
                channel=args.channel,
                source=args.source,
                reason=args.reason,
            )
        else:
            result = soft_delete_payload(
                args.target_type,
                args.source_id,
                actor=args.actor,
                channel=args.channel,
                source=args.source,
                reason=args.reason,
            )
        print_json(finalize_backend(result, args), compact=args.compact)
        return 0
    if command == "restore":
        result = restore_payload(args.target_type, args.source_id, actor=args.actor, channel=args.channel, source=args.source)
        print_json(finalize_backend(result, args), compact=args.compact)
        return 0
    raise OperationKnowledgeError(f"unsupported command: {command}")


if __name__ == "__main__":
    raise SystemExit(main())
