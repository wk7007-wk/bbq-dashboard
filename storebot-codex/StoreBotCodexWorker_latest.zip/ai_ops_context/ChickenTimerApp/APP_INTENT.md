<!-- source: /root/my-first-project/ChickenTimerApp/APP_INTENT.md -->
# ChickenTimerApp APP_INTENT.md

## 기준
- 앱 의도 SOT는 `../ChickenTimerBoard/APP_INTENT.md`다.
- 이 프로젝트는 치킨 타이머 웹 원본을 Android WebView로 안정 실행하는 래퍼다.

## 앱 고유 기준
- 웹 보드는 `https://wk7007-ops-static-2026.web.app/chicken-timer/`를 우선 로드하고, 네트워크 불안정 시 로컬 asset fallback이 동작해야 한다. fallback도 원격 보드와 같은 신뢰 HTTPS origin으로 제공해 localStorage 복구본을 공유하고 `file://` 저장소로 갈라지지 않는다.
- 느린 첫 로딩만으로 보드 실패 화면을 띄우지 말고, 원격/로컬 보드가 실제로 부팅될 시간을 먼저 줘야 한다.
- 화면 꺼짐 방지, 종료 고음 알림, 이동/스위치 저중요도 효과음, 자동업데이트 설치 화면 호출을 유지한다.
- 사용자가 선택한 알림음 크기는 앱 재실행 뒤에도 유지한다.
- 자동업데이트 설치 화면은 웹 보드가 현재 상태를 보고하기 전에는 열지 않고, 진행·정지·완료 대기 중 타이머가 있으면 모두 끝날 때까지 미룬다.
- WebView 안에는 공식 ChickenTimer origin만 유지하고 외부 주소는 시스템 브라우저로 분리한다. 로컬 fallback을 위해 file universal access를 다시 켜지 않는다.
- `source=android` 문자열만으로 인증을 건너뛰지 않고 앱이 제공하는 네이티브 브리지 식별까지 확인한다.
- 웹 원본과 asset 미러가 어긋나면 Android 앱이 낡은 보드를 보여줄 수 있으므로 배포 전 동기화한다.
- asset 미러는 웹 원본의 물리 위치 배지, 즉시 드래그 preview 스왑, 관련 슬롯 부분 갱신, 드롭 확정 피드백/이동 cue, 완료 배지 점멸, `-60/-10/+10/+60` 조절 표기, 서버시간/오프라인 상태 표시, dirty retry 경계를 그대로 따라야 한다.
- asset 미러는 웹 원본의 공통 시간추가 경로도 그대로 따라야 한다. 시간 추가는 `start/clear` 초기화가 아니라 현재 `endAt` 또는 `remainingSeconds`에 delta만 더한다.
- asset 미러는 웹 원본의 split 기준도 그대로 따른다. 한 슬롯의 보조 타이머는 최대 1개이며 완료 후 8초 정리/남은 타이머 단독 승격, 메인/보조 영역 1:1에 가까운 위아래 레이아웃을 유지한다.
- asset 미러는 웹 원본의 튀김 슬롯 색상 기준도 그대로 따라야 한다. 물리 슬롯 `1,2,3`은 노랑 계열, `4,5`는 파랑 계열, `OV`는 초록 구분이다.
- asset 미러는 이름 칸 없는 가로 `1·2·3 | 4·5 | OV` 한 줄/거의 같은 카드 폭, 가로 분·초 2단 카운터, 세로 6행 카드와 4열 숫자판, 최근 동작 4줄을 유지한다. 세로 1열 숫자판은 노트북에서는 버튼 면적에 맞춰 원거리 식별 크기로 커지고 작은 폰에서는 12개 값이 잘리지 않아야 한다. 원거리 정보 우선순위도 웹 원본과 같게 `청록 물 면적/높이와 주황·빨강 전체 둘레 → 검정 그라데이션 보호판 위 숫자 확인` 순서로 유지하고, 구역·물·임박색과 경계 대비를 임의로 바꾸지 않는다.
- asset은 모델명이 아니라 기록된 CSS viewport의 short/long side 기준 Samsung Galaxy Note9 393×852, Samsung Galaxy Tab A 8.0 (2019) 800×1280, 서브 노트북 1085×1885 자동 인식과 그 외 proportional fallback을 웹 원본과 같게 유지한다. 서브 노트북 전용 프로필은 색상/면적과 큰 프리셋 숫자를 우선하고 텍스트 로그는 보조로 둔다.
- 메인·보조 타이머의 정지는 구역색과 분리한 무채색으로 보이고, 시각 갱신은 1초 간격으로 줄이되 만료 watchdog은 250ms를 유지하며 0초에는 물이 완전히 사라져야 한다.
- asset의 실행 중 메인 하단은 `삭제 · 추가 · -10 · -60` 순서를 한 조작대에 두고 `+10 · +60`은 증가 영역에만 둔다. Note9 저높이 가로 plain running은 두 증가 버튼을 카운터 위 가로 한 줄로 두며 split/add 전용 구조는 유지한다. 하단은 고정 청록색이 아닌 반투명 dark/gray로 실제 물 면적을 비추며 물·임박층이 버튼 입력을 가로채지 않아야 한다.
- 화면 회전과 새 정보/게이지 렌더링은 현재 타이머 데이터를 리셋하지 않으며 웹 원본의 `복구` 버튼과 active 스냅샷 히스토리를 그대로 유지한다.
- 레시피 패널 동작도 웹 원본과 동일해야 한다. `뒤로` 닫기, 이름순 자동정렬, 기존 `/packhelper/recipes` DB 보존 저장 기준을 asset 미러에서 유지한다.
- APK metadata/history는 `bbq-dashboard` GitHub Pages `/updates/chicken-timer`, 앱 내부 업데이트용 rolling APK는 GitHub Release `app-updates/ChickenTimer_latest.bin`을 SOT로 쓴다. 수동 복구 페이지는 같은 바이트·SHA의 `ChickenTimer_latest.apk` 별칭을 제공해 Android가 설치 파일로 인식하게 하며, Firebase에는 보드 정적 파일만 두고 신규 APK binary를 배포하지 않는다.
- APK 직접 전달 후에도 GitHub metadata/history와 `ChickenTimer_latest.bin`·동일 해시 `.apk` 별칭을 같은 version/package/certificate/SHA/size로 갱신한다. APK 내부 `version.json`은 자기 자신의 SHA를 포함할 수 없으므로 버전·코드·URL 기준만 공개 manifest와 일치시킨다.

## C&I / AI Ops 경계
- C&I는 WebView 로드 실패, asset 미러 불일치, 고음 알림/화면꺼짐 방지 회귀, APK 빌드/업데이트센터 배포 실패를 self_fix 후보로 올린다.
- 자동 복구는 Android wrapper, asset 미러, APK 빌드, `ChickenTimer_latest.bin` 업로드까지 허용한다.
- 타이머/레시피 DB 원본 변경 판단은 `ChickenTimerBoard/APP_INTENT.md`를 따른다.
- CLI/LLM은 prompt envelope가 있어야 깨어난다. monitor/worker/사용자/수동 enqueue 또는 상주 판단 루프가 prompt를 주입하며, 이것은 C&I 판단 권한 제한이 아니다.

## 수정 전 질문
- 웹 원본 의도와 UI를 바꾸는 변경인가, Android 실행 안정성만 바꾸는 변경인가.
- asset 미러와 호스팅 복사본을 함께 갱신했는가.
- 설치 화면까지 전달했는가.
