# AI Ops Context

이 폴더는 서버폰 C&I/codex_ops가 대상 repo를 직접 열 수 없을 때 읽는 문서 스냅샷이다.
수정 원본은 각 source 경로이며, 스냅샷은 StoreBot Codex worker bundle 생성 시 갱신된다.

## 포함 문서
- `ai_ops_context/root/AGENTS.md` <- `/root/my-first-project/AGENTS.md`
- `ai_ops_context/root/CODEX_BRIEF.md` <- `/root/my-first-project/CODEX_BRIEF.md`
- `ai_ops_context/root/AI_HANDOFF.md` <- `/root/my-first-project/AI_HANDOFF.md`
- `ai_ops_context/root/CODEMAP.txt` <- `/root/my-first-project/CODEMAP.txt`
- `ai_ops_context/root/rules/ai_ops_prompt_contract.txt` <- `/root/my-first-project/rules/ai_ops_prompt_contract.txt`
- `ai_ops_context/root/planning/app_intent_template.md` <- `/root/my-first-project/planning/templates/app_intent.md`
- `ai_ops_context/DeliveryHelper/APP_INTENT.md` <- `/root/DeliveryHelper/APP_INTENT.md`
- `ai_ops_context/DeliveryHelper/CODEMAP.txt` <- `/root/DeliveryHelper/CODEMAP.txt`
- `ai_ops_context/PosDelay/APP_INTENT.md` <- `/root/PosDelay/APP_INTENT.md`
- `ai_ops_context/PosDelay/CODEMAP.txt` <- `/root/PosDelay/CODEMAP.txt`
- `ai_ops_context/PosKDS/APP_INTENT.md` <- `/root/PosKDS/APP_INTENT.md`
- `ai_ops_context/PosKDS/CODEMAP.txt` <- `/root/PosKDS/CODEMAP.txt`
- `ai_ops_context/StoreBot/APP_INTENT.md` <- `/root/StoreBot/APP_INTENT.md`
- `ai_ops_context/StoreBot/CODEMAP.txt` <- `/root/StoreBot/CODEMAP.txt`
- `ai_ops_context/StoreBotTermux/APP_INTENT.md` <- `/root/StoreBotTermux/APP_INTENT.md`
- `ai_ops_context/StoreBotTermux/CODEMAP.txt` <- `/root/StoreBotTermux/CODEMAP.txt`
- `ai_ops_context/PackHelper/APP_INTENT.md` <- `/root/PackHelper/APP_INTENT.md`
- `ai_ops_context/PackHelper/CODEMAP.txt` <- `/root/PackHelper/CODEMAP.txt`
- `ai_ops_context/SiteBot/APP_INTENT.md` <- `/root/SiteBot/APP_INTENT.md`
- `ai_ops_context/SiteBot/CODEMAP.txt` <- `/root/SiteBot/CODEMAP.txt`
- `ai_ops_context/OrderHelper/APP_INTENT.md` <- `/root/OrderHelper/APP_INTENT.md`
- `ai_ops_context/OrderHelper/CODEMAP.txt` <- `/root/OrderHelper/CODEMAP.txt`
- `ai_ops_context/WorkSchedule/APP_INTENT.md` <- `/root/WorkSchedule/APP_INTENT.md`
- `ai_ops_context/WorkSchedule/CODEMAP.txt` <- `/root/WorkSchedule/CODEMAP.txt`
- `ai_ops_context/BankTotal/APP_INTENT.md` <- `/root/BankTotal/APP_INTENT.md`
- `ai_ops_context/BankTotal/CODEMAP.txt` <- `/root/BankTotal/CODEMAP.txt`
- `ai_ops_context/NotallyX/APP_INTENT.md` <- `/root/NotallyX/APP_INTENT.md`
- `ai_ops_context/NotallyX/CODEMAP.txt` <- `/root/NotallyX/CODEMAP.txt`
- `ai_ops_context/AppUpdateCenter/APP_INTENT.md` <- `/root/AppUpdateCenter/APP_INTENT.md`
- `ai_ops_context/AppUpdateCenter/CODEMAP.txt` <- `/root/AppUpdateCenter/CODEMAP.txt`
- `ai_ops_context/ChickenTimerBoard/APP_INTENT.md` <- `/root/my-first-project/ChickenTimerBoard/APP_INTENT.md`
- `ai_ops_context/ChickenTimerBoard/CODEMAP.txt` <- `/root/my-first-project/ChickenTimerBoard/CODEMAP.txt`
- `ai_ops_context/ChickenTimerApp/APP_INTENT.md` <- `/root/my-first-project/ChickenTimerApp/APP_INTENT.md`
- `ai_ops_context/ChickenTimerApp/CODEMAP.txt` <- `/root/my-first-project/ChickenTimerApp/CODEMAP.txt`
- `ai_ops_context/Schedule/APP_INTENT.md` <- `/root/my-first-project/Schedule/APP_INTENT.md`
- `ai_ops_context/Schedule/CODEMAP.txt` <- `/root/my-first-project/Schedule/CODEMAP.txt`
