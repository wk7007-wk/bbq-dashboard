#!/usr/bin/env python3
"""Pure, no-send StoreBotTermux projections for a future Telegram backplane.

This module deliberately performs no I/O.  It turns an existing StoreBot room
event into a small redacted value object that a later, separately gated
transport may consume.  A projection or incident decision is never evidence
that Telegram or Kakao delivery occurred.
"""

from __future__ import annotations

import hashlib
import hmac
import json
import re
from collections.abc import Iterable, Mapping
from typing import Any


SCHEMA = "storebot.telegram_projection.v1"
STOREBOT_RESOURCE = "com.sbotux"
FORBIDDEN_RESOURCE = "com.wonmux"

SUPPORTED_EVENT_KINDS = frozenset(
    {
        "inbound_message",
        "outbound_intent",
        "transport_failure",
    }
)
PROJECTION_KEYS = frozenset(
    {
        "schema",
        "event_kind",
        "projection_id",
        "resource",
        "request_id",
        "correlation_id",
        "status",
        "severity",
        "redacted_preview",
        "source_hash",
        "evidence_pointer",
        "fresh_at_ms",
        "intent",
    }
)
REQUIRED_PROJECTION_KEYS = PROJECTION_KEYS - {"intent"}
FORBIDDEN_PROJECTION_KEYS = frozenset(
    {
        "message",
        "room_name",
        "sender",
        "briefing_text",
        "secret",
    }
)
SAFE_INTENT_CATEGORIES = frozenset(
    {
        "kakao_reply",
        "log_only",
        "report",
        "schedule_image",
        "self_fix",
        "self_heal",
        "skip",
        "system_event",
    }
)
SAFE_STATUSES = frozenset(
    {
        "failed",
        "in_progress",
        "no_send",
        "observed",
        "proposal",
        "recovered",
        "unknown",
    }
)
SAFE_SEVERITIES = frozenset({"info", "warning", "error", "critical"})
TRUSTED_LOCAL_SOURCES = frozenset(
    {
        "storebot_codex_worker_local_direct",
        "storebot_codex_worker_resident",
    }
)
SOURCE_CAPABILITY = "storebot_telegram_projection_v1"
DEFAULT_MAX_SOURCE_AGE_MS = 5 * 60_000
DEFAULT_FUTURE_SKEW_MS = 30_000

_SAFE_ID_RE = re.compile(r"[^A-Za-z0-9._:-]+")
_SAFE_POINTER_RE = re.compile(r"\A[A-Za-z0-9._:/-]{1,240}\Z")
_PHONE_RE = re.compile(r"(?<!\d)01[016789](?:[-\s.]?\d){7,8}(?!\d)")
_EMAIL_RE = re.compile(r"(?i)\b[A-Z0-9._%+-]+@[A-Z0-9.-]+\.[A-Z]{2,}\b")
_PATH_RE = re.compile(r"(?<!\w)(?:/[A-Za-z0-9._-]+){2,}")
_SECRET_ASSIGNMENT_RE = re.compile(
    r"(?i)(비번|비밀번호|공동현관|password|passcode|pin|secret|token|api[_-]?key|authorization)"
    r"\s*(?::|=|은|는)?\s*[^\s,;]{2,}"
)
_DIGIT_RE = re.compile(r"\d+")


class ProjectionValidationError(ValueError):
    """Raised when a projection could cross a package or privacy boundary."""


def _canonical_hash(value: Mapping[str, Any]) -> str:
    encoded = json.dumps(value, ensure_ascii=False, sort_keys=True, separators=(",", ":"))
    return hashlib.sha256(encoded.encode("utf-8")).hexdigest()


def _identity_key(value: bytes | str) -> bytes:
    key = value.encode("utf-8") if isinstance(value, str) else bytes(value)
    if len(key) < 32:
        raise ProjectionValidationError("identity_key must contain at least 32 bytes")
    return key


def _opaque_hmac(prefix: str, key: bytes, value: Mapping[str, Any]) -> str:
    encoded = json.dumps(value, ensure_ascii=False, sort_keys=True, separators=(",", ":")).encode("utf-8")
    return f"{prefix}_{hmac.new(key, encoded, hashlib.sha256).hexdigest()[:32]}"


def redact_projection_preview(value: Any, limit: int = 240) -> str:
    """Return a one-line preview with phone, PIN/secret, and all digits masked.

    Masking every digit also covers compact Korean address forms such as
    ``104동 1808호`` and road-number fragments without trying to infer intent.
    """

    text = re.sub(r"\s+", " ", str(value or "").strip())
    if not text:
        return ""
    text = _PHONE_RE.sub("[phone]", text)
    text = _EMAIL_RE.sub("[email]", text)
    text = _PATH_RE.sub("[path]", text)
    text = _SECRET_ASSIGNMENT_RE.sub(lambda match: f"{match.group(1)} [redacted]", text)
    text = _DIGIT_RE.sub("[digits]", text)
    return text[: max(1, int(limit))]


def _event_kind(event: Mapping[str, Any]) -> str:
    value = str(event.get("event_kind") or event.get("event_type") or "").strip().lower()
    if value not in SUPPORTED_EVENT_KINDS:
        raise ProjectionValidationError(f"unsupported event_kind: {value or '<empty>'}")
    return value


def _assert_storebot_resource(event: Mapping[str, Any]) -> None:
    if str(event.get("application_id") or "").strip().lower() != STOREBOT_RESOURCE:
        raise ProjectionValidationError("application_id=com.sbotux is required")
    if str(event.get("source") or "").strip() not in TRUSTED_LOCAL_SOURCES:
        raise ProjectionValidationError("trusted local source is required")
    if str(event.get("source_capability") or "").strip() != SOURCE_CAPABILITY:
        raise ProjectionValidationError("source capability is required")
    for key in ("resource", "target_resource", "android_package_name", "package_name", "application_id"):
        value = str(event.get(key) or "").strip().lower()
        if value and value != STOREBOT_RESOURCE:
            raise ProjectionValidationError(f"projection resource must be {STOREBOT_RESOURCE}: {key}")
    target = str(event.get("target") or "").strip().lower()
    if target == FORBIDDEN_RESOURCE:
        raise ProjectionValidationError(f"projection target must not be {FORBIDDEN_RESOURCE}")


def _preview_source(event: Mapping[str, Any], event_kind: str) -> str:
    if event_kind == "inbound_message":
        keys = ("message", "text", "message_preview")
    elif event_kind == "outbound_intent":
        keys = ("reply_preview", "reply", "message_preview")
    else:
        keys = ("failure_reason", "error", "message_preview")
    for key in keys:
        value = str(event.get(key) or "").strip()
        if value:
            return value
    return ""


def _status(event: Mapping[str, Any], event_kind: str) -> str:
    if event_kind == "outbound_intent":
        return "proposal"
    if event_kind == "transport_failure":
        return "failed"
    raw = str(event.get("processing_status") or event.get("status") or "").strip().lower()
    aliases = {
        "local_direct_inflight": "in_progress",
        "received": "observed",
        "ready": "observed",
        "outbound_intent_ready": "proposal",
        "deferred_no_kakao_send": "no_send",
        "no_kakao_send": "no_send",
        "transport_failure": "failed",
    }
    normalized = aliases.get(raw, raw or "observed")
    return normalized if normalized in SAFE_STATUSES else "unknown"


def _severity(event: Mapping[str, Any], event_kind: str) -> str:
    raw = str(event.get("severity") or "").strip().lower()
    if raw in SAFE_SEVERITIES:
        return raw
    return "error" if event_kind == "transport_failure" else "info"


def _intent(event: Mapping[str, Any]) -> dict[str, Any]:
    raw = str(event.get("outbound_category") or event.get("output_category") or "log_only")
    category = raw.strip().lower().replace("-", "_")
    if category.startswith("system_"):
        category = "system_event"
    if category not in SAFE_INTENT_CATEGORIES:
        category = "log_only"
    return {
        "category": category,
        "proposal": True,
        "sent": False,
    }


def _timestamp_ms(event: Mapping[str, Any], override: int | None) -> tuple[int, int]:
    original = (
        event.get("fresh_at_ms")
        or event.get("updated_at_ms")
        or event.get("created_at_ms")
        or event.get("message_ts_ms")
    )
    raw = override if override is not None else original
    try:
        value = int(raw or 0)
        identity_value = int(original or override or 0)
    except (TypeError, ValueError) as exc:
        raise ProjectionValidationError("fresh_at_ms must be an integer") from exc
    if value <= 0 or identity_value <= 0:
        raise ProjectionValidationError("fresh_at_ms must be positive")
    return value, identity_value


def _canonical_occurrence(event: Mapping[str, Any]) -> dict[str, Any]:
    event_id = str(event.get("canonical_event_id") or "").strip()
    room_turn = str(event.get("room_turn") or "").strip()
    try:
        turn_seq = int(event.get("turn_seq"))
    except (TypeError, ValueError) as exc:
        raise ProjectionValidationError("turn_seq is required") from exc
    if not event_id or not room_turn or turn_seq < 0:
        raise ProjectionValidationError("canonical_event_id, room_turn, and non-negative turn_seq are required")
    return {
        "canonical_event_id": event_id,
        "room_turn": room_turn,
        "turn_seq": turn_seq,
    }


def build_storebot_telegram_projection(
    event: Mapping[str, Any],
    *,
    identity_key: bytes | str,
    now_ms: int,
    fresh_at_ms: int | None = None,
    max_source_age_ms: int = DEFAULT_MAX_SOURCE_AGE_MS,
    future_skew_ms: int = DEFAULT_FUTURE_SKEW_MS,
) -> dict[str, Any]:
    """Build one deterministic, exact-schema, no-send projection."""

    if not isinstance(event, Mapping):
        raise ProjectionValidationError("event must be a mapping")
    _assert_storebot_resource(event)
    key = _identity_key(identity_key)
    event_kind = _event_kind(event)
    status = _status(event, event_kind)
    severity = _severity(event, event_kind)
    freshness, identity_at_ms = _timestamp_ms(event, fresh_at_ms)
    current_ms = int(now_ms)
    if identity_at_ms < current_ms - max(0, int(max_source_age_ms)):
        raise ProjectionValidationError("source event is stale")
    if identity_at_ms > current_ms + max(0, int(future_skew_ms)):
        raise ProjectionValidationError("source event is too far in the future")
    occurrence = _canonical_occurrence(event)
    private_source_identity = {
        **occurrence,
        "event_kind": event_kind,
        "status": status,
        "event_at_ms": identity_at_ms,
    }
    source_hash = _opaque_hmac("stsrc", key, private_source_identity)
    request_id = _opaque_hmac("streq", key, {**private_source_identity, "scope": "request"})
    correlation_id = _opaque_hmac("stcorr", key, {**private_source_identity, "scope": "correlation"})
    projection_identity = {
        "schema": SCHEMA,
        "event_kind": event_kind,
        "resource": STOREBOT_RESOURCE,
        "request_id": request_id,
        "correlation_id": correlation_id,
        "status": status,
        "severity": severity,
        "source_hash": source_hash,
    }
    projection_id = _opaque_hmac("stp", key, projection_identity)
    redacted_preview = f"[{event_kind}:{status}]"
    projection: dict[str, Any] = {
        **projection_identity,
        "projection_id": projection_id,
        "redacted_preview": redacted_preview,
        "evidence_pointer": f"briefing_channel:projection:{projection_id}",
        "fresh_at_ms": identity_at_ms,
    }
    if event_kind == "outbound_intent":
        projection["intent"] = _intent(event)
    validate_storebot_telegram_projection(projection, now_ms=current_ms, max_source_age_ms=max_source_age_ms, future_skew_ms=future_skew_ms)
    return projection


def validate_storebot_telegram_projection(
    projection: Mapping[str, Any],
    *,
    now_ms: int | None = None,
    max_source_age_ms: int = DEFAULT_MAX_SOURCE_AGE_MS,
    future_skew_ms: int = DEFAULT_FUTURE_SKEW_MS,
) -> None:
    """Fail closed if a projection is not the exact public Phase-1 schema."""

    if not isinstance(projection, Mapping):
        raise ProjectionValidationError("projection must be a mapping")
    keys = frozenset(projection)
    if not REQUIRED_PROJECTION_KEYS.issubset(keys) or not keys.issubset(PROJECTION_KEYS):
        raise ProjectionValidationError("projection keys do not match the allowlist")
    if keys & FORBIDDEN_PROJECTION_KEYS:
        raise ProjectionValidationError("projection contains raw or secret fields")
    if projection.get("schema") != SCHEMA:
        raise ProjectionValidationError("projection schema mismatch")
    if projection.get("resource") != STOREBOT_RESOURCE:
        raise ProjectionValidationError("projection resource mismatch")
    if projection.get("event_kind") not in SUPPORTED_EVENT_KINDS:
        raise ProjectionValidationError("projection event_kind is not allowed")
    if projection.get("status") not in SAFE_STATUSES:
        raise ProjectionValidationError("projection status is not allowed")
    if projection.get("severity") not in SAFE_SEVERITIES:
        raise ProjectionValidationError("projection severity is not allowed")
    preview = str(projection.get("redacted_preview") or "")
    expected_preview = f"[{projection.get('event_kind')}:{projection.get('status')}]"
    if preview != expected_preview:
        raise ProjectionValidationError("projection preview must be status-only")
    for field, prefix in (("projection_id", "stp_"), ("request_id", "streq_"), ("correlation_id", "stcorr_"), ("source_hash", "stsrc_")):
        value = str(projection.get(field) or "")
        if not value.startswith(prefix) or not re.fullmatch(r"[a-z]+_[0-9a-f]{32}", value):
            raise ProjectionValidationError(f"projection {field} is not opaque")
    pointer = str(projection.get("evidence_pointer") or "")
    if pointer != f"briefing_channel:projection:{projection.get('projection_id')}":
        raise ProjectionValidationError("projection evidence_pointer is unsafe")
    source_ms = int(projection.get("fresh_at_ms") or 0)
    if source_ms <= 0:
        raise ProjectionValidationError("projection fresh_at_ms is invalid")
    if now_ms is not None:
        current_ms = int(now_ms)
        if source_ms < current_ms - max(0, int(max_source_age_ms)):
            raise ProjectionValidationError("projection is stale")
        if source_ms > current_ms + max(0, int(future_skew_ms)):
            raise ProjectionValidationError("projection is too far in the future")
    intent = projection.get("intent")
    if projection.get("event_kind") == "outbound_intent":
        if not isinstance(intent, Mapping):
            raise ProjectionValidationError("outbound_intent requires intent metadata")
        if intent.get("category") not in SAFE_INTENT_CATEGORIES:
            raise ProjectionValidationError("intent category is not allowed")
        if intent.get("proposal") is not True or intent.get("sent") is not False:
            raise ProjectionValidationError("outbound intent must remain an unsent proposal")
    elif intent is not None:
        raise ProjectionValidationError("intent metadata is only allowed for outbound_intent")


def incident_dedupe_key(projection: Mapping[str, Any]) -> str:
    validate_storebot_telegram_projection(projection)
    basis = {
        "resource": projection["resource"],
        "event_kind": projection["event_kind"],
        "status": projection["status"],
        "severity": projection["severity"],
        "source_hash": projection["source_hash"],
    }
    return f"sti_{_canonical_hash(basis)[:24]}"


def decide_ca_incident_projection(
    projection: Mapping[str, Any],
    *,
    now_ms: int,
    seen_projection_ids: Iterable[str] = (),
    last_emitted_at_ms_by_key: Mapping[str, int] | None = None,
    cooldown_ms: int = 300_000,
) -> dict[str, Any]:
    """Pure dedupe/cooldown decision for a future CA incident publisher.

    The return value is a proposal only; callers must apply a separate
    allowlist, authorization, and transport gate before any delivery.
    """

    validate_storebot_telegram_projection(projection)
    current_ms = int(now_ms)
    cooldown = max(0, int(cooldown_ms))
    key = incident_dedupe_key(projection)
    projection_id = str(projection["projection_id"])
    last_by_key = last_emitted_at_ms_by_key or {}
    last_emitted = int(last_by_key.get(key) or 0)

    if projection["event_kind"] != "transport_failure" or projection["severity"] not in {"warning", "error", "critical"}:
        emit, reason = False, "not_incident"
    elif projection_id in frozenset(str(value) for value in seen_projection_ids):
        emit, reason = False, "duplicate_projection"
    elif last_emitted > 0 and current_ms < last_emitted + cooldown:
        emit, reason = False, "cooldown"
    else:
        emit, reason = True, "eligible"

    return {
        "emit": emit,
        "reason": reason,
        "incident_key": key,
        "projection_id": projection_id,
        "cooldown_until_ms": max(current_ms, last_emitted + cooldown) if not emit else current_ms + cooldown,
        "intent": {
            "category": "ca_incident",
            "proposal": True,
            "sent": False,
        },
    }
