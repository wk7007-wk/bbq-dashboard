#!/usr/bin/env python3
from __future__ import annotations

import argparse
import json
import time
import urllib.parse
import urllib.request
from datetime import datetime, timedelta, timezone
from typing import Any


FIREBASE_BASE_URL = "https://poskds-4ba60-default-rtdb.asia-southeast1.firebasedatabase.app"
REQUESTS_PATH = "/packhelper/storebot_codex/requests"
HEARTBEAT_PATH = "/packhelper/storebot_codex/heartbeat"
CLAIM_LATEST_PATH = "/packhelper/storebot_termux/kakao_ingress_claims/latest"
INPUT_HEALTH_PATH = "/packhelper/storebot_termux/input_health/latest"
BRIDGE_EVENTS_PATH = "/packhelper/storebot_termux/kakao_bridge_log/events"
BRIDGE_LATEST_PATH = "/packhelper/storebot_termux/kakao_bridge_log/latest"
PENDING_QUEUE_PATH = "/packhelper/storebot_pending_queue"
KST = timezone(timedelta(hours=9))


def now_ms() -> int:
    return int(time.time() * 1000)


def age_sec(ts_ms: Any) -> int:
    try:
        value = int(float(ts_ms))
    except (TypeError, ValueError):
        return -1
    if value <= 0:
        return -1
    if value < 10_000_000_000:
        value *= 1000
    return max(0, int((now_ms() - value) / 1000))


def kst_time(ts_ms: Any) -> str:
    try:
        value = int(float(ts_ms))
    except (TypeError, ValueError):
        return "-"
    if value <= 0:
        return "-"
    if value < 10_000_000_000:
        value *= 1000
    return datetime.fromtimestamp(value / 1000, KST).strftime("%H:%M:%S")


def compact(value: Any, limit: int = 90) -> str:
    text = "" if value is None else str(value)
    text = " ".join(text.split())
    return text if len(text) <= limit else text[:limit] + "..."


KAKAO_SCREEN_UI_TOKENS = {
    "전체보기",
    "접기",
    "이전메시지전체보기",
    "더보기",
}


def compact_no_space(value: Any) -> str:
    return "".join(str(value or "").split())


def is_screen_scan_source(*values: Any) -> bool:
    joined = " ".join(str(value or "") for value in values).lower()
    return (
        "accessibility_foreground_scan" in joined
        or "foreground_scan" in joined
        or "screen_scan" in joined
        or "kakao_screen" in joined
        or "카카오화면" in joined
    )


def is_kakao_screen_ui_noise(value: Any) -> bool:
    compacted = compact_no_space(value)
    if not compacted:
        return False
    return compacted in KAKAO_SCREEN_UI_TOKENS


def firebase_get(path: str, *, timeout: float = 8.0) -> Any:
    with urllib.request.urlopen(FIREBASE_BASE_URL + path, timeout=timeout) as response:
        raw = response.read().decode("utf-8")
    if not raw or raw == "null":
        return None
    return json.loads(raw)


def query_last(path: str, limit: int) -> Any:
    query = urllib.parse.urlencode({"orderBy": '"$key"', "limitToLast": str(limit)})
    return firebase_get(f"{path}.json?{query}")


def dict_or_empty(value: Any) -> dict[str, Any]:
    return value if isinstance(value, dict) else {}


def get_request(request_id: str) -> dict[str, Any]:
    if not request_id:
        return {}
    return dict_or_empty(firebase_get(f"{REQUESTS_PATH}/{request_id.replace('/', '_')}.json"))


def request_status(request: dict[str, Any]) -> str:
    return str(
        request.get("status")
        or request.get("local_recovery_status")
        or request.get("ingress_status")
        or ""
    ).strip().lower()


def request_event_age_sec(request: dict[str, Any]) -> int:
    return age_sec(
        request.get("finished_at_ms")
        or request.get("updated_at_ms")
        or request.get("created_at_ms")
        or request.get("ts_ms")
        or request.get("ts")
    )


def get_events(path: str, limit: int) -> list[dict[str, Any]]:
    raw = query_last(path, limit)
    if not isinstance(raw, dict):
        return []
    rows: list[dict[str, Any]] = []
    for key, value in sorted(raw.items()):
        if isinstance(value, dict):
            item = dict(value)
            item["_key"] = key
            rows.append(item)
    return rows


def get_latest_error_request(limit: int) -> tuple[str, dict[str, Any]]:
    for item in reversed(get_events(REQUESTS_PATH, max(1, limit))):
        status = request_status(item)
        if status in {"error", "action_error"}:
            return str(item.get("_key") or item.get("request_id") or ""), item
    return "", {}


def input_health_summary(input_health: dict[str, Any], active_window_sec: int, input_stale_sec: int) -> dict[str, Any]:
    active_scan_ts = input_health.get("last_active_scan_ms")
    if not active_scan_ts and input_health.get("event") == "active_scan":
        active_scan_ts = input_health.get("updated_at_ms")
    foreground_scan_ts = input_health.get("last_foreground_scan_ms")
    if not foreground_scan_ts and input_health.get("event") == "foreground_scan":
        foreground_scan_ts = input_health.get("updated_at_ms")
    foreground_claim_ts = input_health.get("last_foreground_claim_ms")
    last_claim_ts = input_health.get("last_claim_created_ms")
    last_notification_ts = input_health.get("last_notification_seen_ms")
    last_ingress_ts = input_health.get("last_ingress_ts_ms")
    latest_input_ts = max(
        (int(ts) for ts in (last_claim_ts, last_notification_ts, last_ingress_ts) if isinstance(ts, (int, float))),
        default=0,
    )

    active_scan_age = age_sec(active_scan_ts)
    foreground_scan_age = age_sec(foreground_scan_ts)
    latest_input_age = age_sec(latest_input_ts)
    active_scan_fresh = 0 <= active_scan_age <= active_window_sec
    foreground_scan_fresh = 0 <= foreground_scan_age <= active_window_sec
    input_stale = (active_scan_fresh or foreground_scan_fresh) and latest_input_age >= input_stale_sec
    last_foreground_preview = compact(
        input_health.get("last_foreground_message_preview")
        or input_health.get("last_foreground_claim_preview")
        or input_health.get("last_foreground_scan_preview"),
        80,
    )
    last_message_preview = compact(input_health.get("last_message_preview"), 80)
    screen_scan_source = is_screen_scan_source(
        input_health.get("source"),
        input_health.get("last_sender"),
        input_health.get("last_transport"),
        input_health.get("ingress_trigger"),
    )
    ui_noise_preview = last_message_preview or last_foreground_preview
    screen_scan_ui_noise = screen_scan_source and is_kakao_screen_ui_noise(ui_noise_preview)
    return {
        "present": bool(input_health),
        "status": input_health.get("status") or input_health.get("request_status") or input_health.get("event") or input_health.get("source"),
        "event": input_health.get("event"),
        "source": input_health.get("source"),
        "request_status": input_health.get("request_status"),
        "active_scan_age_sec": active_scan_age,
        "active_scan_fresh": active_scan_fresh,
        "foreground_scan_age_sec": foreground_scan_age,
        "foreground_scan_fresh": foreground_scan_fresh,
        "last_foreground_claim_age_sec": age_sec(foreground_claim_ts),
        "last_foreground_message_preview": last_foreground_preview,
        "latest_input_age_sec": latest_input_age,
        "last_claim_age_sec": age_sec(last_claim_ts),
        "last_notification_age_sec": age_sec(last_notification_ts),
        "last_ingress_age_sec": age_sec(last_ingress_ts),
        "input_stale": input_stale,
        "last_request_id": input_health.get("last_request_id"),
        "last_request_error_id": input_health.get("last_request_error_id"),
        "last_request_error_age_sec": age_sec(input_health.get("last_request_error_at_ms")),
        "last_request_error": compact(input_health.get("last_request_error"), 120),
        "last_request_error_status": input_health.get("last_request_error_status"),
        "last_request_diagnostic_id": input_health.get("last_request_diagnostic_id"),
        "last_request_diagnostic_age_sec": age_sec(input_health.get("last_request_diagnostic_at_ms")),
        "last_request_diagnostic_candidate_type": input_health.get("last_request_diagnostic_candidate_type"),
        "last_request_diagnostic_enqueue_status": input_health.get("last_request_diagnostic_enqueue_status"),
        "diagnostic_enqueued": input_health.get("diagnostic_enqueued"),
        "self_fix_enqueued": input_health.get("self_fix_enqueued"),
        "last_message_preview": last_message_preview,
        "screen_scan_source": screen_scan_source,
        "screen_scan_ui_noise": screen_scan_ui_noise,
        "screen_scan_ui_noise_preview": ui_noise_preview if screen_scan_ui_noise else "",
        "last_room_name": input_health.get("last_room_name"),
        "last_sender": input_health.get("last_sender"),
        "last_transport": input_health.get("last_transport"),
    }


def worker_summary(heartbeat: dict[str, Any]) -> tuple[str, str]:
    if not heartbeat:
        return "OFF", "heartbeat 없음"
    hb_age = age_sec(heartbeat.get("ts"))
    if hb_age > 90:
        return "OFF", f"heartbeat stale {hb_age}s"
    if heartbeat.get("local_direct_listening") is not True:
        return "LOCAL_DIRECT_OFF", "local-direct listener 꺼짐"
    if heartbeat.get("resident_app_server_enabled") is True and heartbeat.get("resident_app_server_active") is not True:
        return "AI_SESSION_NOT_READY", compact(heartbeat.get("resident_app_server_last_error") or "resident app-server inactive")
    return "OK", (
        f"worker={heartbeat.get('status') or '-'} "
        f"model={heartbeat.get('model') or '-'} "
        f"app_server={heartbeat.get('resident_app_server_active')} "
        f"turn={heartbeat.get('resident_app_server_last_turn_duration_ms') or 0}ms"
    )


def classify_request(request: dict[str, Any], heartbeat: dict[str, Any], warn_sec: int) -> tuple[str, str]:
    if not request:
        return "NO_REQUEST", "request 없음"
    status = str(
        request.get("status")
        or request.get("local_recovery_status")
        or request.get("ingress_status")
        or ""
    )
    req_age = age_sec(request.get("created_at_ms") or request.get("ts_ms") or request.get("ts"))
    if status == "local_direct_inflight":
        worker_state, worker_note = worker_summary(heartbeat)
        if worker_state != "OK":
            return "STUCK", f"입력 잡힘 {req_age}s, {worker_note}"
        if req_age >= warn_sec:
            return "SLOW", f"AI 처리/미러 지연 {req_age}s, {worker_note}"
        return "INFLIGHT", f"AI 처리중 {req_age}s, {worker_note}"
    if status == "pending":
        if request.get("local_direct_fallback"):
            return "LEGACY_PENDING", "local-direct 실패 후 legacy pending fallback 대기"
        return "PENDING", "Firebase poll 대기"
    if status == "local_recovery_pending":
        return "LOCAL_RECOVERY_PENDING", compact(request.get("local_recovery_error") or request.get("local_recovery_reason") or "서버폰 로컬 회수 대기")
    if status == "running":
        return "RUNNING", f"worker poll 처리중 {req_age}s"
    if status == "done":
        elapsed = request.get("local_direct_elapsed_ms") or request.get("elapsed_ms") or "-"
        category = request.get("output_category") or ""
        if request.get("reply_skipped") is True:
            return "SKIP_DONE", f"AI 스킵/비카톡 완료 category={category or '-'} elapsed={elapsed}ms"
        if request.get("publish_disabled") is True:
            return "REPLY_DONE_DIRECT", f"AI 답변 완료 direct category={category or 'kakao_reply'} elapsed={elapsed}ms"
        return "REPLY_DONE_QUEUED", f"AI 답변 완료 outbound={request.get('outbound_key') or '-'}"
    if status in {"error", "action_error"}:
        return "ERROR", compact(request.get("error") or request.get("last_error") or "error")
    return status.upper() or "UNKNOWN", f"status={status or '-'} age={req_age}s"


def bridge_message_is_noise(message: Any) -> bool:
    text = str(message or "").lower()
    return (
        "accessibility repair denied" in text
        or "accessibility repair skipped" in text
        or "wakelock" in text
    )


def snapshot(args: argparse.Namespace) -> tuple[str, dict[str, Any]]:
    heartbeat = dict_or_empty(firebase_get(HEARTBEAT_PATH + ".json"))
    claim = dict_or_empty(firebase_get(CLAIM_LATEST_PATH + ".json"))
    input_health = dict_or_empty(firebase_get(INPUT_HEALTH_PATH + ".json"))
    input_summary = input_health_summary(input_health, args.window_sec, args.input_stale_sec)
    claim_age = age_sec(claim.get("created_at_ms") or claim.get("updated_at_ms") or claim.get("ts_ms"))
    claim_request_id = str(claim.get("request_id") or "")
    input_request_id = str(input_health.get("last_request_id") or "")
    if args.request_id:
        request_id = args.request_id
    elif claim_request_id and 0 <= claim_age <= args.window_sec:
        request_id = claim_request_id
    elif input_request_id:
        request_id = input_request_id
    else:
        request_id = claim_request_id
    request = get_request(request_id)
    recent_error_request_id = str(input_health.get("last_request_error_id") or "")
    recent_error_request = get_request(recent_error_request_id)
    recent_error_status = request_status(recent_error_request) or str(input_health.get("last_request_error_status") or "").strip().lower()
    recent_error_age = age_sec(input_health.get("last_request_error_at_ms"))
    if recent_error_age < 0:
        recent_error_age = request_event_age_sec(recent_error_request)
    latest_error_id, latest_error_request = get_latest_error_request(args.request_error_limit)
    latest_error_age = request_event_age_sec(latest_error_request)
    if (
        latest_error_id
        and 0 <= latest_error_age <= args.error_window_sec
        and (not recent_error_request_id or recent_error_age < 0 or latest_error_age <= recent_error_age)
    ):
        recent_error_request_id = latest_error_id
        recent_error_request = latest_error_request
        recent_error_status = request_status(recent_error_request)
        recent_error_age = latest_error_age
    recent_error_text = compact(
        input_health.get("last_request_error")
        or recent_error_request.get("error")
        or recent_error_request.get("last_error"),
        180,
    )
    recent_error_recent = (
        bool(recent_error_request_id)
        and recent_error_status in {"error", "action_error"}
        and 0 <= recent_error_age <= args.error_window_sec
    )
    bridge_latest = dict_or_empty(firebase_get(BRIDGE_LATEST_PATH + ".json"))
    events = get_events(BRIDGE_EVENTS_PATH, args.events)
    pending = get_events(PENDING_QUEUE_PATH, args.pending)

    if args.request_id:
        state, note = classify_request(request, heartbeat, args.inflight_warn_sec)
        preview = compact(request.get("message") or request.get("text"), 50)
        note = f"{note} | req={request_id or '-'} msg='{preview}'"
    elif claim and 0 <= claim_age <= args.window_sec:
        state, note = classify_request(request, heartbeat, args.inflight_warn_sec)
        preview = compact(request.get("message") or claim.get("message_preview"), 50)
        note = f"{note} | req={request_id or '-'} msg='{preview}'"
    else:
        worker_state, worker_note = worker_summary(heartbeat)
        bridge_age = age_sec(bridge_latest.get("ts_ms"))
        bridge_msg = compact(bridge_latest.get("message"), 90)
        request_state, request_note = classify_request(request, heartbeat, args.inflight_warn_sec)
        request_age = request_event_age_sec(request)
        if worker_state != "OK":
            state, note = worker_state, worker_note
        elif input_summary["input_stale"]:
            state = "KAKAO_INPUT_STALE"
            note = (
                f"active scan {input_summary['active_scan_age_sec']}s, "
                f"fg scan {input_summary['foreground_scan_age_sec']}s, "
                f"last input {input_summary['latest_input_age_sec']}s "
                f"last_notif={input_summary['last_notification_age_sec']}s "
                f"last_ingress={input_summary['last_ingress_age_sec']}s "
                f"req={input_summary['last_request_id'] or '-'} "
                f"msg='{input_summary['last_message_preview'] or ''}'"
            )
        elif input_summary["screen_scan_ui_noise"] and (
            input_summary["active_scan_fresh"] or input_summary["foreground_scan_fresh"]
        ):
            state = "KAKAO_INPUT_STALE"
            note = (
                f"screen scan UI-noise '{input_summary['screen_scan_ui_noise_preview']}', "
                f"active={input_summary['active_scan_age_sec']}s "
                f"fg={input_summary['foreground_scan_age_sec']}s "
                f"last_notif={input_summary['last_notification_age_sec']}s "
                f"last_ingress={input_summary['last_ingress_age_sec']}s"
            )
        elif request_state in {"ERROR", "ACTION_ERROR"} and 0 <= request_age <= args.error_window_sec:
            state, note = request_state, f"{request_note} | req={request_id or '-'}"
        elif recent_error_recent:
            state = "RECENT_REQUEST_ERROR"
            note = (
                f"최근 request error {recent_error_age}s "
                f"req={recent_error_request_id} err='{recent_error_text}'"
            )
        elif bridge_latest and 0 <= bridge_age <= args.window_sec and not bridge_message_is_noise(bridge_msg):
            state, note = "BRIDGE_EVENT_ONLY", f"worker 정상, 최근 bridge {bridge_age}s: {bridge_msg}"
        else:
            state, note = "NO_RECENT_INPUT", f"worker 정상, 최근 {args.window_sec}s 내 카톡 입력 claim 없음"

    latest_event = events[-1] if events else {}
    latest_pending = pending[-1] if pending else {}
    payload = {
        "state": state,
        "note": note,
        "claim": {
            "request_id": claim.get("request_id"),
            "status": claim.get("status"),
            "age_sec": claim_age,
            "transport": claim.get("transport"),
            "message_preview": compact(claim.get("message_preview"), 80),
        },
        "request": {
            "request_id": request.get("request_id") or request_id or None,
            "status": request.get("status"),
            "ingress_status": request.get("ingress_status"),
            "local_recovery_status": request.get("local_recovery_status"),
            "reply_skipped": request.get("reply_skipped"),
            "output_category": request.get("output_category"),
            "elapsed_ms": request.get("local_direct_elapsed_ms") or request.get("elapsed_ms"),
            "source": request.get("source"),
            "fallback": request.get("local_direct_fallback"),
            "local_recovery": request.get("local_recovery_pending"),
            "diagnostic_enqueued": request.get("diagnostic_enqueued"),
            "self_fix_enqueued": request.get("self_fix_enqueued"),
            "diagnostic_request_id": request.get("diagnostic_request_id"),
            "diagnostic_enqueue_status": request.get("diagnostic_enqueue_status"),
            "message_preview": compact(request.get("message") or request.get("text"), 80),
        },
        "heartbeat": {
            "age_sec": age_sec(heartbeat.get("ts")),
            "status": heartbeat.get("status"),
            "local_direct_listening": heartbeat.get("local_direct_listening"),
            "resident_app_server_active": heartbeat.get("resident_app_server_active"),
            "resident_session_preboot_ready": heartbeat.get("resident_session_preboot_ready"),
            "resident_session_health_ok": heartbeat.get("resident_session_health_ok"),
            "last_turn_ms": heartbeat.get("resident_app_server_last_turn_duration_ms"),
        },
        "input_health": input_summary,
        "recent_error_request": {
            "present": bool(recent_error_request_id),
            "recent": recent_error_recent,
            "request_id": recent_error_request_id or None,
            "status": recent_error_status or None,
            "age_sec": recent_error_age,
            "error": recent_error_text,
            "message_preview": compact(recent_error_request.get("message") or recent_error_request.get("text"), 80),
            "source": recent_error_request.get("source"),
            "elapsed_ms": recent_error_request.get("local_direct_elapsed_ms") or recent_error_request.get("elapsed_ms"),
            "diagnostic_enqueued": recent_error_request.get("diagnostic_enqueued") or input_health.get("diagnostic_enqueued"),
            "self_fix_enqueued": recent_error_request.get("self_fix_enqueued") or input_health.get("self_fix_enqueued"),
            "diagnostic_request_id": recent_error_request.get("diagnostic_request_id") or input_health.get("last_request_diagnostic_id"),
            "diagnostic_enqueue_status": recent_error_request.get("diagnostic_enqueue_status") or input_health.get("last_request_diagnostic_enqueue_status"),
        },
        "bridge_latest": {
            "age_sec": age_sec(bridge_latest.get("ts_ms")),
            "message": compact(bridge_latest.get("message"), 120),
            "noise": bridge_message_is_noise(bridge_latest.get("message")),
        },
        "latest_event": {
            "time": kst_time(latest_event.get("ts_ms")),
            "message": compact(latest_event.get("message"), 120),
        },
        "latest_pending": {
            "key": latest_pending.get("_key"),
            "sent": latest_pending.get("sent"),
            "sent_at": kst_time(latest_pending.get("sent_at_ms")),
            "message": compact(latest_pending.get("message"), 80),
        },
    }
    line = (
        f"[{datetime.now(KST).strftime('%H:%M:%S')}] {state} - {note} | "
        f"hb={payload['heartbeat']['status']} ld={payload['heartbeat']['local_direct_listening']} "
        f"ai={payload['heartbeat']['resident_session_preboot_ready']}/{payload['heartbeat']['resident_session_health_ok']} "
        f"fg={payload['input_health'].get('foreground_scan_age_sec')}s/"
        f"{payload['input_health'].get('last_foreground_claim_age_sec')}s"
    )
    return line, payload


def run_once(args: argparse.Namespace) -> int:
    line, payload = snapshot(args)
    if args.json:
        print(json.dumps(payload, ensure_ascii=False, indent=2, sort_keys=True))
    else:
        print(line)
        if args.show_events:
            print(f"  bridge: {payload['bridge_latest']['message']}")
            print(f"  event : {payload['latest_event']['time']} {payload['latest_event']['message']}")
            print(f"  pending: {payload['latest_pending']['key']} sent={payload['latest_pending']['sent']} {payload['latest_pending']['message']}")
    return 0


def run_watch(args: argparse.Namespace) -> int:
    last_line = ""
    deadline = time.monotonic() + args.timeout_sec if args.timeout_sec > 0 else None
    while True:
        try:
            line, payload = snapshot(args)
            if args.json:
                print(json.dumps(payload, ensure_ascii=False, sort_keys=True), flush=True)
            elif args.repeat or line != last_line:
                print(line, flush=True)
                last_line = line
        except Exception as exc:
            print(f"[{datetime.now(KST).strftime('%H:%M:%S')}] DIAG_ERROR - {compact(exc, 160)}", flush=True)
        if deadline is not None and time.monotonic() >= deadline:
            return 0
        time.sleep(max(1.0, float(args.interval_sec)))


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description="StoreBot 카톡 답변 경로 실시간 CLI 진단")
    parser.add_argument("--watch", action="store_true", help="계속 감시")
    parser.add_argument("--json", action="store_true", help="JSON 출력")
    parser.add_argument("--repeat", action="store_true", help="watch에서 같은 상태도 반복 출력")
    parser.add_argument("--request-id", default="", help="특정 request_id 추적")
    parser.add_argument("--interval-sec", type=float, default=5.0)
    parser.add_argument("--timeout-sec", type=float, default=0.0, help="watch 종료 시간. 0은 무제한")
    parser.add_argument("--window-sec", type=int, default=600)
    parser.add_argument("--error-window-sec", type=int, default=7200)
    parser.add_argument("--request-error-limit", type=int, default=80)
    parser.add_argument("--inflight-warn-sec", type=int, default=150)
    parser.add_argument("--input-stale-sec", type=int, default=7200)
    parser.add_argument("--events", type=int, default=20)
    parser.add_argument("--pending", type=int, default=10)
    parser.add_argument("--show-events", action="store_true")
    return parser.parse_args()


def main() -> int:
    args = parse_args()
    if args.watch:
        return run_watch(args)
    return run_once(args)


if __name__ == "__main__":
    raise SystemExit(main())
