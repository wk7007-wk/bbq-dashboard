# StoreBot Codex 브리지

## 단일 기록 기준
- 이 파일은 StoreBot AI 답변 루트의 상세 SOT다. 상주 세션, 하이브리드, OpenClaw 후보, 카톡 전송 경계, 검증 기록은 여기만 갱신한다.
- Fast-first 보조 응답 + Codex 보정 답변 lane의 확정 설계와 테스트 기준은 `subphone/STOREBOT_FAST_FIRST_CLI_DESIGN.md`에 둔다.
- `CODEX_BRIEF.md`, `AI_HANDOFF.md`, `CODEMAP.txt`, `rules/openclaw.txt`, `/root/StoreBotTermux/APP_INTENT.md`에는 짧은 포인터만 둔다.
- 근무표/뉴스/월드컵/콘티 같은 카톡 답변 세부 규칙 SOT는 `.agents/skills/storebot-kakao-reply/SKILL.md`다. 이 파일에는 세부 출력 규칙을 중복하지 않는다.

## 목표
- StoreBotTermux 단일 앱이 서브폰의 Codex CLI/proot/Python 세션과 카카오 입출력을 함께 소유한다.
- 일반 AI 답변의 현재 목표 기준은 StoreBotTermux backplane + resident CLI/app-server/terminal session이다. `codex exec/resume`과 외부 API는 기본 hot path가 아니라 제거/비활성화 대상이다.
- 기본 실행은 StoreBotTermux `TermuxService` foreground 세션에 worker와 resident app-server를 붙잡아 두고, preboot된 `storebot_group` session/thread를 일반 카톡 입력의 기본 경로로 재사용하는 것이다. shell/nohup/watchdog sidecar와 one-shot exec fallback은 기본 경로가 아니다.
- worker 판단력 의존은 절대 불가다. `fast_router`는 worker 자연어 판단기가 아니라 Codex 세션 resume 경로 이름이다.
- worker/App/monitor/codex_ops는 자연어 의미, 업무 여부, 답변/SKIP, action/domain/slot을 판단하지 않는다. 이 값은 `storebot-kakao-reply` 스킬을 읽은 Codex/LLM 출력 또는 명시 시스템 이벤트 계약에서만 나온다.
- worker가 할 수 있는 선처리는 자기 메시지, 빈값, 완전 중복, 카카오 UI 토큰 같은 해석 없는 하드가드와 claim/dedupe/transport 노이즈 제거뿐이다. regex, 키워드, 로컬 휴리스틱, fallback worker 판단으로 카톡 업무를 처리하면 실패다.
- worker는 매 턴 최근 방 원장과 직전 StoreBot 답변을 짧게 envelope에 붙여 Codex/skill 판단 재료로만 넘긴다. `진우104.1808` 같은 주소 축약이나 `ㄱ연옥` 같은 짧은 후속 정정은 worker가 뜻을 확정하지 않고, 스킬이 최근 맥락 기준으로 주소/정정/확인/ROUTE_FULL/SKIP을 결정한다.
- 하이브리드는 두 엔진 동시 생성이 아니다. 살아있는 상주 세션을 우선 쓰고, 죽은 세션은 다시 살려 대기 상태로 복구하는 운용 개념이다.
- 2026-06-18 속도 재점검 기록: stateless fast-router는 단문 OK도 약 88초, 근무표 요청은 115초 sync timeout/deferred가 나와 터미널 상주 의도와 맞지 않았다. 당시 fast-router prewarm/resume으로 되돌렸던 기준은 2026-07-09 resident default 전환 이후 역사 기록으로만 본다.
- 2026-06-16 KST 문구 남발/ADB 복구 보정: 공개 StoreBotTermux `0.118.3-storebot.34`, worker bundle `0616.2010`. `system_*`, `skip`, deferred 응답은 카톡 무발송이고 `sender=카카오화면`, message `lee` smoke는 빈 reply skip으로 통과했다. Android 무발송 PATCH는 원래 `skip_reason`을 보존한다. ADB 토글 OFF 복구는 Tasker 또는 StoreBotTermux `AdbRecoveryAgent`가 `toggle_if_off=true` 명령을 받아 무선 디버깅 ON 전환 후 endpoint/status/screenshot을 먼저 올려야 완료다. 서버폰 smoke에서 `10.15.19.73:41353` 발행과 command `done/published_endpoint` 확인.
- 런타임 기준: 현재 목표 기본은 Codex resident StoreBot session이다. 같은 세션 연속 입력에서 세션 끊김 없음, stale event 격리, clean reply 캡처, 평균 속도 개선을 검증하고, API나 one-shot exec fallback은 성공 경로로 세지 않는다.
- API direct는 속도 후보에서 제외한다. 비용 부담이 있고 Codex/Wonmux형 세션 연속성, 스킬 주입, 장기 맥락 유지 방식과 맞지 않는다.
- 하드코딩/regex 답변은 속도 후보가 아니다. 자기 메시지, 중복, 빈값, 카카오 UI 노이즈 제거 같은 안전 guard는 가능하지만 업무 의미 판단을 로컬 규칙으로 대체하지 않는다.
- 속도 개선의 1차 방향은 `codex exec resume`/CLI/proot/세션 부팅 경계 제거다. 서버폰은 Kakao와 Termux가 같은 foreground 로컬 장치에 있으므로 Android->worker 통신보다 resident app-server, 운영방 thread preboot, keepalive, local socket 같은 부팅 없는 호출을 우선 비교한다.
- 다음 구조 변경은 no-send 벤치마크 뒤에만 한다. 현재 `codex exec resume`과 resident/preboot 후보를 감지, worker 처리, AI turn, 카카오 전송 단계로 나눠 측정하고, 실제 카카오 발송 없이 no-publish/no-send로 먼저 검증한다.

## 2026-07-07 resident/preboot 확정 + no-send 검증
- 확정 원칙: StoreBotTermux AI 답변 속도 개선 1순위는 resident/preboot/local socket 계열의 부팅 없는 호출이다. 목표는 매 요청마다 `codex exec resume`/CLI/proot/session 부팅 경계를 없애고 이미 떠 있는 LLM session/server에 local-direct로 주입하는 것이다.
- 제외 원칙: API direct는 비용과 Codex/Wonmux형 세션 맥락 유지 문제로 제외한다. 고정 문구, regex, hardcoded 답변은 AI 답변이 아니므로 제외한다.
- 맥락 조건: 후보 엔진은 LLM 사용을 유지하면서 room/thread/session 단위 맥락을 보존해야 한다. 같은 room/session 2턴 기억, 다른 room/session 격리, stale context reset, rule/skill hash 변경 시 새 세션 생성이 통과되어야 한다.
- 2026-07-07 당시 코드 상태: `STOREBOT_CODEX_RESIDENT_APP_SERVER`, `STOREBOT_CODEX_RESIDENT_SESSION_PREBOOT`, watchdog/keepalive 코드는 존재하지만 start wrapper 기본값은 app-server/preboot/watchdog off였다. 이 기준은 아래 2026-07-09 resident default rollout 이후 현재 기본값이 아니다.
- no-send 테스트: 임시 `CODEX_HOME`, read-only sandbox, MCP off, live worker/ADB/Kakao/Firebase publish 없이 실행했다. `codex exec resume`는 turn1 4235ms, turn2 3658ms로 같은 세션 token 기억 통과, 새 세션 4577ms 격리 통과, greeting skip 7229ms 통과. resident app-server는 thread preboot 1148ms였지만 첫 turn이 120000ms timeout 됐고, 이후 다른 thread가 앞 thread token을 답해 thread 격리 실패를 재현했다.
- 판정: LLM 맥락 유지는 `codex exec resume` 세션으로 가능하다. resident/preboot 후보는 방향은 맞지만 현재 구현은 timeout 뒤 late event가 다른 turn/thread로 섞일 수 있어 live 후보로 승격 불가다.
- resident/preboot 최소 패치 전제: app-server event를 turn/thread id로 상관시킨다. timeout 시 turn cancel 또는 stale event drain을 한다. thread별 in-flight lock과 room_key isolation을 둔다. rule/skill/prompt hash 변경 시 preboot thread를 폐기한다. revive 뒤에는 no-send context/isolation test를 먼저 통과해야 한다.
- 리스크와 완화: 발열/배터리/RAM은 foreground service, thermal mode, 저부하 시간, turn/token cap으로 제한한다. Android background kill은 `TermuxService` foreground, heartbeat, watchdog/keepalive로 복구한다. stale session/세션 오염/방 섞임은 room_key, instruction hash, turn correlation, TTL reset으로 막는다. 중복 답장/중복 발송은 request_id, claim/dedupe, outbound idempotence, no-send gate로 막는다. fallback은 조용한 혼합이 아니라 resident unhealthy -> 명시 fallback/revive -> no-send 재검증 순서로만 허용한다. prompt/rules 갱신은 hash mismatch reset으로 반영한다. local socket/API key는 loopback only와 권한 제한을 유지한다. 장시간 유지 누수는 max age/turn count 재시작과 fd/RSS heartbeat를 둔다.

## 2026-07-09 resident default rollout and API correction
- Current live baseline: server phone APK `com.sbotux` versionName `0.118.3-storebot-kst0709.t0521`, versionCode `1069`; factory PC USB ADB serial `R39M30RWR2F` install succeeded, `lastUpdateTime=2026-07-09 05:31:49`; worker bundle `0709.0920` sha `579db15e8259d244c1a8606b04b00fe9473fc9395fa87237ec3006ae02d31f5b`; resident/preboot/local-direct 기본 구조 적용됨.
- Verified send: 이전 전용방 live 1회 발송 `스토어봇 연결 테스트 완료` PASS, 중복 없음. no-send clean reply gate, learning suppression, PyYAML warning 정리는 완료 상태다. 현재 목표는 카톡 전송 재검증이 아니라 resident 백판 속도/안정화다.
- Resident result contract: completed hot path result must show `brain_route=resident`, `reply_source=resident_session`, `fallback_used=false`. Fallback exec is visible as fallback and is not a completed resident rollout result.
- Current bottleneck: factory PC USB ADB internal local-direct nc request `adb_local_direct_speed_1783551198126_d19f548d` returned HTTP 200/`ok=true` with `wall_time_ms=99299`, `resident_turn_duration_ms=90479`, `resident_wait_ms=90479`, `total_ms=97263`, `bottleneck_stage=resident_wait_ms`; this is resident app-server turn wait, not queue/boot/local-direct transport delay.
- Code-ready correction: fast API brain/Groq/OpenAI route and local secret loader/helper are no longer default. `STOREBOT_FAST_BRAIN_ENABLED=0`, fast secret loading is opt-in, API disabled/no-key is not recorded as resident fallback, and `STOREBOT_CODEX_RESIDENT_FALLBACK_EXEC=0` is the default.
- Resident app-server hardening: `_turn_locked()` filters `item/completed`, delta, token usage, and `turn/completed` by thread/turn id where present, records `resident_turn_id`/`resident_stale_event_discard_count`, and closes the resident process on timeout or `resident_response_health_empty_final` so late/blank events cannot leak into the next turn. Empty final is a retryable runtime/self_fix signal; delta-only text is recovered before failure. Recent room/correction/payload caps were reduced.
- Remaining live target: confirm worker heartbeat adoption, then factory PC USB ADB local-direct no-send remeasure. Success still requires `brain_route=resident`, `reply_source=resident_session`, `fallback_used=false`; hosted bundle alone is not phone adoption proof.

- 카카오톡 운영방 1개를 기준으로 Codex 세션을 유지한다.
- 사용자 UI는 카카오톡 단체방이다. StoreBotTermux는 별도 업무 UI가 아니라 카톡 입출력, 세션 호스팅, 허용 도구 실행, 장애 보존을 맡는 단일 호스트 앱이다.
- 기준은 Codex-main resident session이다. API 계열 Gemini/Groq/OpenAI fast brain fallback은 기본 답변 경로가 아니며, Codex 스킬/자가학습 기준을 대체하지 않는다.
- 실시간 카카오 응답 hot path는 외부 서버/Firebase를 경유하지 않는다. 기본 경로는 `카카오톡 -> StoreBotTermux -> 127.0.0.1 local-direct -> Codex resident app-server/session -> StoreBotTermux 답장`이고, Firebase는 요청 미러/누락 보존/감사/원격 복구명령에만 쓴다. local-direct 실패 입력의 1차 회수도 Firebase poll이 아니라 StoreBotTermux 앱 내부 local recovery queue가 맡는다.
- 운영 판단 규칙은 `storebot-kakao-reply/SKILL.md`가 1차 기준이다. worker/Android는 자연어를 먼저 분류하거나 의도별 데이터를 미리 주입하지 않는다.
- 기본 입구는 StoreBotTermux의 카카오 notification listener/accessibility service다. 앱이 카톡 알림 ReplyAction과 화면 fallback을 잡아 같은 서브폰 내부 HTTP `http://127.0.0.1:8765/storebot/request`로 넘기고, 성공 시 같은 앱이 RemoteInput 또는 접근성 경로로 답장을 보낸다.
- 입력 운반 하이브리드 기준: notification posted, active notification scan, accessibility room scan이 같은 메시지를 잡으면 StoreBotTermux가 2분 claim으로 먼저 잡힌 1건만 처리한다. 이는 자연어 판단이 아니라 운반 중복 제거이며, 업무/SKIP/action 판단은 계속 Codex/스킬 출력만 기준으로 한다.
- foreground standby 정책은 Kakao를 계속 foreground에 두지 않고 StoreBotTermux foreground service와 notification/RemoteInput 우선을 기본 방향으로 둔다. `/packhelper/storebot_termux/storebot_foreground_standby_enabled`는 기본 off이며, on일 때만 접근성 foreground scan을 저 duty로 낮춘다. Activity foreground는 `com.sbotux.STOREBOT_FOREGROUND_STANDBY` 1회 entrypoint일 뿐 강제 루프가 아니다.
- 카톡 메시지를 잡은 순간 앱은 내부 dedupe/claim을 먼저 잡고 local-direct로 바로 보낸다. Firebase request에는 `ingress_status=local_direct_inflight`를 비동기 미러로 남긴다. local-direct가 실패하면 같은 requestId는 앱 내부 local recovery queue에 저장되고, Firebase에는 `local_recovery_pending` 보조 상태만 남긴다. 따라서 “큐가 안 올라옴”은 `앱 입력 없음`, `local-direct 처리 중`, `local recovery 대기`, `done/skip` 중 어디인지로 분리해서 본다.
- `ingress_status=local_direct_inflight`와 `local_recovery_pending`이 오래 남으면 CLI/monitor가 앱 내부 recovery queue, resident health, worker heartbeat 중 어느 지점이 막혔는지 보고 self_fix 후보로 올린다.
- 답변 세션 출력은 일반 텍스트/SKIP 외에 `STOREBOT_OUTPUT` JSON을 허용한다. `kakao_reply`만 카톡으로 나가고, `report/log_only/self_heal/self_fix/skip`은 카톡 발송과 분리된다.
- `self_fix`는 `/packhelper/codex_ops_v2/requests`에 `gpt-5.5/xhigh`, 같은 서버폰 repo/AGENTS 기준 작업으로 들어간다. 승인 지연으로 복구가 멈추지 않게 기본 `is_owner=true`, `approval_policy=never` 환경에서 진행하되 destructive reset/force push/비밀 노출은 계속 금지한다.
- 여기서 말하는 goal mode는 도구 goal이 아니라 운영 모드다. 사용자 추가 승인 없이 분석/복구/자가수정을 계속 진행해 승인 딜레이 때문에 멈추지 않는 것을 뜻한다.
- `codex_ops` 실행자는 StoreBotTermux worker launch/restart 때 같이 기동한다. self_fix 큐만 만들고 실행자가 죽어 있는 상태를 정상으로 보지 않는다.
- local-direct 실시간 답변은 기본적으로 중간 deadline 없이 같은 HTTP 요청을 유지한다. Android read timeout은 600초, worker/fast-router timeout은 540초 기준이며, 완료되면 StoreBotTermux가 즉시 답장한다. `STOREBOT_CODEX_LOCAL_DIRECT_SYNC_TIMEOUT_SEC_OVERRIDE`와 `STOREBOT_CODEX_LOCAL_DIRECT_DEFERRED_PUBLISH_OVERRIDE`를 함께 켠 명시 legacy 테스트에서만 늦게 완성된 일반 답변을 `/packhelper/storebot_pending_queue`로 후속 발송한다.
- `sender=카카오화면` 숫자/`lee`/방제목/프로필형/카카오 하단 탭 단어 accessibility 화면 스캔 잡음은 앱/worker가 AI 호출 전 무발송 처리하고, monitor도 느린 무응답 장애로 보지 않는다. 실제 사람이 보낸 숫자나 단어 답변은 sender가 다르므로 이 규칙 대상이 아니다.
- resident app-server/session에서 schedule/query 같은 action 또는 긴 답변을 처리한 뒤에는 다음 단문 판단이 무거워지지 않도록 stale event drain, turn correlation, prompt cap을 확인한다. 세션은 부팅 때만 compact contract를 넣고 매 턴은 짧은 envelope만 보낸다.
- 근무표/브리핑 응답에 `image_request.type=schedule_briefing`이 있으면 StoreBotTermux가 PNG 카드를 렌더링해 카카오 이미지 공유 전송을 먼저 시도한다. 실패해도 긴 근무표 텍스트를 대신 보내지 않는다.
- OpenClaw 연동은 Codex CLI 화면을 긁는 대체제가 아니라 최종 답변 이벤트를 구조적으로 잡는 실험 경로다. 기본 카톡 답변 엔진은 계속 `codex exec --json -o <output>` 기반 worker다.
- Firebase 요청 큐는 로컬 다이렉트 결과 미러, 보조 상태 기록, 누락 보존/감사 경로다. 누락 조정도 1차는 서버폰 내부 claim/local-direct/local recovery queue로 처리하고, Firebase는 앱 재시작/원격 점검/사후 재처리용 보존 장부로 본다.
- briefing_channel은 카카오 앱 embed가 아니라 worker가 소유하는 로컬 상황판이다. 구조 기준은 `카카오톡 앱 ↔ StoreBotTermux KakaoAdapter transport ↔ worker-owned briefing_channel ↔ AI/resident session`이며, Android는 `127.0.0.1:8765/storebot/briefing-channel/event`로 입력/처리상태/outbound intent만 넘긴다. worker는 기본 `/sdcard/Download/StoreBotTermux/briefing_channel/rooms/{briefing_channel_room_id}.json`와 `/events/{event_id}.json`를 갱신하고, Firebase는 env로 켜는 원격 진단 미러로만 쓴다. 실제 RemoteInput, 접근성 fallback, `ACTION_SEND image/png`, local recovery queue, 전송/재시도 로그는 StoreBotTermux 기존 transport가 계속 소유한다.
- 2026-06-20 KST 구현: worker가 local-direct 실제 요청/응답/실패를 직접 briefing_channel inbound/outbound/failure 이벤트로 기록한다. Android shadow 미러가 아직 live APK에 없거나 실패해도 worker 내부 미러만으로 rooms/events/latest 로컬 파일이 생성되어야 한다. `/packhelper/storebot_termux/briefing_channel` 미러는 `STOREBOT_BRIEFING_CHANNEL_FIREBASE_MIRROR=1`일 때만 원격 진단용으로 쓴다.
- `room_id=storebot_group`은 worker 호환 필드로 유지하고 `briefing_channel_room_id=kakao_{room_name_sanitized}`를 별도로 둔다. rooms에는 최근 메시지, 처리 상태, 마지막 AI 응답, 누락/실패, outbound intent, 브리핑용 `briefing_text`를 둔다. 카카오 날짜 헤더, 방제목, 프로필명, `사진을 보냈습니다`, 공유 UI 텍스트 같은 transport noise는 briefing_channel에 넣지 않는다. channel 기록 실패는 카톡 답변 실패로 전파하지 않는다.
- 첫 연결 때 `storebot-kakao-reply` 스킬과 `STOREBOT_CODEX_WORKER.md` fallback 기준을 주입하고, 이후에는 같은 세션에 메시지를 이어 보낸다.
- 스킬 또는 MD 기준이 바뀌면 worker가 해시 차이를 보고 새 세션을 만들며, 기존 세션은 가능한 경우 `codex archive`로 닫는다.
- Codex는 카톡 입력을 보고 최종 답변, `SKIP`, 또는 허용 도구 요청을 만든다. 기본은 `storebot_codex_worker.py --mcp-server`가 제공하는 StoreBot MCP 도구를 같은 Codex 턴 안에서 직접 호출하는 방식이다.
- 현재 호환 fallback 구현은 같은 허용 action을 `STOREBOT_ACTIONS` JSON으로 주고받는다. MCP가 보이지 않거나 실패해도 이 왕복 경로를 정상 fallback으로 쓸 수 있다. worker가 자연어 의미를 재판정해 직접 MCP 호출을 다시 요구하는 경로는 허용하지 않는다.
- worker는 Codex가 요청한 허용 목록만 실행한다. action 이름은 제품 기능 경계가 아니라 도구 라벨이다. Codex는 근무표, 제한된 Firebase 조회, 최근 전표/주문 요약, 누락조회, 날씨/뉴스/스포츠/웹 RSS 조회, 동적 가이드를 조합해 답한다. TV/방송 채널번호, 전화번호, 영업시간, 공식 위치, 가격/재고처럼 새 외부 사실 질문도 별도 기능을 기다리지 않고 `web.search`로 처리한다.
- 누락조회는 `missed_chat.query` 액션으로 처리한다. worker가 최근 `/packhelper/storebot_codex/requests`를 읽어 pending/error/action_error/publish_missing과 확정된 근무표 반영을 요약해 Codex에 돌려준다. 도장 누락은 기본적으로 카운트만 보고, 항목 조회는 `include_stamp_gaps`가 있을 때만 한다.
- 최근 주문/내점/배달 위험은 `order.recent` 계열 action으로 처리한다. worker가 `/packhelper/capture` 최근 전표를 요약하고, 필요하면 원문 일부를 Codex 세션에만 넘겨 취소/추가/결제/주소/지연을 판단하게 한다. 요청 audit에는 원문을 장기 저장하지 않고 길이/해시로 redaction한다.
- 고정 근무표 알림은 이후 StoreBotTermux 모듈로 이동한다. 앱은 카톡 문구를 만들지 않고 `schedule_attendance_*`, `schedule_fixed_briefing`, `sports_evening`, `weather_rain_watch`를 `event_kind + payload`로 Codex 세션에 넘기며, 최종 문구는 Codex/스킬 출력이 만들고 worker는 운반/미러만 맡는다. 현재 worker가 자동 생성하는 출근독촉은 정각 미출근 확인 1회이며, 같은 출근시각은 `employees` payload 한 건으로 묶는다.
- 사용자 요청이나 Codex 판단으로 생기는 단발 리마인드는 `alert.schedule` 임시 알람으로 worker가 맡는다. 임시 알람은 Codex가 등록 시점에 만든 카톡 문구와 발화 시각을 `/packhelper/storebot_codex/temp_alerts`에 저장하고, due 시점에 `/packhelper/storebot_pending_queue`로 넣어 앱의 예약/알림 발송 경로를 사용한다.
- 사용자 교정과 좋은 출력 패턴은 `guidance.add_rule`로 `/packhelper/storebot_codex/dynamic_guidance`에 저장한다. 다음 poll부터 runtime guide overlay로 스킬 위에 덧씌워지며, 검증된 기준은 다음 번들 MD에 굳힌다.
- 로컬 명령, 파일 수정, 배포, 임의 Firebase 쓰기는 하지 않는다.
- 운영 중 Termux 화면에 직접 채팅을 입력하지 않는다. Termux는 백그라운드 worker host이고, 카카오톡 운영방이 사용자 UI다.
- StoreBotTermux의 책임은 카톡 입출력 안정화와 worker 런타임 소유권이다. 알림, 접근성, 열린 채팅방 감지, 앱킬/worker stale/미발송 큐 감시를 맡고, Termux worker 최신 여부, local-direct 수신, self-sync, codex_ops stale, 원격 restart/update/smoke 명령, 실패 큐 보존을 heartbeat에 드러낸다. 접근성 노드가 부족하면 OCR은 현재 열린 방과 최근 말풍선 확인용 fallback으로 쓴다.
- StoreBotTermux kill 방지는 앱 내부 `START_STICKY` foreground service, wakelock/wifi lock, 2분 keepalive alarm, boot/package/quickboot/user-present/power-connected 재진입, supervisor/power guard 주기 보정이 1차다. ADB가 연결되면 `subphone/harden_storebottermux_power.sh`로 `deviceidle whitelist`, standby active, background/foreground/wakelock appops, 접근성/알림 리스너, 화면/절전 설정을 OS 레벨에서 재적용한다.

## 상주/하이브리드 기준
- 1순위는 세션 유지와 복구다. 속도는 그 다음 판단 기준이다.
- 24시간 상주는 단일 프로세스 방치가 아니라 상호 감시다. StoreBotTermux/native supervisor는 worker/local-direct를 살리고, worker는 resident AI process/thread를 주기적으로 확인해 되살린다.
- self_fix용 `codex_ops_worker.py`도 같은 launch/restart 묶음에서 살아 있어야 한다. heartbeat가 stale이면 StoreBot worker 정상이어도 자가수정 운영은 미완료다.
- 상주 완료 기준은 `local_direct_listening=true`, `resident_app_server_enabled=true`, `resident_app_server_active=true`, `resident_session_preboot_ready=true`, `resident_session_preboot_room_id=storebot_group`, `brain_route=resident`, `reply_source=resident_session`, `fallback_used=false`다. `fast_router_stateless_exec=false`, API off, one-shot exec fallback off도 함께 확인한다.
- 세션 부팅 때만 MD/스킬을 숙지한다. 매 카톡 턴에는 raw envelope와 최소 메타만 넣는다.
- resident가 죽으면 cold `codex exec` fallback을 조용히 쓰는 것이 아니라 resident를 다시 세워 같은 운영방 thread를 대기 상태로 돌려야 한다.
- 현재 구현 완료: worker 시작 시 resident app-server, single-room `storebot_group` preboot, watchdog/revive가 기본 구조이며, fast brain/API와 one-shot exec fallback은 기본 off다. 다음 세션은 bundle/phone adoption과 factory PC USB ADB no-send 속도 재측정으로 실제 일반 답변 경로 재사용을 검증한다.
- full thread preboot/watchdog은 현재 목표 hot path다. heartbeat의 `resident_session_preboot_ready=false`나 `resident_app_server_active=false`는 resident 기본 경로 미완료로 본다.
- AI Ops 모니터도 resident 기본 완료 기준과 동일하게 `resident_app_server_enabled=true + resident_app_server_active=true + resident_session_preboot_ready=true`를 정상으로 보게 맞춘다. API disabled/no-key는 resident fallback으로 기록하지 않는다.
- heartbeat는 `fast_router_stateless_exec`, `fast_router_refresh_after_action`, `fast_router_timeout_sec`, `local_direct_sync_timeout_sec`, `local_direct_deferred_publish`, `resident_app_server_enabled`, `resident_app_server_active`, `resident_app_server_last_error`를 노출한다.
- OpenClaw를 병행 상주시켜도 답변 생성은 동시에 돌리지 않는다. 살아있는 기본 세션 1개가 답하고, 다른 후보는 검증/대기 또는 실패 복구 후보로만 둔다.
- 외부 API 사용은 금지다. OpenClaw 현재 agent model이 API provider이면 agent turn 검증을 하지 않는다.
- 서버폰 자가분석/자가수정은 StoreBot 전용이 아니라 공용 베이스다. `scripts/ai_ops_common_monitor.py`가 DeliveryHelper/PosDelay/BankTotal까지 저부하 관측하고 error급만 cooldown 후 `self_fix(codex_ops)`로 넘긴다.
- BankTotal은 사용자 동작형 앱이라 앱 monitor stale만으로 장애 처리하지 않는다. 최근 crash, 사용자 조작 실패, OCR/SFA/알림 수신 오류가 self_fix 후보 기준이다.

## 오류/개선 분석
- 오류/개선 분석은 별도 프로세스가 아니라 StoreBot worker watch 프로세스 내부 thread가 맡는다.
- 기본은 하루 1회 KST 04:30 저부하 시간 분석이다.
- 분석 전 pending 큐 0개, heartbeat `status=idle`, `local_direct_listening=true`, `resident_app_server_enabled=true`, `resident_app_server_active=true`, `resident_session_preboot_ready=true`, API off, one-shot exec fallback off를 확인한다. 일반 카톡 답변은 resident session 응답으로 검증한다.
- 저부하 조건이 아니면 30분씩 미루고, 최대 4시간 동안 조건이 안 맞으면 그날 분석은 건너뛴다.
- 분석 모델은 기본 `gpt-5.5/low`이며, 평시 카톡 답변 세션과 경쟁하지 않게 즉시 실행/짧은 주기 반복을 금지한다.
- 결과 경로는 `/packhelper/app_improvement_reports/StoreBotTermux/latest`와 `/packhelper/storebot_codex/improvement_reports/latest`다.

## 데이터 위치
- 외부 DB(Firebase RTDB)는 전달 큐와 상태판으로만 쓴다.
- 장기 대화 맥락은 서브폰 Termux의 운영방 Codex 세션에 남긴다.
- 완료된 요청은 기본값으로 원문/답변을 Firebase에 장기 보관하지 않는다.

## 흐름
1. StoreBotTermux가 카톡 알림 ReplyAction, active notification scan, 접근성 fallback 중 먼저 잡힌 메시지/이벤트를 claim한다.
   - 카카오 날짜 헤더, 사진/파일 전송 상태 같은 화면 수집 노이즈는 여기서 차단한다. 이는 자연어 의도 선분류가 아니라 운반 노이즈 제거다.
2. StoreBotTermux가 같은 폰 로컬 worker `POST /storebot/request`를 먼저 호출하고, Firebase requests에는 `ingress_status=local_direct_inflight`를 비동기 미러로 남긴다.
3. 운영방 Codex 세션이 없으면 worker가 새 세션을 만들고 `storebot-kakao-reply` 스킬과 `STOREBOT_CODEX_WORKER.md` fallback 기준을 주입한다.
4. worker가 같은 세션에 카톡 메시지나 이벤트 payload를 입력한다.
5. Codex가 StoreBot MCP 도구를 직접 호출하면 같은 턴 안에서 결과를 받아 최종 답변을 만든다.
6. MCP가 불가해 Codex가 `STOREBOT_ACTIONS`를 출력하면 worker가 허용된 외부 동작을 실행하고 결과를 같은 세션에 다시 넣는다.
7. Codex 최종 답변이 `SKIP`이면 StoreBotTermux는 전송하지 않는다.
8. 답변이 완성되면 StoreBotTermux가 같은 HTTP 응답을 받아 RemoteInput 또는 접근성 경로로 즉시 전송을 시도한다. 기본값은 중간 분기 없이 앱 read timeout 600초 안에서 기다리는 구조다.
9. worker는 로컬 처리 결과를 Firebase 요청 큐와 학습 도장 경로에 미러한다.
10. local-direct 접속/응답 실패 시 같은 requestId를 StoreBotTermux local recovery queue에 저장하고 worker 재기동 후 local-direct + 접근성 전송으로 회수한다. Firebase에는 `local_recovery_pending` 보조 상태만 남긴다.

알림예약, 내점, 결제, 물류도 `event_kind`와 `payload`를 넣으면 같은 경로에서 문구 생성이 가능하다. 단, 예약 시간 계산, 중복 방지, 처리 선점, 발송 방 결정은 앱/worker의 고정 규칙으로 유지한다. 샘플 문구는 시작점이며 사용자 교정/운영 반응은 `guidance.add_rule`로 누적 개선한다.

## OpenClaw 답변 캡처 설계안
- 목적은 답변 타이밍/범위 추정을 터미널 화면 스크래핑으로 하지 않는 것이다.
- 현재 worker의 안정 경계는 resident app-server/session의 최종 메시지와 `brain_route=resident`, `reply_source=resident_session`, `fallback_used=false` 결과다. prewarmed fast-router resume/one-shot exec는 완료 증거가 아니라 복구·진단 후보로만 본다.
- OpenClaw 경로는 카톡 턴마다 MD 전문을 주입하지 않는다. 전용 세션이 StoreBot 카카오 규칙을 숙지한 뒤, 각 턴에는 카톡 원문과 최소 메타만 넣는다.
- OpenClaw resident 후보도 자연어 판단은 AI가 한다. worker/App이 의도를 선분류하지 않고, OpenClaw에는 raw envelope와 최소 메타만 보낸다.
- DeliveryHelper/PosDelay까지 확장할 때도 같은 raw envelope를 쓰되 도메인별 agent/skill/session으로 분리한다. StoreBot 카카오 맥락과 물류/광고 맥락을 한 세션에 섞지 않는다.
- OpenClaw 후보 경계는 session/trajectory JSONL의 `model.completed.data.assistantTexts`다. 이 값만 최종 카톡 답변 후보로 본다.
- 장기 구조는 OpenClaw channel/plugin의 `deliver(payload)`에서 StoreBot worker local endpoint로 넘기고, worker가 기존 `publish_outbound_message` 경로로 StoreBotTermux 전송 큐에 넣는 방식이다.
- OpenClaw Android node의 `notifications.actions`는 살아 있는 카톡 알림 ReplyAction에 텍스트를 넣는 보조 transport 후보로만 검토한다. 빈 summary 알림, 답장 액션 없는 알림, 열린 방 접근성 fallback은 StoreBotTermux 기존 구현이 계속 소유한다.
- 구현 상태는 `--openclaw-latest-final`/`--openclaw-final-path` JSONL 파서와 `POST /storebot/openclaw/outbound` local endpoint까지다. 파서는 proot 홈과 Termux 홈 OpenClaw 세션 경로를 자동 탐색한다.
- 2026-06-14 서버폰 검증: Termux OpenClaw session JSONL 최종 assistant 추출 통과, `/storebot/openclaw/outbound` no-publish smoke 통과. 다음은 전용 세션의 raw-message 1건 smoke 후 필요 시 channel plugin 순서다.
- 속도와 발열이 확인되기 전에는 OpenClaw agent/gateway를 상시 벤치마크하지 않는다. 여러 모델 동시 실행도 금지하고, 기본 운영 답변 엔진 전환도 하지 않는다.

테스트 요청에 `no_publish=true`를 넣으면 Codex 답변 생성과 도장 기록까지만 확인하고 카톡 발송 큐에는 넣지 않는다.

카카오 화면에는 있었지만 Firebase 요청 큐에 없는 원문은 자동 조회할 수 없다. 이때는 `scripts/storebot_codex_replay_chat.py`로 원문을 `chat_replay` 요청에 재주입하고, 최종 답변/DB 반영 여부는 Codex 판단과 action 결과에 맡긴다.

카톡을 경유하지 않고 이 폰/현재 Codex 세션에서 StoreBot 답변 worker로 직접 넣을 때는 `scripts/storebot_direct_inject.py`를 쓴다. 기본값은 `no_publish=true`라 카톡 발송 큐로 보내지 않고, `/packhelper/storebot_codex/requests/{requestId}` 처리 결과와 학습 도장만 남긴다. 카톡 출력까지 원할 때만 `--publish`를 붙인다.

프로젝트 작업, 서버폰 설치, 검증을 ADB 없이 넘기는 목적은 StoreBot 답변 worker가 아니라 별도 `codex_ops_v2` 라인이다. 개인폰 Codex는 `/packhelper/codex_ops_v2/requests`에 작업을 넣고, 서버폰 Termux의 `scripts/codex_ops_worker.py`가 로컬 repo에서 `codex exec`를 실행한다. 이 경로는 ADB와 카톡을 모두 경유하지 않는다.

```bash
python3 scripts/storebot_direct_inject.py --wait "오늘 근무표랑 누락조회"
python3 scripts/storebot_direct_inject.py --publish "운영방에 보낼 StoreBot 답변 생성"
python3 scripts/codex_ops_enqueue.py --wait --cwd /root/my-first-project "서버폰에서 StoreBot worker 상태 확인하고 필요한 파일만 수정"
```

외부 동작 예시:

```text
STOREBOT_ACTIONS
{"actions":[{"type":"schedule.upsert_shift","employee":"재훈","date":"2026-06-12","start":"17:00","end":"03:00","role":"주방"}]}
```

실행 결과가 돌아오면 Codex가 그 결과만 근거로 최종 카톡 답변을 만든다.

## Firebase 경로
- 입력 큐: `/packhelper/storebot_codex/requests/{requestId}`
- 세션 상태: `/packhelper/storebot_codex/sessions/{roomKey}`
- worker 상태: `/packhelper/storebot_codex/heartbeat`
- 카톡 발송 큐: `/packhelper/storebot_pending_queue/{key}`
- StoreBotTermux briefing channel local state: `/sdcard/Download/StoreBotTermux/briefing_channel/rooms/{briefing_channel_room_id}.json`, `/sdcard/Download/StoreBotTermux/briefing_channel/events/{event_id}.json` (`/packhelper/storebot_termux/briefing_channel/**`은 env로 켜는 원격 진단 미러)
- 처리 도장 누적: `/packhelper/ai_learning/storebot/codex_stamps/{yyyyMMdd}/{requestId}`
- 최신 처리 도장: `/packhelper/storebot_codex/learning_stamp/latest`
- 동적 운영 기준: `/packhelper/storebot_codex/dynamic_guidance/rules/{ruleId}`, 최신 기준 `/packhelper/storebot_codex/dynamic_guidance/latest`
- 임시 알람: `/packhelper/storebot_codex/temp_alerts/{alertId}`, 최신 알람 `/packhelper/storebot_codex/temp_alerts/latest`
- 최근 전표 요약 source: `/packhelper/capture/{captureKey}`. 원문은 Codex 판단 입력으로만 쓰고, action audit에는 redaction한다.

처리 도장은 원문/답변을 장기 저장하지 않는다. `message_hash`, `reply_hash`, 길이, event_kind, decision(`skip/reply/action_then_reply/error`), action_count, room, model, guide/skill hash만 남겨 나중에 스킵/답변/실행 패턴을 학습한다. 도장 성공/실패는 요청에도 `learning_stamp_status`와 `learning_stamp_path` 또는 `learning_stamp_error`로 남긴다. action 결과 audit도 전표 `raw_text/raw_hex`는 길이와 짧은 해시만 남긴다.

요청 예시:

```json
{
  "status": "pending",
  "room_id": "storebot_group",
  "room_name": "운영방",
  "sender": "사장",
  "event_kind": "chat",
  "message": "오늘 상태 알려줘",
  "ts": 1780830000000,
  "source": "storebot"
}
```

이벤트 요청 예시:

```json
{
  "status": "pending",
  "room_id": "staff",
  "room_name": "직원방",
  "sender": "system",
  "event_kind": "payment",
  "message": "결제 알림 문구 생성",
  "payload": {
    "order_no": "123",
    "payment": "후불",
    "charge_amount": 18000,
    "menus": "황금올리브"
  },
  "ts": 1780830000000,
  "source": "storebot"
}
```

## 운영방 기준
- 이번 구현은 카카오톡 운영방 1개만 사용한다.
- StoreBotTermux는 카카오 notification listener/accessibility 권한이 켜져 있을 때만 카톡 수신을 Codex 로컬 다이렉트에 넣는다.
- 운영값은 `local_direct_url=http://127.0.0.1:8765/storebot/request`, 앱 read timeout 600초, worker `STOREBOT_CODEX_TIMEOUT_SEC=540`이다. timeout은 무한 대기 방지용이지 30초 실패 처리 기준이 아니다.
- 2026-06-12 기준 메인 소유권은 StoreBotTermux 앱이다. `local_direct`는 Codex CLI 실행 백엔드이지만, 카톡 입력/출력과 worker 생명주기는 StoreBotTermux foreground service/native supervisor가 잡는다.
- 로컬 다이렉트가 실패하거나 worker health가 bridge_safe=false이면 앱이 resident revive/local recovery를 우선 시도하고, 실패하면 Firebase 큐로 보존한다. 브리지 자체가 꺼져 있을 때의 legacy API/로컬 경로는 별도 명시 운영 모드이며 현재 resident 목표의 기본 fallback이 아니다.
- 개인 1:1방과 다중 방 라우팅은 이번 범위에서 제외한다.

## 실행
전제:

- 서브폰 Termux 또는 proot 환경에 `python3`과 `codex` CLI가 있어야 한다.
- Codex CLI는 먼저 `codex`를 실행해 ChatGPT 계정 로그인이 완료된 상태여야 한다.
- Codex CLI가 없으면 공식 설치 방식인 `curl -fsSL https://chatgpt.com/codex/install.sh | sh` 또는 `npm install -g @openai/codex`를 사용한다.
- StoreBot MCP 직접 도구 호출은 `scripts/storebot_codex_worker.py --mcp-server`로 제공한다. worker는 `codex exec` 실행 때 이 MCP만 열고, `STOREBOT_ACTIONS`는 fallback으로 유지한다.
- Debian proot에 Python `mcp` 패키지가 필요하다. 설치 스크립트가 없으면 `python3 -m pip install --break-system-packages "mcp>=1.0"` 또는 `python3 -m pip install --user "mcp>=1.0"`으로 보정한다.
- 기본 답변 모델은 `gpt-5.6-terra`다. 바꾸려면 Termux/proot 실행 환경에서 `STOREBOT_CODEX_MODEL`을 지정한다. 사용자가 `상위 모델`, `다른 답변`, `정밀`, `재분석`처럼 더 높은 품질을 요구하면 해당 요청만 `STOREBOT_CODEX_ESCALATION_MODEL`(기본 `gpt-5.5`)로 승격한다. `auto`, `default`, 빈 값은 Codex CLI 기본값을 사용한다.
- reasoning effort 기본값은 `low`다. `~/.codex/config.toml`이 `xhigh`여도 worker는 `--reasoning-effort low`로 덮어쓴다. 필요할 때만 `STOREBOT_CODEX_REASONING_EFFORT`를 `minimal`, `medium`, `high`, `xhigh` 중 하나로 바꾼다.
- 스킬 파일은 `/root/.agents/skills/storebot-kakao-reply/SKILL.md`와 `/root/my-first-project/.agents/skills/storebot-kakao-reply/SKILL.md`에 둔다. `/sdcard/Download/storebot_codex_worker/skills/storebot-kakao-reply/SKILL.md`가 있으면 설치/복구 스크립트가 두 위치로 복사한다.
- 근무표/브리핑 판단과 세부 출력 규칙은 `storebot-kakao-reply/SKILL.md`만 따른다. worker는 조회형 local-direct 응답의 `image_request.type=schedule_briefing` 계약을 만들고, Android는 PNG 카드 렌더/전송을 맡는다.
- 근무 데이터는 한 곳으로 중앙화한다. worker `schedule.query`는 Android `ScheduleResolver`와 같은 `/workschedule_v2/employees + fixed_schedules + overrides + status`를 같은 우선순위로 읽고, Codex는 출력 양식만 바꾼다.
- `/packhelper/storebot_summary/schedule`은 캐시/표시용일 뿐이며, schedule 답변과 브리핑은 `/workschedule_v2` 계산 결과를 우선한다.
- worker/MD/스킬은 StoreBot 전용 self-sync 대상이다. 공개 manifest `https://wk7007-ops-static-2026.web.app/storebot-codex/bundle.json`의 version/hash가 바뀌면 worker가 zip을 검증해 자기 proot 내부 `/root/my-first-project`와 `/root/.agents/skills`를 갱신한다. 실제 채택 증거는 새 Hosting의 manifest/zip 200, exact SHA-256, serverphone bundle state/heartbeat가 모두 맞을 때만 인정한다.
- `launch_storebot_codex_background.sh`는 host Termux에서는 `proot-distro`로 진입하고, 이미 proot 내부에서 실행된 self_fix 세션에서는 `/root/my-first-project`를 직접 써서 중복 proot 진입을 피한다.
- worker는 `--watch` 실행 시 기본값으로 로컬 다이렉트 HTTP 서버를 같이 연다. 끄려면 `STOREBOT_CODEX_LOCAL_DIRECT_SERVER=false` 또는 `--no-local-direct-server`를 쓴다.
- 로컬 다이렉트 서버 기본값은 `STOREBOT_CODEX_LOCAL_DIRECT_HOST=127.0.0.1`, `STOREBOT_CODEX_LOCAL_DIRECT_PORT=8765`다. 외부 Wi-Fi POST를 받지 않는다.
- worker heartbeat에서 `local_direct_enabled=true`인데 `local_direct_listening=false`면 worker alive라도 카톡 입력 핫패스는 장애 상태로 본다.
- Android 리소스 kill/worker stale 대비는 StoreBotTermux foreground service와 native supervisor가 맡는다. `watch_storebot_codex_worker.sh`는 Termux host 내부 비상 fallback이며 기본 자동실행 대상이 아니다.
- Tasker/ServerPhoneGuard/상위 감시용 얇은 watchdog은 `watch_storebot_kakao_stack.sh`다. 서버폰 Termux/Tasker 내부에서는 `--local`로 `pm path`/`pidof`/`am start`/`curl 127.0.0.1:8765`를 직접 쓰고, 컨트롤러/PC/Wonmux에서는 기본 `--adb`로 ADB를 쓴다. 이 스크립트는 `com.kakao.talk`, `com.sbotux`, `com.termux`, `net.dinglisch.android.taskerm`, `com.nelife.serverphoneguard`, worker process, `127.0.0.1:8765` health만 진단하고, 실패 시 StoreBotTermux wake/repair -> Termux wake/worker restart -> KakaoTalk wake 순서만 요청한다. `--local`의 worker 재시작은 같은 디렉토리 `restart_storebot_codex_worker.sh`가 실행 가능할 때만 호출하고, 없으면 패키지 wake까지만 한다. 카톡 입력 파싱, 답장 생성/전송, business logic, `storebot_manual_reply`/direct inject 호출은 금지다. 복구 대상은 서버폰/kitchen이며 `com.wonmux`는 대상이 아니다.
- 적용 후 worker는 exit 75로 재시작을 요청한다. 파일이 이미 최신이어도 bundle 상태 hash가 바뀌었으면 실행 중인 구버전 프로세스를 피하려고 재시작한다. `subphone/start_storebot_codex_worker.sh`가 이를 받아 새 프로세스로 다시 실행한다.
- heartbeat에는 `bundle_version`, `bundle_sha256`, `bundle_status`, `bundle_applied_at_ms`가 올라간다. 상세 상태는 `/packhelper/storebot_codex/self_sync/latest`에서도 확인한다.

서브폰 proot 안에서:

```bash
cd /root/my-first-project
bash subphone/start_storebot_codex_worker.sh
```

서브폰 Termux 화면에서 직접 시작할 때:

```bash
bash /sdcard/Download/storebot_codex_worker/launch_storebot_codex_background.sh manual
```

기본값은 foreground 실행이다. 예전처럼 분리 실행이 꼭 필요할 때만 명시한다.

```bash
STOREBOT_CODEX_DETACH=1 bash /sdcard/Download/storebot_codex_worker/launch_storebot_codex_background.sh manual
```

자동시작 적용:

```bash
bash /sdcard/Download/storebot_codex_worker/setup_storebot_codex_autostart.sh
```

`setup_storebot_codex_autostart.sh`는 다음을 만든다.

- `~/.termux/boot/10-storebot-codex.sh`: 기본 off. `STOREBOT_CODEX_TERMUX_BOOT_AUTOSTART=1`일 때만 실행.
- `~/.termux/boot/11-storebot-codex-watchdog.sh`: 기본 off. `STOREBOT_CODEX_SHELL_WATCHDOG_AUTOSTART=1`일 때만 worker 프로세스/로컬 health 감시와 자동 재기동.
- `~/.termux/storebot-codex/autostart.sh`: 기본 off. `STOREBOT_CODEX_SHELL_AUTOSTART=1`일 때만 Termux shell-open fallback 실행.
- `~/.bashrc` autostart hook: 기본 off fallback 파일을 source만 한다.
- `~/.termux/termux.properties`의 `allow-external-apps=true`: ADB/Tasker/MacroDroid 연동 여지를 열어둔다.

StoreBotTermux 앱이 boot receiver와 native supervisor로 기본 재기동을 맡는다. Termux:Boot 또는 shell fallback은 앱 경로가 깨졌을 때의 비상 스위치다.

ADB에서 Termux `RUN_COMMAND` 권한이 막혀도 live `run-as com.sbotux` 또는 `run-as com.termux`가 가능하면 자동시작 파일은 원격으로 설치할 수 있다. 이전 전환 상태면 `run-as com.wonmux`도 마이그레이션 후보로만 본다. `run-as`도 막히면 서브폰 Termux 화면에서 `setup_storebot_codex_autostart.sh`를 직접 1회 실행한다.

상태 확인:

```bash
bash /sdcard/Download/storebot_codex_worker/check_storebot_codex_worker.sh
```

Tasker/상위 감시 1회 진단/복구:

```bash
# 서버폰 내부 Termux/Tasker에서 실행: adb 없이 로컬 Android 명령 사용
bash /sdcard/Download/storebot_codex_worker/watch_storebot_kakao_stack.sh --status --local
bash /sdcard/Download/storebot_codex_worker/watch_storebot_kakao_stack.sh --once --local --dry-run
bash /sdcard/Download/storebot_codex_worker/watch_storebot_kakao_stack.sh --once --local

# 외부 컨트롤러/PC/Wonmux에서 실행: 기존 ADB 기반
bash /sdcard/Download/storebot_codex_worker/watch_storebot_kakao_stack.sh --status
bash /sdcard/Download/storebot_codex_worker/watch_storebot_kakao_stack.sh --once --dry-run
ADB_SERIAL="192.168.0.70:35609" bash /sdcard/Download/storebot_codex_worker/watch_storebot_kakao_stack.sh --once
```

Tasker는 주기 조건과 서버폰 내부 `--local` 호출만 맡는다. 채팅 파싱, 답장 문구 생성, Firebase 업무 판단, 카카오 전송은 Tasker에 넣지 않는다. 컨트롤러 ADB 예시는 서버폰 밖에서 상태를 보거나 ADB 복구가 이미 된 뒤 쓴다.

로컬 다이렉트 health 확인:

```bash
curl http://127.0.0.1:8765/storebot/health
```

bundle 생성/배포:

```bash
python3 scripts/build_storebot_codex_bundle.py
firebase deploy --only hosting:attendance --project poskds-4ba60
```

호스팅 반영 뒤 로컬에서 self-sync만 확인:

```bash
python3 scripts/storebot_codex_worker.py --sync-once
```

worker 재시작:

```bash
bash /sdcard/Download/storebot_codex_worker/restart_storebot_codex_worker.sh
```

Termux 수동 답변 복사:

```bash
bash /sdcard/Download/storebot_codex_worker/storebot_manual_reply.sh "답변할 카톡 원문"
```

이 경로는 카톡 자동 전송을 하지 않고 local-direct 응답을 터미널에 출력한 뒤 Android 클립보드에 복사한다. 디버깅/수동 대응용이며, 일반 Codex 모델 호출 자체가 느린 문제를 없애지는 않는다.

ADB 없이 즉시 근무 브리핑 발송:

```bash
# Firebase /subphone/cmd/storebot 값
{"command":"briefing_now"}
{"command":"briefing_now","target":"내일"}
```

## 테스트
대기 요청만 확인:

```bash
python3 scripts/storebot_codex_worker.py --once --dry-run
```

수동 테스트 요청 추가:

```bash
python3 scripts/storebot_codex_replay_chat.py --message "네" --no-publish --force
```

카톡 발송 없이 답변 생성만 검증:

```bash
python3 scripts/storebot_codex_worker.py --enqueue-test "오늘 상태 알려줘" --enqueue-no-publish --room-id storebot_group --room-name "운영방" --sender "사장"
```

1회 처리:

```bash
python3 scripts/storebot_codex_worker.py --once
```

## 안전 기준
- worker는 `codex exec`/`codex exec resume`을 `--ignore-user-config`, `--disable shell_tool`, read-only 설정으로 실행하되, CLI 옵션으로 StoreBot MCP allowlist 도구만 열어 둔다. 사용자 전역 Codex config가 깨져 있어도 StoreBot 답변 세션에 섞이지 않게 하기 위해서다.
- 기본 Codex 작업 루트는 `/root/storebot-codex-workspace`다. 개발 저장소의 AGENTS/작업 규칙이 답변 세션에 섞이지 않게 분리한다.
- heartbeat와 세션 상태에는 현재 `model`과 `reasoning_effort`를 기록한다.
- 스킬 또는 MD 변경 시 기존 세션에 재주입하지 않고 새 세션을 시작한다. 이전 세션은 기본값으로 archive를 시도한다.
- 이 브리지는 출력 전용이다. 구조 변경, 빌드, 배포, Firebase 수정 같은 작업 실행은 별도 승인된 작업 모드에서만 다룬다.
- StoreBotTermux의 카톡 listener/accessibility와 local-direct 위임 경로가 실사용 기준이다. Firebase 요청 큐는 실패 보존/감사/누락조회 경로다.
- OpenClaw 경로는 최종 답변 이벤트만 받는다. 카톡 앱 조작, Android 접근성 전송, 재시도 소유권은 StoreBotTermux 밖으로 넘기지 않는다.
- OpenClaw `notifications.actions`를 쓰더라도 StoreBotTermux 전송 큐/로그/재시도와 충돌하지 않는 보조 transport로만 붙인다.
