<!-- source: /root/my-first-project/planning/templates/app_intent.md -->
# APP_INTENT.md 템플릿

## 만든 이유
-

## 사용자 결과
-

## 절대 기준
-

## UI/동선 기준
-

## 데이터/경계 기준
-

## C&I / AI Ops 경계
- C&I는 오류 감지, 비효율 패턴 개선, 안전 범위 내 self_fix, 문서 갱신, 빌드/업데이트센터 배포까지 맡을 수 있다.
- CLI/LLM은 prompt envelope가 있어야 깨어난다. monitor/worker/앱/사용자/수동 enqueue 또는 상주 판단 루프가 prompt를 주입하며, 이것은 지시 범위 제한이 아니다.
- 자동 복구가 넘으면 안 되는 앱별 금지 경계:

## 수정 전 질문
-

## 완료 기준
- 검증:
- 전달:
- 남은 위험:
