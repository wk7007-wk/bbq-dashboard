#!/usr/bin/env python3
"""Publish one immutable compiled-learning promotion binding; shadow by default."""

from __future__ import annotations

import argparse
import copy
import json
from pathlib import Path
import sys
import time
from typing import Any

ROOT = Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))
from scripts import automation_goal_dispatcher as reducer
from scripts import automation_goal_dispatch_firebase as adapter


DEFAULT_PRODUCER = "automation-learning-publisher-v1"
PUBLISH_CLOCK_BACKDATE_MS = 5_000


class PublishError(ValueError):
    pass


def _safe_id(value: Any, label: str) -> str:
    try:
        return adapter._safe_id(value, label)
    except adapter.AdapterValidationError as exc:
        raise PublishError(str(exc)) from exc


def _compiled_identity(compiled: Any) -> tuple[str, str, str]:
    if not isinstance(compiled, dict) or not isinstance(compiled.get("snapshot"), dict):
        raise PublishError("compiled snapshot is missing")
    snapshot = compiled["snapshot"]
    snapshot_id = _safe_id(snapshot.get("snapshot_id"), "snapshot_id")
    snapshot_hash = snapshot.get("snapshot_hash")
    policy_hash = compiled.get("policy_hash")
    if not isinstance(snapshot_hash, str) or adapter.HEX64.fullmatch(snapshot_hash) is None:
        raise PublishError("compiled snapshot hash is invalid")
    if not isinstance(policy_hash, str) or adapter.HEX64.fullmatch(policy_hash) is None:
        raise PublishError("compiled policy hash is invalid")
    return snapshot_id, snapshot_hash, policy_hash


def _watch_binding(state: Any, goal_id: str, task_id: str, policy: dict[str, Any]) -> tuple[int, dict[str, str]]:
    if not isinstance(state, dict) or not isinstance(state.get("active_goal"), dict):
        raise PublishError("canonical goal state is missing")
    goal = state["active_goal"]
    if goal.get("goal_id") != goal_id or goal.get("status") != "active":
        raise PublishError("canonical active goal binding mismatch")
    epoch = goal.get("goal_epoch")
    if not isinstance(epoch, int) or isinstance(epoch, bool) or epoch < 1 or epoch > policy["learning"]["max_goal_epoch"]:
        raise PublishError("canonical goal epoch is invalid")
    if isinstance(state.get("now"), dict) and state["now"].get("task_id") == task_id:
        raise PublishError("target task is current")
    if any(isinstance(row, dict) and row.get("task_id") == task_id for row in state.get("next") or []):
        raise PublishError("target task is already next")
    if reducer._mapping_entry(state.get("completed") or {}, "task", task_id) is not None:
        raise PublishError("target task is completed")
    matches = [row for row in state.get("watch") or [] if isinstance(row, dict) and row.get("task_id") == task_id]
    if len(matches) != 1:
        raise PublishError("exactly one pre-authorized watch task is required")
    normalized = reducer._normalized_task(matches[0], state, policy)
    return epoch, {
        "task_fingerprint": normalized["task_fingerprint"],
        "prompt_hash": reducer.canonical_hash(normalized["prompt"]),
        "risk_assessment_hash": normalized["risk_assessment"]["assessment_hash"],
    }


def build_documents(
    *,
    compiled: dict[str, Any],
    state: dict[str, Any],
    goal_id: str,
    task_id: str,
    policy: dict[str, Any],
    producer: str = DEFAULT_PRODUCER,
    created_at_ms: int,
    ttl_seconds: int,
    inbox_id: str | None = None,
) -> dict[str, Any]:
    state = adapter._hydrate_rtdb_state(state)
    goal_id = _safe_id(goal_id, "goal_id")
    task_id = _safe_id(task_id, "task_id")
    producer = _safe_id(producer, "producer")
    if producer not in policy["learning"]["allowed_producers"]:
        raise PublishError("producer is not allowlisted")
    if task_id not in policy["learning"]["promotion_allowlist"]:
        raise PublishError("task_id is not promotion-allowlisted")
    if not isinstance(created_at_ms, int) or isinstance(created_at_ms, bool) or created_at_ms < 1:
        raise PublishError("created_at_ms is invalid")
    if not isinstance(ttl_seconds, int) or isinstance(ttl_seconds, bool) or not 1 <= ttl_seconds <= policy["learning"]["max_ttl_seconds"]:
        raise PublishError("ttl_seconds exceeds policy")
    snapshot_id, snapshot_hash, policy_hash = _compiled_identity(compiled)
    if policy_hash not in policy["learning"]["allowed_policy_hashes"]:
        raise PublishError("compiled policy hash is not allowlisted")
    epoch, binding = _watch_binding(state, goal_id, task_id, policy)
    snapshot_path = f"{adapter.LEARNING_SNAPSHOTS_ROOT}/{snapshot_id}"
    snapshot_document = {
        "schema_version": 1,
        "producer": producer,
        "created_at_ms": created_at_ms,
        "body": copy.deepcopy(compiled),
        "body_hash": reducer.canonical_hash(compiled),
    }
    identity = {
        "goal_id": goal_id,
        "goal_epoch": epoch,
        "snapshot_id": snapshot_id,
        "snapshot_hash": snapshot_hash,
        "task_id": task_id,
        **binding,
    }
    inbox_id = _safe_id(inbox_id, "inbox_id") if inbox_id else f"learning-{reducer.canonical_hash(identity)[:24]}"
    if not inbox_id.startswith("learning-"):
        raise PublishError("inbox_id must use the learning- namespace")
    sequence_id = f"seq-{created_at_ms:013d}-{reducer.canonical_hash({'inbox_id': inbox_id, 'snapshot_hash': snapshot_hash})[:16]}"
    inbox = {
        "schema_version": 1,
        "inbox_id": inbox_id,
        "goal_id": goal_id,
        "goal_epoch": epoch,
        "snapshot_path": snapshot_path,
        "snapshot_id": snapshot_id,
        "snapshot_hash": snapshot_hash,
        "policy_hash": policy_hash,
        "action": "promote_existing_watch_once",
        "target_lane": "watch",
        "task_id": task_id,
        **binding,
        "producer": producer,
        "created_at_ms": created_at_ms,
        "expires_at_ms": created_at_ms + ttl_seconds * 1000,
        "sequence_id": sequence_id,
    }
    inbox["item_hash"] = adapter.learning_item_hash(inbox)
    sequence = {
        "schema_version": 1,
        "sequence_id": sequence_id,
        "inbox_id": inbox_id,
        "item_hash": inbox["item_hash"],
        "created_at_ms": created_at_ms,
    }
    adapter.validate_compiled_snapshot_document(snapshot_document, inbox, policy)
    return {"snapshot": snapshot_document, "inbox": inbox, "sequence": sequence}


def _immutable_cas(transport: Any, path: str, value: dict[str, Any]) -> str:
    existing, etag = transport.get_with_etag(path)
    if existing is not None:
        if reducer.canonical_hash(existing) != reducer.canonical_hash(value):
            raise PublishError(f"immutable projection conflict: {path}")
        return "noop"
    if transport.compare_and_put(path, value, etag):
        return "created"
    winner = transport.get(path)
    if reducer.canonical_hash(winner) != reducer.canonical_hash(value):
        raise PublishError(f"immutable projection CAS conflict: {path}")
    return "noop"


def publish(
    *, transport: Any, documents: dict[str, Any], apply: bool = False
) -> dict[str, Any]:
    inbox = documents["inbox"]
    paths = {
        "snapshot_path": inbox["snapshot_path"],
        "inbox_path": f"{adapter.LEARNING_INBOX_ROOT}/{inbox['inbox_id']}",
        "sequence_path": f"{adapter.learning_sequence_scope(inbox['goal_id'], inbox['goal_epoch'])}/{inbox['sequence_id']}",
        "receipt_path": f"{adapter.LEARNING_RECEIPTS_ROOT}/{inbox['inbox_id']}",
    }
    result = {
        "status": "shadow" if not apply else "published",
        "inbox_id": inbox["inbox_id"],
        "item_hash": inbox["item_hash"],
        "snapshot_id": inbox["snapshot_id"],
        "snapshot_hash": inbox["snapshot_hash"],
        **paths,
    }
    if not apply:
        return result
    result["snapshot_write"] = _immutable_cas(transport, paths["snapshot_path"], documents["snapshot"])
    result["inbox_write"] = _immutable_cas(transport, paths["inbox_path"], inbox)
    result["sequence_write"] = _immutable_cas(transport, paths["sequence_path"], documents["sequence"])
    return result


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--compile-file", help="compiled snapshot JSON; stdin when omitted")
    parser.add_argument("--goal-id", required=True)
    parser.add_argument("--task-id", required=True)
    parser.add_argument("--policy", default=str(reducer.DEFAULT_POLICY))
    parser.add_argument("--producer", default=DEFAULT_PRODUCER)
    parser.add_argument("--ttl-seconds", type=int, default=3600)
    parser.add_argument("--inbox-id")
    parser.add_argument("--apply", action="store_true")
    args = parser.parse_args(argv)
    policy = reducer.load_policy(args.policy)
    transport = adapter.CodexOpsFirebaseTransport()
    state = transport.get(f"{adapter.AUTOMATION_ROOT}/goals/{_safe_id(args.goal_id, 'goal_id')}")
    compiled = (
        json.loads(Path(args.compile_file).read_text(encoding="utf-8"))
        if args.compile_file
        else json.load(sys.stdin)
    )
    documents = build_documents(
        compiled=compiled,
        state=state,
        goal_id=args.goal_id,
        task_id=args.task_id,
        policy=policy,
        producer=args.producer,
        # Match the program publisher's bounded skew guard.  The resident
        # adapter may have captured its iteration time just before this
        # immutable item appeared.
        created_at_ms=int(time.time() * 1000) - PUBLISH_CLOCK_BACKDATE_MS,
        ttl_seconds=args.ttl_seconds,
        inbox_id=args.inbox_id,
    )
    print(json.dumps(publish(transport=transport, documents=documents, apply=args.apply), ensure_ascii=False, sort_keys=True))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
