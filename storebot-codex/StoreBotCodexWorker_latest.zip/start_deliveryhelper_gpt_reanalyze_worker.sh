#!/data/data/com.sbotux/files/usr/bin/bash
set -u

ROOT_DIR="${DELIVERYHELPER_GPT_ROOT:-/root/my-first-project}"
LOG_DIR="${DELIVERYHELPER_GPT_LOG_DIR:-/sdcard/Download/deliveryhelper_gpt_worker}"
LOCK_BASE_DIR="${DELIVERYHELPER_GPT_LOCK_BASE_DIR:-${TMPDIR:-${PREFIX:-/data/data/com.sbotux/files/usr}/tmp}}"
LOCK_DIR="${DELIVERYHELPER_GPT_LOCK_DIR:-$LOCK_BASE_DIR/deliveryhelper_gpt_reanalyze.lock}"

PATH="${PATH:-}"
prepend_path_dir() {
  dir="$1"
  [ -n "$dir" ] || return 0
  [ -d "$dir" ] || return 0
  case ":$PATH:" in
    *":$dir:"*) ;;
    *) PATH="$dir${PATH:+:$PATH}" ;;
  esac
}

prepend_path_dir "/usr/local/bin"
prepend_path_dir "/root/.local/bin"
prepend_path_dir "${HOME:-/root}/.local/bin"
if [ -n "${PREFIX:-}" ]; then
  prepend_path_dir "$PREFIX/bin"
fi
prepend_path_dir "/data/data/com.sbotux/files/usr/bin"
prepend_path_dir "/data/data/com.termux/files/usr/bin"
export PATH

: "${DELIVERYHELPER_GPT_TMP_DIR:=$LOG_DIR/tmp}"
export DELIVERYHELPER_GPT_TMP_DIR

mkdir -p "$LOG_DIR" "$LOCK_BASE_DIR" "$DELIVERYHELPER_GPT_TMP_DIR" 2>/dev/null || true

CODEX_PATH="${DELIVERYHELPER_GPT_CODEX_BIN:-}"
if [ -z "$CODEX_PATH" ]; then
  CODEX_PATH="$(command -v codex 2>/dev/null || true)"
  if [ -n "$CODEX_PATH" ]; then
    export DELIVERYHELPER_GPT_CODEX_BIN="$CODEX_PATH"
  fi
elif command -v "$CODEX_PATH" >/dev/null 2>&1; then
  CODEX_PATH="$(command -v "$CODEX_PATH" 2>/dev/null || printf '%s' "$CODEX_PATH")"
  export DELIVERYHELPER_GPT_CODEX_BIN="$CODEX_PATH"
fi
echo "$(date '+%Y-%m-%d %H:%M:%S') DeliveryHelper GPT codex=${DELIVERYHELPER_GPT_CODEX_BIN:-not-found}" >> "$LOG_DIR/worker.log"

pid_matches_worker() {
  pid="$1"
  [ -n "$pid" ] || return 1
  kill -0 "$pid" 2>/dev/null || return 1
  cmdline="$(ps -p "$pid" -o args= 2>/dev/null || true)"
  if [ -z "$cmdline" ] && [ -r "/proc/$pid/cmdline" ]; then
    cmdline="$(tr '\0' ' ' < "/proc/$pid/cmdline" 2>/dev/null || true)"
  fi
  case "$cmdline" in
    *deliveryhelper_gpt_reanalyze_worker.py*|*start_deliveryhelper_gpt_reanalyze_worker.sh*)
      return 0
      ;;
  esac
  return 1
}

cleanup_lock() {
  rm -rf "$LOCK_DIR" 2>/dev/null || true
}

exit_after_signal() {
  code="$1"
  trap - EXIT INT TERM
  cleanup_lock
  exit "$code"
}

if ! mkdir "$LOCK_DIR" 2>/dev/null; then
  old_pid="$(cat "$LOCK_DIR/pid" 2>/dev/null || true)"
  if pid_matches_worker "$old_pid"; then
    echo "DeliveryHelper GPT worker already running pid=$old_pid" >> "$LOG_DIR/worker.log"
    exit 0
  fi
  echo "DeliveryHelper GPT worker removing stale lock pid=${old_pid:-none}" >> "$LOG_DIR/worker.log"
  rm -rf "$LOCK_DIR"
  mkdir "$LOCK_DIR" 2>/dev/null || exit 1
fi
trap cleanup_lock EXIT
trap 'exit_after_signal 130' INT
trap 'exit_after_signal 143' TERM
echo $$ > "$LOCK_DIR/pid"

cd "$ROOT_DIR" || exit 1

: "${DELIVERYHELPER_GPT_MODEL:=gpt-5.5}"
: "${DELIVERYHELPER_GPT_REASONING_EFFORT:=low}"

while true; do
  python3 scripts/deliveryhelper_gpt_reanalyze_worker.py --watch \
    >> "$LOG_DIR/worker.log" 2>&1
  code=$?
  if [ "$code" -eq 130 ]; then
    exit 130
  fi
  echo "DeliveryHelper GPT worker exited code=$code; restart in 10s" >> "$LOG_DIR/worker.log"
  sleep 10
done
