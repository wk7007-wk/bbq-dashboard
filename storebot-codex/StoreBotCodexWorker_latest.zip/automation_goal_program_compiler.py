#!/usr/bin/env python3
"""Compile one main-approved declarative program into one bounded watch task.

This is a pure model-0 compiler. It reads strict local JSON configuration and
prints canonical JSON to stdout. It never invokes AI, Firebase, the network, a
worker, or a file-writing API.
"""

from __future__ import annotations

import argparse
import copy
import json
from pathlib import Path
import re
import sys
from typing import Any

try:
    from scripts import automation_goal_dispatcher as reducer
    from scripts import automation_goal_seed as seed
except ModuleNotFoundError:  # Direct execution from the scripts directory.
    import automation_goal_dispatcher as reducer  # type: ignore[no-redef]
    import automation_goal_seed as seed  # type: ignore[no-redef]


ROOT = Path(__file__).resolve().parents[1]
DEFAULT_PROGRAMS = ROOT / "config" / "automation_goal_programs.json"
DEFAULT_POLICY = ROOT / "config" / "automation_goal_dispatch_policy.json"
HEX40 = re.compile(r"[0-9a-f]{40}")
SAFE_ID = re.compile(r"[A-Za-z0-9][A-Za-z0-9._:-]{0,127}")
REQUEST_FIELDS = {
    "schema_version", "program_id", "goal_id", "goal_epoch", "source_revision",
    "target_node", "resource_id", "model_id", "reasoning_effort",
}
CONFIG_FIELDS = {"schema_version", "config_version", "model_lane", "programs"}
PROGRAM_FIELDS = {
    "program_id", "task_id", "enabled", "template_id", "allowed_goal_ids", "max_goal_epoch",
    "allowed_target_nodes", "allowed_resource_ids", "allowed_model_ids",
    "allowed_reasoning_efforts", "task_contract",
}
TASK_CONTRACT_FIELDS = {
    "capability", "context_tokens", "token_budget", "model_decision_by", "cwd",
    "profile", "is_owner", "target_host", "ttl_seconds", "timeout_seconds",
}

TEMPLATES = {
    "serverphone_runtime_readonly_analysis_v1": {
        "prompt": (
            "Review only the immutable learning pointers and model-0 verification receipt "
            "included in this prompt. Check their internal identity, hash-prefix, path, "
            "and policy-binding consistency, then report aligned, mismatch, or unverifiable "
            "in at most eight concise lines. Do not inspect files, invoke tools, or use any "
            "external context."
        ),
        "done_criteria": [
            "check only prompt-contained immutable pointer and model-0 receipt bindings",
            "report aligned, mismatch, or unverifiable in at most eight lines",
        ],
        "forbidden": [
            "tool_use",
            "file_or_repo_read",
            "file_or_repo_write",
            "git_mutation",
            "build_or_package",
            "deploy_or_publish",
            "network_access",
            "firebase_read_or_write",
            "adb_or_device_action",
            "physical_action",
            "process_start_stop_or_signal",
        ],
    }
}


class ProgramCompileError(ValueError):
    def __init__(self, message: str, *, code: str = "invalid_program_compile_input") -> None:
        super().__init__(message)
        self.code = code


def canonical_json(value: Any) -> str:
    return reducer.canonical_json(value)


def canonical_hash(value: Any) -> str:
    return reducer.canonical_hash(value)


def _safe_id(value: Any, label: str) -> str:
    if not isinstance(value, str) or SAFE_ID.fullmatch(value) is None:
        raise ProgramCompileError(f"{label} must be a bounded safe identifier")
    return value


def _positive_integer(value: Any, label: str) -> int:
    if not isinstance(value, int) or isinstance(value, bool) or value < 1:
        raise ProgramCompileError(f"{label} must be a positive integer")
    return value


def _safe_id_list(value: Any, label: str) -> list[str]:
    if not isinstance(value, list) or not value:
        raise ProgramCompileError(f"{label} must be a non-empty list")
    normalized = [_safe_id(item, label) for item in value]
    if len(normalized) != len(set(normalized)):
        raise ProgramCompileError(f"{label} must not contain duplicates")
    return normalized


def _load_json(path: str | Path) -> dict[str, Any]:
    value = json.loads(Path(path).read_text(encoding="utf-8"))
    if not isinstance(value, dict):
        raise ProgramCompileError(f"{path} must contain a JSON object")
    return value


def validate_programs_config(config: Any, dispatch_policy: dict[str, Any]) -> None:
    reducer.validate_policy(dispatch_policy)
    if not isinstance(config, dict) or set(config) != CONFIG_FIELDS:
        raise ProgramCompileError("program config schema is invalid", code="invalid_program_config")
    if (
        config.get("schema_version") != 1
        or config.get("config_version") != "automation-goal-programs-v1"
        or config.get("model_lane") != "model-0"
    ):
        raise ProgramCompileError("program config version/lane is invalid", code="invalid_program_config")
    programs = config.get("programs")
    if not isinstance(programs, list) or len(programs) != 1:
        raise ProgramCompileError("program config must contain exactly one program", code="invalid_program_config")
    program = programs[0]
    if not isinstance(program, dict) or set(program) != PROGRAM_FIELDS:
        raise ProgramCompileError("program schema is invalid", code="invalid_program_config")
    if program.get("program_id") != "automation-learning-readonly-audit-v1":
        raise ProgramCompileError("program id is not the v1 audit program", code="invalid_program_config")
    if program.get("task_id") != "automation-learning-watch-v1":
        raise ProgramCompileError("program task id is not promotion-allowlisted", code="invalid_program_config")
    if program["task_id"] not in dispatch_policy["learning"]["promotion_allowlist"]:
        raise ProgramCompileError("program task id is outside dispatch promotion policy", code="invalid_program_config")
    if program.get("enabled") is not True:
        raise ProgramCompileError("program must be explicitly enabled", code="program_disabled")
    template_id = program.get("template_id")
    if template_id != "serverphone_runtime_readonly_analysis_v1" or template_id not in TEMPLATES:
        raise ProgramCompileError("program template is not allowlisted", code="invalid_program_config")
    _safe_id_list(program.get("allowed_goal_ids"), "allowed_goal_ids")
    _safe_id_list(program.get("allowed_target_nodes"), "allowed_target_nodes")
    _safe_id_list(program.get("allowed_resource_ids"), "allowed_resource_ids")
    models = _safe_id_list(program.get("allowed_model_ids"), "allowed_model_ids")
    if set(models) - set(dispatch_policy["allowed_model_ids"]):
        raise ProgramCompileError("program model is outside dispatch policy", code="invalid_program_config")
    efforts = _safe_id_list(program.get("allowed_reasoning_efforts"), "allowed_reasoning_efforts")
    if set(efforts) - reducer.WORKER_REASONING_EFFORTS:
        raise ProgramCompileError("program reasoning effort is not worker-compatible", code="invalid_program_config")
    max_epoch = _positive_integer(program.get("max_goal_epoch"), "max_goal_epoch")
    if max_epoch > dispatch_policy["learning"]["max_goal_epoch"]:
        raise ProgramCompileError("program goal epoch cap exceeds dispatch policy", code="invalid_program_config")

    contract = program.get("task_contract")
    if not isinstance(contract, dict) or set(contract) != TASK_CONTRACT_FIELDS:
        raise ProgramCompileError("program task contract schema is invalid", code="invalid_program_config")
    fixed = {
        "capability": "read_only_analysis",
        "model_decision_by": "main",
        "cwd": "/tmp",
        "profile": "read_only",
        "is_owner": False,
        "target_host": "subphone",
    }
    for field, expected in fixed.items():
        if contract.get(field) != expected:
            raise ProgramCompileError(f"program task contract {field} is unsafe", code="invalid_program_config")
    for field in ("context_tokens", "token_budget", "ttl_seconds", "timeout_seconds"):
        _positive_integer(contract.get(field), f"task_contract.{field}")
    budgets = dispatch_policy["budgets"]
    if contract["context_tokens"] > budgets["max_context_tokens_per_child"]:
        raise ProgramCompileError("program context budget exceeds dispatch policy", code="invalid_program_config")
    if contract["token_budget"] > budgets["max_token_budget_per_child"]:
        raise ProgramCompileError("program token budget exceeds dispatch policy", code="invalid_program_config")
    if contract["token_budget"] > budgets["max_total_tokens_per_goal"]:
        raise ProgramCompileError("program token budget exceeds goal budget", code="invalid_program_config")


def program_hash(program: dict[str, Any]) -> str:
    template_id = program["template_id"]
    return canonical_hash({"program": program, "template_contract": TEMPLATES[template_id]})


def compile_watch_task(
    request: Any,
    programs_config: dict[str, Any] | None = None,
    dispatch_policy: dict[str, Any] | None = None,
) -> dict[str, Any]:
    config = copy.deepcopy(programs_config) if programs_config is not None else _load_json(DEFAULT_PROGRAMS)
    policy = copy.deepcopy(dispatch_policy) if dispatch_policy is not None else reducer.load_policy(DEFAULT_POLICY)
    validate_programs_config(config, policy)
    if not isinstance(request, dict) or set(request) != REQUEST_FIELDS:
        raise ProgramCompileError("compile request schema is invalid")
    if request.get("schema_version") != 1:
        raise ProgramCompileError("compile request schema version is invalid")

    program_id = _safe_id(request.get("program_id"), "program_id")
    program = config["programs"][0]
    if program_id != program["program_id"]:
        raise ProgramCompileError("program is not approved", code="program_not_found")
    goal_id = _safe_id(request.get("goal_id"), "goal_id")
    if goal_id not in program["allowed_goal_ids"]:
        raise ProgramCompileError("goal is not allowlisted", code="parameter_not_allowlisted")
    goal_epoch = _positive_integer(request.get("goal_epoch"), "goal_epoch")
    if goal_epoch > program["max_goal_epoch"]:
        raise ProgramCompileError("goal epoch exceeds program cap", code="parameter_not_allowlisted")
    source_revision = request.get("source_revision")
    if not isinstance(source_revision, str) or HEX40.fullmatch(source_revision) is None:
        raise ProgramCompileError("source_revision must be a lowercase 40-hex revision")
    for field, allowlist in (
        ("target_node", "allowed_target_nodes"),
        ("resource_id", "allowed_resource_ids"),
        ("model_id", "allowed_model_ids"),
        ("reasoning_effort", "allowed_reasoning_efforts"),
    ):
        value = _safe_id(request.get(field), field)
        if value not in program[allowlist]:
            raise ProgramCompileError(f"{field} is not allowlisted", code="parameter_not_allowlisted")

    config_digest = canonical_hash(config)
    program_digest = program_hash(program)
    request_digest = canonical_hash(request)
    template = TEMPLATES[program["template_id"]]
    contract = program["task_contract"]
    prompt = template["prompt"]
    evidence_material = {
        "program_hash": program_digest,
        "compile_request_hash": request_digest,
        "evidence_mode": "runtime_attached_immutable_learning_snapshot",
    }
    input_evidence_hash = canonical_hash(evidence_material)
    task_id = program["task_id"]
    task_without_fingerprint = {
        "task_id": task_id,
        "dependencies": [],
        "resource_id": request["resource_id"],
        "capability": contract["capability"],
        "locks": [],
        "context_tokens": contract["context_tokens"],
        "token_budget": contract["token_budget"],
        "model_id": request["model_id"],
        "model_decision_by": contract["model_decision_by"],
        "risk_flags": [],
        "input_evidence_hash": input_evidence_hash,
        "source_revision": source_revision,
        "prompt": prompt,
        "prompt_bytes": len(prompt.encode("utf-8")),
        "cwd": contract["cwd"],
        "profile": contract["profile"],
        "is_owner": contract["is_owner"],
        "reasoning_effort": request["reasoning_effort"],
        "target_host": contract["target_host"],
        "target_node": request["target_node"],
        "ttl_seconds": contract["ttl_seconds"],
        "timeout_seconds": contract["timeout_seconds"],
        "done_criteria": copy.deepcopy(template["done_criteria"]),
        "forbidden": copy.deepcopy(template["forbidden"]),
        "recurring_watch": True,
    }
    fingerprint_material = {
        "program_hash": program_digest,
        "compile_request_hash": request_digest,
        "task_contract": task_without_fingerprint,
    }
    task_fingerprint = canonical_hash(fingerprint_material)
    classification = {
        "task_id": task_id,
        "task_fingerprint": task_fingerprint,
        "prompt_hash": canonical_hash(prompt),
        "risk_flags": [],
        "classified_by": "main",
    }
    task = {
        **task_without_fingerprint,
        "task_fingerprint": task_fingerprint,
        "risk_assessment": {
            **classification,
            "assessment_hash": canonical_hash(classification),
        },
    }

    # Reuse the production reducer gates without persisting or dispatching.
    validated = seed.compile_seed(goal_id, goal_epoch, [copy.deepcopy(task)], policy)
    if validated.get("next") != [task]:
        raise ProgramCompileError("production seed validation changed the compiled task")
    return {
        "status": "ok",
        "mode": "compile_watch_task",
        "model_lane": "model-0",
        "ai_invocations": 0,
        "config_version": config["config_version"],
        "config_hash": config_digest,
        "program_id": program_id,
        "program_hash": program_digest,
        "compile_request_hash": request_digest,
        "task_count": 1,
        "prompt_hash": canonical_hash(prompt),
        "risk_assessment_hash": task["risk_assessment"]["assessment_hash"],
        "task_hash": canonical_hash(task),
        "watch_tasks": [task],
    }


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--program-id", required=True)
    parser.add_argument("--goal-id", required=True)
    parser.add_argument("--goal-epoch", required=True, type=int)
    parser.add_argument("--source-revision", required=True)
    parser.add_argument("--target-node", required=True)
    parser.add_argument("--resource-id", required=True)
    parser.add_argument("--model-id", required=True)
    parser.add_argument("--reasoning-effort", required=True)
    parser.add_argument("--config", default=str(DEFAULT_PROGRAMS))
    parser.add_argument("--policy", default=str(DEFAULT_POLICY))
    args = parser.parse_args(argv)
    request = {
        "schema_version": 1,
        "program_id": args.program_id,
        "goal_id": args.goal_id,
        "goal_epoch": args.goal_epoch,
        "source_revision": args.source_revision,
        "target_node": args.target_node,
        "resource_id": args.resource_id,
        "model_id": args.model_id,
        "reasoning_effort": args.reasoning_effort,
    }
    try:
        config = _load_json(args.config)
        policy = _load_json(args.policy)
        result = compile_watch_task(request, config, policy)
    except (
        ProgramCompileError,
        reducer.GoalDispatchValidationError,
        seed.SeedValidationError,
        OSError,
        json.JSONDecodeError,
    ) as exc:
        print(
            canonical_json({
                "status": "invalid",
                "error_code": getattr(exc, "code", "invalid_json_or_io"),
                "error": str(exc),
            }),
            file=sys.stderr,
        )
        return 2
    print(canonical_json(result))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
